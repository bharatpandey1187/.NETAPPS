﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public class CurrentConditionSubscriber : ISubscriber, IDisplay
    {
        private IPublisher publisher;
        private float temperature;
        private float humidity;
        private float pressure;
        public CurrentConditionSubscriber(IPublisher publisher)
        {
            this.publisher = publisher;
            publisher.AddSubscriber(this);
        }

        public void Display()
        {
            Console.WriteLine("Temperature: {0}, Humidity:{1}, Pressure:{2}", temperature, humidity, pressure);
        }

        public void Update(float temperature, float pressure, float humidity)
        {
            this.temperature = temperature;
            this.pressure = pressure;
            this.humidity = humidity;
            Display();
        }
    }
}
