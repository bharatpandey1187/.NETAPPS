﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            WeatherDataPublisher publisher = new WeatherDataPublisher();
            CurrentConditionSubscriber currentConditionDisplay = new CurrentConditionSubscriber(publisher);
            StatsSubscriber statsSubscriber = new StatsSubscriber(publisher);
            ForcastSubscriber forcastSubscriber = new ForcastSubscriber(publisher);
            publisher.SetWeatherData(23, 40, 89);

            Console.ReadKey();
        }
    }
}
