﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public class StatsSubscriber : ISubscriber, IDisplay
    {
        private IPublisher weatherDataPublisher;
        private float temperature;
        private float pressure;
        private float humidity;


        public StatsSubscriber(IPublisher weatherDataPublisher)
        {
            this.weatherDataPublisher = weatherDataPublisher;
            this.weatherDataPublisher.AddSubscriber(this);
        }
        public void Display()
        {
            Console.WriteLine("Statistical Display: Temperature:{0}, Humidity:{1}, Pressure:{2}", temperature, humidity, pressure);
        }

        public void Update(float temperature, float pressure, float humidity)
        {
            this.temperature = temperature;
            this.humidity = humidity;
            this.pressure = pressure;
            Display();
        }
    }
}
