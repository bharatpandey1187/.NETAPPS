﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPattern
{
    public class WeatherDataPublisher : IPublisher
    {
        public float Temperature { get; set; }
        public float Pressure { get; set; }
        public float Humidity { get; set; }
        private IList<ISubscriber> Subscribers { get; set; }

        public WeatherDataPublisher()
        {
            Subscribers = new List<ISubscriber>();
        }

        public void SetWeatherData(float temperature, float pressure, float humidity)
        {
            Temperature = temperature;
            Pressure = pressure;
            Humidity = humidity;
            NotifyChanged();
        }

        public bool AddSubscriber(ISubscriber subscriber)
        {
            Subscribers.Add(subscriber);
            return true;
        }

        public bool RemoveSubscriber(ISubscriber subscriber)
        {
            return Subscribers.Remove(subscriber);
        }

        public void NotifySubscriber()
        {
            foreach (var subscriber in Subscribers)
            {
                subscriber.Update(Temperature, Pressure, Humidity);
            }
        }

        public void NotifyChanged()
        {
            NotifySubscriber();
        }
    }
}
