﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonDesignPattern
{
    public sealed class BetterPracticeWithoutLock
    {
        private static readonly Lazy<BetterPracticeWithoutLock> lazy = new Lazy<BetterPracticeWithoutLock>(() => new BetterPracticeWithoutLock());

        static BetterPracticeWithoutLock()
        {
            Console.WriteLine("Static Constructor Called.");
        }

        public static string Name { get; set; }

        public static BetterPracticeWithoutLock Instance
        {

            get
            {
                if (lazy.Value != default(BetterPracticeWithoutLock))
                {
                    return lazy.Value;
                }
                else
                {
                    Console.WriteLine("New Instance Created");
                    return new BetterPracticeWithoutLock();
                }
            }
        }

        public void Log(string message) => Console.WriteLine(message);
    }
}
