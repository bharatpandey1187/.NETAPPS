﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonDesignPattern
{
    public sealed class GoodPracticeWithLock
    {
        private static GoodPracticeWithLock logger;
        private static readonly object syncLock = new object();

        public GoodPracticeWithLock()
        {
            Console.WriteLine("Constructor Called");
        }

        public static GoodPracticeWithLock Instance
        {
            get
            {
                lock (syncLock)
                {
                    if (logger == default(GoodPracticeWithLock))
                    {
                        Console.WriteLine("Instance Created");

                        logger = new GoodPracticeWithLock();
                    }
                }

                return logger;
            }
        }

        public void Log(string message) => Console.WriteLine(message);
    }
}
