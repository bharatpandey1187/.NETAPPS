﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonDesignPattern
{
    public sealed class GoodPracticeWithDoubleLock
    {
        private static GoodPracticeWithDoubleLock logger;
        private static readonly object syncLock = new object();

        public GoodPracticeWithDoubleLock()
        {
            Console.WriteLine("Constructor Called");
        }

        public static GoodPracticeWithDoubleLock Instance
        {
            get
            {
                if (logger == default(GoodPracticeWithDoubleLock))
                {
                    lock (syncLock)
                    {
                        if (logger == default(GoodPracticeWithDoubleLock))
                        {
                            Console.WriteLine("Instance Created");

                            logger = new GoodPracticeWithDoubleLock();
                        }
                    }
                }

                return logger;
            }
        }

        public void Log(string message) => Console.WriteLine(message);
    }

}
