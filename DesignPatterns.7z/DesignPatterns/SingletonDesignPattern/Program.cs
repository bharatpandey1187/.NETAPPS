﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonDesignPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            //Bad Practice

            Console.WriteLine("--------------------------------Run 1--------------------");
            Console.Write($"Run Start At:{DateTime.Now}");
            stopwatch.Start();
            Parallel.ForEach(Enumerable.Range(1, 100), (index) =>
            {
                BadLogger.Instance.Log($"Hello From Method at Index:{index }");
            });
            stopwatch.Stop();
            Console.Write($"Run End At:{DateTime.Now}");

            Console.WriteLine(GetPerformance(stopwatch));
            stopwatch.Reset();
            Console.WriteLine("--------------------------------End of Run 1--------------------");


            Console.WriteLine("--------------------------------Run 2--------------------");
            Console.Write($"Run Start At:{DateTime.Now}");
            stopwatch.Start();
            Parallel.ForEach(Enumerable.Range(1, 100), (index) =>

            {
                GoodPracticeWithLock.Instance.Log($"Hello From Method at Index:{index }");
            });
            stopwatch.Stop();
            Console.Write($"Run End At:{DateTime.Now}");
            Console.WriteLine(GetPerformance(stopwatch));
            stopwatch.Reset();
            Console.WriteLine("--------------------------------End Of Run 2--------------------");

            Console.WriteLine("--------------------------------Run 3: Double Lock--------------------");
            Console.Write($"Run Start At:{DateTime.Now}");
            stopwatch.Start();
            Parallel.ForEach(Enumerable.Range(1, 100), (index) =>
            {
                GoodPracticeWithDoubleLock.Instance.Log($"Hello From Method at Index:{index }");
            });

            stopwatch.Stop();
            Console.Write($"Run End At:{DateTime.Now}");
           
            Console.WriteLine(GetPerformance(stopwatch));
            stopwatch.Reset();
            Console.WriteLine("--------------------------------End Of Run 3--------------------");

            Console.WriteLine("--------------------------------Run 4: Best Approach--------------------");
            Console.Write($"Run Start At:{DateTime.Now}");
            stopwatch.Start();
            Parallel.ForEach(Enumerable.Range(1, 100), (index) =>
            {
                BetterPracticeWithoutLock.Instance.Log($"Hello From Method at Index:{index }");
            });
            stopwatch.Stop();
            Console.Write($"Run End At:{DateTime.Now}");
            Console.WriteLine(GetPerformance(stopwatch));
            stopwatch.Reset();
            Console.WriteLine("--------------------------------End Of Run 4--------------------");

            Console.ReadKey();




        }

        public static string GetPerformance(Stopwatch stopwatch) => $"Total Time Taken On Execution (In ms- {((double)stopwatch.ElapsedTicks / Stopwatch.Frequency * 1000).ToString()}";
    }
}
