﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonDesignPattern
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class BadLogger
    {
        private static BadLogger badLogger;
        public BadLogger()
        {
            Console.WriteLine("Constructor Called");
        }

        /// <summary>
        /// Gets the instance.
        /// </summary>
        /// <value>
        /// The instance.
        /// </value>
        public static BadLogger Instance
        {
            get
            {
                if (badLogger == default(BadLogger))
                {
                    Console.WriteLine("Instance Created..");
                    badLogger = new BadLogger();
                }

                return badLogger;
            }
        }

        public void Log(string message) => Console.WriteLine(message);
    }
}
