﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.GoodPractice
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="StrategyPattern.GoodPractice.IFlyBehavior" />
    public class FlyBehavior : IFlyBehavior
    {
        private string duckType;
        public FlyBehavior(string duckType) => this.duckType = duckType;
        public void Fly() => Console.WriteLine($"Fly => For {duckType}");
    }
}
