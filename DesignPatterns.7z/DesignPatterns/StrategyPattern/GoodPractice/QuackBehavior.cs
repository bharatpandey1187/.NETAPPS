﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.GoodPractice
{
    public class QuackBehavior : IQuackBehavior
    {
        private string duckType;
        public QuackBehavior(string duckType) => this.duckType = duckType;
        public void Quack() => Console.WriteLine($"Quack-> For {duckType}");
    }
}
