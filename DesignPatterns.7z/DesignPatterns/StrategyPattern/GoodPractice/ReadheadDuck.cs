﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.GoodPractice
{
    public class ReadheadDuck : Duck
    {
        public ReadheadDuck(IFlyBehavior flyBehavior, IQuackBehavior quackBehavior) : base(flyBehavior, quackBehavior)
        {
        }

        public override void Display()
        {
            this.FlyBehavior?.Fly();
            this.QuackBehavior?.Quack();
        }
    }
}
