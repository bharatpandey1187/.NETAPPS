﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.GoodPractice
{
    public class RocketPoweredFlyingBehavior : IFlyBehavior
    {
        private string duckType;
        public RocketPoweredFlyingBehavior(string duckType) => this.duckType = duckType;
        public void Fly() => Console.WriteLine($"Inside Rocket Powered Flying For Duck: {duckType}");
    }
}
