﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.GoodPractice
{
    public class RubberDuck : Duck
    {
        public RubberDuck(IQuackBehavior quackBehavior) : base(null, quackBehavior)
        {
        }

        public override void Display()
        {
            this.QuackBehavior?.Quack();
        }
    }
}
