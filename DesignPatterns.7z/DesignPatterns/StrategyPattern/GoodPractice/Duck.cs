﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.GoodPractice
{
    public abstract class Duck
    {
        public IQuackBehavior QuackBehavior
        {
            get;
            private set;
        }

        public IFlyBehavior FlyBehavior
        {
            get;
            private set;
        }

        public Duck() { }
        public Duck(IFlyBehavior flyBehavior, IQuackBehavior quackBehavior)
        {
            this.FlyBehavior = flyBehavior;
            this.QuackBehavior = quackBehavior;
        }
        public virtual void Display() => Console.WriteLine("Duck:Display");

        public void PerformFly()
        {
            this.FlyBehavior.Fly();
        }
        public void PerformQuack()
        {
            this.QuackBehavior.Quack();
        }
    }
}
