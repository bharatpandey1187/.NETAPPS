﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.BadPractice
{
    public class Duck
    {
        private string duckType;
        public Duck(string duckType) => this.duckType = duckType;
        public void Display() => Console.WriteLine($"Duck:{duckType} Display");

        public void Quack() => Console.WriteLine($"Duck:{duckType}-Quack");

        public void Fly() => Console.WriteLine($"Duck:{duckType}:Fly");
    }
}
