﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.BadPractice
{
    public class RubberDuck : Duck
    {
        public RubberDuck(string duckType) : base(duckType) { }
        // THESE TYPE OF DUCK's CANNOT FLY BUT QUACK BUT BECAUSE DUCK USES INHERITANCE, SO THEY CAN NOW FLY
    }
}
