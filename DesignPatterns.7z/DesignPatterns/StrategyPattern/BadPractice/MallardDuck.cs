﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.BadPractice
{
    public class MallardDuck : Duck
    {
        public MallardDuck(string duckType) : base(duckType) { }
    }
}
