﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern.BadPractice
{
    public class DecoyDuck : Duck
    {
        public DecoyDuck(string duckType) : base(duckType) { }
        //THESE SHOULD BE FOR DUMMY DUCK WHICH NEITHER CAN FLY OR QUACK. BUT AGAIN, INHERITANCE MESSED UP THE THINGS
    }
}
