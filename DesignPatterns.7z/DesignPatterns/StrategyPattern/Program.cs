﻿using Bad = StrategyPattern.BadPractice;
using Good = StrategyPattern.GoodPractice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*****************************START-BAD PRACTICE EXAMPLE************************");
            List<Bad.Duck> badPracticeDucks = new List<Bad.Duck>
            {
                new Bad.MallardDuck("Mallard"),
                new Bad.RedheadDuck("Redhead"),
                new Bad.RubberDuck("Rubber"),
                new Bad.DecoyDuck("Decoy")
            };

            foreach (var duck in badPracticeDucks)
            {
                duck.Display();
                duck.Fly();
                duck.Quack();
            }
            Console.WriteLine("*****************************END-BAD PRACTICE EXAMPLE************************");


            Console.WriteLine("*****************************START-GOOD PRACTICE EXAMPLE************************");

            List<Good.Duck> goodPracticeDucks = new List<Good.Duck>
            {
                new Good.MallardDuck(new Good.FlyBehavior("Mallard"),new Good.QuackBehavior("Mallard")),
                new Good.ReadheadDuck(new Good.FlyBehavior("Readhead"),new Good.QuackBehavior("Readhead")),
                new Good.RubberDuck(new Good.QuackBehavior("Rubber")),
                new Good.DecoyDuck()
            };

            foreach (var duck in goodPracticeDucks)
            {
                duck.Display();                
            }


            Console.WriteLine("*****************************END-GOOD PRACTICE EXAMPLE************************");
            Console.ReadKey();
        }
    }
}
