﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.PurgeDocumentsRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IPurgeDocumentsRepository))]
  public class PurgeDocumentsRepository : RepositoryBase, IPurgeDocumentsRepository
  {
    private Dictionary<string, string> knownMappings;

    public PurgeDocumentsRepository(Dictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public IDataReader FetchAllPurgeDocuments(
      long entityType,
      DateTime startDate,
      DateTime endDate)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllDocumentsBasedOnEntityType"))
      {
        this.db.AddInParameter(storedProcCommand, "@entityType", SqlDbType.BigInt, (object) entityType);
        this.db.AddInParameter(storedProcCommand, "@startDate", SqlDbType.DateTime, (object) startDate);
        SqlDatabase db = this.db;
        DbCommand command = storedProcCommand;
        DateTime dateTime = endDate.Date;
        dateTime = dateTime.AddHours(23.0);
        dateTime = dateTime.AddMinutes(59.0);
        // ISSUE: variable of a boxed type
        __Boxed<DateTime> local = (System.ValueType) dateTime.AddSeconds(59.0);
        db.AddInParameter(command, "@endDate", SqlDbType.DateTime, (object) local);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void DeleteOrUpdateDocumentsBasedOnId(string docIDs)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteDocumentsBasedOnId"))
      {
        this.db.AddInParameter(storedProcCommand, "@docIDs", SqlDbType.VarChar, (object) docIDs);
        this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchAllEntityTypes(int showSearchEntityType)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllEntityTypes"))
      {
        this.db.AddInParameter(storedProcCommand, "@ShowSearchEntityType", SqlDbType.Int, (object) showSearchEntityType);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
