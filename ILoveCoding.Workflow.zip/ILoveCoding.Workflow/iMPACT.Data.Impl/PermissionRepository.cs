﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.PermissionRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IPermissionRepository))]
  public class PermissionRepository : RepositoryBase, IPermissionRepository
  {
    public bool HasPermission(int[] principals, int permission)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPermissionByPrincipal"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        this.db.AddInParameter(storedProcCommand, "@Permissions", DbType.String, (object) permission.ToString());
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read();
      }
    }

    public bool HasPermission(int[] principals, long entityId, int permission) => throw new NotImplementedException();

    public bool HasAnyPermission(int[] principals, int[] permissions)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPermissionByPrincipal"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        this.db.AddInParameter(storedProcCommand, "@Permissions", DbType.String, (object) string.Join(",", ((IEnumerable<int>) permissions).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read();
      }
    }

    public IrisSoftware.iMPACT.Core.Security.Permission[] GetPermission(int[] principals)
    {
      List<IrisSoftware.iMPACT.Core.Security.Permission> permissionList = new List<IrisSoftware.iMPACT.Core.Security.Permission>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPermissionByPrincipal"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<IrisSoftware.iMPACT.Core.Security.Permission> rowMapper = MapBuilder<IrisSoftware.iMPACT.Core.Security.Permission>.MapAllProperties().Map<string>((Expression<Func<IrisSoftware.iMPACT.Core.Security.Permission, string>>) (x => x.EntityPermission)).ToColumn("Permission").Build();
          while (dataReader.Read())
            permissionList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return permissionList.ToArray();
    }

    public IrisSoftware.iMPACT.Core.Security.Permission[] GetPermission(
      long entityTypeId,
      long entityId,
      int[] principals)
    {
      List<IrisSoftware.iMPACT.Core.Security.Permission> permissionList = new List<IrisSoftware.iMPACT.Core.Security.Permission>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_FetchPermissionByEntityTypeIdEntityId]"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityTypeId", DbType.Int64, (object) entityTypeId);
        this.db.AddInParameter(storedProcCommand, "@EntityId", DbType.Int64, (object) entityId);
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<IrisSoftware.iMPACT.Core.Security.Permission> rowMapper = MapBuilder<IrisSoftware.iMPACT.Core.Security.Permission>.MapAllProperties().Map<string>((Expression<Func<IrisSoftware.iMPACT.Core.Security.Permission, string>>) (x => x.EntityPermission)).ToColumn("Permission").Build();
          while (dataReader.Read())
            permissionList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return permissionList.ToArray();
    }

    public bool CheckPermission(
      long? entityTypeId,
      string[] uiName,
      string permission,
      int[] principals)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_CheckPermissionByEntityID]"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        if (entityTypeId.HasValue)
          this.db.AddInParameter(storedProcCommand, "@EntityTypeID", DbType.Int32, (object) entityTypeId);
        else
          this.db.AddInParameter(storedProcCommand, "@EntityTypeID", DbType.Int32, (object) DBNull.Value);
        if (uiName != null && uiName.Length != 0)
          this.db.AddInParameter(storedProcCommand, "@UIName", DbType.String, (object) string.Join(",", uiName));
        this.db.AddInParameter(storedProcCommand, "@Permission", DbType.String, (object) permission);
        return this.db.ExecuteScalar(storedProcCommand).ToString() == "1";
      }
    }

    public bool CheckPermission(
      long? entityTypeId,
      List<Tuple<string, string>> uiNamePermissionList,
      int[] principals)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_CheckUserPermission]"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        if (entityTypeId.HasValue)
          this.db.AddInParameter(storedProcCommand, "@EntityTypeID", DbType.Int32, (object) entityTypeId);
        else
          this.db.AddInParameter(storedProcCommand, "@EntityTypeID", DbType.Int32, (object) DBNull.Value);
        DataTable dataTable = new DataTable();
        DataColumn column1 = new DataColumn("UIName", typeof (string));
        DataColumn column2 = new DataColumn("Permission", typeof (string));
        dataTable.Columns.Add(column1);
        dataTable.Columns.Add(column2);
        foreach (Tuple<string, string> uiNamePermission in uiNamePermissionList)
        {
          DataRow row = dataTable.NewRow();
          row["UIName"] = (object) uiNamePermission.Item1;
          row["Permission"] = (object) uiNamePermission.Item2;
          dataTable.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblUiNamePermission", SqlDbType.Structured, (object) dataTable);
        return this.db.ExecuteScalar(storedProcCommand).ToString() == "1";
      }
    }

    public IrisSoftware.iMPACT.Core.Security.Permission[] GetPermissionByEntityTypeID(
      int[] principals,
      long entityTypeId)
    {
      List<IrisSoftware.iMPACT.Core.Security.Permission> permissionList = new List<IrisSoftware.iMPACT.Core.Security.Permission>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_FetchPermissionByEntityTypeID]"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        this.db.AddInParameter(storedProcCommand, "@EntityTypeID", DbType.Int32, (object) entityTypeId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<IrisSoftware.iMPACT.Core.Security.Permission> rowMapper = MapBuilder<IrisSoftware.iMPACT.Core.Security.Permission>.MapAllProperties().Map<string>((Expression<Func<IrisSoftware.iMPACT.Core.Security.Permission, string>>) (x => x.EntityPermission)).ToColumn("Permission").Build();
          while (dataReader.Read())
            permissionList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return permissionList.ToArray();
    }

    public IrisSoftware.iMPACT.Core.Security.Permission[] GetPermissionByAppTransIDStatusID(
      int[] principals,
      long appTransID)
    {
      List<IrisSoftware.iMPACT.Core.Security.Permission> permissionList = new List<IrisSoftware.iMPACT.Core.Security.Permission>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_FetchPermissionByAppTransIDStatusID]"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        this.db.AddInParameter(storedProcCommand, "@AppTransID", DbType.Int64, (object) appTransID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<IrisSoftware.iMPACT.Core.Security.Permission> rowMapper = MapBuilder<IrisSoftware.iMPACT.Core.Security.Permission>.MapAllProperties().Map<string>((Expression<Func<IrisSoftware.iMPACT.Core.Security.Permission, string>>) (x => x.EntityPermission)).ToColumn("Permission").Build();
          while (dataReader.Read())
            permissionList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return permissionList.ToArray();
    }

    public IrisSoftware.iMPACT.Core.Security.Permission[] GetIndependentPermission(
      int[] principals)
    {
      List<IrisSoftware.iMPACT.Core.Security.Permission> permissionList = new List<IrisSoftware.iMPACT.Core.Security.Permission>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_FetchIndependentPermissions]"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<IrisSoftware.iMPACT.Core.Security.Permission> rowMapper = MapBuilder<IrisSoftware.iMPACT.Core.Security.Permission>.MapAllProperties().Map<string>((Expression<Func<IrisSoftware.iMPACT.Core.Security.Permission, string>>) (x => x.EntityPermission)).ToColumn("Permission").Build();
          while (dataReader.Read())
            permissionList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return permissionList.ToArray();
    }
  }
}
