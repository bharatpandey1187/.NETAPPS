﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.Formula.FormulaDependencyResolvingVisitor
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.Core.DataStructure;
using IrisSoftware.Core.Formula.Ast;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Data.Impl.Formula
{
  public class FormulaDependencyResolvingVisitor : AstVisitorBase
  {
    private FormulaDependencyResolvingVisitor.VisitResult visitContext = new FormulaDependencyResolvingVisitor.VisitResult();
    private readonly ScopedHash<string> allFormulae;
    private readonly Dictionary<string, FormulaDependencyResolvingVisitor.VisitResult> resolvedSymbols;
    private readonly Stack<FormulaDependencyResolvingVisitor.VisitResult> contextStack = new Stack<FormulaDependencyResolvingVisitor.VisitResult>();

    public FormulaDependencyResolvingVisitor(
      ScopedHash<string> allFormulae,
      Dictionary<string, FormulaDependencyResolvingVisitor.VisitResult> resolvedSymbols)
    {
      this.allFormulae = allFormulae;
      this.resolvedSymbols = resolvedSymbols;
    }

    public FormulaDependencyResolvingVisitor.VisitResult ResolveDependencies(
      AstNode node)
    {
      this.visitContext = new FormulaDependencyResolvingVisitor.VisitResult();
      node.Accept((IAstVisitor) this);
      this.visitContext.Rank = this.visitContext.Dependencies.Count > 0 ? this.visitContext.Dependencies.Select<string, int>((Func<string, int>) (k => this.resolvedSymbols[k].Rank)).Max() + 1 : 1;
      return this.visitContext;
    }

    public override void VisitIdentifier(IdentifierNode identifierNode)
    {
      if (!this.resolvedSymbols.ContainsKey(identifierNode.Text))
      {
        this.visitContext.Dependencies.Add(identifierNode.Text);
        AstNode node = AstParser.Parse(this.allFormulae[identifierNode.Text]);
        this.contextStack.Push(this.visitContext);
        FormulaDependencyResolvingVisitor.VisitResult visitResult = this.ResolveDependencies(node);
        this.resolvedSymbols.Add(identifierNode.Text, visitResult);
        this.visitContext = this.contextStack.Pop();
        foreach (string dependency in visitResult.Dependencies)
          this.visitContext.Dependencies.Add(dependency);
      }
      else
      {
        this.visitContext.Dependencies.Add(identifierNode.Text);
        foreach (string dependency in this.resolvedSymbols[identifierNode.Text].Dependencies)
          this.visitContext.Dependencies.Add(dependency);
      }
    }

    public class VisitResult
    {
      public HashSet<string> Dependencies { get; set; }

      public int Rank { get; set; }

      public VisitResult() => this.Dependencies = new HashSet<string>();
    }
  }
}
