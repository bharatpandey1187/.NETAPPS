﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.ExpenseRevenueRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IExpenseRevenueRepository))]
  public class ExpenseRevenueRepository : RepositoryBase, IExpenseRevenueRepository
  {
    public ExpenseRevenue FetchExpenseRevenueByAppTransactionId(
      long appTransactionId,
      bool isRefresh)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchExpenseRevenueByAppTransactionId"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        this.db.AddInParameter(storedProcCommand, "@IsRefresh", DbType.Boolean, (object) isRefresh);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (!reader.Read())
            return new ExpenseRevenue();
          ExpenseRevenue expenseRevenue = MapBuilder<ExpenseRevenue>.MapAllProperties().Build().MapRow((IDataRecord) reader);
          if (reader.NextResult())
            expenseRevenue.SyndicateMember = this.GetSyndicateDetails(reader);
          if (reader.NextResult())
            expenseRevenue.ExpenseRevenueHistory = this.GetExpenseRevenueHistory(reader);
          return expenseRevenue;
        }
      }
    }

    public ExpenseRevenue FetchExpenseRevenueHistoryByExpenseRevenueId(
      long expenseRevenueId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_FetchExpenseRevenueHistoryByExpenseRevenueId"))
      {
        this.db.AddInParameter(storedProcCommand, "@ExpenseRevenueId", DbType.Int64, (object) expenseRevenueId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (!reader.Read())
            return new ExpenseRevenue();
          ExpenseRevenue expenseRevenue = MapBuilder<ExpenseRevenue>.MapAllProperties().Build().MapRow((IDataRecord) reader);
          if (reader.NextResult())
            expenseRevenue.SyndicateMember = this.GetSyndicateDetails(reader);
          return expenseRevenue;
        }
      }
    }

    private List<ExpenseRevenueHistory> GetExpenseRevenueHistory(
      IDataReader reader)
    {
      List<ExpenseRevenueHistory> expenseRevenueHistoryList = new List<ExpenseRevenueHistory>();
      IRowMapper<ExpenseRevenueHistory> rowMapper = MapBuilder<ExpenseRevenueHistory>.MapAllProperties().Build();
      while (reader.Read())
        expenseRevenueHistoryList.Add(rowMapper.MapRow((IDataRecord) reader));
      return expenseRevenueHistoryList;
    }

    private List<ExpenseRevenueSyndicate> GetSyndicateDetails(
      IDataReader reader)
    {
      List<ExpenseRevenueSyndicate> revenueSyndicateList = new List<ExpenseRevenueSyndicate>();
      IRowMapper<ExpenseRevenueSyndicate> rowMapper = MapBuilder<ExpenseRevenueSyndicate>.MapAllProperties().Build();
      while (reader.Read())
        revenueSyndicateList.Add(rowMapper.MapRow((IDataRecord) reader));
      return revenueSyndicateList;
    }

    public long SaveExpenseRevenue(ExpenseRevenue expenseRevenue, bool isMoveAccrualToHistory)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveExpenseRevenue"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) expenseRevenue.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@ERNumber", DbType.String, (object) expenseRevenue.ERNumber);
        this.db.AddInParameter(storedProcCommand, "@IssueNumber", DbType.String, (object) expenseRevenue.IssueNumber);
        this.db.AddInParameter(storedProcCommand, "@IssueStatus", DbType.String, (object) expenseRevenue.IssueStatus);
        this.db.AddInParameter(storedProcCommand, "@ReviewStatus", DbType.String, (object) expenseRevenue.ReviewStatus);
        this.db.AddInParameter(storedProcCommand, "@ERStatus", DbType.String, (object) expenseRevenue.ERStatus);
        this.db.AddInParameter(storedProcCommand, "@IssueName", DbType.String, (object) expenseRevenue.IssueName);
        this.db.AddInParameter(storedProcCommand, "@IssuerID", DbType.Int64, (object) expenseRevenue.IssuerId);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.Int64, (object) expenseRevenue.StateId);
        this.db.AddInParameter(storedProcCommand, "@FirmRole", DbType.Int64, (object) expenseRevenue.FirmRoleId);
        this.db.AddInParameter(storedProcCommand, "@OfferingType", DbType.Int64, (object) expenseRevenue.OfferingTypeId);
        this.db.AddInParameter(storedProcCommand, "@SaleDate ", DbType.DateTime, (object) expenseRevenue.SaleDate);
        this.db.AddInParameter(storedProcCommand, "@SettlementClosingDate", DbType.DateTime, (object) expenseRevenue.SettlementClosingDate);
        this.db.AddInParameter(storedProcCommand, "@ParAmount", DbType.Decimal, (object) expenseRevenue.ParAmount);
        this.db.AddInParameter(storedProcCommand, "@NbrOfSeries", DbType.Int32, (object) expenseRevenue.NbrOfSeries);
        this.db.AddInParameter(storedProcCommand, "@NbrOfCusip", DbType.Int32, (object) expenseRevenue.NbrOfCusip);
        this.db.AddInParameter(storedProcCommand, "@FirmLiabilityPerc", DbType.Decimal, (object) expenseRevenue.FirmLiabilityPerc);
        this.db.AddInParameter(storedProcCommand, "@FirmMgmtFeePerc", DbType.Decimal, (object) expenseRevenue.FirmMgmtFeePerc);
        this.db.AddInParameter(storedProcCommand, "@ExpenseRevenueSyndicateTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<ExpenseRevenueSyndicate>(expenseRevenue.SyndicateMember));
        this.db.AddInParameter(storedProcCommand, "@ProjManagementFee", DbType.Decimal, (object) expenseRevenue.ProjManagementFee);
        this.db.AddInParameter(storedProcCommand, "@ProjManagementFeePerThou", DbType.Decimal, (object) expenseRevenue.ProjManagementFeePerThou);
        this.db.AddInParameter(storedProcCommand, "@ProjTakedown", DbType.Decimal, (object) expenseRevenue.ProjTakedown);
        this.db.AddInParameter(storedProcCommand, "@ProjTakedownPerThou", DbType.Decimal, (object) expenseRevenue.ProjTakedownPerThou);
        this.db.AddInParameter(storedProcCommand, "@ProjExpenses", DbType.Decimal, (object) expenseRevenue.ProjExpenses);
        this.db.AddInParameter(storedProcCommand, "@ProjExpensesPerThou", DbType.Decimal, (object) expenseRevenue.ProjExpensesPerThou);
        this.db.AddInParameter(storedProcCommand, "@ProjStructuringFee", DbType.Decimal, (object) expenseRevenue.ProjStructuringFee);
        this.db.AddInParameter(storedProcCommand, "@ProjStructuringFeePerThou", DbType.Decimal, (object) expenseRevenue.ProjStructuringFeePerThou);
        this.db.AddInParameter(storedProcCommand, "@ProjGrossSpread", DbType.Decimal, (object) expenseRevenue.ProjGrossSpread);
        this.db.AddInParameter(storedProcCommand, "@ProjGrossSpreadPerThou", DbType.Decimal, (object) expenseRevenue.ProjGrossSpreadPerThou);
        this.db.AddInParameter(storedProcCommand, "@ActManagementFee", DbType.Decimal, (object) expenseRevenue.ActManagementFee);
        this.db.AddInParameter(storedProcCommand, "@ActManagementFeePerThou", DbType.Decimal, (object) expenseRevenue.ActManagementFeePerThou);
        this.db.AddInParameter(storedProcCommand, "@ActTakedown", DbType.Decimal, (object) expenseRevenue.ActTakedown);
        this.db.AddInParameter(storedProcCommand, "@ActTakedownPerThou", DbType.Decimal, (object) expenseRevenue.ActTakedownPerThou);
        this.db.AddInParameter(storedProcCommand, "@ActExpenses", DbType.Decimal, (object) expenseRevenue.ActExpenses);
        this.db.AddInParameter(storedProcCommand, "@ActExpensesPerThou", DbType.Decimal, (object) expenseRevenue.ActExpensesPerThou);
        this.db.AddInParameter(storedProcCommand, "@ActStructuringFee", DbType.Decimal, (object) expenseRevenue.ActStructuringFee);
        this.db.AddInParameter(storedProcCommand, "@ActStructuringFeePerThou", DbType.Decimal, (object) expenseRevenue.ActStructuringFeePerThou);
        this.db.AddInParameter(storedProcCommand, "@ActGrossSpread", DbType.Decimal, (object) expenseRevenue.ActGrossSpread);
        this.db.AddInParameter(storedProcCommand, "@ActGrossSpreadPerThou", DbType.Decimal, (object) expenseRevenue.ActGrossSpreadPerThou);
        this.db.AddInParameter(storedProcCommand, "@ProjFirmUnderwritingRevenue", DbType.Decimal, (object) expenseRevenue.ProjFirmUnderwritingRevenue);
        this.db.AddInParameter(storedProcCommand, "@ProjFinancialAdvisory", DbType.Decimal, (object) expenseRevenue.ProjFinancialAdvisory);
        this.db.AddInParameter(storedProcCommand, "@ProjRemarketingFee", DbType.Decimal, (object) expenseRevenue.ProjRemarketingFee);
        this.db.AddInParameter(storedProcCommand, "@ProjOtherFee", DbType.Decimal, (object) expenseRevenue.ProjOtherFee);
        this.db.AddInParameter(storedProcCommand, "@ProjTotalRevenues", DbType.Decimal, (object) expenseRevenue.ProjTotalRevenues);
        this.db.AddInParameter(storedProcCommand, "@ActFirmUnderwritingRevenue", DbType.Decimal, (object) expenseRevenue.ActFirmUnderwritingRevenue);
        this.db.AddInParameter(storedProcCommand, "@ActFinancialAdvisory", DbType.Decimal, (object) expenseRevenue.ActFinancialAdvisory);
        this.db.AddInParameter(storedProcCommand, "@ActRemarketingFee", DbType.Decimal, (object) expenseRevenue.ActRemarketingFee);
        this.db.AddInParameter(storedProcCommand, "@ActOtherFee", DbType.Decimal, (object) expenseRevenue.ActOtherFee);
        this.db.AddInParameter(storedProcCommand, "@ActTotalRevenues", DbType.Decimal, (object) expenseRevenue.ActTotalRevenues);
        this.db.AddInParameter(storedProcCommand, "@ProjCUSIP", DbType.Decimal, (object) expenseRevenue.ProjCUSIP);
        this.db.AddInParameter(storedProcCommand, "@ProjCalPSA", DbType.Decimal, (object) expenseRevenue.ProjCalPSA);
        this.db.AddInParameter(storedProcCommand, "@ProjMSRB", DbType.Decimal, (object) expenseRevenue.ProjMSRB);
        this.db.AddInParameter(storedProcCommand, "@ProjCDIAC", DbType.Decimal, (object) expenseRevenue.ProjCDIAC);
        this.db.AddInParameter(storedProcCommand, "@ProjSIFMA", DbType.Decimal, (object) expenseRevenue.ProjSIFMA);
        this.db.AddInParameter(storedProcCommand, "@ProjCalMuniStats", DbType.Decimal, (object) expenseRevenue.ProjCalMuniStats);
        this.db.AddInParameter(storedProcCommand, "@ProjBookrunningCharges", DbType.Decimal, (object) expenseRevenue.ProjBookrunningCharges);
        this.db.AddInParameter(storedProcCommand, "@ProjCMBDA", DbType.Decimal, (object) expenseRevenue.ProjCMBDA);
        this.db.AddInParameter(storedProcCommand, "@ProjDayLoan", DbType.Decimal, (object) expenseRevenue.ProjDayLoan);
        this.db.AddInParameter(storedProcCommand, "@ProjMACMI", DbType.Decimal, (object) expenseRevenue.ProjMACMI);
        this.db.AddInParameter(storedProcCommand, "@ProjTicketing", DbType.Decimal, (object) expenseRevenue.ProjTicketing);
        this.db.AddInParameter(storedProcCommand, "@ProjMIPF", DbType.Decimal, (object) expenseRevenue.ProjMIPF);
        this.db.AddInParameter(storedProcCommand, "@ProjTelecommunication", DbType.Decimal, (object) expenseRevenue.ProjTelecommunication);
        this.db.AddInParameter(storedProcCommand, "@ProjMACTX", DbType.Decimal, (object) expenseRevenue.ProjMACTX);
        this.db.AddInParameter(storedProcCommand, "@ProjLegal", DbType.Decimal, (object) expenseRevenue.ProjLegal);
        this.db.AddInParameter(storedProcCommand, "@ProjMACOH", DbType.Decimal, (object) expenseRevenue.ProjMACOH);
        this.db.AddInParameter(storedProcCommand, "@ProjDTCCharges", DbType.Decimal, (object) expenseRevenue.ProjDTCCharges);
        this.db.AddInParameter(storedProcCommand, "@ProjLessExpenseReimbursement", DbType.Decimal, (object) expenseRevenue.ProjLessExpenseReimbursement);
        this.db.AddInParameter(storedProcCommand, "@ProjClearanceExpenses", DbType.Decimal, (object) expenseRevenue.ProjClearanceExpenses);
        this.db.AddInParameter(storedProcCommand, "@ProjOtherExpenses", DbType.Decimal, (object) expenseRevenue.ProjOtherExpenses);
        this.db.AddInParameter(storedProcCommand, "@ProjTotalFinancingExpenses", DbType.Decimal, (object) expenseRevenue.ProjTotalFinancingExpenses);
        this.db.AddInParameter(storedProcCommand, "@ActCUSIP", DbType.Decimal, (object) expenseRevenue.ActCUSIP);
        this.db.AddInParameter(storedProcCommand, "@ActCalPSA", DbType.Decimal, (object) expenseRevenue.ActCalPSA);
        this.db.AddInParameter(storedProcCommand, "@ActMSRB", DbType.Decimal, (object) expenseRevenue.ActMSRB);
        this.db.AddInParameter(storedProcCommand, "@ActCDIAC", DbType.Decimal, (object) expenseRevenue.ActCDIAC);
        this.db.AddInParameter(storedProcCommand, "@ActSIFMA", DbType.Decimal, (object) expenseRevenue.ActSIFMA);
        this.db.AddInParameter(storedProcCommand, "@ActCalMuniStats", DbType.Decimal, (object) expenseRevenue.ActCalMuniStats);
        this.db.AddInParameter(storedProcCommand, "@ActBookrunningCharges", DbType.Decimal, (object) expenseRevenue.ActBookrunningCharges);
        this.db.AddInParameter(storedProcCommand, "@ActCMBDA", DbType.Decimal, (object) expenseRevenue.ActCMBDA);
        this.db.AddInParameter(storedProcCommand, "@ActDayLoan", DbType.Decimal, (object) expenseRevenue.ActDayLoan);
        this.db.AddInParameter(storedProcCommand, "@ActMACMI", DbType.Decimal, (object) expenseRevenue.ActMACMI);
        this.db.AddInParameter(storedProcCommand, "@ActTicketing", DbType.Decimal, (object) expenseRevenue.ActTicketing);
        this.db.AddInParameter(storedProcCommand, "@ActMIPF", DbType.Decimal, (object) expenseRevenue.ActMIPF);
        this.db.AddInParameter(storedProcCommand, "@ActTelecommunication", DbType.Decimal, (object) expenseRevenue.ActTelecommunication);
        this.db.AddInParameter(storedProcCommand, "@ActMACTX", DbType.Decimal, (object) expenseRevenue.ActMACTX);
        this.db.AddInParameter(storedProcCommand, "@ActLegal", DbType.Decimal, (object) expenseRevenue.ActLegal);
        this.db.AddInParameter(storedProcCommand, "@ActMACOH", DbType.Decimal, (object) expenseRevenue.ActMACOH);
        this.db.AddInParameter(storedProcCommand, "@ActDTCCharges", DbType.Decimal, (object) expenseRevenue.ActDTCCharges);
        this.db.AddInParameter(storedProcCommand, "@ActLessExpenseReimbursement", DbType.Decimal, (object) expenseRevenue.ActLessExpenseReimbursement);
        this.db.AddInParameter(storedProcCommand, "@ActClearanceExpenses", DbType.Decimal, (object) expenseRevenue.ActClearanceExpenses);
        this.db.AddInParameter(storedProcCommand, "@ActOtherExpenses", DbType.Decimal, (object) expenseRevenue.ActOtherExpenses);
        this.db.AddInParameter(storedProcCommand, "@ActTotalFinancingExpenses", DbType.Decimal, (object) expenseRevenue.ActTotalFinancingExpenses);
        this.db.AddInParameter(storedProcCommand, "@ProjTotalRevenueBeforeExpenses", DbType.Decimal, (object) expenseRevenue.ProjTotalRevenueBeforeExpenses);
        this.db.AddInParameter(storedProcCommand, "@ProjLessNetDealExpenses", DbType.Decimal, (object) expenseRevenue.ProjLessNetDealExpenses);
        this.db.AddInParameter(storedProcCommand, "@ProjLessCoManagerDistributions", DbType.Decimal, (object) expenseRevenue.ProjLessCoManagerDistributions);
        this.db.AddInParameter(storedProcCommand, "@ProjNetRevenues", DbType.Decimal, (object) expenseRevenue.ProjNetRevenues);
        this.db.AddInParameter(storedProcCommand, "@ActTotalRevenueBeforeExpenses", DbType.Decimal, (object) expenseRevenue.ActTotalRevenueBeforeExpenses);
        this.db.AddInParameter(storedProcCommand, "@ActLessNetDealExpenses", DbType.Decimal, (object) expenseRevenue.ActLessNetDealExpenses);
        this.db.AddInParameter(storedProcCommand, "@ActLessCoManagerDistributions", DbType.Decimal, (object) expenseRevenue.ActLessCoManagerDistributions);
        this.db.AddInParameter(storedProcCommand, "@ActNetRevenues", DbType.Decimal, (object) expenseRevenue.ActNetRevenues);
        this.db.AddInParameter(storedProcCommand, "@ProjTakedownRevenues", DbType.Decimal, (object) expenseRevenue.ProjTakedownRevenues);
        this.db.AddInParameter(storedProcCommand, "@ProjAdjustmentToTakedown", DbType.Decimal, (object) expenseRevenue.ProjAdjustmentToTakedown);
        this.db.AddInParameter(storedProcCommand, "@ProjAdjustedTakedown", DbType.Decimal, (object) expenseRevenue.ProjAdjustedTakedown);
        this.db.AddInParameter(storedProcCommand, "@ActTakedownRevenues", DbType.Decimal, (object) expenseRevenue.ActTakedownRevenues);
        this.db.AddInParameter(storedProcCommand, "@ActAdjustmentToTakedown", DbType.Decimal, (object) expenseRevenue.ActAdjustmentToTakedown);
        this.db.AddInParameter(storedProcCommand, "@ActAdjustedTakedown", DbType.Decimal, (object) expenseRevenue.ActAdjustedTakedown);
        this.db.AddInParameter(storedProcCommand, "@ProjPublicFinance", DbType.Decimal, (object) expenseRevenue.ProjPublicFinance);
        this.db.AddInParameter(storedProcCommand, "@ProjSalesTradingAndUnderwriting", DbType.Decimal, (object) expenseRevenue.ProjSalesTradingAndUnderwriting);
        this.db.AddInParameter(storedProcCommand, "@ProjTotalRevenuesBreakdown", DbType.Decimal, (object) expenseRevenue.ProjTotalRevenuesBreakdown);
        this.db.AddInParameter(storedProcCommand, "@ActPublicFinance", DbType.Decimal, (object) expenseRevenue.ActPublicFinance);
        this.db.AddInParameter(storedProcCommand, "@ActSalesTradingAndUnderwriting", DbType.Decimal, (object) expenseRevenue.ActSalesTradingAndUnderwriting);
        this.db.AddInParameter(storedProcCommand, "@ActTotalRevenuesBreakdown", DbType.Decimal, (object) expenseRevenue.ActTotalRevenuesBreakdown);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, string.IsNullOrEmpty(expenseRevenue.CreatedBy) ? (object) this.AppUser.Name : (object) expenseRevenue.CreatedBy);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@IsMoveAccrualToHistory", DbType.Boolean, (object) isMoveAccrualToHistory);
        this.db.AddOutParameter(storedProcCommand, "@ReturnValue", DbType.Int32, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return (long) Convert.ToInt32(this.db.GetParameterValue(storedProcCommand, "@ReturnValue"));
      }
    }
  }
}
