﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AppTransactionRoleRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAppTransactionRoleRepository))]
  public class AppTransactionRoleRepository : IAppTransactionRoleRepository
  {
    public void Save(AppTransactionRole theAppTransactionRole)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveAppTransactionRole"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theAppTransactionRole.AppTransactionID);
        database.AddInParameter(storedProcCommand, "@Principal", DbType.Int32, (object) theAppTransactionRole.Principal);
        database.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) theAppTransactionRole.RoleID);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public AppTransactionRole FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchAppTransactionRoleByKey"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionRoleId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<AppTransactionRole>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new AppTransactionRole();
      }
    }

    public IEnumerable<AppTransactionRole> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllAppTransactionRole"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<AppTransactionRole> mapper = MapBuilder<AppTransactionRole>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppTransactionRole>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteAppTransactionRoleByKey"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionRoleId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
