﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.ImpliedPermissionRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IImpliedPermissionRepository))]
  public class ImpliedPermissionRepository : IImpliedPermissionRepository
  {
    public void Save(ImpliedPermission theImpliedPermission)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveImpliedPermission"))
      {
        database.AddInParameter(storedProcCommand, "@PermissionID", DbType.Int64, (object) theImpliedPermission.PermissionID);
        database.AddInParameter(storedProcCommand, "@ImpliedPermission", DbType.Int64, (object) theImpliedPermission.ImpliedPermissionID);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public ImpliedPermission FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchImpliedPermissionByKey"))
      {
        database.AddInParameter(storedProcCommand, "@ImpliedPermissionId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<ImpliedPermission>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new ImpliedPermission();
      }
    }

    public IEnumerable<ImpliedPermission> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllImpliedPermission"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<ImpliedPermission> mapper = MapBuilder<ImpliedPermission>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<ImpliedPermission>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteImpliedPermissionByKey"))
      {
        database.AddInParameter(storedProcCommand, "@ImpliedPermissionId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
