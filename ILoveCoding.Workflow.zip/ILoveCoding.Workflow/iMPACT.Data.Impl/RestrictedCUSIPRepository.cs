﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.RestrictedCUSIPRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IRestrictedCUSIPRepository))]
  public class RestrictedCUSIPRepository : RepositoryBase, IRestrictedCUSIPRepository
  {
    public void Save(List<RestrictedCUSIP> restrictedCUSIPs, string restrictedCUSIPIDs)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveRestrictedCUSIP"))
      {
        this.db.AddInParameter(storedProcCommand, "@RestrictedCUSIPTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<RestrictedCUSIP>(restrictedCUSIPs));
        this.db.AddInParameter(storedProcCommand, "@RestrictedCUSIPIds", DbType.String, (object) restrictedCUSIPIDs);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public RestrictedCUSIP FetchByKey(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchRestrictedCUSIPByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@RestrictedCUSIPId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<RestrictedCUSIP>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new RestrictedCUSIP();
      }
    }

    public IEnumerable<RestrictedCUSIP> FetchAll()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAllRestrictedCUSIP"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<RestrictedCUSIP> mapper = MapBuilder<RestrictedCUSIP>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<RestrictedCUSIP>) null;
        }
      }
    }

    public IEnumerable<RestrictedCUSIP> FetchByIssueId(
      long appTransactionId)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchRestrictedCUSIPByAppTransactionID"))
      {
        this.db.AddInParameter(cmd, "@AppTransactionID", DbType.Int32, (object) appTransactionId);
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<RestrictedCUSIP> mapper = MapBuilder<RestrictedCUSIP>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<RestrictedCUSIP>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteRestrictedCUSIPByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@RestrictedCUSIPId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
