﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.DataReaderExtensions
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace IrisSoftware.iMPACT.Data.Impl
{
  public static class DataReaderExtensions
  {
    public static Dictionary<string, object> ConvertToDictionary(this IDataReader value) => Enumerable.Range(0, value.FieldCount).ToDictionary<int, string, object>((Func<int, string>) (i => value.GetName(i)), (Func<int, object>) (i => value.GetValue(i)));
  }
}
