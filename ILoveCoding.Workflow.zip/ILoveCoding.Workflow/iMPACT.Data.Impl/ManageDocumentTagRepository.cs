﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.ManageDocumentTagRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IManageDocumentTagRepository))]
  public class ManageDocumentTagRepository : RepositoryBase, IManageDocumentTagRepository
  {
    public IDataReader FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityDocumentTagByEntityID"))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public IEnumerable<ManageDocumentTag> FetchTagsList()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityDocumentTagByEntityID"))
      {
        List<ManageDocumentTag> manageDocumentTagList = new List<ManageDocumentTag>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<ManageDocumentTag> rowMapper = MapBuilder<ManageDocumentTag>.MapAllProperties().Build();
          do
            ;
          while (dataReader.Read());
          if (dataReader.NextResult())
          {
            while (dataReader.Read())
              manageDocumentTagList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return (IEnumerable<ManageDocumentTag>) manageDocumentTagList;
      }
    }

    public void SaveManageDocumentTagItems(List<ManageDocumentTag> manageDocumentTagItem)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEntityDocumentTagItems"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityDocumentTagItems_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ManageDocumentTag>(manageDocumentTagItem.ToList<ManageDocumentTag>()));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
