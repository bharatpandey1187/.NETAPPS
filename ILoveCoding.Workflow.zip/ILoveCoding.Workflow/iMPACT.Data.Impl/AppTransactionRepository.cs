﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AppTransactionRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAppTransactionRepository))]
  public class AppTransactionRepository : IAppTransactionRepository
  {
    public void Save(AppTransaction theAppTransaction)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveAppTransaction"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theAppTransaction.AppTransactionID);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public AppTransaction FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchAppTransactionByKey"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<AppTransaction>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new AppTransaction();
      }
    }

    public IEnumerable<AppTransaction> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllAppTransaction"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<AppTransaction> mapper = MapBuilder<AppTransaction>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppTransaction>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteAppTransactionByKey"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
