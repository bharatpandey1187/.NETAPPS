﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.RestrictedCusipReportRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IRestrictedCusipReportRepository))]
  public class RestrictedCusipReportRepository : RepositoryBase, IRestrictedCusipReportRepository
  {
    public IDataReader FetchRestrictedCUSIPs(long typeOfOffering, long issueStatus)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllRestrictedCUSIPsForReport"))
      {
        this.db.AddInParameter(storedProcCommand, "@TypeOfOffering", DbType.Int64, (object) typeOfOffering);
        this.db.AddInParameter(storedProcCommand, "@IssueStatus", DbType.Int64, (object) issueStatus);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
