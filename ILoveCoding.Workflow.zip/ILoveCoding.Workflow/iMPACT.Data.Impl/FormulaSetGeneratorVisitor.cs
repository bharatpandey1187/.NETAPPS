﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.FormulaSetGeneratorVisitor
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.Core.DataStructure;
using IrisSoftware.Core.Formula;
using IrisSoftware.Core.Formula.Ast;
using IrisSoftware.Core.Formula.Validation;
using IrisSoftware.Core.Reflection;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace IrisSoftware.iMPACT.Data.Impl
{
  public class FormulaSetGeneratorVisitor : AstVisitorBase
  {
    private readonly Stack<object> exprStack = new Stack<object>();
    private ScopedHash<FormulaSetGeneratorVisitor.VisitResult> knownSymbols;
    private readonly Type knownFunctions;
    private readonly ScopedHash<string> unknownSymbols;
    private readonly Stack<List<int>> rankStack = new Stack<List<int>>();
    private readonly Stack<string> dependentKeys = new Stack<string>();
    private StringBuilder scriptBuilder;
    private readonly string funcPrefix;
    private readonly string symbolPrefix;
    private readonly Stack<StringBuilder> scriptWriter = new Stack<StringBuilder>();
    private bool isLamda;
    private static readonly Dictionary<string, KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>> knownIdentifiers = new Dictionary<string, KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>>((IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)
    {
      {
        "true",
        new KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>("true", new FormulaSetGeneratorVisitor.VisitResult()
        {
          Type = typeof (bool),
          Rank = 0
        })
      },
      {
        "false",
        new KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>("false", new FormulaSetGeneratorVisitor.VisitResult()
        {
          Type = typeof (bool),
          Rank = 0
        })
      },
      {
        "null",
        new KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>("null", new FormulaSetGeneratorVisitor.VisitResult()
        {
          Type = typeof (object),
          Rank = 0
        })
      }
    };
    private static readonly Dictionary<BinaryOperator, string> _operatorTokens = new Dictionary<BinaryOperator, string>()
    {
      {
        BinaryOperator.LogicalAnd,
        " && "
      },
      {
        BinaryOperator.LogicalOr,
        " || "
      },
      {
        BinaryOperator.Equal,
        " === "
      },
      {
        BinaryOperator.StrictlyEqual,
        " === "
      },
      {
        BinaryOperator.NotEqual,
        " !== "
      },
      {
        BinaryOperator.StrictlyNotEqual,
        " !== "
      },
      {
        BinaryOperator.Greater,
        " > "
      },
      {
        BinaryOperator.GreaterOrEqual,
        " >= "
      },
      {
        BinaryOperator.Less,
        " < "
      },
      {
        BinaryOperator.LessOrEqual,
        " <= "
      },
      {
        BinaryOperator.BitwiseAnd,
        " & "
      },
      {
        BinaryOperator.BitwiseOr,
        " | "
      },
      {
        BinaryOperator.Plus,
        " + "
      },
      {
        BinaryOperator.Divide,
        " / "
      },
      {
        BinaryOperator.BitwiseXor,
        " ^ "
      },
      {
        BinaryOperator.LeftShift,
        " << "
      },
      {
        BinaryOperator.Modulo,
        " % "
      },
      {
        BinaryOperator.Times,
        " * "
      },
      {
        BinaryOperator.RightShift,
        " >> "
      },
      {
        BinaryOperator.Minus,
        " - "
      }
    };

    public FormulaSetGeneratorVisitor(
      ScopedHash<FormulaSetGeneratorVisitor.VisitResult> knownSymbols,
      ScopedHash<string> unknownSymbols,
      Type predefinedFunctions,
      string funcPrefix,
      string symbolPrefix)
    {
      this.knownSymbols = knownSymbols;
      this.unknownSymbols = unknownSymbols;
      this.knownFunctions = predefinedFunctions;
      this.funcPrefix = FormulaSetGeneratorVisitor.AdjustTrailingDot(funcPrefix);
      this.symbolPrefix = FormulaSetGeneratorVisitor.AdjustTrailingDot(symbolPrefix);
    }

    private static ScopedHash<FormulaSetGeneratorVisitor.VisitResult> BuildKnownSymbolTable(
      ScopedHash<Type> knownSymbols)
    {
      return new ScopedHash<FormulaSetGeneratorVisitor.VisitResult>(knownSymbols.Select<KeyValuePair<string, Type>, KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>>((Func<KeyValuePair<string, Type>, KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>>) (t => new KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>(t.Key, new FormulaSetGeneratorVisitor.VisitResult()
      {
        Rank = 0,
        Type = t.Value
      }))));
    }

    private void Push(FormulaSetGeneratorVisitor.MethodData item) => this.exprStack.Push((object) item);

    private void Push(Type type) => this.exprStack.Push((object) new FormulaSetGeneratorVisitor.VisitResult()
    {
      Type = type,
      Rank = 0
    });

    private void Push(FormulaSetGeneratorVisitor.VisitResult visitResult) => this.exprStack.Push((object) visitResult);

    private void Push(MethodInfo[] methodInfo) => this.exprStack.Push((object) methodInfo);

    private object Pop() => this.exprStack.Pop();

    public FormulaSetGeneratorVisitor.VisitResult Validate(
      AstNode exprTree,
      ScopedHash<FormulaSetGeneratorVisitor.VisitResult> knownSymbols)
    {
      return this.Validate(exprTree, knownSymbols, new StringBuilder());
    }

    private FormulaSetGeneratorVisitor.VisitResult Validate(
      AstNode exprTree,
      ScopedHash<FormulaSetGeneratorVisitor.VisitResult> knownSymbols,
      StringBuilder stringBuilder)
    {
      this.scriptBuilder = stringBuilder;
      this.rankStack.Push(new List<int>());
      this.knownSymbols = knownSymbols;
      this.Visit(exprTree);
      List<int> source = this.rankStack.Pop();
      return new FormulaSetGeneratorVisitor.VisitResult()
      {
        Type = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type,
        Rank = (source.Count > 0 ? source.Max() : 0) + 1,
        ClientScript = this.scriptBuilder.ToString()
      };
    }

    private void Visit(AstNode node) => node.Accept((IAstVisitor) this);

    public override void VisitUnary(UnaryNode unaryNode)
    {
      this.scriptBuilder.Append(FormulaSetGeneratorVisitor._operatorTokens[unaryNode.UnaryOperator]);
      this.Visit(unaryNode.Node);
      Type type = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
      if (unaryNode.UnaryOperator.IsLogicalOperator())
      {
        if (type != typeof (bool))
          throw new FormulaException("Invalid type", unaryNode.Position);
        this.Push(typeof (bool));
      }
      else
      {
        if (!unaryNode.UnaryOperator.IsArithmeticOperator())
          throw new FormulaException("Invalid Operator", unaryNode.Position);
        if (!type.IsNumericType())
          throw new FormulaException("Invalid type", unaryNode.Position);
        this.Push(type);
      }
    }

    public override void VisitMember(MemberNode node) => base.VisitMember(node);

    public override void VisitMethodCall(MethodCallNode methodCallNode)
    {
      if (methodCallNode.Args.Length != 0 && methodCallNode.Args[0].NodeType == AstNodeType.Lambda)
        this.isLamda = true;
      this.Visit(methodCallNode.CalledNode);
      object poppedResult = this.Pop();
      if (this.CheckMethodCall(methodCallNode, poppedResult))
        return;
      if (!this.CheckAggregateMethodCall(methodCallNode, poppedResult))
        throw new FormulaException("Unable to resolve method", methodCallNode.Position);
      this.scriptBuilder.Append(")");
    }

    private bool CheckMethodCall(MethodCallNode methodCallNode, object poppedResult)
    {
      if (!(poppedResult is MethodInfo[] methods))
        return false;
      this.scriptBuilder.Append("(");
      Type[] argTypes = this.VisitArguments(methodCallNode.Args);
      this.scriptBuilder.Append(")");
      this.Push((FormulaSetGeneratorVisitor.GetMatchingMethod(methods, argTypes) ?? throw new FormulaException("Unable to resolve method", methodCallNode.Position)).ReturnType);
      return true;
    }

    private static MethodInfo GetMatchingMethod(MethodInfo[] methods, Type[] argTypes) => ((IEnumerable<MethodInfo>) methods).Where<MethodInfo>((Func<MethodInfo, bool>) (m => FormulaSetGeneratorVisitor.IsApplicable(m, argTypes))).FirstOrDefault<MethodInfo>();

    private static bool IsApplicable(MethodInfo methodInfo, Type[] argTypes)
    {
      ParameterInfo[] parameters = methodInfo.GetParameters();
      int length = parameters.Length;
      if ((length <= 0 || !parameters[length - 1].ParameterType.IsArray ? 0 : (parameters[length - 1].IsDefined(typeof (ParamArrayAttribute), false) ? 1 : 0)) == 0)
      {
        if (length != argTypes.Length)
          return false;
        for (int index = 0; index < length; ++index)
        {
          if (!TypeHelpers.CanCast(parameters[index].ParameterType, argTypes[index]))
            return false;
        }
      }
      else
      {
        for (int index = 0; index < length - 1; ++index)
        {
          if (!TypeHelpers.CanCast(parameters[index].ParameterType, argTypes[index]))
            return false;
        }
        Type enumerableMemberType = TypeHelpers.GetEnumerableMemberType(parameters[length - 1].ParameterType);
        for (int index = length - 1; index < argTypes.Length; ++index)
        {
          if (!TypeHelpers.CanCast(argTypes[index], enumerableMemberType))
            return false;
        }
      }
      return true;
    }

    private bool CheckAggregateMethodCall(MethodCallNode methodCallNode, object poppedResult)
    {
      if (!(poppedResult is FormulaSetGeneratorVisitor.MethodData methodData))
        return false;
      Type enumerableMemberType = TypeHelpers.GetEnumerableMemberType(methodData.Type);
      this.knownSymbols = new ScopedHash<FormulaSetGeneratorVisitor.VisitResult>(this.knownSymbols);
      try
      {
        this.knownSymbols["it"] = new FormulaSetGeneratorVisitor.VisitResult()
        {
          Type = enumerableMemberType,
          Rank = 0
        };
        Type[] argTypes = this.VisitArguments(methodCallNode.Args);
        MethodInfo enumerableMethod = FormulaSetGeneratorVisitor.GetMatchingEnumerableMethod(methodData.Methods, enumerableMemberType, argTypes);
        if (enumerableMethod == null)
          throw new FormulaException("Unable to resolve method", methodCallNode.Position);
        if (enumerableMethod.GetParameters()[0].ParameterType == enumerableMethod.ReturnType)
          this.Push(methodData.Type);
        else
          this.Push(enumerableMethod.ReturnType);
        return true;
      }
      finally
      {
        this.knownSymbols = this.knownSymbols.Parent;
      }
    }

    private static MethodInfo GetMatchingEnumerableMethod(
      MethodInfo[] methods,
      Type elementType,
      Type[] argTypes)
    {
      return ((IEnumerable<MethodInfo>) methods).Where<MethodInfo>((Func<MethodInfo, bool>) (m => FormulaSetGeneratorVisitor.IsAggregateMethodApplicable(m, elementType, argTypes))).FirstOrDefault<MethodInfo>();
    }

    private static bool IsAggregateMethodApplicable(
      MethodInfo methodInfo,
      Type elementType,
      Type[] argTypes)
    {
      ParameterInfo[] parameters = methodInfo.GetParameters();
      int length = parameters.Length;
      if (length == 1 && argTypes.Length == 0)
        return true;
      Type[] genericArguments = parameters[length - 1].ParameterType.GetGenericArguments();
      return genericArguments.Length != 0 && argTypes[0] == genericArguments[genericArguments.Length - 1];
    }

    private Type[] VisitArguments(AstNode[] nodes)
    {
      List<Type> typeList = new List<Type>();
      for (int index = 0; index < nodes.Length; ++index)
      {
        this.Visit(nodes[index]);
        Type type = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
        typeList.Add(type);
        if (index < nodes.Length - 1)
          this.scriptBuilder.Append(", ");
      }
      return typeList.ToArray();
    }

    private void VisitArguments(AstNode[] nodes, Func<int, Type> getTypeForPosition)
    {
      for (int index = 0; index < nodes.Length; ++index)
      {
        this.Visit(nodes[index]);
        if (!TypeHelpers.CanCast((this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type, getTypeForPosition(index)))
          throw new FormulaException("Invalid argument type", nodes[index].Position);
      }
    }

    public override void VisitMemberAccess(MemberAccessNode memberAccessNode)
    {
      int length = this.scriptBuilder.ToString().Length;
      this.Visit(memberAccessNode.ObjectNode);
      Type type = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
      if (this.CheckMemberAccess(type, memberAccessNode.PropertyNode.Text) || this.CheckMethodAccess(type, memberAccessNode.PropertyNode.Text, false) || this.CheckMethodAccess(type, memberAccessNode.PropertyNode.Text, true))
        return;
      if (!this.CheckAggregateMethodAccess(type, memberAccessNode.PropertyNode.Text))
        throw new FormulaException("Unable to resolve member access", memberAccessNode.Position);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(this.funcPrefix + memberAccessNode.PropertyNode.Text.ToLower());
      stringBuilder.Append("(");
      this.scriptBuilder.Insert(length, stringBuilder.ToString());
    }

    private bool CheckAggregateMethodAccess(Type type, string text)
    {
      if (typeof (IEnumerable).IsAssignableFrom(type) && typeof (FormulaSetGeneratorVisitor.IEnumerableSignatures).GetMember(text, MemberTypes.Method, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.Public).Length != 0)
      {
        MethodInfo[] array = ((IEnumerable<MethodInfo>) typeof (Enumerable).GetMethods(BindingFlags.Static | BindingFlags.Public)).Where<MethodInfo>((Func<MethodInfo, bool>) (m => string.Compare(m.Name, text, StringComparison.OrdinalIgnoreCase) == 0)).ToArray<MethodInfo>();
        if (array != null && array.Length != 0)
        {
          this.Push(new FormulaSetGeneratorVisitor.MethodData()
          {
            Type = type,
            Methods = array
          });
          return true;
        }
      }
      return false;
    }

    private bool CheckMemberAccess(Type type, string text)
    {
      PropertyInfo property = type.GetProperty(text, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.Public);
      if (property == null)
        return false;
      KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult> keyValuePair = this.knownSymbols.FirstOrDefault<KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>>((Func<KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>, bool>) (_ => _.Value.Type.FullName == type.FullName));
      if (keyValuePair.Key != null)
      {
        int startIndex = this.scriptBuilder.ToString().LastIndexOf(keyValuePair.Key);
        if (startIndex != -1)
          this.scriptBuilder.Remove(startIndex, keyValuePair.Key.Length);
      }
      this.Push(property.PropertyType);
      this.scriptBuilder.Append(property.Name);
      return true;
    }

    public override void VisitLambda(LambdaNode node)
    {
      this.scriptBuilder.Append(",");
      this.scriptBuilder.Append(" function(");
      node.Arg.Accept((IAstVisitor) this);
      this.scriptBuilder.Append(")");
      this.scriptBuilder.Append("{");
      this.scriptBuilder.Append("return ");
      node.Body.Accept((IAstVisitor) this);
      this.scriptBuilder.Append("}");
    }

    public override void VisitIndexedAccess(IndexAccessNode indexAccessNode)
    {
      this.Visit(indexAccessNode.ObjectNode);
      Type type = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
      if (!type.IsArray)
        return;
      this.scriptBuilder.Append("[");
      this.VisitArguments(indexAccessNode.PropertyNodes, (Func<int, Type>) (idx => typeof (long)));
      this.scriptBuilder.Append("]");
      this.Push(type.GetElementType());
    }

    public override void VisitBinary(BinaryNode binaryNode)
    {
      this.scriptBuilder.Append("(");
      this.Visit(binaryNode.Left);
      this.scriptBuilder.Append(FormulaSetGeneratorVisitor._operatorTokens[binaryNode.BinaryOperator]);
      Type type1 = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
      this.Visit(binaryNode.Right);
      Type type2 = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
      this.scriptBuilder.Append(")");
      this.Push(this.CalculateResultingType(binaryNode.BinaryOperator, type1, type2, binaryNode.Position));
    }

    private Type CalculateResultingType(
      BinaryOperator binaryOperator,
      Type lType,
      Type rType,
      int position)
    {
      if (binaryOperator.IsLogicalOperator())
      {
        if (lType != typeof (bool) || rType != typeof (bool))
          throw new FormulaException("Invalid type", position);
        return typeof (bool);
      }
      if (binaryOperator.IsArithmeticOperator())
      {
        if (binaryOperator == BinaryOperator.Plus && (lType == typeof (string) || rType == typeof (string)))
          return typeof (string);
        if (!lType.IsNumericType() || !rType.IsNumericType())
          throw new FormulaException("Invalid type", position);
        return TypeHelpers.IsCompatible(lType, rType) ? TypeHelpers.SelectType(lType, rType) : throw new FormulaException("Invalid type", position);
      }
      if (binaryOperator.IsEqualityOperator() && (TypeHelpers.CanCast(lType, rType) || TypeHelpers.CanCast(rType, lType)))
        return typeof (bool);
      throw new FormulaException("Unknown operator", position);
    }

    public override void VisitConditional(ConditionalNode conditionalNode)
    {
      this.scriptBuilder.Append("(");
      this.scriptBuilder.Append("(");
      this.Visit(conditionalNode.Test);
      this.scriptBuilder.Append(") ? (");
      if ((this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type != typeof (bool))
        throw new FormulaException("Invalid type", conditionalNode.Test.Position);
      this.Visit(conditionalNode.Consequent);
      Type type1 = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
      this.scriptBuilder.Append(") : (");
      this.Visit(conditionalNode.Alternate);
      Type type2 = (this.Pop() as FormulaSetGeneratorVisitor.VisitResult).Type;
      this.scriptBuilder.Append(")");
      this.scriptBuilder.Append(")");
      if (!TypeHelpers.IsCompatible(type1, type2))
        throw new FormulaException("Invalid type", conditionalNode.Test.Position);
      this.Push(TypeHelpers.SelectType(type1, type2));
    }

    public override void VisitIdentifier(IdentifierNode identifierNode)
    {
      string identifierText = identifierNode.Text;
      if (FormulaSetGeneratorVisitor.knownIdentifiers.ContainsKey(identifierText))
      {
        this.Push(FormulaSetGeneratorVisitor.knownIdentifiers[identifierText].Value);
        this.scriptBuilder.Append(identifierText);
      }
      else
      {
        if (this.CheckMethodAccess(this.knownFunctions, identifierText, false))
          return;
        if (this.knownSymbols.ContainsKey(identifierText))
        {
          KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult> keyValuePair = this.knownSymbols.FirstOrDefault<KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>>((Func<KeyValuePair<string, FormulaSetGeneratorVisitor.VisitResult>, bool>) (_ => _.Key.ToUpper() == identifierText.ToUpper()));
          this.Push(this.knownSymbols[identifierText]);
          this.rankStack.Peek().Add(this.knownSymbols[identifierText].Rank);
          if (identifierText.ToLower() == "it")
            this.scriptBuilder.Append("it");
          else if (this.unknownSymbols.ContainsKey(identifierText))
            this.scriptBuilder.Append(this.symbolPrefix + keyValuePair.Key);
          else if (string.Compare(this.knownSymbols[identifierText].Type.Name, identifierText, true) != 0)
            this.scriptBuilder.Append(this.symbolPrefix + keyValuePair.Key);
          else
            this.scriptBuilder.Append(this.symbolPrefix);
        }
        else
        {
          if (!this.unknownSymbols.ContainsKey(identifierText))
            throw new FormulaException("Unknown Identifier", identifierNode.Position);
          if (this.dependentKeys.Contains(identifierText))
            throw new CircularDependencyException("Circular Dependency of Identifier", identifierText, identifierNode.Position);
          this.dependentKeys.Push(identifierText);
          AstNode exprTree = (AstNode) null;
          if (this.unknownSymbols[identifierText] != string.Empty)
            exprTree = AstParser.Parse(this.unknownSymbols[identifierText]);
          try
          {
            StringBuilder stringBuilder = new StringBuilder();
            this.scriptWriter.Push(this.scriptBuilder);
            FormulaSetGeneratorVisitor.VisitResult visitResult1;
            if (exprTree == null)
              visitResult1 = new FormulaSetGeneratorVisitor.VisitResult()
              {
                Type = typeof (Decimal)
              };
            else
              visitResult1 = this.Validate(exprTree, this.knownSymbols, stringBuilder);
            FormulaSetGeneratorVisitor.VisitResult visitResult2 = visitResult1;
            this.scriptBuilder = this.scriptWriter.Pop();
            this.scriptBuilder.Append(this.symbolPrefix + identifierText);
            this.Push(visitResult2);
            this.knownSymbols.Add(identifierText, visitResult2);
            this.rankStack.Peek().Add(visitResult2.Rank);
            this.dependentKeys.Pop();
          }
          catch (CircularDependencyException ex)
          {
            this.dependentKeys.Reverse<string>();
            StringBuilder stringBuilder = new StringBuilder();
            while (this.dependentKeys.Count > 0)
            {
              stringBuilder.Append(this.dependentKeys.Pop());
              if (this.dependentKeys.Count != 0)
                stringBuilder.Append("->");
            }
            throw ex;
          }
        }
      }
    }

    private bool CheckMethodAccess(Type type, string text, bool staticAccess)
    {
      if (type == null)
        return false;
      MethodInfo[] methods = FormulaSetGeneratorVisitor.FindMethods(type, text, staticAccess);
      if (methods == null)
        return false;
      this.Push(methods);
      if (type == this.knownFunctions)
        this.scriptBuilder.Append(this.funcPrefix + methods[0].Name.ToLower());
      else
        this.scriptBuilder.Append("." + methods[0].Name);
      return true;
    }

    private static MethodInfo[] FindMethods(
      Type type,
      string methodName,
      bool staticAccess)
    {
      BindingFlags bindingAttr = (BindingFlags) (18 | (staticAccess ? 8 : 4));
      List<MethodInfo> methodInfoList = new List<MethodInfo>();
      foreach (Type selfAndBaseType in type.SelfAndBaseTypes())
      {
        MethodInfo[] array = selfAndBaseType.FindMembers(MemberTypes.Method, bindingAttr, Type.FilterNameIgnoreCase, (object) methodName).Cast<MethodInfo>().ToArray<MethodInfo>();
        if (array != null && array.Length != 0)
          methodInfoList.AddRange((IEnumerable<MethodInfo>) array);
      }
      return methodInfoList.Count > 0 ? methodInfoList.ToArray() : (MethodInfo[]) null;
    }

    public override void VisitLiteral(LiteralNode literalNode)
    {
      if (literalNode.Type == LiteralType.Date)
      {
        DateTime result;
        DateTime.TryParse(literalNode.Text, out result);
        this.scriptBuilder.Append(string.Format("new Date({0},{1},{2},{3},{4})", (object) result.Year, (object) result.Month, (object) result.Day, (object) result.Hour, (object) result.Minute));
      }
      else if (literalNode.Type == LiteralType.String)
        this.scriptBuilder.Append("'" + this.EncodeString(literalNode.Text) + "'");
      else
        this.scriptBuilder.Append(literalNode.Text);
      this.Push(literalNode.Type.ToType());
    }

    private static string AdjustTrailingDot(string text)
    {
      text = text ?? string.Empty;
      if (text.Length > 0 && !text.EndsWith("."))
        text += ".";
      return text;
    }

    private string EncodeString(string text) => text.Replace("\"", "\"").Replace("'", "'");

    private class MethodData
    {
      public Type Type;
      public MethodInfo[] Methods;
    }

    public class VisitResult
    {
      public Type Type { get; set; }

      public int Rank { get; set; }

      public string ClientScript { get; set; }
    }

    private interface IEnumerableSignatures
    {
      void Where(bool predicate);

      void Any();

      void Any(bool predicate);

      void All(bool predicate);

      void Count();

      void Count(bool predicate);

      void Min(object selector);

      void Max(object selector);

      void Sum(int selector);

      void Sum(int? selector);

      void Sum(long selector);

      void Sum(long? selector);

      void Sum(float selector);

      void Sum(float? selector);

      void Sum(double selector);

      void Sum(double? selector);

      void Sum(Decimal selector);

      void Sum(Decimal? selector);

      void Average(int selector);

      void Average(int? selector);

      void Average(long selector);

      void Average(long? selector);

      void Average(float selector);

      void Average(float? selector);

      void Average(double selector);

      void Average(double? selector);

      void Average(Decimal selector);

      void Average(Decimal? selector);

      void ToArray();

      void Take(int selector);

      void Skip(int selector);

      void OrderBy(int selector);

      void OrderBy(object obj, object exp);

      void Reverse();
    }
  }
}
