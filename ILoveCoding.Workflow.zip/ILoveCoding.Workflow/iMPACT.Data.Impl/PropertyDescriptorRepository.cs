﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.PropertyDescriptorRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IPropertyDescriptorRepository))]
  public class PropertyDescriptorRepository : RepositoryBase, IPropertyDescriptorRepository
  {
    public IEnumerable<PropertyDescriptor> FetchPropertyDescriptorsByEntity(
      long entityId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPropertyDescriptorsByEntityID"))
      {
        List<PropertyDescriptor> propertyDescriptorList = new List<PropertyDescriptor>();
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<PropertyDescriptor> rowMapper = MapBuilder<PropertyDescriptor>.MapAllProperties().DoNotMap<long>((Expression<Func<PropertyDescriptor, long>>) (_ => _.PSVID)).DoNotMap<string>((Expression<Func<PropertyDescriptor, string>>) (_ => _.Value)).Build();
          while (dataReader.Read())
            propertyDescriptorList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<PropertyDescriptor>) propertyDescriptorList;
      }
    }

    public IEnumerable<PropertyDescriptor> FetchPropertyDescriptorsDataByEntity(
      long appTransactionID,
      long entityId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPropertyDescriptorsDataByEntity"))
      {
        List<PropertyDescriptor> propertyDescriptorList = new List<PropertyDescriptor>();
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<PropertyDescriptor> rowMapper = MapBuilder<PropertyDescriptor>.MapAllProperties().DoNotMap<long>((Expression<Func<PropertyDescriptor, long>>) (_ => _.EntityID)).DoNotMap<DateTime>((Expression<Func<PropertyDescriptor, DateTime>>) (_ => _.EffectFrom)).DoNotMap<DateTime?>((Expression<Func<PropertyDescriptor, DateTime?>>) (_ => _.EffectTill)).DoNotMap<string>((Expression<Func<PropertyDescriptor, string>>) (_ => _.CreatedBy)).DoNotMap<DateTime>((Expression<Func<PropertyDescriptor, DateTime>>) (_ => _.CreatedDate)).DoNotMap<string>((Expression<Func<PropertyDescriptor, string>>) (_ => _.ModifiedBy)).DoNotMap<DateTime>((Expression<Func<PropertyDescriptor, DateTime>>) (_ => _.ModifiedDate)).Build();
          while (dataReader.Read())
            propertyDescriptorList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<PropertyDescriptor>) propertyDescriptorList;
      }
    }

    public void SavePropertyDescriptorValues(List<PropertyDescriptor> propertyDescriptors)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SavePropertyDescriptors"))
      {
        this.db.AddInParameter(storedProcCommand, "@PropertyDescriptorTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<PropertyDescriptor>(propertyDescriptors));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
