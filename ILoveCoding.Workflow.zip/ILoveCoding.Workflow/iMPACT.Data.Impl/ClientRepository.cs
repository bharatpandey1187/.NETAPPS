﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.ClientRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IClientRepository))]
  public class ClientRepository : RepositoryBase, IClientRepository, IQuery
  {
    private Dictionary<string, string> knownMappings;

    [Dependency]
    public ISearchSettingRepository SearchSettingRepository { get; set; }

    public ClientRepository(Dictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public long Save(Client theClient)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_SaveClient]"))
      {
        this.db.AddInParameter(storedProcCommand, "@ClientID", DbType.Int64, (object) theClient.ClientID);
        this.db.AddInParameter(storedProcCommand, "@ExternalClientID", DbType.String, (object) theClient.ExternalClientID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) theClient.Name);
        this.db.AddInParameter(storedProcCommand, "@KFUJName", DbType.String, (object) theClient.KFUJName);
        this.db.AddInParameter(storedProcCommand, "@StreetAddress", DbType.String, (object) theClient.StreetAddress);
        this.db.AddInParameter(storedProcCommand, "@City", DbType.String, (object) theClient.City);
        SqlDatabase db = this.db;
        DbCommand command = storedProcCommand;
        long? state = theClient.State;
        // ISSUE: variable of a boxed type
        __Boxed<long?> local = (System.ValueType) (state.HasValue ? state : new long?());
        db.AddInParameter(command, "@State", DbType.Int64, (object) local);
        this.db.AddInParameter(storedProcCommand, "@Zip", DbType.String, (object) theClient.Zip);
        this.db.AddInParameter(storedProcCommand, "@CountryCode", DbType.String, (object) theClient.CountryCode);
        this.db.AddInParameter(storedProcCommand, "@CountryIncorporation", DbType.String, (object) theClient.CountryIncorporation);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) theClient.Phone);
        this.db.AddInParameter(storedProcCommand, "@Fax", DbType.String, (object) theClient.Fax);
        this.db.AddInParameter(storedProcCommand, "@TaxID", DbType.String, (object) theClient.TaxID);
        this.db.AddInParameter(storedProcCommand, "@WebsiteUrl", DbType.String, (object) theClient.WebsiteUrl);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) theClient.IsActive);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) theClient.Title);
        this.db.AddInParameter(storedProcCommand, "@FirstName", DbType.String, (object) theClient.FirstName);
        this.db.AddInParameter(storedProcCommand, "@LastName", DbType.String, (object) theClient.LastName);
        this.db.AddInParameter(storedProcCommand, "@Suffix", DbType.String, (object) theClient.Suffix);
        this.db.AddInParameter(storedProcCommand, "@Mobile", DbType.String, (object) theClient.Mobile);
        this.db.AddInParameter(storedProcCommand, "@ClientContactTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ClientContact>(theClient.ClientContacts.ToList<ClientContact>()));
        this.db.AddInParameter(storedProcCommand, "@ClientCUSIPPrefixTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ClientCUSIPPrefix>(theClient.ClientCUSIPPrefix.ToList<ClientCUSIPPrefix>()));
        this.db.AddInParameter(storedProcCommand, "@ClientAliasTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ClientAlias>(theClient.ClientAlias.ToList<ClientAlias>()));
        this.db.AddInParameter(storedProcCommand, "@ClientMAExemptionTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ClientMAExemptionDetail>(theClient.MAExemptionDetails.ToList<ClientMAExemptionDetail>()));
        this.db.AddInParameter(storedProcCommand, "@ClientCRMTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ClientCRM>(theClient.ClientCRM.ToList<ClientCRM>()));
        this.db.AddInParameter(storedProcCommand, "@ClientAddressTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ClientAddress>(theClient.ClientAddress.ToList<ClientAddress>()));
        this.db.AddOutParameter(storedProcCommand, "@OutClientID", DbType.Int64, 0);
        this.db.AddInParameter(storedProcCommand, "@MAExempt", DbType.String, (object) theClient.MAExempt);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutClientID"));
      }
    }

    public long UpdateContactDetails(ClientContact clientContact)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_SaveClientContact]"))
      {
        this.db.AddInParameter(storedProcCommand, "@ClientID", DbType.Int64, (object) clientContact.ClientID);
        this.db.AddInParameter(storedProcCommand, "@ClientContactID", DbType.Int64, (object) clientContact.ClientContactID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) clientContact.Name);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) clientContact.Phone);
        this.db.AddInParameter(storedProcCommand, "@Fax", DbType.String, (object) clientContact.Fax);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) clientContact.Email);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) clientContact.IsActive);
        this.db.AddInParameter(storedProcCommand, "@IsDefault", DbType.Boolean, (object) clientContact.IsDefault);
        this.db.AddInParameter(storedProcCommand, "@IsG17Contact", DbType.Boolean, (object) clientContact.IsG17Contact);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) clientContact.Title);
        this.db.AddInParameter(storedProcCommand, "@ContactAddressID", DbType.Int64, (object) clientContact.ContactAddressID);
        this.db.AddInParameter(storedProcCommand, "@NameTitle", DbType.String, (object) clientContact.NameTitle);
        this.db.AddInParameter(storedProcCommand, "@FirstName", DbType.String, (object) clientContact.FirstName);
        this.db.AddInParameter(storedProcCommand, "@LastName", DbType.String, (object) clientContact.LastName);
        this.db.AddInParameter(storedProcCommand, "@Suffix", DbType.String, (object) clientContact.Suffix);
        this.db.AddInParameter(storedProcCommand, "@Mobile", DbType.String, (object) clientContact.Mobile);
        this.db.AddOutParameter(storedProcCommand, "@OutClientContactID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutClientContactID"));
      }
    }

    public Client FetchByKey(long currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchClientByKey"))
      {
        Client client1 = new Client();
        this.db.AddInParameter(storedProcCommand, "@ClientId", DbType.Int64, (object) currentId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (!reader.Read())
            return client1;
          Client client2 = MapBuilder<Client>.MapAllProperties().Build().MapRow((IDataRecord) reader);
          if (reader.NextResult())
            client2.ClientContacts = this.GetContacts(reader);
          if (reader.NextResult())
            client2.ClientCUSIPPrefix = this.GetCUSIPPrefixes(reader);
          if (reader.NextResult())
            client2.ClientAlias = this.GetClientAlias(reader);
          if (reader.NextResult())
            client2.MAExemptionDetails = this.GetMAExemptionDetails(reader);
          if (reader.NextResult())
            client2.ClientCRM = this.GetClientCRM(reader);
          if (reader.NextResult())
            client2.ClientAddress = this.GetClientAddress(reader);
          if (reader.NextResult())
            client2.ClientActiveAddress = this.GetClientActiveAddress(reader);
          return client2;
        }
      }
    }

    public Client FetchClientDetailsOnlyByKey(long currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchClientDetailsOnlyByKey"))
      {
        Client client = new Client();
        this.db.AddInParameter(storedProcCommand, "@ClientId", DbType.Int64, (object) currentId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<Client>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : client;
      }
    }

    public IEnumerable<Client> FetchAll()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAllClient"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<Client> mapper = MapBuilder<Client>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<Client>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteClientByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@ClientId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    private List<ClientContact> GetContacts(IDataReader reader)
    {
      List<ClientContact> clientContactList = new List<ClientContact>();
      IRowMapper<ClientContact> rowMapper = MapBuilder<ClientContact>.MapAllProperties().Build();
      while (reader.Read())
        clientContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return clientContactList;
    }

    private List<ClientCUSIPPrefix> GetCUSIPPrefixes(IDataReader reader)
    {
      List<ClientCUSIPPrefix> clientCusipPrefixList = new List<ClientCUSIPPrefix>();
      IRowMapper<ClientCUSIPPrefix> rowMapper = MapBuilder<ClientCUSIPPrefix>.MapAllProperties().Build();
      while (reader.Read())
        clientCusipPrefixList.Add(rowMapper.MapRow((IDataRecord) reader));
      return clientCusipPrefixList;
    }

    private List<ClientAlias> GetClientAlias(IDataReader reader)
    {
      List<ClientAlias> clientAliasList = new List<ClientAlias>();
      IRowMapper<ClientAlias> rowMapper = MapBuilder<ClientAlias>.MapAllProperties().Build();
      while (reader.Read())
        clientAliasList.Add(rowMapper.MapRow((IDataRecord) reader));
      return clientAliasList;
    }

    private List<ClientMAExemptionDetail> GetMAExemptionDetails(
      IDataReader reader)
    {
      List<ClientMAExemptionDetail> maExemptionDetailList = new List<ClientMAExemptionDetail>();
      IRowMapper<ClientMAExemptionDetail> rowMapper = MapBuilder<ClientMAExemptionDetail>.MapAllProperties().Build();
      while (reader.Read())
        maExemptionDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return maExemptionDetailList;
    }

    private List<ClientCRM> GetClientCRM(IDataReader reader)
    {
      List<ClientCRM> clientCrmList = new List<ClientCRM>();
      IRowMapper<ClientCRM> rowMapper = MapBuilder<ClientCRM>.MapAllProperties().DoNotMap<bool>((Expression<Func<ClientCRM, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<ClientCRM, bool>>) (x => x.IsDirty)).Build();
      while (reader.Read())
        clientCrmList.Add(rowMapper.MapRow((IDataRecord) reader));
      return clientCrmList;
    }

    private List<ClientAddress> GetClientAddress(IDataReader reader)
    {
      List<ClientAddress> clientAddressList = new List<ClientAddress>();
      IRowMapper<ClientAddress> rowMapper = MapBuilder<ClientAddress>.MapAllProperties().DoNotMap<bool>((Expression<Func<ClientAddress, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<ClientAddress, bool>>) (x => x.IsDirty)).Build();
      while (reader.Read())
        clientAddressList.Add(rowMapper.MapRow((IDataRecord) reader));
      return clientAddressList;
    }

    private List<ClientActiveAddress> GetClientActiveAddress(
      IDataReader reader)
    {
      List<ClientActiveAddress> clientActiveAddressList = new List<ClientActiveAddress>();
      IRowMapper<ClientActiveAddress> rowMapper = MapBuilder<ClientActiveAddress>.MapAllProperties().Build();
      while (reader.Read())
        clientActiveAddressList.Add(rowMapper.MapRow((IDataRecord) reader));
      return clientActiveAddressList;
    }

    public IEnumerable<Client> FetchByName()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchClient"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<Client> mapper = MapBuilder<Client>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<Client>) null;
        }
      }
    }

    public IDataReader Query(QueryDefinition definition, int pageSize, int pageNumber)
    {
      SqlCriterionVisitResult criterionVisitResult = new SqlCriterionVisitor((IDictionary<string, string>) this.knownMappings).Build(definition.Criterion);
      string str = string.Empty;
      foreach (Ordering ordering in definition.Order)
        str = string.Format("{0}{1} {2},", (object) str, (object) ordering.PropertyName, (object) ordering.Direction);
      DbCommand sqlStringCommand = this.db.GetSqlStringCommand(string.Format("{0}  SELECT count(Name) FROM View_ClientSearch WHERE {1}", (object) string.Format(";WITH cte as (SELECT *, ROW_NUMBER() OVER (ORDER BY {0}) AS _row FROM (Select Distinct * FROM View_ClientSearch WHERE {1})k) SELECT * FROM cte WHERE _row BETWEEN {2} AND {3}", (object) (string.IsNullOrEmpty(str) ? "Name asc" : str.Substring(0, str.Length - 1)), (object) criterionVisitResult.WhereClause, (object) (pageNumber + 1), (object) (pageSize + pageNumber)), (object) criterionVisitResult.WhereClause));
      sqlStringCommand.Parameters.AddRange((Array) criterionVisitResult.Parameters);
      return this.db.ExecuteReader(sqlStringCommand);
    }

    public IDataReader FetchFullLegalNames(string fullLegalName, bool showAll)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssuerNamesAutoComplete"))
      {
        this.db.AddInParameter(storedProcCommand, "@FullLegalName", DbType.String, (object) RepositoryBase.EscapeForLike(fullLegalName));
        this.db.AddInParameter(storedProcCommand, "@ShowAll", DbType.Boolean, (object) showAll);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchFullLegalWithStateNames(string fullLegalName, bool showAll)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssuerWithStateNamesAutoComplete"))
      {
        this.db.AddInParameter(storedProcCommand, "@FullLegalName", DbType.String, (object) RepositoryBase.EscapeForLike(fullLegalName));
        this.db.AddInParameter(storedProcCommand, "@ShowAll", DbType.Boolean, (object) showAll);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader GetClientForAlias(string clientFullName, long clientId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchClientAliasAutoComplete"))
      {
        this.db.AddInParameter(storedProcCommand, "@clientId", DbType.Int64, (object) clientId);
        this.db.AddInParameter(storedProcCommand, "@ClientFullName", DbType.String, (object) RepositoryBase.EscapeForLike(clientFullName));
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IEnumerable<SearchSetting> FetchAllBookmarks() => this.SearchSettingRepository.FetchByModuleName("Client Search", (long) this.AppUser.Id);

    public void SaveBookMark(SearchSetting searchSetting)
    {
      searchSetting.Module = "Client Search";
      searchSetting.UserId = (long) this.AppUser.Id;
      this.SearchSettingRepository.Save(searchSetting);
    }

    public void DeleteBookMark(long bookmarkId) => this.SearchSettingRepository.Delete(bookmarkId);

    public bool CheckClientIdUsedInEntity(long clientId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_CheckClientIdUsedInEntity"))
      {
        this.db.AddInParameter(storedProcCommand, "@ClientId", DbType.Int64, (object) clientId);
        return Convert.ToBoolean(this.db.ExecuteScalar(storedProcCommand));
      }
    }

    public bool IsClientAddressUsed(long AddressID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CheckClientAddressUsed"))
      {
        this.db.AddInParameter(storedProcCommand, "@AddressID", DbType.Int64, (object) AddressID);
        return Convert.ToBoolean(this.db.ExecuteScalar(storedProcCommand));
      }
    }
  }
}
