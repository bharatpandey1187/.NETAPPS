﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.GraphicalViewRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IGraphicalViewRepository))]
  public class GraphicalViewRepository : RepositoryBase, IGraphicalViewRepository
  {
    public WorkflowHtml GetWorkflowHtml(long entityID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchWorkflowHtmlByEntityId"))
      {
        WorkflowHtml workflowHtml = new WorkflowHtml();
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          if (dataReader.Read())
            workflowHtml = MapBuilder<WorkflowHtml>.MapAllProperties().Build().MapRow((IDataRecord) dataReader);
        }
        return workflowHtml;
      }
    }
  }
}
