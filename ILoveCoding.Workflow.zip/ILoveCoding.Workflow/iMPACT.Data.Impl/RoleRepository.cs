﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.RoleRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IRoleRepository))]
  public class RoleRepository : RepositoryBase, IRoleRepository
  {
    public string Save(Role theRole)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveRole"))
      {
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) theRole.RoleID);
        this.db.AddInParameter(storedProcCommand, "@RoleName", DbType.String, (object) theRole.RoleName);
        this.db.AddInParameter(storedProcCommand, "@Entity", DbType.String, (object) theRole.Entity);
        this.db.AddOutParameter(storedProcCommand, "@ResultMessage", DbType.String, 1000);
        this.db.ExecuteNonQuery(storedProcCommand);
        return this.db.GetParameterValue(storedProcCommand, "@ResultMessage").ToString();
      }
    }

    public Role FetchByKey(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchRoleByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@RoleId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<Role>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new Role();
      }
    }

    public IEnumerable<Role> FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllRole"))
      {
        List<Role> roleList = new List<Role>();
        this.db.AddInParameter(storedProcCommand, "@Entity", DbType.String, (object) null);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Role> rowMapper1 = MapBuilder<Role>.MapAllProperties().Build();
          while (dataReader.Read())
            roleList.Add(rowMapper1.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            IRowMapper<Permission> rowMapper2 = MapBuilder<Permission>.MapAllProperties().Build();
            List<Permission> source = new List<Permission>();
            while (dataReader.Read())
              source.Add(rowMapper2.MapRow((IDataRecord) dataReader));
            foreach (Role role1 in roleList)
            {
              Role role = role1;
              role.Permissions = source.Where<Permission>((Func<Permission, bool>) (x => x.RoleID == role.RoleID)).ToList<Permission>();
            }
          }
        }
        return (IEnumerable<Role>) roleList;
      }
    }

    public IEnumerable<Permission> FetchAllPermissions(bool orderByEntity = false)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllPermission"))
      {
        this.db.AddInParameter(storedProcCommand, "@OrderByEntity", DbType.Boolean, (object) orderByEntity);
        List<Permission> permissionList = new List<Permission>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Permission> rowMapper = MapBuilder<Permission>.MapAllProperties().DoNotMap<long>((Expression<Func<Permission, long>>) (x => x.RoleID)).Build();
          while (dataReader.Read())
            permissionList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<Permission>) permissionList;
      }
    }

    public IEnumerable<RolePermission> FetchAllRolePermissions()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllRolePermission"))
      {
        List<RolePermission> rolePermissionList = new List<RolePermission>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<RolePermission> rowMapper = MapBuilder<RolePermission>.MapAllProperties().Build();
          while (dataReader.Read())
            rolePermissionList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<RolePermission>) rolePermissionList;
      }
    }

    public void SaveRolePermissions(List<RolePermission> rolePermissions, long roleId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveRolePermission"))
      {
        this.db.AddInParameter(storedProcCommand, "@RolePermissionTable", SqlDbType.Structured, (object) this.ConvertListToDataTable<RolePermission>(rolePermissions));
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) roleId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteRoleByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@RoleId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IEnumerable<Role> FetchByEntity(string entity)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllRole"))
      {
        List<Role> roleList = new List<Role>();
        this.db.AddInParameter(storedProcCommand, "@Entity", DbType.String, (object) entity);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Role> rowMapper1 = MapBuilder<Role>.MapAllProperties().Build();
          while (dataReader.Read())
            roleList.Add(rowMapper1.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            IRowMapper<Permission> rowMapper2 = MapBuilder<Permission>.MapAllProperties().Build();
            List<Permission> source = new List<Permission>();
            while (dataReader.Read())
              source.Add(rowMapper2.MapRow((IDataRecord) dataReader));
            foreach (Role role1 in roleList)
            {
              Role role = role1;
              role.Permissions = source.Where<Permission>((Func<Permission, bool>) (x => x.RoleID == role.RoleID)).ToList<Permission>();
            }
          }
        }
        return (IEnumerable<Role>) roleList;
      }
    }
  }
}
