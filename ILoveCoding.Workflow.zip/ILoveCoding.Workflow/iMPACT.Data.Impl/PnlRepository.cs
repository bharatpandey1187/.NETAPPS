﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.PnlRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IPnlRepository))]
  public class PnlRepository : RepositoryBase, IPnlRepository
  {
    public ApplicablePnlTemplate FetchApplicablePnlTemplateById(
      long issueId,
      string jobNumber)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchApplicablePnlTemplateById"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int64, (object) issueId);
        this.db.AddInParameter(storedProcCommand, "@JobNumber", DbType.String, (object) jobNumber);
        this.db.AddInParameter(storedProcCommand, "@WithEffectFrom", DbType.DateTime, (object) DateTime.UtcNow);
        ApplicablePnlTemplate applicablePnlTemplate = new ApplicablePnlTemplate();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<ApplicablePnlTemplate> rowMapper = MapBuilder<ApplicablePnlTemplate>.MapAllProperties().Build();
          if (dataReader.Read())
            applicablePnlTemplate = rowMapper.MapRow((IDataRecord) dataReader);
        }
        return applicablePnlTemplate;
      }
    }

    public Pnl FetchPnlDetailsById(
      long issueId,
      string jobNumber,
      long templateId,
      long AppTranID = 0,
      long toState = 0)
    {
      Pnl pnl = new Pnl();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPnlTemplateFields"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int64, (object) issueId);
        this.db.AddInParameter(storedProcCommand, "@TemplateId", DbType.Int64, (object) templateId);
        this.db.AddInParameter(storedProcCommand, "@JobNumber", DbType.String, (object) jobNumber);
        this.db.AddInParameter(storedProcCommand, "@AppTranID", DbType.String, (object) AppTranID);
        this.db.AddInParameter(storedProcCommand, "@entityStateID", DbType.Int64, (object) toState);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          while (reader.Read())
          {
            object obj = reader.GetValue(0);
            if (obj != null)
              pnl.JobNumbers.Add(obj.ToString());
          }
          if (reader.NextResult())
          {
            IRowMapper<PnlHeaderInfo> rowMapper = MapBuilder<PnlHeaderInfo>.MapAllProperties().Build();
            if (reader.Read())
              pnl.PnlHeaderInfo = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult())
          {
            IRowMapper<PnlSyndicateMember> rowMapper = MapBuilder<PnlSyndicateMember>.MapAllProperties().Build();
            while (reader.Read())
              pnl.SyndicateMembers.Add(rowMapper.MapRow((IDataRecord) reader));
          }
          if (reader.NextResult())
          {
            IRowMapper<PnlSeries> rowMapper = MapBuilder<PnlSeries>.MapAllProperties().DoNotMap<int>((Expression<Func<PnlSeries, int>>) (s => s.Version)).Build();
            while (reader.Read())
              pnl.PnlSeries.Add(rowMapper.MapRow((IDataRecord) reader));
          }
          if (reader.NextResult())
          {
            IRowMapper<UniqueSection> rowMapper = MapBuilder<UniqueSection>.MapAllProperties().Build();
            while (reader.Read())
              pnl.UniqueSections.Add(rowMapper.MapRow((IDataRecord) reader));
          }
          if (reader.NextResult())
          {
            IRowMapper<UniqueCategory> rowMapper = MapBuilder<UniqueCategory>.MapAllProperties().DoNotMap<bool>((Expression<Func<UniqueCategory, bool>>) (x => x.IsCategoryViewOnly)).Build();
            while (reader.Read())
              pnl.UniqueCategories.Add(rowMapper.MapRow((IDataRecord) reader));
          }
          if (reader.NextResult())
          {
            IRowMapper<UniqueRowUnderSection> rowMapper = MapBuilder<UniqueRowUnderSection>.MapAllProperties().Build();
            while (reader.Read())
              pnl.UniqueRowsUnderSection.Add(rowMapper.MapRow((IDataRecord) reader));
          }
          if (reader.NextResult())
          {
            while (reader.Read())
            {
              IRowMapper<PnLTemplateFields> rowMapper = MapBuilder<PnLTemplateFields>.MapAllProperties().Build();
              pnl.PnLFields.Add(rowMapper.MapRow((IDataRecord) reader));
              pnl.PnLTemplateFields.Add(rowMapper.MapRow((IDataRecord) reader));
            }
            PnLTemplateFields pnLtemplateFields1 = pnl.PnLTemplateFields.FirstOrDefault<PnLTemplateFields>((Func<PnLTemplateFields, bool>) (t => t.Key == "Notes_RecordActionTotalPerThousand"));
            if (pnLtemplateFields1.Value == null)
              pnLtemplateFields1.Value = "0101";
            pnl.PnLTemplateFields = FormulaHelper.GenerateScriptForFormula(pnl.PnLTemplateFields);
            PnLTemplateFields pnLtemplateFields2 = pnl.PnLFields.FirstOrDefault<PnLTemplateFields>((Func<PnLTemplateFields, bool>) (t => t.Key == "Notes_RecordActionTotalPerThousand"));
            if (pnLtemplateFields2.Value == null)
              pnLtemplateFields2.Value = "0101";
            pnl.PnLFields = FormulaHelper.GenerateScriptForFormula(pnl.PnLFields, false);
          }
          if (reader.NextResult())
          {
            IRowMapper<AppTransactionPnLUnderWritingSpread> rowMapper = MapBuilder<AppTransactionPnLUnderWritingSpread>.MapAllProperties().Build();
            while (reader.Read())
              pnl.UnderwritingSpread = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult())
            pnl.WorkflowStateTransitions = this.GetStateTransitions(reader);
          if (reader.NextResult())
          {
            while (reader.Read())
              pnl.Version = (int) Convert.ToInt16(reader[0].ToString());
          }
          if (reader.NextResult())
          {
            while (reader.Read())
              pnl.PnlCount = (int) Convert.ToInt16(reader[0].ToString());
          }
          if (reader.NextResult())
            pnl.PnL = this.GetPnLBO(reader);
          pnl.PnlFieldDetails = this.ConvertPnlFieldsToDictionary(pnl);
          if (!string.IsNullOrEmpty(pnl.PnlHeaderInfo.CommaSeperatedStateID))
            pnl.PnlHeaderInfo.PnLStatus = ((IEnumerable<string>) pnl.PnlHeaderInfo.CommaSeperatedStateID.Split(new string[1]
            {
              ","
            }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
          else
            pnl.PnlHeaderInfo.PnLStatus = new List<long>();
          pnl.PnL.PricingDesk = pnl.PnlHeaderInfo.PricingDesk;
        }
      }
      return pnl;
    }

    private Dictionary<string, object> ConvertPnlFieldsToDictionary(Pnl pnl)
    {
      Dictionary<string, object> dictionary = new Dictionary<string, object>();
      foreach (PnLTemplateFields pnLtemplateField in pnl.PnLTemplateFields)
      {
        if (!string.IsNullOrEmpty(pnLtemplateField.Key))
        {
          if (!string.IsNullOrEmpty(pnLtemplateField.Value))
          {
            if (pnLtemplateField.DataType == "Decimal")
            {
              Decimal result;
              Decimal.TryParse(pnLtemplateField.Value, out result);
              dictionary.Add(pnLtemplateField.Key, (object) result);
            }
            else if (pnLtemplateField.DataType == "Date")
            {
              DateTime result;
              DateTime.TryParse(pnLtemplateField.Value, out result);
              dictionary.Add(pnLtemplateField.Key, (object) result);
            }
            else if (pnLtemplateField.DataType == "Integer")
            {
              long result;
              long.TryParse(pnLtemplateField.Value, out result);
              dictionary.Add(pnLtemplateField.Key, (object) result);
            }
            else
              dictionary.Add(pnLtemplateField.Key, (object) pnLtemplateField.Value);
          }
          else
            dictionary.Add(pnLtemplateField.Key, (object) pnLtemplateField.Value);
        }
        else
          dictionary.Add(pnLtemplateField.Key, (object) pnLtemplateField.Value);
      }
      dictionary.Add("PnlFieldsMetadata", (object) pnl.PnLTemplateFields);
      return dictionary;
    }

    public Dictionary<PnlEnums.PnLStatus, PnlEnums.PnLStatus> FetchHistoryByAppTransactionID(
      long appTransactionID)
    {
      Dictionary<PnlEnums.PnLStatus, PnlEnums.PnLStatus> dictionary;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchHistoryByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          dictionary = new Dictionary<PnlEnums.PnLStatus, PnlEnums.PnLStatus>();
          int ordinal1 = dataReader.GetOrdinal("ParentStateID");
          int ordinal2 = dataReader.GetOrdinal("StateID");
          while (dataReader.Read())
          {
            PnlEnums.PnLStatus int32_1 = (PnlEnums.PnLStatus) dataReader.GetInt32(ordinal1);
            PnlEnums.PnLStatus int32_2 = (PnlEnums.PnLStatus) dataReader.GetInt32(ordinal2);
            dictionary.Add(int32_1, int32_2);
          }
        }
      }
      return dictionary;
    }

    public Pnl FetchPnlHistoryById(long appId, int fromVersion, int toVersion)
    {
      Pnl pnl = new Pnl();
      List<Dictionary<string, object>> dictionaryList1 = new List<Dictionary<string, object>>();
      List<Dictionary<string, object>> dictionaryList2 = new List<Dictionary<string, object>>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPnlTemplateFieldsHistory"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appId);
        this.db.AddInParameter(storedProcCommand, "@fromVersion", DbType.Int64, (object) fromVersion);
        this.db.AddInParameter(storedProcCommand, "@toVersion", DbType.Int64, (object) toVersion);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          if (dataReader != null)
          {
            IRowMapper<UniqueSection> rowMapper1 = MapBuilder<UniqueSection>.MapAllProperties().Build();
            while (dataReader.Read())
              pnl.UniqueSections.Add(rowMapper1.MapRow((IDataRecord) dataReader));
            for (int index = 0; index < pnl.UniqueSections.Count; ++index)
            {
              if (dataReader.NextResult())
              {
                while (dataReader.Read())
                {
                  Dictionary<string, object> dictionary = dataReader.ConvertToDictionary();
                  dictionaryList1.Add(dictionary);
                }
              }
            }
            if (dataReader.NextResult())
            {
              pnl.PnlUserInfo = new List<PnlUserInfo>();
              IRowMapper<PnlUserInfo> rowMapper2 = MapBuilder<PnlUserInfo>.MapAllProperties().Build();
              while (dataReader.Read())
                pnl.PnlUserInfo.Add(rowMapper2.MapRow((IDataRecord) dataReader));
            }
            if (dataReader.NextResult())
            {
              while (dataReader.Read())
              {
                Dictionary<string, object> dictionary = dataReader.ConvertToDictionary();
                dictionaryList2.Add(dictionary);
              }
            }
          }
        }
      }
      pnl.PnlAuditData = dictionaryList1;
      pnl.PnlSummaryUnderWrittingHistory = dictionaryList2;
      return pnl;
    }

    public long Save(
      Pnl pnl,
      Dictionary<int, int> history,
      List<PnLFromStateToState> fromToStateList,
      List<PnLFromStateToState> stateAuditTrailList,
      long issueId,
      string jobNumber)
    {
      PnlEnums.PnLStatus pnLstatus = fromToStateList == null || fromToStateList.FirstOrDefault<PnLFromStateToState>() == null ? (PnlEnums.PnLStatus) 0 : fromToStateList.FirstOrDefault<PnLFromStateToState>().ToState;
      if (pnl == null)
      {
        Pnl pnl1 = this.FetchPnlDetailsById(issueId, jobNumber, 0L, 0L, (long) pnLstatus);
        pnl = pnl1;
        string performTotalPerThousand = pnl.PnlFieldDetails.FirstOrDefault<KeyValuePair<string, object>>((Func<KeyValuePair<string, object>, bool>) (t => t.Key == "Notes_RecordActionTotalPerThousand")).Value.ToString();
        this.BindUnderWritingSpread(pnl.UnderwritingSpread, pnl.PnL);
        this.ReInitUnderWritingValue(pnl.PnL);
        FormulaHelper.RecalculateUnderwritingSpread(pnl.PnL, performTotalPerThousand);
        FormulaHelper.EvaluateFormula(pnl1.PnLFields, pnl.PnL, pnl1.PnlFieldDetails, pnl1.PnLFields);
      }
      else
      {
        Pnl pnl1 = this.FetchPnlDetailsById(pnl.PnlHeaderInfo.IssueId, pnl.PnlHeaderInfo.JobNumber, pnl.PnlHeaderInfo.PnlTemplateId, pnl.PnlHeaderInfo.AppTransactionId, (long) pnLstatus);
        string performTotalPerThousand = pnl.PnlFieldDetails.FirstOrDefault<KeyValuePair<string, object>>((Func<KeyValuePair<string, object>, bool>) (t => t.Key == "Notes_RecordActionTotalPerThousand")).Value.ToString();
        this.ReInitUnderWritingValue(pnl.PnL);
        FormulaHelper.RecalculateUnderwritingSpread(pnl.PnL, performTotalPerThousand);
        FormulaHelper.EvaluateFormula(pnl1.PnLFields, pnl.PnL, pnl.PnlFieldDetails, pnl.PnLTemplateFields);
      }
      pnl.AppTransactionPnLFields = pnl.PnLTemplateFields.Where<PnLTemplateFields>((Func<PnLTemplateFields, bool>) (q => !string.IsNullOrEmpty(q.Key))).Select<PnLTemplateFields, AppTransactionPnLFields>((Func<PnLTemplateFields, AppTransactionPnLFields>) (q => new AppTransactionPnLFields()
      {
        AppTransactionID = pnl.PnlHeaderInfo.AppTransactionId,
        Key = q.Key,
        Value = pnl.PnlFieldDetails.ContainsKey(q.Key) ? (pnl.PnlFieldDetails[q.Key] == null || string.IsNullOrEmpty(pnl.PnlFieldDetails[q.Key].ToString()) ? (string) null : pnl.PnlFieldDetails[q.Key].ToString()) : (string) null,
        Overridden = q.Overridden,
        DataType = q.DataType,
        SectionId = q.SectionId,
        CategoryId = q.CategoryId,
        Format = q.Format,
        RowNumber = q.PnLTemplateKeyId,
        Caption = q.Caption
      })).ToList<AppTransactionPnLFields>();
      pnl.AppTransactionPnLSeries = pnl.PnlSeries.Select<PnlSeries, AppTransactionPnLSeries>((Func<PnlSeries, AppTransactionPnLSeries>) (pnlSeriesRow => new AppTransactionPnLSeries()
      {
        PnlNumber = pnl.PnlHeaderInfo.PnlNumber,
        SeriesId = pnlSeriesRow.SeriesID
      })).ToList<AppTransactionPnLSeries>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SavePnl"))
      {
        DataTable dataTable1 = new DataTable();
        dataTable1.Columns.Add("AppTransactionId", typeof (long));
        dataTable1.Columns.Add("Key", typeof (string));
        dataTable1.Columns.Add("Value", typeof (string));
        dataTable1.Columns.Add("Overridden", typeof (bool));
        dataTable1.Columns.Add("DataType", typeof (string));
        dataTable1.Columns.Add("Format", typeof (string));
        foreach (AppTransactionPnLFields transactionPnLfield in pnl.AppTransactionPnLFields)
        {
          DataRow row = dataTable1.NewRow();
          row["AppTransactionId"] = (object) pnl.PnlHeaderInfo.AppTransactionId;
          row["Key"] = (object) transactionPnLfield.Key;
          row["Value"] = (object) transactionPnLfield.Value;
          row["Overridden"] = (object) transactionPnLfield.Overridden;
          row["DataType"] = (object) transactionPnLfield.DataType;
          row["Format"] = (object) transactionPnLfield.Format;
          dataTable1.Rows.Add(row);
        }
        DataTable dataTable2 = new DataTable();
        dataTable2.Columns.Add("AppTransactionID", typeof (long));
        dataTable2.Columns.Add("StateID", typeof (int));
        if (pnl.PnlHeaderInfo.PnLStatus != null)
        {
          foreach (long pnLstatu in pnl.PnlHeaderInfo.PnLStatus)
          {
            DataRow row = dataTable2.NewRow();
            row["AppTransactionID"] = (object) pnl.PnlHeaderInfo.AppTransactionId;
            row["StateID"] = (object) int.Parse(pnLstatu.ToString());
            dataTable2.Rows.Add(row);
          }
        }
        DataTable dataTable3 = new DataTable();
        dataTable3.Columns.Add("AppTransactionID", typeof (long));
        dataTable3.Columns.Add("ParentStateID", typeof (int));
        dataTable3.Columns.Add("StateID", typeof (int));
        if (history != null && history.Count > 0)
        {
          foreach (KeyValuePair<int, int> keyValuePair in history)
          {
            DataRow row = dataTable3.NewRow();
            row["AppTransactionID"] = (object) pnl.PnlHeaderInfo.AppTransactionId;
            row["ParentStateID"] = (object) keyValuePair.Key;
            row["StateID"] = (object) keyValuePair.Value;
            dataTable3.Rows.Add(row);
          }
        }
        DataTable dataTable4 = new DataTable();
        dataTable4.Columns.Add("FromState", typeof (int));
        dataTable4.Columns.Add("ToState", typeof (int));
        if (fromToStateList != null)
        {
          foreach (PnLFromStateToState fromToState in fromToStateList)
          {
            DataRow row = dataTable4.NewRow();
            PnlEnums.PnLStatus? fromState = fromToState.FromState;
            if (fromState.HasValue)
            {
              DataRow dataRow = row;
              fromState = fromToState.FromState;
              // ISSUE: variable of a boxed type
              __Boxed<int> local = (System.ValueType) (int) fromState.Value;
              dataRow["FromState"] = (object) local;
            }
            else
              row["FromState"] = (object) DBNull.Value;
            row["ToState"] = (object) (int) fromToState.ToState;
            dataTable4.Rows.Add(row);
          }
        }
        DataTable dataTable5 = new DataTable();
        dataTable5.Columns.Add("FromState", typeof (int));
        dataTable5.Columns.Add("ToState", typeof (int));
        if (stateAuditTrailList != null)
        {
          foreach (PnLFromStateToState stateAuditTrail in stateAuditTrailList)
          {
            DataRow row = dataTable5.NewRow();
            row["FromState"] = (object) (int) stateAuditTrail.FromState.Value;
            row["ToState"] = (object) (int) stateAuditTrail.ToState;
            dataTable5.Rows.Add(row);
          }
        }
        DataTable dataTable6 = this.ConvertListToDataTable<AppTransactionPnLUnderWritingSpread>(new List<AppTransactionPnLUnderWritingSpread>()
        {
          pnl.UnderwritingSpread
        });
        this.db.AddInParameter(storedProcCommand, "@AppTranID", DbType.Int64, (object) pnl.PnlHeaderInfo.AppTransactionId);
        this.db.AddInParameter(storedProcCommand, "@PnlTemplateId", DbType.Int64, (object) pnl.PnlHeaderInfo.PnlTemplateId);
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int64, (object) pnl.PnlHeaderInfo.IssueId);
        this.db.AddInParameter(storedProcCommand, "@PnlNbr", DbType.String, (object) pnl.PnlHeaderInfo.PnlNumber);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailDate", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionPnLFieldsTableType", SqlDbType.Structured, (object) dataTable1);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionPnLSeriesTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<AppTransactionPnLSeries>(pnl.AppTransactionPnLSeries));
        this.db.AddInParameter(storedProcCommand, "@ActionPerformedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionState", SqlDbType.Structured, (object) dataTable2);
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionStateHistory", SqlDbType.Structured, (object) dataTable3);
        this.db.AddInParameter(storedProcCommand, "@tblFromStateToState", SqlDbType.Structured, (object) dataTable4);
        this.db.AddInParameter(storedProcCommand, "@tblAuditTrail", SqlDbType.Structured, (object) dataTable5);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) 3);
        this.db.AddInParameter(storedProcCommand, "@JobNumber", DbType.String, (object) pnl.PnlHeaderInfo.JobNumber);
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionPnLUnderWritingSpread", SqlDbType.Structured, (object) dataTable6);
        this.db.AddInParameter(storedProcCommand, "@Version", SqlDbType.Int, (object) pnl.Version);
        this.db.AddInParameter(storedProcCommand, "@PNLNotes", DbType.String, (object) pnl.PnlHeaderInfo.PnlNotes);
        this.db.AddInParameter(storedProcCommand, "@PricingDesk", DbType.Int64, (object) pnl.PnlHeaderInfo.PricingDeskId);
        this.db.AddInParameter(storedProcCommand, "@ManagementFee", DbType.String, (object) pnl.PnlHeaderInfo.ManagementFee);
        this.db.AddInParameter(storedProcCommand, "@PNLReviewComments", DbType.String, (object) pnl.PnlHeaderInfo.PnlReviewComments);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.AddParameter(storedProcCommand, "@RETURN_VALUE", DbType.Int32, ParameterDirection.ReturnValue, string.Empty, DataRowVersion.Default, (object) null);
        this.db.ExecuteNonQuery(storedProcCommand);
        long num = Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
        int result;
        if (int.TryParse(Convert.ToString(storedProcCommand.Parameters["@RETURN_VALUE"].Value), out result))
        {
          switch (result)
          {
            case -2:
              num = -2L;
              break;
            case -1:
              num = -1L;
              break;
          }
        }
        return num;
      }
    }

    public bool UpdateStatusTracking(long appTransactionID, List<int> pnlStatusList, int entityID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEntityStateTracking_New"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityID);
        DataTable dataTable = new DataTable();
        dataTable.Columns.Add("ID", typeof (int));
        foreach (int pnlStatus in pnlStatusList)
        {
          DataRow row = dataTable.NewRow();
          row["ID"] = (object) pnlStatus;
          dataTable.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblCurrentState", SqlDbType.Structured, (object) dataTable);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public List<string> FetchJobNumbers(long appTransactionID)
    {
      List<string> stringList = new List<string>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_FetchIssueJobNumbers"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueID", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            stringList.Add(dataReader.GetString(0));
        }
      }
      return stringList;
    }

    public DataTable FetchWriteOffData(long PnLTemplateID)
    {
      DataTable dataTable = new DataTable();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_FetchWriteOffData"))
      {
        this.db.AddInParameter(storedProcCommand, "@PnLTemplateID", DbType.Int64, (object) PnLTemplateID);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
          dataTable.Load(reader);
      }
      return dataTable;
    }

    private List<AppTransactionStateTransition> GetStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    public List<PnLStatusData> FetchAllPnLStatusByIssueId(long issueId)
    {
      List<PnLStatusData> pnLstatusDataList = new List<PnLStatusData>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllPnLStatusByIssueId"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int64, (object) issueId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<PnLStatusData> rowMapper = MapBuilder<PnLStatusData>.MapAllProperties().Build();
          while (dataReader.Read())
            pnLstatusDataList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return pnLstatusDataList;
    }

    public IDataReader FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityPNLTemplateByEntityID"))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public IDataReader FetchCategoryNames(int sectionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityCategoryNamesBySectionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@SectionID", DbType.Int64, (object) sectionID);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public List<Dictionary<string, object>> ConvertDataTabletoDictionary(DataTable dt)
    {
      List<Dictionary<string, object>> dictionaryList = new List<Dictionary<string, object>>();
      foreach (DataRow row in (InternalDataCollectionBase) dt.Rows)
      {
        Dictionary<string, object> dictionary = new Dictionary<string, object>();
        foreach (DataColumn column in (InternalDataCollectionBase) dt.Columns)
          dictionary.Add(column.ColumnName, row[column]);
        dictionaryList.Add(dictionary);
      }
      return dictionaryList;
    }

    public List<Dictionary<string, object>> FetchAllGridData(
      long templateId,
      int sectionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPNLGridData", (object) templateId, (object) sectionId))
      {
        List<Dictionary<string, object>> dictionaryList;
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          DataTable dt = new DataTable();
          dt.Load(reader);
          dictionaryList = this.ConvertDataTabletoDictionary(dt);
        }
        return dictionaryList;
      }
    }

    public string CopyPNLTemplate(long templateId)
    {
      string[] strArray = TimeZone.CurrentTimeZone.StandardName.Split(new char[1]
      {
        ' '
      }, StringSplitOptions.RemoveEmptyEntries);
      StringBuilder stringBuilder = new StringBuilder();
      foreach (string str in strArray)
        stringBuilder.Append(str[0]);
      string str1 = "_" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " (" + (object) stringBuilder + ")";
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CopyPnlTemplate"))
      {
        this.db.AddInParameter(storedProcCommand, "@PNLTemplateID", SqlDbType.BigInt, (object) templateId);
        this.db.AddInParameter(storedProcCommand, "@DateTimeInfo", SqlDbType.VarChar, (object) str1);
        this.db.AddOutParameter(storedProcCommand, "@OutPNLTemplateName", DbType.String, 64);
        this.db.ExecuteNonQuery(storedProcCommand);
        return this.db.GetParameterValue(storedProcCommand, "@OutPNLTemplateName").ToString();
      }
    }

    public IDataReader FetchPNLKeyDetails(string key, long pnlTemplateID, int sectionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchKeyDetailsFromTemplateID", (object) key, (object) pnlTemplateID, (object) sectionID))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public long SavePNLTemplate(PNLTemplate pnlTemplate)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SavePnlTemplate"))
      {
        this.db.AddInParameter(storedProcCommand, "@PNLTemplateID", SqlDbType.BigInt, (object) pnlTemplate.PNLTemplateID);
        this.db.AddInParameter(storedProcCommand, "@PNLTemplateName", SqlDbType.VarChar, (object) pnlTemplate.PNLTemplateName);
        this.db.AddInParameter(storedProcCommand, "@EntityID", SqlDbType.BigInt, (object) pnlTemplate.EntityID);
        this.db.AddInParameter(storedProcCommand, "@SelectorFormula", SqlDbType.VarChar, (object) pnlTemplate.SelectorFormula);
        this.db.AddInParameter(storedProcCommand, "@WithEffectFrom", SqlDbType.DateTime, (object) pnlTemplate.WithEffectFrom);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", SqlDbType.VarChar, (object) this.AppUser.Name);
        this.db.AddOutParameter(storedProcCommand, "@OutPNLTemplateID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutPNLTemplateID"));
      }
    }

    public long SavePNLTemplateKeys(PNLTemplate pnlTemplate)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SavePnlTemplateKeys"))
      {
        this.db.AddInParameter(storedProcCommand, "@IsKeyUpdate", SqlDbType.Bit, (object) pnlTemplate.IsKeyUpdate);
        this.db.AddInParameter(storedProcCommand, "@PNLTemplateID", SqlDbType.BigInt, (object) pnlTemplate.PNLTemplateID);
        this.db.AddInParameter(storedProcCommand, "@SectionID", SqlDbType.BigInt, (object) pnlTemplate.SectionID);
        this.db.AddInParameter(storedProcCommand, "@CategoryID", SqlDbType.BigInt, (object) pnlTemplate.CategoryID);
        this.db.AddInParameter(storedProcCommand, "@RowNumber", SqlDbType.BigInt, (object) pnlTemplate.RowNumber);
        if (!string.IsNullOrEmpty(pnlTemplate.Caption))
          this.db.AddInParameter(storedProcCommand, "@Caption", SqlDbType.VarChar, (object) pnlTemplate.Caption);
        this.db.AddInParameter(storedProcCommand, "@Key", SqlDbType.VarChar, (object) pnlTemplate.Key);
        this.db.AddInParameter(storedProcCommand, "@Formula", SqlDbType.VarChar, (object) pnlTemplate.Formula);
        this.db.AddInParameter(storedProcCommand, "@CanOverride", SqlDbType.Bit, (object) pnlTemplate.CanOverride);
        this.db.AddInParameter(storedProcCommand, "@DataType", SqlDbType.VarChar, (object) pnlTemplate.DataType);
        if (!string.IsNullOrEmpty(pnlTemplate.Format))
          this.db.AddInParameter(storedProcCommand, "@Format", SqlDbType.VarChar, (object) pnlTemplate.Format);
        if (!string.IsNullOrEmpty(pnlTemplate.Notes))
          this.db.AddInParameter(storedProcCommand, "@Notes", SqlDbType.VarChar, (object) pnlTemplate.Notes);
        this.db.AddInParameter(storedProcCommand, "@Indenting", SqlDbType.Int, (object) pnlTemplate.Indenting);
        this.db.AddOutParameter(storedProcCommand, "@OutPNLTemplateID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutPNLTemplateID"));
      }
    }

    public IDataReader FetchPNLTemplateByID(int TemplateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPnlTemplateFromID", (object) TemplateID))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public void DeletePNLTemplateKeys(string key)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeletePnlTemplateKeys", (object) key))
        this.db.ExecuteNonQuery(storedProcCommand);
    }

    public void SaveIntegrationQueue(long appTransID, List<int> statusList)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveIntegrationQueue"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", SqlDbType.BigInt, (object) appTransID);
        this.db.AddInParameter(storedProcCommand, "@state", SqlDbType.BigInt, (object) statusList[0]);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void UpdatePNLTemplatePublishedStatus(long templateId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_UpdatePNLTemplatePublishedStatus", (object) templateId))
        this.db.ExecuteNonQuery(storedProcCommand);
      Pnl pnl = new Pnl();
      using (IDataReader dataReader = this.FetchAllPnlTemplateKeyDetails(templateId))
      {
        IRowMapper<PnLTemplateFields> rowMapper = MapBuilder<PnLTemplateFields>.MapAllProperties().DoNotMap<long>((Expression<Func<PnLTemplateFields, long>>) (x => x.CategoryId)).DoNotMap<long>((Expression<Func<PnLTemplateFields, long>>) (x => x.SectionId)).DoNotMap<string>((Expression<Func<PnLTemplateFields, string>>) (x => x.Value)).Build();
        while (dataReader.Read())
          pnl.PnLTemplateFields.Add(rowMapper.MapRow((IDataRecord) dataReader));
      }
      pnl.PnLTemplateFields = FormulaHelper.GenerateScriptForFormula(pnl.PnLTemplateFields);
    }

    public void InsertRowIntoPNLGrid(long templateId, long sectionId, long rowNumber)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_InsertRowIntoPNLGrid", (object) templateId, (object) sectionId, (object) rowNumber))
        this.db.ExecuteNonQuery(storedProcCommand);
    }

    public void DeleteRowFromPNLGrid(long templateId, long sectionId, long rowNumber)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteRowFromPNLGrid", (object) templateId, (object) sectionId, (object) rowNumber))
        this.db.ExecuteNonQuery(storedProcCommand);
    }

    public bool FetchPNLTemplatePublishState(long templateId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPNLTemplatePublishState"))
      {
        this.db.AddInParameter(storedProcCommand, "@PNLTemplateID", SqlDbType.BigInt, (object) templateId);
        this.db.AddOutParameter(storedProcCommand, "@OutIsPublished", DbType.Boolean, 1);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@OutIsPublished"));
      }
    }

    public IDataReader FetchAllPnlTemplateKeyDetails(long templateId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllPublishedKeyDetailsFromTemplateID", (object) templateId))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public void EvaluateFormula(
      List<PnLTemplateFields> oldPnlFields,
      PnLBO pnl,
      Dictionary<string, object> pnlFieldDetails,
      List<PnLTemplateFields> pnlFieldsForSequence)
    {
      this.ReInitUnderWritingValue(pnl);
      PnLTemplateFields pnLtemplateFields = oldPnlFields.FirstOrDefault<PnLTemplateFields>((Func<PnLTemplateFields, bool>) (t => t.Key == "Notes_RecordActionTotalPerThousand"));
      FormulaHelper.RecalculateUnderwritingSpread(pnl, pnLtemplateFields.Value);
      FormulaHelper.EvaluateFormula(oldPnlFields, pnl, pnlFieldDetails, pnlFieldsForSequence);
    }

    private PnLBO GetPnLBO(IDataReader reader)
    {
      PnLBO pnLbo = new PnLBO();
      IRowMapper<PnLBO> rowMapper = MapBuilder<PnLBO>.MapAllProperties().DoNotMap<int>((Expression<Func<PnLBO, int>>) (q => q.NoOfSeries)).DoNotMap<Decimal>((Expression<Func<PnLBO, Decimal>>) (q => q.SeriesParAmount)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedTakedownTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedTakedownPerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualTakedownTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualTakedownPerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.TakedownDifference)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedExpenseTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedExpensePerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualExpenseTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualExpensePerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ExpenseDifference)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedExpenseTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedExpensePerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualExpenseTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualExpensePerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ExpenseDifference)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedStructuringTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedStructuringPerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualStructuringTotal)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualStructuringPerThousand)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.StructuringDifference)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedTotalGrossSpread)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ProjectedPerThousandGrossSpread)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualTotalGrossSpread)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.ActualPerThousandGrossSpread)).DoNotMap<Decimal?>((Expression<Func<PnLBO, Decimal?>>) (q => q.DifferenceGrossSpread)).DoNotMap<string>((Expression<Func<PnLBO, string>>) (q => q.PnLStatus)).DoNotMap<string>((Expression<Func<PnLBO, string>>) (q => q.PricingDesk)).Build();
      if (reader.Read())
      {
        pnLbo = rowMapper.MapRow((IDataRecord) reader);
        if (reader.NextResult())
          pnLbo.Series = this.GetIssueSeries(reader);
      }
      if (pnLbo != null)
      {
        if (pnLbo.Series != null && pnLbo.Series.Count > 0)
        {
          pnLbo.SeriesParAmount = pnLbo.Series.Sum<SeriesBO>((Func<SeriesBO, Decimal>) (item => item.SeriesParAmount));
          pnLbo.NoOfSeries = pnLbo.Series.Count;
        }
        else
        {
          pnLbo.SeriesParAmount = 0M;
          pnLbo.NoOfSeries = 0;
        }
      }
      return pnLbo;
    }

    private void ReInitUnderWritingValue(PnLBO underWritingPnl)
    {
      PnLBO pnLbo1 = underWritingPnl;
      Decimal? nullable1 = underWritingPnl.ProjectedTakedownTotal;
      Decimal? nullable2 = new Decimal?(nullable1 ?? 0M);
      pnLbo1.ProjectedTakedownTotal = nullable2;
      PnLBO pnLbo2 = underWritingPnl;
      nullable1 = underWritingPnl.ProjectedTakedownPerThousand;
      Decimal? nullable3 = new Decimal?(nullable1 ?? 0M);
      pnLbo2.ProjectedTakedownPerThousand = nullable3;
      PnLBO pnLbo3 = underWritingPnl;
      nullable1 = underWritingPnl.ActualTakedownTotal;
      Decimal? nullable4 = new Decimal?(nullable1 ?? 0M);
      pnLbo3.ActualTakedownTotal = nullable4;
      PnLBO pnLbo4 = underWritingPnl;
      nullable1 = underWritingPnl.ActualTakedownPerThousand;
      Decimal? nullable5 = new Decimal?(nullable1 ?? 0M);
      pnLbo4.ActualTakedownPerThousand = nullable5;
      PnLBO pnLbo5 = underWritingPnl;
      nullable1 = underWritingPnl.ProjectedExpensePerThousand;
      Decimal? nullable6 = new Decimal?(nullable1 ?? 0M);
      pnLbo5.ProjectedExpensePerThousand = nullable6;
      PnLBO pnLbo6 = underWritingPnl;
      nullable1 = underWritingPnl.ActualExpenseTotal;
      Decimal? nullable7 = new Decimal?(nullable1 ?? 0M);
      pnLbo6.ActualExpenseTotal = nullable7;
      PnLBO pnLbo7 = underWritingPnl;
      nullable1 = underWritingPnl.ActualExpensePerThousand;
      Decimal? nullable8 = new Decimal?(nullable1 ?? 0M);
      pnLbo7.ActualExpensePerThousand = nullable8;
      PnLBO pnLbo8 = underWritingPnl;
      nullable1 = underWritingPnl.ExpenseDifference;
      Decimal? nullable9 = new Decimal?(nullable1 ?? 0M);
      pnLbo8.ExpenseDifference = nullable9;
      PnLBO pnLbo9 = underWritingPnl;
      nullable1 = underWritingPnl.ProjectedStructuringPerThousand;
      Decimal? nullable10 = new Decimal?(nullable1 ?? 0M);
      pnLbo9.ProjectedStructuringPerThousand = nullable10;
      PnLBO pnLbo10 = underWritingPnl;
      nullable1 = underWritingPnl.ActualStructuringTotal;
      Decimal? nullable11 = new Decimal?(nullable1 ?? 0M);
      pnLbo10.ActualStructuringTotal = nullable11;
      PnLBO pnLbo11 = underWritingPnl;
      nullable1 = underWritingPnl.ActualStructuringPerThousand;
      Decimal? nullable12 = new Decimal?(nullable1 ?? 0M);
      pnLbo11.ActualStructuringPerThousand = nullable12;
      PnLBO pnLbo12 = underWritingPnl;
      nullable1 = underWritingPnl.ProjectedTotalGrossSpread;
      Decimal? nullable13 = new Decimal?(nullable1 ?? 0M);
      pnLbo12.ProjectedTotalGrossSpread = nullable13;
      PnLBO pnLbo13 = underWritingPnl;
      nullable1 = underWritingPnl.ProjectedPerThousandGrossSpread;
      Decimal? nullable14 = new Decimal?(nullable1 ?? 0M);
      pnLbo13.ProjectedPerThousandGrossSpread = nullable14;
      PnLBO pnLbo14 = underWritingPnl;
      nullable1 = underWritingPnl.ActualTotalGrossSpread;
      Decimal? nullable15 = new Decimal?(nullable1 ?? 0M);
      pnLbo14.ActualTotalGrossSpread = nullable15;
      PnLBO pnLbo15 = underWritingPnl;
      nullable1 = underWritingPnl.ActualPerThousandGrossSpread;
      Decimal? nullable16 = new Decimal?(nullable1 ?? 0M);
      pnLbo15.ActualPerThousandGrossSpread = nullable16;
    }

    private void BindUnderWritingSpread(
      AppTransactionPnLUnderWritingSpread pnLUnderWritingSpread,
      PnLBO Pnl)
    {
      Pnl.ProjectedTakedownTotal = pnLUnderWritingSpread.ProjectedTakedownTotal;
      Pnl.ProjectedTakedownPerThousand = pnLUnderWritingSpread.ProjectedTakedownPerThousand;
      Pnl.ActualTakedownTotal = pnLUnderWritingSpread.ActualTakedownTotal;
      Pnl.ActualTakedownPerThousand = pnLUnderWritingSpread.ActualTakedownPerThousand;
      Pnl.TakedownDifference = pnLUnderWritingSpread.TakedownDifference;
      Pnl.ProjectedExpenseTotal = pnLUnderWritingSpread.ProjectedExpenseTotal;
      Pnl.ProjectedExpensePerThousand = pnLUnderWritingSpread.ProjectedExpensePerThousand;
      Pnl.ActualExpenseTotal = pnLUnderWritingSpread.ActualExpenseTotal;
      Pnl.ActualExpensePerThousand = pnLUnderWritingSpread.ActualExpensePerThousand;
      Pnl.ExpenseDifference = pnLUnderWritingSpread.ExpenseDifference;
      Pnl.ProjectedStructuringTotal = pnLUnderWritingSpread.ProjectedStructuringTotal;
      Pnl.ProjectedStructuringPerThousand = pnLUnderWritingSpread.ProjectedStructuringPerThousand;
      Pnl.ActualStructuringTotal = pnLUnderWritingSpread.ActualStructuringTotal;
      Pnl.ActualStructuringPerThousand = pnLUnderWritingSpread.ActualStructuringPerThousand;
      Pnl.StructuringDifference = pnLUnderWritingSpread.StructuringDifference;
      Pnl.ProjectedTotalGrossSpread = pnLUnderWritingSpread.ProjectedTotalGrossSpread;
      Pnl.ProjectedPerThousandGrossSpread = pnLUnderWritingSpread.ProjectedPerThousandGrossSpread;
      Pnl.ActualTotalGrossSpread = pnLUnderWritingSpread.ActualTotalGrossSpread;
      Pnl.ActualPerThousandGrossSpread = pnLUnderWritingSpread.ActualPerThousandGrossSpread;
      Pnl.DifferenceGrossSpread = pnLUnderWritingSpread.DifferenceGrossSpread;
    }

    private List<SeriesBO> GetIssueSeries(IDataReader reader)
    {
      List<SeriesBO> seriesBoList = new List<SeriesBO>();
      IRowMapper<SeriesBO> rowMapper = MapBuilder<SeriesBO>.MapAllProperties().Build();
      while (reader.Read())
        seriesBoList.Add(rowMapper.MapRow((IDataRecord) reader));
      return seriesBoList;
    }
  }
}
