﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.ManageContactRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IManageContactRepository))]
  public class ManageContactRepository : RepositoryBase, IManageContactRepository
  {
    private Dictionary<string, string> knownMappings;

    public ManageContactRepository(Dictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public long Save(
      ManageContact theManageContact,
      IEnumerable<PropertySetValue> MiscFieldsValueDetail)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_SaveManageContact]"))
      {
        this.db.AddInParameter(storedProcCommand, "@ContactID", DbType.Int64, (object) theManageContact.ContactID);
        this.db.AddInParameter(storedProcCommand, "@Type", DbType.String, (object) theManageContact.Type);
        this.db.AddInParameter(storedProcCommand, "@RefId", DbType.Int64, (object) theManageContact.RefId);
        this.db.AddInParameter(storedProcCommand, "@Initials", DbType.String, (object) theManageContact.Initials);
        this.db.AddInParameter(storedProcCommand, "@FirstName", DbType.String, (object) theManageContact.FirstName);
        this.db.AddInParameter(storedProcCommand, "@MiddleName", DbType.String, (object) theManageContact.MiddleName);
        this.db.AddInParameter(storedProcCommand, "@LastName", DbType.String, (object) theManageContact.LastName);
        this.db.AddInParameter(storedProcCommand, "@Suffix", DbType.String, (object) theManageContact.Suffix);
        this.db.AddInParameter(storedProcCommand, "@DisplayName", DbType.String, (object) theManageContact.DisplayName);
        this.db.AddInParameter(storedProcCommand, "@Address", DbType.String, (object) theManageContact.Address);
        this.db.AddInParameter(storedProcCommand, "@City", DbType.String, (object) theManageContact.City);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.String, theManageContact.State != "" ? (object) theManageContact.State : (object) (string) null);
        this.db.AddInParameter(storedProcCommand, "@Zip", DbType.String, (object) theManageContact.Zip);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) theManageContact.Title);
        this.db.AddInParameter(storedProcCommand, "@Department", DbType.String, (object) theManageContact.Department);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) theManageContact.Phone);
        this.db.AddInParameter(storedProcCommand, "@Mobile", DbType.String, (object) theManageContact.Mobile);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) theManageContact.Email);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) theManageContact.IsActive);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) DateTime.UtcNow);
        if (MiscFieldsValueDetail != null)
          this.db.AddInParameter(storedProcCommand, "@PropertySetValueTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<PropertySetValue>(MiscFieldsValueDetail.ToList<PropertySetValue>()));
        this.db.AddOutParameter(storedProcCommand, "@OutContactID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutContactID"));
      }
    }

    public void ImportContact(List<ManageContact> theManageContact)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_ImportManageContact"))
      {
        this.db.AddInParameter(storedProcCommand, "@ManageContactTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<ManageContact>(theManageContact.ToList<ManageContact>()));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public ManageContact FetchByKey(long ContactID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchManageContactByKey"))
      {
        ManageContact manageContact = new ManageContact();
        this.db.AddInParameter(storedProcCommand, "@ContactID", DbType.Int64, (object) ContactID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<ManageContact>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : manageContact;
      }
    }

    public IEnumerable<ManageContact> FetchAll()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchManageContact"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<ManageContact> mapper = MapBuilder<ManageContact>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<ManageContact>) null;
        }
      }
    }

    public IDataReader FetchFullLegalNames(string FullName, string Type)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchClienAndPartnerNamesAutoComplete"))
      {
        this.db.AddInParameter(storedProcCommand, "@FullName", DbType.String, (object) RepositoryBase.EscapeForLike(FullName));
        this.db.AddInParameter(storedProcCommand, "@Type", DbType.String, (object) Type);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
