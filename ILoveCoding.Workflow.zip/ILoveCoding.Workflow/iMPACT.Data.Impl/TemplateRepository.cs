﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.TemplateRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ITemplateRepository))]
  public class TemplateRepository : RepositoryBase, ITemplateRepository
  {
    public long Save(Template theTemplate, long CopyTemplateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveTemplate"))
      {
        this.db.AddInParameter(storedProcCommand, "@TemplateID", DbType.Int64, (object) theTemplate.TemplateID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) theTemplate.EntityID);
        this.db.AddInParameter(storedProcCommand, "@WithEffectFrom", DbType.DateTime, (object) theTemplate.WithEffectFrom);
        this.db.AddInParameter(storedProcCommand, "@TemplateName", DbType.String, (object) theTemplate.TemplateName);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedDate", DbType.DateTime, (object) DateTime.Now);
        this.db.AddInParameter(storedProcCommand, "@ModeifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedDate", DbType.DateTime, (object) DateTime.Now);
        this.db.AddInParameter(storedProcCommand, "@CopyTemplateID", DbType.Int64, (object) CopyTemplateID);
        this.db.AddOutParameter(storedProcCommand, "@OutTemplateID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutTemplateID"));
      }
    }

    public IEnumerable<Template> FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllTemplate"))
      {
        List<Template> templateList = new List<Template>();
        this.db.AddInParameter(storedProcCommand, "@TemplateID", DbType.Int32, (object) null);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Template> rowMapper = MapBuilder<Template>.MapAllProperties().Build();
          while (dataReader.Read())
            templateList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<Template>) templateList;
      }
    }

    public IEnumerable<TemplateField> FetchByTemplateID(long templateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchTemplateFieldsByTemplateID"))
      {
        List<TemplateField> templateFieldList = new List<TemplateField>();
        this.db.AddInParameter(storedProcCommand, "@TemplateID", DbType.Int32, (object) templateID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<TemplateField> rowMapper = MapBuilder<TemplateField>.MapAllProperties().Build();
          while (dataReader.Read())
            templateFieldList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<TemplateField>) templateFieldList;
      }
    }

    public IEnumerable<TemplateField> FetchAllTemplateFields()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchTemplateFieldsByTemplateID"))
      {
        List<TemplateField> templateFieldList = new List<TemplateField>();
        this.db.AddInParameter(storedProcCommand, "@TemplateID", DbType.Int32, (object) null);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<TemplateField> rowMapper = MapBuilder<TemplateField>.MapAllProperties().Build();
          while (dataReader.Read())
            templateFieldList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<TemplateField>) templateFieldList;
      }
    }

    public void SaveTemplateFields(List<TemplateField> templateFields)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveTemplateFields"))
      {
        this.db.AddInParameter(storedProcCommand, "@TemplateFieldTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<TemplateField>(templateFields));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
