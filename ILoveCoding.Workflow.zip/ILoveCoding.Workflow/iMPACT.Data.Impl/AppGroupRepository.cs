﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AppGroupRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAppGroupRepository))]
  public class AppGroupRepository : RepositoryBase, IAppGroupRepository
  {
    public string Save(AppGroup appGroup)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveAppGroup"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppGroupID", DbType.Int32, (object) appGroup.GroupID);
        this.db.AddInParameter(storedProcCommand, "@AppGroupName", DbType.String, (object) appGroup.Name);
        this.db.AddInParameter(storedProcCommand, "@PrincipalID", DbType.Int32, (object) appGroup.PrincipalID);
        this.db.AddOutParameter(storedProcCommand, "@ResultMessage", DbType.String, 1000);
        this.db.ExecuteNonQuery(storedProcCommand);
        return this.db.GetParameterValue(storedProcCommand, "@ResultMessage").ToString();
      }
    }
  }
}
