﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.MergInfoReportRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using System;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IMergInfoReportRepository))]
  public class MergInfoReportRepository : RepositoryBase, IMergInfoReportRepository
  {
    public IDataReader FetchMergInfoReportData(
      DateTime fromDate,
      DateTime toDate,
      long? leadBankerEmpID,
      long? supervisoryPrincipalEmpID,
      string ExemtionType,
      int IsPrimary,
      Ordering[] order,
      int pageSize,
      int pageNumber)
    {
      string str1 = "Issuer";
      string str2 = "Asc";
      if (order.Length != 0)
      {
        str1 = order[0].PropertyName;
        str2 = order[0].Direction.ToString();
      }
      long? nullable1 = leadBankerEmpID;
      long num1 = 0;
      if ((nullable1.GetValueOrDefault() == num1 ? (nullable1.HasValue ? 1 : 0) : 0) != 0)
        leadBankerEmpID = new long?();
      long? nullable2 = supervisoryPrincipalEmpID;
      long num2 = 0;
      if ((nullable2.GetValueOrDefault() == num2 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
        supervisoryPrincipalEmpID = new long?();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_GetMergInfoReport"))
      {
        this.db.AddInParameter(storedProcCommand, "@FromDate", DbType.DateTime, (object) fromDate);
        this.db.AddInParameter(storedProcCommand, "@ToDate", DbType.DateTime, (object) toDate);
        this.db.AddInParameter(storedProcCommand, "@LeadBanker", DbType.Int64, (object) leadBankerEmpID);
        this.db.AddInParameter(storedProcCommand, "@SupervisoryPrincipal", DbType.Int64, (object) supervisoryPrincipalEmpID);
        this.db.AddInParameter(storedProcCommand, "@ExemptionType", DbType.String, (object) ExemtionType);
        this.db.AddInParameter(storedProcCommand, "@IsPrimary", DbType.Int16, (object) IsPrimary);
        this.db.AddInParameter(storedProcCommand, "@Skip", DbType.String, (object) (pageSize + 1));
        this.db.AddInParameter(storedProcCommand, "@Take", DbType.String, (object) (pageNumber + pageSize));
        this.db.AddInParameter(storedProcCommand, "@OrderBy", DbType.String, (object) str1);
        this.db.AddInParameter(storedProcCommand, "@OrderDir", DbType.String, (object) str2);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
