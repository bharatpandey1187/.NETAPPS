﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.GoodFaithViewsRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IGoodFaithViewsRepository))]
  public class GoodFaithViewsRepository : RepositoryBase, IGoodFaithViewsRepository
  {
    public IDataReader FetchIssuesForBankerView(
      DateTime? fromDate,
      DateTime? toDate,
      int typeOfOffering,
      string state,
      bool isOpsView)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_GoodFaithInfoSearch"))
      {
        if (fromDate.HasValue)
          this.db.AddInParameter(storedProcCommand, "@StartDate", DbType.DateTime, (object) fromDate);
        else
          this.db.AddInParameter(storedProcCommand, "@StartDate", DbType.DateTime, (object) DBNull.Value);
        if (toDate.HasValue)
          this.db.AddInParameter(storedProcCommand, "@EndDate", DbType.DateTime, (object) toDate);
        else
          this.db.AddInParameter(storedProcCommand, "@EndDate", DbType.DateTime, (object) DBNull.Value);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.String, (object) state);
        this.db.AddInParameter(storedProcCommand, "@TypeOfOffering", DbType.Int16, (object) typeOfOffering);
        this.db.AddInParameter(storedProcCommand, "@IsOpsView", DbType.Boolean, (object) isOpsView);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchGoodFaithEmailDetails(string state)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_GoodFaithEmailDetails"))
      {
        this.db.AddInParameter(storedProcCommand, "@State", DbType.String, (object) state);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void SaveOperationsViewData(DataTable dtOps)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveGoodFaithViewtems"))
      {
        this.db.AddInParameter(storedProcCommand, "@GoodFaithViewItems_TVP", SqlDbType.Structured, (object) dtOps);
        this.db.AddInParameter(storedProcCommand, "@User", SqlDbType.VarChar, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailDate", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void SaveBankerViewAuditTrail(string issues, string content)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_updateBankerViewAuditTrail"))
      {
        this.db.AddInParameter(storedProcCommand, "@Issues", SqlDbType.VarChar, (object) issues);
        this.db.AddInParameter(storedProcCommand, "@Content", SqlDbType.VarChar, (object) content);
        this.db.AddInParameter(storedProcCommand, "@User", SqlDbType.VarChar, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailDate", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
