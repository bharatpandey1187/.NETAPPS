﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.IssuePricingRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IIssuePricingRepository))]
  public class IssuePricingRepository : RepositoryBase, IIssuePricingRepository
  {
    public void SaveIssuePricings(long appTransactionID, DataTable pricing, DataTable cusip)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveIssuePricings"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Double, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@IssuePricing_TVP", SqlDbType.Structured, (object) pricing);
        this.db.AddInParameter(storedProcCommand, "@CUSIP_TVP", SqlDbType.Structured, (object) cusip);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public string CheckDuplicateCusip(long appTransactionID, DataTable cusip)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CheckDuplicateCusipInPricing"))
      {
        this.db.AddInParameter(storedProcCommand, "@CUSIP_TVP", SqlDbType.Structured, (object) cusip);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Double, (object) appTransactionID);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.String, 250);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToString(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public IDataReader FetchIssuePricings(long appTransactionID, bool IsCopyIssue = false)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssuePricingDetails"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Double, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@IsCopyIssue", DbType.Double, (object) IsCopyIssue);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void SavePricingStatus(long pricingStatus, long appTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SavePricingStatus"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@PricingStatus", DbType.Int64, (object) pricingStatus);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IDataReader FetchIssueStatusByAppTransactionID(long appTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssueStatusByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
