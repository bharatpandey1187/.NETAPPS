﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AppTransactionDocSetRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAppTransactionDocSetRepository))]
  public class AppTransactionDocSetRepository : RepositoryBase, IAppTransactionDocSetRepository
  {
    private List<DocSetPermission> OpptyRepositoryPermissionList;
    private List<DocSetPermission> RFPRepositoryPermissionList;
    private List<DocSetPermission> IssueRepositoryPermissionList;

    public void Save(AppTransactionDocSet theAppTransactionDocSet)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveAppTransactionDocSet"))
      {
        this.db.AddInParameter(storedProcCommand, "@DocSetID", DbType.Int64, (object) theAppTransactionDocSet.DocSetID);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theAppTransactionDocSet.EntityID);
        this.db.AddInParameter(storedProcCommand, "@DocSetType", DbType.Int64, (object) theAppTransactionDocSet.EntityDocSetTypeID);
        this.db.AddInParameter(storedProcCommand, "@URL", DbType.String, (object) theAppTransactionDocSet.URL);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public bool IsDocSetCreated(AppTransactionDocSet theAppTransactionDocSet)
    {
      bool flag = false;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_IsDocSetCreated"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theAppTransactionDocSet.EntityID);
        this.db.AddInParameter(storedProcCommand, "@DocSetType", DbType.Int64, (object) theAppTransactionDocSet.EntityDocSetTypeID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            flag = dataReader.GetBoolean(dataReader.GetOrdinal("Exist"));
            theAppTransactionDocSet.DocSetID = (int) dataReader.GetInt64(dataReader.GetOrdinal("DocSetID"));
          }
        }
      }
      return flag;
    }

    public IEnumerable<AppTransactionDocSet> FetchByKey(
      long entityTypeID,
      long currentId,
      long userId = 0)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAppTransactionDocSetByKey"))
      {
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(cmd, "@EntityTypeID", DbType.Int64, (object) entityTypeID);
        this.db.AddInParameter(cmd, "@AppTransactionId", DbType.Int64, (object) currentId);
        this.db.AddInParameter(cmd, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<AppTransactionDocSet> mapper = MapBuilder<AppTransactionDocSet>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppTransactionDocSet>) null;
        }
      }
    }

    public IEnumerable<AppTransactionDocSet> FetchByEntityTypeID(
      long entityTypeID,
      long currentId,
      long userId = 0)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAppTransactionDocSetByEntityTypeID"))
      {
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(cmd, "@EntityTypeID", DbType.Int64, (object) entityTypeID);
        this.db.AddInParameter(cmd, "@AppTransactionId", DbType.Int64, (object) currentId);
        this.db.AddInParameter(cmd, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<AppTransactionDocSet> mapper = MapBuilder<AppTransactionDocSet>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppTransactionDocSet>) null;
        }
      }
    }

    public string FetchLibraryURLByEntityTypeID(long entityTypeID)
    {
      string empty = string.Empty;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityTypeDocumentLibraryLocation"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityTypeID", DbType.Int64, (object) entityTypeID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            empty = Convert.ToString(dataReader["Location"]);
        }
      }
      return empty;
    }

    public List<AppTransactionDocSet> FetchByAppTransactionID(
      long appTransactionID)
    {
      List<AppTransactionDocSet> transactionDocSetList = new List<AppTransactionDocSet>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAppTransactionDocSetByAppTransactionId"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            transactionDocSetList.Add(new AppTransactionDocSet()
            {
              DocSetID = Convert.ToInt32(dataReader["DocSetID"]),
              EntityID = Convert.ToInt64(dataReader["EntityID"]),
              EntityDocSetTypeID = new long?(Convert.ToInt64(dataReader["EntityDocSetTypeID"])),
              URL = Convert.ToString(dataReader["URL"])
            });
        }
      }
      return transactionDocSetList;
    }

    public List<DocSetDocument> FetchDocSetDocumentByAppTransactionID(
      long appTransactionID)
    {
      List<DocSetDocument> docSetDocumentList = new List<DocSetDocument>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllAppTransactionDocSetDocument"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            docSetDocumentList.Add(new DocSetDocument()
            {
              AppTransactionDocSetDocumentID = Convert.ToInt64(dataReader["AppTransactionDocSetDocumentID"]),
              AppTransactionDocSetID = Convert.ToInt64(dataReader["AppTransactionDocSetID"]),
              AppTransactionID = Convert.ToInt64(dataReader["AppTransactionID"]),
              DocSetName = Convert.ToInt64(dataReader["DocSetName"]),
              DocSetID = Convert.ToInt64(dataReader["DocSetID"]),
              DocSetURL = Convert.ToString(dataReader["DocSetURL"]),
              DocumentID = Convert.ToString(dataReader["DocumentID"]),
              DocumentURL = Convert.ToString(dataReader["DocumentURL"]),
              DocumentListID = Convert.ToString(dataReader["DocumentListID"]),
              UIVersionLabel = Convert.ToString(dataReader["UIVersionLabel"]),
              TotalVersion = dataReader["TotalVersion"] is DBNull ? new long?() : new long?(Convert.ToInt64(dataReader["TotalVersion"])),
              CheckoutType = Convert.ToString(dataReader["CheckoutType"]),
              LastModifiedBy = Convert.ToString(dataReader["LastModifiedBy"]),
              LastModifiedOn = Convert.ToDateTime(dataReader["LastModifiedOn"]),
              CheckedoutBy = Convert.ToString(dataReader["CheckedoutBy"]),
              CheckedoutDate = dataReader["CheckedoutDate"] is DBNull ? new DateTime?() : new DateTime?(Convert.ToDateTime(dataReader["CheckedoutDate"])),
              CheckedOutExpires = dataReader["CheckedOutExpires"] is DBNull ? new DateTime?() : new DateTime?(Convert.ToDateTime(dataReader["CheckedOutExpires"])),
              StorageKey = Convert.ToString(dataReader["StorageKey"]),
              EntityType = Convert.ToInt64(dataReader["EntityType"]),
              CheckoutDocumentID = Convert.ToString(dataReader["CheckoutDocumentID"]),
              DocumentName = Convert.ToString(dataReader["DocumentName"]),
              Category = Convert.ToString(dataReader["Category"]),
              DocType = Convert.ToString(dataReader["DocType"]),
              TypeOtherDesc = Convert.ToString(dataReader["TypeOtherDesc"]),
              Tags = Convert.ToString(dataReader["Tags"])
            });
        }
      }
      return docSetDocumentList;
    }

    public List<DocSetPermission> FetchDocSetPermissionByTransactionID(
      long currentId)
    {
      List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPermissionsOnTransaction"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) currentId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            docSetPermissionList.Add(new DocSetPermission()
            {
              Permission = "view",
              PrincipalId = dataReader.GetInt32(dataReader.GetOrdinal("Principal")),
              PermissionId = (int) dataReader.GetInt64(dataReader.GetOrdinal("PermissionID"))
            });
        }
      }
      return docSetPermissionList;
    }

    public IEnumerable<AppTransactionDocSet> FetchAll()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAllAppTransactionDocSet"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<AppTransactionDocSet> mapper = MapBuilder<AppTransactionDocSet>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppTransactionDocSet>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteAppTransactionDocSetByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionDocSetId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public List<DocSetPermission> FetchOpptyRepositoryPermissionsByAppTransID(
      long appTransID,
      int entityTypeID)
    {
      if (this.OpptyRepositoryPermissionList == null)
        this.OpptyRepositoryPermissionList = this.FetchRepositoryPermissionByTransactionID(appTransID, entityTypeID);
      return this.OpptyRepositoryPermissionList;
    }

    public List<DocSetPermission> FetchRFPRepositoryPermissionsByAppTransID(
      long appTransID,
      int entityTypeID)
    {
      if (this.RFPRepositoryPermissionList == null)
        this.RFPRepositoryPermissionList = this.FetchRepositoryPermissionByTransactionID(appTransID, entityTypeID);
      return this.RFPRepositoryPermissionList;
    }

    public List<DocSetPermission> FetchIssueRepositoryPermissionsByAppTransID(
      long appTransID,
      int entityTypeID)
    {
      if (this.IssueRepositoryPermissionList == null)
        this.IssueRepositoryPermissionList = this.FetchRepositoryPermissionByTransactionID(appTransID, entityTypeID);
      return this.IssueRepositoryPermissionList;
    }

    private List<DocSetPermission> FetchRepositoryPermissionByTransactionID(
      long appTransID,
      int entityTypeID)
    {
      List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchRepositoryPermissions"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransID);
        this.db.AddInParameter(storedProcCommand, "@EntityTypeID", DbType.Int32, (object) entityTypeID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          int? nullable1 = new int?();
          int? nullable2 = new int?();
          int? nullable3 = new int?();
          int? nullable4 = new int?();
          try
          {
            nullable1 = new int?(dataReader.GetOrdinal("Principal"));
          }
          catch (IndexOutOfRangeException ex)
          {
          }
          try
          {
            nullable2 = new int?(dataReader.GetOrdinal("Permission"));
          }
          catch (IndexOutOfRangeException ex)
          {
          }
          try
          {
            nullable3 = new int?(dataReader.GetOrdinal("RepositoryName"));
          }
          catch (IndexOutOfRangeException ex)
          {
          }
          try
          {
            nullable4 = new int?(dataReader.GetOrdinal("RepositoryID"));
          }
          catch (IndexOutOfRangeException ex)
          {
          }
          while (dataReader.Read())
          {
            DocSetPermission docSetPermission = new DocSetPermission();
            if (nullable2.HasValue)
              docSetPermission.Permission = dataReader.GetString(nullable2.Value);
            if (nullable1.HasValue)
              docSetPermission.PrincipalId = dataReader.GetInt32(nullable1.Value);
            if (nullable3.HasValue)
              docSetPermission.RepositoryName = dataReader.GetString(nullable3.Value);
            if (nullable4.HasValue)
              docSetPermission.RepositoryID = dataReader.GetInt64(nullable4.Value);
            docSetPermissionList.Add(docSetPermission);
          }
        }
      }
      return docSetPermissionList;
    }

    public IDataReader FetchUploadDropDowns(long appId, int entityId)
    {
      int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchUploadDropDowns"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appId);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchStateIndependentUploadDropDowns(long appId, int entityId)
    {
      int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchStateIndependentUploadDropDowns"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appId);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void SaveDocumentSetQueue(List<long> appTransactionIDList)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveDocumentSetQueue"))
      {
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionID", SqlDbType.Structured, (object) this.GetDataTableFromAppTransactionList(appTransactionIDList));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    private DataTable GetDataTableFromAppTransactionList(List<long> appTransactionIDList)
    {
      DataTable dataTable = new DataTable();
      DataColumn column = new DataColumn("ID", typeof (long));
      dataTable.Columns.Add(column);
      foreach (long appTransactionId in appTransactionIDList)
      {
        DataRow row = dataTable.NewRow();
        row["ID"] = (object) appTransactionId;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }
  }
}
