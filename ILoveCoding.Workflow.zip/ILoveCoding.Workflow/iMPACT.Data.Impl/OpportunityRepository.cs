﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.OpportunityRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IOpportunityRepository))]
  public class OpportunityRepository : RepositoryBase, IOpportunityRepository, IQuery
  {
    private Dictionary<string, string> knownMappings;
    private static readonly List<SearchSQLField> knownProjection = new List<SearchSQLField>()
    {
      new SearchSQLField("OpportunityNbr"),
      new SearchSQLField("OpportunityName"),
      new SearchSQLField("OpportunityStatus"),
      new SearchSQLField("ReviewStatus"),
      new SearchSQLField("JobNumber"),
      new SearchSQLField("State"),
      new SearchSQLField("Issuer"),
      new SearchSQLField("Borrower"),
      new SearchSQLField("Guarantor"),
      new SearchSQLField("OpportunityType"),
      new SearchSQLField("ParAmount"),
      new SearchSQLField("TransactionType"),
      new SearchSQLField("SecurityType"),
      new SearchSQLField("MaterialType"),
      new SearchSQLField("BankQualified"),
      new SearchSQLField("AMTTaxable"),
      new SearchSQLField("FedTaxable"),
      new SearchSQLField("StateTaxable"),
      new SearchSQLField("FAEngaged"),
      new SearchSQLField("ApprovedDerivativeMarketer"),
      new SearchSQLField("ExpectedFirmRole"),
      new SearchSQLField("AssignedFirmRole"),
      new SearchSQLField("ExpectedFirmLiabilityPerc"),
      new SearchSQLField("LeadBanker"),
      new SearchSQLField("Banker"),
      new SearchSQLField("Quant"),
      new SearchSQLField("SupervisoryPrincipal"),
      new SearchSQLField("FinancialAdvisor"),
      new SearchSQLField("EscrowVerificationAgent"),
      new SearchSQLField("EscrowSecuritiesProvider"),
      new SearchSQLField("EscrowAgentForRefundedBonds"),
      new SearchSQLField("PayingAgent"),
      new SearchSQLField("RemarketingAgent"),
      new SearchSQLField("Trustee"),
      new SearchSQLField("OtherAdvisorAgents"),
      new SearchSQLField("BondCounsel"),
      new SearchSQLField("UnderwriterCounsel"),
      new SearchSQLField("DisclosureCounsel"),
      new SearchSQLField("IssuerCounsel"),
      new SearchSQLField("BorrowerCounsel"),
      new SearchSQLField("OtherCounsels"),
      new SearchSQLField("RFPMAExemption"),
      new SearchSQLField("RFPMAExemptionDate"),
      new SearchSQLField("RFPMAExemptionExpirationDate"),
      new SearchSQLField("UWMAExemption"),
      new SearchSQLField("UWMAExemptionDate"),
      new SearchSQLField("UWMAExemptionExpirationDate"),
      new SearchSQLField("IRMAMAExemption"),
      new SearchSQLField("IRMAMAExemptionDate"),
      new SearchSQLField("IRMAMAExemptionExpirationDate"),
      new SearchSQLField("NoneMAExemption"),
      new SearchSQLField("NoneMAExemptionStartDate"),
      new SearchSQLField("NoneMAExemptionExpirationDate"),
      new SearchSQLField("MoodyRating"),
      new SearchSQLField("SPRating"),
      new SearchSQLField("KrollRating"),
      new SearchSQLField("FitchRating"),
      new SearchSQLField("CreateDate", "CreatedOn"),
      new SearchSQLField("CreatedBy"),
      new SearchSQLField("ResponseDueDate", "ResponseDueDateTimezone"),
      new SearchSQLField("SaleDate"),
      new SearchSQLField("CloseDate"),
      new SearchSQLField("ClientLastContactedDate"),
      new SearchSQLField("G17RoleLetter"),
      new SearchSQLField("G17RoleLetterSentDate"),
      new SearchSQLField("G17RoleLetterAckDate"),
      new SearchSQLField("G17ConflictLetter"),
      new SearchSQLField("G17ConflictLetterSentDate"),
      new SearchSQLField("G17ConflictLetterAckDate"),
      new SearchSQLField("G17RoleDisclosureLetter"),
      new SearchSQLField("G17RoleDisclosureLetterSentDate"),
      new SearchSQLField("G17RoleDisclosureLetterAckDate"),
      new SearchSQLField("G17StructureLetter"),
      new SearchSQLField("G17StructureLetterSentDate"),
      new SearchSQLField("G17StructureLetterAckDate"),
      new SearchSQLField("GrossSpread"),
      new SearchSQLField("EstGrossRev"),
      new SearchSQLField("TakeDownValue"),
      new SearchSQLField("SoleManager"),
      new SearchSQLField("SeniorManager"),
      new SearchSQLField("JointSeniorMgrBookRunning"),
      new SearchSQLField("JointSeniorMgrNonBookRunning"),
      new SearchSQLField("CoSeniorMgr"),
      new SearchSQLField("CoManager"),
      new SearchSQLField("SellingGroupMember"),
      new SearchSQLField("OtherSyndicateMembers"),
      new SearchSQLField("WinningSoleManager"),
      new SearchSQLField("WinningSeniorManager"),
      new SearchSQLField("WinningJointSeniorMgrBookRunning"),
      new SearchSQLField("WinningJointSeniorMgrNonBookRunning"),
      new SearchSQLField("WinningCoSeniorMgr"),
      new SearchSQLField("WinningCoManager"),
      new SearchSQLField("WinningSellingGroupMember"),
      new SearchSQLField("OtherWinningSyndicateMembers"),
      new SearchSQLField("RFPFees"),
      new SearchSQLField("ExpectedPricingDate"),
      new SearchSQLField("ProposedManagementFee"),
      new SearchSQLField("ProposedUnderwriterExpenses"),
      new SearchSQLField("FirmMgmtFee"),
      new SearchSQLField("FedTaxName"),
      new SearchSQLField("DealType"),
      new SearchSQLField("Market"),
      new SearchSQLField("Notes"),
      new SearchSQLField("CepProviderName"),
      new SearchSQLField("RFPType"),
      new SearchSQLField("AdditionalRFPDetails"),
      new SearchSQLField("SDCCreditPerc"),
      new SearchSQLField("RateType"),
      new SearchSQLField("AdditionalInformationforCommitmentCommittee"),
      new SearchSQLField("OpportunityLeadManager"),
      new SearchSQLField("OpportunityNonLeadManager")
    };

    [Dependency]
    public ISearchSettingRepository SearchSettingRepository { get; set; }

    public OpportunityRepository(Dictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public long Save(
      Opportunity opportunity,
      Dictionary<int, int> history,
      List<Opportunity.OpportunityFromStateToState> fromToStateList,
      List<Opportunity.OpportunityFromStateToState> stateAuditTrailList)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveOpportunity"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) opportunity.OpportunityDetail.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@OpportunityNbr", DbType.String, (object) opportunity.OpportunityDetail.OpportunityNbr);
        this.db.AddInParameter(storedProcCommand, "@OpportunityPowerID", DbType.String, (object) opportunity.OpportunityDetail.OpportunityPowerID);
        this.db.AddInParameter(storedProcCommand, "@OpportunityName", DbType.String, (object) opportunity.OpportunityDetail.OpportunityName);
        this.db.AddInParameter(storedProcCommand, "@Issuer", DbType.Int64, (object) opportunity.OpportunityDetail.IssuerID);
        this.db.AddInParameter(storedProcCommand, "@Borrower", DbType.Int64, (object) opportunity.OpportunityDetail.BorrowerID);
        this.db.AddInParameter(storedProcCommand, "@Guarantor", DbType.Int64, (object) opportunity.OpportunityDetail.GuarantorID);
        this.db.AddInParameter(storedProcCommand, "@OpportunityType", DbType.Int64, (object) opportunity.OpportunityDetail.OpportunityType);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.Int64, (object) opportunity.OpportunityDetail.State);
        this.db.AddInParameter(storedProcCommand, "@County", DbType.String, (object) opportunity.OpportunityDetail.County);
        this.db.AddInParameter(storedProcCommand, "@IsNewOpportunity", DbType.Boolean, (object) opportunity.OpportunityDetail.IsNewOpportunity);
        this.db.AddInParameter(storedProcCommand, "@MaterialType", DbType.Int64, (object) opportunity.OpportunityDetail.MaterialType);
        this.db.AddInParameter(storedProcCommand, "@HybridSolutionIndicator", DbType.Boolean, (object) opportunity.OpportunityDetail.HybridSolutionIndicator);
        this.db.AddInParameter(storedProcCommand, "@DualProposalProposed", DbType.Boolean, (object) opportunity.OpportunityDetail.DualProposalProposed);
        this.db.AddInParameter(storedProcCommand, "@InformationalMERGRequired", DbType.Boolean, (object) opportunity.OpportunityDetail.InformationalMERGRequired);
        this.db.AddInParameter(storedProcCommand, "@ApprovedDerivativeMarketer", DbType.Int64, (object) opportunity.OpportunityDetail.ApprovedDerivativeMarketer);
        if (opportunity.OpportunityDetail.MAExemptionDetails != null)
          this.db.AddInParameter(storedProcCommand, "@MAExemptionDetailTableType", SqlDbType.Structured, (object) this.GetMAExemptionDetailDataTable(opportunity.OpportunityDetail.MAExemptionDetails));
        this.db.AddInParameter(storedProcCommand, "@ParAmount", DbType.Decimal, (object) opportunity.OpportunityDetail.ParAmount);
        this.db.AddInParameter(storedProcCommand, "@FirmRole", DbType.Int64, (object) opportunity.OpportunityDetail.FirmRole);
        this.db.AddInParameter(storedProcCommand, "@FirmLiabilityPerc", DbType.Decimal, (object) opportunity.OpportunityDetail.FirmLiabilityPerc);
        this.db.AddInParameter(storedProcCommand, "@AssignedFirmRole", DbType.Int64, (object) opportunity.OpportunityDetail.AssignedFirmRole);
        this.db.AddInParameter(storedProcCommand, "@AssignedFirmLiability", DbType.Decimal, (object) opportunity.OpportunityDetail.AssignedFirmLiability);
        this.db.AddInParameter(storedProcCommand, "@Purpose", DbType.Int64, (object) opportunity.OpportunityDetail.Purpose);
        this.db.AddInParameter(storedProcCommand, "@TransactionType", DbType.Int64, (object) opportunity.OpportunityDetail.TransactionType);
        this.db.AddInParameter(storedProcCommand, "@SecurityType", DbType.Int64, (object) opportunity.OpportunityDetail.SecurityType);
        this.db.AddInParameter(storedProcCommand, "@InsuranceProvider", DbType.Int64, (object) opportunity.OpportunityDetail.InsuranceProvider);
        this.db.AddInParameter(storedProcCommand, "@CreditProvider", DbType.Int64, (object) opportunity.OpportunityDetail.CepProviderID);
        this.db.AddInParameter(storedProcCommand, "@FedTaxable", DbType.String, (object) opportunity.OpportunityDetail.FedTaxable);
        this.db.AddInParameter(storedProcCommand, "@FedTax", DbType.Int64, (object) opportunity.OpportunityDetail.FedTax);
        this.db.AddInParameter(storedProcCommand, "@StateTaxable", DbType.String, (object) opportunity.OpportunityDetail.StateTaxable);
        this.db.AddInParameter(storedProcCommand, "@AMTTaxable", DbType.String, (object) opportunity.OpportunityDetail.AMTTaxable);
        this.db.AddInParameter(storedProcCommand, "@BankQualified", DbType.Boolean, (object) opportunity.OpportunityDetail.BankQualified);
        this.db.AddInParameter(storedProcCommand, "@FAEngaged", DbType.Boolean, (object) opportunity.OpportunityDetail.FAEngaged);
        this.db.AddInParameter(storedProcCommand, "@CMRelationship", DbType.Boolean, (object) opportunity.OpportunityDetail.CMRelationship);
        this.db.AddInParameter(storedProcCommand, "@BankRelationship", DbType.Boolean, (object) opportunity.OpportunityDetail.BankRelationship);
        this.db.AddInParameter(storedProcCommand, "@ConflictOfInterest", DbType.Boolean, (object) opportunity.OpportunityDetail.ConflictOfInterest);
        this.db.AddInParameter(storedProcCommand, "@DerivativesStrategy", DbType.Boolean, (object) opportunity.OpportunityDetail.DerivativesStrategy);
        this.db.AddInParameter(storedProcCommand, "@Market", DbType.Int64, (object) opportunity.OpportunityDetail.Market);
        this.db.AddInParameter(storedProcCommand, "@RfpType", DbType.Int64, (object) opportunity.OpportunityDetail.RFPType);
        this.db.AddInParameter(storedProcCommand, "@RateType", DbType.Int64, (object) opportunity.OpportunityDetail.RateType);
        this.db.AddInParameter(storedProcCommand, "@GrossSpread", DbType.Decimal, (object) opportunity.OpportunityDetail.GrossSpread);
        this.db.AddInParameter(storedProcCommand, "@EstGrossRev", DbType.Decimal, (object) opportunity.OpportunityDetail.EstGrossRev);
        this.db.AddInParameter(storedProcCommand, "@DateHired", DbType.DateTime, (object) opportunity.OpportunityDetail.DateHired);
        this.db.AddInParameter(storedProcCommand, "@SaleDate", DbType.DateTime, (object) opportunity.OpportunityDetail.SaleDate);
        this.db.AddInParameter(storedProcCommand, "@FinancingDate", DbType.DateTime, (object) opportunity.OpportunityDetail.FinancingDate);
        this.db.AddInParameter(storedProcCommand, "@CloseDate", DbType.DateTime, (object) opportunity.OpportunityDetail.CloseDate);
        this.db.AddInParameter(storedProcCommand, "@G17SentDate", DbType.DateTime, (object) opportunity.OpportunityDetail.G17SentDate);
        this.db.AddInParameter(storedProcCommand, "@G17AckDate", DbType.DateTime, (object) opportunity.OpportunityDetail.G17AckDate);
        this.db.AddInParameter(storedProcCommand, "@SupervisoryPrincipalReviewDate", DbType.DateTime, (object) opportunity.OpportunityDetail.SupervisoryPrincipalReviewDate);
        this.db.AddInParameter(storedProcCommand, "@SupervisoryPrincipalApprovalDate", DbType.DateTime, (object) opportunity.OpportunityDetail.SupervisoryPrincipalApprovalDate);
        this.db.AddInParameter(storedProcCommand, "@SupervisoryPrincipalApproverName", DbType.String, (object) opportunity.OpportunityDetail.SupervisoryPrincipalApproverName);
        this.db.AddInParameter(storedProcCommand, "@ClientLastContactedDate", DbType.DateTime, (object) opportunity.OpportunityDetail.ClientLastContactedDate);
        this.db.AddInParameter(storedProcCommand, "@AdditionalInformationForCommitmentCommittee", DbType.String, (object) opportunity.OpportunityDetail.AdditionalInformationForCommitmentCommittee);
        this.db.AddInParameter(storedProcCommand, "@AdditionalRFPDetails", DbType.String, (object) opportunity.OpportunityDetail.AdditionalRFPDetails);
        this.db.AddInParameter(storedProcCommand, "@SentTo3Firms", DbType.Boolean, (object) opportunity.OpportunityDetail.SentTo3Firms);
        this.db.AddInParameter(storedProcCommand, "@MoodyRatingLT", DbType.Int64, (object) opportunity.OpportunityDetail.MoodyRatingLT);
        this.db.AddInParameter(storedProcCommand, "@SPRatingLT", DbType.Int64, (object) opportunity.OpportunityDetail.SPRatingLT);
        this.db.AddInParameter(storedProcCommand, "@FitchRatingLT", DbType.Int64, (object) opportunity.OpportunityDetail.FitchRatingLT);
        this.db.AddInParameter(storedProcCommand, "@KrollRatingLT", DbType.Int64, (object) opportunity.OpportunityDetail.KrollRatingLT);
        this.db.AddInParameter(storedProcCommand, "@Notes", DbType.String, (object) opportunity.OpportunityDetail.Notes);
        this.db.AddInParameter(storedProcCommand, "@ReviewComment", DbType.String, (object) opportunity.OpportunityDetail.ReviewComments);
        this.db.AddInParameter(storedProcCommand, "@ActionPerformedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedByWithEmail", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedByWithEmail", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddInParameter(storedProcCommand, "@DocumentLibraryURL", DbType.String, (object) opportunity.OpportunityDetail.DocumentLibraryURL);
        this.db.AddInParameter(storedProcCommand, "@GeneralCategorySpecific", DbType.Int64, (object) opportunity.OpportunityDetail.GeneralCategorySpecific);
        if (opportunity.AppTransactionClientContacts != null)
          this.db.AddInParameter(storedProcCommand, "@AppTransactionClientContactTableType", SqlDbType.Structured, (object) this.GetAppTransactionClientContactDataTable(opportunity.AppTransactionClientContacts));
        if (opportunity.InternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerTableType", SqlDbType.Structured, (object) this.GetInternalPartnerDataTable(opportunity.InternalPartners));
        if (opportunity.InternalPartnerBankRMs != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerBankRMTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<InternalPartnerBankRM>(opportunity.InternalPartnerBankRMs));
        if (opportunity.ExternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@ExternalPartnerTableType", SqlDbType.Structured, (object) this.GetExternalPartnerDataTable(opportunity.ExternalPartners));
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) 21);
        this.db.AddInParameter(storedProcCommand, "@Version", DbType.Int32, (object) opportunity.OpportunityDetail.Version);
        this.db.AddInParameter(storedProcCommand, "@ProposedManagementFee ", DbType.Decimal, (object) opportunity.OpportunityDetail.ProposedManagementFee);
        this.db.AddInParameter(storedProcCommand, "@ProposedUnderwriterExpenses  ", DbType.Decimal, (object) opportunity.OpportunityDetail.ProposedUnderwriterExpenses);
        this.db.AddInParameter(storedProcCommand, "@FirmMgmtFee  ", DbType.Decimal, (object) opportunity.OpportunityDetail.FirmMgmtFee);
        DateTime? submittedToMergDate = opportunity.OpportunityDetail.SubmittedToMERGDate;
        if (submittedToMergDate.HasValue)
        {
          SqlDatabase db = this.db;
          DbCommand command = storedProcCommand;
          submittedToMergDate = opportunity.OpportunityDetail.SubmittedToMERGDate;
          // ISSUE: variable of a boxed type
          __Boxed<DateTime> local = (System.ValueType) submittedToMergDate.Value;
          db.AddInParameter(command, "@SubmittedToMERGDate", DbType.DateTime, (object) local);
        }
        else
          this.db.AddInParameter(storedProcCommand, "@SubmittedToMERGDate", DbType.DateTime, (object) DBNull.Value);
        DataTable dataTable1 = new DataTable();
        dataTable1.Columns.Add("AppTransactionID", typeof (long));
        dataTable1.Columns.Add("StateID", typeof (int));
        foreach (long opportunityStatu in opportunity.OpportunityDetail.OpportunityStatus)
        {
          DataRow row = dataTable1.NewRow();
          row["AppTransactionID"] = (object) opportunity.OpportunityDetail.AppTransactionID;
          row["StateID"] = (object) int.Parse(opportunityStatu.ToString());
          dataTable1.Rows.Add(row);
        }
        DataTable dataTable2 = new DataTable();
        dataTable2.Columns.Add("AppTransactionID", typeof (long));
        dataTable2.Columns.Add("ParentStateID", typeof (int));
        dataTable2.Columns.Add("StateID", typeof (int));
        if (history != null && history.Count > 0)
        {
          foreach (KeyValuePair<int, int> keyValuePair in history)
          {
            DataRow row = dataTable2.NewRow();
            row["AppTransactionID"] = (object) opportunity.OpportunityDetail.AppTransactionID;
            row["ParentStateID"] = (object) keyValuePair.Key;
            row["StateID"] = (object) keyValuePair.Value;
            dataTable2.Rows.Add(row);
          }
        }
        DataTable dataTable3 = new DataTable();
        dataTable3.Columns.Add("FromState", typeof (int));
        dataTable3.Columns.Add("ToState", typeof (int));
        foreach (Opportunity.OpportunityFromStateToState fromToState in fromToStateList)
        {
          DataRow row = dataTable3.NewRow();
          Opportunity.Status? fromState = fromToState.FromState;
          if (fromState.HasValue)
          {
            DataRow dataRow = row;
            fromState = fromToState.FromState;
            // ISSUE: variable of a boxed type
            __Boxed<int> local = (System.ValueType) (int) fromState.Value;
            dataRow["FromState"] = (object) local;
          }
          else
            row["FromState"] = (object) DBNull.Value;
          row["ToState"] = (object) (int) fromToState.ToState;
          dataTable3.Rows.Add(row);
        }
        DataTable dataTable4 = new DataTable();
        dataTable4.Columns.Add("FromState", typeof (int));
        dataTable4.Columns.Add("ToState", typeof (int));
        foreach (Opportunity.OpportunityFromStateToState stateAuditTrail in stateAuditTrailList)
        {
          DataRow row = dataTable4.NewRow();
          row["FromState"] = (object) (int) stateAuditTrail.FromState.Value;
          row["ToState"] = (object) (int) stateAuditTrail.ToState;
          dataTable4.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionState", SqlDbType.Structured, (object) dataTable1);
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionStateHistory", SqlDbType.Structured, (object) dataTable2);
        this.db.AddInParameter(storedProcCommand, "@tblFromStateToState", SqlDbType.Structured, (object) dataTable3);
        this.db.AddInParameter(storedProcCommand, "@tblAuditTrail", SqlDbType.Structured, (object) dataTable4);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.AddParameter(storedProcCommand, "@RETURN_VALUE", DbType.Int32, ParameterDirection.ReturnValue, string.Empty, DataRowVersion.Default, (object) null);
        this.db.AddInParameter(storedProcCommand, "@SDCCreditPerc", DbType.Decimal, (object) opportunity.OpportunityDetail.SDCCreditPerc);
        this.db.AddInParameter(storedProcCommand, "@CommitmentCommitteeReviewDate", DbType.DateTime, (object) opportunity.OpportunityDetail.CommitmentCommitteeReviewDate);
        this.db.AddInParameter(storedProcCommand, "@CommitmentCommitteeApprovedDate", DbType.DateTime, (object) opportunity.OpportunityDetail.CommitmentCommitteeApprovedDate);
        this.db.AddInParameter(storedProcCommand, "@ManagementReviewDate", DbType.DateTime, (object) opportunity.OpportunityDetail.ManagementReviewDate);
        this.db.AddInParameter(storedProcCommand, "@ManagementApprovedDate", DbType.DateTime, (object) opportunity.OpportunityDetail.ManagementApprovedDate);
        this.db.AddInParameter(storedProcCommand, "@DealType", DbType.Int64, (object) opportunity.OpportunityDetail.DealType);
        if (opportunity.OpportunityDetail.G17Details != null)
          this.db.AddInParameter(storedProcCommand, "@G17DetailTableType", SqlDbType.Structured, (object) this.GetG17DetailDataTable(opportunity.OpportunityDetail.G17Details));
        if (opportunity.MiscFieldsValueDetail != null)
          this.db.AddInParameter(storedProcCommand, "@PropertySetValueTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<PropertySetValue>(opportunity.MiscFieldsValueDetail.ToList<PropertySetValue>()));
        this.db.AddInParameter(storedProcCommand, "@GeneralCategory", DbType.Int64, (object) opportunity.OpportunityDetail.GeneralCategory);
        this.db.AddInParameter(storedProcCommand, "@SubmissionDateAndTime", DbType.DateTime, (object) opportunity.OpportunityDetail.SubmissionDateAndTime);
        this.db.AddInParameter(storedProcCommand, "@SubmissionDateTimezone", DbType.String, (object) opportunity.OpportunityDetail.SubmissionDateTimezone);
        this.db.AddInParameter(storedProcCommand, "@ResponseDueDate", DbType.DateTime, (object) opportunity.OpportunityDetail.ResponseDueDateTime);
        this.db.AddInParameter(storedProcCommand, "@ResponseDueDateTimezone", DbType.String, (object) opportunity.OpportunityDetail.ResponseDueDateTimezone);
        this.db.AddInParameter(storedProcCommand, "@RFPFees", DbType.Decimal, (object) opportunity.OpportunityDetail.RFPFees);
        this.db.AddInParameter(storedProcCommand, "@TakeDownValue", DbType.Decimal, (object) opportunity.OpportunityDetail.TakeDownValue);
        this.db.AddInParameter(storedProcCommand, "@JobNumber", DbType.String, (object) opportunity.OpportunityDetail.JobNumber);
        this.db.AddInParameter(storedProcCommand, "@HasRFPFeeChangedAfterManagementApprovalProcess", DbType.Boolean, (object) opportunity.OpportunityDetail.HasRFPFeeChangedAfterManagementApprovalProcess);
        this.db.AddInParameter(storedProcCommand, "@ExpectedPricingDate", DbType.DateTime, (object) opportunity.OpportunityDetail.ExpectedPricingDate);
        if (opportunity.OpportunityDetail.MSBankingGroupOpportunity != null)
          this.db.AddInParameter(storedProcCommand, "@MSBankingGroupTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<MsBankingGroupOpportunity>(opportunity.OpportunityDetail.MSBankingGroupOpportunity.ToList<MsBankingGroupOpportunity>()));
        this.db.ExecuteNonQuery(storedProcCommand);
        long num = Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
        int result;
        if (int.TryParse(Convert.ToString(storedProcCommand.Parameters["@RETURN_VALUE"].Value), out result) && result == -1)
          num = -1L;
        return num;
      }
    }

    public Opportunity CopyOpportunity(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CreateOpportunity"))
      {
        Opportunity opportunity = new Opportunity();
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (reader.Read())
          {
            IRowMapper<OpportunityDetail> rowMapper1 = MapBuilder<OpportunityDetail>.MapAllProperties().DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.CommaSeperatedStateID)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.Notes)).DoNotMap<Decimal?>((Expression<Func<OpportunityDetail, Decimal?>>) (x => x.SDCCreditPerc)).DoNotMap<DateTime?>((Expression<Func<OpportunityDetail, DateTime?>>) (x => x.CommitmentCommitteeApprovedDate)).DoNotMap<DateTime?>((Expression<Func<OpportunityDetail, DateTime?>>) (x => x.CommitmentCommitteeReviewDate)).DoNotMap<DateTime?>((Expression<Func<OpportunityDetail, DateTime?>>) (x => x.ManagementApprovedDate)).DoNotMap<DateTime?>((Expression<Func<OpportunityDetail, DateTime?>>) (x => x.ManagementReviewDate)).DoNotMap<Decimal?>((Expression<Func<OpportunityDetail, Decimal?>>) (x => x.RFPFees)).DoNotMap<DateTime?>((Expression<Func<OpportunityDetail, DateTime?>>) (x => x.ResponseDueDateTime)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.ResponseDueDateTimezone)).DoNotMap<DateTime?>((Expression<Func<OpportunityDetail, DateTime?>>) (x => x.SubmissionDateAndTime)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.SubmissionDateTimezone)).DoNotMap<long?>((Expression<Func<OpportunityDetail, long?>>) (x => x.GeneralCategory)).DoNotMap<long?>((Expression<Func<OpportunityDetail, long?>>) (x => x.DealType)).DoNotMap<bool?>((Expression<Func<OpportunityDetail, bool?>>) (x => x.IsCommitmentCommitteeApproved)).DoNotMap<bool?>((Expression<Func<OpportunityDetail, bool?>>) (x => x.IsManagementApproved)).DoNotMap<Decimal?>((Expression<Func<OpportunityDetail, Decimal?>>) (x => x.TakeDownValue)).DoNotMap<bool?>((Expression<Func<OpportunityDetail, bool?>>) (x => x.DualProposalProposed)).DoNotMap<long?>((Expression<Func<OpportunityDetail, long?>>) (x => x.CreatorEmployeeId)).DoNotMap<long?>((Expression<Func<OpportunityDetail, long?>>) (x => x.GeneralCategorySpecific)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.OpportunityTypeValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.StateValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.MaterialTypeValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.ApprovedDerivativeMarketerValue)).DoNotMap<bool?>((Expression<Func<OpportunityDetail, bool?>>) (x => x.HasRFPFeeChangedAfterManagementApprovalProcess)).DoNotMap<bool?>((Expression<Func<OpportunityDetail, bool?>>) (x => x.IsManagementApprovedStateVisited)).DoNotMap<bool>((Expression<Func<OpportunityDetail, bool>>) (x => x.ToSkipCase)).DoNotMap<Decimal?>((Expression<Func<OpportunityDetail, Decimal?>>) (x => x.OldRFPFees)).DoNotMap<bool>((Expression<Func<OpportunityDetail, bool>>) (x => x.IsFreeze)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.AdditionalInformationForCommitmentCommittee)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.AdditionalRFPDetails)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactPrefix)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactFirstName)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactLastName)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactSuffix)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactAddress)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactEmail)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactJobTitle)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.ExpectedFirmRoleValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.FirmRoleValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.Ratings)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.LeadBanker)).Build();
            opportunity.OpportunityDetail = rowMapper1.MapRow((IDataRecord) reader);
            if (reader.NextResult())
              opportunity.InternalPartners = this.GetInternalPartners(reader);
            if (reader.NextResult())
              opportunity.InternalPartnerBankRMs = this.GetInternalPartnerBankRMs(reader);
            if (reader.NextResult())
            {
              List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
              IRowMapper<ExternalPartner> rowMapper2 = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).DoNotMap<int>((Expression<Func<ExternalPartner, int>>) (x => x.Version)).Build();
              while (reader.Read())
                externalPartnerList.Add(rowMapper2.MapRow((IDataRecord) reader));
              if (externalPartnerList.Count > 0)
                externalPartnerList.RemoveAll((Predicate<ExternalPartner>) (t => t.LookupKey == "Winning Syndicate Member Role"));
              opportunity.ExternalPartners = externalPartnerList;
            }
            if (reader.NextResult())
              opportunity.AppTransactionClientContacts = this.GetClientContacts(reader);
            if (reader.NextResult())
              opportunity.OpportunityDetail.MAExemptionDetails = this.GetMAExemptionDetails(reader);
            if (reader.NextResult())
              opportunity.OpportunityDetail.MSBankingGroupOpportunity = this.GetMSBankingGroupDetails(reader);
            if (reader.NextResult())
              opportunity.OpportunityContact = this.GetOpportunityContacts(reader);
            if (reader.NextResult())
              opportunity.WorkflowStateTransitions = this.GetStateTransitions(reader);
            if (reader.NextResult())
              opportunity.OpportunityDetail.NotesCollection = this.GetNotes(reader);
            if (reader.NextResult())
              opportunity.ReviewCommentsCollection = this.GetReviewComments(reader);
            if (reader.NextResult())
              opportunity.OpportunityDetail.MAExemptionDetails = this.GetMAExemptionDetails(reader);
          }
        }
        return opportunity;
      }
    }

    public Opportunity FetchByID(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchOpportunityById"))
      {
        Opportunity opportunity = new Opportunity();
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (reader.Read())
          {
            IRowMapper<OpportunityDetail> rowMapper = MapBuilder<OpportunityDetail>.MapAllProperties().DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.OpportunityTypeValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.StateValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.MaterialTypeValue)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.ApprovedDerivativeMarketerValue)).DoNotMap<bool>((Expression<Func<OpportunityDetail, bool>>) (x => x.ToSkipCase)).DoNotMap<bool?>((Expression<Func<OpportunityDetail, bool?>>) (x => x.IsManagementApprovedStateVisited)).DoNotMap<Decimal?>((Expression<Func<OpportunityDetail, Decimal?>>) (x => x.OldRFPFees)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactPrefix)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactFirstName)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactLastName)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactSuffix)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactJobTitle)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactAddress)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.G17ContactEmail)).DoNotMap<string>((Expression<Func<OpportunityDetail, string>>) (x => x.LeadBanker)).Build();
            opportunity.OpportunityDetail = rowMapper.MapRow((IDataRecord) reader);
            if (reader.NextResult())
              opportunity.InternalPartners = this.GetInternalPartners(reader);
            if (reader.NextResult())
              opportunity.InternalPartnerBankRMs = this.GetInternalPartnerBankRMs(reader);
            if (reader.NextResult())
              opportunity.ExternalPartners = this.GetExternalPartners(reader);
            if (reader.NextResult())
              opportunity.OpportunityContact = this.GetOpportunityContacts(reader);
            if (reader.NextResult())
              opportunity.WorkflowStateTransitions = this.GetStateTransitions(reader);
            if (reader.NextResult())
              opportunity.OpportunityDetail.MAExemptionDetails = this.GetMAExemptionDetails(reader);
            if (reader.NextResult())
              opportunity.ReviewCommentsCollection = this.GetReviewComments(reader);
            if (reader.NextResult())
              opportunity.OpportunityDetail.G17Details = this.GetG17Details(reader);
            if (reader.NextResult())
            {
              while (reader.Read())
                opportunity.OpportunityDetail.G17ContactAddress = reader["G17ContactAddress"].ToString();
            }
            if (reader.NextResult())
            {
              while (reader.Read())
              {
                opportunity.OpportunityDetail.G17ContactPrefix = reader["G17ContactPrefix"].ToString();
                opportunity.OpportunityDetail.G17ContactFirstName = reader["G17ContactFirstName"].ToString();
                opportunity.OpportunityDetail.G17ContactLastName = reader["G17ContactLastName"].ToString();
                opportunity.OpportunityDetail.G17ContactSuffix = reader["G17ContactSuffix"].ToString();
                opportunity.OpportunityDetail.G17ContactJobTitle = reader["G17ContactJobTitle"].ToString();
                opportunity.OpportunityDetail.G17ContactEmail = reader["G17ContactEmail"].ToString();
              }
            }
            if (reader.NextResult())
            {
              while (reader.Read())
                opportunity.OpportunityDetail.LeadBanker = reader["LeadBankerName"].ToString();
            }
            if (reader.NextResult())
              opportunity.OpportunityDetail.MSBankingGroupOpportunity = this.GetMSBankingGroupDetails(reader);
            opportunity.OpportunityDetail.IsManagementApprovedStateVisited = new bool?(this.CheckIfVisitedState(appTransactionId, 9L));
          }
        }
        return opportunity;
      }
    }

    public List<IssueContact> FetchOpportunityContact(long AppTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssueContactsByIssueID"))
      {
        List<IssueContact> issueContactList = new List<IssueContact>();
        this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) AppTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<IssueContact> rowMapper = MapBuilder<IssueContact>.MapAllProperties().Build();
          while (dataReader.Read())
            issueContactList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return issueContactList;
      }
    }

    public IEnumerable<Opportunity> FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllOpportunity"))
      {
        List<Opportunity> opportunityList = new List<Opportunity>();
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Opportunity> rowMapper = MapBuilder<Opportunity>.MapAllProperties().DoNotMap<List<InternalPartner>>((Expression<Func<Opportunity, List<InternalPartner>>>) (x => x.InternalPartners)).DoNotMap<List<ExternalPartner>>((Expression<Func<Opportunity, List<ExternalPartner>>>) (x => x.ExternalPartners)).Build();
          while (dataReader.Read())
            opportunityList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<Opportunity>) opportunityList;
      }
    }

    public IDataReader FetchOpportunityNegotiatedCalendar(
      DateTime dateHiredFrom,
      DateTime dateHiredTo,
      long typeOfOpportunity,
      Ordering[] order,
      int pageNumber,
      int pageSize)
    {
      string str1 = "DateHired";
      string str2 = "Asc";
      if (order.Length != 0)
      {
        str1 = order[0].PropertyName;
        str2 = order[0].Direction.ToString();
      }
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchOpportunityNegotiatedCalendar"))
      {
        List<Opportunity> opportunityList = new List<Opportunity>();
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        this.db.AddInParameter(storedProcCommand, "@DateHiredFrom", DbType.DateTime, (object) dateHiredFrom);
        this.db.AddInParameter(storedProcCommand, "@DateHiredTo", DbType.DateTime, (object) dateHiredTo);
        this.db.AddInParameter(storedProcCommand, "@TypeOfOpportunity", DbType.Int64, (object) typeOfOpportunity);
        this.db.AddInParameter(storedProcCommand, "@Skip", DbType.String, (object) (pageNumber + 1));
        this.db.AddInParameter(storedProcCommand, "@Take", DbType.String, (object) (pageSize + pageNumber));
        this.db.AddInParameter(storedProcCommand, "@OrderBy", DbType.String, (object) str1);
        this.db.AddInParameter(storedProcCommand, "@OrderDir", DbType.String, (object) str2);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchOpportunityPipeline()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchOpportunityPipeline"))
      {
        List<Opportunity> opportunityList = new List<Opportunity>();
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public bool CheckForDuplicateOpportunityName(long appTransactionID, string opportunityName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CheckDuplicateOpportunityName"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@OpportunityName", DbType.String, (object) opportunityName);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public List<string> FetchOpportunityNames(string opportunityName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchOpportunityNames"))
      {
        this.db.AddInParameter(storedProcCommand, "@opportunityName", DbType.String, (object) RepositoryBase.EscapeForLike(opportunityName));
        List<string> stringList = new List<string>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            stringList.Add(dataReader.GetString(0));
        }
        return stringList;
      }
    }

    public bool UpdateStatusTracking(long appTransactionID, List<int> rfpStatusList, int entityID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEntityStateTracking_New"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityID);
        DataTable dataTable = new DataTable();
        dataTable.Columns.Add("ID", typeof (int));
        foreach (int rfpStatus in rfpStatusList)
        {
          DataRow row = dataTable.NewRow();
          row["ID"] = (object) rfpStatus;
          dataTable.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblCurrentState", SqlDbType.Structured, (object) dataTable);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    private List<Notes> GetNotes(IDataReader reader)
    {
      List<Notes> notesList = new List<Notes>();
      IRowMapper<Notes> rowMapper = MapBuilder<Notes>.MapAllProperties().DoNotMap<string>((Expression<Func<Notes, string>>) (m => m.NotesDateTimeString)).Build();
      while (reader.Read())
        notesList.Add(rowMapper.MapRow((IDataRecord) reader));
      return notesList;
    }

    private List<ReviewComments> GetReviewComments(IDataReader reader)
    {
      List<ReviewComments> reviewCommentsList = new List<ReviewComments>();
      IRowMapper<ReviewComments> rowMapper = MapBuilder<ReviewComments>.MapAllProperties().DoNotMap<string>((Expression<Func<ReviewComments, string>>) (m => m.ReviewCommentDateTimeString)).Build();
      while (reader.Read())
        reviewCommentsList.Add(rowMapper.MapRow((IDataRecord) reader));
      return reviewCommentsList;
    }

    private List<AppTransactionStateTransition> WorkflowStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    private DataTable GetAppTransactionClientContactDataTable(
      List<AppTransactionClientContact> theAppTransactionClientContacts)
    {
      theAppTransactionClientContacts = theAppTransactionClientContacts.ToList<AppTransactionClientContact>();
      return this.ConvertListToDataTable<AppTransactionClientContact>(theAppTransactionClientContacts);
    }

    private DataTable GetMAExemptionDetailDataTable(
      List<MAExemptionDetail> theMAExemptionDetails)
    {
      theMAExemptionDetails = theMAExemptionDetails.ToList<MAExemptionDetail>();
      return this.ConvertListToDataTable<MAExemptionDetail>(theMAExemptionDetails);
    }

    private DataTable GetExternalPartnerDataTable(
      List<ExternalPartner> theIssueExternalPartner,
      bool includeDirtyRecordsOnly = true)
    {
      if (includeDirtyRecordsOnly)
        theIssueExternalPartner = theIssueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.IsDirty)).ToList<ExternalPartner>();
      return this.ConvertListToDataTable<ExternalPartner>(theIssueExternalPartner);
    }

    private DataTable GetInternalPartnerDataTable(
      List<InternalPartner> internalPartner,
      bool includeDirtyRecordsOnly = true)
    {
      if (includeDirtyRecordsOnly)
        internalPartner = internalPartner.Where<InternalPartner>((Func<InternalPartner, bool>) (x => x.IsDirty)).ToList<InternalPartner>();
      DataTable dataTable = this.ConvertListToDataTable<InternalPartner>(internalPartner);
      foreach (DataRow dataRow in dataTable.Select("IsPrimary='Yes' OR IsPrimary='No'"))
        dataRow["IsPrimary"] = dataRow["IsPrimary"].ToString() == "Yes" ? (object) "1" : (object) "0";
      return dataTable;
    }

    private List<ExternalPartner> GetExternalPartners(IDataReader reader)
    {
      List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
      IRowMapper<ExternalPartner> rowMapper = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.InsertedIssueContact)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).DoNotMap<int>((Expression<Func<ExternalPartner, int>>) (x => x.Version)).Build();
      while (reader.Read())
        externalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return externalPartnerList;
    }

    private List<InternalPartner> GetInternalPartners(IDataReader reader)
    {
      List<InternalPartner> internalPartnerList = new List<InternalPartner>();
      IRowMapper<InternalPartner> rowMapper = MapBuilder<InternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<int>((Expression<Func<InternalPartner, int>>) (x => x.Version)).Build();
      while (reader.Read())
        internalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerList;
    }

    private List<InternalPartnerBankRM> GetInternalPartnerBankRMs(
      IDataReader reader)
    {
      List<InternalPartnerBankRM> internalPartnerBankRmList = new List<InternalPartnerBankRM>();
      IRowMapper<InternalPartnerBankRM> rowMapper = MapBuilder<InternalPartnerBankRM>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartnerBankRM, bool>>) (x => x.IsDeleted)).Build();
      while (reader.Read())
        internalPartnerBankRmList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerBankRmList;
    }

    private List<AppTransactionClientContact> GetClientContacts(
      IDataReader reader)
    {
      List<AppTransactionClientContact> transactionClientContactList = new List<AppTransactionClientContact>();
      IRowMapper<AppTransactionClientContact> rowMapper = MapBuilder<AppTransactionClientContact>.MapAllProperties().Build();
      while (reader.Read())
        transactionClientContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionClientContactList;
    }

    private List<IssueContact> GetOpportunityContacts(IDataReader reader)
    {
      List<IssueContact> issueContactList = new List<IssueContact>();
      IRowMapper<IssueContact> rowMapper = MapBuilder<IssueContact>.MapAllProperties().Build();
      while (reader.Read())
        issueContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return issueContactList;
    }

    private List<AppTransactionStateTransition> GetStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    private List<MAExemptionDetail> GetMAExemptionDetails(IDataReader reader)
    {
      List<MAExemptionDetail> maExemptionDetailList = new List<MAExemptionDetail>();
      IRowMapper<MAExemptionDetail> rowMapper = MapBuilder<MAExemptionDetail>.MapAllProperties().DoNotMap<long>((Expression<Func<MAExemptionDetail, long>>) (x => x.MAExemptionID)).DoNotMap<int>((Expression<Func<MAExemptionDetail, int>>) (x => x.Version)).Build();
      int num = 1;
      while (reader.Read())
      {
        MAExemptionDetail maExemptionDetail = rowMapper.MapRow((IDataRecord) reader);
        maExemptionDetail.MAExemptionID = (long) num++;
        maExemptionDetailList.Add(maExemptionDetail);
      }
      return maExemptionDetailList;
    }

    public IEnumerable<SearchSetting> FetchAllBookmarks() => this.SearchSettingRepository.FetchByModuleName("Opportunity Search", (long) this.AppUser.Id);

    public void SaveBookmark(SearchSetting searchSetting)
    {
      searchSetting.Module = "Opportunity Search";
      searchSetting.UserId = (long) this.AppUser.Id;
      this.SearchSettingRepository.Save(searchSetting);
    }

    public void DeleteBookmark(long bookmarkId) => this.SearchSettingRepository.Delete(bookmarkId);

    public IDataReader Query(QueryDefinition definition, int pageSize, int pageNumber)
    {
      SqlCriterionVisitResult criterionVisitResult = new SqlCriterionVisitor((IDictionary<string, string>) this.knownMappings).Build(definition.Criterion);
      string str1 = string.Empty;
      foreach (Ordering ordering in definition.Order)
        str1 = string.Format("{0}{1} {2},", (object) str1, (object) ordering.PropertyName, (object) ordering.Direction);
      string str2 = string.IsNullOrEmpty(str1) ? "OpportunityName asc" : str1.Substring(0, str1.Length - 1);
      string str3 = string.Empty;
      if (definition.Projection != null && definition.Projection.Count<string>() > 0)
      {
        List<string> list1 = OpportunityRepository.knownProjection.Where<SearchSQLField>((Func<SearchSQLField, bool>) (x => definition.Projection.Contains<string>(x.Name))).Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.Query)).ToList<string>();
        List<string> list2 = OpportunityRepository.knownProjection.Where<SearchSQLField>((Func<SearchSQLField, bool>) (x => !definition.Projection.Contains<string>(x.Name))).Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.EmptyQuery)).ToList<string>();
        if (list1 != null && list1.Count > 0)
          str3 = list1.Join<string>(", ");
        if (list2 != null && list2.Count > 0)
          str3 = !string.IsNullOrEmpty(str3) ? string.Format("{0}, {1}", (object) str3, (object) list2.Join<string>(", ")) : list2.Join<string>(", ");
      }
      else
      {
        List<string> list = OpportunityRepository.knownProjection.Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.EmptyQuery)).ToList<string>();
        if (list != null && list.Count > 0)
          str3 = list.Join<string>(", ");
      }
      StringBuilder stringBuilder1 = new StringBuilder();
      StringBuilder stringBuilder2 = new StringBuilder();
      if (definition.SubQueryDefinitions != null && definition.SubQueryDefinitions.Count > 0)
      {
        foreach (SubQueryDefinition subQueryDefinition in definition.SubQueryDefinitions)
        {
          if (subQueryDefinition.Field.ToLower() == "opportunitystatusid")
          {
            stringBuilder1.Append(string.Format(" LEFT OUTER JOIN (SELECT DISTINCT ATS.AppTransactionID FROM AppTransactionState ATS WHERE ATS.StateID in ({0})) ATS ON View_OpportunitySearch.AppTransactionID = ATS.AppTransactionID", (object) subQueryDefinition.Value));
            stringBuilder2.Append(" AND ATS.AppTransactionID IS NULL");
          }
        }
      }
      string str4 = string.Format("{0} {1}", (object) criterionVisitResult.WhereClause, (object) stringBuilder2);
      using (DbCommand sqlStringCommand = this.db.GetSqlStringCommand(string.Format("{0} Select COUNT(*) From(SELECT Distinct View_OpportunitySearch.AppTransactionID, {1} FROM View_OpportunitySearch {2} WHERE {3} GROUP BY View_OpportunitySearch.AppTransactionID)k", (object) string.Format("WITH cte as (Select *, ROW_NUMBER() OVER (ORDER BY {0}) AS _row From((SELECT Distinct View_OpportunitySearch.AppTransactionID, {1} FROM View_OpportunitySearch {2} WHERE {3} GROUP BY View_OpportunitySearch.AppTransactionID))k) SELECT * FROM cte WHERE _row BETWEEN {4} AND {5} ", (object) str2, (object) str3, (object) stringBuilder1, (object) str4, (object) (pageNumber + 1), (object) (pageSize + pageNumber)), (object) str3, (object) stringBuilder1, (object) str4)))
      {
        sqlStringCommand.Parameters.AddRange((Array) criterionVisitResult.Parameters);
        return this.db.ExecuteReader(sqlStringCommand);
      }
    }

    public Dictionary<Opportunity.Status, Opportunity.Status> FetchHistoryByAppTransactionID(
      long appTransactionID)
    {
      Dictionary<Opportunity.Status, Opportunity.Status> dictionary;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchHistoryByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          dictionary = new Dictionary<Opportunity.Status, Opportunity.Status>();
          int ordinal1 = dataReader.GetOrdinal("ParentStateID");
          int ordinal2 = dataReader.GetOrdinal("StateID");
          while (dataReader.Read())
          {
            Opportunity.Status int32_1 = (Opportunity.Status) dataReader.GetInt32(ordinal1);
            Opportunity.Status int32_2 = (Opportunity.Status) dataReader.GetInt32(ordinal2);
            dictionary.Add(int32_1, int32_2);
          }
        }
      }
      return dictionary;
    }

    public long CreateRFPFromOpportunity(long AppTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CreateRFPFromOpportunity"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
      }
    }

    public long CreateIssueFromOpportunity(long AppTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CreateIssueFromOpportunity"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
      }
    }

    private List<G17Detail> GetG17Details(IDataReader reader)
    {
      List<G17Detail> g17DetailList = new List<G17Detail>();
      IRowMapper<G17Detail> rowMapper = MapBuilder<G17Detail>.MapAllProperties().DoNotMap<long>((Expression<Func<G17Detail, long>>) (x => x.G17ID)).DoNotMap<string>((Expression<Func<G17Detail, string>>) (x => x.G17TypeName)).DoNotMap<int>((Expression<Func<G17Detail, int>>) (x => x.Version)).Build();
      int num = 1;
      while (reader.Read())
      {
        G17Detail g17Detail = rowMapper.MapRow((IDataRecord) reader);
        g17Detail.G17ID = (long) num++;
        g17DetailList.Add(g17Detail);
      }
      return g17DetailList;
    }

    private DataTable GetG17DetailDataTable(List<G17Detail> theG17Details)
    {
      theG17Details = theG17Details.ToList<G17Detail>();
      return this.ConvertListToDataTable<G17Detail>(theG17Details);
    }

    private List<MsBankingGroupOpportunity> GetMSBankingGroupDetails(
      IDataReader reader)
    {
      List<MsBankingGroupOpportunity> groupOpportunityList = new List<MsBankingGroupOpportunity>();
      IRowMapper<MsBankingGroupOpportunity> rowMapper = MapBuilder<MsBankingGroupOpportunity>.MapAllProperties().Build();
      while (reader.Read())
        groupOpportunityList.Add(rowMapper.MapRow((IDataRecord) reader));
      return groupOpportunityList;
    }

    public bool UpdateField(long appTransactionID, bool fieldValue, string fieldName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_UpdateField"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@FieldValue", DbType.Boolean, (object) fieldValue);
        this.db.AddInParameter(storedProcCommand, "@FieldName", DbType.String, (object) fieldName);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public bool CheckIfVisitedState(long appTransactionID, long stateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CheckIfVisitedState"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@StateID", DbType.Int64, (object) stateID);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public List<UploadedDocumentType> FetchUploadedDocumentTypes(
      long entityID)
    {
      List<UploadedDocumentType> uploadedDocumentTypeList = new List<UploadedDocumentType>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssueDocumentTypes"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<UploadedDocumentType> rowMapper = MapBuilder<UploadedDocumentType>.MapAllProperties().Build();
          while (dataReader.Read())
            uploadedDocumentTypeList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return uploadedDocumentTypeList;
    }
  }
}
