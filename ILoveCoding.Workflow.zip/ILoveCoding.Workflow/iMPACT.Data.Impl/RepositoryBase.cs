﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.RepositoryBase
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Security;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;

namespace IrisSoftware.iMPACT.Data.Impl
{
  public class RepositoryBase
  {
    [Dependency]
    public IUser AppUser { get; set; }

    [Dependency]
    public SqlDatabase db { get; set; }

    public DataTable ConvertListToDataTable<T>(List<T> items)
    {
      DataTable dataTable = new DataTable(typeof (T).Name);
      IEnumerable<PropertyInfo> source = ((IEnumerable<PropertyInfo>) typeof (T).GetProperties()).Select(property => new
      {
        property = property,
        orderAttribute = ((IEnumerable<object>) property.GetCustomAttributes(typeof (SQLTableTypeOrderAttribute), true)).SingleOrDefault<object>() as SQLTableTypeOrderAttribute
      }).Where(_param1 => _param1.orderAttribute != null && _param1.orderAttribute.Order > 0).OrderBy(_param1 => _param1.orderAttribute.Order).Select(_param1 => _param1.property);
      foreach (PropertyInfo propertyInfo in source)
      {
        Type type = propertyInfo.PropertyType;
        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>))
          type = Nullable.GetUnderlyingType(type);
        dataTable.Columns.Add(propertyInfo.Name, type);
      }
      foreach (T obj in items)
      {
        int num = 0;
        object[] objArray = new object[source.Count<PropertyInfo>()];
        foreach (PropertyInfo propertyInfo in source)
          objArray[num++] = propertyInfo.GetValue((object) obj, (object[]) null);
        dataTable.Rows.Add(objArray);
      }
      return dataTable;
    }

    public static string EscapeForLike(string value) => value.Replace("[", "[[]").Replace("_", "[_]").Replace("%", "[%]");
  }
}
