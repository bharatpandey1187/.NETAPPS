﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.SystemGeneratedIssueRoleRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ISystemGeneratedIssueRoleRepository))]
  public class SystemGeneratedIssueRoleRepository : ISystemGeneratedIssueRoleRepository
  {
    public void Save(
      SystemGeneratedIssueRole theSystemGeneratedIssueRole)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveSystemGeneratedIssueRole"))
      {
        database.AddInParameter(storedProcCommand, "@Principal", DbType.Int32, (object) theSystemGeneratedIssueRole.Principal);
        database.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) theSystemGeneratedIssueRole.RoleID);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public SystemGeneratedIssueRole FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchSystemGeneratedIssueRoleByKey"))
      {
        database.AddInParameter(storedProcCommand, "@SystemGeneratedIssueRoleId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<SystemGeneratedIssueRole>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new SystemGeneratedIssueRole();
      }
    }

    public IEnumerable<SystemGeneratedIssueRole> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllSystemGeneratedIssueRole"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<SystemGeneratedIssueRole> mapper = MapBuilder<SystemGeneratedIssueRole>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<SystemGeneratedIssueRole>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteSystemGeneratedIssueRoleByKey"))
      {
        database.AddInParameter(storedProcCommand, "@SystemGeneratedIssueRoleId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
