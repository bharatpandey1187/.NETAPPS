﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.EmailTemplateRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IEmailTemplateRepository))]
  public class EmailTemplateRepository : RepositoryBase, IEmailTemplateRepository
  {
    public void Save(EmailTemplate theEmailTemplate)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEmailTemplate"))
      {
        this.db.AddInParameter(storedProcCommand, "@EmailTemplateID", DbType.Int32, (object) theEmailTemplate.EmailTemplateID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) theEmailTemplate.Name);
        this.db.AddInParameter(storedProcCommand, "@Description", DbType.String, (object) theEmailTemplate.Description);
        this.db.AddInParameter(storedProcCommand, "@To", DbType.String, (object) theEmailTemplate.To);
        this.db.AddInParameter(storedProcCommand, "@Cc", DbType.String, (object) theEmailTemplate.Cc);
        this.db.AddInParameter(storedProcCommand, "@Subject", DbType.String, (object) theEmailTemplate.Subject);
        this.db.AddInParameter(storedProcCommand, "@Body", DbType.String, (object) theEmailTemplate.Body);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) theEmailTemplate.IsActive);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public EmailTemplate FetchByKey(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmailTemplateByID"))
      {
        EmailTemplate emailTemplate = new EmailTemplate();
        this.db.AddInParameter(storedProcCommand, "@EmailTemplateID", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          if (dataReader.Read())
            emailTemplate = MapBuilder<EmailTemplate>.MapAllProperties().DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (email => email.UIName)).Build().MapRow((IDataRecord) dataReader);
          return emailTemplate;
        }
      }
    }

    public EmailTemplate[] FetchEntityTemplates(int entityId)
    {
      List<EmailTemplate> emailTemplateList = new List<EmailTemplate>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmailTemplateByEntityId"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<EmailTemplate> rowMapper = MapBuilder<EmailTemplate>.MapAllProperties().DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (map => map.Body)).DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (map => map.Cc)).DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (map => map.CreatedBy)).DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (map => map.ModifiedBy)).DoNotMap<DateTime>((Expression<Func<EmailTemplate, DateTime>>) (map => map.ModifiedOn)).DoNotMap<DateTime>((Expression<Func<EmailTemplate, DateTime>>) (map => map.CreatedOn)).DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (map => map.To)).DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (map => map.Subject)).DoNotMap<bool>((Expression<Func<EmailTemplate, bool>>) (map => map.IsActive)).Build();
          while (dataReader.Read())
            emailTemplateList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return emailTemplateList.ToArray();
    }

    public IDataReader FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmailTemplate"))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public EmailTemplate FetchIssueClosedEmailTemplate(
      int templateID,
      long appTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchBankerAttestedPersonEmail"))
      {
        EmailTemplate emailTemplate = this.FetchByKey(templateID);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int32, (object) appTransactionID);
        string str = Convert.ToString(this.db.ExecuteScalar(storedProcCommand));
        if (!string.IsNullOrEmpty(str))
          emailTemplate.To = emailTemplate.To.Trim(';') + ";" + str;
        return emailTemplate;
      }
    }

    public List<string> FetchEmailByRoleID(long AppTransactionID, string GroupID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmailByRoleID"))
      {
        List<string> stringList = new List<string>();
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@GroupID", DbType.String, (object) GroupID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            stringList.Add(dataReader.GetString(0));
          return stringList;
        }
      }
    }

    public List<EmailTemplate> FetchByEntityIDStateID(
      long? EntityID,
      long? FromStateID,
      long? ToStateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmailTemplateByEntityIDStateID"))
      {
        List<EmailTemplate> emailTemplateList = new List<EmailTemplate>();
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) EntityID);
        this.db.AddInParameter(storedProcCommand, "@FromStateID", DbType.Int32, (object) FromStateID);
        this.db.AddInParameter(storedProcCommand, "@ToStateID", DbType.Int32, (object) ToStateID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            IRowMapper<EmailTemplate> rowMapper = MapBuilder<EmailTemplate>.MapAllProperties().DoNotMap<string>((Expression<Func<EmailTemplate, string>>) (email => email.UIName)).Build();
            emailTemplateList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
          return emailTemplateList;
        }
      }
    }

    public void SaveToEmailLog(
      DateTime sent,
      string from,
      string To,
      string Cc,
      string subject,
      string body)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_InsertEmailLog"))
      {
        this.db.AddInParameter(storedProcCommand, "@Sent", DbType.DateTime, (object) sent);
        this.db.AddInParameter(storedProcCommand, "@From", DbType.String, (object) from);
        this.db.AddInParameter(storedProcCommand, "@To", DbType.String, (object) To);
        this.db.AddInParameter(storedProcCommand, "@Cc", DbType.String, (object) Cc);
        this.db.AddInParameter(storedProcCommand, "@Subject", DbType.String, (object) subject);
        this.db.AddInParameter(storedProcCommand, "@Body", DbType.String, (object) body);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
