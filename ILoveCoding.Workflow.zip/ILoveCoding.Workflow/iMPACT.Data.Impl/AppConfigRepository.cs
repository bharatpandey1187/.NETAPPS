﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AppConfigRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAppConfigRepository))]
  public class AppConfigRepository : RepositoryBase, IAppConfigRepository
  {
    public void Save(AppConfig theAppConfig)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveAppConfig"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppConfigID", DbType.Int64, (object) theAppConfig.AppConfigID);
        this.db.AddInParameter(storedProcCommand, "@Key", DbType.String, (object) theAppConfig.Key);
        this.db.AddInParameter(storedProcCommand, "@Value", DbType.String, (object) theAppConfig.Value);
        this.db.AddInParameter(storedProcCommand, "@Descr", DbType.String, (object) theAppConfig.Descr);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) theAppConfig.ModifiedBy);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void SaveConfigValues(List<AppConfig> appConfigItems)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveAppConfigItemValues"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppConfig_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<AppConfig>(appConfigItems));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public AppConfig FetchByKey(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAppConfigByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppConfigId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<AppConfig>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new AppConfig();
      }
    }

    public IEnumerable<AppConfig> FetchAll()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAllAppConfig"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<AppConfig> mapper = MapBuilder<AppConfig>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppConfig>) null;
        }
      }
    }
  }
}
