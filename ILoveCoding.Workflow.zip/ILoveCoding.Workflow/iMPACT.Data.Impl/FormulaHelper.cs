﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.FormulaHelper
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.Core.DataStructure;
using IrisSoftware.Core.Formula.Ast;
using IrisSoftware.Core.Formula.LinqExpression;
using IrisSoftware.Core.Formula.Validation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Data.Impl
{
  public class FormulaHelper
  {
    public static List<PnLTemplateFields> GenerateScriptForFormula(
      List<PnLTemplateFields> fieldList,
      bool requireFormula = true)
    {
      List<PnLTemplateFields> source = new List<PnLTemplateFields>();
      ScopedHash<FormulaSetGeneratorVisitor.VisitResult> knownSymbols = new ScopedHash<FormulaSetGeneratorVisitor.VisitResult>();
      knownSymbols.Add("PnL", new FormulaSetGeneratorVisitor.VisitResult()
      {
        Type = typeof (PnLBO)
      });
      ScopedHash<string> unknownSymbols = new ScopedHash<string>();
      foreach (PnLTemplateFields field in fieldList)
      {
        if (!string.IsNullOrEmpty(field.Key))
        {
          if (!unknownSymbols.ContainsKey(field.Key))
          {
            if (!string.IsNullOrEmpty(field.Formula))
            {
              unknownSymbols.Add(field.Key, field.Formula);
            }
            else
            {
              knownSymbols.Add(field.Key, new FormulaSetGeneratorVisitor.VisitResult()
              {
                Type = FormulaHelper.GetType(field.DataType)
              });
              source.Add(field);
            }
          }
        }
        else
          source.Add(field);
      }
      FormulaSetGeneratorVisitor generatorVisitor = new FormulaSetGeneratorVisitor(knownSymbols, unknownSymbols, typeof (IKnownMethods), "this.", "this.");
      foreach (KeyValuePair<string, string> keyValuePair in unknownSymbols)
      {
        KeyValuePair<string, string> item = keyValuePair;
        PnLTemplateFields pnLtemplateFields = fieldList.FirstOrDefault<PnLTemplateFields>((Func<PnLTemplateFields, bool>) (_ => _.Key == item.Key));
        if (!knownSymbols.ContainsKey(item.Key))
        {
          if (!string.IsNullOrEmpty(item.Value))
          {
            AstNode exprTree = AstParser.Parse(item.Value);
            FormulaSetGeneratorVisitor.VisitResult visitResult = generatorVisitor.Validate(exprTree, knownSymbols);
            knownSymbols.Add(item.Key, visitResult);
            if (requireFormula)
              pnLtemplateFields.Formula = visitResult.ClientScript;
            pnLtemplateFields.EvaluationSequence = visitResult.Rank;
          }
        }
        else
        {
          if (requireFormula)
            pnLtemplateFields.Formula = knownSymbols[item.Key].ClientScript;
          pnLtemplateFields.EvaluationSequence = knownSymbols[item.Key].Rank;
        }
        source.Add(pnLtemplateFields);
      }
      source.Select<PnLTemplateFields, bool>((Func<PnLTemplateFields, bool>) (x => x.EvaluationSequence > 0)).ToList<bool>();
      return source;
    }

    public static void EvaluateFormula(
      List<PnLTemplateFields> oldPnlFields,
      PnLBO pnl,
      Dictionary<string, object> pnlFieldDetails,
      List<PnLTemplateFields> pnlFieldsForSequence)
    {
      Dictionary<string, object> knownKeys = FormulaHelper.GetKnownKeys();
      knownKeys.Add("PnL", (object) pnl);
      foreach (PnLTemplateFields pnLtemplateFields in (IEnumerable<PnLTemplateFields>) pnlFieldsForSequence.OrderBy<PnLTemplateFields, int>((Func<PnLTemplateFields, int>) (_ => _.EvaluationSequence)))
      {
        PnLTemplateFields item = pnLtemplateFields;
        PnLTemplateFields newItem = oldPnlFields.FirstOrDefault<PnLTemplateFields>((Func<PnLTemplateFields, bool>) (_ => _.Key == item.Key));
        if (newItem != null)
          FormulaHelper.SetValues(pnlFieldDetails, knownKeys, item, newItem);
      }
    }

    private static void SetValues(
      Dictionary<string, object> pnlFieldDetails,
      Dictionary<string, object> context,
      PnLTemplateFields item,
      PnLTemplateFields newItem)
    {
      if (string.IsNullOrEmpty(item.Key))
        return;
      if (!item.Overridden && !string.IsNullOrEmpty(newItem.Formula))
      {
        object obj1 = newItem.IsEvaluate ? Interpreter.Interpret(newItem.Formula, (IDictionary<string, object>) context) : (object) newItem.Value;
        object obj2 = FormulaHelper.GetValue(item.DataType, item.Format, obj1);
        context.Add(item.Key, obj2);
        pnlFieldDetails[item.Key] = obj2;
      }
      else
      {
        object obj = FormulaHelper.GetValue(item.DataType, item.Format, pnlFieldDetails[item.Key]);
        context.Add(item.Key, obj);
      }
    }

    private static Dictionary<string, object> GetKnownKeys()
    {
      KnownMethods knownMethods = new KnownMethods();
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      // ISSUE: virtual method pointer
      return new Dictionary<string, object>()
      {
        {
          "Ucase",
          (object) new Func<string, string>((object) knownMethods, __vmethodptr(knownMethods, Ucase))
        },
        {
          "Lcase",
          (object) new Func<string, string>((object) knownMethods, __vmethodptr(knownMethods, Lcase))
        },
        {
          "Str",
          (object) new Func<string, string>((object) knownMethods, __vmethodptr(knownMethods, Str))
        },
        {
          "CInt",
          (object) new Func<string, int>((object) knownMethods, __vmethodptr(knownMethods, CInt))
        },
        {
          "CLong",
          (object) new Func<string, long>((object) knownMethods, __vmethodptr(knownMethods, CLong))
        },
        {
          "CDbl",
          (object) new Func<string, double>((object) knownMethods, __vmethodptr(knownMethods, CDbl))
        },
        {
          "CDateTime",
          (object) new Func<string, DateTime>((object) knownMethods, __vmethodptr(knownMethods, CDateTime))
        },
        {
          "Mid",
          (object) new Func<string, int, int, string>((object) knownMethods, __vmethodptr(knownMethods, Mid))
        },
        {
          "Strcmpi",
          (object) new Func<string, string, bool>((object) knownMethods, __vmethodptr(knownMethods, Strcmpi))
        },
        {
          "Strcmp",
          (object) new Func<string, string, bool>((object) knownMethods, __vmethodptr(knownMethods, Strcmp))
        },
        {
          "Round",
          (object) new Func<double, int, double>((object) knownMethods, __vmethodptr(knownMethods, Round))
        },
        {
          "Len",
          (object) new Func<string, int>((object) knownMethods, __vmethodptr(knownMethods, Len))
        },
        {
          "Now",
          (object) new Func<DateTime>((object) knownMethods, __vmethodptr(knownMethods, Now))
        },
        {
          "UtcNow",
          (object) new Func<DateTime>((object) knownMethods, __vmethodptr(knownMethods, UtcNow))
        },
        {
          "Truncate",
          (object) new Func<Decimal, Decimal>((object) knownMethods, __vmethodptr(knownMethods, Truncate))
        }
      };
    }

    private static Type GetType(string type)
    {
      if (type == "Integer")
        return typeof (long);
      if (type == "Decimal")
        return typeof (Decimal);
      if (type == "DateTime" || type == "Date")
        return typeof (DateTime);
      if (type == "String")
        ;
      return typeof (string);
    }

    private static object GetValue(string type, string format, object value)
    {
      if (!(type == "Integer"))
      {
        if (!(type == "Decimal"))
        {
          if (type == "String")
            ;
          return value != null ? value : (object) string.Empty;
        }
        string lower = format.ToLower();
        if (lower == "2 decimal")
          return (object) (value == null ? Convert.ToDecimal(0.00M) : System.Math.Round(Convert.ToDecimal(value), 2, MidpointRounding.AwayFromZero));
        if (lower == "3 decimal")
          return (object) (value == null ? Convert.ToDecimal(0.00M) : System.Math.Round(Convert.ToDecimal(value), 3, MidpointRounding.AwayFromZero));
        if (lower == "4 decimal")
          return (object) (value == null ? Convert.ToDecimal(0.00M) : System.Math.Round(Convert.ToDecimal(value), 4, MidpointRounding.AwayFromZero));
        return value != null ? value : (object) Convert.ToDecimal(0.00M);
      }
      return value != null ? value : (object) 0;
    }

    public static void RecalculateUnderwritingSpread(PnLBO pnl, string performTotalPerThousand)
    {
      Decimal seriesParAmount = pnl.SeriesParAmount;
      if (performTotalPerThousand == "0000")
      {
        pnl.ProjectedTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedTakedownPerThousand, seriesParAmount));
        pnl.ActualTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualTakedownPerThousand, seriesParAmount));
        pnl.ProjectedStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedStructuringPerThousand, seriesParAmount));
        pnl.ActualStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualStructuringPerThousand, seriesParAmount));
      }
      else if (performTotalPerThousand == "0001")
      {
        pnl.ProjectedTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedTakedownTotal, seriesParAmount));
        pnl.ActualTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualTakedownTotal, seriesParAmount));
        pnl.ProjectedStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedStructuringPerThousand, seriesParAmount));
        pnl.ActualStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualStructuringPerThousand, seriesParAmount));
      }
      else if (performTotalPerThousand == "0100")
      {
        pnl.ProjectedTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedTakedownPerThousand, seriesParAmount));
        pnl.ActualTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualTakedownPerThousand, seriesParAmount));
        pnl.ProjectedStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedStructuringTotal, seriesParAmount));
        pnl.ActualStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualStructuringTotal, seriesParAmount));
      }
      else if (performTotalPerThousand == "0101")
      {
        pnl.ProjectedTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedTakedownTotal, seriesParAmount));
        pnl.ActualTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualTakedownTotal, seriesParAmount));
        pnl.ProjectedStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedStructuringTotal, seriesParAmount));
        pnl.ActualStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualStructuringTotal, seriesParAmount));
      }
      pnl.ProjectedExpensePerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedExpenseTotal, seriesParAmount));
      pnl.ProjectedExpensePerThousand = new Decimal?(!pnl.ProjectedExpensePerThousand.HasValue ? Convert.ToDecimal(0.00M) : System.Math.Round(Convert.ToDecimal((object) pnl.ProjectedExpensePerThousand), Convert.ToInt32("6"), MidpointRounding.AwayFromZero));
      pnl.ActualExpensePerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualExpenseTotal, seriesParAmount));
      pnl.TakedownDifference = new Decimal?(FormulaHelper.CalculateDifference(pnl.ProjectedTakedownTotal, pnl.ActualTakedownTotal));
      pnl.ExpenseDifference = new Decimal?(FormulaHelper.CalculateDifference(pnl.ProjectedExpenseTotal, pnl.ActualExpenseTotal));
      pnl.StructuringDifference = new Decimal?(FormulaHelper.CalculateDifference(pnl.ProjectedStructuringTotal, pnl.ActualStructuringTotal));
      pnl.ProjectedTotalGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ProjectedTakedownTotal, pnl.ProjectedExpenseTotal, pnl.ProjectedStructuringTotal));
      pnl.ProjectedPerThousandGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ProjectedTakedownPerThousand, pnl.ProjectedExpensePerThousand, pnl.ProjectedStructuringPerThousand));
      pnl.ActualTotalGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ActualTakedownTotal, pnl.ActualExpenseTotal, pnl.ActualStructuringTotal));
      pnl.ActualPerThousandGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ActualTakedownPerThousand, pnl.ActualExpensePerThousand, pnl.ActualStructuringPerThousand));
      pnl.DifferenceGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.TakedownDifference, pnl.ExpenseDifference, pnl.StructuringDifference));
    }

    private static Decimal CalculatePerThousand(
      Decimal? valueToBeCalculate,
      Decimal parAmount)
    {
      Decimal num = 0M;
      if (parAmount > 0M)
      {
        valueToBeCalculate = new Decimal?(!valueToBeCalculate.HasValue ? Convert.ToDecimal(0.00M) : System.Math.Round(Convert.ToDecimal((object) valueToBeCalculate), Convert.ToInt32("2"), MidpointRounding.AwayFromZero));
        num = System.Math.Round(Convert.ToDecimal(Convert.ToDecimal((object) valueToBeCalculate) / parAmount * 1000M), Convert.ToInt32("6"), MidpointRounding.AwayFromZero);
      }
      return num;
    }

    private static Decimal CalculateTotal(Decimal? perThousandValue, Decimal parAmount)
    {
      Decimal num = 0M;
      if (parAmount > 0M)
      {
        perThousandValue = new Decimal?(!perThousandValue.HasValue ? Convert.ToDecimal(0.00M) : System.Math.Round(Convert.ToDecimal((object) perThousandValue), Convert.ToInt32("6"), MidpointRounding.AwayFromZero));
        num = System.Math.Round(Convert.ToDecimal(Convert.ToDecimal(parAmount) / 1000M * Convert.ToDecimal((object) perThousandValue)), Convert.ToInt32("2"), MidpointRounding.AwayFromZero);
      }
      return num;
    }

    private static Decimal CalculateDifference(Decimal? projectedTotal, Decimal? actualTotal) => Convert.ToDecimal((object) projectedTotal) - Convert.ToDecimal((object) actualTotal);

    private static Decimal AddGrossSpreadAmount(
      Decimal? takedownTotal,
      Decimal? expenseTotal,
      Decimal? structuringTotal)
    {
      return Convert.ToDecimal((object) takedownTotal) + Convert.ToDecimal((object) expenseTotal) + Convert.ToDecimal((object) structuringTotal);
    }

    public static bool ValidateFormula(
      string formula,
      object bo,
      string boName,
      Type[] resultType)
    {
      ScopedHash<IrisSoftware.Core.Formula.Validation.VisitResult> resolvedSymbols = new ScopedHash<IrisSoftware.Core.Formula.Validation.VisitResult>();
      resolvedSymbols.Add(boName, new IrisSoftware.Core.Formula.Validation.VisitResult()
      {
        Type = bo.GetType()
      });
      AstNode exprTree = AstParser.Parse(formula);
      FormulaValidatingVisitor validatingVisitor = new FormulaValidatingVisitor((IResolver) new IrisSoftware.Core.Formula.Validation.Resolver(resolvedSymbols, (ScopedHash<string>) null, typeof (IKnownMethods)));
      try
      {
        IrisSoftware.Core.Formula.Validation.VisitResult visitResult = validatingVisitor.Validate(exprTree);
        foreach (Type type in resultType)
        {
          if (visitResult.Type == type)
            return true;
        }
        return false;
      }
      catch
      {
        throw;
      }
    }

    public static object EvaluateFormula(string formula, object bo, string boName)
    {
      Dictionary<string, object> knownKeys = FormulaHelper.GetKnownKeys();
      knownKeys.Add(boName, bo);
      return Interpreter.Interpret(formula, (IDictionary<string, object>) knownKeys);
    }

    public static ScopedHash<string> GetAllFormulae(List<PNLTemplate> fieldList)
    {
      ScopedHash<string> scopedHash = new ScopedHash<string>();
      foreach (PNLTemplate field in fieldList)
      {
        if (!string.IsNullOrEmpty(field.Key) && !scopedHash.ContainsKey(field.Key))
        {
          if (!string.IsNullOrEmpty(field.Formula))
            scopedHash.Add(field.Key, field.Formula);
          else
            scopedHash.Add(field.Key, string.Empty);
        }
      }
      return scopedHash;
    }

    public static List<PNLTemplate> ValidateAndGenerateEvalSequence(
      List<PNLTemplate> fieldList)
    {
      List<PNLTemplate> pnlTemplateList = new List<PNLTemplate>();
      ScopedHash<FormulaSetGeneratorVisitor.VisitResult> knownSymbols = new ScopedHash<FormulaSetGeneratorVisitor.VisitResult>();
      knownSymbols.Add("PnL", new FormulaSetGeneratorVisitor.VisitResult()
      {
        Type = typeof (PnLBO)
      });
      ScopedHash<string> unknownSymbols = new ScopedHash<string>();
      foreach (PNLTemplate field in fieldList)
      {
        if (!string.IsNullOrEmpty(field.Key))
        {
          if (!unknownSymbols.ContainsKey(field.Key))
          {
            if (!string.IsNullOrEmpty(field.Formula))
            {
              unknownSymbols.Add(field.Key, field.Formula);
            }
            else
            {
              knownSymbols.Add(field.Key, new FormulaSetGeneratorVisitor.VisitResult()
              {
                Type = FormulaHelper.GetType(field.DataType)
              });
              pnlTemplateList.Add(field);
            }
          }
        }
        else
          pnlTemplateList.Add(field);
      }
      FormulaSetGeneratorVisitor generatorVisitor = new FormulaSetGeneratorVisitor(knownSymbols, unknownSymbols, typeof (IKnownMethods), "this.", "this.");
      foreach (KeyValuePair<string, string> keyValuePair in unknownSymbols)
      {
        KeyValuePair<string, string> item = keyValuePair;
        PNLTemplate pnlTemplate = fieldList.FirstOrDefault<PNLTemplate>((Func<PNLTemplate, bool>) (_ => _.Key == item.Key));
        if (!knownSymbols.ContainsKey(item.Key))
        {
          if (!string.IsNullOrEmpty(item.Value))
          {
            AstNode exprTree = AstParser.Parse(item.Value);
            FormulaSetGeneratorVisitor.VisitResult visitResult = generatorVisitor.Validate(exprTree, knownSymbols);
            knownSymbols.Add(item.Key, visitResult);
            pnlTemplate.EvaluationSequence = visitResult.Rank;
          }
        }
        else
          pnlTemplate.EvaluationSequence = knownSymbols[item.Key].Rank;
        pnlTemplateList.Add(pnlTemplate);
      }
      return pnlTemplateList;
    }

    public static List<PnLCompetitiveTemplateFields> GenerateScriptForFormula(
      List<PnLCompetitiveTemplateFields> fieldList,
      bool requireFormula = true)
    {
      List<PnLCompetitiveTemplateFields> source = new List<PnLCompetitiveTemplateFields>();
      ScopedHash<FormulaSetGeneratorVisitor.VisitResult> knownSymbols = new ScopedHash<FormulaSetGeneratorVisitor.VisitResult>();
      knownSymbols.Add("PnL", new FormulaSetGeneratorVisitor.VisitResult()
      {
        Type = typeof (PnLCompetitiveBO)
      });
      ScopedHash<string> unknownSymbols = new ScopedHash<string>();
      foreach (PnLCompetitiveTemplateFields field in fieldList)
      {
        if (!string.IsNullOrEmpty(field.Key))
        {
          if (!unknownSymbols.ContainsKey(field.Key))
          {
            if (!string.IsNullOrEmpty(field.Formula))
            {
              unknownSymbols.Add(field.Key, field.Formula);
            }
            else
            {
              knownSymbols.Add(field.Key, new FormulaSetGeneratorVisitor.VisitResult()
              {
                Type = FormulaHelper.GetType(field.DataType)
              });
              source.Add(field);
            }
          }
        }
        else
          source.Add(field);
      }
      FormulaSetGeneratorVisitor generatorVisitor = new FormulaSetGeneratorVisitor(knownSymbols, unknownSymbols, typeof (IKnownMethods), "this.", "this.");
      foreach (KeyValuePair<string, string> keyValuePair in unknownSymbols)
      {
        KeyValuePair<string, string> item = keyValuePair;
        PnLCompetitiveTemplateFields lcompetitiveTemplateFields = fieldList.FirstOrDefault<PnLCompetitiveTemplateFields>((Func<PnLCompetitiveTemplateFields, bool>) (_ => _.Key == item.Key));
        if (!knownSymbols.ContainsKey(item.Key))
        {
          if (!string.IsNullOrEmpty(item.Value))
          {
            AstNode exprTree = AstParser.Parse(item.Value);
            FormulaSetGeneratorVisitor.VisitResult visitResult = generatorVisitor.Validate(exprTree, knownSymbols);
            knownSymbols.Add(item.Key, visitResult);
            if (requireFormula)
              lcompetitiveTemplateFields.Formula = visitResult.ClientScript;
            lcompetitiveTemplateFields.EvaluationSequence = visitResult.Rank;
          }
        }
        else
        {
          if (requireFormula)
            lcompetitiveTemplateFields.Formula = knownSymbols[item.Key].ClientScript;
          lcompetitiveTemplateFields.EvaluationSequence = knownSymbols[item.Key].Rank;
        }
        source.Add(lcompetitiveTemplateFields);
      }
      source.Select<PnLCompetitiveTemplateFields, bool>((Func<PnLCompetitiveTemplateFields, bool>) (x => x.EvaluationSequence > 0)).ToList<bool>();
      return source;
    }

    public static void EvaluateFormula(
      List<PnLCompetitiveTemplateFields> oldPnlFields,
      PnLCompetitiveBO pnl,
      Dictionary<string, object> pnlFieldDetails,
      List<PnLCompetitiveTemplateFields> pnlFieldsForSequence)
    {
      Dictionary<string, object> knownKeys = FormulaHelper.GetKnownKeys();
      knownKeys.Add("PnL", (object) pnl);
      foreach (PnLCompetitiveTemplateFields lcompetitiveTemplateFields in (IEnumerable<PnLCompetitiveTemplateFields>) pnlFieldsForSequence.OrderBy<PnLCompetitiveTemplateFields, int>((Func<PnLCompetitiveTemplateFields, int>) (_ => _.EvaluationSequence)))
      {
        PnLCompetitiveTemplateFields item = lcompetitiveTemplateFields;
        PnLCompetitiveTemplateFields newItem = oldPnlFields.FirstOrDefault<PnLCompetitiveTemplateFields>((Func<PnLCompetitiveTemplateFields, bool>) (_ => _.Key == item.Key));
        if (newItem != null)
          FormulaHelper.SetValues(pnlFieldDetails, knownKeys, item, newItem);
      }
    }

    private static void SetValues(
      Dictionary<string, object> pnlFieldDetails,
      Dictionary<string, object> context,
      PnLCompetitiveTemplateFields item,
      PnLCompetitiveTemplateFields newItem)
    {
      if (string.IsNullOrEmpty(item.Key))
        return;
      if (!item.Overridden && !string.IsNullOrEmpty(newItem.Formula))
      {
        object obj1 = newItem.IsEvaluate ? Interpreter.Interpret(newItem.Formula, (IDictionary<string, object>) context) : (object) newItem.Value;
        object obj2 = FormulaHelper.GetValue(item.DataType, item.Format, obj1);
        context.Add(item.Key, obj2);
        pnlFieldDetails[item.Key] = obj2;
      }
      else
      {
        object obj = FormulaHelper.GetValue(item.DataType, item.Format, pnlFieldDetails[item.Key]);
        context.Add(item.Key, obj);
      }
    }

    public static void RecalculateUnderwritingSpread(
      PnLCompetitiveBO pnl,
      string performTotalPerThousand)
    {
      Decimal seriesParAmount = pnl.SeriesParAmount;
      if (performTotalPerThousand == "0000")
      {
        pnl.ProjectedTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedTakedownPerThousand, seriesParAmount));
        pnl.ActualTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualTakedownPerThousand, seriesParAmount));
        pnl.ProjectedStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedStructuringPerThousand, seriesParAmount));
        pnl.ActualStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualStructuringPerThousand, seriesParAmount));
      }
      else if (performTotalPerThousand == "0001")
      {
        pnl.ProjectedTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedTakedownTotal, seriesParAmount));
        pnl.ActualTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualTakedownTotal, seriesParAmount));
        pnl.ProjectedStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedStructuringPerThousand, seriesParAmount));
        pnl.ActualStructuringTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualStructuringPerThousand, seriesParAmount));
      }
      else if (performTotalPerThousand == "0100")
      {
        pnl.ProjectedTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ProjectedTakedownPerThousand, seriesParAmount));
        pnl.ActualTakedownTotal = new Decimal?(FormulaHelper.CalculateTotal(pnl.ActualTakedownPerThousand, seriesParAmount));
        pnl.ProjectedStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedStructuringTotal, seriesParAmount));
        pnl.ActualStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualStructuringTotal, seriesParAmount));
      }
      else if (performTotalPerThousand == "0101")
      {
        pnl.ProjectedTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedTakedownTotal, seriesParAmount));
        pnl.ActualTakedownPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualTakedownTotal, seriesParAmount));
        pnl.ProjectedStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedStructuringTotal, seriesParAmount));
        pnl.ActualStructuringPerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualStructuringTotal, seriesParAmount));
      }
      pnl.ProjectedExpensePerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ProjectedExpenseTotal, seriesParAmount));
      pnl.ProjectedExpensePerThousand = new Decimal?(!pnl.ProjectedExpensePerThousand.HasValue ? Convert.ToDecimal(0.00M) : System.Math.Round(Convert.ToDecimal((object) pnl.ProjectedExpensePerThousand), Convert.ToInt32("6"), MidpointRounding.AwayFromZero));
      pnl.ActualExpensePerThousand = new Decimal?(FormulaHelper.CalculatePerThousand(pnl.ActualExpenseTotal, seriesParAmount));
      pnl.TakedownDifference = new Decimal?(FormulaHelper.CalculateDifference(pnl.ProjectedTakedownTotal, pnl.ActualTakedownTotal));
      pnl.ExpenseDifference = new Decimal?(FormulaHelper.CalculateDifference(pnl.ProjectedExpenseTotal, pnl.ActualExpenseTotal));
      pnl.StructuringDifference = new Decimal?(FormulaHelper.CalculateDifference(pnl.ProjectedStructuringTotal, pnl.ActualStructuringTotal));
      pnl.ProjectedTotalGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ProjectedTakedownTotal, pnl.ProjectedExpenseTotal, pnl.ProjectedStructuringTotal));
      pnl.ProjectedPerThousandGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ProjectedTakedownPerThousand, pnl.ProjectedExpensePerThousand, pnl.ProjectedStructuringPerThousand));
      pnl.ActualTotalGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ActualTakedownTotal, pnl.ActualExpenseTotal, pnl.ActualStructuringTotal));
      pnl.ActualPerThousandGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.ActualTakedownPerThousand, pnl.ActualExpensePerThousand, pnl.ActualStructuringPerThousand));
      pnl.DifferenceGrossSpread = new Decimal?(FormulaHelper.AddGrossSpreadAmount(pnl.TakedownDifference, pnl.ExpenseDifference, pnl.StructuringDifference));
    }
  }
}
