﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.KnownMethods
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using System;

namespace IrisSoftware.iMPACT.Data.Impl
{
  public class KnownMethods : IKnownMethods
  {
    public string Ucase(string str) => str == null ? string.Empty : str.ToUpper();

    public string Lcase(string str) => str == null ? string.Empty : str.ToLower();

    public string Str(object input) => input.ToString();

    public int CInt(string str) => Convert.ToInt32(str);

    public long CLong(string str) => Convert.ToInt64(str);

    public double CDbl(string str) => Convert.ToDouble(str);

    public DateTime CDateTime(string str) => Convert.ToDateTime(str);

    public string Mid(string str, int startIndex, int length) => str.Substring(startIndex, length);

    public bool Strcmpi(string first, string second) => string.Compare(first, second, true) == 0;

    public bool Strcmp(string first, string second) => string.Compare(first, second, false) == 0;

    public double Round(double value, int decimals)
    {
      if (decimals >= 0)
        return Math.Round(value, decimals, MidpointRounding.AwayFromZero);
      double num = Math.Pow(10.0, (double) -decimals);
      return this.Round(value / num, 0) * num;
    }

    public int Len(string str) => str.Length;

    public DateTime Now() => DateTime.Now;

    public DateTime UtcNow() => DateTime.UtcNow;

    public Decimal Truncate(Decimal value) => Math.Truncate(value);
  }
}
