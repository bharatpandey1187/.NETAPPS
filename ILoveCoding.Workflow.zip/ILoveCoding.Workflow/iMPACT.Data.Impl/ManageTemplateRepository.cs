﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.ManageTemplateRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IManageTemplateRepository))]
  public class ManageTemplateRepository : RepositoryBase, IManageTemplateRepository
  {
    public IDataReader FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityTemplateByLookupID"))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public IEnumerable<ManageTemplate> FetchEntityTemplateByEntityID(
      long entityId,
      long entityTypeDocSetId,
      long appTransactionId,
      int[] principals)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityTemplateByEntityID"))
      {
        List<ManageTemplate> manageTemplateList = new List<ManageTemplate>();
        this.db.AddInParameter(storedProcCommand, "@EntityId", DbType.Int64, (object) entityId);
        this.db.AddInParameter(storedProcCommand, "@EntityTypeDocSetId", DbType.Int64, (object) entityTypeDocSetId);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionId);
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) principals).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<ManageTemplate> rowMapper = MapBuilder<ManageTemplate>.MapAllProperties().DoNotMap<string>((Expression<Func<ManageTemplate, string>>) (x => x.Value)).Build();
          while (dataReader.Read())
            manageTemplateList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<ManageTemplate>) manageTemplateList;
      }
    }

    public void Save(List<ManageTemplate> manageTemplateItem)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEntityTemplateItems"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityTemplateItems_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ManageTemplate>(manageTemplateItem.ToList<ManageTemplate>()));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Copy(List<ManageTemplate> manageTemplateItem)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CopyEntityTemplateItems"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityTemplateItems_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ManageTemplate>(manageTemplateItem.ToList<ManageTemplate>()));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Delete(List<long> lstEntityTemplateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteEntityTemplate"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityTemplateIds_TVP", SqlDbType.Structured, (object) this.GetDataTableFromEntityTemplateIDList(lstEntityTemplateID));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Move(List<ManageTemplate> lstTemplate)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_MoveEntityTemplateItems"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityTemplateItems_TVP", SqlDbType.Structured, (object) this.GetDataTable(lstTemplate));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    private DataTable GetDataTable(List<ManageTemplate> documentList)
    {
      DataTable dataTable = new DataTable("Document");
      PropertyInfo[] properties = typeof (ManageTemplate).GetProperties();
      foreach (PropertyInfo propertyInfo in properties)
      {
        Type type = propertyInfo.PropertyType;
        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>))
          type = Nullable.GetUnderlyingType(type);
        dataTable.Columns.Add(propertyInfo.Name, type);
      }
      foreach (ManageTemplate document in documentList)
      {
        int num = 0;
        object[] objArray = new object[((IEnumerable<PropertyInfo>) properties).Count<PropertyInfo>()];
        foreach (PropertyInfo propertyInfo in properties)
          objArray[num++] = propertyInfo.GetValue((object) document, (object[]) null);
        dataTable.Rows.Add(objArray);
      }
      return dataTable;
    }

    private DataTable GetDataTableFromEntityTemplateIDList(List<long> lstTemplateIDs)
    {
      DataTable dataTable = new DataTable();
      DataColumn column = new DataColumn("Id", typeof (long));
      dataTable.Columns.Add(column);
      foreach (long lstTemplateId in lstTemplateIDs)
      {
        DataRow row = dataTable.NewRow();
        row["Id"] = (object) lstTemplateId;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }
  }
}
