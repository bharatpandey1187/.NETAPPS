﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AuditTrailRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAuditTrailRepository))]
  public class AuditTrailRepository : RepositoryBase, IAuditTrailRepository
  {
    public long Save(AuditTrail theAuditTrail)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveAuditTrail"))
      {
        this.db.AddInParameter(storedProcCommand, "@AuditTrailID", DbType.Int64, (object) theAuditTrail.AuditTrailID);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theAuditTrail.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@When", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@What", DbType.String, (object) theAuditTrail.What);
        this.db.AddInParameter(storedProcCommand, "@Who", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddInParameter(storedProcCommand, "@Entity", DbType.String, (object) theAuditTrail.Entity);
        this.db.AddOutParameter(storedProcCommand, "@ResultAuditTrailID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAuditTrailID"));
      }
    }

    public AuditTrail FetchByKey(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAuditTrailByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@AuditTrailId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<AuditTrail>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new AuditTrail();
      }
    }

    public IEnumerable<AuditTrail> FetchAll()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAllAuditTrail"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<AuditTrail> mapper = MapBuilder<AuditTrail>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AuditTrail>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteAuditTrailByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@AuditTrailId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IEnumerable<AuditTrail> FetchByAppTransactionID(
      long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAuditTrailByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          List<AuditTrail> auditTrailList = new List<AuditTrail>();
          IRowMapper<AuditTrail> rowMapper = MapBuilder<AuditTrail>.MapAllProperties().Build();
          while (dataReader.Read())
          {
            AuditTrail auditTrail = rowMapper.MapRow((IDataRecord) dataReader);
            auditTrailList.Add(auditTrail);
          }
          return (IEnumerable<AuditTrail>) auditTrailList;
        }
      }
    }

    public DataSet FetchAuditTrailReportData(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAuditTrailReportData"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionId);
        DbDataAdapter dataAdapter = this.db.DbProviderFactory.CreateDataAdapter();
        storedProcCommand.Connection = this.db.CreateConnection();
        dataAdapter.SelectCommand = storedProcCommand;
        DataSet dataSet = new DataSet();
        dataAdapter.Fill(dataSet);
        return dataSet;
      }
    }
  }
}
