﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.EntityStateRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IEntityStateRepository))]
  public class EntityStateRepository : RepositoryBase, IEntityStateRepository
  {
    public IEnumerable<EntityState> FetchEntityStateByEntityID(long EntityID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityStateByEntityID"))
      {
        List<EntityState> entityStateList = new List<EntityState>();
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) EntityID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<EntityState> rowMapper = MapBuilder<EntityState>.MapAllProperties().DoNotMap<long>((Expression<Func<EntityState, long>>) (x => x.EntityID)).Build();
          while (dataReader.Read())
            entityStateList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<EntityState>) entityStateList;
      }
    }

    public bool IsEntityStateFreezed(long EntityID, string StateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_IsStateFreezed"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) EntityID);
        this.db.AddInParameter(storedProcCommand, "@StateID", DbType.String, (object) StateID);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public IEnumerable<EntityState> FetchEntityStatesByEntityIDs(
      string entityIds)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityStatesByEntityIDs"))
      {
        List<EntityState> entityStateList = new List<EntityState>();
        this.db.AddInParameter(storedProcCommand, "@entityIDs", DbType.String, (object) entityIds);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<EntityState> rowMapper = MapBuilder<EntityState>.MapAllProperties().Build();
          while (dataReader.Read())
            entityStateList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<EntityState>) entityStateList;
      }
    }
  }
}
