﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AppTransactionDocSetRoleRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAppTransactionDocSetRoleRepository))]
  public class AppTransactionDocSetRoleRepository : IAppTransactionDocSetRoleRepository
  {
    public void Save(
      AppTransactionDocSetRole theAppTransactionDocSetRole)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveAppTransactionDocSetRole"))
      {
        database.AddInParameter(storedProcCommand, "@DocSetID", DbType.Guid, (object) theAppTransactionDocSetRole.DocSetID);
        database.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) theAppTransactionDocSetRole.Principal);
        database.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) theAppTransactionDocSetRole.RoleID);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public AppTransactionDocSetRole FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchAppTransactionDocSetRoleByKey"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionDocSetRoleId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<AppTransactionDocSetRole>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new AppTransactionDocSetRole();
      }
    }

    public IEnumerable<AppTransactionDocSetRole> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllAppTransactionDocSetRole"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<AppTransactionDocSetRole> mapper = MapBuilder<AppTransactionDocSetRole>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppTransactionDocSetRole>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteAppTransactionDocSetRoleByKey"))
      {
        database.AddInParameter(storedProcCommand, "@AppTransactionDocSetRoleId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
