﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.ClientContactRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IClientContactRepository))]
  public class ClientContactRepository : IClientContactRepository
  {
    public void Save(ClientContact theClientContact)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveClientContact"))
      {
        database.AddInParameter(storedProcCommand, "@ClientContactID", DbType.Int64, (object) theClientContact.ClientContactID);
        database.AddInParameter(storedProcCommand, "@ClientID", DbType.Int64, (object) theClientContact.ClientID);
        database.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) theClientContact.Name);
        database.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) theClientContact.Phone);
        database.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) theClientContact.Title);
        database.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) theClientContact.Email);
        database.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) theClientContact.IsActive);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public ClientContact FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchClientContactByKey"))
      {
        database.AddInParameter(storedProcCommand, "@ClientContactId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<ClientContact>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new ClientContact();
      }
    }

    public IEnumerable<ClientContact> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllClientContact"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<ClientContact> mapper = MapBuilder<ClientContact>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<ClientContact>) null;
        }
      }
    }

    public IEnumerable<ClientContact> FetchContactByKey(long currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllClientContact"))
      {
        database.AddInParameter(cmd, "@ClientId", DbType.Int64, (object) currentId);
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<ClientContact> mapper = MapBuilder<ClientContact>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<ClientContact>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteClientContactByKey"))
      {
        database.AddInParameter(storedProcCommand, "@ClientContactId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
