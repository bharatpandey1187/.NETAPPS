﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.IssueManagementRepositry
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IIssueManagementRepository))]
  public class IssueManagementRepositry : RepositoryBase, IIssueManagementRepository, IQuery
  {
    private Dictionary<string, string> knownMappings;

    public IssueManagementRepositry(Dictionary<string, string> knownMappings) => this.knownMappings = new Dictionary<string, string>()
    {
      {
        "FullLegalName",
        "view_IssueManagement.IssuerName"
      },
      {
        "IssueName",
        "view_IssueManagement.IssueName"
      },
      {
        "StateID",
        "view_IssueManagement.StateID"
      },
      {
        "CreatedOn",
        "view_IssueManagement.CreatedOn"
      }
    };

    public IDataReader Query(QueryDefinition definition, int pageSize, int pageNumber)
    {
      SqlCriterionVisitResult criterionVisitResult = new SqlCriterionVisitor((IDictionary<string, string>) this.knownMappings).Build(definition.Criterion);
      string str1 = "IssueName";
      string str2 = "asc";
      if (definition.Order.Length != 0)
      {
        str1 = definition.Order[0].PropertyName;
        str2 = definition.Order[0].Direction.ToString();
      }
      DbCommand sqlStringCommand = this.db.GetSqlStringCommand(string.Format("{0} SELECT count(*) FROM view_IssueManagement WHERE {1}", (object) string.Format(";WITH cte as (SELECT *, ROW_NUMBER() OVER (ORDER BY {0} {1}) AS _row FROM view_IssueManagement WHERE {2}) SELECT * FROM cte WHERE _row BETWEEN {3} AND {4}", (object) str1, (object) str2, (object) criterionVisitResult.WhereClause, (object) (pageNumber + 1), (object) (pageSize + pageNumber)), (object) criterionVisitResult.WhereClause));
      sqlStringCommand.Parameters.AddRange((Array) criterionVisitResult.Parameters);
      return this.db.ExecuteReader(sqlStringCommand);
    }

    public void Delete(string strIssueIds)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteIssueByIdCollection"))
      {
        this.db.AddInParameter(storedProcCommand, "@InputIssueIdCollection", DbType.String, (object) strIssueIds);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
