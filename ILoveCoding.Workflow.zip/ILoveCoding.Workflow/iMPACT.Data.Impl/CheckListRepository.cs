﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.CheckListRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ICheckListRepository))]
  public class CheckListRepository : RepositoryBase, ICheckListRepository
  {
    public IEnumerable<CheckListCategory> FetchCheckListCategoryByEntityId(
      long entityID)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("Usp_FetchAllCheckListCategoryByEntityId"))
      {
        this.db.AddInParameter(cmd, "@EntityID", DbType.Int64, (object) entityID);
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<CheckListCategory> mapper = MapBuilder<CheckListCategory>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<CheckListCategory>) null;
        }
      }
    }

    public long SaveCheckListCategory(CheckListCategory checkListCategory)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_saveCheckListCategory"))
      {
        this.db.AddInParameter(storedProcCommand, "@ChecklistCategoryID", DbType.Int64, (object) checkListCategory.ChecklistCategoryID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) checkListCategory.EntityID);
        this.db.AddInParameter(storedProcCommand, "@Category", DbType.String, (object) checkListCategory.Category);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) checkListCategory.IsActive);
        this.db.AddOutParameter(storedProcCommand, "@OutChecklistCategoryID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutChecklistCategoryID"));
      }
    }

    public void SaveCheckListCategoryItems(
      List<CheckListCategoryItems> checkListCategoryItems)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveCheckListCategoryItems"))
      {
        this.db.AddInParameter(storedProcCommand, "@ChecklistCategoryItemTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<CheckListCategoryItems>(checkListCategoryItems));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IEnumerable<CheckListCategoryItems> FetchByCheckListItemsByCategoryID(
      long? issueChckListCategoryID)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchCheckListItemsByCategoryID"))
      {
        long? nullable1 = issueChckListCategoryID;
        long num = 0;
        if ((nullable1.GetValueOrDefault() == num ? (!nullable1.HasValue ? 1 : 0) : 1) != 0)
        {
          SqlDatabase db = this.db;
          DbCommand command = cmd;
          long? nullable2 = issueChckListCategoryID;
          // ISSUE: variable of a boxed type
          __Boxed<long?> local = (System.ValueType) (nullable2.HasValue ? nullable2 : new long?());
          db.AddInParameter(command, "@CategoryID", DbType.Int64, (object) local);
        }
        else
          this.db.AddInParameter(cmd, "@CategoryID", DbType.Int64, (object) null);
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<CheckListCategoryItems> mapper = MapBuilder<CheckListCategoryItems>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<CheckListCategoryItems>) null;
        }
      }
    }

    public IDataReader FetchReviewCheckListByAppTransactionID(
      long appTransactionID,
      long entityId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_FetchReviewCheckListByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void Save(ReviewChecklist theReviewChecklist)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_SaveReviewChecklist"))
      {
        this.db.AddInParameter(storedProcCommand, "@ReviewCheckListID", DbType.Int64, (object) theReviewChecklist.ReviewCheckListID);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theReviewChecklist.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ReviewChecklistDetailTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<ReviewChecklistDetail>(theReviewChecklist.ReviewChecklistDetail.ToList<ReviewChecklistDetail>()));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public ReviewChecklist FetchReviewChecklist(
      long appTransactionID,
      params string[] keys)
    {
      ReviewChecklist reviewChecklist = new ReviewChecklist();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_FetchReviewChecklistForGuard"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@ChecklistItems", DbType.String, (object) string.Join(",", keys));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          reviewChecklist.AppTransactionID = appTransactionID;
          if (dataReader.Read())
            reviewChecklist.ReviewChecklistDetail.Add(new ReviewChecklistDetail()
            {
              ReviewChecklistDetailID = (long) dataReader["ReviewChecklistDetailID"],
              ChecklistItemID = (long) dataReader["ChecklistItemID"],
              ChecklistItemValue = dataReader["ChecklistItemValue"].ToString()
            });
        }
      }
      return reviewChecklist;
    }
  }
}
