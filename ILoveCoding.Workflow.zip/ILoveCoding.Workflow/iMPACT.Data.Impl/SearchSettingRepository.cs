﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.SearchSettingRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ISearchSettingRepository))]
  public class SearchSettingRepository : RepositoryBase, ISearchSettingRepository
  {
    public IEnumerable<SearchSetting> FetchByModuleName(
      string module,
      long userId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchSearchSettings"))
      {
        this.db.AddInParameter(storedProcCommand, "@module", SqlDbType.VarChar, (object) module);
        this.db.AddInParameter(storedProcCommand, "@Principal", SqlDbType.BigInt, (object) userId);
        List<SearchSetting> searchSettingList = new List<SearchSetting>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<SearchSetting> rowMapper = MapBuilder<SearchSetting>.MapAllProperties().Build();
          while (dataReader.Read())
            searchSettingList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<SearchSetting>) searchSettingList;
      }
    }

    public void Save(SearchSetting searchSetting)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveSearchSetting"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principal", SqlDbType.BigInt, (object) searchSetting.UserId);
        this.db.AddInParameter(storedProcCommand, "@SearchSettingID", SqlDbType.BigInt, (object) searchSetting.SearchSettingID);
        this.db.AddInParameter(storedProcCommand, "@Name", SqlDbType.VarChar, (object) searchSetting.Name);
        this.db.AddInParameter(storedProcCommand, "@Criteria", SqlDbType.NVarChar, (object) searchSetting.Criteria);
        this.db.AddInParameter(storedProcCommand, "@GridSetting", SqlDbType.NVarChar, (object) searchSetting.GridSetting);
        this.db.AddInParameter(storedProcCommand, "@Module", SqlDbType.VarChar, (object) searchSetting.Module);
        this.db.AddInParameter(storedProcCommand, "@Public", SqlDbType.Bit, (object) searchSetting.Public);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Delete(long searchSettingId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteSearchSetting"))
      {
        this.db.AddInParameter(storedProcCommand, "@SearchSettingID", SqlDbType.BigInt, (object) searchSettingId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
