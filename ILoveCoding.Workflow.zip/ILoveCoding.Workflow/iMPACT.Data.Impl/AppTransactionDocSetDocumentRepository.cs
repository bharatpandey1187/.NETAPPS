﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AppTransactionDocSetDocumentRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAppTransactionDocSetDocumentRepository))]
  public class AppTransactionDocSetDocumentRepository : RepositoryBase, IAppTransactionDocSetDocumentRepository
  {
    public List<Document> GetDocuments(long apptransactionID, long docSetType)
    {
      List<Document> documentList = new List<Document>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAppTransactionDocSetDocument"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) apptransactionID);
        this.db.AddInParameter(storedProcCommand, "@DocSetType", DbType.Int64, (object) docSetType);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            IRowMapper<Document> rowMapper = MapBuilder<Document>.MapAllProperties().DoNotMap<bool>((Expression<Func<Document, bool>>) (x => x.ExistsInSameDocSet)).Build();
            documentList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
      }
      return documentList;
    }

    public Document GetDocument(long appTransactionDocSetDocumentID)
    {
      Document document = (Document) null;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_FetchDocument]"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionDocSetDocumentID", DbType.Int64, (object) appTransactionDocSetDocumentID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            document = MapBuilder<Document>.MapAllProperties().DoNotMap<bool>((Expression<Func<Document, bool>>) (x => x.ExistsInSameDocSet)).Build().MapRow((IDataRecord) dataReader);
        }
      }
      return document;
    }

    public List<Document> GetDocumentsToBeCopiedToTransaction(
      long apptransactionID,
      long docSetType)
    {
      List<Document> documentList = new List<Document>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchDocSetDocumentsToBeCopiedToTransaction"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) apptransactionID);
        this.db.AddInParameter(storedProcCommand, "@DocSetType", DbType.Int64, (object) docSetType);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            IRowMapper<Document> rowMapper = MapBuilder<Document>.MapAllProperties().DoNotMap<bool>((Expression<Func<Document, bool>>) (x => x.ExistsInSameDocSet)).Build();
            documentList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
      }
      return documentList;
    }

    public List<Document> GetDocumentsByAppTransactionDocSetDocumentIDs(
      List<long> appTransactionDocSetDocumentIDList)
    {
      List<Document> documentList = new List<Document>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_FetchDocumentsByAppTransactionDocSetDocumentID]"))
      {
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionDocSetDocumentID", SqlDbType.Structured, (object) this.GetDataTableFromAppTransactionDocSetDocumentIDList(appTransactionDocSetDocumentIDList));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            IRowMapper<Document> rowMapper = MapBuilder<Document>.MapAllProperties().DoNotMap<bool>((Expression<Func<Document, bool>>) (x => x.ExistsInSameDocSet)).Build();
            documentList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
      }
      return documentList;
    }

    public List<Document> GetDocumentsFromDocumentQueue()
    {
      List<Document> documentList = new List<Document>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchDocsFromDocumentQueue"))
      {
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            IRowMapper<Document> rowMapper = MapBuilder<Document>.MapAllProperties().DoNotMap<bool>((Expression<Func<Document, bool>>) (x => x.ExistsInSameDocSet)).Build();
            documentList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
      }
      return documentList;
    }

    public void Save(Document document)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveAppTransactionDocSetDocument"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) document.EntityID);
        long result;
        if (long.TryParse(document.DocSetId, out result))
          this.db.AddInParameter(storedProcCommand, "@DocSetID", DbType.Int64, (object) result);
        else
          this.db.AddInParameter(storedProcCommand, "@DocSetID", DbType.Int64, (object) DBNull.Value);
        this.db.AddInParameter(storedProcCommand, "@DocumentID", DbType.String, (object) document.DocumentId);
        this.db.AddInParameter(storedProcCommand, "@DocumentURL", DbType.String, (object) document.DocumentURL);
        this.db.AddInParameter(storedProcCommand, "@DocumentListID", DbType.String, (object) document.DocumentListID);
        this.db.AddInParameter(storedProcCommand, "@UIVersionLabel", DbType.String, (object) document.UIVersionLabel);
        this.db.AddInParameter(storedProcCommand, "@TotalVersion", DbType.Int32, (object) document.TotalVersion);
        this.db.AddInParameter(storedProcCommand, "@CheckoutType", DbType.String, (object) document.CheckOutType);
        this.db.AddInParameter(storedProcCommand, "@LastModifiedBy", DbType.String, (object) document.LastModifiedBy);
        this.db.AddInParameter(storedProcCommand, "@LastModifiedOn", DbType.DateTime, (object) document.LastModifiedOn);
        this.db.AddInParameter(storedProcCommand, "@CheckedoutBy", DbType.String, (object) document.CheckedOutBy);
        DateTime? nullable = document.CheckedOutDate;
        if (nullable.HasValue)
          this.db.AddInParameter(storedProcCommand, "@CheckedoutDate", DbType.DateTime, (object) document.CheckedOutDate);
        else
          this.db.AddInParameter(storedProcCommand, "@CheckedoutDate", DbType.DateTime, (object) DBNull.Value);
        nullable = document.CheckedOutExpires;
        if (nullable.HasValue)
          this.db.AddInParameter(storedProcCommand, "@CheckedOutExpires", DbType.DateTime, (object) document.CheckedOutExpires);
        else
          this.db.AddInParameter(storedProcCommand, "@CheckedOutExpires", DbType.DateTime, (object) DBNull.Value);
        this.db.AddInParameter(storedProcCommand, "@StorageKey", DbType.String, (object) document.StorageKey);
        this.db.AddInParameter(storedProcCommand, "@CheckoutDocumentID", DbType.String, (object) document.CheckOutDocumentId);
        this.db.AddInParameter(storedProcCommand, "@DocumentName", DbType.String, (object) document.DocumentName);
        this.db.AddInParameter(storedProcCommand, "@Category", DbType.String, (object) document.EntityTypeDocTypeCategoryID);
        this.db.AddInParameter(storedProcCommand, "@DocType", DbType.String, (object) document.EntityTypeDocTypeID);
        this.db.AddInParameter(storedProcCommand, "@TypeOtherDesc", DbType.String, (object) document.TypeOtherDesc);
        this.db.AddInParameter(storedProcCommand, "@Tags", DbType.String, (object) document.Tags);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Update(Document document)
    {
      List<Document> documentList = new List<Document>();
      documentList.Add(document);
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_UpdateAppTransactionDocSetDocument"))
      {
        this.db.AddInParameter(storedProcCommand, "@tblDocument", SqlDbType.Structured, (object) this.GetDataTable(documentList));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Delete(long appTransactionDocSetDocumentID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteDocument"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionDocSetDocumentID", DbType.Int64, (object) appTransactionDocSetDocumentID);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void SaveToDocumentLog(
      long entityTypeId,
      long appTransactionId,
      string documentName,
      long DocumentTypeId,
      DateTime documentLogDateTime,
      string actionPerformed,
      string actionPerformedBy)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_InsertDocumentLog"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityTypeId", DbType.Int64, (object) entityTypeId);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        this.db.AddInParameter(storedProcCommand, "@DocumentName", DbType.String, (object) documentName);
        this.db.AddInParameter(storedProcCommand, "@DocumentTypeId", DbType.Int64, (object) DocumentTypeId);
        this.db.AddInParameter(storedProcCommand, "@DocumentLogDateTime", DbType.DateTime, (object) documentLogDateTime);
        this.db.AddInParameter(storedProcCommand, "@ActionPerformed", DbType.String, (object) actionPerformed);
        this.db.AddInParameter(storedProcCommand, "@ActionPerformedBy", DbType.String, (object) actionPerformedBy);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Move(List<Document> documentList)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_UpdateAppTransactionDocSetDocument"))
      {
        this.db.AddInParameter(storedProcCommand, "@tblDocument", SqlDbType.Structured, (object) this.GetDataTable(documentList));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Copy(List<Document> documentList)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CopyAppTransactionDocSetDocument"))
      {
        this.db.AddInParameter(storedProcCommand, "@tblDocument", SqlDbType.Structured, (object) this.GetDataTable(documentList));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    private DataTable GetDataTableFromAppTransactionDocSetDocumentIDList(
      List<long> DocumentIDList)
    {
      DataTable dataTable = new DataTable();
      DataColumn column = new DataColumn("Id", typeof (long));
      dataTable.Columns.Add(column);
      foreach (long documentId in DocumentIDList)
      {
        DataRow row = dataTable.NewRow();
        row["Id"] = (object) documentId;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    private DataTable GetDataTable(List<Document> documentList)
    {
      DataTable dataTable = new DataTable("Document");
      PropertyInfo[] properties = typeof (Document).GetProperties();
      foreach (PropertyInfo propertyInfo in properties)
      {
        Type type = propertyInfo.PropertyType;
        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>))
          type = Nullable.GetUnderlyingType(type);
        dataTable.Columns.Add(propertyInfo.Name, type);
      }
      foreach (Document document in documentList)
      {
        int num = 0;
        object[] objArray = new object[((IEnumerable<PropertyInfo>) properties).Count<PropertyInfo>()];
        foreach (PropertyInfo propertyInfo in properties)
          objArray[num++] = propertyInfo.GetValue((object) document, (object[]) null);
        dataTable.Rows.Add(objArray);
      }
      return dataTable;
    }
  }
}
