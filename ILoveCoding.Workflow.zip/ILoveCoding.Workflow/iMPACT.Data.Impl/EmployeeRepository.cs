﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.EmployeeRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IEmployeeRepository))]
  public class EmployeeRepository : RepositoryBase, IEmployeeRepository
  {
    public long Save(Employee theEmployee)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEmployee"))
      {
        this.db.AddInParameter(storedProcCommand, "@EmployeeID", DbType.Int64, (object) theEmployee.EmployeeID);
        this.db.AddInParameter(storedProcCommand, "@EmpNbr", DbType.String, (object) theEmployee.EmpNbr);
        this.db.AddInParameter(storedProcCommand, "@FullName", DbType.String, (object) theEmployee.FullName);
        this.db.AddInParameter(storedProcCommand, "@Address", DbType.String, (object) theEmployee.StreetAddress);
        this.db.AddInParameter(storedProcCommand, "@City", DbType.String, (object) theEmployee.City);
        this.db.AddInParameter(storedProcCommand, "@Zip", DbType.String, (object) theEmployee.Zip);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) theEmployee.Phone);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) theEmployee.Title);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) theEmployee.Email);
        SqlDatabase db = this.db;
        DbCommand command = storedProcCommand;
        long? state = theEmployee.State;
        // ISSUE: variable of a boxed type
        __Boxed<long?> local = (System.ValueType) (state.HasValue ? state : new long?());
        db.AddInParameter(command, "@State", DbType.Int64, (object) local);
        this.db.AddInParameter(storedProcCommand, "@WindowID", DbType.String, (object) theEmployee.WindowID);
        this.db.AddInParameter(storedProcCommand, "@KerberosID", DbType.String, (object) theEmployee.KerberosID);
        this.db.AddInParameter(storedProcCommand, "@CostCenter", DbType.String, (object) theEmployee.CostCenter);
        this.db.AddInParameter(storedProcCommand, "@AppRoles", DbType.String, (object) theEmployee.SysRolesValues);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) theEmployee.IsActive);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int32, (object) theEmployee.Principal);
        this.db.AddInParameter(storedProcCommand, "@ROGroupPrincipal", DbType.Int32, (object) theEmployee.ROGroupPrincipal);
        this.db.AddInParameter(storedProcCommand, "@SupportGroupPrincipal", DbType.Int32, (object) theEmployee.SupportGroupPrincipal);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddOutParameter(storedProcCommand, "@OutEmployeeID", DbType.Int64, 0);
        this.db.AddInParameter(storedProcCommand, "@Fax", DbType.String, (object) theEmployee.Fax);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutEmployeeID"));
      }
    }

    public IEnumerable<AppRoles> FetchAplicationRoles(string entity)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchAppRoles"))
      {
        this.db.AddInParameter(cmd, "@Entity", DbType.String, (object) entity);
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<AppRoles> mapper = MapBuilder<AppRoles>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<AppRoles>) null;
        }
      }
    }

    public IEnumerable<GroupRole> FetchGroupRoles()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchGroupRoles"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<GroupRole> mapper = MapBuilder<GroupRole>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<GroupRole>) null;
        }
      }
    }

    public Employee FetchByKey(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmployeeByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@EmployeeId", DbType.Int32, (object) currentId);
        Employee employee1 = new Employee();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          if (dataReader.Read())
          {
            Employee employee2 = MapBuilder<Employee>.MapAllProperties().DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.PlatformRoles)).Build().MapRow((IDataRecord) dataReader);
            if (dataReader.NextResult())
            {
              string str = string.Empty;
              while (dataReader.Read())
                str = !(str == string.Empty) ? string.Format("{0},{1}", (object) str, (object) dataReader.GetString(0)) : dataReader.GetString(0);
              employee2.PlatformRoles = str;
            }
            return employee2;
          }
          employee1.IsActive = true;
          return employee1;
        }
      }
    }

    public IEnumerable<Employee> FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllEmployee"))
      {
        List<Employee> employeeList = new List<Employee>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Employee> rowMapper1 = MapBuilder<Employee>.MapAllProperties().DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.SysRolesValues)).DoNotMap<long?>((Expression<Func<Employee, long?>>) (x => x.PlatformRole)).Build();
          while (dataReader.Read())
            employeeList.Add(rowMapper1.MapRow((IDataRecord) dataReader));
          List<GroupRole> source = new List<GroupRole>();
          IRowMapper<GroupRole> rowMapper2 = MapBuilder<GroupRole>.MapAllProperties().Build();
          if (dataReader.NextResult())
          {
            while (dataReader.Read())
              source.Add(rowMapper2.MapRow((IDataRecord) dataReader));
          }
          foreach (Employee employee1 in employeeList)
          {
            Employee employee = employee1;
            employee.GroupRoles = source.Where<GroupRole>((Func<GroupRole, bool>) (x => x.EmployeeID == employee.EmployeeID)).ToList<GroupRole>();
          }
        }
        return (IEnumerable<Employee>) employeeList;
      }
    }

    public IEnumerable<Employee> FetchAllEmployeeByRoles(
      string employeeFullName,
      long roleTypeId,
      long entityId,
      bool includeInActive)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmployeeAutoComplete"))
      {
        this.db.AddInParameter(storedProcCommand, "@FullName", DbType.String, (object) employeeFullName);
        this.db.AddInParameter(storedProcCommand, "@RoleTypeId", DbType.Int64, (object) roleTypeId);
        this.db.AddInParameter(storedProcCommand, "@EntityId", DbType.Int64, (object) entityId);
        this.db.AddInParameter(storedProcCommand, "@IncludeInActive", DbType.Boolean, (object) includeInActive);
        List<Employee> employeeList = new List<Employee>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Employee> rowMapper = MapBuilder<Employee>.MapAllProperties().DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.StreetAddress)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.City)).DoNotMap<long?>((Expression<Func<Employee, long?>>) (x => x.State)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.StateName)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.Zip)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.PlatformRoles)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.SysRolesValues)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.KerberosID)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.CostCenter)).Build();
          while (dataReader.Read())
            employeeList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          return (IEnumerable<Employee>) employeeList;
        }
      }
    }

    public IEnumerable<Employee> FetchAllEmployeeIrrespectiveOfRole(
      string employeeFullName,
      bool includeInActive)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmployeeIrrespectiveOfRoleAutoComplete"))
      {
        this.db.AddInParameter(storedProcCommand, "@FullName", DbType.String, (object) employeeFullName);
        this.db.AddInParameter(storedProcCommand, "@IncludeInActive", DbType.Boolean, (object) includeInActive);
        List<Employee> employeeList = new List<Employee>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Employee> rowMapper = MapBuilder<Employee>.MapAllProperties().DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.StreetAddress)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.City)).DoNotMap<long?>((Expression<Func<Employee, long?>>) (x => x.State)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.StateName)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.Zip)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.PlatformRoles)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.SysRolesValues)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.KerberosID)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.CostCenter)).Build();
          while (dataReader.Read())
            employeeList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          return (IEnumerable<Employee>) employeeList;
        }
      }
    }

    public IEnumerable<Employee> FetchEmployeeAutoCompleteByFullName(
      string employeeFullName,
      bool IsUserProfile)
    {
      if (IsUserProfile)
      {
        using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmployeeAutoCompleteByFullNameUPS"))
        {
          this.db.AddInParameter(storedProcCommand, "@FullName", DbType.String, (object) employeeFullName);
          List<Employee> employeeList = new List<Employee>();
          using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          {
            IRowMapper<Employee> rowMapper = MapBuilder<Employee>.MapAllProperties().DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.PlatformRoles)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.SysRolesValues)).Build();
            while (dataReader.Read())
              employeeList.Add(rowMapper.MapRow((IDataRecord) dataReader));
            return (IEnumerable<Employee>) employeeList;
          }
        }
      }
      else
      {
        using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmployeeAutoCompleteByFullName"))
        {
          this.db.AddInParameter(storedProcCommand, "@FullName", DbType.String, (object) employeeFullName);
          List<Employee> employeeList = new List<Employee>();
          using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          {
            IRowMapper<Employee> rowMapper = MapBuilder<Employee>.MapAllProperties().DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.StreetAddress)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.City)).DoNotMap<long?>((Expression<Func<Employee, long?>>) (x => x.State)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.StateName)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.Zip)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.PlatformRoles)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.SysRolesValues)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.KerberosID)).DoNotMap<string>((Expression<Func<Employee, string>>) (x => x.CostCenter)).Build();
            while (dataReader.Read())
              employeeList.Add(rowMapper.MapRow((IDataRecord) dataReader));
            return (IEnumerable<Employee>) employeeList;
          }
        }
      }
    }

    public List<Role> FetchEmployeeRolesByPrincipal(int principal)
    {
      List<Role> roleList = new List<Role>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEmployeeRolesByPrincipal"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int32, (object) principal);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Role> rowMapper = MapBuilder<Role>.MapAllProperties().Build();
          while (dataReader.Read())
            roleList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return roleList;
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteEmployeeByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@EmployeeId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public int FetchUsersCount()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchUsersCount"))
        return (int) this.db.ExecuteScalar(storedProcCommand);
    }

    public void UpdateGroupPrincipals(
      int principal,
      int roGroupPrincipal,
      int supportGroupPrincipal)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_UpdateGroupPrincipalsByPrincipalID"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int32, (object) principal);
        this.db.AddInParameter(storedProcCommand, "@ROGroupPrincipal", DbType.Int32, (object) roGroupPrincipal);
        this.db.AddInParameter(storedProcCommand, "@SupportGroupPrincipal", DbType.Int32, (object) supportGroupPrincipal);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public bool CheckIsEmployeeActive(int? EmployeeID)
    {
      if (!EmployeeID.HasValue)
        return false;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_IsEmployeeActive"))
      {
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int32, (object) EmployeeID);
        return this.db.ExecuteScalar(storedProcCommand).ToString() == "1";
      }
    }

    public List<EmployeeUPSMapping> FetchSPUserProfileMapping()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchSPUserProfileMapping"))
      {
        List<EmployeeUPSMapping> employeeUpsMappingList = new List<EmployeeUPSMapping>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<EmployeeUPSMapping> rowMapper = MapBuilder<EmployeeUPSMapping>.MapAllProperties().Build();
          while (dataReader.Read())
            employeeUpsMappingList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return employeeUpsMappingList;
      }
    }

    public void SaveToUserLog(
      string userName,
      DateTime userLogDateTime,
      string email,
      string effectivePrincipalIds)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_InsertUserLog"))
      {
        this.db.AddInParameter(storedProcCommand, "@UserName", DbType.String, (object) userName);
        this.db.AddInParameter(storedProcCommand, "@UserLogDateTime", DbType.DateTime, (object) userLogDateTime);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) email);
        this.db.AddInParameter(storedProcCommand, "@EffectivePrincipalIds", DbType.String, (object) effectivePrincipalIds);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
