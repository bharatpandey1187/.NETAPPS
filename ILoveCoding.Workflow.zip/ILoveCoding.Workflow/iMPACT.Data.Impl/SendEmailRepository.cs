﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.SendEmailRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ISendEmailRepository))]
  public class SendEmailRepository : RepositoryBase, ISendEmailRepository
  {
    public void GetSmtpInfo(out string smtpHost, out string smtpPort)
    {
      smtpHost = string.Empty;
      smtpPort = string.Empty;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchSmtpDetails"))
      {
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            if (dataReader["KEY"].ToString() == "SMTPHost")
              smtpHost = dataReader["value"].ToString();
            else if (dataReader["KEY"].ToString() == "SMTPPort")
              smtpPort = dataReader["value"].ToString();
          }
        }
      }
    }

    public void SaveToEmailLog(
      DateTime sent,
      string from,
      string To,
      string Cc,
      string subject,
      string body)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_InsertEmailLog"))
      {
        this.db.AddInParameter(storedProcCommand, "@Sent", DbType.DateTime, (object) sent);
        this.db.AddInParameter(storedProcCommand, "@From", DbType.String, (object) from);
        this.db.AddInParameter(storedProcCommand, "@To", DbType.String, (object) To);
        this.db.AddInParameter(storedProcCommand, "@Cc", DbType.String, (object) Cc);
        this.db.AddInParameter(storedProcCommand, "@Subject", DbType.String, (object) subject);
        this.db.AddInParameter(storedProcCommand, "@Body", DbType.String, (object) body);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
