﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.SearchFieldsConfigRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ISearchFieldsConfigRepository))]
  public class SearchFieldsConfigRepository : ISearchFieldsConfigRepository
  {
    public void Save(SearchFieldsConfig theSearchFieldsConfig)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveSearchFieldsConfig"))
      {
        database.AddInParameter(storedProcCommand, "@SearchFieldsConfigID", DbType.Int32, (object) theSearchFieldsConfig.SearchFieldsConfigID);
        database.AddInParameter(storedProcCommand, "@EntityType", DbType.String, (object) theSearchFieldsConfig.EntityType);
        database.AddInParameter(storedProcCommand, "@UIFieldName", DbType.String, (object) theSearchFieldsConfig.UIFieldName);
        database.AddInParameter(storedProcCommand, "@SPFieldName", DbType.String, (object) theSearchFieldsConfig.SPFieldName);
        database.AddInParameter(storedProcCommand, "@SPFieldType", DbType.String, (object) theSearchFieldsConfig.SPFieldType);
        database.AddInParameter(storedProcCommand, "@SQLFieldName", DbType.String, (object) theSearchFieldsConfig.SQLFieldName);
        database.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) theSearchFieldsConfig.CreatedBy);
        database.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) theSearchFieldsConfig.CreatedOn);
        database.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) theSearchFieldsConfig.ModifiedBy);
        database.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) theSearchFieldsConfig.ModifiedOn);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public SearchFieldsConfig FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchSearchFieldsConfigByKey"))
      {
        database.AddInParameter(storedProcCommand, "@SearchFieldsConfigId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<SearchFieldsConfig>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new SearchFieldsConfig();
      }
    }

    public IEnumerable<SearchFieldsConfig> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllSearchFieldsConfig"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<SearchFieldsConfig> mapper = MapBuilder<SearchFieldsConfig>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<SearchFieldsConfig>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteSearchFieldsConfigByKey"))
      {
        database.AddInParameter(storedProcCommand, "@SearchFieldsConfigId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
