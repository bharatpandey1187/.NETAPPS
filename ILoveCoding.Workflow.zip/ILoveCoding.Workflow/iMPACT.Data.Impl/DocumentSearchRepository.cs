﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.DocumentSearchRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IDocumentSearchRepository))]
  public class DocumentSearchRepository : RepositoryBase, IDocumentSearchRepository, IQuery
  {
    private Dictionary<string, string> knownMappings;

    [Dependency]
    public ISearchSettingRepository SearchSettingRepository { get; set; }

    public DocumentSearchRepository(Dictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public IDataReader SearchDocument(DataTable table)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DocumentSearch"))
      {
        this.db.AddInParameter(storedProcCommand, "@Documents_TVP", SqlDbType.Structured, (object) table);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchAllEntityTypes(int showSearchEntityType)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllEntityTypes"))
      {
        this.db.AddInParameter(storedProcCommand, "@ShowSearchEntityType", SqlDbType.Int, (object) showSearchEntityType);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IEnumerable<SearchSetting> FetchDocumentBookmarks() => this.SearchSettingRepository.FetchByModuleName("Document Search", (long) this.AppUser.Id);

    public void SaveDocumentBookMark(SearchSetting searchSetting)
    {
      searchSetting.Module = "Document Search";
      searchSetting.UserId = (long) this.AppUser.Id;
      this.SearchSettingRepository.Save(searchSetting);
    }

    public void DeleteBookMark(long bookmarkId) => this.SearchSettingRepository.Delete(bookmarkId);

    public IDataReader Query(QueryDefinition definition, int pageSize, int pageNumber)
    {
      SqlCriterionVisitResult criterionVisitResult = new SqlCriterionVisitor((IDictionary<string, string>) this.knownMappings).Build(definition.Criterion);
      string str = string.Empty;
      foreach (Ordering ordering in definition.Order)
        str = string.Format("{0}{1} {2},", (object) str, (object) ordering.PropertyName, (object) ordering.Direction);
      DbCommand sqlStringCommand = this.db.GetSqlStringCommand(string.Format("{0}  SELECT count(DISTINCT EntityDocSetDocumentID) FROM View_Document WHERE {1}", (object) string.Format(";WITH cte as (SELECT *, ROW_NUMBER() OVER (ORDER BY {0}) AS _row FROM (Select Distinct EntityDocSetDocumentID,\r\n\t\t\tAppTransactionID,EntityTypeID,DealNumber,DealName,DealStatus,DealIssuer,DealBorrower, DealIssuerName,DealFirmRole,ParAmount,DocumentName,DocumentURL,DocumentType,Repository,UploadDate,DocumentRepository,\r\n\t\t\tSelectedDocumentTags, SourceLocation,JobNumbers,MSBankingGroup,DealBorrowerName,CategoryName,TransactionDescription,OpportunityDescription FROM View_Document WHERE {1})k) SELECT * FROM cte WHERE _row BETWEEN {2} AND {3}", (object) (string.IsNullOrEmpty(str) ? "DealName asc" : str.Substring(0, str.Length - 1)), (object) criterionVisitResult.WhereClause, (object) (pageNumber + 1), (object) (pageSize + pageNumber)), (object) criterionVisitResult.WhereClause));
      sqlStringCommand.Parameters.AddRange((Array) criterionVisitResult.Parameters);
      return this.db.ExecuteReader(sqlStringCommand);
    }
  }
}
