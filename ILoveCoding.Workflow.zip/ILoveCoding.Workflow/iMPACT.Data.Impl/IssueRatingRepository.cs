﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.IssueRatingRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IIssueRatingRepository))]
  public class IssueRatingRepository : RepositoryBase, IIssueRatingRepository
  {
    public IDataReader FetchSeriesDetails(long appTransId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchSeriesInfoByAppTransID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Double, (object) appTransId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchEnhancedRatingDetails(long appTransId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEnhancedRatingInfoByAppTransID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Double, (object) appTransId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void SaveIssueRatings(
      DataTable underlyingRatings,
      long appTransactionID,
      DataTable enhancedRating)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveIssueRatings"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Double, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@IssueRatings_TVP", SqlDbType.Structured, (object) underlyingRatings);
        this.db.AddInParameter(storedProcCommand, "@EnhancedRatings_TVP", SqlDbType.Structured, (object) enhancedRating);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IDataReader FetchCEProvidersByName(string name)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchCEProviderByName"))
      {
        this.db.AddInParameter(storedProcCommand, "@ProviderSearchString", DbType.String, (object) RepositoryBase.EscapeForLike(name));
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
