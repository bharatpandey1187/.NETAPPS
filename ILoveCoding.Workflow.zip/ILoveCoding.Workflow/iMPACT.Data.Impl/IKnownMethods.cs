﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.IKnownMethods
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using System;

namespace IrisSoftware.iMPACT.Data.Impl
{
  public interface IKnownMethods
  {
    string Ucase(string str);

    string Lcase(string str);

    string Str(object input);

    int CInt(string str);

    long CLong(string str);

    double CDbl(string str);

    DateTime CDateTime(string str);

    string Mid(string str, int startIndex, int length);

    bool Strcmpi(string first, string second);

    bool Strcmp(string first, string second);

    double Round(double value, int decimals);

    int Len(string str);

    DateTime Now();

    DateTime UtcNow();

    Decimal Truncate(Decimal value);
  }
}
