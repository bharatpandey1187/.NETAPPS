﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.BidCalendarRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IBidCalendarRepository))]
  public class BidCalendarRepository : RepositoryBase, IBidCalendarRepository
  {
    public IDataReader FetchAll(bool? IsActive = null)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_GetAllBids"))
      {
        if (IsActive.HasValue)
          this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) IsActive.Value);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void ShortListBidByIssueID(long issueID, string ModifiedBy)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_ShortlistByIssueID"))
      {
        this.db.AddInParameter(storedProcCommand, "@issueID", DbType.Int64, (object) issueID);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) ModifiedBy);
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) 3);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
