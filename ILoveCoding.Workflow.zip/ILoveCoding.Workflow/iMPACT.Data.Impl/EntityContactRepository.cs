﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.EntityContactRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IEntityContactRepository))]
  public class EntityContactRepository : RepositoryBase, IEntityContactRepository
  {
    public IssueClientContactAddress FetchIssueClientContactsByKey(
      long currentId,
      long appTransactionID,
      string clientType)
    {
      IssueClientContactAddress clientContactAddress = new IssueClientContactAddress();
      List<IssueClientContact> issueClientContactList = new List<IssueClientContact>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssueClientContactByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@ClientId", DbType.Int64, (object) currentId);
        this.db.AddInParameter(storedProcCommand, "@ClientType", DbType.String, (object) clientType);
        if (appTransactionID != 0L)
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        else
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) null);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<IssueClientContact> rowMapper = MapBuilder<IssueClientContact>.MapAllProperties().Build();
          while (reader.Read())
            issueClientContactList.Add(rowMapper.MapRow((IDataRecord) reader));
          clientContactAddress.IssueClientContact = issueClientContactList;
          if (reader.NextResult())
            clientContactAddress.ClientActiveAddress = this.GetClientActiveAddress(reader);
        }
        return clientContactAddress;
      }
    }

    private List<ClientActiveAddress> GetClientActiveAddress(
      IDataReader reader)
    {
      List<ClientActiveAddress> clientActiveAddressList = new List<ClientActiveAddress>();
      IRowMapper<ClientActiveAddress> rowMapper = MapBuilder<ClientActiveAddress>.MapAllProperties().Build();
      while (reader.Read())
        clientActiveAddressList.Add(rowMapper.MapRow((IDataRecord) reader));
      return clientActiveAddressList;
    }

    public long SaveIssueClientContacts(
      IssueClientContact issueClientContact,
      out string clientName)
    {
      clientName = string.Empty;
      long int64;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveClientContact"))
      {
        this.db.AddInParameter(storedProcCommand, "@ClientID", DbType.Int64, (object) issueClientContact.ClientID);
        this.db.AddInParameter(storedProcCommand, "@ClientContactID", DbType.Int64, (object) issueClientContact.ClientContactID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) issueClientContact.ClientContactName);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) issueClientContact.Title);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) issueClientContact.Phone);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) issueClientContact.Email);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) issueClientContact.IsActive);
        this.db.AddInParameter(storedProcCommand, "@IsDefault", DbType.Boolean, (object) issueClientContact.IsDefault);
        this.db.AddInParameter(storedProcCommand, "@IsG17Contact", DbType.Boolean, (object) issueClientContact.IsG17Contact);
        this.db.AddInParameter(storedProcCommand, "@ContactAddressID", DbType.Int64, (object) issueClientContact.ContactAddressID);
        this.db.AddInParameter(storedProcCommand, "@NameTitle", DbType.Int16, (object) issueClientContact.NameTitle);
        this.db.AddInParameter(storedProcCommand, "@FirstName", DbType.String, (object) issueClientContact.FirstName);
        this.db.AddInParameter(storedProcCommand, "@LastName", DbType.String, (object) issueClientContact.LastName);
        this.db.AddInParameter(storedProcCommand, "@Suffix", DbType.String, (object) issueClientContact.Suffix);
        this.db.AddInParameter(storedProcCommand, "@Mobile", DbType.String, (object) issueClientContact.Mobile);
        this.db.AddInParameter(storedProcCommand, "@Fax", DbType.String, (object) issueClientContact.Fax);
        this.db.AddOutParameter(storedProcCommand, "@OutClientContactID", DbType.Int64, 0);
        this.db.AddOutParameter(storedProcCommand, "@OutClientName", DbType.String, (int) byte.MaxValue);
        this.db.ExecuteNonQuery(storedProcCommand);
        int64 = Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutClientContactID"));
        clientName = Convert.ToString(this.db.GetParameterValue(storedProcCommand, "@OutClientName"));
      }
      return int64;
    }

    public IDataReader FetchPartnerContactsByKey(
      long currentId,
      long appTransactionID,
      long externalPartnerID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssuePartnerContactByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerID", DbType.Int64, (object) currentId);
        if (appTransactionID != 0L)
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        else
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) null);
        this.db.AddInParameter(storedProcCommand, "@ExternalPartnerID", DbType.Int64, (object) externalPartnerID);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public long SavePartnerContacts(IssuePartnerContact issuePartnerContact, out string partnerName)
    {
      partnerName = string.Empty;
      long int64;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveIsuePartnerContact"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerID", DbType.Int64, (object) issuePartnerContact.PartnerID);
        this.db.AddInParameter(storedProcCommand, "@PartnerContactID", DbType.Int64, (object) issuePartnerContact.PartnerContactID);
        this.db.AddInParameter(storedProcCommand, "@ExternalPartnerID", DbType.Int64, (object) issuePartnerContact.ExternalPartnerID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) issuePartnerContact.PartnerContactName);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) issuePartnerContact.Title);
        this.db.AddInParameter(storedProcCommand, "@StreetAddress", DbType.String, (object) issuePartnerContact.StreetAddress);
        this.db.AddInParameter(storedProcCommand, "@City", DbType.String, (object) issuePartnerContact.City);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.Int64, (object) issuePartnerContact.State);
        this.db.AddInParameter(storedProcCommand, "@Zip", DbType.String, (object) issuePartnerContact.Zip);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) issuePartnerContact.Phone);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, string.IsNullOrEmpty(issuePartnerContact.Email) ? (object) issuePartnerContact.Email : (object) issuePartnerContact.Email.ToLower());
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) issuePartnerContact.IsActive);
        this.db.AddInParameter(storedProcCommand, "@IsDefault", DbType.Boolean, (object) issuePartnerContact.IsDefault);
        this.db.AddInParameter(storedProcCommand, "@NameTitle", DbType.String, (object) issuePartnerContact.NameTitle);
        this.db.AddInParameter(storedProcCommand, "@FirstName", DbType.String, (object) issuePartnerContact.FirstName);
        this.db.AddInParameter(storedProcCommand, "@LastName", DbType.String, (object) issuePartnerContact.LastName);
        this.db.AddInParameter(storedProcCommand, "@Suffix", DbType.String, (object) issuePartnerContact.Suffix);
        this.db.AddInParameter(storedProcCommand, "@Mobile", DbType.String, (object) issuePartnerContact.Mobile);
        this.db.AddInParameter(storedProcCommand, "@Fax", DbType.String, (object) issuePartnerContact.Fax);
        this.db.AddInParameter(storedProcCommand, "@PartnerContactAddressID", DbType.Int64, (object) issuePartnerContact.PartnerContactAddressID);
        this.db.AddOutParameter(storedProcCommand, "@OutPartnerContactID", DbType.Int64, 0);
        this.db.AddOutParameter(storedProcCommand, "@OutPartnerName", DbType.String, (int) byte.MaxValue);
        this.db.ExecuteNonQuery(storedProcCommand);
        int64 = Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutPartnerContactID"));
        partnerName = Convert.ToString(this.db.GetParameterValue(storedProcCommand, "@OutPartnerName"));
      }
      return int64;
    }
  }
}
