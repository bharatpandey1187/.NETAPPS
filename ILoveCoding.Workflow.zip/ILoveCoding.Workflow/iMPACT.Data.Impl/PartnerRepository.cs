﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.PartnerRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IPartnerRepository))]
  public class PartnerRepository : RepositoryBase, IPartnerRepository
  {
    public long Save(Partner thePartner)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SavePartner"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerID", DbType.Int64, (object) thePartner.PartnerID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) thePartner.Name);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) thePartner.Title);
        this.db.AddInParameter(storedProcCommand, "@FirstName", DbType.String, (object) thePartner.FirstName);
        this.db.AddInParameter(storedProcCommand, "@LastName", DbType.String, (object) thePartner.LastName);
        this.db.AddInParameter(storedProcCommand, "@Suffix", DbType.String, (object) thePartner.Suffix);
        this.db.AddInParameter(storedProcCommand, "@Address", DbType.String, (object) thePartner.StreetAddress);
        this.db.AddInParameter(storedProcCommand, "@City", DbType.String, (object) thePartner.City);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.String, (object) thePartner.State);
        this.db.AddInParameter(storedProcCommand, "@Zip", DbType.String, (object) thePartner.Zip);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) thePartner.Phone);
        this.db.AddInParameter(storedProcCommand, "@Mobile", DbType.String, (object) thePartner.Mobile);
        this.db.AddInParameter(storedProcCommand, "@Fax", DbType.String, (object) thePartner.Fax);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) thePartner.IsActive);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@PartnerContactTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<PartnerContact>(thePartner.PartnerContacts.ToList<PartnerContact>()));
        this.db.AddInParameter(storedProcCommand, "@PartnerContactAddressTableType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<PartnerContactAddress>(thePartner.PartnerContactAddress.ToList<PartnerContactAddress>()));
        this.db.AddInParameter(storedProcCommand, "@PartnerToPartnerType_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<PartnerRoles>(thePartner.PartnerToPartnerTypes.ToList<PartnerRoles>()));
        this.db.AddOutParameter(storedProcCommand, "@OutPartnerID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutPartnerID"));
      }
    }

    public Partner FetchByKey(long currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPartnerByKey"))
      {
        Partner partner = new Partner();
        this.db.AddInParameter(storedProcCommand, "@PartnerId", DbType.Int64, (object) currentId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (reader.Read())
          {
            partner = MapBuilder<Partner>.MapAllProperties().DoNotMap<long>((Expression<Func<Partner, long>>) (x => x.PartnerType)).Build().MapRow((IDataRecord) reader);
            if (reader.NextResult())
              partner.PartnerContacts = this.GetContacts(reader);
            if (reader.NextResult())
              partner.PartnerToPartnerTypes = this.GetPartnerTypes(reader);
            if (reader.NextResult())
              partner.PartnerContactAddress = this.GetContactAddress(reader);
            if (reader.NextResult())
              partner.PartnerActiveAddress = this.GetContactActiveAddress(reader);
          }
        }
        return partner;
      }
    }

    public IDataReader FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllPartner"))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public IDataReader FetchFinancialAdvisorsByName(string name, string partnerTypeName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchFinancialAdvisors"))
      {
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) name);
        this.db.AddInParameter(storedProcCommand, "@PartnerTypeName", DbType.String, (object) partnerTypeName);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    private List<PartnerContact> GetContacts(IDataReader reader)
    {
      List<PartnerContact> partnerContactList = new List<PartnerContact>();
      IRowMapper<PartnerContact> rowMapper = MapBuilder<PartnerContact>.MapAllProperties().Build();
      while (reader.Read())
        partnerContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return partnerContactList;
    }

    private List<PartnerContactAddress> GetContactAddress(
      IDataReader reader)
    {
      List<PartnerContactAddress> partnerContactAddressList = new List<PartnerContactAddress>();
      IRowMapper<PartnerContactAddress> rowMapper = MapBuilder<PartnerContactAddress>.MapAllProperties().DoNotMap<bool>((Expression<Func<PartnerContactAddress, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<PartnerContactAddress, bool>>) (x => x.IsDirty)).Build();
      while (reader.Read())
        partnerContactAddressList.Add(rowMapper.MapRow((IDataRecord) reader));
      return partnerContactAddressList;
    }

    private List<PartnerActiveAddress> GetContactActiveAddress(
      IDataReader reader)
    {
      List<PartnerActiveAddress> partnerActiveAddressList = new List<PartnerActiveAddress>();
      IRowMapper<PartnerActiveAddress> rowMapper = MapBuilder<PartnerActiveAddress>.MapAllProperties().Build();
      while (reader.Read())
        partnerActiveAddressList.Add(rowMapper.MapRow((IDataRecord) reader));
      return partnerActiveAddressList;
    }

    private List<PartnerRoles> GetPartnerTypes(IDataReader reader)
    {
      List<PartnerRoles> partnerRolesList = new List<PartnerRoles>();
      IRowMapper<PartnerRoles> rowMapper = MapBuilder<PartnerRoles>.MapAllProperties().Build();
      while (reader.Read())
        partnerRolesList.Add(rowMapper.MapRow((IDataRecord) reader));
      return partnerRolesList;
    }

    public IDataReader FetchPartnersByType(
      string name,
      string partnerTypeName,
      bool isAllRecords)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPartnerAutocomplete"))
      {
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) RepositoryBase.EscapeForLike(name));
        this.db.AddInParameter(storedProcCommand, "@PartnerTypeName", DbType.String, (object) partnerTypeName);
        this.db.AddInParameter(storedProcCommand, "@IsAllRecords", DbType.Boolean, (object) isAllRecords);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public long UpdateContactDetails(PartnerContact partnerContact)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("[usp_SavePartnerContact]"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerID", DbType.Int64, (object) partnerContact.PartnerID);
        this.db.AddInParameter(storedProcCommand, "@PartnerContactID", DbType.Int64, (object) partnerContact.PartnerContactID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) partnerContact.Name);
        this.db.AddInParameter(storedProcCommand, "@StreetAddress", DbType.String, (object) partnerContact.StreetAddress);
        this.db.AddInParameter(storedProcCommand, "@City", DbType.String, (object) partnerContact.City);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.Int64, (object) partnerContact.State);
        this.db.AddInParameter(storedProcCommand, "@Zip", DbType.String, (object) partnerContact.Zip);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) partnerContact.Phone);
        this.db.AddInParameter(storedProcCommand, "@Fax", DbType.String, (object) partnerContact.Fax);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) partnerContact.Email);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) partnerContact.IsActive);
        this.db.AddInParameter(storedProcCommand, "@IsDefault", DbType.Boolean, (object) partnerContact.IsDefault);
        this.db.AddInParameter(storedProcCommand, "@NameTitle", DbType.String, (object) partnerContact.NameTitle);
        this.db.AddInParameter(storedProcCommand, "@FirstName", DbType.String, (object) partnerContact.FirstName);
        this.db.AddInParameter(storedProcCommand, "@LastName", DbType.String, (object) partnerContact.LastName);
        this.db.AddInParameter(storedProcCommand, "@Suffix", DbType.String, (object) partnerContact.Suffix);
        this.db.AddInParameter(storedProcCommand, "@Mobile", DbType.String, (object) partnerContact.Mobile);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) partnerContact.Title);
        this.db.AddInParameter(storedProcCommand, "@PartnerContactAddressID", DbType.Int64, (object) partnerContact.PartnerContactAddressID);
        this.db.AddOutParameter(storedProcCommand, "@OutPartnerContactID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutPartnerContactID"));
      }
    }

    public bool CheckPartnerIdUsedInEntity(long partnerId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_CheckPartnerIdUsedInEntity"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerId", DbType.Int64, (object) partnerId);
        return Convert.ToBoolean(this.db.ExecuteScalar(storedProcCommand));
      }
    }
  }
}
