﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.LookupRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ILookupRepository))]
  public class LookupRepository : RepositoryBase, ILookupRepository
  {
    public void Save(Lookup theLookup)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveLookup"))
      {
        this.db.AddInParameter(storedProcCommand, "@LookupID", DbType.Int64, (object) theLookup.LookupID);
        this.db.AddInParameter(storedProcCommand, "@Key", DbType.String, (object) theLookup.Key);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) theLookup.IsActive);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    private IEnumerable<LookupItem> GetItems(IDataReader reader)
    {
      List<LookupItem> lookupItemList = new List<LookupItem>();
      IRowMapper<LookupItem> rowMapper = MapBuilder<LookupItem>.MapAllProperties().DoNotMap<bool>((Expression<Func<LookupItem, bool>>) (x => x.IsEditable)).Build();
      while (reader.Read())
        lookupItemList.Add(rowMapper.MapRow((IDataRecord) reader));
      return (IEnumerable<LookupItem>) lookupItemList;
    }

    public IEnumerable<Lookup> FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllLookup"))
      {
        List<Lookup> lookupList = new List<Lookup>();
        this.db.AddInParameter(storedProcCommand, "@LookupId", DbType.Int32, (object) null);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<Lookup> rowMapper = MapBuilder<Lookup>.MapAllProperties().Build();
          while (dataReader.Read())
            lookupList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<Lookup>) lookupList;
      }
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteLookupByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@LookupId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void SaveLookupItems(List<LookupItem> lookupItems)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveLookupItems"))
      {
        this.db.AddInParameter(storedProcCommand, "@LookupItems_TVP", SqlDbType.Structured, (object) this.ConvertListToDataTable<LookupItem>(lookupItems.ToList<LookupItem>()));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void Save(LookupItem theLookupItem)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveLookupItem"))
      {
        this.db.AddInParameter(storedProcCommand, "@LookupItemID", DbType.Int64, (object) theLookupItem.LookupItemID);
        this.db.AddInParameter(storedProcCommand, "@LookupID", DbType.Int64, (object) theLookupItem.LookupID);
        this.db.AddInParameter(storedProcCommand, "@Value", DbType.String, (object) theLookupItem.Value);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) theLookupItem.IsActive);
        this.db.AddInParameter(storedProcCommand, "@ItemOrder", DbType.Int32, (object) theLookupItem.ItemOrder);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IEnumerable<LookupItem> FetchByLookupId(
      int lookupId,
      bool IncludeNegative)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchLookupItemsByLookupID"))
      {
        List<LookupItem> lookupItemList = new List<LookupItem>();
        this.db.AddInParameter(storedProcCommand, "@LookupID", DbType.Int32, (object) lookupId);
        this.db.AddInParameter(storedProcCommand, "@IncludeNegative", DbType.Boolean, (object) IncludeNegative);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<LookupItem> rowMapper = MapBuilder<LookupItem>.MapAllProperties().Build();
          while (dataReader.Read())
            lookupItemList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<LookupItem>) lookupItemList;
      }
    }

    public IEnumerable<LookupItem> FetchByLookupKey(string key)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_GetLookUpItemsByName"))
      {
        List<LookupItem> lookupItemList = new List<LookupItem>();
        this.db.AddInParameter(storedProcCommand, "@key", DbType.String, (object) key);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<LookupItem> rowMapper = MapBuilder<LookupItem>.MapAllProperties().DoNotMap<bool>((Expression<Func<LookupItem, bool>>) (x => x.IsEditable)).Build();
          while (dataReader.Read())
            lookupItemList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<LookupItem>) lookupItemList;
      }
    }

    public IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys(
      params string[] keys)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchLookupItemsByKeys"))
      {
        List<LookupItemMappings> lookupItemMappingsList = new List<LookupItemMappings>();
        this.db.AddInParameter(storedProcCommand, "@Keys", DbType.String, (object) string.Join(",", keys));
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<LookupItemMappings> rowMapper = MapBuilder<LookupItemMappings>.MapAllProperties().DoNotMap<bool>((Expression<Func<LookupItemMappings, bool>>) (x => x.IsEditable)).Build();
          while (dataReader.Read())
            lookupItemMappingsList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<LookupItemMappings>) lookupItemMappingsList;
      }
    }

    public IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys(
      string[] keys,
      string[] includeLookupItemIDs)
    {
      return this.FetchLookupItemsByLookupKeys(keys, includeLookupItemIDs, false);
    }

    public IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys(
      string[] keys,
      string[] includeLookupItemIDs,
      bool includeInactive)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchLookupItemsByKeys"))
      {
        List<LookupItemMappings> lookupItemMappingsList = new List<LookupItemMappings>();
        this.db.AddInParameter(storedProcCommand, "@Keys", DbType.String, keys != null ? (object) string.Join(",", keys) : (object) string.Empty);
        this.db.AddInParameter(storedProcCommand, "@LookupItemsID", DbType.String, includeLookupItemIDs != null ? (object) string.Join(",", includeLookupItemIDs) : (object) (string) null);
        this.db.AddInParameter(storedProcCommand, "@IncludeInactive", DbType.Boolean, (object) includeInactive);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<LookupItemMappings> rowMapper = MapBuilder<LookupItemMappings>.MapAllProperties().DoNotMap<bool>((Expression<Func<LookupItemMappings, bool>>) (x => x.IsEditable)).Build();
          while (dataReader.Read())
            lookupItemMappingsList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<LookupItemMappings>) lookupItemMappingsList;
      }
    }
  }
}
