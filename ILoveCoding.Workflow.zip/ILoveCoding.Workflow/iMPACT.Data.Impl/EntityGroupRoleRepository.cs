﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.EntityGroupRoleRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using System;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IEntityGroupRoleRepository))]
  public class EntityGroupRoleRepository : RepositoryBase, IEntityGroupRoleRepository
  {
    public IDataReader GetAllEntityGroupRole()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllEntityGroupRoles"))
        return this.db.ExecuteReader(storedProcCommand);
    }

    public long Save(EntityGroupRole theEntityGroupRole)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEntityGroupRole"))
      {
        this.db.AddInParameter(storedProcCommand, "@GroupId", DbType.Int64, (object) theEntityGroupRole.GroupId);
        this.db.AddInParameter(storedProcCommand, "@EntityId", DbType.Int64, (object) theEntityGroupRole.EntityId);
        this.db.AddInParameter(storedProcCommand, "@RoleTypeId", DbType.Int64, (object) theEntityGroupRole.RoleTypesId);
        this.db.AddInParameter(storedProcCommand, "@SelectedRoles", DbType.String, (object) theEntityGroupRole.SelectedRoles);
        this.db.AddOutParameter(storedProcCommand, "@OutEntityGroupRoleID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@OutEntityGroupRoleID"));
      }
    }

    public IDataReader GetEntityGroupRoleByKeys(
      long GroupId,
      long EntityId,
      long RoleTypesId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEntityGrouptRoleByKeys"))
      {
        this.db.AddInParameter(storedProcCommand, "@GroupId", DbType.Int64, (object) GroupId);
        this.db.AddInParameter(storedProcCommand, "@EntityId", DbType.Int64, (object) EntityId);
        this.db.AddInParameter(storedProcCommand, "@RoleTypeId", DbType.Int64, (object) RoleTypesId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
