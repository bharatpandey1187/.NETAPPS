﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.CompetitiveIssueRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (ICompetitiveIssueRepository))]
  public class CompetitiveIssueRepository : RepositoryBase, ICompetitiveIssueRepository, IQuery
  {
    private Dictionary<string, string> knownMappings;
    private static readonly List<SearchSQLField> knownProjection = new List<SearchSQLField>()
    {
      new SearchSQLField("IssueNumber"),
      new SearchSQLField("IssueName"),
      new SearchSQLField("IssueStatus"),
      new SearchSQLField("PnLStatusID"),
      new SearchSQLField("ReviewStatus"),
      new SearchSQLField("Issuer"),
      new SearchSQLField("Borrower"),
      new SearchSQLField("Guarantor"),
      new SearchSQLField("TypeOfOffering"),
      new SearchSQLField("State"),
      new SearchSQLField("DateHired"),
      new SearchSQLField("G17RoleLetter"),
      new SearchSQLField("G17RoleLetterSentDate"),
      new SearchSQLField("G17RoleLetterAckDate"),
      new SearchSQLField("G17ConflictLetter"),
      new SearchSQLField("G17ConflictLetterSentDate"),
      new SearchSQLField("G17ConflictLetterAckDate"),
      new SearchSQLField("G17RoleDisclosureLetter"),
      new SearchSQLField("G17RoleDisclosureLetterSentDate"),
      new SearchSQLField("G17RoleDisclosureLetterAckDate"),
      new SearchSQLField("G17StructureLetter"),
      new SearchSQLField("G17StructureLetterSentDate"),
      new SearchSQLField("G17StructureLetterAckDate"),
      new SearchSQLField("RFPMAExemption"),
      new SearchSQLField("RFPMAExemptionStartDate"),
      new SearchSQLField("RFPMAExemptionExpirationDate"),
      new SearchSQLField("IRMAMAExemption"),
      new SearchSQLField("IRMAMAExemptionStartDate"),
      new SearchSQLField("IRMAMAExemptionExpirationDate"),
      new SearchSQLField("UWMAExemption"),
      new SearchSQLField("UWMAExemptionStartDate"),
      new SearchSQLField("UWMAExemptionExpirationDate"),
      new SearchSQLField("NoneMAExemption"),
      new SearchSQLField("NoneMAExemptionStartDate"),
      new SearchSQLField("NoneMAExemptionExpirationDate"),
      new SearchSQLField("FirmRole"),
      new SearchSQLField("LiabilityPercentage"),
      new SearchSQLField("FirmManagementFeePercentage"),
      new SearchSQLField("FirmOtherRoles"),
      new SearchSQLField("LeadBanker"),
      new SearchSQLField("Banker"),
      new SearchSQLField("Quant"),
      new SearchSQLField("SupervisoryPrincipal"),
      new SearchSQLField("Underwriter"),
      new SearchSQLField("SoleManager"),
      new SearchSQLField("SeniorManager"),
      new SearchSQLField("JointSeniorMgrBookRunning"),
      new SearchSQLField("JointSeniorMgrNonBookRunning"),
      new SearchSQLField("CoSeniorMgr"),
      new SearchSQLField("CoManager"),
      new SearchSQLField("SellingGroupMember"),
      new SearchSQLField("OtherSyndicateMembers"),
      new SearchSQLField("FinancialAdvisor"),
      new SearchSQLField("EscrowVerificationAgent"),
      new SearchSQLField("EscrowSecuritiesProvider"),
      new SearchSQLField("EscrowAgentForRefundedBonds"),
      new SearchSQLField("PayingAgent"),
      new SearchSQLField("RemarketingAgent"),
      new SearchSQLField("OtherAdvisorAgents"),
      new SearchSQLField("BondCounsel"),
      new SearchSQLField("UnderwriterCounsel"),
      new SearchSQLField("DisclosureCounsel"),
      new SearchSQLField("IssuerCounsel"),
      new SearchSQLField("BorrowerCounsel"),
      new SearchSQLField("Trustee"),
      new SearchSQLField("OtherCounsels"),
      new SearchSQLField("OtherPartners"),
      new SearchSQLField("ParAmount"),
      new SearchSQLField("AdvanceRefunding"),
      new SearchSQLField("UseOfProceeds"),
      new SearchSQLField("GeneralCategory"),
      new SearchSQLField("GoodFaithAmount"),
      new SearchSQLField("GoodFaithDate"),
      new SearchSQLField("CommitmentCommitteeApprovalDate"),
      new SearchSQLField("PricingDate"),
      new SearchSQLField("ExpectedAwardDate"),
      new SearchSQLField("ActualAwardDate", "ActualAwardDateTimeZone"),
      new SearchSQLField("SettlementDate"),
      new SearchSQLField("ARDSubmissionDate"),
      new SearchSQLField("G37SettlementDate"),
      new SearchSQLField("DateCounselApprovedByLegal"),
      new SearchSQLField("FinalOSReceivedDate", "FinalOSReceivedDateTimeZone"),
      new SearchSQLField("DateApprovedByMUCC"),
      new SearchSQLField("G32SubmissionDate", "G32SubmissionDateTimeZone"),
      new SearchSQLField("SeriesName"),
      new SearchSQLField("SeriesCode"),
      new SearchSQLField("SeriesParAmount"),
      new SearchSQLField("SecurityType"),
      new SearchSQLField("Denomination"),
      new SearchSQLField("MaturityPeriod"),
      new SearchSQLField("Security"),
      new SearchSQLField("SecurityDetails"),
      new SearchSQLField("SeriesDatedDate"),
      new SearchSQLField("FirstCouponDate"),
      new SearchSQLField("SeriesSettlementDate"),
      new SearchSQLField("PutDate"),
      new SearchSQLField("PricingForm"),
      new SearchSQLField("RecordDate"),
      new SearchSQLField("SeriesFedTax"),
      new SearchSQLField("FedTaxName"),
      new SearchSQLField("SeriesStateTaxable"),
      new SearchSQLField("SeriesBankQualified"),
      new SearchSQLField("AccrueFrom"),
      new SearchSQLField("Form"),
      new SearchSQLField("CouponFreq"),
      new SearchSQLField("DayCount"),
      new SearchSQLField("RateType"),
      new SearchSQLField("SeriesCallFeature"),
      new SearchSQLField("SeriesCallDate"),
      new SearchSQLField("CallPrice"),
      new SearchSQLField("Insurance"),
      new SearchSQLField("FirmInventory"),
      new SearchSQLField("FirstMaturity"),
      new SearchSQLField("FinalMaturity"),
      new SearchSQLField("UnderlyingRating"),
      new SearchSQLField("EnhancedRating"),
      new SearchSQLField("CreditEnhancementProvider"),
      new SearchSQLField("CEType"),
      new SearchSQLField("CEExpirationDate"),
      new SearchSQLField("Takedown"),
      new SearchSQLField("EstimatedRevenue"),
      new SearchSQLField("GrossSpread"),
      new SearchSQLField("InsuranceFee"),
      new SearchSQLField("JobNumber"),
      new SearchSQLField("PriorityOfOrders"),
      new SearchSQLField("CreateDate", "CreatedOn"),
      new SearchSQLField("CreatedBy"),
      new SearchSQLField("ROPDate"),
      new SearchSQLField("DealType"),
      new SearchSQLField("FormalDueDiligenceDate"),
      new SearchSQLField("IssuePriceCertReviewDate"),
      new SearchSQLField("LiquidityAgreementUploadDate"),
      new SearchSQLField("CrossSellIdValue"),
      new SearchSQLField("ABANumber"),
      new SearchSQLField("AccountNumber"),
      new SearchSQLField("AccountName"),
      new SearchSQLField("GoodFaithNotes"),
      new SearchSQLField("GoodFaithInstructions"),
      new SearchSQLField("GoodFaithType"),
      new SearchSQLField("SDCCreditPerc"),
      new SearchSQLField("CrossSellDetail"),
      new SearchSQLField("FirmOtherRoleAdditionalDetails"),
      new SearchSQLField("JobNumbers"),
      new SearchSQLField("SeriesQuarter"),
      new SearchSQLField("TransactionLeadManager"),
      new SearchSQLField("TransactionNonLeadManager"),
      new SearchSQLField("TransactionQuarter"),
      new SearchSQLField("SeriesPricingDate"),
      new SearchSQLField("SeriesROPDate"),
      new SearchSQLField("SeriesActualAwardDate", "SeriesActualAwardDateTimeZone"),
      new SearchSQLField("SeriesFirmRoleName"),
      new SearchSQLField("SeriesFirmLiability"),
      new SearchSQLField("SeriesFirmMgtFee"),
      new SearchSQLField("SeriesSDCCredit"),
      new SearchSQLField("OSDeemedFinalDate"),
      new SearchSQLField("DatedDate"),
      new SearchSQLField("ReasonOfHold"),
      new SearchSQLField("BankName"),
      new SearchSQLField("GFRequired"),
      new SearchSQLField("GoodFaithApplied"),
      new SearchSQLField("GoodFaithDueDate"),
      new SearchSQLField("GoodFaithReturnedDate"),
      new SearchSQLField("GoodFaithIssuedDate")
    };

    [Dependency]
    public ISearchSettingRepository SearchSettingRepository { get; set; }

    public CompetitiveIssueRepository(Dictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public long Save(long appTransactionID)
    {
      long num = 0;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_SaveIssueCompHistory"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
      return num;
    }

    public long Save(
      CompetitiveIssue theIssue,
      Dictionary<int, int> history,
      List<CompetitiveIssueFromStateToState> fromToStateList,
      List<CompetitiveIssueFromStateToState> stateAuditTrailList,
      DataTable pricing,
      DataTable underlyingRatingDetail)
    {
      long num;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_SaveIssueCompetitive"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theIssue.IssueDetail.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@ParentOpportunityID", DbType.Int64, (object) theIssue.IssueDetail.ParentOpportunityID);
        this.db.AddInParameter(storedProcCommand, "@ParentRFPID", DbType.Int64, (object) theIssue.IssueDetail.ParentRFPID);
        this.db.AddInParameter(storedProcCommand, "@PowerID", DbType.String, (object) theIssue.IssueDetail.PowerID);
        this.db.AddInParameter(storedProcCommand, "@IssueName", DbType.String, (object) theIssue.IssueDetail.IssueName);
        this.db.AddInParameter(storedProcCommand, "@Issuer", DbType.Int64, (object) theIssue.IssueDetail.IssuerID);
        this.db.AddInParameter(storedProcCommand, "@JobNumber", DbType.String, (object) theIssue.IssueDetail.JobNumber);
        this.db.AddInParameter(storedProcCommand, "@Borrower", DbType.Int64, (object) theIssue.IssueDetail.BorrowerID);
        this.db.AddInParameter(storedProcCommand, "@Guarantor", DbType.Int64, (object) theIssue.IssueDetail.GuarantorID);
        this.db.AddInParameter(storedProcCommand, "@OfferingType", DbType.Int64, (object) theIssue.IssueDetail.OfferingType);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.Int64, (object) theIssue.IssueDetail.State);
        this.db.AddInParameter(storedProcCommand, "@HybridSolutionIndicator", DbType.Boolean, (object) theIssue.IssueDetail.HybridSolutionIndicator);
        this.db.AddInParameter(storedProcCommand, "@DualProposalProposed", DbType.Boolean, (object) theIssue.IssueDetail.DualProposalProposed);
        this.db.AddInParameter(storedProcCommand, "@DateHired", DbType.DateTime, (object) theIssue.IssueDetail.DateHired);
        this.db.AddInParameter(storedProcCommand, "@G17SentDate", DbType.DateTime, (object) theIssue.IssueDetail.G17SentDate);
        this.db.AddInParameter(storedProcCommand, "@G17AckDate", DbType.DateTime, (object) theIssue.IssueDetail.G17AckDate);
        if (theIssue.IssueDetail.MAExemptions == null)
          theIssue.IssueDetail.MAExemptions = (IEnumerable<MAExemptionDetail>) new List<MAExemptionDetail>();
        this.db.AddInParameter(storedProcCommand, "@MAExemptionsTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<MAExemptionDetail>(theIssue.IssueDetail.MAExemptions.ToList<MAExemptionDetail>()));
        if (theIssue.IssueDetail.SelectedMERGReviewTypes != null)
          this.db.AddInParameter(storedProcCommand, "@MERGReviewTypeTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<MERGReviewTypeDetail>(theIssue.IssueDetail.SelectedMERGReviewTypes.ToList<MERGReviewTypeDetail>()));
        this.db.AddInParameter(storedProcCommand, "@RemarksForMERG", DbType.String, (object) theIssue.IssueDetail.RemarksForMERG);
        this.db.AddInParameter(storedProcCommand, "@RemarksForMUCC", DbType.String, (object) theIssue.IssueDetail.RemarksForMUCC);
        this.db.AddInParameter(storedProcCommand, "@FirmRole", DbType.Int64, (object) theIssue.IssueDetail.FirmRole);
        this.db.AddInParameter(storedProcCommand, "@FirmLiabilityPerc", DbType.Decimal, (object) theIssue.IssueDetail.FirmLiabilityPerc);
        this.db.AddInParameter(storedProcCommand, "@FirmMgmtFeePerc", DbType.Decimal, (object) theIssue.IssueDetail.FirmMgmtFeePerc);
        if (theIssue.IssueDetail.FirmOtherRoles != null)
          this.db.AddInParameter(storedProcCommand, "@FirmOtherRoleTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<FirmOtherRole>(theIssue.IssueDetail.FirmOtherRoles.ToList<FirmOtherRole>()));
        if (theIssue.IssueDetail.PriorityOfOrders != null)
          this.db.AddInParameter(storedProcCommand, "@PriorityOfOrdersTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<PriorityOfOrderDetail>(theIssue.IssueDetail.PriorityOfOrders.ToList<PriorityOfOrderDetail>()));
        this.db.AddInParameter(storedProcCommand, "@ParAmount", DbType.Decimal, (object) theIssue.IssueDetail.ParAmount);
        this.db.AddInParameter(storedProcCommand, "@SDCCreditPerc", DbType.Decimal, (object) theIssue.IssueDetail.SDCCreditPerc);
        this.db.AddInParameter(storedProcCommand, "@DSRF", DbType.Int64, (object) theIssue.IssueDetail.DSRF);
        this.db.AddInParameter(storedProcCommand, "@County", DbType.String, (object) theIssue.IssueDetail.County);
        this.db.AddInParameter(storedProcCommand, "@Purpose", DbType.Int64, (object) theIssue.IssueDetail.Purpose);
        this.db.AddInParameter(storedProcCommand, "@TransactionType", DbType.Int64, (object) theIssue.IssueDetail.TransactionType);
        this.db.AddInParameter(storedProcCommand, "@InsuranceProvider", DbType.Int64, (object) theIssue.IssueDetail.InsuranceProvider);
        this.db.AddInParameter(storedProcCommand, "@GeneralCategory", DbType.Int64, (object) theIssue.IssueDetail.GeneralCategory);
        this.db.AddInParameter(storedProcCommand, "@GeneralCategorySpecific", DbType.Int64, (object) theIssue.IssueDetail.GeneralCategorySpecific);
        this.db.AddInParameter(storedProcCommand, "@CreditEnhancementProg", DbType.Int64, (object) theIssue.IssueDetail.CreditEnhancementProg);
        this.db.AddInParameter(storedProcCommand, "@Security", DbType.String, (object) theIssue.IssueDetail.Security);
        this.db.AddInParameter(storedProcCommand, "@SecurityDetails", DbType.String, (object) theIssue.IssueDetail.SecurityDetails);
        this.db.AddInParameter(storedProcCommand, "@PricingDate", DbType.DateTime, (object) theIssue.IssueDetail.PricingDate);
        this.db.AddInParameter(storedProcCommand, "@ROPDate", DbType.DateTime, (object) theIssue.IssueDetail.ROPDate);
        this.db.AddInParameter(storedProcCommand, "@ExpectedAwardDate", DbType.DateTime, (object) theIssue.IssueDetail.ExpectedAwardDate);
        this.db.AddInParameter(storedProcCommand, "@ExpectedAwardTxtDate", DbType.String, (object) theIssue.IssueDetail.ExpectedAwardTxtDate);
        this.db.AddInParameter(storedProcCommand, "@ActualAwardDateTime", DbType.DateTime, (object) theIssue.IssueDetail.ActualAwardDateTime);
        this.db.AddInParameter(storedProcCommand, "@ActualAwardDateTimeZone", DbType.String, (object) theIssue.IssueDetail.ActualAwardDateTimeZone);
        this.db.AddInParameter(storedProcCommand, "@SettlementDate", DbType.DateTime, (object) theIssue.IssueDetail.SettlementDate);
        this.db.AddInParameter(storedProcCommand, "@TicketExecDateTime", DbType.DateTime, (object) theIssue.IssueDetail.TicketExecDateTime);
        this.db.AddInParameter(storedProcCommand, "@TicketExecDateTimeZone", DbType.String, (object) theIssue.IssueDetail.TicketExecDateTimeZone);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithAmount", DbType.Decimal, (object) theIssue.IssueDetail.GoodFaithAmount);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithDate", DbType.DateTime, (object) theIssue.IssueDetail.GoodFaithDate);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithInstructions", DbType.String, (object) theIssue.IssueDetail.GoodFaithInstructions);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithNotes", DbType.String, (object) theIssue.IssueDetail.GoodFaithNotes);
        this.db.AddInParameter(storedProcCommand, "@AccountName", DbType.String, (object) theIssue.IssueDetail.AccountName);
        this.db.AddInParameter(storedProcCommand, "@AccountNumber", DbType.String, (object) theIssue.IssueDetail.AccountNumber);
        this.db.AddInParameter(storedProcCommand, "@ABANumber", DbType.String, (object) theIssue.IssueDetail.ABANumber);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithType", DbType.Int64, (object) theIssue.IssueDetail.GoodFaithType);
        this.db.AddInParameter(storedProcCommand, "@ReasonOfHold", DbType.String, (object) theIssue.IssueDetail.ReasonOfHold);
        if (theIssue.IssueDetail.Series != null)
          this.db.AddInParameter(storedProcCommand, "@SeriesTableType", SqlDbType.Structured, (object) this.TruncateColumns(this.ConvertListToDataTable<Series>(theIssue.IssueDetail.Series.ToList<Series>())));
        this.db.AddInParameter(storedProcCommand, "@ARDSubmissionDate", DbType.DateTime, (object) theIssue.IssueDetail.ARDSubmissionDate);
        this.db.AddInParameter(storedProcCommand, "@LiquidityAgreementUploadDate", DbType.DateTime, (object) theIssue.IssueDetail.LiquidityAgreementUploadDate);
        this.db.AddInParameter(storedProcCommand, "@G37SettlementDate", DbType.DateTime, (object) theIssue.IssueDetail.G37SettlementDate);
        this.db.AddInParameter(storedProcCommand, "@FinalOSReceivedDateTime", DbType.DateTime, (object) theIssue.IssueDetail.FinalOSReceivedDateTime);
        this.db.AddInParameter(storedProcCommand, "@FinalOSReceivedDateTimeZone", DbType.String, (object) theIssue.IssueDetail.FinalOSReceivedDateTimeZone);
        this.db.AddInParameter(storedProcCommand, "@DateCounselApprovedByLegal", DbType.DateTime, (object) theIssue.IssueDetail.DateCounselApprovedByLegal);
        this.db.AddInParameter(storedProcCommand, "@DateApprovedByMERG", DbType.DateTime, (object) theIssue.IssueDetail.DateApprovedByMERG);
        this.db.AddInParameter(storedProcCommand, "@DateApprovedByMUCC", DbType.DateTime, (object) theIssue.IssueDetail.DateApprovedByMUCC);
        this.db.AddInParameter(storedProcCommand, "@G32SubmissionDateTime", DbType.DateTime, (object) theIssue.IssueDetail.G32SubmissionDateTime);
        this.db.AddInParameter(storedProcCommand, "@G32SubmissionDateTimeZone", DbType.String, (object) theIssue.IssueDetail.G32SubmissionDateTimeZone);
        this.db.AddInParameter(storedProcCommand, "@BPASigningDate", DbType.DateTime, (object) theIssue.IssueDetail.BPASigningDate);
        this.db.AddInParameter(storedProcCommand, "@CommitmentCommitteeApprovalDate", DbType.DateTime, (object) theIssue.IssueDetail.CommitmentCommitteeApprovalDate);
        this.db.AddInParameter(storedProcCommand, "@AdvanceRefunding", DbType.Int64, (object) theIssue.IssueDetail.AdvanceRefunding);
        this.db.AddInParameter(storedProcCommand, "@G37Filed", DbType.Boolean, (object) theIssue.IssueDetail.G37Filed);
        this.db.AddInParameter(storedProcCommand, "@Notes", DbType.String, (object) theIssue.IssueDetail.Notes);
        this.db.AddInParameter(storedProcCommand, "@PricingComments", DbType.String, (object) theIssue.IssueDetail.PricingComments);
        this.db.AddInParameter(storedProcCommand, "@RatingComments", DbType.String, (object) theIssue.IssueDetail.RatingComments);
        this.db.AddInParameter(storedProcCommand, "@ReviewComments", DbType.String, (object) theIssue.IssueDetail.ReviewComments);
        this.db.AddInParameter(storedProcCommand, "@NbrOfCusip", DbType.Int32, (object) theIssue.IssueDetail.NbrOfCusip);
        this.db.AddInParameter(storedProcCommand, "@BidCalc", DbType.Int64, (object) theIssue.IssueDetail.BidCalc);
        this.db.AddInParameter(storedProcCommand, "@BidPlatform", DbType.Int64, (object) theIssue.IssueDetail.BidPlatform);
        this.db.AddInParameter(storedProcCommand, "@CrossSellId", DbType.Int64, (object) theIssue.IssueDetail.CrossSellId);
        this.db.AddInParameter(storedProcCommand, "@CrossSellDetail", DbType.String, (object) theIssue.IssueDetail.CrossSellDetail);
        if (theIssue.IssueFee == null)
          theIssue.IssueFee = new IssueFee();
        if (theIssue.AppTransactionClientContacts != null)
          this.db.AddInParameter(storedProcCommand, "@AppTransactionClientContactTableType", SqlDbType.Structured, (object) this.GetAppTransactionClientContactDataTable(theIssue.AppTransactionClientContacts));
        if (theIssue.InternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerTableType", SqlDbType.Structured, (object) this.GetInternalPartnerDataTable(theIssue.InternalPartners));
        if (theIssue.InternalPartnerBankRMs != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerBankRMTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<InternalPartnerBankRM>(theIssue.InternalPartnerBankRMs));
        if (theIssue.ExternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@IssueExternalPartnerTableType", SqlDbType.Structured, (object) this.GetExternalPartnerDataTable(theIssue.ExternalPartners));
        if (theIssue.PaidCheckDetail != null && theIssue.ReceivedCheckDetail != null)
          this.db.AddInParameter(storedProcCommand, "@CheckDetailTableType", SqlDbType.Structured, (object) this.GetCheckDetails(theIssue.PaidCheckDetail, theIssue.ReceivedCheckDetail));
        this.db.AddInParameter(storedProcCommand, "@GrossSpread", DbType.Decimal, (object) theIssue.IssueFee.GrossSpread);
        this.db.AddInParameter(storedProcCommand, "@Takedown", DbType.Decimal, (object) theIssue.IssueFee.Takedown);
        this.db.AddInParameter(storedProcCommand, "@EstimatedRevenue", DbType.Decimal, (object) theIssue.IssueDetail.EstimatedRevenue);
        this.db.AddInParameter(storedProcCommand, "@NetRevenue", DbType.Decimal, (object) theIssue.IssueFee.NetRevenue);
        this.db.AddInParameter(storedProcCommand, "@CusipFee", DbType.Decimal, (object) theIssue.IssueFee.CusipFee);
        this.db.AddInParameter(storedProcCommand, "@IpreoFee", DbType.Decimal, (object) theIssue.IssueFee.IpreoFee);
        this.db.AddInParameter(storedProcCommand, "@MacFee", DbType.Decimal, (object) theIssue.IssueFee.MacFee);
        this.db.AddInParameter(storedProcCommand, "@BondCounselFee", DbType.Decimal, (object) theIssue.IssueFee.BondCounselFee);
        this.db.AddInParameter(storedProcCommand, "@UnderwriterCounselFee", DbType.Decimal, (object) theIssue.IssueFee.UnderwriterCounselFee);
        this.db.AddInParameter(storedProcCommand, "@InsuranceFee", DbType.Int32, (object) theIssue.IssueFee.InsuranceFee);
        this.db.AddInParameter(storedProcCommand, "@BondsUnderwritten", DbType.Decimal, (object) theIssue.IssueFee.BondsUnderwritten);
        this.db.AddInParameter(storedProcCommand, "@RemarketingFee", DbType.Int32, (object) theIssue.IssueFee.RemarketingFee);
        this.db.AddInParameter(storedProcCommand, "@TotalRetailOrders", DbType.Decimal, (object) theIssue.IssueFee.TotalRetailOrders);
        this.db.AddInParameter(storedProcCommand, "@TotalInstitutionalOrders", DbType.Decimal, (object) theIssue.IssueFee.TotalInstitutionalOrders);
        this.db.AddInParameter(storedProcCommand, "@TotalInstitutionalAllotments", DbType.Decimal, (object) theIssue.IssueFee.TotalInstitutionalAllotments);
        this.db.AddInParameter(storedProcCommand, "@TotalMemberOrders", DbType.Decimal, (object) theIssue.IssueFee.TotalMemberOrders);
        this.db.AddInParameter(storedProcCommand, "@TotalMemberAllotments", DbType.Decimal, (object) theIssue.IssueFee.TotalMemberAllotments);
        this.db.AddInParameter(storedProcCommand, "@TotalDesignationDollars", DbType.Decimal, (object) theIssue.IssueFee.TotalDesignationDollars);
        this.db.AddInParameter(storedProcCommand, "@Remarks", DbType.String, (object) theIssue.IssueFee.Remarks);
        this.db.AddInParameter(storedProcCommand, "@DocumentLibraryURL", DbType.String, (object) theIssue.IssueDetail.DocumentLibraryURL);
        this.db.AddInParameter(storedProcCommand, "@InRetention", DbType.Boolean, (object) theIssue.IssueDetail.InRetention);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, string.IsNullOrEmpty(theIssue.IssueDetail.CreatedBy) ? (object) this.AppUser.Name : (object) theIssue.IssueDetail.CreatedBy);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailDate", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@Version", DbType.Int32, (object) theIssue.IssueDetail.Version);
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) 3);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@DealType", DbType.Int64, (object) theIssue.IssueDetail.DealType);
        this.db.AddInParameter(storedProcCommand, "@FormalDueDiligenceDate", DbType.DateTime, (object) theIssue.IssueDetail.FormalDueDiligenceDate);
        this.db.AddInParameter(storedProcCommand, "@IssuePriceCertReviewDate", DbType.DateTime, (object) theIssue.IssueDetail.IssuePriceCertReviewDate);
        if (theIssue.IssueDetail.G17Details != null)
          this.db.AddInParameter(storedProcCommand, "@G17DetailTableType", SqlDbType.Structured, (object) this.GetG17DetailDataTable(theIssue.IssueDetail.G17Details.ToList<G17Detail>()));
        this.db.AddInParameter(storedProcCommand, "@DatedDate", DbType.DateTime, (object) theIssue.IssueDetail.DatedDate);
        this.db.AddInParameter(storedProcCommand, "@IsIssueInitiatedFromParentOpportunity", DbType.Boolean, (object) theIssue.IssueDetail.IsIssueInitiatedFromParentOpportunity);
        this.db.AddInParameter(storedProcCommand, "@IsIssueInitiatedFromParentRFP", DbType.Boolean, (object) theIssue.IssueDetail.IsIssueInitiatedFromParentRFP);
        this.db.AddInParameter(storedProcCommand, "@OSDeemedFinalDate", DbType.DateTime, (object) theIssue.IssueDetail.OSDeemedFinalDate);
        this.db.AddInParameter(storedProcCommand, "@GFRequired", DbType.Boolean, (object) theIssue.GoodFaithDetails.GFRequired);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithDueDate", DbType.DateTime, (object) theIssue.GoodFaithDetails.GoodFaithDueDate);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithApplied", DbType.Boolean, (object) theIssue.GoodFaithDetails.GoodFaithApplied);
        this.db.AddInParameter(storedProcCommand, "@BankName", DbType.String, (object) theIssue.GoodFaithDetails.BankName);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithIssuedDate", DbType.DateTime, (object) theIssue.GoodFaithDetails.GoodFaithIssuedDate);
        this.db.AddInParameter(storedProcCommand, "@GoodFaithReturnedDate", DbType.DateTime, (object) theIssue.GoodFaithDetails.GoodFaithReturnedDate);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        DataTable dataTable1 = new DataTable();
        dataTable1.Columns.Add("AppTransactionID", typeof (long));
        dataTable1.Columns.Add("StateID", typeof (int));
        foreach (long issueStatu in theIssue.IssueDetail.IssueStatus)
        {
          DataRow row = dataTable1.NewRow();
          row["AppTransactionID"] = (object) theIssue.IssueDetail.AppTransactionID;
          row["StateID"] = (object) int.Parse(issueStatu.ToString());
          dataTable1.Rows.Add(row);
        }
        DataTable dataTable2 = new DataTable();
        dataTable2.Columns.Add("AppTransactionID", typeof (long));
        dataTable2.Columns.Add("ParentStateID", typeof (int));
        dataTable2.Columns.Add("StateID", typeof (int));
        if (history != null && history.Count > 0)
        {
          foreach (KeyValuePair<int, int> keyValuePair in history)
          {
            DataRow row = dataTable2.NewRow();
            row["AppTransactionID"] = (object) theIssue.IssueDetail.AppTransactionID;
            row["ParentStateID"] = (object) keyValuePair.Key;
            row["StateID"] = (object) keyValuePair.Value;
            dataTable2.Rows.Add(row);
          }
        }
        DataTable dataTable3 = new DataTable();
        dataTable3.Columns.Add("FromState", typeof (int));
        dataTable3.Columns.Add("ToState", typeof (int));
        foreach (CompetitiveIssueFromStateToState fromToState in fromToStateList)
        {
          DataRow row = dataTable3.NewRow();
          CompetitiveIssueEnums.IssueStatus? fromState = fromToState.FromState;
          if (fromState.HasValue)
          {
            DataRow dataRow = row;
            fromState = fromToState.FromState;
            // ISSUE: variable of a boxed type
            __Boxed<int> local = (System.ValueType) (int) fromState.Value;
            dataRow["FromState"] = (object) local;
          }
          else
            row["FromState"] = (object) DBNull.Value;
          row["ToState"] = (object) (int) fromToState.ToState;
          dataTable3.Rows.Add(row);
        }
        DataTable dataTable4 = new DataTable();
        dataTable4.Columns.Add("FromState", typeof (int));
        dataTable4.Columns.Add("ToState", typeof (int));
        foreach (CompetitiveIssueFromStateToState stateAuditTrail in stateAuditTrailList)
        {
          DataRow row = dataTable4.NewRow();
          row["FromState"] = (object) (int) stateAuditTrail.FromState.Value;
          row["ToState"] = (object) (int) stateAuditTrail.ToState;
          dataTable4.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionState", SqlDbType.Structured, (object) dataTable1);
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionStateHistory", SqlDbType.Structured, (object) dataTable2);
        this.db.AddInParameter(storedProcCommand, "@tblFromStateToState", SqlDbType.Structured, (object) dataTable3);
        this.db.AddInParameter(storedProcCommand, "@tblAuditTrail", SqlDbType.Structured, (object) dataTable4);
        if (theIssue.IssueDetail.MSBankingGroup != null)
          this.db.AddInParameter(storedProcCommand, "@MSBankingGroupTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<CompetitiveMsBankingGroup>(theIssue.IssueDetail.MSBankingGroup.ToList<CompetitiveMsBankingGroup>()));
        if (theIssue.MiscFieldsValueDetail != null)
          this.db.AddInParameter(storedProcCommand, "@PropertySetValueTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<PropertySetValue>(theIssue.MiscFieldsValueDetail.ToList<PropertySetValue>()));
        this.db.AddParameter(storedProcCommand, "@ReturnValue", DbType.Int32, ParameterDirection.ReturnValue, string.Empty, DataRowVersion.Default, (object) null);
        if (pricing != null && pricing.Rows.Count > 0)
          this.db.AddInParameter(storedProcCommand, "@IssuePricing_TVP", SqlDbType.Structured, (object) pricing);
        if (underlyingRatingDetail != null && underlyingRatingDetail.Rows.Count > 0)
          this.db.AddInParameter(storedProcCommand, "@IssueRatings_TVP", SqlDbType.Structured, (object) underlyingRatingDetail);
        this.db.ExecuteNonQuery(storedProcCommand);
        num = Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
        int result;
        if (int.TryParse(Convert.ToString(storedProcCommand.Parameters["@ReturnValue"].Value), out result))
        {
          if (result == -1)
            num = -1L;
        }
      }
      return num;
    }

    public CompetitiveIssue FetchByKey(long currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssueCompByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int32, (object) currentId);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) -31);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (!reader.Read())
            return new CompetitiveIssue();
          IRowMapper<CompetitiveIssueDetail> rowMapper = MapBuilder<CompetitiveIssueDetail>.MapAllProperties().DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.Notes)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.ReviewComments)).DoNotMap<bool?>((Expression<Func<CompetitiveIssueDetail, bool?>>) (x => x.IsIssueInitiatedFromParentOpportunity)).DoNotMap<bool?>((Expression<Func<CompetitiveIssueDetail, bool?>>) (x => x.IsIssueInitiatedFromParentRFP)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactPrefix)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactFirstName)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactLastName)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactSuffix)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactJobTitle)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.IssuerAddress)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactAddress)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.LeadBanker)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactEmail)).DoNotMap<long?>((Expression<Func<CompetitiveIssueDetail, long?>>) (x => x.G17Type)).DoNotMap<bool?>((Expression<Func<CompetitiveIssueDetail, bool?>>) (x => x.IsTransactionPriced)).DoNotMap<bool?>((Expression<Func<CompetitiveIssueDetail, bool?>>) (x => x.IsPnLExistForAllJobNumbers)).Build();
          CompetitiveIssue competitiveIssue = new CompetitiveIssue();
          competitiveIssue.IssueDetail = rowMapper.MapRow((IDataRecord) reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.MAExemptions = this.GetMAExemptionDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.SelectedMERGReviewTypes = this.GetMERGReviewTypeDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.PriorityOfOrders = this.GetPriorityOfOrderDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.FirmOtherRoles = this.GetFirmOtherRoles(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.Series = (IEnumerable<Series>) this.GetSeriesDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.NotesHistory = (IEnumerable<Notes>) this.GetNotesHistory(reader);
          if (reader.NextResult())
            competitiveIssue.Partner = this.GetPartnerDetails(reader);
          if (reader.NextResult())
            competitiveIssue.PaidCheckDetail = this.GetPaidChequetails(reader);
          if (reader.NextResult())
            competitiveIssue.ReceivedCheckDetail = this.GetReceivedChequeDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueFee = this.GetIssueFee(reader);
          if (reader.NextResult())
            competitiveIssue.ExternalPartners = this.GetExternalPartners(reader);
          if (reader.NextResult())
            competitiveIssue.InternalPartners = this.GetInternalPartners(reader);
          if (reader.NextResult())
            competitiveIssue.InternalPartnerBankRMs = this.GetInternalPartnerBankRMs(reader);
          if (reader.NextResult())
            competitiveIssue.IssueContact = (IEnumerable<IssueContact>) this.GetIssueContacts(reader);
          if (reader.NextResult())
            competitiveIssue.WorkflowStateTransitions = this.GetStateTransitions(reader);
          if (reader.NextResult())
            competitiveIssue.IssueReviews = (IEnumerable<ReviewComments>) this.GetIssueReviews(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.G17Details = (IEnumerable<G17Detail>) this.GetG17Details(reader);
          if (reader.NextResult())
          {
            while (reader.Read())
              competitiveIssue.IssueDetail.G17ContactAddress = Convert.ToString(reader["G17ContactAddress"]);
          }
          if (reader.NextResult())
          {
            while (reader.Read())
            {
              competitiveIssue.IssueDetail.G17ContactPrefix = Convert.ToString(reader["G17ContactPrefix"]);
              competitiveIssue.IssueDetail.G17ContactFirstName = Convert.ToString(reader["G17ContactFirstName"]);
              competitiveIssue.IssueDetail.G17ContactLastName = Convert.ToString(reader["G17ContactLastName"]);
              competitiveIssue.IssueDetail.G17ContactSuffix = Convert.ToString(reader["G17ContactSuffix"]);
              competitiveIssue.IssueDetail.G17ContactJobTitle = Convert.ToString(reader["G17ContactJobTitle"]);
              competitiveIssue.IssueDetail.G17ContactEmail = Convert.ToString(reader["G17ContactEmail"]);
            }
          }
          if (reader.NextResult())
          {
            while (reader.Read())
              competitiveIssue.IssueDetail.LeadBanker = reader["LeadBankerName"].ToString();
          }
          if (reader.NextResult())
          {
            while (reader.Read())
              competitiveIssue.IssueDetail.IssuerAddress = reader["IssuerAddresse"].ToString();
          }
          if (reader.NextResult())
            competitiveIssue.IssueDetail.MSBankingGroup = (IEnumerable<CompetitiveMsBankingGroup>) this.GetMSBankingGroupDetails(reader);
          if (reader.NextResult())
            competitiveIssue.GoodFaithDetails = this.GetGoodFaithIssueDetails(reader);
          return competitiveIssue;
        }
      }
    }

    public CompetitiveIssue CopyIssueByKey(long currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CopyIssueByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int32, (object) currentId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (!reader.Read())
            return new CompetitiveIssue();
          IRowMapper<CompetitiveIssueDetail> rowMapper1 = MapBuilder<CompetitiveIssueDetail>.MapAllProperties().DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.Notes)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.ReviewComments)).DoNotMap<bool?>((Expression<Func<CompetitiveIssueDetail, bool?>>) (x => x.IsIssueInitiatedFromParentOpportunity)).DoNotMap<bool?>((Expression<Func<CompetitiveIssueDetail, bool?>>) (x => x.IsIssueInitiatedFromParentRFP)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.FirmRoleTxt)).DoNotMap<long?>((Expression<Func<CompetitiveIssueDetail, long?>>) (x => x.G17Type)).DoNotMap<bool>((Expression<Func<CompetitiveIssueDetail, bool>>) (x => x.IsFreeze)).DoNotMap<bool?>((Expression<Func<CompetitiveIssueDetail, bool?>>) (x => x.IsTransactionPriced)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactPrefix)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactFirstName)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactLastName)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactSuffix)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactJobTitle)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.IssuerAddress)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactAddress)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.LeadBanker)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.G17ContactEmail)).DoNotMap<long?>((Expression<Func<CompetitiveIssueDetail, long?>>) (x => x.G17Type)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.TaxStatus)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.FirmRoleValue)).DoNotMap<string>((Expression<Func<CompetitiveIssueDetail, string>>) (x => x.IssueUnderlyingRating)).Build();
          CompetitiveIssue competitiveIssue = new CompetitiveIssue();
          competitiveIssue.IssueDetail = rowMapper1.MapRow((IDataRecord) reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.MAExemptions = this.GetMAExemptionDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.SelectedMERGReviewTypes = this.GetMERGReviewTypeDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.PriorityOfOrders = this.GetPriorityOfOrderDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.FirmOtherRoles = this.GetFirmOtherRoles(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.Series = (IEnumerable<Series>) this.GetSeriesDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.NotesHistory = (IEnumerable<Notes>) this.GetNotesHistory(reader);
          if (reader.NextResult())
            competitiveIssue.Partner = this.GetPartnerDetails(reader);
          if (reader.NextResult())
            competitiveIssue.PaidCheckDetail = this.GetPaidChequetails(reader);
          if (reader.NextResult())
            competitiveIssue.ReceivedCheckDetail = this.GetReceivedChequeDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueFee = this.GetIssueFee(reader);
          if (reader.NextResult())
          {
            List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
            IRowMapper<ExternalPartner> rowMapper2 = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).DoNotMap<int>((Expression<Func<ExternalPartner, int>>) (x => x.Version)).Build();
            while (reader.Read())
              externalPartnerList.Add(rowMapper2.MapRow((IDataRecord) reader));
            competitiveIssue.ExternalPartners = externalPartnerList;
          }
          if (reader.NextResult())
            competitiveIssue.InternalPartners = this.GetInternalPartners(reader);
          if (reader.NextResult())
            competitiveIssue.InternalPartnerBankRMs = this.GetInternalPartnerBankRMs(reader);
          if (reader.NextResult())
            competitiveIssue.AppTransactionClientContacts = this.GetClientContacts(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.MAExemptions = this.GetMAExemptionDetails(reader);
          if (reader.NextResult())
            competitiveIssue.IssueDetail.MSBankingGroup = (IEnumerable<CompetitiveMsBankingGroup>) this.GetMSBankingGroupDetails(reader);
          return competitiveIssue;
        }
      }
    }

    private List<AppTransactionClientContact> GetClientContacts(
      IDataReader reader)
    {
      List<AppTransactionClientContact> transactionClientContactList = new List<AppTransactionClientContact>();
      IRowMapper<AppTransactionClientContact> rowMapper = MapBuilder<AppTransactionClientContact>.MapAllProperties().Build();
      while (reader.Read())
        transactionClientContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionClientContactList;
    }

    public IEnumerable<CompetitiveIssue> FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllIssue"))
      {
        List<CompetitiveIssue> competitiveIssueList = new List<CompetitiveIssue>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<CompetitiveIssue> rowMapper = MapBuilder<CompetitiveIssue>.MapAllProperties().Build();
          while (dataReader.Read())
            competitiveIssueList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<CompetitiveIssue>) competitiveIssueList;
      }
    }

    public void Delete(int currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_DeleteIssueByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void UpdateIsJobAdminInformedAsTrue(long currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_UpdateIsJobAdminInformedAsTrue"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int32, (object) currentId);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IDataReader Query(QueryDefinition definition, int pageSize, int pageNumber)
    {
      SqlCriterionVisitResult criterionVisitResult = new SqlCriterionVisitor((IDictionary<string, string>) this.knownMappings).Build(definition.Criterion);
      string str1 = string.Empty;
      foreach (Ordering ordering in definition.Order)
        str1 = string.Format("{0}{1} {2},", (object) str1, (object) ordering.PropertyName, (object) ordering.Direction);
      string str2 = string.IsNullOrEmpty(str1) ? "IssueName asc" : str1.Substring(0, str1.Length - 1);
      string str3 = string.Empty;
      if (definition.Projection != null && definition.Projection.Count<string>() > 0)
      {
        List<string> list1 = CompetitiveIssueRepository.knownProjection.Where<SearchSQLField>((Func<SearchSQLField, bool>) (x => definition.Projection.Contains<string>(x.Name))).Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.Query)).ToList<string>();
        List<string> list2 = CompetitiveIssueRepository.knownProjection.Where<SearchSQLField>((Func<SearchSQLField, bool>) (x => !definition.Projection.Contains<string>(x.Name))).Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.EmptyQuery)).ToList<string>();
        if (list1 != null && list1.Count > 0)
          str3 = list1.Join<string>(", ");
        if (list2 != null && list2.Count > 0)
          str3 = !string.IsNullOrEmpty(str3) ? string.Format("{0}, {1}", (object) str3, (object) list2.Join<string>(", ")) : list2.Join<string>(", ");
      }
      else
      {
        List<string> list = CompetitiveIssueRepository.knownProjection.Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.EmptyQuery)).ToList<string>();
        if (list != null && list.Count > 0)
          str3 = list.Join<string>(", ");
      }
      StringBuilder stringBuilder1 = new StringBuilder();
      StringBuilder stringBuilder2 = new StringBuilder();
      if (definition.SubQueryDefinitions != null && definition.SubQueryDefinitions.Count > 0)
      {
        foreach (SubQueryDefinition subQueryDefinition in definition.SubQueryDefinitions)
        {
          if (subQueryDefinition.Field.ToLower() == "issuestatusid")
          {
            stringBuilder1.Append(string.Format(" LEFT OUTER JOIN (SELECT DISTINCT ATS.AppTransactionID FROM AppTransactionState ATS WHERE ATS.StateID in ({0})) ATS ON view_IssueSearch.AppTransactionID = ATS.AppTransactionID", (object) subQueryDefinition.Value));
            stringBuilder2.Append(" AND ATS.AppTransactionID IS NULL");
          }
        }
      }
      string str4 = string.Format("{0} {1}", (object) criterionVisitResult.WhereClause, (object) stringBuilder2);
      DbCommand sqlStringCommand = this.db.GetSqlStringCommand(string.Format("{0} Select COUNT(*) From(SELECT DISTINCT view_IssueSearch.AppTransactionID, {1} FROM view_IssueSearch {2} WHERE {3} GROUP BY view_IssueSearch.AppTransactionID, SeriesID)k", (object) string.Format("WITH cte as (Select *, ROW_NUMBER() OVER (ORDER BY {0}) AS _row From((SELECT DISTINCT view_IssueSearch.AppTransactionID, {1} FROM view_IssueSearch {2} WHERE {3} GROUP BY view_IssueSearch.AppTransactionID, SeriesID))k) SELECT * FROM cte WHERE _row BETWEEN {4} AND {5} ", (object) str2, (object) str3, (object) stringBuilder1, (object) str4, (object) (pageNumber + 1), (object) (pageSize + pageNumber)), (object) str3, (object) stringBuilder1, (object) str4));
      sqlStringCommand.CommandTimeout = 120;
      sqlStringCommand.Parameters.AddRange((Array) criterionVisitResult.Parameters);
      return this.db.ExecuteReader(sqlStringCommand);
    }

    public IEnumerable<string> FetchIssueNames(string issueName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssueNames"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueName", DbType.String, (object) RepositoryBase.EscapeForLike(issueName));
        List<string> stringList = new List<string>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            stringList.Add(dataReader.GetString(0));
        }
        return (IEnumerable<string>) stringList;
      }
    }

    public IEnumerable<string> FetchDealNames(string dealName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchDealNames"))
      {
        this.db.AddInParameter(storedProcCommand, "@dealName", DbType.String, (object) RepositoryBase.EscapeForLike(dealName));
        List<string> stringList = new List<string>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            stringList.Add(dataReader.GetString(0));
        }
        return (IEnumerable<string>) stringList;
      }
    }

    public IEnumerable<SearchSetting> FetchAllBookmarks() => this.SearchSettingRepository.FetchByModuleName("Issue Search", (long) this.AppUser.Id);

    public void SaveBookMark(SearchSetting searchSetting)
    {
      searchSetting.Module = "Issue Search";
      searchSetting.UserId = (long) this.AppUser.Id;
      this.SearchSettingRepository.Save(searchSetting);
    }

    public void DeleteBookMark(long bookmarkId) => this.SearchSettingRepository.Delete(bookmarkId);

    public void SaveTransactionReport(IssueTransactionReport issueTransactionReport)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveCheckDetails"))
      {
        DataTable dataTable1 = this.ConvertListToDataTable<CheckDetail>(issueTransactionReport.PaidCheckDetail);
        DataTable dataTable2 = this.ConvertListToDataTable<CheckDetail>(issueTransactionReport.ReceivedCheckDetail);
        dataTable1.Merge(dataTable2);
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) issueTransactionReport.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@CheckDetailTableType_TVP", SqlDbType.Structured, (object) dataTable1);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void SaveInternalPartner(List<InternalPartner> internalPartner)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveInternalPartner"))
      {
        this.db.AddInParameter(storedProcCommand, "@InternalPartnerTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<InternalPartner>(internalPartner));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public void SaveExternalPartner(List<ExternalPartner> theIssueExternalPartner)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveExternalPartner"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueExternalPartnerTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<ExternalPartner>(theIssueExternalPartner));
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IDataReader FetchIssuePartnerContactsByKey(
      long currentId,
      long appTransactionID,
      long externalPartnerID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssuePartnerContactByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerID", DbType.Int64, (object) currentId);
        if (appTransactionID != 0L)
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        else
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) null);
        this.db.AddInParameter(storedProcCommand, "@ExternalPartnerID", DbType.Int64, (object) externalPartnerID);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public void SaveIssuePartnerContacts(IssuePartnerContact issuePartnerContact)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveIsuePartnerContact"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerID", DbType.Int64, (object) issuePartnerContact.PartnerID);
        this.db.AddInParameter(storedProcCommand, "@PartnerContactID", DbType.Int64, (object) issuePartnerContact.PartnerContactID);
        this.db.AddInParameter(storedProcCommand, "@ExternalPartnerID", DbType.Int64, (object) issuePartnerContact.ExternalPartnerID);
        this.db.AddInParameter(storedProcCommand, "@Name", DbType.String, (object) issuePartnerContact.PartnerContactName);
        this.db.AddInParameter(storedProcCommand, "@Title", DbType.String, (object) issuePartnerContact.Title);
        this.db.AddInParameter(storedProcCommand, "@StreetAddress", DbType.String, (object) issuePartnerContact.StreetAddress);
        this.db.AddInParameter(storedProcCommand, "@City", DbType.String, (object) issuePartnerContact.City);
        this.db.AddInParameter(storedProcCommand, "@State", DbType.Int64, (object) issuePartnerContact.State);
        this.db.AddInParameter(storedProcCommand, "@Zip", DbType.String, (object) issuePartnerContact.Zip);
        this.db.AddInParameter(storedProcCommand, "@Phone", DbType.String, (object) issuePartnerContact.Phone);
        this.db.AddInParameter(storedProcCommand, "@Email", DbType.String, (object) issuePartnerContact.Email);
        this.db.AddInParameter(storedProcCommand, "@IsActive", DbType.Boolean, (object) issuePartnerContact.IsActive);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public IEnumerable<ExternalPartner> FetchIssueExternalPartnerByIssueKey(
      long currentId)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchExternalPartnerByIssueKey"))
      {
        this.db.AddInParameter(cmd, "@AppTransactionId", DbType.Int64, (object) currentId);
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<ExternalPartner> mapper = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.InsertedIssueContact)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).DoNotMap<int>((Expression<Func<ExternalPartner, int>>) (x => x.Version)).Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<ExternalPartner>) null;
        }
      }
    }

    public IEnumerable<InternalPartner> FetchIssueInternalPartnerByIssueKey(
      long currentId)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchInternalPartnerByIssueKey"))
      {
        this.db.AddInParameter(cmd, "@AppTransactionId", DbType.Int64, (object) currentId);
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<InternalPartner> mapper = MapBuilder<InternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<int>((Expression<Func<InternalPartner, int>>) (x => x.Version)).Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<InternalPartner>) null;
        }
      }
    }

    public IDataReader FetchIssuePipeline(long advisoryAgentType)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchCompetitiveIssuePipeline"))
      {
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@AdvisoryAgentType", DbType.Int64, (object) advisoryAgentType);
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IEnumerable<IssueContact> FetchIssueContactsByIssueKey(
      long currentId)
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetchIssueContactsByIssueID"))
      {
        this.db.AddInParameter(cmd, "@AppTransactionId", DbType.Int64, (object) currentId);
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<IssueContact> mapper = MapBuilder<IssueContact>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<IssueContact>) null;
        }
      }
    }

    public IDataReader FetchIssueAuditTrail(long appTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAuditTrailsByIssueID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionID);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchPnlAuditTrail(long appTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPnlAuditTrailsByIssueID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionID);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public bool CheckForDuplicateIssueName(long appTransactionID, string issueName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CheckDuplicateIssueName"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@IssueName", DbType.String, (object) issueName);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public DataSet FetchFinalPricingReport(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchFinalPricingReportData"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionId);
        DbDataAdapter dataAdapter = this.db.DbProviderFactory.CreateDataAdapter();
        storedProcCommand.Connection = this.db.CreateConnection();
        dataAdapter.SelectCommand = storedProcCommand;
        DataSet dataSet = new DataSet();
        dataAdapter.Fill(dataSet);
        return dataSet;
      }
    }

    public DataSet FetchDistributionListReport(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_IssueWiseDistributionReport"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionId);
        DbDataAdapter dataAdapter = this.db.DbProviderFactory.CreateDataAdapter();
        storedProcCommand.Connection = this.db.CreateConnection();
        dataAdapter.SelectCommand = storedProcCommand;
        DataSet dataSet = new DataSet();
        dataAdapter.Fill(dataSet);
        return dataSet;
      }
    }

    public IDataReader FetchCalendar()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchCompetitiveCalendar"))
      {
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IEnumerable<Partner> FetchAllPartner()
    {
      using (DbCommand cmd = this.db.GetStoredProcCommand("usp_FetcAllPartner"))
      {
        using (IDataReader reader = this.db.ExecuteReader(cmd))
        {
          IRowMapper<Partner> mapper = MapBuilder<Partner>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<Partner>) null;
        }
      }
    }

    public Dictionary<CompetitiveIssueEnums.IssueStatus, CompetitiveIssueEnums.IssueStatus> FetchHistoryByAppTransactionID(
      long appTransactionID)
    {
      Dictionary<CompetitiveIssueEnums.IssueStatus, CompetitiveIssueEnums.IssueStatus> dictionary;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchHistoryByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          dictionary = new Dictionary<CompetitiveIssueEnums.IssueStatus, CompetitiveIssueEnums.IssueStatus>();
          int ordinal1 = dataReader.GetOrdinal("ParentStateID");
          int ordinal2 = dataReader.GetOrdinal("StateID");
          while (dataReader.Read())
          {
            CompetitiveIssueEnums.IssueStatus int32_1 = (CompetitiveIssueEnums.IssueStatus) dataReader.GetInt32(ordinal1);
            CompetitiveIssueEnums.IssueStatus int32_2 = (CompetitiveIssueEnums.IssueStatus) dataReader.GetInt32(ordinal2);
            dictionary.Add(int32_1, int32_2);
          }
        }
      }
      return dictionary;
    }

    public Dictionary<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveIssueEnums.IssueG37FormStatus> FetchG37HistoryByAppTransactionID(
      long appTransactionID)
    {
      Dictionary<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveIssueEnums.IssueG37FormStatus> dictionary;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchHistoryByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          dictionary = new Dictionary<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveIssueEnums.IssueG37FormStatus>();
          int ordinal1 = dataReader.GetOrdinal("ParentStateID");
          int ordinal2 = dataReader.GetOrdinal("StateID");
          while (dataReader.Read())
          {
            CompetitiveIssueEnums.IssueG37FormStatus int32_1 = (CompetitiveIssueEnums.IssueG37FormStatus) dataReader.GetInt32(ordinal1);
            CompetitiveIssueEnums.IssueG37FormStatus int32_2 = (CompetitiveIssueEnums.IssueG37FormStatus) dataReader.GetInt32(ordinal2);
            dictionary.Add(int32_1, int32_2);
          }
        }
      }
      return dictionary;
    }

    public bool UpdateStatusTracking(long appTransactionID, List<int> rfpStatusList, int entityID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEntityStateTracking_New"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityID);
        DataTable dataTable = new DataTable();
        dataTable.Columns.Add("ID", typeof (int));
        foreach (int rfpStatus in rfpStatusList)
        {
          DataRow row = dataTable.NewRow();
          row["ID"] = (object) rfpStatus;
          dataTable.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblCurrentState", SqlDbType.Structured, (object) dataTable);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public List<UploadedDocumentType> FetchUploadedDocumentTypes(
      long entityID)
    {
      List<UploadedDocumentType> uploadedDocumentTypeList = new List<UploadedDocumentType>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssueDocumentTypes"))
      {
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<UploadedDocumentType> rowMapper = MapBuilder<UploadedDocumentType>.MapAllProperties().Build();
          while (dataReader.Read())
            uploadedDocumentTypeList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return uploadedDocumentTypeList;
    }

    public bool IsPnLExistForAllJobNumbers(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_IsPnLExistForAllJobNumbers"))
      {
        this.db.AddInParameter(storedProcCommand, "@appTransactionId", SqlDbType.BigInt, (object) appTransactionId);
        this.db.AddOutParameter(storedProcCommand, "@OutIsPnLExistForAllJobNumbers", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@OutIsPnLExistForAllJobNumbers"));
      }
    }

    private DataTable TruncateColumns(DataTable dt)
    {
      List<string> stringList = new List<string>();
      foreach (DataColumn column in (InternalDataCollectionBase) dt.Columns)
      {
        if (column.ColumnName != "SeriesID" && column.ColumnName != "SeriesCode" && (column.ColumnName != "SeriesName" && column.ColumnName != "JobNumber") && (column.ColumnName != "RateType" && column.ColumnName != "FedTax" && column.ColumnName != "ParAmount"))
          stringList.Add(column.ColumnName);
      }
      foreach (string name in stringList)
        dt.Columns.Remove(name);
      dt.AcceptChanges();
      return dt;
    }

    private DataTable GetG17DetailDataTable(List<G17Detail> theG17Details)
    {
      theG17Details = theG17Details.ToList<G17Detail>();
      return this.ConvertListToDataTable<G17Detail>(theG17Details);
    }

    private List<CompetitiveMsBankingGroup> GetMSBankingGroupDetails(
      IDataReader reader)
    {
      List<CompetitiveMsBankingGroup> competitiveMsBankingGroupList = new List<CompetitiveMsBankingGroup>();
      IRowMapper<CompetitiveMsBankingGroup> rowMapper = MapBuilder<CompetitiveMsBankingGroup>.MapAllProperties().Build();
      while (reader.Read())
        competitiveMsBankingGroupList.Add(rowMapper.MapRow((IDataRecord) reader));
      return competitiveMsBankingGroupList;
    }

    private IEnumerable<MAExemptionDetail> GetMAExemptionDetails(
      IDataReader reader)
    {
      List<MAExemptionDetail> maExemptionDetailList = new List<MAExemptionDetail>();
      IRowMapper<MAExemptionDetail> rowMapper = MapBuilder<MAExemptionDetail>.MapAllProperties().DoNotMap<long>((Expression<Func<MAExemptionDetail, long>>) (x => x.MAExemptionID)).DoNotMap<int>((Expression<Func<MAExemptionDetail, int>>) (x => x.Version)).Build();
      int num = 1;
      while (reader.Read())
      {
        MAExemptionDetail maExemptionDetail = rowMapper.MapRow((IDataRecord) reader);
        maExemptionDetail.MAExemptionID = (long) num++;
        maExemptionDetailList.Add(maExemptionDetail);
      }
      return (IEnumerable<MAExemptionDetail>) maExemptionDetailList;
    }

    private IEnumerable<MERGReviewTypeDetail> GetMERGReviewTypeDetails(
      IDataReader reader)
    {
      List<MERGReviewTypeDetail> reviewTypeDetailList = new List<MERGReviewTypeDetail>();
      IRowMapper<MERGReviewTypeDetail> rowMapper = MapBuilder<MERGReviewTypeDetail>.MapAllProperties().Build();
      while (reader.Read())
        reviewTypeDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return (IEnumerable<MERGReviewTypeDetail>) reviewTypeDetailList;
    }

    private IEnumerable<PriorityOfOrderDetail> GetPriorityOfOrderDetails(
      IDataReader reader)
    {
      List<PriorityOfOrderDetail> priorityOfOrderDetailList = new List<PriorityOfOrderDetail>();
      IRowMapper<PriorityOfOrderDetail> rowMapper = MapBuilder<PriorityOfOrderDetail>.MapAllProperties().Build();
      while (reader.Read())
        priorityOfOrderDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return (IEnumerable<PriorityOfOrderDetail>) priorityOfOrderDetailList;
    }

    private IEnumerable<FirmOtherRole> GetFirmOtherRoles(IDataReader reader)
    {
      List<FirmOtherRole> firmOtherRoleList = new List<FirmOtherRole>();
      IRowMapper<FirmOtherRole> rowMapper = MapBuilder<FirmOtherRole>.MapAllProperties().Build();
      while (reader.Read())
        firmOtherRoleList.Add(rowMapper.MapRow((IDataRecord) reader));
      return (IEnumerable<FirmOtherRole>) firmOtherRoleList;
    }

    private List<Series> GetSeriesDetails(IDataReader reader)
    {
      List<Series> seriesList = new List<Series>();
      IRowMapper<Series> rowMapper = MapBuilder<Series>.MapAllProperties().DoNotMap<string>((Expression<Func<Series, string>>) (x => x.CreditEnhancementProvide)).DoNotMap<string>((Expression<Func<Series, string>>) (x => x.CreditEnhancementType)).DoNotMap<int>((Expression<Func<Series, int>>) (x => x.Version)).Build();
      while (reader.Read())
      {
        Series series = rowMapper.MapRow((IDataRecord) reader);
        series.EnhancementRatingBySeries = this.BindEnhancementRatingBySeries(series.SeriesID);
        seriesList.Add(series);
      }
      return seriesList;
    }

    private List<EnhancementRatingBySeries> BindEnhancementRatingBySeries(
      long SeriesId)
    {
      List<EnhancementRatingBySeries> enhancementRatingBySeriesList = new List<EnhancementRatingBySeries>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchEnhancementRatingBySeriesId"))
      {
        this.db.AddInParameter(storedProcCommand, "@SeriesID", DbType.Int64, (object) SeriesId);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<EnhancementRatingBySeries> rowMapper = MapBuilder<EnhancementRatingBySeries>.MapAllProperties().Build();
          while (dataReader.Read())
            enhancementRatingBySeriesList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return enhancementRatingBySeriesList;
    }

    private List<Notes> GetNotesHistory(IDataReader reader)
    {
      List<Notes> notesList = new List<Notes>();
      IRowMapper<Notes> rowMapper = MapBuilder<Notes>.MapAllProperties().DoNotMap<string>((Expression<Func<Notes, string>>) (m => m.NotesDateTimeString)).Build();
      while (reader.Read())
        notesList.Add(rowMapper.MapRow((IDataRecord) reader));
      return notesList;
    }

    private List<Partner> GetPartnerDetails(IDataReader reader)
    {
      List<Partner> partnerList = new List<Partner>();
      IRowMapper<Partner> rowMapper = MapBuilder<Partner>.MapAllProperties().DoNotMap<long>((Expression<Func<Partner, long>>) (x => x.PartnerType)).Build();
      while (reader.Read())
        partnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return partnerList;
    }

    private List<CheckDetail> GetPaidChequetails(IDataReader reader)
    {
      List<CheckDetail> checkDetailList = new List<CheckDetail>();
      IRowMapper<CheckDetail> rowMapper = MapBuilder<CheckDetail>.MapAllProperties().DoNotMap<bool>((Expression<Func<CheckDetail, bool>>) (x => x.IsDirty)).Build();
      while (reader.Read())
        checkDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return checkDetailList;
    }

    private List<CheckDetail> GetReceivedChequeDetails(IDataReader reader)
    {
      List<CheckDetail> checkDetailList = new List<CheckDetail>();
      IRowMapper<CheckDetail> rowMapper = MapBuilder<CheckDetail>.MapAllProperties().DoNotMap<bool>((Expression<Func<CheckDetail, bool>>) (x => x.IsDirty)).Build();
      while (reader.Read())
        checkDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return checkDetailList;
    }

    private IssueFee GetIssueFee(IDataReader reader)
    {
      IssueFee issueFee = new IssueFee();
      IRowMapper<IssueFee> rowMapper = MapBuilder<IssueFee>.MapAllProperties().Build();
      if (reader.Read())
        issueFee = rowMapper.MapRow((IDataRecord) reader);
      return issueFee;
    }

    private DataTable GetCheckDetails(
      List<CheckDetail> paidCheckDetail,
      List<CheckDetail> receivedCheckDetail)
    {
      paidCheckDetail = paidCheckDetail.Where<CheckDetail>((Func<CheckDetail, bool>) (x => x.IsDirty)).ToList<CheckDetail>();
      receivedCheckDetail = receivedCheckDetail.Where<CheckDetail>((Func<CheckDetail, bool>) (x => x.IsDirty)).ToList<CheckDetail>();
      DataTable dataTable = new DataTable("PaidCheckDetail");
      dataTable.Columns.Add(new DataColumn("CheckDetailID", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("AppTransactionID", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("SyndicateMemberID", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("CheckDate", Type.GetType("System.DateTime")));
      dataTable.Columns.Add(new DataColumn("CheckAmount", Type.GetType("System.Decimal")));
      dataTable.Columns.Add(new DataColumn("IsSent", Type.GetType("System.Boolean")));
      dataTable.Columns.Add(new DataColumn("PartnerName", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("IsDeleted", Type.GetType("System.Boolean")));
      foreach (CheckDetail checkDetail in paidCheckDetail)
      {
        DataRow row = dataTable.NewRow();
        row["CheckDetailID"] = (object) checkDetail.CheckDetailID;
        row["AppTransactionID"] = (object) checkDetail.AppTransactionID;
        row["SyndicateMemberID"] = (object) checkDetail.SyndicateMemberID;
        row["CheckDate"] = (object) checkDetail.CheckDate;
        row["CheckAmount"] = (object) checkDetail.CheckAmount;
        row["IsSent"] = (object) checkDetail.IsSent;
        row["PartnerName"] = (object) checkDetail.PartnerName;
        row["IsDeleted"] = (object) checkDetail.IsDeleted;
        dataTable.Rows.Add(row);
      }
      DataTable table = new DataTable("ReceivedCheckDetail");
      table.Columns.Add(new DataColumn("CheckDetailID", Type.GetType("System.Double")));
      table.Columns.Add(new DataColumn("AppTransactionID", Type.GetType("System.Double")));
      table.Columns.Add(new DataColumn("SyndicateMemberID", Type.GetType("System.Double")));
      table.Columns.Add(new DataColumn("CheckDate", Type.GetType("System.DateTime")));
      table.Columns.Add(new DataColumn("CheckAmount", Type.GetType("System.Decimal")));
      table.Columns.Add(new DataColumn("IsSent", Type.GetType("System.Boolean")));
      table.Columns.Add(new DataColumn("PartnerName", Type.GetType("System.String")));
      table.Columns.Add(new DataColumn("IsDeleted", Type.GetType("System.Boolean")));
      foreach (CheckDetail checkDetail in receivedCheckDetail)
      {
        DataRow row = table.NewRow();
        row["CheckDetailID"] = (object) checkDetail.CheckDetailID;
        row["AppTransactionID"] = (object) checkDetail.AppTransactionID;
        row["SyndicateMemberID"] = (object) DBNull.Value;
        row["CheckDate"] = (object) checkDetail.CheckDate;
        row["CheckAmount"] = (object) checkDetail.CheckAmount;
        row["IsSent"] = (object) checkDetail.IsSent;
        row["PartnerName"] = (object) checkDetail.PartnerName;
        row["IsDeleted"] = (object) checkDetail.IsDeleted;
        table.Rows.Add(row);
      }
      dataTable.Merge(table);
      return dataTable;
    }

    private List<ExternalPartner> GetExternalPartners(IDataReader reader)
    {
      List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
      IRowMapper<ExternalPartner> rowMapper = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.InsertedIssueContact)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).DoNotMap<int>((Expression<Func<ExternalPartner, int>>) (x => x.Version)).Build();
      while (reader.Read())
        externalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return externalPartnerList;
    }

    private List<InternalPartner> GetInternalPartners(IDataReader reader)
    {
      List<InternalPartner> internalPartnerList = new List<InternalPartner>();
      IRowMapper<InternalPartner> rowMapper = MapBuilder<InternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<int>((Expression<Func<InternalPartner, int>>) (x => x.Version)).Build();
      while (reader.Read())
        internalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerList;
    }

    private List<InternalPartnerBankRM> GetInternalPartnerBankRMs(
      IDataReader reader)
    {
      List<InternalPartnerBankRM> internalPartnerBankRmList = new List<InternalPartnerBankRM>();
      IRowMapper<InternalPartnerBankRM> rowMapper = MapBuilder<InternalPartnerBankRM>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartnerBankRM, bool>>) (x => x.IsDeleted)).Build();
      while (reader.Read())
        internalPartnerBankRmList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerBankRmList;
    }

    private DataTable GetAppTransactionClientContactDataTable(
      List<AppTransactionClientContact> theAppTransactionClientContacts)
    {
      theAppTransactionClientContacts = theAppTransactionClientContacts.ToList<AppTransactionClientContact>();
      return this.ConvertListToDataTable<AppTransactionClientContact>(theAppTransactionClientContacts);
    }

    private DataTable GetExternalPartnerDataTable(
      List<ExternalPartner> theIssueExternalPartner)
    {
      theIssueExternalPartner = theIssueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.IsDirty)).ToList<ExternalPartner>();
      return this.ConvertListToDataTable<ExternalPartner>(theIssueExternalPartner);
    }

    private DataTable GetInternalPartnerDataTable(List<InternalPartner> internalPartner)
    {
      internalPartner = internalPartner.Where<InternalPartner>((Func<InternalPartner, bool>) (x => x.IsDirty)).ToList<InternalPartner>();
      DataTable dataTable = this.ConvertListToDataTable<InternalPartner>(internalPartner);
      foreach (DataRow dataRow in dataTable.Select("IsPrimary='Yes' OR IsPrimary='No'"))
        dataRow["IsPrimary"] = dataRow["IsPrimary"].ToString() == "Yes" ? (object) "1" : (object) "0";
      return dataTable;
    }

    private List<IssueContact> GetIssueContacts(IDataReader reader)
    {
      List<IssueContact> issueContactList = new List<IssueContact>();
      IRowMapper<IssueContact> rowMapper = MapBuilder<IssueContact>.MapAllProperties().Build();
      while (reader.Read())
        issueContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return issueContactList;
    }

    private List<AppTransactionStateTransition> GetStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    private List<ReviewComments> GetIssueReviews(IDataReader reader)
    {
      List<ReviewComments> reviewCommentsList = new List<ReviewComments>();
      IRowMapper<ReviewComments> rowMapper = MapBuilder<ReviewComments>.MapAllProperties().DoNotMap<string>((Expression<Func<ReviewComments, string>>) (m => m.ReviewCommentDateTimeString)).Build();
      while (reader.Read())
        reviewCommentsList.Add(rowMapper.MapRow((IDataRecord) reader));
      return reviewCommentsList;
    }

    private List<G17Detail> GetG17Details(IDataReader reader)
    {
      List<G17Detail> g17DetailList = new List<G17Detail>();
      IRowMapper<G17Detail> rowMapper = MapBuilder<G17Detail>.MapAllProperties().DoNotMap<long>((Expression<Func<G17Detail, long>>) (x => x.G17ID)).DoNotMap<int>((Expression<Func<G17Detail, int>>) (x => x.Version)).DoNotMap<string>((Expression<Func<G17Detail, string>>) (x => x.G17TypeName)).Build();
      int num = 1;
      while (reader.Read())
      {
        G17Detail g17Detail = rowMapper.MapRow((IDataRecord) reader);
        g17Detail.G17ID = (long) num++;
        g17DetailList.Add(g17Detail);
      }
      return g17DetailList;
    }

    public long Save(
      CompetitiveG37Form theG37Form,
      Dictionary<int, int> history,
      List<CompetitiveIssueG37FormFromStateToState> fromToStateList,
      List<CompetitiveIssueG37FormFromStateToState> stateAuditTrailList)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveG37Form"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theG37Form.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@ParentAppTransactionID", DbType.Int64, (object) theG37Form.ParentAppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@CompBid", DbType.Boolean, (object) theG37Form.CompBid);
        this.db.AddInParameter(storedProcCommand, "@NegoBid", DbType.Boolean, (object) theG37Form.NegoBid);
        SqlDatabase db1 = this.db;
        DbCommand command1 = storedProcCommand;
        Decimal? nullable1 = theG37Form.EsmtCheck;
        // ISSUE: variable of a boxed type
        __Boxed<Decimal?> local1 = (System.ValueType) (nullable1.HasValue ? nullable1 : new Decimal?());
        db1.AddInParameter(command1, "@EsmtCheck", DbType.Decimal, (object) local1);
        this.db.AddInParameter(storedProcCommand, "@Description", DbType.String, (object) theG37Form.Description);
        SqlDatabase db2 = this.db;
        DbCommand command2 = storedProcCommand;
        DateTime? nullable2 = theG37Form.AcctClosedDate;
        // ISSUE: variable of a boxed type
        __Boxed<DateTime?> local2 = (System.ValueType) (nullable2.HasValue ? nullable2 : new DateTime?());
        db2.AddInParameter(command2, "@AcctClosedDate", DbType.DateTime, (object) local2);
        SqlDatabase db3 = this.db;
        DbCommand command3 = storedProcCommand;
        byte? nullable3 = theG37Form.OrdRetail;
        // ISSUE: variable of a boxed type
        __Boxed<byte?> local3 = (System.ValueType) (nullable3.HasValue ? nullable3 : new byte?());
        db3.AddInParameter(command3, "@OrdRetail", DbType.Int32, (object) local3);
        SqlDatabase db4 = this.db;
        DbCommand command4 = storedProcCommand;
        nullable3 = theG37Form.OrdPreSale;
        // ISSUE: variable of a boxed type
        __Boxed<byte?> local4 = (System.ValueType) (nullable3.HasValue ? nullable3 : new byte?());
        db4.AddInParameter(command4, "@OrdPreSale", DbType.Int32, (object) local4);
        SqlDatabase db5 = this.db;
        DbCommand command5 = storedProcCommand;
        nullable3 = theG37Form.OrdNetDesig;
        // ISSUE: variable of a boxed type
        __Boxed<byte?> local5 = (System.ValueType) (nullable3.HasValue ? nullable3 : new byte?());
        db5.AddInParameter(command5, "@OrdNetDesig", DbType.Int32, (object) local5);
        SqlDatabase db6 = this.db;
        DbCommand command6 = storedProcCommand;
        nullable3 = theG37Form.OrdGroupNet;
        // ISSUE: variable of a boxed type
        __Boxed<byte?> local6 = (System.ValueType) (nullable3.HasValue ? nullable3 : new byte?());
        db6.AddInParameter(command6, "@OrdGroupNet", DbType.Int32, (object) local6);
        SqlDatabase db7 = this.db;
        DbCommand command7 = storedProcCommand;
        nullable3 = theG37Form.OrdMember;
        // ISSUE: variable of a boxed type
        __Boxed<byte?> local7 = (System.ValueType) (nullable3.HasValue ? nullable3 : new byte?());
        db7.AddInParameter(command7, "@OrdMember", DbType.Int32, (object) local7);
        this.db.AddInParameter(storedProcCommand, "@Deviation", DbType.String, (object) theG37Form.Deviation);
        SqlDatabase db8 = this.db;
        DbCommand command8 = storedProcCommand;
        nullable1 = theG37Form.CusipFee;
        // ISSUE: variable of a boxed type
        __Boxed<Decimal?> local8 = (System.ValueType) (nullable1.HasValue ? nullable1 : new Decimal?());
        db8.AddInParameter(command8, "@CusipFee", DbType.Decimal, (object) local8);
        SqlDatabase db9 = this.db;
        DbCommand command9 = storedProcCommand;
        nullable1 = theG37Form.IpreoFee;
        // ISSUE: variable of a boxed type
        __Boxed<Decimal?> local9 = (System.ValueType) (nullable1.HasValue ? nullable1 : new Decimal?());
        db9.AddInParameter(command9, "@IpreoFee", DbType.Decimal, (object) local9);
        SqlDatabase db10 = this.db;
        DbCommand command10 = storedProcCommand;
        nullable1 = theG37Form.MacFee;
        // ISSUE: variable of a boxed type
        __Boxed<Decimal?> local10 = (System.ValueType) (nullable1.HasValue ? nullable1 : new Decimal?());
        db10.AddInParameter(command10, "@MacFee", DbType.Decimal, (object) local10);
        SqlDatabase db11 = this.db;
        DbCommand command11 = storedProcCommand;
        nullable1 = theG37Form.InsuranceFee;
        // ISSUE: variable of a boxed type
        __Boxed<Decimal?> local11 = (System.ValueType) (nullable1.HasValue ? nullable1 : new Decimal?());
        db11.AddInParameter(command11, "@InsuranceFee", DbType.Decimal, (object) local11);
        SqlDatabase db12 = this.db;
        DbCommand command12 = storedProcCommand;
        nullable1 = theG37Form.BondCounselFee;
        // ISSUE: variable of a boxed type
        __Boxed<Decimal?> local12 = (System.ValueType) (nullable1.HasValue ? nullable1 : new Decimal?());
        db12.AddInParameter(command12, "@BondCounselFee", DbType.Decimal, (object) local12);
        this.db.AddInParameter(storedProcCommand, "@SetupBy", DbType.String, (object) theG37Form.SetUpBy);
        SqlDatabase db13 = this.db;
        DbCommand command13 = storedProcCommand;
        nullable2 = theG37Form.SetUpDate;
        // ISSUE: variable of a boxed type
        __Boxed<DateTime?> local13 = (System.ValueType) (nullable2.HasValue ? nullable2 : new DateTime?());
        db13.AddInParameter(command13, "@SetupDate", DbType.DateTime, (object) local13);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@CreatedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedOn", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@Version", DbType.Int32, (object) theG37Form.Version);
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) 3);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailDate", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        DataTable dataTable1 = new DataTable();
        dataTable1.Columns.Add("AppTransactionID", typeof (long));
        dataTable1.Columns.Add("StateID", typeof (int));
        foreach (long g37Statu in theG37Form.G37Status)
        {
          DataRow row = dataTable1.NewRow();
          row["AppTransactionID"] = (object) theG37Form.AppTransactionID;
          row["StateID"] = (object) int.Parse(g37Statu.ToString());
          dataTable1.Rows.Add(row);
        }
        DataTable dataTable2 = new DataTable();
        dataTable2.Columns.Add("AppTransactionID", typeof (long));
        dataTable2.Columns.Add("ParentStateID", typeof (int));
        dataTable2.Columns.Add("StateID", typeof (int));
        if (history != null && history.Count > 0)
        {
          foreach (KeyValuePair<int, int> keyValuePair in history)
          {
            DataRow row = dataTable2.NewRow();
            row["AppTransactionID"] = (object) theG37Form.AppTransactionID;
            row["ParentStateID"] = (object) keyValuePair.Key;
            row["StateID"] = (object) keyValuePair.Value;
            dataTable2.Rows.Add(row);
          }
        }
        DataTable dataTable3 = new DataTable();
        dataTable3.Columns.Add("FromState", typeof (int));
        dataTable3.Columns.Add("ToState", typeof (int));
        foreach (CompetitiveIssueG37FormFromStateToState fromToState in fromToStateList)
        {
          DataRow row = dataTable3.NewRow();
          CompetitiveIssueEnums.IssueG37FormStatus? fromState = fromToState.FromState;
          if (fromState.HasValue)
          {
            DataRow dataRow = row;
            fromState = fromToState.FromState;
            // ISSUE: variable of a boxed type
            __Boxed<int> local14 = (System.ValueType) (int) fromState.Value;
            dataRow["FromState"] = (object) local14;
          }
          else
            row["FromState"] = (object) DBNull.Value;
          row["ToState"] = (object) (int) fromToState.ToState;
          dataTable3.Rows.Add(row);
        }
        DataTable dataTable4 = new DataTable();
        dataTable4.Columns.Add("FromState", typeof (int));
        dataTable4.Columns.Add("ToState", typeof (int));
        foreach (CompetitiveIssueG37FormFromStateToState stateAuditTrail in stateAuditTrailList)
        {
          DataRow row = dataTable4.NewRow();
          row["FromState"] = (object) (int) stateAuditTrail.FromState.Value;
          row["ToState"] = (object) (int) stateAuditTrail.ToState;
          dataTable4.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionState", SqlDbType.Structured, (object) dataTable1);
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionStateHistory", SqlDbType.Structured, (object) dataTable2);
        this.db.AddInParameter(storedProcCommand, "@tblFromStateToState", SqlDbType.Structured, (object) dataTable3);
        this.db.AddInParameter(storedProcCommand, "@tblAuditTrail", SqlDbType.Structured, (object) dataTable4);
        this.db.AddParameter(storedProcCommand, "@ReturnValue", DbType.Int32, ParameterDirection.ReturnValue, string.Empty, DataRowVersion.Default, (object) null);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
      }
    }

    public G37Form FetchG37FormByKey(long g37FormKey)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchG37FormByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@G37FormId", DbType.Int32, (object) g37FormKey);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<G37Form>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new G37Form();
      }
    }

    public IDataReader FetchG37FormViewByIssueKey(
      long issueKey,
      string SyndicateMemberRole)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchG37FormByIssueKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@ParentAppTransactionID", DbType.Int64, (object) issueKey);
        this.db.AddInParameter(storedProcCommand, "@SyndicateMemberRole", DbType.String, (object) SyndicateMemberRole);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public bool SaveRegulatoryCheckList(
      CompetitiveIssueRegulatoryCheckList issueRegulatoryCheckList,
      long appTransactionId)
    {
      bool flag = false;
      try
      {
        using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveRegulatoryCheckListComp"))
        {
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionId);
          this.db.AddInParameter(storedProcCommand, "@WasRFP", DbType.Boolean, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.WasRFP);
          this.db.AddInParameter(storedProcCommand, "@IsRegisteredMunicipalAdvisor", DbType.Boolean, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IsRegisteredMunicipalAdvisor);
          this.db.AddInParameter(storedProcCommand, "@IsIRMACertificationReceived", DbType.Boolean, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IsIRMACertificationReceived);
          this.db.AddInParameter(storedProcCommand, "@IRMACertificationDate", DbType.Date, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IRMACertificationDate);
          this.db.AddInParameter(storedProcCommand, "@IRMACertificationExpiryDate", DbType.Date, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IRMACertificationExpiryDate);
          this.db.AddInParameter(storedProcCommand, "@IsIRMAReprentativeSentToClientAndIssuer", DbType.Boolean, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IsIRMAReprentativeSentToClientAndIssuer);
          this.db.AddInParameter(storedProcCommand, "@IRMAPresentationDate", DbType.Date, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IRMAPresentationDate);
          this.db.AddInParameter(storedProcCommand, "@IsIRMAPresentationCopyRetained", DbType.Boolean, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IsIRMAPresentationCopyRetained);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoCopyRetained", DbType.String, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.ReasonForNoCopyRetained);
          this.db.AddInParameter(storedProcCommand, "@UnderWriterOrRemarketingAgentMethod", DbType.String, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.UnderWriterOrRemarketingAgentMethod);
          this.db.AddInParameter(storedProcCommand, "@EngagementDate", DbType.Date, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.EngagementDate);
          this.db.AddInParameter(storedProcCommand, "@IssuerID", DbType.String, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IssuerID);
          this.db.AddInParameter(storedProcCommand, "@FinancialAdvisor", DbType.String, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.FinancialAdvisor);
          this.db.AddInParameter(storedProcCommand, "@EvidenceOfEngagement", DbType.String, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.EvidenceOfEngagement);
          this.db.AddInParameter(storedProcCommand, "@IRMANotPerfect", DbType.String, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.IRMANotPerfect);
          this.db.AddInParameter(storedProcCommand, "@EarlistDateOfEngagement", DbType.Date, (object) issueRegulatoryCheckList.MunicipalAdvisorRegCheckList.EarlistDateOfEngagement);
          this.db.AddInParameter(storedProcCommand, "@IsObtainedAndReviwedStatement", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IsObtainedAndReviwedStatement);
          this.db.AddInParameter(storedProcCommand, "@TypeOfDoc", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.TypeOfDoc);
          this.db.AddInParameter(storedProcCommand, "@DateReceived", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DateReceived);
          this.db.AddInParameter(storedProcCommand, "@DateReviewed", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DateReviewed);
          this.db.AddInParameter(storedProcCommand, "@MethodDocDeemedFinal", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.MethodDocDeemedFinal);
          this.db.AddInParameter(storedProcCommand, "@DateDocDeemedFinal", DbType.DateTime, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DateDocDeemedFinal);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNotObtainingOrReview", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.ReasonForNotObtainingOrReview);
          this.db.AddInParameter(storedProcCommand, "@HasMeetAdoptedGuideLines", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.HasMeetAdoptedGuideLines);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNotAdoptingGuideLines", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.ReasonForNotAdoptingGuideLines);
          this.db.AddInParameter(storedProcCommand, "@WasOfficialDocAmended", DbType.Int64, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.WasOfficialDocAmended);
          this.db.AddInParameter(storedProcCommand, "@DocAmendedDate", DbType.Date, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DocAmendedDate);
          this.db.AddInParameter(storedProcCommand, "@IsSlaMeet", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IsSlaMeet);
          this.db.AddInParameter(storedProcCommand, "@IssuerAndObligorCovenantMade", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IssuerAndObligorCovenantMade);
          this.db.AddInParameter(storedProcCommand, "@SlaViolationReason", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.SlaViolationReason);
          this.db.AddInParameter(storedProcCommand, "@IsDilegenceReviewConducted", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IsDilegenceReviewConducted);
          this.db.AddInParameter(storedProcCommand, "@IsDilegenceCallOrMeeting", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IsDilegenceCallOrMeeting);
          this.db.AddInParameter(storedProcCommand, "@DilegenceMeetingDate", DbType.Date, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DilegenceMeetingDate);
          this.db.AddInParameter(storedProcCommand, "@DilegenceReviewMethod", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DilegenceReviewMethod);
          this.db.AddInParameter(storedProcCommand, "@DidOutSideCounselAssisted", DbType.Int64, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DidOutSideCounselAssisted);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoAssistence", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.ReasonForNoAssistence);
          this.db.AddInParameter(storedProcCommand, "@IsIssuerAndObligorAreInAggrement", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IsIssuerAndObligorAreInAggrement);
          this.db.AddInParameter(storedProcCommand, "@IssuerAndObligorAggrementPlace", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IssuerAndObligorAggrementPlace);
          this.db.AddInParameter(storedProcCommand, "@IssuerAndObligorNonAggrementReason", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IssuerAndObligorNonAggrementReason);
          this.db.AddInParameter(storedProcCommand, "@IsReviewedEMMAAndNRMSIR", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IsReviewedEMMAAndNRMSIR);
          this.db.AddInParameter(storedProcCommand, "@DidUnderWriterAssisted", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.DidUnderWriterAssisted);
          this.db.AddInParameter(storedProcCommand, "@EMMAReviewDate", DbType.Date, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.EMMAReviewDate);
          this.db.AddInParameter(storedProcCommand, "@IsIssuerAndObligorCompliance", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IsIssuerAndObligorCompliance);
          this.db.AddInParameter(storedProcCommand, "@IncidentOfNonCompliance", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.IncidentOfNonCompliance);
          this.db.AddInParameter(storedProcCommand, "@WasLegalAndComplianceConsulted", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.WasLegalAndComplianceConsulted);
          this.db.AddInParameter(storedProcCommand, "@LegalAndComplianceDate", DbType.Date, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.LegalAndComplianceDate);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoLegalConsultaion", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.ReasonForNoLegalConsultaion);
          this.db.AddInParameter(storedProcCommand, "@WasCDAFindingsSatifactory", DbType.Boolean, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.WasCDAFindingsSatifactory);
          this.db.AddInParameter(storedProcCommand, "@CDAFindingsUnSatisfactoryReason", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.CDAFindingsUnSatisfactoryReason);
          this.db.AddInParameter(storedProcCommand, "@WasLegalAndComplianceConsultedReason", DbType.String, (object) issueRegulatoryCheckList.Rule15c212RegCheckList.WasLegalAndComplianceConsultedReason);
          this.db.AddInParameter(storedProcCommand, "@IsDeliveredToIssuer", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsDeliveredToIssuer);
          this.db.AddInParameter(storedProcCommand, "@IsDeliveredToObligor", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsDeliveredToObligor);
          this.db.AddInParameter(storedProcCommand, "@DeliveryDateToIssuer", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.DeliveryDateToIssuer);
          this.db.AddInParameter(storedProcCommand, "@DeliveryDateToObligor", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.DeliveryDateToObligor);
          this.db.AddInParameter(storedProcCommand, "@RoleDisclosureSender", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.RoleDisclosureSender);
          this.db.AddInParameter(storedProcCommand, "@RoleDisclosureMethodName", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.RoleDisclosureMethodName);
          this.db.AddInParameter(storedProcCommand, "@RoleDisclosureReceipentName", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.RoleDisclosureReceipentName);
          this.db.AddInParameter(storedProcCommand, "@IsRoleDisclosureLetterCopyRetained", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsRoleDisclosureLetterCopyRetained);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNonRetainingCopy", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNonRetainingCopy);
          this.db.AddInParameter(storedProcCommand, "@IsRoleDisclosureAckReceived", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsRoleDisclosureAckReceived);
          this.db.AddInParameter(storedProcCommand, "@AckReceivedDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckReceivedDate);
          this.db.AddInParameter(storedProcCommand, "@AckExecuterName", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckExecuterName);
          this.db.AddInParameter(storedProcCommand, "@AckMethodForRoleDisclosure", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckMethodForRoleDisclosure);
          this.db.AddInParameter(storedProcCommand, "@IsCopyRetainedForRoleDisclosureAck", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsCopyRetainedForRoleDisclosureAck);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNotGettingAckForRoleDisclosre", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNotGettingAckForRoleDisclosre);
          this.db.AddInParameter(storedProcCommand, "@IsConflictDisclosureLetterDeliveredToIssuer", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsConflictDisclosureLetterDeliveredToIssuer);
          this.db.AddInParameter(storedProcCommand, "@IsConflictDisclosureLetterDeliveredToObligor", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsConflictDisclosureLetterDeliveredToObligor);
          this.db.AddInParameter(storedProcCommand, "@ConflictDisclosreLetterDeliveryDateToIssuer", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ConflictDisclosreLetterDeliveryDateToIssuer);
          this.db.AddInParameter(storedProcCommand, "@ConflictDisclosreLetterDeliveryDateToObligor", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ConflictDisclosreLetterDeliveryDateToObligor);
          this.db.AddInParameter(storedProcCommand, "@ConflictDisclosreLetterMethod", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ConflictDisclosreLetterMethod);
          this.db.AddInParameter(storedProcCommand, "@ConflictDisclosureLetterReceipentName", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ConflictDisclosureLetterReceipentName);
          this.db.AddInParameter(storedProcCommand, "@IsCopyRetainedForConflictDisclosure", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsCopyRetainedForConflictDisclosure);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNotRetaingCopyOfConflictDisclosure", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNotRetaingCopyOfConflictDisclosure);
          this.db.AddInParameter(storedProcCommand, "@IsAckReceivedOfConflictDisclosure", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsAckReceivedOfConflictDisclosure);
          this.db.AddInParameter(storedProcCommand, "@AckG17ReceivedDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckG17ReceivedDate);
          this.db.AddInParameter(storedProcCommand, "@AckConflictDisclosureExecuter", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckConflictDisclosureExecuter);
          this.db.AddInParameter(storedProcCommand, "@AckConflictMethod", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckConflictMethod);
          this.db.AddInParameter(storedProcCommand, "@IsAckCopyRetainedConflictDisclosure", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsAckCopyRetainedConflictDisclosure);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoConflictDisclosureAck", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNoConflictDisclosureAck);
          this.db.AddInParameter(storedProcCommand, "@IsG17StructureAndRoleLetterDeliveredIssuer", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsG17StructureAndRoleLetterDeliveredIssuer);
          this.db.AddInParameter(storedProcCommand, "@IsG17StructureAndRoleLetterDeliveredObligor", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsG17StructureAndRoleLetterDeliveredObligor);
          this.db.AddInParameter(storedProcCommand, "@G17SturectureAndRoleLetterDateIssuer", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.G17SturectureAndRoleLetterDateIssuer);
          this.db.AddInParameter(storedProcCommand, "@G17SturectureAndRoleLetterDateObligor", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.G17SturectureAndRoleLetterDateObligor);
          this.db.AddInParameter(storedProcCommand, "@G17SturectureAndRoleLetterSender", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.G17SturectureAndRoleLetterSender);
          this.db.AddInParameter(storedProcCommand, "@G17StructureAndRoleLetterMethod", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.G17StructureAndRoleLetterMethod);
          this.db.AddInParameter(storedProcCommand, "@G17StructureAndRoleLetterReceipent", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.G17StructureAndRoleLetterReceipent);
          this.db.AddInParameter(storedProcCommand, "@IsCopyRetainedForRoleDisclosure", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsCopyRetainedForRoleDisclosure);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNotRetaingCopyOfRoleAndSturucture", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNotRetaingCopyOfRoleAndSturucture);
          this.db.AddInParameter(storedProcCommand, "@isAckG17RoleAndStuructureLetterReceived", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsAckG17RoleAndStuructureLetterReceived);
          this.db.AddInParameter(storedProcCommand, "@AckG17RoleAndStructureLetterDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckG17RoleAndStructureLetterDate);
          this.db.AddInParameter(storedProcCommand, "@AckG17RoleAndStructureExecuter", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckG17RoleAndStructureExecuter);
          this.db.AddInParameter(storedProcCommand, "@AckG17RoleAndStructureMethod", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.AckG17RoleAndStructureMethod);
          this.db.AddInParameter(storedProcCommand, "@IsCopyRetainedG17RoleAndStructureAck", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsCopyRetainedG17RoleAndStructureAck);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoAckG17RoleAndStructure", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNoAckG17RoleAndStructure);
          this.db.AddInParameter(storedProcCommand, "@isEMMAReviewed", DbType.Int64, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.isEMMAReviewed);
          this.db.AddInParameter(storedProcCommand, "@IsUnderWriterAssistedEMMAReview", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsUnderWriterAssistedEMMAReview);
          this.db.AddInParameter(storedProcCommand, "@UnderWriterReviewDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.UnderWriterReviewDate);
          this.db.AddInParameter(storedProcCommand, "@IsUnderWriterPriceValid", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsUnderWriterPriceValid);
          this.db.AddInParameter(storedProcCommand, "@IsUnderWriterCertificateAmended", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsUnderWriterCertificateAmended);
          this.db.AddInParameter(storedProcCommand, "@IslegalAndComplianceConsulted", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IslegalAndComplianceConsulted);
          this.db.AddInParameter(storedProcCommand, "@LegalAndComplianceConsultedDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.LegalAndComplianceConsultedDate);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoEMMAReview", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNoEMMAReview);
          this.db.AddInParameter(storedProcCommand, "@isFirmPayingToMSA", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.isFirmPayingToMSA);
          this.db.AddInParameter(storedProcCommand, "@IsMSAReviewed", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.IsMSAReviewed);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNOMSAReview", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ReasonForNOMSAReview);
          this.db.AddInParameter(storedProcCommand, "@MSAName", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.MSAName);
          this.db.AddInParameter(storedProcCommand, "@MSACertification", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.MSACertification);
          this.db.AddInParameter(storedProcCommand, "@RoleLetterExplain", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.RoleLetterExplain);
          this.db.AddInParameter(storedProcCommand, "@ConflictLetterExplain", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.ConflictLetterExplain);
          this.db.AddInParameter(storedProcCommand, "@RoleDisclosureLetterExplain", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.RoleDisclosureLetterExplain);
          this.db.AddInParameter(storedProcCommand, "@StructureExplain", DbType.String, (object) issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList.StructureExplain);
          this.db.AddInParameter(storedProcCommand, "@IsOfficialStatementPostedToEMMA", DbType.Boolean, (object) issueRegulatoryCheckList.RuleG32RegulatoryCheckList.IsOfficialStatementPostedToEMMA);
          this.db.AddInParameter(storedProcCommand, "@OfficialStatementDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG32RegulatoryCheckList.OfficialStatementDate);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoPosting", DbType.String, (object) issueRegulatoryCheckList.RuleG32RegulatoryCheckList.ReasonForNoPosting);
          this.db.AddInParameter(storedProcCommand, "@IsEscrowfiledWithMSRB", DbType.Int64, (object) issueRegulatoryCheckList.RuleG32RegulatoryCheckList.IsEscrowfiledWithMSRB);
          this.db.AddInParameter(storedProcCommand, "@AggrementPostedDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG32RegulatoryCheckList.AggrementPostedDate);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoEscrowAggrement", DbType.String, (object) issueRegulatoryCheckList.RuleG32RegulatoryCheckList.ReasonForNoEscrowAggrement);
          this.db.AddInParameter(storedProcCommand, "@IsLiquidyCommentsPosted", DbType.Int64, (object) issueRegulatoryCheckList.RuleG34cRegulatoryCheckList.IsLiquidyCommentsPosted);
          this.db.AddInParameter(storedProcCommand, "@DocumentPostedDate", DbType.Date, (object) issueRegulatoryCheckList.RuleG34cRegulatoryCheckList.DocumentPostedDate);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoPostingRuleG34", DbType.String, (object) issueRegulatoryCheckList.RuleG34cRegulatoryCheckList.ReasonForNoPosting);
          this.db.AddInParameter(storedProcCommand, "@IsSoleManaged", DbType.Boolean, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.IsSoleManaged);
          this.db.AddInParameter(storedProcCommand, "@LegalFeesNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.LegalFeesNotes);
          this.db.AddInParameter(storedProcCommand, "@SyndicateNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.SyndicateNotes);
          this.db.AddInParameter(storedProcCommand, "@DTCChargesNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.DTCChargesNotes);
          this.db.AddInParameter(storedProcCommand, "@IPREONotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.IPREONotes);
          this.db.AddInParameter(storedProcCommand, "@CUSIPFeeNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.CUSIPFeeNotes);
          this.db.AddInParameter(storedProcCommand, "@MSRBandStateSpecificFeeNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.MSRBandStateSpecificFeeNotes);
          this.db.AddInParameter(storedProcCommand, "@AgentNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.AgentNotes);
          this.db.AddInParameter(storedProcCommand, "@TravelNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.TravelNotes);
          this.db.AddInParameter(storedProcCommand, "@MealsClientEntertainNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.MealsClientEntertainNotes);
          this.db.AddInParameter(storedProcCommand, "@InternetNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.InternetNotes);
          this.db.AddInParameter(storedProcCommand, "@PrintingNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.PrintingNotes);
          this.db.AddInParameter(storedProcCommand, "@MailDeliveryExpensesNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.MailDeliveryExpensesNotes);
          this.db.AddInParameter(storedProcCommand, "@MarketingNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.MarketingNotes);
          this.db.AddInParameter(storedProcCommand, "@CoManagerExpensesNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.CoManagerExpensesNotes);
          this.db.AddInParameter(storedProcCommand, "@OtherNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.OtherNotes);
          this.db.AddInParameter(storedProcCommand, "@LessExpenseReimbursementNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.LessExpenseReimbursementNotes);
          this.db.AddInParameter(storedProcCommand, "@TotalExpensesNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.TotalExpensesNotes);
          this.db.AddInParameter(storedProcCommand, "@TransactionExpensesNotes", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.TransactionExpensesNotes);
          this.db.AddInParameter(storedProcCommand, "@AreExpensesAuthorized", DbType.Boolean, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.AreExpensesAuthorized);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNonAutorization", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.ReasonForNonAutorization);
          this.db.AddInParameter(storedProcCommand, "@IsDocAttachedToCheckList", DbType.Boolean, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.IsDocAttachedToCheckList);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNotAttachingCheckList", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.ReasonForNotAttachingCheckList);
          this.db.AddInParameter(storedProcCommand, "@Discripiencies", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.Discripiencies);
          this.db.AddInParameter(storedProcCommand, "@LeadMSBanker", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.LeadMSBanker);
          this.db.AddInParameter(storedProcCommand, "@LeadMSBankerSignDate", DbType.Date, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.LeadMSBankerSignDate);
          this.db.AddInParameter(storedProcCommand, "@SeriesSupervisor", DbType.String, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.SeriesSupervisor);
          this.db.AddInParameter(storedProcCommand, "@SeriesSupervisorDate", DbType.Date, (object) issueRegulatoryCheckList.ExpenseRegulatoryCheckList.SeriesSupervisorDate);
          this.db.AddInParameter(storedProcCommand, "@IsObtainedAndReviwedFinalDoc", DbType.Boolean, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.IsObtainedAndReviwedFinalDoc);
          this.db.AddInParameter(storedProcCommand, "@TypeOfDocument", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.TypeOfDocument);
          this.db.AddInParameter(storedProcCommand, "@DateReceived_DDRC", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.DateReceived);
          this.db.AddInParameter(storedProcCommand, "@DateReviewed_DDRC", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.DateReviewed);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNotObtainingOrReviewFinalDoc", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.ReasonForNotObtainingOrReviewFinalDoc);
          this.db.AddInParameter(storedProcCommand, "@WasDisclosureDocumentAmended", DbType.Int64, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.WasDisclosureDocumentAmended);
          this.db.AddInParameter(storedProcCommand, "@DocumentAmendedDate", DbType.Date, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.DocumentAmendedDate);
          this.db.AddInParameter(storedProcCommand, "@IsDueDilegenceReviewConducted", DbType.Boolean, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.IsDueDilegenceReviewConducted);
          this.db.AddInParameter(storedProcCommand, "@IsDueDilegenceCallOrMeeting", DbType.Boolean, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.IsDueDilegenceCallOrMeeting);
          this.db.AddInParameter(storedProcCommand, "@DueDilegenceMeetingDate", DbType.Date, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.DueDilegenceMeetingDate);
          this.db.AddInParameter(storedProcCommand, "@DueDilegenceReviewMethod", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.DueDilegenceReviewMethod);
          this.db.AddInParameter(storedProcCommand, "@DidOutSideCounselDiligence", DbType.Int64, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.DidOutSideCounselDiligence);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoDueDiligence", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.ReasonForNoDueDiligence);
          this.db.AddInParameter(storedProcCommand, "@HasIssuerObligorCovenanted", DbType.Boolean, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.HasIssuerObligorCovenanted);
          this.db.AddInParameter(storedProcCommand, "@IssuerObligorCovenanted", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.IssuerObligorCovenanted);
          this.db.AddInParameter(storedProcCommand, "@ReasonForNoIssuerObligorCovenanted", DbType.String, (object) issueRegulatoryCheckList.DisclosureDiligenceRegChecklist.ReasonForNoIssuerObligorCovenanted);
          this.db.ExecuteNonQuery(storedProcCommand);
          flag = true;
        }
        return flag;
      }
      catch (Exception ex)
      {
        throw;
      }
    }

    public IDataReader GetIssueRegulatoryCheckListReader(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_FetchIssueRegulatoryChecklistCompByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        this.db.AddInParameter(storedProcCommand, "@LBFromStateId", DbType.Int32, (object) 64);
        this.db.AddInParameter(storedProcCommand, "@LBToStateId", DbType.Int32, (object) 66);
        this.db.AddInParameter(storedProcCommand, "@SPFromStateId", DbType.Int32, (object) 68);
        this.db.AddInParameter(storedProcCommand, "@SPToStateId", DbType.Int32, (object) 70);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public CompetitiveIssueRegulatoryCheckList FetchIssueRegulatoryCheckList(
      long appTransactionId)
    {
      CompetitiveIssueRegulatoryCheckList regulatoryCheckList = new CompetitiveIssueRegulatoryCheckList();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("Usp_FetchIssueRegulatoryChecklistCompByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        this.db.AddInParameter(storedProcCommand, "@LBFromStateId", DbType.Int32, (object) 64);
        this.db.AddInParameter(storedProcCommand, "@LBToStateId", DbType.Int32, (object) 66);
        this.db.AddInParameter(storedProcCommand, "@SPFromStateId", DbType.Int32, (object) 68);
        this.db.AddInParameter(storedProcCommand, "@SPToStateId", DbType.Int32, (object) 70);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (reader.Read())
          {
            IRowMapper<CompetitiveIssueDetailCheckList> rowMapper = MapBuilder<CompetitiveIssueDetailCheckList>.MapAllProperties().DoNotMap<bool>((Expression<Func<CompetitiveIssueDetailCheckList, bool>>) (x => x.IsViewOnly)).DoNotMap<bool>((Expression<Func<CompetitiveIssueDetailCheckList, bool>>) (x => x.CanSaveRegulatoryChecklist)).DoNotMap<bool>((Expression<Func<CompetitiveIssueDetailCheckList, bool>>) (x => x.CannotGenerateRegulatoryChecklist)).Build();
            regulatoryCheckList.IssueDetailCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveMunicipalAdvisorRegCheckList> rowMapper = MapBuilder<CompetitiveMunicipalAdvisorRegCheckList>.MapAllProperties().Build();
            regulatoryCheckList.MunicipalAdvisorRegCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveRule15c212RegCheckList> rowMapper = MapBuilder<CompetitiveRule15c212RegCheckList>.MapAllProperties().DoNotMap<long>((Expression<Func<CompetitiveRule15c212RegCheckList, long>>) (x => x.Rule15c212RegCheckListID)).Build();
            regulatoryCheckList.Rule15c212RegCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveRuleG17G23ResulatoryCheckList> rowMapper = MapBuilder<CompetitiveRuleG17G23ResulatoryCheckList>.MapAllProperties().DoNotMap<long>((Expression<Func<CompetitiveRuleG17G23ResulatoryCheckList, long>>) (x => x.RuleG17G23RegCheckListID)).Build();
            regulatoryCheckList.RuleG17G23ResulatoryCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveRuleG32RegulatoryCheckList> rowMapper = MapBuilder<CompetitiveRuleG32RegulatoryCheckList>.MapAllProperties().DoNotMap<long>((Expression<Func<CompetitiveRuleG32RegulatoryCheckList, long>>) (x => x.RuleG32RegCheckListID)).Build();
            regulatoryCheckList.RuleG32RegulatoryCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveRuleG34cRegulatoryCheckList> rowMapper = MapBuilder<CompetitiveRuleG34cRegulatoryCheckList>.MapAllProperties().DoNotMap<long>((Expression<Func<CompetitiveRuleG34cRegulatoryCheckList, long>>) (x => x.RuleG34cRegCheckListID)).Build();
            regulatoryCheckList.RuleG34cRegulatoryCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveExpenseRegulatoryCheckList> rowMapper = MapBuilder<CompetitiveExpenseRegulatoryCheckList>.MapAllProperties().Build();
            regulatoryCheckList.ExpenseRegulatoryCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveRegulatoryPnLChecklist> rowMapper = MapBuilder<CompetitiveRegulatoryPnLChecklist>.MapAllProperties().Build();
            regulatoryCheckList.RegulatoryPnLCheckList = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult() && reader.Read())
          {
            IRowMapper<CompetitiveDisclosureDiligenceRegChecklist> rowMapper = MapBuilder<CompetitiveDisclosureDiligenceRegChecklist>.MapAllProperties().Build();
            regulatoryCheckList.DisclosureDiligenceRegChecklist = rowMapper.MapRow((IDataRecord) reader);
          }
          if (reader.NextResult())
            regulatoryCheckList.ClientMAExemptionDetail = this.GetClientMAExemptionDetail(reader);
        }
      }
      return regulatoryCheckList;
    }

    private List<ClientMAExemptionDetail> GetClientMAExemptionDetail(
      IDataReader reader)
    {
      List<ClientMAExemptionDetail> maExemptionDetailList = new List<ClientMAExemptionDetail>();
      IRowMapper<ClientMAExemptionDetail> rowMapper = MapBuilder<ClientMAExemptionDetail>.MapAllProperties().Build();
      while (reader.Read())
        maExemptionDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return maExemptionDetailList;
    }

    public BidDetail FetchBidDetailsByKey(long currentId, long entityId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchBidDetailsById"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) currentId);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          BidDetail bidDetail = new BidDetail();
          if (reader.Read())
          {
            bidDetail = MapBuilder<BidDetail>.MapAllProperties().DoNotMap<List<BidDetailSeries>>((Expression<Func<BidDetail, List<BidDetailSeries>>>) (x => x.bidDetailSeries)).Build().MapRow((IDataRecord) reader);
            if (reader.NextResult())
              bidDetail.bidDetailSeries = this.GetBidDetails(reader);
          }
          return bidDetail;
        }
      }
    }

    public void SaveIssueBidDetails(
      long appTransactionID,
      BidDetail bidDetails,
      DataTable bidSeriesDt)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveIssueBidDetails"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Double, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@Pos_Url", DbType.String, (object) bidDetails.Pos_Url);
        this.db.AddInParameter(storedProcCommand, "@Nos_Url", DbType.String, (object) bidDetails.Nos_Url);
        this.db.AddInParameter(storedProcCommand, "@Os_Url", DbType.String, (object) bidDetails.Os_Url);
        this.db.AddInParameter(storedProcCommand, "@Nos2_Url", DbType.String, (object) bidDetails.Nos2_Url);
        this.db.AddInParameter(storedProcCommand, "@IPREOIssuerName", DbType.String, (object) bidDetails.IPREOIssuerName);
        this.db.AddInParameter(storedProcCommand, "@IPREOIssueStatus", DbType.String, (object) bidDetails.IPREOIssueStatus);
        this.db.AddInParameter(storedProcCommand, "@Last_Sale", DbType.String, (object) bidDetails.Last_Sale);
        this.db.AddInParameter(storedProcCommand, "@IssueBidDetails", SqlDbType.Structured, (object) bidSeriesDt);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public CompetitiveMucc FetchMuccDetailsByKey(long currentId, long entityId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchMuccDetailsById"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int64, (object) currentId);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          CompetitiveMucc competitiveMucc = new CompetitiveMucc();
          if (!reader.Read())
            return competitiveMucc;
          IRowMapper<CompetitiveMuccIssueDetails> rowMapper = MapBuilder<CompetitiveMuccIssueDetails>.MapAllProperties().Build();
          competitiveMucc.MuccIssueDetail = rowMapper.MapRow((IDataRecord) reader);
          if (reader.NextResult())
            competitiveMucc.MuccDetail = this.GetMuccIssueDetails(reader);
          if (reader.NextResult())
            competitiveMucc.MuccInternalPartner = this.GetInternalPartnerDetails(reader);
          if (reader.NextResult())
            competitiveMucc.MuccExternalPartner = this.GetExternalPartnerDetails(reader);
          if (reader.NextResult())
            competitiveMucc.MuccSyndicateMember = this.GetSyndicateMemberDetails(reader);
          return competitiveMucc;
        }
      }
    }

    public long SaveMucc(CompetitiveMucc theMucc)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveMuccDetail"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) theMucc.MuccDetail.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@SyndicateCompensation", DbType.String, (object) theMucc.MuccDetail.SyndicateCompensation);
        this.db.AddInParameter(storedProcCommand, "@MSSwapExposure", DbType.String, (object) theMucc.MuccDetail.MSSwapExposure);
        this.db.AddInParameter(storedProcCommand, "@AgreedUponProceduresLetter", DbType.String, (object) theMucc.MuccDetail.AgreedUponProceduresLetter);
        this.db.AddInParameter(storedProcCommand, "@StatusofDiligenceReview", DbType.String, (object) theMucc.MuccDetail.StatusofDiligenceReview);
        this.db.AddInParameter(storedProcCommand, "@StatusofRegulatoryChecklist", DbType.String, (object) theMucc.MuccDetail.StatusofRegulatoryChecklist);
        this.db.AddInParameter(storedProcCommand, "@LegalOptions", DbType.String, (object) theMucc.MuccDetail.LegalOptions);
        this.db.AddInParameter(storedProcCommand, "@KeyIssuesforMUCCConsideration", DbType.String, (object) theMucc.MuccDetail.KeyIssuesforMUCCConsideration);
        this.db.AddInParameter(storedProcCommand, "@MorganStanleyRelationship", DbType.String, (object) theMucc.MuccDetail.MorganStanleyRelationship);
        this.db.AddInParameter(storedProcCommand, "@IssuerBorrowerOverviewandCreditSummary", DbType.String, (object) theMucc.MuccDetail.IssuerBorrowerOverviewandCreditSummary);
        this.db.AddInParameter(storedProcCommand, "@MaterialEventsandPotentialInvestorConcerns", DbType.String, (object) theMucc.MuccDetail.MaterialEventsandPotentialInvestorConcerns);
        this.db.AddInParameter(storedProcCommand, "@Covenants", DbType.String, (object) theMucc.MuccDetail.Covenants);
        this.db.AddInParameter(storedProcCommand, "@FinancialInformation", DbType.String, (object) theMucc.MuccDetail.FinancialInformation);
        this.db.AddInParameter(storedProcCommand, "@AdditionalFeeDetail", DbType.String, (object) theMucc.MuccDetail.AdditionalFeeDetail);
        this.db.AddInParameter(storedProcCommand, "@MuccManagementFee", DbType.Decimal, (object) theMucc.MuccDetail.MuccManagementFee);
        this.db.AddInParameter(storedProcCommand, "@MuccAverageTakedown", DbType.String, (object) theMucc.MuccDetail.MuccAverageTakedown);
        this.db.AddInParameter(storedProcCommand, "@MuccExpenses", DbType.String, (object) theMucc.MuccDetail.MuccExpenses);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
      }
    }

    public IDataReader ExportMuccTemplate(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchMuccDetailsByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@IssueId", DbType.Int64, (object) appTransactionId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    private CompetitiveMuccDetails GetMuccIssueDetails(IDataReader reader)
    {
      CompetitiveMuccDetails competitiveMuccDetails = new CompetitiveMuccDetails();
      IRowMapper<CompetitiveMuccDetails> rowMapper = MapBuilder<CompetitiveMuccDetails>.MapAllProperties().DoNotMap<bool>((Expression<Func<CompetitiveMuccDetails, bool>>) (x => x.IsViewOnly)).DoNotMap<bool>((Expression<Func<CompetitiveMuccDetails, bool>>) (x => x.CanSaveMuccChecklist)).Build();
      if (reader.Read())
        competitiveMuccDetails = rowMapper.MapRow((IDataRecord) reader);
      return competitiveMuccDetails;
    }

    private List<CompetitiveKeyContacts> GetInternalPartnerDetails(
      IDataReader reader)
    {
      List<CompetitiveKeyContacts> competitiveKeyContactsList = new List<CompetitiveKeyContacts>();
      IRowMapper<CompetitiveKeyContacts> rowMapper = MapBuilder<CompetitiveKeyContacts>.MapAllProperties().Build();
      while (reader.Read())
        competitiveKeyContactsList.Add(rowMapper.MapRow((IDataRecord) reader));
      return competitiveKeyContactsList;
    }

    private List<BidDetailSeries> GetBidDetails(IDataReader reader)
    {
      List<BidDetailSeries> bidDetailSeriesList = new List<BidDetailSeries>();
      IRowMapper<BidDetailSeries> rowMapper = MapBuilder<BidDetailSeries>.MapAllProperties().Build();
      while (reader.Read())
        bidDetailSeriesList.Add(rowMapper.MapRow((IDataRecord) reader));
      return bidDetailSeriesList;
    }

    private List<CompetitiveExternalContacts> GetExternalPartnerDetails(
      IDataReader reader)
    {
      List<CompetitiveExternalContacts> externalContactsList = new List<CompetitiveExternalContacts>();
      IRowMapper<CompetitiveExternalContacts> rowMapper = MapBuilder<CompetitiveExternalContacts>.MapAllProperties().Build();
      while (reader.Read())
        externalContactsList.Add(rowMapper.MapRow((IDataRecord) reader));
      return externalContactsList;
    }

    private List<CompetitiveMuccSyndicateMember> GetSyndicateMemberDetails(
      IDataReader reader)
    {
      List<CompetitiveMuccSyndicateMember> muccSyndicateMemberList = new List<CompetitiveMuccSyndicateMember>();
      IRowMapper<CompetitiveMuccSyndicateMember> rowMapper = MapBuilder<CompetitiveMuccSyndicateMember>.MapAllProperties().Build();
      while (reader.Read())
        muccSyndicateMemberList.Add(rowMapper.MapRow((IDataRecord) reader));
      return muccSyndicateMemberList;
    }

    public RevenueAttribution FetchInvestmentBankingTeamByAppID(long AppID)
    {
      RevenueAttribution revenueAttribution = new RevenueAttribution();
      List<InternalPartner> internalPartnerList = new List<InternalPartner>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchInvestmentBankingTeamByAppID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) AppID);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<InternalPartner> rowMapper = MapBuilder<InternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<int>((Expression<Func<InternalPartner, int>>) (x => x.Version)).Build();
          while (reader.Read())
            internalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
          revenueAttribution.InternalPartner = internalPartnerList;
          if (reader.NextResult() && reader.Read())
          {
            int ordinal = reader.GetOrdinal("CommaSeperatedStateID");
            revenueAttribution.CommaSeperatedStateID = reader.GetString(ordinal);
          }
          if (reader.NextResult())
            revenueAttribution.RevenuePercentage = this.GetRevenuePercentage(reader);
          if (reader.NextResult())
          {
            while (reader.Read())
              revenueAttribution.AttributionReviewed = Convert.ToString(reader["AttributionReviewed"]).ToLower();
          }
        }
      }
      return revenueAttribution;
    }

    private List<RevenuePercentage> GetRevenuePercentage(IDataReader reader)
    {
      List<RevenuePercentage> revenuePercentageList = new List<RevenuePercentage>();
      IRowMapper<RevenuePercentage> rowMapper = MapBuilder<RevenuePercentage>.MapAllProperties().Build();
      while (reader.Read())
        revenuePercentageList.Add(rowMapper.MapRow((IDataRecord) reader));
      return revenuePercentageList;
    }

    public void SaveInvestmentBankingTeam(
      List<InternalPartner> InvestmentBankingTeam,
      long AppTransactionID,
      List<RevenuePercentage> RevenuePecentage,
      string AttributionReviewed)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveRevenueAttribution"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID ", DbType.Int64, (object) AppTransactionID);
        if (InvestmentBankingTeam != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerTableType", SqlDbType.Structured, (object) this.GetInternalPartnerDataTable(InvestmentBankingTeam));
        if (RevenuePecentage != null)
          this.db.AddInParameter(storedProcCommand, "@RevenueAttributionTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<RevenuePercentage>(RevenuePecentage));
        this.db.AddInParameter(storedProcCommand, "@AttributionReviewed ", DbType.String, (object) AttributionReviewed);
        this.db.ExecuteNonQuery(storedProcCommand);
      }
    }

    public DealFileChecklist FetchDealFileChecklistByKey(long currentId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchDealFileChecklistByAppId"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) currentId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          DealFileChecklist dealFileChecklist = new DealFileChecklist();
          if (!reader.Read())
            return dealFileChecklist;
          IRowMapper<DealFileChecklistIssueDetails> rowMapper = MapBuilder<DealFileChecklistIssueDetails>.MapAllProperties().Build();
          dealFileChecklist.DealFileChecklistIssueDetail = rowMapper.MapRow((IDataRecord) reader);
          if (reader.NextResult())
            dealFileChecklist.DealFileChecklistDetail = this.GetDealFileDetails(reader);
          return dealFileChecklist;
        }
      }
    }

    public long SaveDealFileChecklist(DealFileChecklist dealFileChecklist)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveDealFileChecklist"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@DueDiligenceReviewStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.DueDiligenceReviewStatus);
        this.db.AddInParameter(storedProcCommand, "@ReviewDate", DbType.DateTime, (object) dealFileChecklist.DealFileChecklistDetail.ReviewDate);
        this.db.AddInParameter(storedProcCommand, "@ReviewingPersonnel", DbType.String, (object) dealFileChecklist.DealFileChecklistDetail.ReviewingPersonnel);
        this.db.AddInParameter(storedProcCommand, "@PreliminaryOfficialStatementStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.PreliminaryOfficialStatementStatus);
        this.db.AddInParameter(storedProcCommand, "@FinalOfficialStatementStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.FinalOfficialStatementStatus);
        this.db.AddInParameter(storedProcCommand, "@EvidenceFilingStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.EvidenceFilingStatus);
        this.db.AddInParameter(storedProcCommand, "@ContinuingDisclosureUndertakingStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.ContinuingDisclosureUndertakingStatus);
        this.db.AddInParameter(storedProcCommand, "@NoticeofSaleStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.NoticeofSaleStatus);
        this.db.AddInParameter(storedProcCommand, "@FinalOperativeDocumentsStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.FinalOperativeDocumentsStatus);
        this.db.AddInParameter(storedProcCommand, "@FinalBondInsuranceStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.FinalBondInsuranceStatus);
        this.db.AddInParameter(storedProcCommand, "@LegalOpinions", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.LegalOpinionsStatus);
        this.db.AddInParameter(storedProcCommand, "@AgreedUponProceduresStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.AgreedUponProceduresStatus);
        this.db.AddInParameter(storedProcCommand, "@ClosingCertificateStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.ClosingCertificateStatus);
        this.db.AddInParameter(storedProcCommand, "@IssuePriceCertificateStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.IssuePriceCertificateStatus);
        this.db.AddInParameter(storedProcCommand, "@ReceiptStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.ReceiptStatus);
        this.db.AddInParameter(storedProcCommand, "@DealAnnouncementStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.DealAnnouncementStatus);
        this.db.AddInParameter(storedProcCommand, "@CopyOfIpreoWiresStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.CopyOfIpreoWiresStatus);
        this.db.AddInParameter(storedProcCommand, "@CopyOfOrdersStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.CopyOfOrdersStatus);
        this.db.AddInParameter(storedProcCommand, "@CopyOfCheckWireStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.CopyOfCheckWireStatus);
        this.db.AddInParameter(storedProcCommand, "@CusipStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.CusipStatus);
        this.db.AddInParameter(storedProcCommand, "@WrittenCorrespondenceStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.WrittenCorrespondenceStatus);
        this.db.AddInParameter(storedProcCommand, "@DealTranscriptStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.DealTranscriptStatus);
        this.db.AddInParameter(storedProcCommand, "@CopySubmittedBidStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.CopySubmittedBidStatus);
        this.db.AddInParameter(storedProcCommand, "@WorkingGroupListStatus", DbType.Int64, (object) dealFileChecklist.DealFileChecklistDetail.WorkingGroupListStatus);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
      }
    }

    public IDataReader ExportDealFile(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchDealFileChecklistReportByAppId"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    private DealFileChecklistDetails GetDealFileDetails(IDataReader reader)
    {
      DealFileChecklistDetails checklistDetails = new DealFileChecklistDetails();
      IRowMapper<DealFileChecklistDetails> rowMapper = MapBuilder<DealFileChecklistDetails>.MapAllProperties().Build();
      if (reader.Read())
        checklistDetails = rowMapper.MapRow((IDataRecord) reader);
      return checklistDetails;
    }

    private CompetitiveGoodFaithDetail GetGoodFaithIssueDetails(
      IDataReader reader)
    {
      CompetitiveGoodFaithDetail competitiveGoodFaithDetail = new CompetitiveGoodFaithDetail();
      IRowMapper<CompetitiveGoodFaithDetail> rowMapper = MapBuilder<CompetitiveGoodFaithDetail>.MapAllProperties().Build();
      if (reader.Read())
        competitiveGoodFaithDetail = rowMapper.MapRow((IDataRecord) reader);
      return competitiveGoodFaithDetail;
    }
  }
}
