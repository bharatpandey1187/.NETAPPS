﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.RFPRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IRFPRepository))]
  public class RFPRepository : RepositoryBase, IRFPRepository, IQuery
  {
    private Dictionary<string, string> knownMappings;
    private static readonly List<SearchSQLField> knownProjection = new List<SearchSQLField>()
    {
      new SearchSQLField("RFPNumber"),
      new SearchSQLField("RFPName"),
      new SearchSQLField("RFPStatus"),
      new SearchSQLField("RFPReviewStatus"),
      new SearchSQLField("PowerID"),
      new SearchSQLField("Issuer"),
      new SearchSQLField("Borrower"),
      new SearchSQLField("Guarantor"),
      new SearchSQLField("RFPType"),
      new SearchSQLField("State"),
      new SearchSQLField("County"),
      new SearchSQLField("MaterialType"),
      new SearchSQLField("HybridSolutionIndicator"),
      new SearchSQLField("DualProposalProposed"),
      new SearchSQLField("InformationalMERGRequired"),
      new SearchSQLField("RFPMAExemption"),
      new SearchSQLField("RFPMAExemptionDate", "RFPMAExemptionDateValue"),
      new SearchSQLField("IRMAMAExemption"),
      new SearchSQLField("IRMAMAExemptionDate", "IRMAMAExemptionDateValue"),
      new SearchSQLField("UWMAExemption"),
      new SearchSQLField("UWMAExemptionDate", "UWMAExemptionDateValue"),
      new SearchSQLField("ApprovedDerivativeMarketer"),
      new SearchSQLField("ParAmount"),
      new SearchSQLField("ExpectedFirmRole"),
      new SearchSQLField("ExpectedFirmLiabilityPercentage"),
      new SearchSQLField("AssignedFirmRole"),
      new SearchSQLField("AssignedFirmLiabilityPercentage"),
      new SearchSQLField("LeadBanker"),
      new SearchSQLField("Banker"),
      new SearchSQLField("LeadAnalyst"),
      new SearchSQLField("Analyst"),
      new SearchSQLField("SupervisoryPrincipal"),
      new SearchSQLField("BankRM"),
      new SearchSQLField("FinancialAdvisor"),
      new SearchSQLField("EscrowVerificationAgent"),
      new SearchSQLField("EscrowSecuritiesProvider"),
      new SearchSQLField("EscrowAgentForRefundedBonds"),
      new SearchSQLField("PayingAgent"),
      new SearchSQLField("RemarketingAgent"),
      new SearchSQLField("Trustee"),
      new SearchSQLField("OtherAdvisorAgents"),
      new SearchSQLField("BondCounsel"),
      new SearchSQLField("UnderwriterCounsel"),
      new SearchSQLField("DisclosureCounsel"),
      new SearchSQLField("OtherCounsels"),
      new SearchSQLField("Purpose"),
      new SearchSQLField("TransactionType"),
      new SearchSQLField("SecurityType"),
      new SearchSQLField("GeneralCategory"),
      new SearchSQLField("FedTaxable"),
      new SearchSQLField("StateTaxable"),
      new SearchSQLField("AMTTaxable"),
      new SearchSQLField("BankQualified"),
      new SearchSQLField("GrossSpread"),
      new SearchSQLField("EstGrossRev"),
      new SearchSQLField("CreatedOn", "CreatedOnValue"),
      new SearchSQLField("ResponseDueDateTime", "ResponseDueDateTimeValue", "ResponseDueDateTimeZone"),
      new SearchSQLField("SubmissionDateTime", "SubmissionDateTimeValue", "SubmissionDateTimeZone"),
      new SearchSQLField("SupervisoryPrincipalReviewDate", "SupervisoryPrincipalReviewDateValue"),
      new SearchSQLField("SupervisoryPrincipalApprovalDate", "SupervisoryPrincipalApprovalDateValue"),
      new SearchSQLField("MoodyRatingLT"),
      new SearchSQLField("SPRatingLT"),
      new SearchSQLField("KrollRatingLT"),
      new SearchSQLField("FitchRatingLT"),
      new SearchSQLField("SentTo3Firms")
    };

    [Dependency]
    public ISearchSettingRepository SearchSettingRepository { get; set; }

    [Dependency]
    public IIssueRepository IssueRepository { get; set; }

    public RFPRepository(Dictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public long Save(
      RFP rfp,
      Dictionary<int, int> history,
      List<RfpFromStateToState> fromToStateList,
      List<RfpFromStateToState> stateAuditTrailList)
    {
      long num1 = 0;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveRFP"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) rfp.RfpDetail.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@RFPName", DbType.String, (object) rfp.RfpDetail.RFPName);
        this.db.AddInParameter(storedProcCommand, "@IssuerID", DbType.Int64, (object) rfp.RfpDetail.IssuerID);
        this.db.AddInParameter(storedProcCommand, "@BorrowerID", DbType.Int64, (object) rfp.RfpDetail.BorrowerID);
        this.db.AddInParameter(storedProcCommand, "@GuarantorID", DbType.Int64, (object) rfp.RfpDetail.GuarantorID);
        this.db.AddInParameter(storedProcCommand, "@SubmissionDateTime", DbType.DateTime, (object) rfp.RfpDetail.SubmissionDateTime);
        SqlDatabase db1 = this.db;
        DbCommand command1 = storedProcCommand;
        long? nullable1 = rfp.RfpDetail.RFPType;
        long num2 = 0;
        long? nullable2;
        if ((nullable1.GetValueOrDefault() == num2 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable2 = rfp.RfpDetail.RFPType;
        }
        else
        {
          nullable1 = new long?();
          nullable2 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local1 = (System.ValueType) nullable2;
        db1.AddInParameter(command1, "@RFPType", DbType.Int64, (object) local1);
        this.db.AddInParameter(storedProcCommand, "@ParAmount", DbType.Decimal, (object) rfp.RfpDetail.ParAmount);
        SqlDatabase db2 = this.db;
        DbCommand command2 = storedProcCommand;
        nullable1 = rfp.RfpDetail.State;
        long num3 = 0;
        long? nullable3;
        if ((nullable1.GetValueOrDefault() == num3 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable3 = rfp.RfpDetail.State;
        }
        else
        {
          nullable1 = new long?();
          nullable3 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local2 = (System.ValueType) nullable3;
        db2.AddInParameter(command2, "@State", DbType.Int64, (object) local2);
        this.db.AddInParameter(storedProcCommand, "@County", DbType.String, (object) rfp.RfpDetail.County);
        SqlDatabase db3 = this.db;
        DbCommand command3 = storedProcCommand;
        nullable1 = rfp.RfpDetail.FirmRole;
        long num4 = 0;
        long? nullable4;
        if ((nullable1.GetValueOrDefault() == num4 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable4 = rfp.RfpDetail.FirmRole;
        }
        else
        {
          nullable1 = new long?();
          nullable4 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local3 = (System.ValueType) nullable4;
        db3.AddInParameter(command3, "@FirmRole", DbType.Int64, (object) local3);
        this.db.AddInParameter(storedProcCommand, "@FirmLiabilityPerc", DbType.Decimal, (object) rfp.RfpDetail.FirmLiabilityPerc);
        SqlDatabase db4 = this.db;
        DbCommand command4 = storedProcCommand;
        nullable1 = rfp.RfpDetail.AssignedFirmRole;
        long num5 = 0;
        long? nullable5;
        if ((nullable1.GetValueOrDefault() == num5 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable5 = rfp.RfpDetail.AssignedFirmRole;
        }
        else
        {
          nullable1 = new long?();
          nullable5 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local4 = (System.ValueType) nullable5;
        db4.AddInParameter(command4, "@AssignedFirmRole", DbType.Int64, (object) local4);
        this.db.AddInParameter(storedProcCommand, "@AssignedFirmLiability", DbType.Decimal, (object) rfp.RfpDetail.AssignedFirmLiability);
        SqlDatabase db5 = this.db;
        DbCommand command5 = storedProcCommand;
        nullable1 = rfp.RfpDetail.Purpose;
        long num6 = 0;
        long? nullable6;
        if ((nullable1.GetValueOrDefault() == num6 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable6 = rfp.RfpDetail.Purpose;
        }
        else
        {
          nullable1 = new long?();
          nullable6 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local5 = (System.ValueType) nullable6;
        db5.AddInParameter(command5, "@Purpose", DbType.Int64, (object) local5);
        SqlDatabase db6 = this.db;
        DbCommand command6 = storedProcCommand;
        nullable1 = rfp.RfpDetail.GeneralCategory;
        long num7 = 0;
        long? nullable7;
        if ((nullable1.GetValueOrDefault() == num7 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable7 = rfp.RfpDetail.GeneralCategory;
        }
        else
        {
          nullable1 = new long?();
          nullable7 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local6 = (System.ValueType) nullable7;
        db6.AddInParameter(command6, "@GeneralCategory", DbType.Int64, (object) local6);
        this.db.AddInParameter(storedProcCommand, "@FedTaxable", DbType.String, (object) rfp.RfpDetail.FedTaxable);
        this.db.AddInParameter(storedProcCommand, "@StateTaxable", DbType.String, (object) rfp.RfpDetail.StateTaxable);
        this.db.AddInParameter(storedProcCommand, "@AMTTaxable", DbType.String, (object) rfp.RfpDetail.AMTTaxable);
        this.db.AddInParameter(storedProcCommand, "@BankQualified", DbType.Boolean, (object) rfp.RfpDetail.BankQualified);
        this.db.AddInParameter(storedProcCommand, "@MoodyRatingLT", DbType.String, (object) rfp.RfpDetail.MoodyRatingLT);
        this.db.AddInParameter(storedProcCommand, "@SPRatingLT", DbType.String, (object) rfp.RfpDetail.SPRatingLT);
        this.db.AddInParameter(storedProcCommand, "@FitchRatingLT", DbType.String, (object) rfp.RfpDetail.FitchRatingLT);
        this.db.AddInParameter(storedProcCommand, "@KrollRatingLT", DbType.Int64, (object) rfp.RfpDetail.KrollRatingLT);
        this.db.AddInParameter(storedProcCommand, "@ReviewComments", DbType.String, (object) rfp.RfpDetail.ReviewComments);
        if (rfp.AppTransactionClientContacts != null)
          this.db.AddInParameter(storedProcCommand, "@AppTransactionClientContactTableType", SqlDbType.Structured, (object) this.GetAppTransactionClientContactDataTable(rfp.AppTransactionClientContacts));
        if (rfp.InternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerTableType", SqlDbType.Structured, (object) this.GetInternalPartnerDataTable(rfp.InternalPartners));
        if (rfp.InternalPartnerBankRMs != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerBankRMTableType", SqlDbType.Structured, (object) this.ConvertListToDataTable<InternalPartnerBankRM>(rfp.InternalPartnerBankRMs));
        if (rfp.ExternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@RfpExternalPartnerTableType", SqlDbType.Structured, (object) this.GetExternalPartnerDataTable(rfp.ExternalPartners));
        if (rfp.RfpDetail.MAExemptionDetails != null)
          this.db.AddInParameter(storedProcCommand, "@MAExemptionDetailTableType", SqlDbType.Structured, (object) this.GetMAExemptionDetailDataTable(rfp.RfpDetail.MAExemptionDetails));
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) 4);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@BankerRole", DbType.Int64, (object) 6);
        this.db.AddInParameter(storedProcCommand, "@BankerRO", DbType.Int64, (object) 18);
        this.db.AddInParameter(storedProcCommand, "@DocumentLibraryURL", DbType.String, (object) rfp.RfpDetail.DocumentLibraryURL);
        this.db.AddInParameter(storedProcCommand, "@Version", DbType.Int32, (object) rfp.RfpDetail.Version);
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailDate", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddInParameter(storedProcCommand, "@ParentOpportunityID", DbType.Int64, (object) rfp.RfpDetail.ParentOpportunityID);
        this.db.AddInParameter(storedProcCommand, "@PowerID", DbType.String, (object) rfp.RfpDetail.PowerID);
        this.db.AddInParameter(storedProcCommand, "@HybridSolutionIndicator", DbType.Boolean, (object) rfp.RfpDetail.HybridSolutionIndicator);
        this.db.AddInParameter(storedProcCommand, "@DualProposalProposed", DbType.Boolean, (object) rfp.RfpDetail.DualProposalProposed);
        this.db.AddInParameter(storedProcCommand, "@InformationalMERGRequired", DbType.Boolean, (object) rfp.RfpDetail.InformationalMERGRequired);
        this.db.AddInParameter(storedProcCommand, "@ApprovedDerivativeMarketer", DbType.Int64, (object) rfp.RfpDetail.ApprovedDerivativeMarketer);
        this.db.AddInParameter(storedProcCommand, "@TransactionType", DbType.Int64, (object) rfp.RfpDetail.TransactionType);
        this.db.AddInParameter(storedProcCommand, "@SecurityType", DbType.Int64, (object) rfp.RfpDetail.SecurityType);
        this.db.AddInParameter(storedProcCommand, "@GrossSpread", DbType.Decimal, (object) rfp.RfpDetail.GrossSpread);
        this.db.AddInParameter(storedProcCommand, "@EstGrossRev", DbType.Decimal, (object) rfp.RfpDetail.EstGrossRev);
        this.db.AddInParameter(storedProcCommand, "@ResponseDueDateTime", DbType.DateTime, (object) rfp.RfpDetail.ResponseDueDateTime);
        this.db.AddInParameter(storedProcCommand, "@ResponseDueDateTimezone", DbType.String, (object) rfp.RfpDetail.ResponseDueDateTimezone);
        this.db.AddInParameter(storedProcCommand, "@SubmissionDateTimezone", DbType.String, (object) rfp.RfpDetail.SubmissionDateTimezone);
        this.db.AddInParameter(storedProcCommand, "@SupervisoryPrincipalReviewDate", DbType.DateTime, (object) rfp.RfpDetail.SupervisoryPrincipalReviewDate);
        this.db.AddInParameter(storedProcCommand, "@SupervisoryPrincipalApprovalDate", DbType.DateTime, (object) rfp.RfpDetail.SupervisoryPrincipalApprovalDate);
        this.db.AddInParameter(storedProcCommand, "@SupervisoryPrincipalApproverName", DbType.String, (object) rfp.RfpDetail.SupervisoryPrincipalApproverName);
        this.db.AddInParameter(storedProcCommand, "@SentTo3Firms", DbType.Boolean, (object) rfp.RfpDetail.SentTo3Firms);
        this.db.AddInParameter(storedProcCommand, "@Notes", DbType.String, (object) rfp.RfpDetail.Notes);
        this.db.AddInParameter(storedProcCommand, "@MaterialType", DbType.Int64, (object) rfp.RfpDetail.MaterialType);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        if (rfp.RfpDetail.SubmittedToMERGDate.HasValue)
          this.db.AddInParameter(storedProcCommand, "@SubmittedToMERGDate", DbType.DateTime, (object) rfp.RfpDetail.SubmittedToMERGDate.Value);
        else
          this.db.AddInParameter(storedProcCommand, "@SubmittedToMERGDate", DbType.DateTime, (object) DBNull.Value);
        this.db.AddInParameter(storedProcCommand, "@IsRFPInitiatedFromParentOpportunity", DbType.Boolean, (object) rfp.RfpDetail.IsRFPInitiatedFromParentOpportunity);
        DataTable dataTable1 = new DataTable();
        dataTable1.Columns.Add("AppTransactionID", typeof (long));
        dataTable1.Columns.Add("StateID", typeof (int));
        foreach (long rfpStatu in rfp.RfpDetail.RFPStatus)
        {
          DataRow row = dataTable1.NewRow();
          row["AppTransactionID"] = (object) rfp.RfpDetail.AppTransactionID;
          row["StateID"] = (object) int.Parse(rfpStatu.ToString());
          dataTable1.Rows.Add(row);
        }
        DataTable dataTable2 = new DataTable();
        dataTable2.Columns.Add("AppTransactionID", typeof (long));
        dataTable2.Columns.Add("ParentStateID", typeof (int));
        dataTable2.Columns.Add("StateID", typeof (int));
        if (history != null && history.Count > 0)
        {
          foreach (KeyValuePair<int, int> keyValuePair in history)
          {
            DataRow row = dataTable2.NewRow();
            row["AppTransactionID"] = (object) rfp.RfpDetail.AppTransactionID;
            row["ParentStateID"] = (object) keyValuePair.Key;
            row["StateID"] = (object) keyValuePair.Value;
            dataTable2.Rows.Add(row);
          }
        }
        DataTable dataTable3 = new DataTable();
        dataTable3.Columns.Add("FromState", typeof (int));
        dataTable3.Columns.Add("ToState", typeof (int));
        foreach (RfpFromStateToState fromToState in fromToStateList)
        {
          DataRow row = dataTable3.NewRow();
          RFP.RfpStatus? fromState = fromToState.FromState;
          if (fromState.HasValue)
          {
            DataRow dataRow = row;
            fromState = fromToState.FromState;
            // ISSUE: variable of a boxed type
            __Boxed<int> local7 = (System.ValueType) (int) fromState.Value;
            dataRow["FromState"] = (object) local7;
          }
          else
            row["FromState"] = (object) DBNull.Value;
          row["ToState"] = (object) (int) fromToState.ToState;
          dataTable3.Rows.Add(row);
        }
        DataTable dataTable4 = new DataTable();
        dataTable4.Columns.Add("FromState", typeof (int));
        dataTable4.Columns.Add("ToState", typeof (int));
        foreach (RfpFromStateToState stateAuditTrail in stateAuditTrailList)
        {
          DataRow row = dataTable4.NewRow();
          row["FromState"] = (object) (int) stateAuditTrail.FromState.Value;
          row["ToState"] = (object) (int) stateAuditTrail.ToState;
          dataTable4.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionState", SqlDbType.Structured, (object) dataTable1);
        this.db.AddInParameter(storedProcCommand, "@tblAppTransactionStateHistory", SqlDbType.Structured, (object) dataTable2);
        this.db.AddInParameter(storedProcCommand, "@tblFromStateToState", SqlDbType.Structured, (object) dataTable3);
        this.db.AddInParameter(storedProcCommand, "@tblAuditTrail", SqlDbType.Structured, (object) dataTable4);
        this.db.AddParameter(storedProcCommand, "@ReturnValue", DbType.Int32, ParameterDirection.ReturnValue, string.Empty, DataRowVersion.Default, (object) null);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        num1 = Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
        int result;
        if (int.TryParse(Convert.ToString(storedProcCommand.Parameters["@ReturnValue"].Value), out result))
        {
          if (result == -1)
            num1 = -1L;
        }
      }
      return num1;
    }

    private DataTable GetMAExemptionDetailDataTable(
      List<MAExemptionDetail> theMAExemptionDetails)
    {
      theMAExemptionDetails = theMAExemptionDetails.ToList<MAExemptionDetail>();
      return this.ConvertListToDataTable<MAExemptionDetail>(theMAExemptionDetails);
    }

    public long CreateIssue(RFP rfp)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CreateIssueFromRFP"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.String, (object) rfp.RfpDetail.AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@RFPName", DbType.String, (object) rfp.RfpDetail.RFPName);
        this.db.AddInParameter(storedProcCommand, "@IssuerID", DbType.Int64, (object) rfp.RfpDetail.IssuerID);
        SqlDatabase db1 = this.db;
        DbCommand command1 = storedProcCommand;
        long? nullable1 = rfp.RfpDetail.FirmRole;
        long num1 = 0;
        long? nullable2;
        if ((nullable1.GetValueOrDefault() == num1 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable2 = rfp.RfpDetail.FirmRole;
        }
        else
        {
          nullable1 = new long?();
          nullable2 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local1 = (System.ValueType) nullable2;
        db1.AddInParameter(command1, "@FirmRole", DbType.Int64, (object) local1);
        this.db.AddInParameter(storedProcCommand, "@ParAmount", DbType.Decimal, (object) rfp.RfpDetail.ParAmount);
        SqlDatabase db2 = this.db;
        DbCommand command2 = storedProcCommand;
        nullable1 = rfp.RfpDetail.State;
        long num2 = 0;
        long? nullable3;
        if ((nullable1.GetValueOrDefault() == num2 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable3 = rfp.RfpDetail.State;
        }
        else
        {
          nullable1 = new long?();
          nullable3 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local2 = (System.ValueType) nullable3;
        db2.AddInParameter(command2, "@State", DbType.Int64, (object) local2);
        SqlDatabase db3 = this.db;
        DbCommand command3 = storedProcCommand;
        nullable1 = rfp.RfpDetail.Purpose;
        long num3 = 0;
        long? nullable4;
        if ((nullable1.GetValueOrDefault() == num3 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable4 = rfp.RfpDetail.Purpose;
        }
        else
        {
          nullable1 = new long?();
          nullable4 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local3 = (System.ValueType) nullable4;
        db3.AddInParameter(command3, "@Purpose", DbType.Int64, (object) local3);
        SqlDatabase db4 = this.db;
        DbCommand command4 = storedProcCommand;
        nullable1 = rfp.RfpDetail.GeneralCategory;
        long num4 = 0;
        long? nullable5;
        if ((nullable1.GetValueOrDefault() == num4 ? (nullable1.HasValue ? 1 : 0) : 0) == 0)
        {
          nullable5 = rfp.RfpDetail.GeneralCategory;
        }
        else
        {
          nullable1 = new long?();
          nullable5 = nullable1;
        }
        // ISSUE: variable of a boxed type
        __Boxed<long?> local4 = (System.ValueType) nullable5;
        db4.AddInParameter(command4, "@GeneralCategory", DbType.Int64, (object) local4);
        if (rfp.InternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@InternalPartnerTableType", SqlDbType.Structured, (object) this.GetInternalPartnerDataTable(rfp.InternalPartners, false));
        if (rfp.ExternalPartners != null)
          this.db.AddInParameter(storedProcCommand, "@ExternalPartnerTableType", SqlDbType.Structured, (object) this.GetExternalPartnerDataTable(rfp.ExternalPartners, false));
        this.db.AddInParameter(storedProcCommand, "@CreatedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@ModifiedBy", DbType.String, (object) this.AppUser.Name);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) 3);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailDate", DbType.DateTime, (object) DateTime.UtcNow);
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
      }
    }

    public RFP FetchByID(long appTransactionId)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchRFPById"))
      {
        RFP rfp = new RFP();
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionId);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          if (reader.Read())
          {
            IRowMapper<RfpDetail> rowMapper = MapBuilder<RfpDetail>.MapAllProperties().DoNotMap<string>((Expression<Func<RfpDetail, string>>) (x => x.ReviewComments)).DoNotMap<string>((Expression<Func<RfpDetail, string>>) (x => x.Notes)).DoNotMap<bool?>((Expression<Func<RfpDetail, bool?>>) (x => x.IsRFPInitiatedFromParentOpportunity)).Build();
            rfp.RfpDetail = rowMapper.MapRow((IDataRecord) reader);
            if (reader.NextResult())
              rfp.InternalPartners = this.GetInternalPartners(reader);
            if (reader.NextResult())
              rfp.InternalPartnerBankRMs = this.GetInternalPartnerBankRMs(reader);
            if (reader.NextResult())
              rfp.ExternalPartners = this.GetExternalPartners(reader);
            if (reader.NextResult())
              rfp.RfpContact = this.GetRfpContacts(reader);
            if (reader.NextResult())
              rfp.WorkflowStateTransitions = this.GetStateTransitions(reader);
            if (reader.NextResult())
              rfp.RfpDetail.MAExemptionDetails = this.GetMAExemptionDetails(reader);
            if (reader.NextResult())
              rfp.RfpDetail.NotesCollection = this.GetNotes(reader);
            if (reader.NextResult())
              rfp.ReviewCommentsCollection = this.GetReviewComments(reader);
          }
        }
        return rfp;
      }
    }

    private List<MAExemptionDetail> GetMAExemptionDetails(IDataReader reader)
    {
      List<MAExemptionDetail> maExemptionDetailList = new List<MAExemptionDetail>();
      IRowMapper<MAExemptionDetail> rowMapper = MapBuilder<MAExemptionDetail>.MapAllProperties().DoNotMap<long>((Expression<Func<MAExemptionDetail, long>>) (x => x.MAExemptionID)).Build();
      int num = 1;
      while (reader.Read())
      {
        MAExemptionDetail maExemptionDetail = rowMapper.MapRow((IDataRecord) reader);
        maExemptionDetail.MAExemptionID = (long) num++;
        maExemptionDetailList.Add(maExemptionDetail);
      }
      return maExemptionDetailList;
    }

    private List<Notes> GetNotes(IDataReader reader)
    {
      List<Notes> notesList = new List<Notes>();
      IRowMapper<Notes> rowMapper = MapBuilder<Notes>.MapAllProperties().DoNotMap<string>((Expression<Func<Notes, string>>) (m => m.NotesDateTimeString)).Build();
      while (reader.Read())
        notesList.Add(rowMapper.MapRow((IDataRecord) reader));
      return notesList;
    }

    private List<ReviewComments> GetReviewComments(IDataReader reader)
    {
      List<ReviewComments> reviewCommentsList = new List<ReviewComments>();
      IRowMapper<ReviewComments> rowMapper = MapBuilder<ReviewComments>.MapAllProperties().DoNotMap<string>((Expression<Func<ReviewComments, string>>) (m => m.ReviewCommentDateTimeString)).Build();
      while (reader.Read())
        reviewCommentsList.Add(rowMapper.MapRow((IDataRecord) reader));
      return reviewCommentsList;
    }

    public Dictionary<RFP.RfpStatus, RFP.RfpStatus> FetchHistoryByAppTransactionID(
      long appTransactionID)
    {
      Dictionary<RFP.RfpStatus, RFP.RfpStatus> dictionary = (Dictionary<RFP.RfpStatus, RFP.RfpStatus>) null;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchHistoryByAppTransactionID"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appTransactionID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          dictionary = new Dictionary<RFP.RfpStatus, RFP.RfpStatus>();
          int ordinal1 = dataReader.GetOrdinal("ParentStateID");
          int ordinal2 = dataReader.GetOrdinal("StateID");
          while (dataReader.Read())
          {
            RFP.RfpStatus int32_1 = (RFP.RfpStatus) dataReader.GetInt32(ordinal1);
            RFP.RfpStatus int32_2 = (RFP.RfpStatus) dataReader.GetInt32(ordinal2);
            dictionary.Add(int32_1, int32_2);
          }
        }
      }
      return dictionary;
    }

    public IDataReader FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllRFP"))
      {
        List<RFP> rfpList = new List<RFP>();
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IDataReader FetchPartnerContactsByKey(
      long partnerID,
      long appTransactionID,
      long externalPartnerID)
    {
      List<IssuePartnerContact> issuePartnerContactList = new List<IssuePartnerContact>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchIssuePartnerContactByKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@PartnerID", DbType.Int64, (object) partnerID);
        if (appTransactionID != 0L)
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        else
          this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) null);
        this.db.AddInParameter(storedProcCommand, "@ExternalPartnerID", DbType.Int64, (object) externalPartnerID);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    public IEnumerable<SearchSetting> FetchAllBookmarks() => this.SearchSettingRepository.FetchByModuleName("RFP Search", (long) this.AppUser.Id);

    public void SaveBookMark(SearchSetting searchSetting)
    {
      searchSetting.Module = "RFP Search";
      searchSetting.UserId = (long) this.AppUser.Id;
      this.SearchSettingRepository.Save(searchSetting);
    }

    public void DeleteBookMark(long bookmarkId) => this.SearchSettingRepository.Delete(bookmarkId);

    public IDataReader Query(QueryDefinition definition, int pageSize, int pageNumber)
    {
      SqlCriterionVisitResult criterionVisitResult = new SqlCriterionVisitor((IDictionary<string, string>) this.knownMappings).Build(definition.Criterion);
      string str1 = string.Empty;
      foreach (Ordering ordering in definition.Order)
        str1 = string.Format("{0}{1} {2},", (object) str1, (object) ordering.PropertyName, (object) ordering.Direction);
      string str2 = string.IsNullOrEmpty(str1) ? "RfpName asc" : str1.Substring(0, str1.Length - 1);
      string str3 = string.Empty;
      if (definition.Projection != null && definition.Projection.Count<string>() > 0)
      {
        List<string> list1 = RFPRepository.knownProjection.Where<SearchSQLField>((Func<SearchSQLField, bool>) (x => definition.Projection.Contains<string>(x.Name))).Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.Query)).ToList<string>();
        List<string> list2 = RFPRepository.knownProjection.Where<SearchSQLField>((Func<SearchSQLField, bool>) (x => !definition.Projection.Contains<string>(x.Name))).Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.EmptyQuery)).ToList<string>();
        if (list1 != null && list1.Count > 0)
          str3 = list1.Join<string>(", ");
        if (list2 != null && list2.Count > 0)
          str3 = !string.IsNullOrEmpty(str3) ? string.Format("{0}, {1}", (object) str3, (object) list2.Join<string>(", ")) : list2.Join<string>(", ");
      }
      else
      {
        List<string> list = RFPRepository.knownProjection.Select<SearchSQLField, string>((Func<SearchSQLField, string>) (x => x.EmptyQuery)).ToList<string>();
        if (list != null && list.Count > 0)
          str3 = list.Join<string>(", ");
      }
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      if (definition.SubQueryDefinitions != null && definition.SubQueryDefinitions.Count > 0)
      {
        foreach (SubQueryDefinition subQueryDefinition in definition.SubQueryDefinitions)
        {
          if (subQueryDefinition.Field.ToLower() == "rfpstatusid")
          {
            empty1 += string.Format(" LEFT OUTER JOIN (SELECT DISTINCT ATS.AppTransactionID FROM AppTransactionState ATS WHERE ATS.StateID in ({0})) ATS ON View_RfpSearch.AppTransactionID = ATS.AppTransactionID", (object) subQueryDefinition.Value);
            empty2 += " AND ATS.AppTransactionID IS NULL";
          }
        }
      }
      string str4 = string.Format("{0} {1}", (object) criterionVisitResult.WhereClause, (object) empty2);
      DbCommand sqlStringCommand = this.db.GetSqlStringCommand(string.Format("{0} Select COUNT(*) From(SELECT Distinct View_RfpSearch.AppTransactionID, {1}  FROM View_RfpSearch {2} WHERE {3} GROUP BY View_RfpSearch.AppTransactionID)k", (object) string.Format("WITH cte as (Select *, ROW_NUMBER() OVER (ORDER BY {0}) AS _row From((SELECT Distinct View_RfpSearch.AppTransactionID, {1} FROM View_RfpSearch {2} WHERE {3} GROUP BY View_RfpSearch.AppTransactionID))k) SELECT * FROM cte WHERE _row BETWEEN {4} AND {5} ", (object) str2, (object) str3, (object) empty1, (object) str4, (object) (pageNumber + 1), (object) (pageSize + pageNumber)), (object) str3, (object) empty1, (object) str4));
      sqlStringCommand.Parameters.AddRange((Array) criterionVisitResult.Parameters);
      return this.db.ExecuteReader(sqlStringCommand);
    }

    public bool CheckForDuplicateRFPName(long appTransactionID, string rfpName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CheckDuplicateRFPName"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@RFPName", DbType.String, (object) rfpName);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    public List<string> FetchRfpNames(string rfpName)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchRfpNames"))
      {
        this.db.AddInParameter(storedProcCommand, "@RfpName", DbType.String, (object) RepositoryBase.EscapeForLike(rfpName));
        List<string> stringList = new List<string>();
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
            stringList.Add(dataReader.GetString(0));
        }
        return stringList;
      }
    }

    public bool UpdateStatusTracking(long appTransactionID, List<int> rfpStatusList, int entityID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_SaveEntityStateTracking"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) appTransactionID);
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int32, (object) entityID);
        DataTable dataTable = new DataTable();
        dataTable.Columns.Add("ID", typeof (int));
        foreach (int rfpStatus in rfpStatusList)
        {
          DataRow row = dataTable.NewRow();
          row["ID"] = (object) rfpStatus;
          dataTable.Rows.Add(row);
        }
        this.db.AddInParameter(storedProcCommand, "@tblCurrentState", SqlDbType.Structured, (object) dataTable);
        this.db.AddOutParameter(storedProcCommand, "@Result", DbType.Boolean, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToBoolean(this.db.GetParameterValue(storedProcCommand, "@Result"));
      }
    }

    private DataTable GetAppTransactionClientContactDataTable(
      List<AppTransactionClientContact> theAppTransactionClientContacts)
    {
      theAppTransactionClientContacts = theAppTransactionClientContacts.ToList<AppTransactionClientContact>();
      return this.ConvertListToDataTable<AppTransactionClientContact>(theAppTransactionClientContacts);
    }

    private DataTable GetExternalPartnerDataTable(
      List<ExternalPartner> theIssueExternalPartner,
      bool includeDirtyRecordsOnly = true)
    {
      if (includeDirtyRecordsOnly)
        theIssueExternalPartner = theIssueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.IsDirty)).ToList<ExternalPartner>();
      return this.ConvertListToDataTable<ExternalPartner>(theIssueExternalPartner);
    }

    private DataTable GetInternalPartnerDataTable(
      List<InternalPartner> internalPartner,
      bool includeDirtyRecordsOnly = true)
    {
      if (includeDirtyRecordsOnly)
        internalPartner = internalPartner.Where<InternalPartner>((Func<InternalPartner, bool>) (x => x.IsDirty)).ToList<InternalPartner>();
      DataTable dataTable = this.ConvertListToDataTable<InternalPartner>(internalPartner);
      foreach (DataRow dataRow in dataTable.Select("IsPrimary='Yes' OR IsPrimary='No'"))
        dataRow["IsPrimary"] = dataRow["IsPrimary"].ToString() == "Yes" ? (object) "1" : (object) "0";
      return dataTable;
    }

    private List<ExternalPartner> GetExternalPartners(IDataReader reader)
    {
      List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
      IRowMapper<ExternalPartner> rowMapper = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.InsertedIssueContact)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).DoNotMap<int>((Expression<Func<ExternalPartner, int>>) (x => x.Version)).Build();
      while (reader.Read())
        externalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return externalPartnerList;
    }

    private List<InternalPartner> GetInternalPartners(IDataReader reader)
    {
      List<InternalPartner> internalPartnerList = new List<InternalPartner>();
      IRowMapper<InternalPartner> rowMapper = MapBuilder<InternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartner, bool>>) (x => x.IsDirty)).Build();
      while (reader.Read())
        internalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerList;
    }

    private List<InternalPartnerBankRM> GetInternalPartnerBankRMs(
      IDataReader reader)
    {
      List<InternalPartnerBankRM> internalPartnerBankRmList = new List<InternalPartnerBankRM>();
      IRowMapper<InternalPartnerBankRM> rowMapper = MapBuilder<InternalPartnerBankRM>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartnerBankRM, bool>>) (x => x.IsDeleted)).Build();
      while (reader.Read())
        internalPartnerBankRmList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerBankRmList;
    }

    private List<IssueContact> GetRfpContacts(IDataReader reader)
    {
      List<IssueContact> issueContactList = new List<IssueContact>();
      IRowMapper<IssueContact> rowMapper = MapBuilder<IssueContact>.MapAllProperties().Build();
      while (reader.Read())
        issueContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return issueContactList;
    }

    private List<AppTransactionStateTransition> GetStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    public long CreateIssueFromRFP(long AppTransactionID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_CreateIssueFromRFP"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionID", DbType.Int64, (object) AppTransactionID);
        this.db.AddInParameter(storedProcCommand, "@Principal", DbType.Int64, (object) this.AppUser.Id);
        this.db.AddInParameter(storedProcCommand, "@AuditTrailUser", DbType.String, (object) (this.AppUser.Name + (string.IsNullOrEmpty(this.AppUser.Email) ? "" : ";<br/>" + this.AppUser.Email)));
        this.db.AddOutParameter(storedProcCommand, "@ResultAppTransactionID", DbType.Int64, 0);
        this.db.ExecuteNonQuery(storedProcCommand);
        return Convert.ToInt64(this.db.GetParameterValue(storedProcCommand, "@ResultAppTransactionID"));
      }
    }
  }
}
