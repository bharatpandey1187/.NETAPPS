﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AuditTrailRepositoryComp
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IAuditTrailReportRepositoryComp))]
  public class AuditTrailRepositoryComp : RepositoryBase, IAuditTrailReportRepositoryComp
  {
    public IDataReader FetchAllAuditTrailsForReport(
      DateTime dateFrom,
      DateTime dateTo,
      string entity)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllAuditTrailsForReport"))
      {
        this.db.AddInParameter(storedProcCommand, "@FROMDATE", DbType.DateTime, (object) dateFrom);
        if (dateTo != DateTime.MinValue)
          this.db.AddInParameter(storedProcCommand, "@TODATE", DbType.DateTime, (object) dateTo);
        else
          this.db.AddInParameter(storedProcCommand, "@TODATE", DbType.DateTime, (object) DBNull.Value);
        this.db.AddInParameter(storedProcCommand, "@Entity", DbType.String, (object) entity);
        int[] effectivePrincipalIds = this.AppUser.GetEffectivePrincipalIds();
        this.db.AddInParameter(storedProcCommand, "@Principals", DbType.String, (object) string.Join(",", ((IEnumerable<int>) effectivePrincipalIds).Select<int, string>((Func<int, string>) (p => p.ToString())).ToArray<string>()));
        return this.db.ExecuteReader(storedProcCommand);
      }
    }

    private List<Notes> GetNotes(IDataReader reader)
    {
      List<Notes> notesList = new List<Notes>();
      IRowMapper<Notes> rowMapper = MapBuilder<Notes>.MapAllProperties().DoNotMap<string>((Expression<Func<Notes, string>>) (m => m.NotesDateTimeString)).Build();
      while (reader.Read())
        notesList.Add(rowMapper.MapRow((IDataRecord) reader));
      return notesList;
    }

    private List<ReviewComments> GetReviewComments(IDataReader reader)
    {
      List<ReviewComments> reviewCommentsList = new List<ReviewComments>();
      IRowMapper<ReviewComments> rowMapper = MapBuilder<ReviewComments>.MapAllProperties().DoNotMap<string>((Expression<Func<ReviewComments, string>>) (m => m.ReviewCommentDateTimeString)).Build();
      while (reader.Read())
        reviewCommentsList.Add(rowMapper.MapRow((IDataRecord) reader));
      return reviewCommentsList;
    }

    private List<AppTransactionStateTransition> WorkflowStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    public List<InternalPartner> GetInternalPartners(IDataReader reader)
    {
      List<InternalPartner> internalPartnerList = new List<InternalPartner>();
      IRowMapper<InternalPartner> rowMapper = MapBuilder<InternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<int>((Expression<Func<InternalPartner, int>>) (x => x.Version)).Build();
      while (reader.Read())
        internalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerList;
    }

    public List<InternalPartner> GetInternalPartnersHistory(IDataReader reader)
    {
      List<InternalPartner> internalPartnerList = new List<InternalPartner>();
      IRowMapper<InternalPartner> rowMapper = MapBuilder<InternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<InternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<Decimal?>((Expression<Func<InternalPartner, Decimal?>>) (x => x.Percentage)).Build();
      while (reader.Read())
        internalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return internalPartnerList;
    }

    public List<AppTransactionClientContact> GetClientContacts(
      IDataReader reader)
    {
      List<AppTransactionClientContact> transactionClientContactList = new List<AppTransactionClientContact>();
      IRowMapper<AppTransactionClientContact> rowMapper = MapBuilder<AppTransactionClientContact>.MapAllProperties().Build();
      while (reader.Read())
        transactionClientContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionClientContactList;
    }

    private List<IssueContact> GetOpportunityContacts(IDataReader reader)
    {
      List<IssueContact> issueContactList = new List<IssueContact>();
      IRowMapper<IssueContact> rowMapper = MapBuilder<IssueContact>.MapAllProperties().Build();
      while (reader.Read())
        issueContactList.Add(rowMapper.MapRow((IDataRecord) reader));
      return issueContactList;
    }

    private List<AppTransactionStateTransition> GetStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    private List<MAExemptionDetail> GetMAExemptionDetailsHistory(
      IDataReader reader)
    {
      List<MAExemptionDetail> maExemptionDetailList = new List<MAExemptionDetail>();
      IRowMapper<MAExemptionDetail> rowMapper = MapBuilder<MAExemptionDetail>.MapAllProperties().DoNotMap<long>((Expression<Func<MAExemptionDetail, long>>) (x => x.MAExemptionID)).Build();
      int num = 1;
      while (reader.Read())
      {
        MAExemptionDetail maExemptionDetail = rowMapper.MapRow((IDataRecord) reader);
        maExemptionDetail.MAExemptionID = (long) num++;
        maExemptionDetailList.Add(maExemptionDetail);
      }
      return maExemptionDetailList;
    }

    private List<ExternalPartner> GetExternalPartnersHistory(IDataReader reader)
    {
      List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
      IRowMapper<ExternalPartner> rowMapper = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.InsertedIssueContact)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).Build();
      while (reader.Read())
        externalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return externalPartnerList;
    }

    private List<ExternalPartner> GetSyndicateExternalPartner(IDataReader reader)
    {
      List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
      IRowMapper<ExternalPartner> rowMapper = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.InsertedIssueContact)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).Build();
      while (reader.Read())
        externalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return externalPartnerList;
    }

    private List<ExternalPartner> GetExternalPartners(IDataReader reader)
    {
      List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
      IRowMapper<ExternalPartner> rowMapper = MapBuilder<ExternalPartner>.MapAllProperties().DoNotMap<bool>((Expression<Func<ExternalPartner, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.InsertedIssueContact)).DoNotMap<string>((Expression<Func<ExternalPartner, string>>) (x => x.DeletedIssueContact)).DoNotMap<int>((Expression<Func<ExternalPartner, int>>) (x => x.Version)).Build();
      while (reader.Read())
        externalPartnerList.Add(rowMapper.MapRow((IDataRecord) reader));
      return externalPartnerList;
    }

    private List<G17Detail> GetG17Details(IDataReader reader)
    {
      List<G17Detail> g17DetailList = new List<G17Detail>();
      G17Detail g17Detail = MapBuilder<G17Detail>.MapAllProperties().DoNotMap<long>((Expression<Func<G17Detail, long>>) (x => x.G17ID)).DoNotMap<int>((Expression<Func<G17Detail, int>>) (x => x.Version)).DoNotMap<string>((Expression<Func<G17Detail, string>>) (x => x.G17TypeName)).Build().MapRow((IDataRecord) reader);
      g17Detail.G17ID = 1L;
      g17DetailList.Add(g17Detail);
      return g17DetailList;
    }

    private List<G17Detail> GetG17DetailsHistory(IDataReader reader)
    {
      List<G17Detail> g17DetailList = new List<G17Detail>();
      IRowMapper<G17Detail> rowMapper = MapBuilder<G17Detail>.MapAllProperties().DoNotMap<long>((Expression<Func<G17Detail, long>>) (x => x.G17ID)).Build();
      int num = 1;
      while (reader.Read())
      {
        G17Detail g17Detail = rowMapper.MapRow((IDataRecord) reader);
        g17Detail.G17ID = (long) num++;
        g17DetailList.Add(g17Detail);
      }
      return g17DetailList;
    }

    public List<OpportunityAuditFields> GetOpportunityAuditTrail(
      long appId,
      int fromVersion,
      int toVersion)
    {
      List<OpportunityAuditFields> opportunityAuditFieldsList = new List<OpportunityAuditFields>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchOpportunityAuditTrail"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appId);
        this.db.AddInParameter(storedProcCommand, "@fromVersion", DbType.Int64, (object) fromVersion);
        this.db.AddInParameter(storedProcCommand, "@toVersion", DbType.Int64, (object) toVersion);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          while (reader.Read())
          {
            OpportunityAuditFields opportunityAuditFields = MapBuilder<OpportunityAuditFields>.MapAllProperties().DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.MAExemptions)).DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.G17Details)).DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.InvestmentBankingTeam)).DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.SupervisoryPrincipal)).DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.SyndicateMembers)).DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.AdvisoryAgents)).DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.WinningSyndicate)).DoNotMap<string>((Expression<Func<OpportunityAuditFields, string>>) (x => x.Counsels)).Build().MapRow((IDataRecord) reader);
            opportunityAuditFieldsList.Add(opportunityAuditFields);
          }
          DateTime? nullable;
          DateTime dateTime;
          if (reader.NextResult())
          {
            List<MAExemptionDetail> exemptionDetailsHistory = this.GetMAExemptionDetailsHistory(reader);
            for (int index1 = 0; index1 < opportunityAuditFieldsList.Count; ++index1)
            {
              opportunityAuditFieldsList[index1].MAExemptions = "";
              for (int index2 = 0; index2 < exemptionDetailsHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(opportunityAuditFieldsList[index1].VersionNumber) == exemptionDetailsHistory[index2].Version)
                {
                  nullable = exemptionDetailsHistory[index2].MAExemptionDate;
                  string str1;
                  if (!nullable.HasValue)
                  {
                    str1 = "NA";
                  }
                  else
                  {
                    nullable = exemptionDetailsHistory[index2].MAExemptionDate;
                    dateTime = nullable.Value;
                    str1 = dateTime.ToString("MM/dd/yyyy");
                  }
                  string str2 = str1;
                  nullable = exemptionDetailsHistory[index2].MAExemptionExpirationDate;
                  string str3;
                  if (!nullable.HasValue)
                  {
                    str3 = "NA";
                  }
                  else
                  {
                    nullable = exemptionDetailsHistory[index2].MAExemptionExpirationDate;
                    dateTime = nullable.Value;
                    str3 = dateTime.ToString("MM/dd/yyyy");
                  }
                  string str4 = str3;
                  opportunityAuditFieldsList[index1].MAExemptions = opportunityAuditFieldsList[index1].MAExemptions + exemptionDetailsHistory[index2].MAExemptionTypeName + ":" + str2 + ":" + str4 + "\n";
                }
              }
            }
          }
          if (reader.NextResult())
          {
            List<G17Detail> g17DetailsHistory = this.GetG17DetailsHistory(reader);
            for (int index1 = 0; index1 < opportunityAuditFieldsList.Count; ++index1)
            {
              opportunityAuditFieldsList[index1].G17Details = "";
              for (int index2 = 0; index2 < g17DetailsHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(opportunityAuditFieldsList[index1].VersionNumber) == g17DetailsHistory[index2].Version)
                {
                  nullable = g17DetailsHistory[index2].G17SentDate;
                  string str1;
                  if (!nullable.HasValue)
                  {
                    str1 = "NA";
                  }
                  else
                  {
                    nullable = g17DetailsHistory[index2].G17SentDate;
                    dateTime = nullable.Value;
                    str1 = dateTime.ToString("MM/dd/yyyy");
                  }
                  string str2 = str1;
                  nullable = g17DetailsHistory[index2].G17AcknowledgementDate;
                  string str3;
                  if (!nullable.HasValue)
                  {
                    str3 = "NA";
                  }
                  else
                  {
                    nullable = g17DetailsHistory[index2].G17AcknowledgementDate;
                    dateTime = nullable.Value;
                    str3 = dateTime.ToString("MM/dd/yyyy");
                  }
                  string str4 = str3;
                  opportunityAuditFieldsList[index1].G17Details = opportunityAuditFieldsList[index1].G17Details + g17DetailsHistory[index2].G17TypeName + ":" + str2 + ":" + str4 + "\n";
                }
              }
            }
          }
          if (reader.NextResult())
          {
            List<InternalPartner> internalPartnersHistory = this.GetInternalPartnersHistory(reader);
            for (int index1 = 0; index1 < opportunityAuditFieldsList.Count; ++index1)
            {
              opportunityAuditFieldsList[index1].InternalPartners = new List<InternalPartner>();
              for (int index2 = 0; index2 < internalPartnersHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(opportunityAuditFieldsList[index1].VersionNumber) == internalPartnersHistory[index2].Version)
                  opportunityAuditFieldsList[index1].InternalPartners.Add(internalPartnersHistory[index2]);
              }
            }
          }
          if (reader.NextResult())
          {
            List<ExternalPartner> externalPartnersHistory = this.GetExternalPartnersHistory(reader);
            for (int index1 = 0; index1 < opportunityAuditFieldsList.Count; ++index1)
            {
              opportunityAuditFieldsList[index1].ExternalPartners = new List<ExternalPartner>();
              for (int index2 = 0; index2 < externalPartnersHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(opportunityAuditFieldsList[index1].VersionNumber) == externalPartnersHistory[index2].Version)
                  opportunityAuditFieldsList[index1].ExternalPartners.Add(externalPartnersHistory[index2]);
              }
            }
          }
        }
      }
      return opportunityAuditFieldsList;
    }

    public List<CompetitiveTransactionAuditFields> GetTransactionAuditTrailComp(
      long appId,
      int fromVersion,
      int toVersion,
      out List<SeriesAudit> seriesData)
    {
      List<CompetitiveTransactionAuditFields> transactionAuditFieldsList = new List<CompetitiveTransactionAuditFields>();
      seriesData = new List<SeriesAudit>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchTransactionAuditTrailComp"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appId);
        this.db.AddInParameter(storedProcCommand, "@fromVersion", DbType.Int64, (object) fromVersion);
        this.db.AddInParameter(storedProcCommand, "@toVersion", DbType.Int64, (object) toVersion);
        using (IDataReader reader = this.db.ExecuteReader(storedProcCommand))
        {
          while (reader.Read())
          {
            CompetitiveTransactionAuditFields transactionAuditFields = MapBuilder<CompetitiveTransactionAuditFields>.MapAllProperties().DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.G17Details)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.MAExemptions)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.InvestmentBankingTeam)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.SupervisoryPrincipal)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.SyndicateTeam)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.SyndicateMembers)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.AdvisoryAgents)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.OtherExternalType)).DoNotMap<List<Series>>((Expression<Func<CompetitiveTransactionAuditFields, List<Series>>>) (x => x.Series)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.Counsels)).DoNotMap<List<InternalPartner>>((Expression<Func<CompetitiveTransactionAuditFields, List<InternalPartner>>>) (x => x.InternalPartners)).DoNotMap<string>((Expression<Func<CompetitiveTransactionAuditFields, string>>) (x => x.IRMAIndependent)).Build().MapRow((IDataRecord) reader);
            transactionAuditFieldsList.Add(transactionAuditFields);
          }
          DateTime? nullable;
          if (reader.NextResult())
          {
            List<MAExemptionDetail> exemptionDetailsHistory = this.GetMAExemptionDetailsHistory(reader);
            for (int index1 = 0; index1 < transactionAuditFieldsList.Count; ++index1)
            {
              transactionAuditFieldsList[index1].MAExemptions = "";
              for (int index2 = 0; index2 < exemptionDetailsHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(transactionAuditFieldsList[index1].VersionNo) == exemptionDetailsHistory[index2].Version)
                {
                  nullable = exemptionDetailsHistory[index2].MAExemptionDate;
                  string str1;
                  if (!nullable.HasValue)
                  {
                    str1 = "NA";
                  }
                  else
                  {
                    nullable = exemptionDetailsHistory[index2].MAExemptionDate;
                    str1 = nullable.Value.ToString("MM/dd/yyyy");
                  }
                  string str2 = str1;
                  nullable = exemptionDetailsHistory[index2].MAExemptionExpirationDate;
                  string str3;
                  if (!nullable.HasValue)
                  {
                    str3 = "NA";
                  }
                  else
                  {
                    nullable = exemptionDetailsHistory[index2].MAExemptionExpirationDate;
                    str3 = nullable.Value.ToString("MM/dd/yyyy");
                  }
                  string str4 = str3;
                  transactionAuditFieldsList[index1].MAExemptions = transactionAuditFieldsList[index1].MAExemptions + exemptionDetailsHistory[index2].MAExemptionTypeName + ":" + str2 + ":" + str4 + "\n";
                }
              }
            }
          }
          if (reader.NextResult())
          {
            List<G17Detail> g17DetailsHistory = this.GetG17DetailsHistory(reader);
            for (int index1 = 0; index1 < transactionAuditFieldsList.Count; ++index1)
            {
              transactionAuditFieldsList[index1].G17Details = "";
              for (int index2 = 0; index2 < g17DetailsHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(transactionAuditFieldsList[index1].VersionNo) == g17DetailsHistory[index2].Version)
                {
                  nullable = g17DetailsHistory[index2].G17SentDate;
                  string str1;
                  if (!nullable.HasValue)
                  {
                    str1 = "NA";
                  }
                  else
                  {
                    nullable = g17DetailsHistory[index2].G17SentDate;
                    str1 = nullable.Value.ToString("MM/dd/yyyy");
                  }
                  string str2 = str1;
                  nullable = g17DetailsHistory[index2].G17AcknowledgementDate;
                  string str3;
                  if (!nullable.HasValue)
                  {
                    str3 = "NA";
                  }
                  else
                  {
                    nullable = g17DetailsHistory[index2].G17AcknowledgementDate;
                    str3 = nullable.Value.ToString("MM/dd/yyyy");
                  }
                  string str4 = str3;
                  transactionAuditFieldsList[index1].G17Details = transactionAuditFieldsList[index1].G17Details + g17DetailsHistory[index2].G17TypeName + ":" + str2 + ":" + str4 + "\n";
                }
              }
            }
          }
          if (reader.NextResult())
          {
            List<InternalPartner> internalPartnersHistory = this.GetInternalPartnersHistory(reader);
            for (int index1 = 0; index1 < transactionAuditFieldsList.Count; ++index1)
            {
              transactionAuditFieldsList[index1].InternalPartners = new List<InternalPartner>();
              for (int index2 = 0; index2 < internalPartnersHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(transactionAuditFieldsList[index1].VersionNo) == internalPartnersHistory[index2].Version)
                  transactionAuditFieldsList[index1].InternalPartners.Add(internalPartnersHistory[index2]);
              }
            }
          }
          if (reader.NextResult())
          {
            List<ExternalPartner> externalPartnersHistory = this.GetExternalPartnersHistory(reader);
            for (int index1 = 0; index1 < transactionAuditFieldsList.Count; ++index1)
            {
              transactionAuditFieldsList[index1].SyndicateExternalPartners = new List<ExternalPartner>();
              for (int index2 = 0; index2 < externalPartnersHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(transactionAuditFieldsList[index1].VersionNo) == externalPartnersHistory[index2].Version)
                  transactionAuditFieldsList[index1].SyndicateExternalPartners.Add(externalPartnersHistory[index2]);
              }
            }
          }
          if (reader.NextResult())
          {
            List<ExternalPartner> externalPartnersHistory = this.GetExternalPartnersHistory(reader);
            for (int index1 = 0; index1 < transactionAuditFieldsList.Count; ++index1)
            {
              transactionAuditFieldsList[index1].ExternalPartners = new List<ExternalPartner>();
              for (int index2 = 0; index2 < externalPartnersHistory.Count; ++index2)
              {
                if ((int) Convert.ToInt16(transactionAuditFieldsList[index1].VersionNo) == externalPartnersHistory[index2].Version)
                  transactionAuditFieldsList[index1].ExternalPartners.Add(externalPartnersHistory[index2]);
              }
            }
          }
          if (reader.NextResult())
          {
            List<SeriesAudit> seriesHistoryDetails = this.GetSeriesHistoryDetails(reader);
            for (int index = 0; index < seriesHistoryDetails.Count; ++index)
            {
              int versionNA;
              if (this.checkIfOnlyOneVersionExistsForSeries(seriesHistoryDetails, seriesHistoryDetails[index].SeriesCode, fromVersion, toVersion, out versionNA))
                seriesData.Add(new SeriesAudit()
                {
                  SeriesCodeUnBind = seriesHistoryDetails[index].SeriesCode,
                  Version = versionNA
                });
              SeriesAudit seriesAudit = seriesHistoryDetails[index];
              seriesAudit.SeriesCodeUnBind = seriesHistoryDetails[index].SeriesCode;
              seriesData.Add(seriesAudit);
            }
            if (seriesHistoryDetails.Count > 0)
              seriesData = seriesData.OrderBy<SeriesAudit, int>((Func<SeriesAudit, int>) (s => s.Version)).ToList<SeriesAudit>();
          }
        }
      }
      return transactionAuditFieldsList;
    }

    private bool checkIfOnlyOneVersionExistsForSeries(
      List<SeriesAudit> seriesResult,
      string seriesCode,
      int fromVersion,
      int toVersion,
      out int versionNA)
    {
      versionNA = 0;
      if (seriesResult.Count > 0)
      {
        if (!seriesResult.Any<SeriesAudit>((Func<SeriesAudit, bool>) (s => s.SeriesCode == seriesCode && s.Version == fromVersion)))
        {
          versionNA = fromVersion;
          return true;
        }
        if (!seriesResult.Any<SeriesAudit>((Func<SeriesAudit, bool>) (s => s.SeriesCode == seriesCode && s.Version == toVersion)))
        {
          versionNA = toVersion;
          return true;
        }
      }
      return false;
    }

    private List<SeriesAudit> GetSeriesHistoryDetails(IDataReader reader)
    {
      List<SeriesAudit> seriesAuditList = new List<SeriesAudit>();
      IRowMapper<SeriesAudit> rowMapper = MapBuilder<SeriesAudit>.MapAllProperties().DoNotMap<string>((Expression<Func<SeriesAudit, string>>) (x => x.CreditEnhancementProvide)).DoNotMap<string>((Expression<Func<SeriesAudit, string>>) (x => x.CreditEnhancementType)).DoNotMap<string>((Expression<Func<SeriesAudit, string>>) (x => x.SeriesCodeUnBind)).DoNotMap<string>((Expression<Func<SeriesAudit, string>>) (x => x.WhenString)).Build();
      while (reader.Read())
      {
        SeriesAudit seriesAudit = rowMapper.MapRow((IDataRecord) reader);
        seriesAuditList.Add(seriesAudit);
      }
      return seriesAuditList;
    }

    public object FetchLastValueForFieldByEntityIdAppTransactionId(
      long appId,
      long entityId,
      string field)
    {
      object obj = (object) null;
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchLastValueForFieldByEntityIdAppTransactionId"))
      {
        this.db.AddInParameter(storedProcCommand, "@AppTransactionId", DbType.Int64, (object) appId);
        this.db.AddInParameter(storedProcCommand, "@EntityId", DbType.Int64, (object) entityId);
        this.db.AddInParameter(storedProcCommand, "@Field", DbType.String, (object) field);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          while (dataReader.Read())
          {
            if (!dataReader.IsDBNull(dataReader.GetOrdinal(field)) && dataReader.GetFieldType(dataReader.GetOrdinal(field)).FullName == "System.Decimal")
              obj = (object) dataReader.GetDecimal(dataReader.GetOrdinal(field));
          }
        }
      }
      return obj;
    }
  }
}
