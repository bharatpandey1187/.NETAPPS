﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.DocSetRolePermissionRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IDocSetRolePermissionRepository))]
  public class DocSetRolePermissionRepository : IDocSetRolePermissionRepository
  {
    public void Save(DocSetRolePermission theDocSetRolePermission)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_SaveDocSetRolePermission"))
      {
        database.AddInParameter(storedProcCommand, "@RoleID", DbType.Int64, (object) theDocSetRolePermission.RoleID);
        database.AddInParameter(storedProcCommand, "@PermissionID", DbType.Int64, (object) theDocSetRolePermission.PermissionID);
        database.AddInParameter(storedProcCommand, "@DocSetType", DbType.Int64, (object) theDocSetRolePermission.DocSetType);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }

    public DocSetRolePermission FetchByKey(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_FetchDocSetRolePermissionByKey"))
      {
        database.AddInParameter(storedProcCommand, "@DocSetRolePermissionId", DbType.Int32, (object) currentId);
        using (IDataReader dataReader = database.ExecuteReader(storedProcCommand))
          return dataReader.Read() ? MapBuilder<DocSetRolePermission>.MapAllProperties().Build().MapRow((IDataRecord) dataReader) : new DocSetRolePermission();
      }
    }

    public IEnumerable<DocSetRolePermission> FetchAll()
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand cmd = database.GetStoredProcCommand("usp_FetchAllDocSetRolePermission"))
      {
        using (IDataReader reader = database.ExecuteReader(cmd))
        {
          IRowMapper<DocSetRolePermission> mapper = MapBuilder<DocSetRolePermission>.MapAllProperties().Build();
          while (reader.Read())
            yield return mapper.MapRow((IDataRecord) reader);
          mapper = (IRowMapper<DocSetRolePermission>) null;
        }
      }
    }

    public void Delete(int currentId)
    {
      Database database = DatabaseFactory.CreateDatabase();
      using (DbCommand storedProcCommand = database.GetStoredProcCommand("usp_DeleteDocSetRolePermissionByKey"))
      {
        database.AddInParameter(storedProcCommand, "@DocSetRolePermissionId", DbType.Int32, (object) currentId);
        database.ExecuteNonQuery(storedProcCommand);
      }
    }
  }
}
