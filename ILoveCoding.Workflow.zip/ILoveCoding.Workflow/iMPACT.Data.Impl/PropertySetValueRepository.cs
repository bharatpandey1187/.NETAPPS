﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.PropertySetValueRepository
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Data.Impl
{
  [Export(typeof (IPropertySetValueRepository))]
  public class PropertySetValueRepository : RepositoryBase, IPropertySetValueRepository
  {
    public IEnumerable<PropertySetValue> FetchAll()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchAllPropertySetValue"))
      {
        List<PropertySetValue> propertySetValueList = new List<PropertySetValue>();
        this.db.AddInParameter(storedProcCommand, "@PropertySetValueID", DbType.Int32, (object) null);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<PropertySetValue> rowMapper = MapBuilder<PropertySetValue>.MapAllProperties().Build();
          while (dataReader.Read())
            propertySetValueList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<PropertySetValue>) propertySetValueList;
      }
    }

    public IEnumerable<PropertySetValue> FetchByPropertySetValueID(
      long templateID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchMiscAttrEditorFieldsByMiscAttrEditorID"))
      {
        List<PropertySetValue> propertySetValueList = new List<PropertySetValue>();
        this.db.AddInParameter(storedProcCommand, "@MiscAttrEditorID", DbType.Int32, (object) templateID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<PropertySetValue> rowMapper = MapBuilder<PropertySetValue>.MapAllProperties().Build();
          while (dataReader.Read())
            propertySetValueList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<PropertySetValue>) propertySetValueList;
      }
    }

    public IEnumerable<PropertySetValue> FetchAllPropertySetValue()
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchMiscAttrEditorsByMiscAttrEditorID"))
      {
        List<PropertySetValue> propertySetValueList = new List<PropertySetValue>();
        this.db.AddInParameter(storedProcCommand, "@MiscAttrEditorID", DbType.Int32, (object) null);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<PropertySetValue> rowMapper = MapBuilder<PropertySetValue>.MapAllProperties().Build();
          while (dataReader.Read())
            propertySetValueList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<PropertySetValue>) propertySetValueList;
      }
    }

    public IEnumerable<PropertySetValue> FetchPropertySetValuesByEntity(
      long entityID)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchPropertySetValuesByEntityID"))
      {
        List<PropertySetValue> propertySetValueList = new List<PropertySetValue>();
        this.db.AddInParameter(storedProcCommand, "@EntityID", DbType.Int64, (object) entityID);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          IRowMapper<PropertySetValue> rowMapper = MapBuilder<PropertySetValue>.MapAllProperties().Build();
          while (dataReader.Read())
            propertySetValueList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return (IEnumerable<PropertySetValue>) propertySetValueList;
      }
    }

    public IDataReader FetchTransposedPropertySetValues(string apptransactionIds)
    {
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_GetEntityMiscFields"))
      {
        List<IDictionary<string, object>> dictionaryList = new List<IDictionary<string, object>>();
        this.db.AddInParameter(storedProcCommand, "@ApptransactionIds", DbType.String, (object) apptransactionIds);
        return this.db.ExecuteReader(storedProcCommand);
      }
    }
  }
}
