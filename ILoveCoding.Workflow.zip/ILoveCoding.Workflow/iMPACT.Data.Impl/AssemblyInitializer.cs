﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Data.Impl.AssemblyInitializer
// Assembly: iMPACT.Data.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 4FD93254-E351-4585-8F88-94CE2D1C217F
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Data.Impl.dll

using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.Unity;
using System.Collections.Generic;
using System.Reflection;

namespace IrisSoftware.iMPACT.Data.Impl
{
  public class AssemblyInitializer : IAssemblyInitializer
  {
    public void Initialize(IUnityContainer container)
    {
      SqlDatabase instance = new SqlDatabase(container.Resolve<string>("connectionString"));
      container.RegisterInstance<SqlDatabase>(instance);
      this.RegisterKnownQueryFieldMappings(container);
    }

    private void RegisterKnownQueryFieldMappings(IUnityContainer container)
    {
      Dictionary<string, string> instance = new Dictionary<string, string>()
      {
        {
          "IssueNumber",
          "View_IssueSearch.IssueNumber"
        },
        {
          "IssueName",
          "View_IssueSearch.IssueName"
        },
        {
          "Address",
          "View_ClientSearch.StreetAddress1"
        }
      };
      container.RegisterInstance<Dictionary<string, string>>(instance);
    }

    public void InitializePerRequest(IUnityContainer container) => new ExportAttributeBasedContainerConfigurator().ConfigureContainer(container, Assembly.GetExecutingAssembly());
  }
}
