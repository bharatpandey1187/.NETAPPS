﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.PnlUpdatedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class PnlUpdatedEvent : BaseEvent, IEvent
  {
    public PnlUpdatedEvent(Pnl newPnL, Pnl oldPnL)
    {
      this.Id = Guid.NewGuid();
      this.newPnL = newPnL;
      this.oldPnL = oldPnL;
      this.OldStatus = this.GetOpptyStatusListFromStatusIDList(oldPnL.PnlHeaderInfo.PnLStatus);
    }

    public Guid Id { get; set; }

    public Pnl newPnL { get; private set; }

    public Pnl oldPnL { get; private set; }

    public List<PnlEnums.PnLStatus> OldStatus { get; private set; }

    private List<PnlEnums.PnLStatus> GetOpptyStatusListFromStatusIDList(
      List<long> lstOpptyStatusID)
    {
      List<PnlEnums.PnLStatus> pnLstatusList = new List<PnlEnums.PnLStatus>();
      foreach (long num in lstOpptyStatusID)
        pnLstatusList.Add((PnlEnums.PnLStatus) num);
      return pnLstatusList;
    }
  }
}
