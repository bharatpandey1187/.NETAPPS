﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.PnlCompUpdatedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class PnlCompUpdatedEvent : BaseEvent, IEvent
  {
    public PnlCompUpdatedEvent(PnlCompetitive newPnL, PnlCompetitive oldPnL)
    {
      this.Id = Guid.NewGuid();
      this.newPnL = newPnL;
      this.oldPnL = oldPnL;
      this.OldStatus = this.GetOpptyStatusListFromStatusIDList(oldPnL.PnlHeaderInfo.PnLStatus);
    }

    public Guid Id { get; set; }

    public PnlCompetitive newPnL { get; private set; }

    public PnlCompetitive oldPnL { get; private set; }

    public List<PnlCompetitiveEnums.PnLStatus> OldStatus { get; private set; }

    private List<PnlCompetitiveEnums.PnLStatus> GetOpptyStatusListFromStatusIDList(
      List<long> lstOpptyStatusID)
    {
      List<PnlCompetitiveEnums.PnLStatus> pnLstatusList = new List<PnlCompetitiveEnums.PnLStatus>();
      foreach (long num in lstOpptyStatusID)
        pnLstatusList.Add((PnlCompetitiveEnums.PnLStatus) num);
      return pnLstatusList;
    }
  }
}
