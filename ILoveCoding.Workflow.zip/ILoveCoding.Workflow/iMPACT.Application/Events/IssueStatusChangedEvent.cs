﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.IssueStatusChangedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class IssueStatusChangedEvent : BaseEvent, IEvent
  {
    public Guid Id { get; set; }

    public Issue Issue { get; private set; }

    public List<IssueEnums.IssueStatus> OldStatus { get; private set; }

    public List<IssueFromStateToState> FromStateToStateList { get; set; }

    public IssueStatusChangedEvent(Issue newIssue, List<IssueEnums.IssueStatus> oldStatus)
    {
      this.Id = Guid.NewGuid();
      this.Issue = newIssue;
      this.OldStatus = oldStatus;
    }

    public IssueStatusChangedEvent(Issue newIssue, List<IssueFromStateToState> fromStateToStateList)
    {
      this.Id = Guid.NewGuid();
      this.Issue = newIssue;
      this.FromStateToStateList = fromStateToStateList;
    }

    public IssueStatusChangedEvent(List<int> stateTrackingList, long appTransID)
    {
      this.AppTransactionID = appTransID;
      this.EntityStateTrackingList = stateTrackingList;
      this.StatusChangedType = 1;
    }

    public int StatusChangedType { get; set; }

    public long AppTransactionID { get; set; }

    public List<int> EntityStateTrackingList { get; set; }
  }
}
