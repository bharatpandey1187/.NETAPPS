﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.CompetitiveIssueG37FormStatusChangedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class CompetitiveIssueG37FormStatusChangedEvent : BaseEvent, IEvent
  {
    public Guid Id { get; set; }

    public CompetitiveG37Form G37Form { get; private set; }

    public List<CompetitiveIssueEnums.IssueG37FormStatus> OldStatus { get; private set; }

    public List<CompetitiveIssueG37FormFromStateToState> FromStateToStateList { get; set; }

    public CompetitiveIssueG37FormStatusChangedEvent(
      CompetitiveG37Form g37Form,
      List<CompetitiveIssueEnums.IssueG37FormStatus> oldStatus)
    {
      this.Id = Guid.NewGuid();
      this.G37Form = g37Form;
      this.OldStatus = oldStatus;
    }

    public CompetitiveIssueG37FormStatusChangedEvent(
      CompetitiveG37Form g37Form,
      List<CompetitiveIssueG37FormFromStateToState> fromStateToStateList)
    {
      this.Id = Guid.NewGuid();
      this.G37Form = g37Form;
      this.FromStateToStateList = fromStateToStateList;
    }

    public CompetitiveIssueG37FormStatusChangedEvent(List<int> stateTrackingList, long appTransID)
    {
      this.AppTransactionID = appTransID;
      this.EntityStateTrackingList = stateTrackingList;
      this.StatusChangedType = 1;
    }

    public int StatusChangedType { get; set; }

    public long AppTransactionID { get; set; }

    public List<int> EntityStateTrackingList { get; set; }
  }
}
