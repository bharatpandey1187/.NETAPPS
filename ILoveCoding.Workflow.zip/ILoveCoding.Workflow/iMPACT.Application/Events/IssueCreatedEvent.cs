﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.IssueCreatedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class IssueCreatedEvent : IEvent
  {
    public Guid Id { get; set; }

    public Issue Issue { get; private set; }

    public IssueCreatedEvent(Issue newIssue)
    {
      this.Id = Guid.NewGuid();
      this.Issue = newIssue;
    }

    public IssueCreatedEvent(List<int> stateTrackingList, long appTransID)
    {
      this.AppTransactionID = appTransID;
      this.EntityStateTrackingList = stateTrackingList;
      this.CreatedEventType = 1;
    }

    public long AppTransactionID { get; set; }

    public List<int> EntityStateTrackingList { get; set; }

    public int CreatedEventType { get; set; }
  }
}
