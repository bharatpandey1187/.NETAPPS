﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.CompetitiveReviewChecklistStatusChangedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class CompetitiveReviewChecklistStatusChangedEvent : BaseEvent, IEvent
  {
    public Guid Id { get; set; }

    public CompetitiveReviewChecklist ReviewChecklist { get; private set; }
  }
}
