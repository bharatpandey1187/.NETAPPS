﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.OpportunityFieldUpdateEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using System;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class OpportunityFieldUpdateEvent : BaseEvent, IEvent
  {
    public OpportunityFieldUpdateEvent(
      long appTransID,
      bool updateField,
      bool fieldValue,
      string fieldName)
    {
      this.AppTransactionID = appTransID;
      this.UpdateField = updateField;
      this.FieldValue = fieldValue;
      this.FieldName = fieldName;
    }

    public long AppTransactionID { get; set; }

    public bool UpdateField { get; set; }

    public bool FieldValue { get; set; }

    public string FieldName { get; set; }

    public Guid Id { get; set; }
  }
}
