﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.RfpUpdatedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class RfpUpdatedEvent : BaseEvent, IEvent
  {
    public RfpUpdatedEvent(RFP newRfp, RFP oldRfp)
    {
      this.Id = Guid.NewGuid();
      this.newRFP = newRfp;
      this.oldRFP = oldRfp;
      this.OldStatus = this.GetRFPStatusListFromStatusIDList(oldRfp.RfpDetail.RFPStatus);
    }

    public Guid Id { get; set; }

    public RFP newRFP { get; private set; }

    public RFP oldRFP { get; private set; }

    public List<RFP.RfpStatus> OldStatus { get; private set; }

    public List<RfpFromStateToState> FromStateToStateList { get; set; }

    private List<RFP.RfpStatus> GetRFPStatusListFromStatusIDList(List<long> lstRfpStatusID)
    {
      List<RFP.RfpStatus> rfpStatusList = new List<RFP.RfpStatus>();
      foreach (long num in lstRfpStatusID)
        rfpStatusList.Add((RFP.RfpStatus) num);
      return rfpStatusList;
    }
  }
}
