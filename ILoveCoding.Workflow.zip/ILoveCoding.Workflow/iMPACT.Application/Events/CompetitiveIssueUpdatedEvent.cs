﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.CompetitiveIssueUpdatedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class CompetitiveIssueUpdatedEvent : BaseEvent, IEvent
  {
    public CompetitiveIssueUpdatedEvent(CompetitiveIssue newIssue, CompetitiveIssue oldIssue)
    {
      this.Id = Guid.NewGuid();
      this.newISSUE = newIssue;
      this.oldISSUE = oldIssue;
      this.OldStatus = this.GetIssueStatusListFromStatusIDList(oldIssue.IssueDetail.IssueStatus);
    }

    public Guid Id { get; set; }

    public CompetitiveIssue newISSUE { get; private set; }

    public CompetitiveIssue oldISSUE { get; private set; }

    public List<CompetitiveIssueEnums.IssueStatus> OldStatus { get; private set; }

    private List<CompetitiveIssueEnums.IssueStatus> GetIssueStatusListFromStatusIDList(
      List<long> lstIssueStatusID)
    {
      List<CompetitiveIssueEnums.IssueStatus> issueStatusList = new List<CompetitiveIssueEnums.IssueStatus>();
      if (lstIssueStatusID != null)
      {
        foreach (long num in lstIssueStatusID)
          issueStatusList.Add((CompetitiveIssueEnums.IssueStatus) num);
      }
      return issueStatusList;
    }
  }
}
