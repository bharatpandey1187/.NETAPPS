﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.IssueG37FormStatusChangedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class IssueG37FormStatusChangedEvent : BaseEvent, IEvent
  {
    public Guid Id { get; set; }

    public G37Form G37Form { get; private set; }

    public List<IssueEnums.IssueG37FormStatus> OldStatus { get; private set; }

    public List<IssueG37FormFromStateToState> FromStateToStateList { get; set; }

    public IssueG37FormStatusChangedEvent(
      G37Form g37Form,
      List<IssueEnums.IssueG37FormStatus> oldStatus)
    {
      this.Id = Guid.NewGuid();
      this.G37Form = g37Form;
      this.OldStatus = oldStatus;
    }

    public IssueG37FormStatusChangedEvent(
      G37Form g37Form,
      List<IssueG37FormFromStateToState> fromStateToStateList)
    {
      this.Id = Guid.NewGuid();
      this.G37Form = g37Form;
      this.FromStateToStateList = fromStateToStateList;
    }

    public IssueG37FormStatusChangedEvent(List<int> stateTrackingList, long appTransID)
    {
      this.AppTransactionID = appTransID;
      this.EntityStateTrackingList = stateTrackingList;
      this.StatusChangedType = 1;
    }

    public int StatusChangedType { get; set; }

    public long AppTransactionID { get; set; }

    public List<int> EntityStateTrackingList { get; set; }
  }
}
