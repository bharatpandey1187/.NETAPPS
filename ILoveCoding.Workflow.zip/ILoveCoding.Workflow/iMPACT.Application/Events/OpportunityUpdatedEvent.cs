﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.OpportunityUpdatedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class OpportunityUpdatedEvent : BaseEvent, IEvent
  {
    public OpportunityUpdatedEvent(Opportunity newOpportunity, Opportunity oldOpportunity)
    {
      this.Id = Guid.NewGuid();
      this.newOpportunity = newOpportunity;
      this.oldOpportunity = oldOpportunity;
      this.OldStatus = this.GetOpptyStatusListFromStatusIDList(oldOpportunity.OpportunityDetail.OpportunityStatus);
    }

    public Guid Id { get; set; }

    public Opportunity newOpportunity { get; private set; }

    public Opportunity oldOpportunity { get; private set; }

    public List<Opportunity.Status> OldStatus { get; private set; }

    private List<Opportunity.Status> GetOpptyStatusListFromStatusIDList(
      List<long> lstOpptyStatusID)
    {
      List<Opportunity.Status> statusList = new List<Opportunity.Status>();
      foreach (long num in lstOpptyStatusID)
        statusList.Add((Opportunity.Status) num);
      return statusList;
    }
  }
}
