﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Events.CompetitiveIssueStatusChangedEvent
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.Events
{
  public class CompetitiveIssueStatusChangedEvent : BaseEvent, IEvent
  {
    public Guid Id { get; set; }

    public CompetitiveIssue Issue { get; private set; }

    public List<CompetitiveIssueEnums.IssueStatus> OldStatus { get; private set; }

    public List<CompetitiveIssueFromStateToState> FromStateToStateList { get; set; }

    public CompetitiveIssueStatusChangedEvent(
      CompetitiveIssue newIssue,
      List<CompetitiveIssueEnums.IssueStatus> oldStatus)
    {
      this.Id = Guid.NewGuid();
      this.Issue = newIssue;
      this.OldStatus = oldStatus;
    }

    public CompetitiveIssueStatusChangedEvent(
      CompetitiveIssue newIssue,
      List<CompetitiveIssueFromStateToState> fromStateToStateList)
    {
      this.Id = Guid.NewGuid();
      this.Issue = newIssue;
      this.FromStateToStateList = fromStateToStateList;
    }

    public CompetitiveIssueStatusChangedEvent(List<int> stateTrackingList, long appTransID)
    {
      this.AppTransactionID = appTransID;
      this.EntityStateTrackingList = stateTrackingList;
      this.StatusChangedType = 1;
    }

    public int StatusChangedType { get; set; }

    public long AppTransactionID { get; set; }

    public List<int> EntityStateTrackingList { get; set; }
  }
}
