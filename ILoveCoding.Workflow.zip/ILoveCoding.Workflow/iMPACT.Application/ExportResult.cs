﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ExportResult
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

namespace IrisSoftware.iMPACT.Application
{
  public class ExportResult
  {
    public byte[] Data { get; set; }

    public string MimeType { get; set; }

    public string Filename { get; set; }
  }
}
