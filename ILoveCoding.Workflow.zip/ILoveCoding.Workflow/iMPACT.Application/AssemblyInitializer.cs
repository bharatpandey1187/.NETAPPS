﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.AssemblyInitializer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace IrisSoftware.iMPACT.Application
{
  public class AssemblyInitializer : IAssemblyInitializer
  {
    private List<Type> knownEventHandlerTypes;

    public void Initialize(IUnityContainer container)
    {
      new ExportAttributeBasedContainerConfigurator().ConfigureContainer(container, Assembly.GetExecutingAssembly());
      this.RegisterWorkflows(container);
      this.knownEventHandlerTypes = this.GetEventHandlers();
    }

    private void RegisterEventHandlers(IUnityContainer container, List<Type> eventHandlerTypes)
    {
      IEventHandlerRegistry eventHandlerRegistry = container.Resolve<IEventHandlerRegistry>();
      foreach (Type eventHandlerType in eventHandlerTypes)
      {
        IEventHandler eventHandler = container.Resolve(eventHandlerType) as IEventHandler;
        eventHandlerRegistry.Register(eventHandler);
        container.RegisterInstance<IEventHandler>(eventHandler);
      }
    }

    private List<Type> GetEventHandlers() => ((IEnumerable<Type>) Assembly.GetExecutingAssembly().GetExportedTypes()).Where<Type>((Func<Type, bool>) (t => typeof (IEventHandler).IsAssignableFrom(t) && !t.IsAbstract && t.IsClass)).ToList<Type>();

    private void RegisterEventBus(IUnityContainer container)
    {
      EventHandlerRegistry eventHandlerRegistry = new EventHandlerRegistry();
      container.RegisterInstance<IEventHandlerRegistry>((IEventHandlerRegistry) eventHandlerRegistry);
      container.RegisterInstance<IEventBus>((IEventBus) new EventDispatcher((IEventHandlerRegistry) eventHandlerRegistry));
    }

    public void InitializePerRequest(IUnityContainer container)
    {
      this.RegisterEventBus(container);
      this.RegisterEventHandlers(container, this.knownEventHandlerTypes);
    }

    private void RegisterWorkflows(IUnityContainer container)
    {
      this.RegisterIssueWorkflow(container);
      this.RegisterCompetitiveIssueWorkflow(container);
      this.RegisterG37FormWorkflow(container);
      this.RegisterCompetitiveG37FormWorkflow(container);
      this.RegisterRfpWorkflow(container);
      this.RegisterOpportunityWorkflow(container);
      this.RegisterPnLWorkflow(container);
      this.RegisterPnLCompWorkflow(container);
    }

    private void RegisterIssueWorkflow(IUnityContainer container) => container.RegisterInstance<IIssueWorkflowFactory>((IIssueWorkflowFactory) new IssueWorkflowFactory());

    private void RegisterCompetitiveIssueWorkflow(IUnityContainer container) => container.RegisterInstance<ICompetitiveIssueWorkflowFactory>((ICompetitiveIssueWorkflowFactory) new CompetitiveIssueWorkflowFactory());

    private void RegisterG37FormWorkflow(IUnityContainer container) => container.RegisterInstance<IIssueG37FormWorkflowFactory>((IIssueG37FormWorkflowFactory) new IssueG37FormWorkflowFactory());

    private void RegisterCompetitiveG37FormWorkflow(IUnityContainer container) => container.RegisterInstance<ICompetitiveIssueG37FormWorkflowFactory>((ICompetitiveIssueG37FormWorkflowFactory) new CompetitiveIssueG37FormWorkflowFactory());

    private void RegisterRfpWorkflow(IUnityContainer container) => container.RegisterInstance<IRfpWorkflowFactory>((IRfpWorkflowFactory) new RfpWorkflowFactory());

    private void RegisterOpportunityWorkflow(IUnityContainer container) => container.RegisterInstance<IOpportunityWorkflowFactory>((IOpportunityWorkflowFactory) new OpportunityWorkflowFactory());

    private void RegisterPnLWorkflow(IUnityContainer container) => container.RegisterInstance<IPnLWorkflowFactory>((IPnLWorkflowFactory) new PnLWorkflowFactory());

    private void RegisterPnLCompWorkflow(IUnityContainer container) => container.RegisterInstance<IPnLCompetitiveWorkflowFactory>((IPnLCompetitiveWorkflowFactory) new PnLCompetitiveWorkflowFactory());
  }
}
