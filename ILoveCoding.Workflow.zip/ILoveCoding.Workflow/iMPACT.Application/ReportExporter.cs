﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ReportExporter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.Logging;
using IrisSoftware.Reporting.ReportDefinition;
using Microsoft.Practices.Unity;
using Microsoft.Reporting.WebForms;
using Microsoft.SharePoint;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Web;
using System.Xml.Serialization;

namespace IrisSoftware.iMPACT.Application
{
  public class ReportExporter
  {
    private const string CONTAINER_KEY = "UnityHttpModule.Container";

    [Dependency]
    public Logger<Modules> Log { get; set; }

    public ReportExporter()
    {
      if (!(HttpContext.Current.Items[(object) "UnityHttpModule.Container"] is IUnityContainer container))
        return;
      container.BuildUp(this.GetType(), (object) this);
    }

    public ExportResult Export(
      Report report,
      string format,
      string filename,
      object data)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      ReportExporter.\u003C\u003Ec__DisplayClass6_0 cDisplayClass60 = new ReportExporter.\u003C\u003Ec__DisplayClass6_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass60.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass60.report = report;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass60.format = format;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass60.data = data;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass60.filename = filename;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass60.newExportResult = (ExportResult) null;
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass60, __methodptr(\u003CExport\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass60.newExportResult;
    }

    public ExportResult Export(
      string reportPath,
      string format,
      string filename,
      object data)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      ReportExporter.\u003C\u003Ec__DisplayClass7_0 cDisplayClass70 = new ReportExporter.\u003C\u003Ec__DisplayClass7_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass70.reportPath = reportPath;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass70.format = format;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass70.data = data;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass70.filename = filename;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass70.newExportResult = (ExportResult) null;
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass70, __methodptr(\u003CExport\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass70.newExportResult;
    }

    private byte[] GenerateReport(
      Report report,
      string format,
      object data,
      out string mimeType,
      out string extension)
    {
      ReportViewer reportViewer1 = new ReportViewer();
      reportViewer1.set_ProcessingMode((ProcessingMode) 0);
      byte[] numArray;
      using (ReportViewer reportViewer2 = reportViewer1)
      {
        ReportExporter.LoadReport(reportViewer2, report, data);
        string str1 = (string) null;
        string str2;
        string[] strArray;
        Warning[] warningArray;
        numArray = ((Report) reportViewer2.get_LocalReport()).Render(format, str1, ref mimeType, ref str2, ref extension, ref strArray, ref warningArray);
        foreach (Warning warning in warningArray)
          this.Log.Error(Modules.Report, "GenerateReport-- Rendered report's warnings : " + warning.get_Message());
      }
      return numArray;
    }

    private static void LoadReport(ReportViewer reportViewer, Report report, object data)
    {
      using (Stream reportStream = ReportExporter.GetReportStream(report))
      {
        reportViewer.Reset();
        reportViewer.get_LocalReport().set_EnableExternalImages(true);
        ((Report) reportViewer.get_LocalReport()).LoadReportDefinition(reportStream);
        reportViewer.set_SizeToReportContent(true);
        ((Collection<ReportDataSource>) reportViewer.get_LocalReport().get_DataSources()).Clear();
        ((Collection<ReportDataSource>) reportViewer.get_LocalReport().get_DataSources()).Add(new ReportDataSource("DataSet", data));
      }
    }

    private static Stream GetReportStream(Report report)
    {
      MemoryStream memoryStream = new MemoryStream();
      new XmlSerializer(typeof (Report)).Serialize((Stream) memoryStream, (object) report);
      memoryStream.Position = 0L;
      return (Stream) memoryStream;
    }

    private static byte[] GenerateReport(
      string reportFile,
      string format,
      object data,
      out string mimeType,
      out string extension)
    {
      ReportViewer reportViewer1 = new ReportViewer();
      reportViewer1.set_ProcessingMode((ProcessingMode) 0);
      using (ReportViewer reportViewer2 = reportViewer1)
      {
        reportFile = HttpContext.Current.Server.MapPath(reportFile);
        using (FileStream fileStream = File.Open(reportFile, FileMode.Open, FileAccess.Read))
        {
          reportViewer2.Reset();
          reportViewer2.get_LocalReport().set_ReportPath(reportFile);
          reportViewer2.get_LocalReport().set_EnableExternalImages(true);
          ((Report) reportViewer2.get_LocalReport()).LoadReportDefinition((Stream) fileStream);
          ((Collection<ReportDataSource>) reportViewer2.get_LocalReport().get_DataSources()).Clear();
          foreach (DataTable table in (InternalDataCollectionBase) ((DataSet) data).Tables)
            ((Collection<ReportDataSource>) reportViewer2.get_LocalReport().get_DataSources()).Add(new ReportDataSource(table.TableName, table));
        }
        string str1 = (string) null;
        string str2;
        string[] strArray;
        Warning[] warningArray;
        return ((Report) reportViewer2.get_LocalReport()).Render(format, str1, ref mimeType, ref str2, ref extension, ref strArray, ref warningArray);
      }
    }
  }
}
