﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.IssueG37FormWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class IssueG37FormWorkflowFactory : IIssueG37FormWorkflowFactory
  {
    private readonly Workflow<IssueEnums.IssueG37FormStatus, G37Form> defaultWorkflow;

    public IssueG37FormWorkflowFactory()
    {
      IssueG37FormState issueG37FormState = new IssueG37FormState();
      this.defaultWorkflow = new Workflow<IssueEnums.IssueG37FormStatus, G37Form>((IEnumerable<Transition<IssueEnums.IssueG37FormStatus, G37Form>>) new Transition<IssueEnums.IssueG37FormStatus, G37Form>[2]
      {
        new Transition<IssueEnums.IssueG37FormStatus, G37Form>((IState<IssueEnums.IssueG37FormStatus, G37Form>) issueG37FormState.Open, IssueG37FormAction.SubmitToCompliance, (IState<IssueEnums.IssueG37FormStatus, G37Form>) issueG37FormState.SubmittedToCompliance),
        new Transition<IssueEnums.IssueG37FormStatus, G37Form>((IState<IssueEnums.IssueG37FormStatus, G37Form>) issueG37FormState.SubmittedToCompliance, IssueG37FormAction.ReceivedByCompliance, (IState<IssueEnums.IssueG37FormStatus, G37Form>) issueG37FormState.ReceivedByCompliance)
      });
    }

    public IWorkflow<IssueEnums.IssueG37FormStatus, G37Form> GetWorkflow(
      string workflowType)
    {
      return (IWorkflow<IssueEnums.IssueG37FormStatus, G37Form>) this.defaultWorkflow;
    }
  }
}
