﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.RfpWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class RfpWorkflowFactory : IRfpWorkflowFactory
  {
    private readonly Workflow<RFP.RfpStatus, RFP> pncWorkflow;

    public RfpWorkflowFactory()
    {
      RfpState rfpState = new RfpState();
      this.pncWorkflow = new Workflow<RFP.RfpStatus, RFP>((IEnumerable<Transition<RFP.RfpStatus, RFP>>) new Transition<RFP.RfpStatus, RFP>[37]
      {
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.open, RfpAction.SendForActivation, (IState<RFP.RfpStatus, RFP>) rfpState.active),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.open, RfpAction.MarkCancelled, (IState<RFP.RfpStatus, RFP>) rfpState.cancelled),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.open, RfpAction.MarkPostpone, (IState<RFP.RfpStatus, RFP>) rfpState.postponed),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.active, RfpAction.MarkCancelled, (IState<RFP.RfpStatus, RFP>) rfpState.cancelled),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.active, RfpAction.MarkPostpone, (IState<RFP.RfpStatus, RFP>) rfpState.postponed),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.active, RfpAction.SendForComplianceReview, (IState<RFP.RfpStatus, RFP>) rfpState.complianceUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.active, RfpAction.SendForLegalReview, (IState<RFP.RfpStatus, RFP>) rfpState.legalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.active, RfpAction.SendForComplianceLegalReview, (IEnumerable<IState<RFP.RfpStatus, RFP>>) new AtomicState<RFP.RfpStatus, RFP>[2]
        {
          rfpState.complianceUnderReview,
          rfpState.legalUnderReview
        }),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.active, RfpAction.SendForSupervisoryPrincipalReview, (IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.complianceUnderReview, RfpAction.CompMoreInfoNeeded, (IState<RFP.RfpStatus, RFP>) rfpState.complianceMoreInfoNeeded),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.complianceUnderReview, RfpAction.CompReviewed, (IState<RFP.RfpStatus, RFP>) rfpState.complianceReviewed),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.complianceMoreInfoNeeded, RfpAction.SendForComplianceReview, (IState<RFP.RfpStatus, RFP>) rfpState.complianceUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.legalUnderReview, RfpAction.LegalMoreInfoNeeded, (IState<RFP.RfpStatus, RFP>) rfpState.legalMoreInfoNeeded),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.legalUnderReview, RfpAction.LegalReviewed, (IState<RFP.RfpStatus, RFP>) rfpState.legalReviewed),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.legalMoreInfoNeeded, RfpAction.SendForLegalReview, (IState<RFP.RfpStatus, RFP>) rfpState.legalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.complianceLegalReviewed, RfpAction.SendForSupervisoryPrincipalReview, (IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.complianceLegalReviewed, RfpAction.SendForComplianceReview, (IState<RFP.RfpStatus, RFP>) rfpState.complianceUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.complianceLegalReviewed, RfpAction.SendForLegalReview, (IState<RFP.RfpStatus, RFP>) rfpState.legalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.complianceLegalReviewed, RfpAction.SendForComplianceLegalReview, (IEnumerable<IState<RFP.RfpStatus, RFP>>) new AtomicState<RFP.RfpStatus, RFP>[2]
        {
          rfpState.complianceUnderReview,
          rfpState.legalUnderReview
        }),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalUnderReview, RfpAction.SupervisoryPrincipalMoreInfoNeeded, (IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalMoreInfoNeeded),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalUnderReview, RfpAction.SupervisoryPrincipalApproved, (IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalUnderReview, RfpAction.SupervisoryPrincipalDisapproved, (IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalDisapproved),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalMoreInfoNeeded, RfpAction.SendForSupervisoryPrincipalReview, (IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved, RfpAction.SendForSupervisoryPrincipalReview, (IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved, RfpAction.SendForComplianceLegalReview, (IEnumerable<IState<RFP.RfpStatus, RFP>>) new AtomicState<RFP.RfpStatus, RFP>[2]
        {
          rfpState.complianceUnderReview,
          rfpState.legalUnderReview
        }),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved, RfpAction.SendForComplianceReview, (IState<RFP.RfpStatus, RFP>) rfpState.complianceUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved, RfpAction.SendForLegalReview, (IState<RFP.RfpStatus, RFP>) rfpState.legalUnderReview),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved, RfpAction.MERGInformed, (IState<RFP.RfpStatus, RFP>) rfpState.mergInformed),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved, RfpAction.MarkWon, (IState<RFP.RfpStatus, RFP>) rfpState.won),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.supervisoryPrincipalApproved, RfpAction.MarkLost, (IState<RFP.RfpStatus, RFP>) rfpState.lost),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.mergInformed, RfpAction.MarkWon, (IState<RFP.RfpStatus, RFP>) rfpState.won),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.mergInformed, RfpAction.MarkLost, (IState<RFP.RfpStatus, RFP>) rfpState.lost),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.reviewProcess, RfpAction.MarkCancelled, (IState<RFP.RfpStatus, RFP>) rfpState.cancelled),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.reviewProcess, RfpAction.MarkPostpone, (IState<RFP.RfpStatus, RFP>) rfpState.postponed),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.postponed, RfpAction.ReturnToReviewProcess, (IState<RFP.RfpStatus, RFP>) rfpState.reviewProcess, true),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.postponed, RfpAction.SendForActivation, (IState<RFP.RfpStatus, RFP>) rfpState.active),
        new Transition<RFP.RfpStatus, RFP>((IState<RFP.RfpStatus, RFP>) rfpState.postponed, RfpAction.Reopen, (IState<RFP.RfpStatus, RFP>) rfpState.open)
      });
    }

    public IWorkflow<RFP.RfpStatus, RFP> GetWorkflow() => (IWorkflow<RFP.RfpStatus, RFP>) this.pncWorkflow;
  }
}
