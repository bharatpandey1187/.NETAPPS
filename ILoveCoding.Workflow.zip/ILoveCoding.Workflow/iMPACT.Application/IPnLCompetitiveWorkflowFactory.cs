﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.IPnLCompetitiveWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;

namespace IrisSoftware.iMPACT.Application
{
  public interface IPnLCompetitiveWorkflowFactory
  {
    IWorkflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive> GetWorkflow(
      string workflowType);
  }
}
