﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.PnLCompetitiveWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class PnLCompetitiveWorkflowFactory : IPnLCompetitiveWorkflowFactory
  {
    private readonly Workflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive> defaultWorkflow;
    private readonly Dictionary<string, Workflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>> knownWorkflows;

    public PnLCompetitiveWorkflowFactory()
    {
      PnlCompetitiveState competitiveState = new PnlCompetitiveState();
      this.knownWorkflows = new Dictionary<string, Workflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>>();
      this.defaultWorkflow = new Workflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IEnumerable<Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>>) new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>[9]
      {
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.open, PnlCompAction.SendForPnLApproverReview, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverUnderReview),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverUnderReview, PnlCompAction.MarkPnLApproverMoreInfoNeeded, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverMoreInfoNeeded),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverUnderReview, PnlCompAction.MarkPnLApproverApproved, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverApproved),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverMoreInfoNeeded, PnlCompAction.SendForPnLApproverReview, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverUnderReview),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlApproverApproved, PnlCompAction.SendForPnLAdministratorReview, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminUnderReview),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminUnderReview, PnlCompAction.MarkPnLAdministratorMoreInfoNeeded, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminMoreInfoNeeded),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminUnderReview, PnlCompAction.MarkPnLAdministratorApproved, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminApproved),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminMoreInfoNeeded, PnlCompAction.SendForPnLAdministratorReview, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminUnderReview),
        new Transition<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>((IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlAdminApproved, PnlCompAction.MarkPublished, (IState<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) competitiveState.pnlPublished)
      });
    }

    public IWorkflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive> GetWorkflow(
      string workflowType)
    {
      return this.knownWorkflows.ContainsKey(workflowType) ? (IWorkflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) this.knownWorkflows[workflowType] : (IWorkflow<PnlCompetitiveEnums.PnLStatus, PnlCompetitive>) this.defaultWorkflow;
    }
  }
}
