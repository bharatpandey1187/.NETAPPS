﻿// Decompiled with JetBrains decompiler
// Type: System.Data.DataReaderExtensions
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;
using System.Linq;

namespace System.Data
{
  public static class DataReaderExtensions
  {
    public static Dictionary<string, object> ConvertToDictionary(this IDataReader value) => Enumerable.Range(0, value.FieldCount).ToDictionary<int, string, object>((Func<int, string>) (i => value.GetName(i)), (Func<int, object>) (i => value.GetValue(i)));

    public static Dictionary<string, object> ConvertToDictionary(
      this IDataReader value,
      Func<string, object, object> columnValueTranslator)
    {
      return Enumerable.Range(0, value.FieldCount).ToDictionary<int, string, object>((Func<int, string>) (i => value.GetName(i)), (Func<int, object>) (i => columnValueTranslator(value.GetName(i), value.GetValue(i))));
    }
  }
}
