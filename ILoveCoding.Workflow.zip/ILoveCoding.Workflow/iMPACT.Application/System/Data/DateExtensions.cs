﻿// Decompiled with JetBrains decompiler
// Type: System.Data.DateExtensions
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Globalization;

namespace System.Data
{
  public static class DateExtensions
  {
    public static string DateFormatDayMonthYear(this DateTime? value)
    {
      if (!value.HasValue)
        return "";
      DateTime dateTime = value.Value;
      DayOfWeek dayOfWeek = dateTime.DayOfWeek;
      string monthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(dateTime.Month);
      int year = dateTime.Year;
      return dayOfWeek.ToString() + ", " + monthName + " " + (object) dateTime.Day + ", " + (object) year;
    }
  }
}
