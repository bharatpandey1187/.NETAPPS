﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.OpportunityWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class OpportunityWorkflowFactory : IOpportunityWorkflowFactory
  {
    private readonly Workflow<Opportunity.Status, Opportunity> defaultWorkflow;
    private readonly Dictionary<string, Workflow<Opportunity.Status, Opportunity>> knownWorkflows;

    public OpportunityWorkflowFactory()
    {
      OpportunityState opportunityState1 = new OpportunityState();
      OpportunityState opportunityState2 = new OpportunityState();
      OpportunityState opportunityState3 = new OpportunityState();
      this.knownWorkflows = new Dictionary<string, Workflow<Opportunity.Status, Opportunity>>();
      this.defaultWorkflow = new Workflow<Opportunity.Status, Opportunity>((IEnumerable<Transition<Opportunity.Status, Opportunity>>) new Transition<Opportunity.Status, Opportunity>[18]
      {
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.Open, OpportunityAction.SendForManagementReview, (IState<Opportunity.Status, Opportunity>) opportunityState1.managementUnderReview),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.Open, OpportunityAction.MarkCancelled, (IState<Opportunity.Status, Opportunity>) opportunityState1.cancelled),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.managementUnderReview, OpportunityAction.MarkManagementApproved, (IState<Opportunity.Status, Opportunity>) opportunityState1.managementApproved),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.managementUnderReview, OpportunityAction.MarkManagementMoreInfoNeeded, (IState<Opportunity.Status, Opportunity>) opportunityState1.managementMoreInfoNeeded),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.managementMoreInfoNeeded, OpportunityAction.SendForManagementReview, (IState<Opportunity.Status, Opportunity>) opportunityState1.managementUnderReview),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.managementApproved, OpportunityAction.SendForManagementReview, (IState<Opportunity.Status, Opportunity>) opportunityState1.managementUnderReview),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.managementApproved, OpportunityAction.SendForCommitmentCommitteeReview, (IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeUnderReview),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.managementApproved, OpportunityAction.MarkOpportunityRFPSubmitted, (IState<Opportunity.Status, Opportunity>) opportunityState1.opportunityRFPSubmitted),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.compoundManagementReview, OpportunityAction.MarkCancelled, (IState<Opportunity.Status, Opportunity>) opportunityState1.cancelled),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeUnderReview, OpportunityAction.MarkCommitmentCommitteeApproved, (IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeApproved),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeUnderReview, OpportunityAction.MarkCommitmentCommitteeMoreInfoNeeded, (IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeMoreInfoNeeded),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeMoreInfoNeeded, OpportunityAction.SendForCommitmentCommitteeReview, (IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeUnderReview),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeApproved, OpportunityAction.SendForManagementReview, (IState<Opportunity.Status, Opportunity>) opportunityState1.managementUnderReview),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.commitmentCommitteeApproved, OpportunityAction.MarkOpportunityRFPSubmitted, (IState<Opportunity.Status, Opportunity>) opportunityState1.opportunityRFPSubmitted),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.compoundCommitmentCommitteeReview, OpportunityAction.MarkCancelled, (IState<Opportunity.Status, Opportunity>) opportunityState1.cancelled),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.opportunityRFPSubmitted, OpportunityAction.MarkWon, (IState<Opportunity.Status, Opportunity>) opportunityState1.won),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.opportunityRFPSubmitted, OpportunityAction.MarkLost, (IState<Opportunity.Status, Opportunity>) opportunityState1.lost),
        new Transition<Opportunity.Status, Opportunity>((IState<Opportunity.Status, Opportunity>) opportunityState1.opportunityRFPSubmitted, OpportunityAction.MarkCancelled, (IState<Opportunity.Status, Opportunity>) opportunityState1.cancelled)
      });
    }

    public IWorkflow<Opportunity.Status, Opportunity> GetWorkflow(
      string workflowType)
    {
      return this.knownWorkflows.ContainsKey(workflowType) ? (IWorkflow<Opportunity.Status, Opportunity>) this.knownWorkflows[workflowType] : (IWorkflow<Opportunity.Status, Opportunity>) this.defaultWorkflow;
    }
  }
}
