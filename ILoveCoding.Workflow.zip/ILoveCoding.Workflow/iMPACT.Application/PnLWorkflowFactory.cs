﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.PnLWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class PnLWorkflowFactory : IPnLWorkflowFactory
  {
    private readonly Workflow<PnlEnums.PnLStatus, Pnl> defaultWorkflow;
    private readonly Dictionary<string, Workflow<PnlEnums.PnLStatus, Pnl>> knownWorkflows;

    public PnLWorkflowFactory()
    {
      PnlState pnlState = new PnlState();
      this.knownWorkflows = new Dictionary<string, Workflow<PnlEnums.PnLStatus, Pnl>>();
      this.defaultWorkflow = new Workflow<PnlEnums.PnLStatus, Pnl>((IEnumerable<Transition<PnlEnums.PnLStatus, Pnl>>) new Transition<PnlEnums.PnLStatus, Pnl>[9]
      {
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.open, PnlAction.SendForPnLApproverReview, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverUnderReview),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverUnderReview, PnlAction.MarkPnLApproverMoreInfoNeeded, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverMoreInfoNeeded),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverUnderReview, PnlAction.MarkPnLApproverApproved, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverApproved),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverMoreInfoNeeded, PnlAction.SendForPnLApproverReview, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverUnderReview),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlApproverApproved, PnlAction.SendForPnLAdministratorReview, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminUnderReview),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminUnderReview, PnlAction.MarkPnLAdministratorMoreInfoNeeded, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminMoreInfoNeeded),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminUnderReview, PnlAction.MarkPnLAdministratorApproved, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminApproved),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminMoreInfoNeeded, PnlAction.SendForPnLAdministratorReview, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminUnderReview),
        new Transition<PnlEnums.PnLStatus, Pnl>((IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlAdminApproved, PnlAction.MarkPublished, (IState<PnlEnums.PnLStatus, Pnl>) pnlState.pnlPublished)
      });
    }

    public IWorkflow<PnlEnums.PnLStatus, Pnl> GetWorkflow(string workflowType) => this.knownWorkflows.ContainsKey(workflowType) ? (IWorkflow<PnlEnums.PnLStatus, Pnl>) this.knownWorkflows[workflowType] : (IWorkflow<PnlEnums.PnLStatus, Pnl>) this.defaultWorkflow;
  }
}
