﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ExpenseRevenueViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ExpenseRevenueViewModelContainer : ViewModelBase
  {
    public ExpenseRevenueViewModelContainer()
    {
      this.ExpenseRevenueDetail = new ExpenseRevenueViewModel();
      this.ExpenseRevenueSyndicateDetail = new ExpenseRevenueSyndicateViewModel();
      this.ExpenseRevenueHistory = new ExpenseRevenueHistoryViewModel();
    }

    public ExpenseRevenueViewModelContainer(ExpenseRevenue expenseRevenueDetails)
    {
      this.ExpenseRevenueDetail = new ExpenseRevenueViewModel(expenseRevenueDetails);
      this.ExpenseRevenueSyndicateDetail = new ExpenseRevenueSyndicateViewModel(expenseRevenueDetails.SyndicateMember);
      this.ExpenseRevenueHistory = new ExpenseRevenueHistoryViewModel(expenseRevenueDetails.ExpenseRevenueHistory);
    }

    public ExpenseRevenueViewModel ExpenseRevenueDetail { get; set; }

    public ExpenseRevenueSyndicateViewModel ExpenseRevenueSyndicateDetail { get; set; }

    public ExpenseRevenueHistoryViewModel ExpenseRevenueHistory { get; set; }

    public string[] Actions { get; set; }

    public bool IsProjectedValuesDisable { get; set; }

    public bool IsActualValuesDisable { get; set; }

    public bool IsViewOnly { get; set; }

    public bool IsProjCAStateDisable { get; set; }

    public bool IsProjCOStateDisable { get; set; }

    public bool IsProjMIStateDisable { get; set; }

    public bool IsProjMNStateDisable { get; set; }

    public bool IsProjTXStateDisable { get; set; }

    public bool IsProjOHStateDisable { get; set; }

    public bool IsActCAStateDisable { get; set; }

    public bool IsActCOStateDisable { get; set; }

    public bool IsActMIStateDisable { get; set; }

    public bool IsActMNStateDisable { get; set; }

    public bool IsActTXStateDisable { get; set; }

    public bool IsActOHStateDisable { get; set; }

    public int[] UnderwritingFirmRoles { get; set; }

    public int SoleManagerFirmRFole { get; set; }
  }
}
