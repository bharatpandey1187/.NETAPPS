﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ShowDealDetails
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ShowDealDetails
  {
    public long AppTransactionID { get; set; }

    public string DealStatusValue { get; set; }

    public string DealReviewStatusValue { get; set; }

    public string DealNbr { get; set; }

    public string DealName { get; set; }

    public string DealType { get; set; }
  }
}
