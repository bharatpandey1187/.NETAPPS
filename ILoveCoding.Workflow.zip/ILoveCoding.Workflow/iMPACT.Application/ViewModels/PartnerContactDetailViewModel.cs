﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PartnerContactDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PartnerContactDetailViewModel : ViewModelBase
  {
    public PartnerContactDetailViewModel()
    {
    }

    public PartnerContactDetailViewModel(PartnerContactAddress partnerContactAddress)
    {
      this.PartnerContactAddressID = partnerContactAddress.PartnerContactAddressID;
      this.PartnerID = partnerContactAddress.PartnerID;
      this.StreetAddress = partnerContactAddress.StreetAddress != null ? partnerContactAddress.StreetAddress.Trim() : "";
      this.City = partnerContactAddress.City != null ? partnerContactAddress.City.Trim() : "";
      this.State = partnerContactAddress.State;
      this.Phone = partnerContactAddress.Phone;
      this.Zip = partnerContactAddress.Zip;
      this.StateName = partnerContactAddress.StateName;
      this.Fax = partnerContactAddress.Fax;
      this.IsDefault = partnerContactAddress.IsDefault;
      this.IsDeleted = partnerContactAddress.IsDeleted;
      this.IsDirty = partnerContactAddress.IsDirty;
      this.IsActive = partnerContactAddress.IsActive;
      this.IsUsed = partnerContactAddress.IsUsed;
    }

    public PartnerContactAddress GetPartnerContactAddress() => new PartnerContactAddress()
    {
      PartnerContactAddressID = this.PartnerContactAddressID,
      PartnerID = this.PartnerID,
      StreetAddress = this.StreetAddress != null ? this.StreetAddress.Trim() : "",
      City = this.City != null ? this.City.Trim() : "",
      Phone = this.Phone,
      State = this.State,
      StateName = this.StateName,
      Zip = this.Zip,
      Fax = this.Fax,
      IsDefault = this.IsDefault,
      IsActive = this.IsActive,
      IsDeleted = this.IsDeleted,
      IsDirty = this.IsDirty,
      IsUsed = this.IsUsed
    };

    public long PartnerContactAddressID { get; set; }

    public long PartnerID { get; set; }

    [StringLength(12, ErrorMessage = "Length of Phone field should be equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    public string Phone { get; set; }

    [StringLength(12, ErrorMessage = "Length of Fax field should be equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    public string Fax { get; set; }

    [StringLength(500, ErrorMessage = "Length of Street address field should be less than or equal to 500 characters.")]
    public string StreetAddress { get; set; }

    [StringLength(100, ErrorMessage = "Length of City field for a Client should be less than or equal to 100 characters.")]
    public string City { get; set; }

    public long? State { get; set; }

    public string StateName { get; set; }

    [StringLength(12, ErrorMessage = "Length of ZIP Code field should be less than or equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$))", MessageTemplate = "ZIP Code for USA should be XXXXX or XXXXX-XXXX.")]
    public string Zip { get; set; }

    public bool IsDefault { get; set; }

    public bool IsActive { get; set; }

    public bool IsUsed { get; set; }
  }
}
