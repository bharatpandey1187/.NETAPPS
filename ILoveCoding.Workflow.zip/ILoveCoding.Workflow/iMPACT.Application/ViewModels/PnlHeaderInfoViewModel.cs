﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PnlHeaderInfoViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PnlHeaderInfoViewModel : ViewModelBase
  {
    public long IssueId { get; set; }

    public string IssueNbr { get; set; }

    public string IssueStatus { get; set; }

    public string ReviewStatus { get; set; }

    public string IssueName { get; set; }

    public string IssuerName { get; set; }

    public string OfferingTypeValue { get; set; }

    [AbsoluteDate]
    public DateTime? PricingDate { get; set; }

    public string SettlementDate { get; set; }

    public long PnlTemplateId { get; set; }

    public string PnlNumber { get; set; }

    public long AppTransactionId { get; set; }

    public long CurrentPnlTemplateId { get; set; }

    public List<long> PnLStatus { get; set; }

    public string PnLStatusValue { get; set; }

    public string PnLReviewStatus { get; set; }

    public string CommaSeperatedStateID { get; set; }

    public string LastModifiedBy { get; set; }

    public string JobNumber { get; set; }

    public long StateId { get; set; }

    public string PnlNotes { get; set; }

    public long PricingDeskId { get; set; }

    public string ManagementFee { get; set; }

    public string PnlReviewComments { get; set; }

    public PnlHeaderInfoViewModel()
    {
    }

    public PnlHeaderInfoViewModel(PnlHeaderInfo pnlHeaderInfo)
    {
      this.IssueId = pnlHeaderInfo.IssueId;
      this.IssueNbr = pnlHeaderInfo.IssueNbr;
      this.IssueStatus = pnlHeaderInfo.IssueStatus;
      this.ReviewStatus = pnlHeaderInfo.ReviewStatus;
      this.IssueName = pnlHeaderInfo.IssueName;
      this.IssuerName = pnlHeaderInfo.IssuerName;
      this.OfferingTypeValue = pnlHeaderInfo.OfferingTypeValue;
      this.PricingDate = pnlHeaderInfo.PricingDate;
      this.SettlementDate = pnlHeaderInfo.SettlementDate;
      this.PnlTemplateId = pnlHeaderInfo.PnlTemplateId;
      this.PnlNumber = pnlHeaderInfo.PnlNumber;
      this.AppTransactionId = pnlHeaderInfo.AppTransactionId;
      this.CurrentPnlTemplateId = pnlHeaderInfo.CurrentPnlTemplateId;
      this.PnLStatus = pnlHeaderInfo.PnLStatus;
      this.PnLStatusValue = pnlHeaderInfo.PnLStatusValue;
      this.PnLReviewStatus = pnlHeaderInfo.PnLReviewStatus;
      this.CommaSeperatedStateID = pnlHeaderInfo.CommaSeperatedStateID;
      this.JobNumber = pnlHeaderInfo.JobNumber;
      this.LastModifiedBy = pnlHeaderInfo.LastModifiedBy;
      this.PnlNotes = pnlHeaderInfo.PnlNotes;
      this.PricingDeskId = pnlHeaderInfo.PricingDeskId;
      this.ManagementFee = pnlHeaderInfo.ManagementFee;
      this.PnlReviewComments = pnlHeaderInfo.PnlReviewComments;
    }

    public PnlHeaderInfo GetPnlHeaderInfo() => new PnlHeaderInfo()
    {
      IssueId = this.IssueId,
      IssueNbr = this.IssueNbr,
      IssueStatus = this.IssueStatus,
      ReviewStatus = this.ReviewStatus,
      IssueName = this.IssueName,
      IssuerName = this.IssuerName,
      OfferingTypeValue = this.OfferingTypeValue,
      PricingDate = this.PricingDate,
      SettlementDate = this.SettlementDate,
      PnlTemplateId = this.PnlTemplateId,
      PnlNumber = this.PnlNumber,
      AppTransactionId = this.AppTransactionId,
      PnLStatus = this.PnLStatus,
      PnLStatusValue = this.PnLStatusValue,
      PnLReviewStatus = this.PnLReviewStatus,
      CommaSeperatedStateID = this.CommaSeperatedStateID,
      LastModifiedBy = this.LastModifiedBy,
      JobNumber = this.JobNumber,
      PnlNotes = this.PnlNotes,
      PricingDeskId = this.PricingDeskId,
      ManagementFee = this.ManagementFee,
      PnlReviewComments = this.PnlReviewComments
    };
  }
}
