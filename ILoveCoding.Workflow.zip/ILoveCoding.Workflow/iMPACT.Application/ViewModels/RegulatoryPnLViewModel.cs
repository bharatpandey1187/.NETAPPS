﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RegulatoryPnLViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RegulatoryPnLViewModel : ViewModelBase
  {
    public string ActualLegal { get; set; }

    public string ProjectLegal { get; set; }

    public string ActualSyndicate { get; set; }

    public string ProjectSyndicate { get; set; }

    public string ActualDTCCharges { get; set; }

    public string ProjectDTCCharges { get; set; }

    public string ActualIPREO { get; set; }

    public string ProjectIPREO { get; set; }

    public string ActualCUSIPFees { get; set; }

    public string ProjectCUSIPFees { get; set; }

    public string ActualMSRBAndStateSpecificFee { get; set; }

    public string ProjectMSRBAndStateSpecificFee { get; set; }

    public string ActualCalcAgentAnalysis { get; set; }

    public string ProjectCalcAgentAnalysis { get; set; }

    public string ActualTravelExpenses { get; set; }

    public string ProjectTravelExpenses { get; set; }

    public string ActualMealsClientEntertaing { get; set; }

    public string ProjectMealsClientEntertaing { get; set; }

    public string ActualInternetRoadShow { get; set; }

    public string ProjectInternetRoadShow { get; set; }

    public string ActualPrintingCharges { get; set; }

    public string ProjectPrintingCharges { get; set; }

    public string ActualDeliveryExpenses { get; set; }

    public string ProjectDeliveryExpenses { get; set; }

    public string ActualMarketing { get; set; }

    public string ProjectMarketing { get; set; }

    public string ActualCoManagerExpenses { get; set; }

    public string ProjectCoManagerExpenses { get; set; }

    public string ActualOtherExpenses { get; set; }

    public string ProjectOtherExpenses { get; set; }

    public string ActualLessExpenseReimbursement { get; set; }

    public string ProjectLessExpenseReimbursement { get; set; }

    public string ActualTotalExpenses { get; set; }

    public string ProjectTotalExpenses { get; set; }

    public string ActualTransactionExpenses { get; set; }

    public string ProjectTransactionExpenses { get; set; }

    public string ActualStateSpecificFee { get; set; }

    public string ProjectStateSpecificFee { get; set; }

    public string ActualDealMementos { get; set; }

    public string ProjectDealMementos { get; set; }
  }
}
