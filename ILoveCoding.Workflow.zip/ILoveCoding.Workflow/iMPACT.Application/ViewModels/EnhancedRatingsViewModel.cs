﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.EnhancedRatingsViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class EnhancedRatingsViewModel : ViewModelBase
  {
    public long EnhancedRatingID { get; set; }

    public long SeriesId { get; set; }

    public string MoodyRatingLT { get; set; }

    public string MoodyRatingLTOutlook { get; set; }

    public string MoodyRatingST { get; set; }

    public string MoodyRatingSTOutlook { get; set; }

    public string SPRatingLT { get; set; }

    public string SPRatingLTOutlook { get; set; }

    public string SPRatingST { get; set; }

    public string SPRatingSTOutlook { get; set; }

    public string KrollRatingLT { get; set; }

    public string KrollRatingLTOutlook { get; set; }

    public string KrollRatingST { get; set; }

    public string KrollRatingSTOutlook { get; set; }

    public string FitchRatingLT { get; set; }

    public string FitchRatingLTOutlook { get; set; }

    public string FitchRatingST { get; set; }

    public string FitchRatingSTOutlook { get; set; }

    public KeyPair CreditEnhancementProvider { get; set; }

    public string CreditEnhancementType { get; set; }

    public string CreditEnhancementProviderText { get; set; }

    public string CreditEnhancementTypeText { get; set; }

    public string Series { get; set; }

    public string OtherCreditEnhancementType { get; set; }

    [AbsoluteDate]
    public DateTime? CEExpirationDate { get; set; }
  }
}
