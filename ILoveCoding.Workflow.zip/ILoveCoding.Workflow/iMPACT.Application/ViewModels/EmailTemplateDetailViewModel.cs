﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.EmailTemplateDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Data;
using System;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class EmailTemplateDetailViewModel : ViewModelBase
  {
    public EmailTemplateDetailViewModel()
    {
    }

    public EmailTemplateDetailViewModel(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public EmailTemplateDetailViewModel(EmailTemplate emailTemplate)
    {
      this.EmailTemplateID = emailTemplate.EmailTemplateID;
      this.Name = emailTemplate.Name != null ? emailTemplate.Name.Trim() : emailTemplate.Name;
      this.Description = emailTemplate.Description != null ? emailTemplate.Description.Trim() : emailTemplate.Description;
      this.To = emailTemplate.To;
      this.Cc = emailTemplate.Cc;
      this.Subject = emailTemplate.Subject != null ? emailTemplate.Subject.Trim() : emailTemplate.Subject;
      this.Body = emailTemplate.Body;
      this.IsActive = emailTemplate.IsActive;
      this.CreatedBy = emailTemplate.CreatedBy;
      this.CreatedOn = emailTemplate.CreatedOn;
      this.ModifiedBy = emailTemplate.ModifiedBy;
      this.ModifiedOn = emailTemplate.ModifiedOn;
    }

    public EmailTemplate GetEmailTemplate(
      EmailTemplateDetailViewModel emailTemplateViewModel)
    {
      return new EmailTemplate()
      {
        EmailTemplateID = emailTemplateViewModel.EmailTemplateID,
        Name = emailTemplateViewModel.Name.Trim(),
        Description = emailTemplateViewModel.Description.Trim(),
        To = emailTemplateViewModel.To,
        Cc = emailTemplateViewModel.Cc,
        Subject = emailTemplateViewModel.Subject.Trim(),
        Body = emailTemplateViewModel.Body,
        IsActive = emailTemplateViewModel.IsActive,
        CreatedBy = emailTemplateViewModel.CreatedBy,
        CreatedOn = emailTemplateViewModel.CreatedOn,
        ModifiedBy = emailTemplateViewModel.ModifiedBy,
        ModifiedOn = emailTemplateViewModel.ModifiedOn
      };
    }

    public int EmailTemplateID { get; set; }

    [Required(ErrorMessage = "Name field cannot be blank.")]
    [StringLength(200, ErrorMessage = "Name field length should be less than or equal to 200 characters.")]
    public string Name { get; set; }

    [StringLength(1000, ErrorMessage = "Description field length should be less than or equal to 1000 characters.")]
    public string Description { get; set; }

    [StringLength(1000, ErrorMessage = "To field length should be less than or equal to 1000 characters.")]
    public string To { get; set; }

    [StringLength(1000, ErrorMessage = "Cc field length should be less than or equal to 1000 characters.")]
    public string Cc { get; set; }

    [Required(ErrorMessage = "Subject field cannot be blank.")]
    [StringLength(1000, ErrorMessage = "Subject field length should be less than or equal to 1000 characters.")]
    public string Subject { get; set; }

    [AllowHtml]
    public string Body { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public bool IsViewOnly { get; set; }

    public string AttachmentURL { get; set; }
  }
}
