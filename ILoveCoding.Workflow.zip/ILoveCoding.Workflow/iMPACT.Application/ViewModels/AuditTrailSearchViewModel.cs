﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.AuditTrailSearchViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class AuditTrailSearchViewModel
  {
    [Required(ErrorMessage = "From (Audit Date) cannot be blank.")]
    [DataType(DataType.DateTime, ErrorMessage = "Please enter a valid date in the format dd/mm/yyyy")]
    [Range(typeof (DateTime), "01/01/1900", "01/01/2099", ErrorMessage = "From (Audit Date) Value for {0} must be between {1} and {2}")]
    public DateTime dateFrom { get; set; }

    [Required(ErrorMessage = "To (Audit Date) cannot be blank.")]
    [DataType(DataType.DateTime, ErrorMessage = "Please enter a valid date in the format dd/mm/yyyy")]
    [Range(typeof (DateTime), "01/01/1900", "01/01/2099", ErrorMessage = "To (Audit Date) Value for {0} must be between {1} and {2}")]
    public DateTime dateTo { get; set; }

    public string entity { get; set; }

    public string EntityName { get; set; }
  }
}
