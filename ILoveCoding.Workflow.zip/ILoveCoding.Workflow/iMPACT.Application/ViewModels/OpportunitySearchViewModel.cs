﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.OpportunitySearchViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class OpportunitySearchViewModel
  {
    public List<KeyValuePair<long, string>> OpportunityStatuses { get; set; }

    public List<KeyPair> SelectedOpportunityStatuses { get; set; }

    public bool IsOpportunityStatusIn { get; set; }

    public string OpportunityNumber { get; set; }

    public string OpportunityName { get; set; }

    public List<KeyValuePair<long, string>> States { get; set; }

    public List<KeyPair> SelectedOpportunityStates { get; set; }

    public bool IsOpportunityStateIn { get; set; }

    public string Issuer { get; set; }

    public string Borrower { get; set; }

    public List<KeyPair> SelectedIssuerStates { get; set; }

    public bool IsIssuerStateIn { get; set; }

    public List<KeyPair> SelectedBorrowerStates { get; set; }

    public bool IsBorrowerStateIn { get; set; }

    public string ParAmountFrom { get; set; }

    public string ParAmountTo { get; set; }

    [AbsoluteDate]
    public DateTime? SaleDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? SaleDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? CloseDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? CloseDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? DateHiredFrom { get; set; }

    [AbsoluteDate]
    public DateTime? DateHiredTo { get; set; }

    [AbsoluteDate]
    public DateTime? FinanceDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? FinanceDateTo { get; set; }

    public DateTime? CreateDateFrom { get; set; }

    public DateTime? CreateDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? SubmissionDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? SubmissionDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? ResponseDueDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? ResponseDueDateTo { get; set; }

    public List<KeyValuePair<long, string>> OpportunityTypes { get; set; }

    public List<KeyPair> SelectedOpportunityTypes { get; set; }

    public bool IsOpportunityTypeIn { get; set; }

    public string FedTaxable { get; set; }

    public List<KeyValuePair<long, string>> MAExemptions { get; set; }

    public List<KeyPair> SelectedMAExemptions { get; set; }

    public bool IsMAExemptionIn { get; set; }

    public List<KeyValuePair<long, string>> FirmRoles { get; set; }

    public List<KeyPair> SelectedExpectedFirmRoles { get; set; }

    public bool IsExpectedFirmRoleIn { get; set; }

    public List<KeyPair> SelectedAssignedFirmRoles { get; set; }

    public bool IsAssignedFirmRoleIn { get; set; }

    public string StateTaxable { get; set; }

    public string FedTax { get; set; }

    public List<KeyPair> Purposes { get; set; }

    public string Purpose { get; set; }

    public List<KeyPair> SecurityTypes { get; set; }

    public string SecurityType { get; set; }

    public List<KeyValuePair<long, string>> Markets { get; set; }

    public List<KeyValuePair<long, string>> SeriesFedTax { get; set; }

    public List<KeyPair> SelectedMarkets { get; set; }

    public bool IsMarketIn { get; set; }

    public bool? BankQualified { get; set; }

    public List<KeyPair> MoodyLongTermRatings { get; set; }

    public string MoodyLongTermRating { get; set; }

    public List<KeyPair> SPLongTermRatings { get; set; }

    public string SPLongTermRating { get; set; }

    public List<KeyPair> KrollLongTermRatings { get; set; }

    public string KrollLongTermRating { get; set; }

    public List<KeyPair> FitchLongTermRatings { get; set; }

    public string FitchLongTermRating { get; set; }

    public List<InternalPartnerSearchModel> InternalPartners { get; set; }

    public List<KeyPair> AdvisorAgentType { get; set; }

    public List<KeyPair> CounselType { get; set; }

    public List<KeyPair> SyndicateMember { get; set; }

    public List<ExternalPartnerSearchModel> ExternalPartners { get; set; }

    public List<SearchResultField> AllFields { get; set; }

    public List<SearchResultField> SelectedAllFields { get; set; }

    public List<SearchResultField> SelectedFields { get; set; }

    public List<SearchResultField> FieldsToSelect { get; set; }

    public bool CanCreatePublicBookmark { get; set; }

    public List<KeyPair> WinningSyndicateMember { get; set; }

    public string Name { get; set; }

    public string Scope { get; set; }

    public string CreatedBy { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedPricingDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedPricingDateTo { get; set; }

    public List<KeyValuePair<long, string>> DealTypes { get; set; }

    public long? DealType { get; set; }

    public List<KeyValuePair<long, string>> InterestRateTypes { get; set; }

    public long? RateTypeID { get; set; }

    public List<KeyValuePair<long, string>> UseOfProceeds { get; set; }

    public long? UseOfProceedsID { get; set; }

    public List<KeyValuePair<long, string>> RFPTypes { get; set; }

    public long? RFPTypeID { get; set; }

    public OpportunitySearchViewModel()
    {
      this.OpportunityStatuses = new List<KeyValuePair<long, string>>();
      this.IsOpportunityStatusIn = true;
      this.IsOpportunityStateIn = true;
      this.IsIssuerStateIn = true;
      this.IsBorrowerStateIn = true;
      this.IsOpportunityTypeIn = true;
      this.IsMAExemptionIn = true;
      this.IsExpectedFirmRoleIn = true;
      this.IsAssignedFirmRoleIn = true;
      this.IsMarketIn = true;
      this.States = new List<KeyValuePair<long, string>>();
      this.OpportunityTypes = new List<KeyValuePair<long, string>>();
      this.FirmRoles = new List<KeyValuePair<long, string>>();
      this.MAExemptions = new List<KeyValuePair<long, string>>();
      this.Markets = new List<KeyValuePair<long, string>>();
      this.DealTypes = new List<KeyValuePair<long, string>>();
      this.InterestRateTypes = new List<KeyValuePair<long, string>>();
      this.UseOfProceeds = new List<KeyValuePair<long, string>>();
      this.RFPTypes = new List<KeyValuePair<long, string>>();
      this.SeriesFedTax = new List<KeyValuePair<long, string>>();
      this.SelectedOpportunityStatuses = new List<KeyPair>();
      this.Purposes = new List<KeyPair>();
      this.SelectedMarkets = new List<KeyPair>();
      this.MoodyLongTermRatings = new List<KeyPair>();
      this.SPLongTermRatings = new List<KeyPair>();
      this.KrollLongTermRatings = new List<KeyPair>();
      this.FitchLongTermRatings = new List<KeyPair>();
      this.AdvisorAgentType = new List<KeyPair>();
      this.CounselType = new List<KeyPair>();
      this.SyndicateMember = new List<KeyPair>();
      this.SecurityTypes = new List<KeyPair>();
      this.SelectedExpectedFirmRoles = new List<KeyPair>();
      this.SelectedAssignedFirmRoles = new List<KeyPair>();
      this.SelectedOpportunityTypes = new List<KeyPair>();
      this.SelectedMAExemptions = new List<KeyPair>();
      this.SelectedOpportunityStates = new List<KeyPair>();
      this.SelectedIssuerStates = new List<KeyPair>();
      this.SelectedBorrowerStates = new List<KeyPair>();
      this.WinningSyndicateMember = new List<KeyPair>();
      this.InternalPartners = new List<InternalPartnerSearchModel>();
      this.ExternalPartners = new List<ExternalPartnerSearchModel>();
      this.AllFields = new List<SearchResultField>();
      this.SelectedAllFields = new List<SearchResultField>();
      this.SelectedFields = new List<SearchResultField>();
      this.FieldsToSelect = new List<SearchResultField>();
    }
  }
}
