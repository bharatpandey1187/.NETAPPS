﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DocSetDocumentViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DocSetDocumentViewModel : ViewModelBase
  {
    public DocSetDocumentViewModel()
    {
    }

    public DocSetDocumentViewModel(DocSetDocument doc)
    {
      this.EntityDocSetDocumentID = doc.AppTransactionDocSetDocumentID;
      this.AppTransactionDocSetID = doc.AppTransactionDocSetID;
      this.AppTransactionID = doc.AppTransactionID;
      this.DocSetName = doc.DocSetName;
      this.DocSetID = doc.DocSetID;
      this.DocSetURL = doc.DocSetURL;
      this.DocumentID = doc.DocumentID;
      this.DocumentURL = doc.DocumentURL;
      this.DocumentListID = doc.DocumentListID;
      this.UIVersionLabel = doc.UIVersionLabel;
      this.TotalVersion = doc.TotalVersion;
      this.CheckoutType = doc.CheckoutType;
      this.LastModifiedBy = doc.LastModifiedBy;
      this.LastModifiedOn = doc.LastModifiedOn;
      this.CheckedoutBy = doc.CheckedoutBy;
      this.CheckedoutDate = doc.CheckedoutDate;
      this.CheckedOutExpires = doc.CheckedOutExpires;
      this.StorageKey = doc.StorageKey;
      this.EntityType = doc.EntityType;
      this.CheckoutDocumentID = doc.CheckoutDocumentID;
      this.DocumentName = doc.DocumentName;
      this.Category = doc.Category;
      this.DocType = doc.DocType;
      this.TypeOtherDesc = doc.TypeOtherDesc;
      this.Tags = doc.Tags;
    }

    public long EntityDocSetDocumentID { get; set; }

    public long AppTransactionDocSetID { get; set; }

    public long AppTransactionID { get; set; }

    public long DocSetName { get; set; }

    public long DocSetID { get; set; }

    public string DocSetURL { get; set; }

    public string DocumentID { get; set; }

    public string DocumentURL { get; set; }

    public string DocumentListID { get; set; }

    public string UIVersionLabel { get; set; }

    public long? TotalVersion { get; set; }

    public string CheckoutType { get; set; }

    public string LastModifiedBy { get; set; }

    public DateTime LastModifiedOn { get; set; }

    public string CheckedoutBy { get; set; }

    public DateTime? CheckedoutDate { get; set; }

    public DateTime? CheckedOutExpires { get; set; }

    public string StorageKey { get; set; }

    public long EntityType { get; set; }

    public string CheckoutDocumentID { get; set; }

    public string DocumentName { get; set; }

    public string Category { get; set; }

    public string DocType { get; set; }

    public string TypeOtherDesc { get; set; }

    public string Tags { get; set; }
  }
}
