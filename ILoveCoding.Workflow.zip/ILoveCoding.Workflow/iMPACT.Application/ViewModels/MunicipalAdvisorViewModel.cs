﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MunicipalAdvisorViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MunicipalAdvisorViewModel
  {
    public long MunicipalAdvisorRegCheckListID { get; set; }

    public bool? WasRFP { get; set; }

    public bool? IsRegisteredMunicipalAdvisor { get; set; }

    public bool? IsIRMACertificationReceived { get; set; }

    [AbsoluteDate]
    public DateTime? IRMACertificationDate { get; set; }

    [AbsoluteDate]
    public DateTime? IRMACertificationExpiryDate { get; set; }

    public bool? IsIRMAReprentativeSentToClientAndIssuer { get; set; }

    [AbsoluteDate]
    public DateTime? IRMAPresentationDate { get; set; }

    public bool? IsIRMAPresentationCopyRetained { get; set; }

    public string ReasonForNoCopyRetained { get; set; }

    public string UnderWriterOrRemarketingAgentMethod { get; set; }

    [AbsoluteDate]
    public DateTime? EngagementDate { get; set; }

    public long IssuerID { get; set; }

    public string EvidenceOfEngagement { get; set; }

    public long AppTransactionID { get; set; }

    [AbsoluteDate]
    public DateTime? EarlistDateOfEngagement { get; set; }

    public string IRMANotPerfect { get; set; }

    public string FinancialAdvisor { get; set; }
  }
}
