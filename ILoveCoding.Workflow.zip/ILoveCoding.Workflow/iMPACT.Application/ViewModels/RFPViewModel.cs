﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RFPViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RFPViewModel : ViewModelBase
  {
    public RFPViewModel()
    {
      this.Issuer = new KeyPair();
      this.Analysts = new List<InternalPartner>();
      this.Bankers = new List<InternalPartner>();
      this.AuditTrails = new List<AuditTrailViewModel>();
      this.SupervisoryPrincipals = new List<InternalPartner>();
      this.BankRMs = new List<InternalPartnerBankRM>();
      this.RFPTypes = new List<KeyPair>();
      this.States = new List<KeyPair>();
      this.Roles = new List<KeyPair>();
      this.Purposes = new List<KeyPair>();
      this.GeneralCategories = new List<KeyPair>();
      this.MoodyRatings = new List<KeyPair>();
      this.SnPRatings = new List<KeyPair>();
      this.FitchRatings = new List<KeyPair>();
      this.KrollRatings = new List<KeyPair>();
      this.RfpContact = new RfpContactDetailViewModel();
      this.ApprovedDerivativeMarketers = new List<KeyPair>();
      this.TransactionTypes = new List<KeyPair>();
      this.SecurityTypes = new List<KeyPair>();
      this.MAExemptionDetails = new List<MAExemptionDetail>();
      this.MAExemptions = new List<KeyPair>();
      this.MaterialTypes = new List<KeyPair>();
      this.Counsels = new List<ExternalPartner>();
      this.NotesCollection = new List<IrisSoftware.iMPACT.Data.Notes>();
      this.ReviewCommentsCollection = new List<IrisSoftware.iMPACT.Data.ReviewComments>();
    }

    public RFPViewModel(RFP rfp)
    {
      this.AppTransactionID = rfp.RfpDetail.AppTransactionID;
      this.RFPNbr = rfp.RfpDetail.RFPNbr;
      this.RFPName = rfp.RfpDetail.RFPName;
      this.RFPStatus = rfp.RfpDetail.RFPStatus;
      this.RFPStatusValue = rfp.RfpDetail.RFPStatusValue;
      this.RFPReviewStatus = rfp.RfpDetail.RFPReviewStatus;
      this.IssuerID = rfp.RfpDetail.IssuerID;
      this.IssuerName = rfp.RfpDetail.IssuerName;
      if (rfp.RfpDetail.IssuerID.HasValue)
        this.Issuer = new KeyPair(rfp.RfpDetail.IssuerID.Value, rfp.RfpDetail.IssuerName);
      this.BorrowerID = rfp.RfpDetail.BorrowerID;
      this.BorrowerName = rfp.RfpDetail.BorrowerName;
      if (rfp.RfpDetail.BorrowerID.HasValue)
        this.Borrower = new KeyPair(rfp.RfpDetail.BorrowerID.Value, rfp.RfpDetail.BorrowerName);
      this.GuarantorID = rfp.RfpDetail.GuarantorID;
      this.GuarantorName = rfp.RfpDetail.GuarantorName;
      if (rfp.RfpDetail.GuarantorID.HasValue)
        this.Guarantor = new KeyPair(rfp.RfpDetail.GuarantorID.Value, rfp.RfpDetail.GuarantorName);
      this.SubmissionDateTime = rfp.RfpDetail.SubmissionDateTime;
      this.RFPType = rfp.RfpDetail.RFPType;
      this.ParAmount = rfp.RfpDetail.ParAmount;
      this.State = rfp.RfpDetail.State;
      this.County = rfp.RfpDetail.County;
      this.FirmRole = rfp.RfpDetail.FirmRole;
      this.FirmLiabilityPerc = rfp.RfpDetail.FirmLiabilityPerc;
      this.AssignedFirmRole = rfp.RfpDetail.AssignedFirmRole;
      this.AssignedFirmLiability = rfp.RfpDetail.AssignedFirmLiability;
      this.Purpose = rfp.RfpDetail.Purpose;
      this.GeneralCategory = rfp.RfpDetail.GeneralCategory;
      this.FedTax = rfp.RfpDetail.FedTaxable;
      this.StateTax = rfp.RfpDetail.StateTaxable;
      this.AMT = rfp.RfpDetail.AMTTaxable;
      this.BankQualified = rfp.RfpDetail.BankQualified;
      this.Moody = rfp.RfpDetail.MoodyRatingLT;
      this.SP = rfp.RfpDetail.SPRatingLT;
      this.Fitch = rfp.RfpDetail.FitchRatingLT;
      this.KrollRatingLT = rfp.RfpDetail.KrollRatingLT;
      this.ReviewComments = rfp.RfpDetail.ReviewComments;
      this.AppTransactionClientContacts = rfp.AppTransactionClientContacts;
      this.FinancialAdvisorName = rfp.FinancialAdvisorName;
      this.AssignedTo = rfp.AssignedTo;
      this.Version = rfp.RfpDetail.Version;
      this.DocumentLibraryURL = rfp.RfpDetail.DocumentLibraryURL;
      this.CreatedBy = rfp.RfpDetail.CreatedBy;
      this.CreatedOn = rfp.RfpDetail.CreatedOn;
      this.ModifiedBy = rfp.RfpDetail.ModifiedBy;
      this.ModifiedOn = rfp.RfpDetail.ModifiedOn;
      this.LastModifiedBy = rfp.RfpDetail.LastModifiedBy;
      if (rfp.InternalPartners != null && rfp.InternalPartners.Count > 0)
      {
        this.Bankers = rfp.InternalPartners == null ? new List<InternalPartner>() : rfp.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
        {
          long? roleTypeId = x.RoleTypeId;
          long int64 = Convert.ToInt64((object) RFP.RoleTypes.InvestmentBankingTeam);
          return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
        })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
        this.Analysts = rfp.InternalPartners == null ? new List<InternalPartner>() : rfp.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
        {
          long? roleTypeId = x.RoleTypeId;
          long int64 = Convert.ToInt64((object) RFP.RoleTypes.AnalystProfessionalSupport);
          return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
        })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
        this.SupervisoryPrincipals = rfp.InternalPartners == null ? new List<InternalPartner>() : rfp.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
        {
          long? roleTypeId = x.RoleTypeId;
          long int64 = Convert.ToInt64((object) RFP.RoleTypes.SupervisoryPrincipal);
          return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
        })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      }
      this.BankRMs = rfp.InternalPartnerBankRMs == null ? new List<InternalPartnerBankRM>() : rfp.InternalPartnerBankRMs.OrderBy<InternalPartnerBankRM, string>((Func<InternalPartnerBankRM, string>) (x => x.Name)).ToList<InternalPartnerBankRM>();
      if (rfp.ExternalPartners != null && rfp.ExternalPartners.Count > 0)
      {
        this.Advisors = rfp.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Advisory Agent Type")).OrderBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>();
        this.Counsels = rfp.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Counsel Type")).OrderBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>();
      }
      this.RfpContact = new RfpContactDetailViewModel(rfp);
      this.AuditTrails = new List<AuditTrailViewModel>();
      this.ParentOpportunityID = rfp.RfpDetail.ParentOpportunityID;
      this.ParentOpportunityName = rfp.RfpDetail.ParentOpportunityName;
      this.PowerID = rfp.RfpDetail.PowerID;
      this.HybridSolutionIndicator = rfp.RfpDetail.HybridSolutionIndicator;
      this.DualProposalProposed = rfp.RfpDetail.DualProposalProposed;
      this.InformationalMERGRequired = rfp.RfpDetail.InformationalMERGRequired;
      this.ApprovedDerivativeMarketer = rfp.RfpDetail.ApprovedDerivativeMarketer;
      this.TransactionType = rfp.RfpDetail.TransactionType;
      this.SecurityType = rfp.RfpDetail.SecurityType;
      this.GrossSpread = rfp.RfpDetail.GrossSpread;
      this.EstGrossRev = rfp.RfpDetail.EstGrossRev;
      this.ResponseDueDateTime = rfp.RfpDetail.ResponseDueDateTime;
      this.ResponseDueDateTimezone = rfp.RfpDetail.ResponseDueDateTimezone;
      this.SubmissionDateTimezone = rfp.RfpDetail.SubmissionDateTimezone;
      this.SupervisoryPrincipalReviewDate = rfp.RfpDetail.SupervisoryPrincipalReviewDate;
      this.SupervisoryPrincipalApprovalDate = rfp.RfpDetail.SupervisoryPrincipalApprovalDate;
      this.SentTo3Firms = rfp.RfpDetail.SentTo3Firms;
      this.Notes = rfp.RfpDetail.Notes;
      this.MAExemptionDetails = rfp.RfpDetail.MAExemptionDetails;
      this.MaterialType = rfp.RfpDetail.MaterialType;
      this.NotesCollection = rfp.RfpDetail.NotesCollection;
      this.ReviewCommentsCollection = rfp.ReviewCommentsCollection;
      this.IsMERGInformed = rfp.RfpDetail.IsMERGInformed;
      this.SubmittedToMERGDate = rfp.RfpDetail.SubmittedToMERGDate;
      this.HasIssueInitiated = rfp.RfpDetail.HasIssueInitiated;
      this.IsRFPInitiatedFromParentOpportunity = rfp.RfpDetail.IsRFPInitiatedFromParentOpportunity;
      this.CreatorEmployeeId = rfp.RfpDetail.CreatorEmployeeId;
    }

    public RFP GetRFP()
    {
      RFP rfp = new RFP();
      rfp.RfpDetail.AppTransactionID = this.AppTransactionID;
      rfp.RfpDetail.RFPNbr = this.RFPNbr != null ? this.RFPNbr.Trim() : this.RFPNbr;
      rfp.RfpDetail.RFPName = this.RFPName != null ? this.RFPName.Trim() : this.RFPName;
      rfp.RfpDetail.RFPStatus = this.RFPStatus;
      rfp.RfpDetail.IssuerID = this.Issuer == null || string.IsNullOrEmpty(this.Issuer.Key) ? new long?() : new long?(Convert.ToInt64(this.Issuer.Key));
      rfp.RfpDetail.IssuerName = this.Issuer == null || string.IsNullOrEmpty(this.Issuer.Value) ? (string) null : this.Issuer.Value;
      rfp.RfpDetail.BorrowerID = this.Borrower == null || string.IsNullOrEmpty(this.Borrower.Key) ? new long?() : new long?(Convert.ToInt64(this.Borrower.Key));
      rfp.RfpDetail.GuarantorID = this.Guarantor == null || string.IsNullOrEmpty(this.Guarantor.Key) ? new long?() : new long?(Convert.ToInt64(this.Guarantor.Key));
      rfp.RfpDetail.SubmissionDateTime = this.SubmissionDateTime;
      rfp.RfpDetail.RFPType = this.RFPType;
      rfp.RfpDetail.ParAmount = this.ParAmount;
      rfp.RfpDetail.State = this.State;
      rfp.RfpDetail.County = this.County != null ? this.County.Trim() : this.County;
      rfp.RfpDetail.FirmRole = this.FirmRole;
      rfp.RfpDetail.FirmLiabilityPerc = this.FirmLiabilityPerc;
      rfp.RfpDetail.AssignedFirmRole = this.AssignedFirmRole;
      rfp.RfpDetail.AssignedFirmLiability = this.AssignedFirmLiability;
      rfp.RfpDetail.Purpose = this.Purpose;
      rfp.RfpDetail.GeneralCategory = this.GeneralCategory;
      rfp.RfpDetail.FedTaxable = this.FedTax;
      rfp.RfpDetail.StateTaxable = this.StateTax;
      rfp.RfpDetail.AMTTaxable = this.AMT;
      rfp.RfpDetail.BankQualified = this.BankQualified;
      rfp.RfpDetail.MoodyRatingLT = this.Moody;
      rfp.RfpDetail.SPRatingLT = this.SP;
      rfp.RfpDetail.FitchRatingLT = this.Fitch;
      rfp.RfpDetail.KrollRatingLT = this.KrollRatingLT;
      rfp.RfpDetail.ReviewComments = this.ReviewComments != null ? this.ReviewComments.Trim() : this.ReviewComments;
      rfp.AppTransactionClientContacts = this.AppTransactionClientContacts;
      rfp.InternalPartners = new List<InternalPartner>();
      if (this.Bankers != null && this.Bankers.Count > 0)
        rfp.InternalPartners.AddRange((IEnumerable<InternalPartner>) this.Bankers);
      if (this.Analysts != null && this.Analysts.Count > 0)
        rfp.InternalPartners.AddRange((IEnumerable<InternalPartner>) this.Analysts);
      if (this.SupervisoryPrincipals != null && this.SupervisoryPrincipals.Count > 0)
        rfp.InternalPartners.AddRange((IEnumerable<InternalPartner>) this.SupervisoryPrincipals);
      if (this.BankRMs != null && this.BankRMs.Count > 0)
        rfp.InternalPartnerBankRMs = this.BankRMs;
      rfp.ExternalPartners = new List<ExternalPartner>();
      if (this.Advisors != null && this.Advisors.Count > 0)
        rfp.ExternalPartners.AddRange((IEnumerable<ExternalPartner>) this.Advisors);
      rfp.RfpDetail.MAExemptionDetails = new List<MAExemptionDetail>();
      if (this.MAExemptionDetails != null && this.MAExemptionDetails.Count > 0)
        rfp.RfpDetail.MAExemptionDetails.AddRange((IEnumerable<MAExemptionDetail>) this.MAExemptionDetails);
      rfp.RfpDetail.Version = this.Version;
      rfp.RfpDetail.DocumentLibraryURL = this.DocumentLibraryURL;
      rfp.RfpDetail.CreatedBy = this.CreatedBy;
      rfp.RfpDetail.CreatedOn = this.CreatedOn;
      rfp.RfpDetail.ModifiedBy = this.ModifiedBy;
      rfp.RfpDetail.ModifiedOn = this.ModifiedOn;
      rfp.RfpDetail.LastModifiedBy = this.LastModifiedBy;
      rfp.RfpDetail.ParentOpportunityID = this.ParentOpportunityID;
      rfp.RfpDetail.PowerID = this.PowerID != null ? this.PowerID.Trim() : this.PowerID;
      rfp.RfpDetail.HybridSolutionIndicator = this.HybridSolutionIndicator;
      rfp.RfpDetail.DualProposalProposed = this.DualProposalProposed;
      rfp.RfpDetail.InformationalMERGRequired = this.InformationalMERGRequired;
      rfp.RfpDetail.ApprovedDerivativeMarketer = this.ApprovedDerivativeMarketer;
      rfp.RfpDetail.TransactionType = this.TransactionType;
      rfp.RfpDetail.SecurityType = this.SecurityType;
      rfp.RfpDetail.GrossSpread = this.GrossSpread;
      rfp.RfpDetail.EstGrossRev = this.EstGrossRev;
      rfp.RfpDetail.ResponseDueDateTime = this.ResponseDueDateTime;
      rfp.RfpDetail.ResponseDueDateTimezone = this.ResponseDueDateTimezone;
      rfp.RfpDetail.SubmissionDateTimezone = this.SubmissionDateTimezone;
      rfp.RfpDetail.SupervisoryPrincipalReviewDate = this.SupervisoryPrincipalReviewDate;
      rfp.RfpDetail.SupervisoryPrincipalApprovalDate = this.SupervisoryPrincipalApprovalDate;
      rfp.RfpDetail.SentTo3Firms = this.SentTo3Firms;
      rfp.RfpDetail.Notes = this.Notes;
      rfp.RfpDetail.MaterialType = this.MaterialType;
      if (this.Counsels != null && this.Counsels.Count > 0)
        rfp.ExternalPartners.AddRange((IEnumerable<ExternalPartner>) this.Counsels);
      rfp.RfpDetail.IsMERGInformed = this.IsMERGInformed;
      rfp.RfpDetail.SubmittedToMERGDate = this.SubmittedToMERGDate;
      rfp.RfpDetail.HasIssueInitiated = this.HasIssueInitiated;
      rfp.RfpDetail.IsRFPInitiatedFromParentOpportunity = this.IsRFPInitiatedFromParentOpportunity;
      return rfp;
    }

    public long AppTransactionID { get; set; }

    public string RFPNbr { get; set; }

    [Required(ErrorMessage = "RFP Name cannot be blank.")]
    public string RFPName { get; set; }

    public List<long> RFPStatus { get; set; }

    public string RFPStatusValue { get; set; }

    public string RFPReviewStatus { get; set; }

    [Required(ErrorMessage = "Issuer cannot be blank.")]
    public KeyPair Issuer { get; set; }

    public long? IssuerID { get; set; }

    public string IssuerName { get; set; }

    public KeyPair Borrower { get; set; }

    public long? BorrowerID { get; set; }

    public string BorrowerName { get; set; }

    public KeyPair Guarantor { get; set; }

    public long? GuarantorID { get; set; }

    public string GuarantorName { get; set; }

    public DateTime? SubmissionDateTime { get; set; }

    public long? RFPType { get; set; }

    public Decimal? ParAmount { get; set; }

    public long? State { get; set; }

    public string County { get; set; }

    public long? FirmRole { get; set; }

    public Decimal? FirmLiabilityPerc { get; set; }

    public long? AssignedFirmRole { get; set; }

    public Decimal? AssignedFirmLiability { get; set; }

    public long? Purpose { get; set; }

    public long? GeneralCategory { get; set; }

    public string FedTax { get; set; }

    public string StateTax { get; set; }

    public string AMT { get; set; }

    public bool? BankQualified { get; set; }

    public long? Moody { get; set; }

    public long? SP { get; set; }

    public long? Fitch { get; set; }

    public long? KrollRatingLT { get; set; }

    public string FinancialAdvisorName { get; set; }

    public string AssignedTo { get; set; }

    public int Version { get; set; }

    public string DocumentLibraryURL { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public string LastModifiedBy { get; set; }

    public List<AuditTrailViewModel> AuditTrails { get; set; }

    public string[] Actions { get; set; }

    public RfpBanker Banker { get; set; }

    public List<KeyPair> RFPTypes { get; set; }

    public List<KeyPair> States { get; set; }

    public List<KeyPair> Roles { get; set; }

    public List<KeyPair> Purposes { get; set; }

    public List<KeyPair> GeneralCategories { get; set; }

    public List<KeyPair> MoodyRatings { get; set; }

    public List<KeyPair> SnPRatings { get; set; }

    public List<KeyPair> FitchRatings { get; set; }

    public List<KeyPair> KrollRatings { get; set; }

    public List<KeyPair> AdvisorAgentType { get; set; }

    public List<InternalPartner> Bankers { get; set; }

    public List<InternalPartner> Analysts { get; set; }

    public List<ExternalPartner> Advisors { get; set; }

    public List<InternalPartner> SupervisoryPrincipals { get; set; }

    public List<InternalPartnerBankRM> BankRMs { get; set; }

    public List<AppTransactionClientContact> AppTransactionClientContacts { get; set; }

    public RfpContactDetailViewModel RfpContact { get; set; }

    public List<AppTransactionStateTransition> WorkflowStateTransitions { get; set; }

    public long? ParentOpportunityID { get; set; }

    public string ParentOpportunityName { get; set; }

    public string PowerID { get; set; }

    public bool? HybridSolutionIndicator { get; set; }

    public bool? DualProposalProposed { get; set; }

    public bool? InformationalMERGRequired { get; set; }

    public long? ApprovedDerivativeMarketer { get; set; }

    public long? TransactionType { get; set; }

    public long? SecurityType { get; set; }

    public Decimal? GrossSpread { get; set; }

    public Decimal? EstGrossRev { get; set; }

    public DateTime? ResponseDueDateTime { get; set; }

    public string ResponseDueDateTimezone { get; set; }

    public string SubmissionDateTimezone { get; set; }

    public DateTime? SupervisoryPrincipalReviewDate { get; set; }

    public DateTime? SupervisoryPrincipalApprovalDate { get; set; }

    public bool? SentTo3Firms { get; set; }

    public string ReviewData { get; set; }

    public List<KeyPair> ApprovedDerivativeMarketers { get; set; }

    public List<KeyPair> TransactionTypes { get; set; }

    public List<KeyPair> SecurityTypes { get; set; }

    public string NotesData { get; set; }

    public List<MAExemptionDetail> MAExemptionDetails { get; set; }

    public List<KeyPair> MAExemptions { get; set; }

    public List<KeyPair> MaterialTypes { get; set; }

    public long? MaterialType { get; set; }

    public List<KeyPair> CounselType { get; set; }

    public List<ExternalPartner> Counsels { get; set; }

    public bool IsViewOnly { get; set; }

    public bool ViewRfpInternalPartners { get; set; }

    public bool IsRfpInternalPartnersViewOnly { get; set; }

    public bool ViewRfpExternalPartners { get; set; }

    public bool IsRfpExternalPartnersViewOnly { get; set; }

    public bool ViewRfpDocuments { get; set; }

    public bool CanUploadRfpDocuments { get; set; }

    public bool IsRfpDocumentsViewOnly { get; set; }

    public bool ViewRfpContacts { get; set; }

    public bool ViewRfpReview { get; set; }

    public bool IsReviewViewOnly { get; set; }

    public bool ViewRfpAuditTrail { get; set; }

    public bool DisableRfpDetailEmail { get; set; }

    public string Notes { get; set; }

    public string ReviewComments { get; set; }

    public List<IrisSoftware.iMPACT.Data.Notes> NotesCollection { get; set; }

    public List<IrisSoftware.iMPACT.Data.ReviewComments> ReviewCommentsCollection { get; set; }

    public bool IsMERGInformed { get; set; }

    public DateTime? SubmittedToMERGDate { get; set; }

    public bool DisableInitiateIssue { get; set; }

    public bool CanInitiateIssue { get; set; }

    public bool? HasIssueInitiated { get; set; }

    public bool? HasDualProposalRequestedOrProposed { get; set; }

    public bool IsAppTransactionClientContactEditable { get; set; }

    public bool? IsRFPInitiatedFromParentOpportunity { get; set; }

    public long? CreatorEmployeeId { get; set; }
  }
}
