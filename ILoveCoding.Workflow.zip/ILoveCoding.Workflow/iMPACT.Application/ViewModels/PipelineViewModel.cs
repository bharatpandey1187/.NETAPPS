﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PipelineViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PipelineViewModel
  {
    private string _Office;

    public long AppTransactionID { get; set; }

    public string ExpectedAwardTxtDateTime { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedAwardDateTime { get; set; }

    public string ExpectedAwardDate => this.ExpectedAwardDateTime.HasValue ? this.ExpectedAwardDateTime.Value.ToShortDateString() : string.Empty;

    [AbsoluteDate]
    public DateTime? PricingDateTime { get; set; }

    public string PricingDate => this.PricingDateTime.HasValue ? this.PricingDateTime.Value.ToShortDateString() : string.Empty;

    public string ParAmount { get; set; }

    public string Issuer { get; set; }

    public string State { get; set; }

    public string FirmRole { get; set; }

    public string FA { get; set; }

    public string Office
    {
      get
      {
        if (this._Office == null)
          return string.Empty;
        return this._Office.Trim().Length == 1 && this._Office.Trim() == ";" ? this._Office.Replace(';', ' ') : this._Office;
      }
      set => this._Office = value;
    }

    public string LeadBanker { get; set; }

    public string IssueStatus { get; set; }

    public string ReviewStatus { get; set; }

    public string BidPlatform { get; set; }

    public string BidCalc { get; set; }

    public long OfferingType { get; set; }

    public string IssueName { get; set; }

    [AbsoluteDate]
    public DateTime? CreatedOn { get; set; }

    public string OfferingTypeName { get; set; }

    public List<SeriesPipelineViewModel> Series { get; set; }

    [AbsoluteDate]
    public DateTime? DeliveryDate { get; set; }

    public string Borrower { get; set; }

    public string JobNumber { get; set; }

    public long EntityID { get; set; }
  }
}
