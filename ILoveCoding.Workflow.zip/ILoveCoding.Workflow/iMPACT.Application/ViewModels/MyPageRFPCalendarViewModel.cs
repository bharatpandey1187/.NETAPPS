﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MyPageRFPCalendarViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MyPageRFPCalendarViewModel
  {
    public long AppTransactionID { get; set; }

    public string RFPNbr { get; set; }

    public string RFPName { get; set; }

    public string IssuerName { get; set; }

    public string State { get; set; }

    public string RFPType { get; set; }

    public string RFPStatus { get; set; }

    public string ReviewStatus { get; set; }

    public Decimal? ParAmount { get; set; }

    public string FirmRole { get; set; }

    public DateTime? ResponseDueDateTime { get; set; }

    public DateTime? SupervisoryPrincipalReviewDate { get; set; }

    public string Task { get; set; }
  }
}
