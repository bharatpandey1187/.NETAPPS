﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.AuditTrailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class AuditTrailViewModel
  {
    public AuditTrailViewModel()
    {
    }

    public AuditTrailViewModel(AuditTrail auditTrail)
    {
      this.AuditTrailID = auditTrail.AuditTrailID;
      this.AppTransactionID = auditTrail.AppTransactionID;
      this.When = auditTrail.When;
      this.What = auditTrail.What;
      this.Who = auditTrail.Who;
      this.Entity = auditTrail.Entity;
      this.VersionNo = auditTrail.VersionNo;
    }

    public List<int> Versions { get; set; }

    public int VersionNo { get; set; }

    public long AuditTrailID { get; set; }

    public long? AppTransactionID { get; set; }

    public DateTime? When { get; set; }

    public string What { get; set; }

    public string Who { get; set; }

    public string Entity { get; set; }

    public string Status { get; set; }

    public string WhenString => this.When.HasValue ? this.When.Value.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;
  }
}
