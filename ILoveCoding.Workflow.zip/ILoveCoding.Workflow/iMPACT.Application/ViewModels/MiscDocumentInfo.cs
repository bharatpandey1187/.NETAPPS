﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MiscDocumentInfo
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MiscDocumentInfo
  {
    public long EntityDocSetDocumentID { get; set; }

    public string WebURL { get; set; }

    public string FullUrl { get; set; }

    public string Name { get; set; }

    public string FileID { get; set; }

    public string Category { get; set; }

    public string Type { get; set; }

    public string TypeOtherDesc { get; set; }

    public string Tags { get; set; }

    public string CheckOutType { get; set; }

    public string UIVersionLabel { get; set; }

    public int TotalVersion { get; set; }

    public string LastModifiedBy { get; set; }

    public DateTime LastModifiedOn { get; set; }

    public string CheckedOutBy { get; set; }

    public DateTime CheckedOutDate { get; set; }

    public DateTime CheckedOutExpires { get; set; }

    public string StorageKey { get; set; }
  }
}
