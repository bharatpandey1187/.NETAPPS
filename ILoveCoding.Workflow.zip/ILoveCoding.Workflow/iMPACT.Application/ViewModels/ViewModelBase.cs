﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ViewModelBase
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Validation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ViewModelBase
  {
    public bool IsDirty { get; set; }

    public bool IsDeleted { get; set; }

    public string ErrorMessage { get; set; }

    public virtual SaveResult Validate<T>()
    {
      ValidationResults validationResults = EnterpriseLibraryContainer.Current.GetInstance<ValidatorFactory>().CreateValidator<T>().Validate((object) this);
      return !validationResults.IsValid ? SaveResult.Failure(validationResults) : new SaveResult();
    }

    public byte? ConvertStringToByte(string str) => string.IsNullOrEmpty(str) ? new byte?() : new byte?(Convert.ToByte(str));

    public int? ConvertStringToInt(string str) => string.IsNullOrEmpty(str) ? new int?() : new int?(Convert.ToInt32(str));

    public long? ConvertStringToInt64(string str) => string.IsNullOrEmpty(str) ? new long?() : new long?(Convert.ToInt64(str));

    public Decimal? ConvertStringToDecimal(string str) => string.IsNullOrEmpty(str) ? new Decimal?() : new Decimal?(Convert.ToDecimal(str));

    public Decimal? ConvertCurrenyToDecimal(string currency)
    {
      if (string.IsNullOrEmpty(currency))
        return new Decimal?();
      currency = currency.Replace("$", "").Replace(",", "");
      return new Decimal?(Convert.ToDecimal(currency));
    }

    public DateTime? ConvertStringToDate(string strDate) => string.IsNullOrEmpty(strDate) ? new DateTime?() : new DateTime?(Convert.ToDateTime(strDate));

    public string ConvertDateTimeToString(DateTime? date) => !date.HasValue ? (string) null : date.Value.ToShortDateString();

    public string GetCommaSeperatedString(List<KeyPair> keyPairs)
    {
      string str = string.Empty;
      if (keyPairs != null && keyPairs.Count > 0)
        str = string.Join(",", keyPairs.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>());
      return str;
    }

    public List<KeyPair> GetKeyPairFromCommaSeperatedString(string commaSeperatedIds)
    {
      List<KeyPair> keyPairList = new List<KeyPair>();
      if (!string.IsNullOrEmpty(commaSeperatedIds))
      {
        string str1 = commaSeperatedIds;
        char[] chArray = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray))
          keyPairList.Add(new KeyPair() { Key = str2 });
      }
      return keyPairList;
    }
  }
}
