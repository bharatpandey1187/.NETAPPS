﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PnlCompSeriesViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PnlCompSeriesViewModel
  {
    public long SeriesID { get; set; }

    public long AppTransactionID { get; set; }

    public string SeriesName { get; set; }

    public string SeriesCode { get; set; }

    public string JobNumber { get; set; }

    public bool IsSelected { get; set; }

    public int Version { get; set; }

    public Decimal ParAmount { get; set; }

    public DateTime? SettlementDate { get; set; }

    public PnlCompSeriesViewModel()
    {
    }

    public PnlCompSeriesViewModel(PnlCompetitiveSeries pnlSeries)
    {
      this.SeriesID = pnlSeries.SeriesID;
      this.AppTransactionID = pnlSeries.AppTransactionID;
      this.SeriesName = pnlSeries.SeriesName;
      this.SeriesCode = pnlSeries.SeriesCode;
      this.JobNumber = pnlSeries.JobNumber;
      this.IsSelected = pnlSeries.IsSelected;
      this.Version = pnlSeries.Version;
      this.ParAmount = pnlSeries.ParAmount;
      this.SettlementDate = pnlSeries.SettlementDate;
    }
  }
}
