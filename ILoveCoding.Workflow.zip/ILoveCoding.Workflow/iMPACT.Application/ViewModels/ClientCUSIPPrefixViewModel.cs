﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ClientCUSIPPrefixViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ClientCUSIPPrefixViewModel : ViewModelBase
  {
    public ClientCUSIPPrefixViewModel()
    {
    }

    public long ClientID { get; set; }

    public long ClientCUSIPPrefixID { get; set; }

    public ClientCUSIPPrefixViewModel(ClientCUSIPPrefix clientCUSIPPrefix)
    {
      this.ClientCUSIPPrefixID = clientCUSIPPrefix.ClientCUSIPPrefixID;
      this.CUSIPPrefix = clientCUSIPPrefix.CUSIPPrefix;
      this.ClientID = clientCUSIPPrefix.ClientID;
      this.IsBaseCUSIP = clientCUSIPPrefix.IsBaseCUSIP;
      this.ClientCUSIPPrefixID = clientCUSIPPrefix.ClientCUSIPPrefixID;
      this.SecurityType = clientCUSIPPrefix.SecurityType;
      this.SecurityTypeName = clientCUSIPPrefix.SecurityTypeName;
    }

    [RegexValidator("^[a-zA-Z0-9#@*]*$", MessageTemplate = "Please enter valid basic CUSIP.")]
    public string CUSIPPrefix { get; set; }

    public bool IsBaseCUSIP { get; set; }

    public long? SecurityType { get; set; }

    public string SecurityTypeName { get; set; }

    public ClientCUSIPPrefix GetClientCUSIPPrefix() => new ClientCUSIPPrefix()
    {
      ClientCUSIPPrefixID = this.ClientCUSIPPrefixID,
      ClientID = this.ClientID,
      CUSIPPrefix = this.CUSIPPrefix,
      IsBaseCUSIP = this.IsBaseCUSIP,
      SecurityType = this.SecurityType,
      SecurityTypeName = this.SecurityTypeName
    };
  }
}
