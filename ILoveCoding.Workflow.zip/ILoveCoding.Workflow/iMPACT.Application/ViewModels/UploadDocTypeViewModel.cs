﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.UploadDocTypeViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class UploadDocTypeViewModel : ViewModelBase
  {
    public UploadDocTypeViewModel()
    {
    }

    public UploadDocTypeViewModel(UploadDocType uploadDocType)
    {
      this.UploadDocTypeID = uploadDocType.EntityTypeDocTypeID;
      this.UploadCategoryID = uploadDocType.EntityTypeDocTypeCategoryID;
      this.Name = uploadDocType.DocTypeName;
      this.Cardinality = uploadDocType.Cardinality;
      this.IsActive = uploadDocType.IsActive;
      this.MoveToRetentionSite = uploadDocType.MoveToRetentionSite;
      this.IsEditEnable = true;
      this.IsDirty = false;
    }

    public UploadDocType GetUploadDocType() => new UploadDocType()
    {
      EntityTypeDocTypeID = this.UploadDocTypeID,
      EntityTypeDocTypeCategoryID = this.UploadCategoryID,
      DocTypeName = this.Name,
      Cardinality = this.Cardinality,
      IsActive = this.IsActive,
      MoveToRetentionSite = this.MoveToRetentionSite
    };

    public long UploadDocTypeID { get; set; }

    public long UploadCategoryID { get; set; }

    [Required(ErrorMessage = "Name cannot be blank.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    [StringLength(100, ErrorMessage = "Length of Name field should be less than or equal to 100 characters.")]
    public string Name { get; set; }

    public string Cardinality { get; set; }

    public bool IsActive { get; set; }

    public bool MoveToRetentionSite { get; set; }

    public bool IsEditEnable { get; set; }
  }
}
