﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.FinancialAdvisorViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class FinancialAdvisorViewModel
  {
    public FinancialAdvisorViewModel()
    {
    }

    public FinancialAdvisorViewModel(FinancialAdvisor financialAdvisor)
    {
      this.PartnerID = financialAdvisor.PartnerID;
      this.Name = financialAdvisor.Name;
      this.City = financialAdvisor.City;
      this.State = financialAdvisor.State;
      this.Zip = financialAdvisor.Zip;
      this.Phone = financialAdvisor.Phone;
      this.Fax = financialAdvisor.Fax;
      if (financialAdvisor.Contacts != null && financialAdvisor.Contacts.Count > 0)
        this.Contacts = financialAdvisor.Contacts.Select<PartnerContact, PartnerContactViewModel>((Func<PartnerContact, PartnerContactViewModel>) (x => new PartnerContactViewModel(x))).ToList<PartnerContactViewModel>();
      else
        this.Contacts = new List<PartnerContactViewModel>();
    }

    public FinancialAdvisor GetFinancialAdvisor() => new FinancialAdvisor()
    {
      PartnerID = this.PartnerID,
      Name = this.Name,
      City = this.City,
      State = this.State,
      Zip = this.Zip,
      Phone = this.Phone,
      Fax = this.Fax,
      Contacts = this.Contacts != null ? this.Contacts.Select<PartnerContactViewModel, PartnerContact>((Func<PartnerContactViewModel, PartnerContact>) (x => x.GetPartnerContactDetail())).ToList<PartnerContact>() : new List<PartnerContact>()
    };

    public long PartnerID { get; set; }

    public string Name { get; set; }

    public string City { get; set; }

    public string State { get; set; }

    public string Zip { get; set; }

    public string Phone { get; set; }

    public string Fax { get; set; }

    public string CityStateZip => !string.IsNullOrEmpty(this.City) || !string.IsNullOrEmpty(this.State) || !string.IsNullOrEmpty(this.Zip) ? string.Format("{0}, {1}, {2}", (object) this.City, (object) this.State, (object) this.Zip) : string.Empty;

    public List<PartnerContactViewModel> Contacts { get; set; }
  }
}
