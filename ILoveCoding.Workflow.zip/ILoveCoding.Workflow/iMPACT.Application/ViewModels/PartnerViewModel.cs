﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PartnerViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PartnerViewModel : ViewModelBase
  {
    public PartnerViewModel()
    {
      this.PartnerContacts = new List<PartnerDetailViewModel>();
      this.PartnerToPartnerTypes = new List<PartnerRoles>();
    }

    public PartnerViewModel(string strErrorMsg)
    {
      this.ErrorMessage = strErrorMsg;
      this.PartnerContacts = new List<PartnerDetailViewModel>();
      this.PartnerToPartnerTypes = new List<PartnerRoles>();
    }

    public PartnerViewModel(Partner partner)
    {
      this.PartnerID = partner.PartnerID;
      this.Name = partner.Name != null ? partner.Name.Trim() : "";
      this.Title = partner.Title;
      this.FirstName = partner.FirstName != null ? partner.FirstName.Trim() : "";
      this.LastName = partner.LastName != null ? partner.LastName.Trim() : "";
      this.Suffix = partner.Suffix;
      this.StreetAddress = partner.StreetAddress != null ? partner.StreetAddress.Trim() : "";
      this.City = partner.City != null ? partner.City.Trim() : "";
      this.State = partner.State;
      this.StateName = partner.StateName;
      this.Zip = partner.Zip;
      this.Phone = partner.Phone;
      this.Mobile = partner.Mobile;
      this.Fax = partner.Fax;
      this.IsActive = partner.IsActive;
      this.CreatedBy = partner.CreatedBy;
      this.CreatedOn = partner.CreatedOn;
      this.ModifiedBy = partner.ModifiedBy;
      this.ModifiedOn = partner.ModifiedOn;
      this.PartnerActiveAddress = partner.PartnerActiveAddress;
      this.PartnerContacts = partner.PartnerContacts == null || partner.PartnerContacts.ToList<PartnerContact>().Count <= 0 ? new List<PartnerDetailViewModel>() : partner.PartnerContacts.Select<PartnerContact, PartnerDetailViewModel>((Func<PartnerContact, PartnerDetailViewModel>) (x => new PartnerDetailViewModel(x))).ToList<PartnerDetailViewModel>();
      this.PartnerContactAddress = partner.PartnerContactAddress == null || partner.PartnerContactAddress.ToList<IrisSoftware.iMPACT.Data.PartnerContactAddress>().Count <= 0 ? new List<PartnerContactDetailViewModel>() : partner.PartnerContactAddress.Select<IrisSoftware.iMPACT.Data.PartnerContactAddress, PartnerContactDetailViewModel>((Func<IrisSoftware.iMPACT.Data.PartnerContactAddress, PartnerContactDetailViewModel>) (x => new PartnerContactDetailViewModel(x))).ToList<PartnerContactDetailViewModel>();
      this.PartnerToPartnerTypes = partner.PartnerToPartnerTypes;
    }

    public Partner GetPartnerDatail(PartnerViewModel partnerViewModel) => new Partner()
    {
      PartnerID = partnerViewModel.PartnerID,
      PartnerToPartnerTypes = partnerViewModel.PartnerToPartnerTypes,
      Name = partnerViewModel.Name != null ? partnerViewModel.Name.Trim() : "",
      Title = partnerViewModel.Title,
      FirstName = partnerViewModel.FirstName != null ? partnerViewModel.FirstName.Trim() : "",
      LastName = partnerViewModel.LastName != null ? partnerViewModel.LastName.Trim() : "",
      Suffix = partnerViewModel.Suffix,
      StreetAddress = partnerViewModel.StreetAddress != null ? partnerViewModel.StreetAddress.Trim() : "",
      City = partnerViewModel.City != null ? partnerViewModel.City.Trim() : "",
      State = partnerViewModel.State,
      StateName = partnerViewModel.StateName,
      Zip = partnerViewModel.Zip,
      Phone = partnerViewModel.Phone,
      Mobile = partnerViewModel.Mobile,
      Fax = partnerViewModel.Fax,
      IsActive = partnerViewModel.IsActive,
      CreatedBy = partnerViewModel.CreatedBy,
      CreatedOn = partnerViewModel.CreatedOn,
      ModifiedBy = partnerViewModel.ModifiedBy,
      ModifiedOn = partnerViewModel.ModifiedOn,
      PartnerActiveAddress = partnerViewModel.PartnerActiveAddress,
      PartnerContacts = partnerViewModel.PartnerContacts == null ? new List<PartnerContact>() : partnerViewModel.PartnerContacts.Select<PartnerDetailViewModel, PartnerContact>((Func<PartnerDetailViewModel, PartnerContact>) (x => x.GetPartnerContact())).ToList<PartnerContact>(),
      PartnerContactAddress = partnerViewModel.PartnerContactAddress == null ? new List<IrisSoftware.iMPACT.Data.PartnerContactAddress>() : partnerViewModel.PartnerContactAddress.Select<PartnerContactDetailViewModel, IrisSoftware.iMPACT.Data.PartnerContactAddress>((Func<PartnerContactDetailViewModel, IrisSoftware.iMPACT.Data.PartnerContactAddress>) (x => x.GetPartnerContactAddress())).ToList<IrisSoftware.iMPACT.Data.PartnerContactAddress>()
    };

    public long PartnerID { get; set; }

    public string PartnerType { get; set; }

    public List<PartnerRoles> PartnerToPartnerTypes { get; set; }

    [Required(ErrorMessage = "Partner name cannot be blank.")]
    [StringLength(80, ErrorMessage = "Length of Partner Name field should be less than or equal to 80 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string Name { get; set; }

    public string Title { get; set; }

    public string FirstName { get; set; }

    public string LastName { get; set; }

    public string Suffix { get; set; }

    [StringLength(500, ErrorMessage = "Length of Street address field should be less than or equal to 500 characters.")]
    public string StreetAddress { get; set; }

    [RegexValidator("^$|(^[A-Za-z'-. ]+$)", MessageTemplate = "Only alphabets, comma, dash, period, apostrophe and space are allowed.")]
    [StringLength(100, ErrorMessage = "Length of City field for a Client should be less than or equal to 100 characters.")]
    public string City { get; set; }

    public long? State { get; set; }

    public string StateName { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Length of Phone field should be equal to 12 characters.")]
    public string Phone { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Length of Mobile field should be equal to 12 characters.")]
    public string Mobile { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Fax number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Length of Fax field should be equal to 12 characters.")]
    public string Fax { get; set; }

    [RegexValidator("^$|((^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$))", MessageTemplate = "ZIP Code for USA should be XXXXX or XXXXX-XXXX.")]
    [StringLength(12, ErrorMessage = "Length of ZIP Code field should be less than or equal to 12 characters.")]
    public string Zip { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public bool IsViewOnly { get; set; }

    public bool IsAddPartner { get; set; }

    public bool IsEditPartner { get; set; }

    public bool IsAddContact { get; set; }

    public bool IsEditContact { get; set; }

    public List<PartnerDetailViewModel> PartnerContacts { get; set; }

    public List<PartnerContactDetailViewModel> PartnerContactAddress { get; set; }

    public List<IrisSoftware.iMPACT.Data.PartnerActiveAddress> PartnerActiveAddress { get; set; }

    public bool IsPartnerIdUsedInEntity { get; set; }

    public bool IsPartnerContactAdded { get; set; }

    public List<KeyPair> ContactTitle { get; set; }
  }
}
