﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueExternalPartnerViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueExternalPartnerViewModel : ViewModelBase
  {
    public IssueExternalPartnerViewModel()
    {
      this.SyndicateMemberType = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.WinningSyndicateMemberType = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.AdvisorAgentType = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.CounselType = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.OtherPartnerType = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.SyndicateMember = new List<ExternalPartner>();
      this.WinningSyndicateMember = new List<ExternalPartner>();
      this.AdvisorAgent = new List<ExternalPartner>();
      this.Counsel = new List<ExternalPartner>();
      this.OtherPartner = new List<ExternalPartner>();
      this.SyndicateMemberAutoComplete = new KeyPair();
      this.WinningSyndicateMemberAutoComplete = new KeyPair();
      this.AdvisorAgentAutoComplete = new KeyPair();
      this.CounselAutoComplete = new KeyPair();
      this.OtherPartnerAutoComplete = new KeyPair();
    }

    public IssueExternalPartnerViewModel(
      List<LookupItemMappings> lookupItems,
      List<ExternalPartner> issueExternalPartner)
    {
      this.SyndicateMemberType = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Syndicate Member Role"));
      this.WinningSyndicateMemberType = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Winning Syndicate Member Role"));
      this.AdvisorAgentType = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Advisory Agent Type"));
      this.CounselType = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Counsel Type"));
      this.OtherPartnerType = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Other Partner Type"));
      this.SyndicateMember = issueExternalPartner != null ? issueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Syndicate Member Role")).OrderByDescending<ExternalPartner, Decimal?>((Func<ExternalPartner, Decimal?>) (x => x.LiabilityPerc)).ThenBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>() : new List<ExternalPartner>();
      this.WinningSyndicateMember = issueExternalPartner != null ? issueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Winning Syndicate Member Role")).OrderByDescending<ExternalPartner, Decimal?>((Func<ExternalPartner, Decimal?>) (x => x.LiabilityPerc)).ThenBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>() : new List<ExternalPartner>();
      this.AdvisorAgent = issueExternalPartner != null ? issueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Advisory Agent Type")).OrderBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>() : new List<ExternalPartner>();
      this.Counsel = issueExternalPartner != null ? issueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Counsel Type")).OrderBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>() : new List<ExternalPartner>();
      this.OtherPartner = issueExternalPartner != null ? issueExternalPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Other Partner Type")).OrderBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>() : new List<ExternalPartner>();
    }

    public long AppTransactionID { get; set; }

    public long CopyAppTransactionID { get; set; }

    public bool ExternalPartnerIsViewOnly { get; set; }

    public List<ExternalPartner> SyndicateMember { get; set; }

    public List<ExternalPartner> WinningSyndicateMember { get; set; }

    public List<ExternalPartner> AdvisorAgent { get; set; }

    public List<ExternalPartner> Counsel { get; set; }

    public List<ExternalPartner> OtherPartner { get; set; }

    public IEnumerable<LookupItemMappings> SyndicateMemberType { get; set; }

    public IEnumerable<LookupItemMappings> WinningSyndicateMemberType { get; set; }

    public IEnumerable<LookupItemMappings> AdvisorAgentType { get; set; }

    public IEnumerable<LookupItemMappings> CounselType { get; set; }

    public IEnumerable<LookupItemMappings> OtherPartnerType { get; set; }

    public KeyPair SyndicateMemberAutoComplete { get; set; }

    public KeyPair WinningSyndicateMemberAutoComplete { get; set; }

    public KeyPair AdvisorAgentAutoComplete { get; set; }

    public KeyPair CounselAutoComplete { get; set; }

    public KeyPair OtherPartnerAutoComplete { get; set; }
  }
}
