﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PNLTemplateViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PNLTemplateViewModelContainer : ViewModelBase
  {
    public PNLTemplateViewModelContainer()
    {
      this.EntityTypes = new List<LookupItemViewModel>();
      this.PNLTemplateItems = new List<PNLTemplateViewModel>();
      this.PNLTemplateKeyItems = new List<PNLTemplateViewModel>();
    }

    public PNLTemplateViewModelContainer(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public bool IsViewOnly { get; set; }

    public List<LookupItemViewModel> EntityTypes { get; set; }

    public List<PNLTemplateViewModel> Section { get; set; }

    public List<PNLTemplateViewModel> Category { get; set; }

    public List<PNLTemplateViewModel> PNLTemplateItems { get; set; }

    public List<PNLTemplateViewModel> PNLTemplateKeyItems { get; set; }

    public List<PNLTemplateViewModel> PNLTemplateFilteredItems { get; set; }

    public List<Dictionary<string, object>> gridDataAsJSON { get; set; }
  }
}
