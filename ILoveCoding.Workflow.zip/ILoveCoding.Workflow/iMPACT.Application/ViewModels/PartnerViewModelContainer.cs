﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PartnerViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PartnerViewModelContainer : ViewModelBase
  {
    public PartnerViewModelContainer()
    {
      this.States = new List<LookupItemViewModel>();
      this.PartnerTypes = new List<LookupItemViewModel>();
    }

    public PartnerViewModelContainer(string strErrorMsg)
    {
      this.ErrorMessage = strErrorMsg;
      this.Partners = new List<PartnerViewModel>();
      this.States = new List<LookupItemViewModel>();
      this.PartnerTypes = new List<LookupItemViewModel>();
    }

    public List<PartnerViewModel> Partners { get; set; }

    public List<LookupItemViewModel> States { get; set; }

    public List<LookupItemViewModel> PartnerTypes { get; set; }

    public bool IsViewOnly { get; set; }

    public bool IsAddPartner { get; set; }

    public bool IsEditPartner { get; set; }
  }
}
