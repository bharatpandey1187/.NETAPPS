﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.OpportunityAuditTrailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class OpportunityAuditTrailViewModel
  {
    public long AppTransactionID { get; set; }

    public string DealType { get; set; }

    public string VersionNumber { get; set; }

    public string VersionInfo { get; set; }

    public DateTime CreateDate { get; set; }

    public string UserInfo { get; set; }

    public string WhenString => this.CreateDate > DateTime.MinValue ? this.CreateDate.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;

    public string OpportunityNbr { get; set; }

    public string OpportunityName { get; set; }

    public string OpportunityStatus { get; set; }

    public string ReviewStatus { get; set; }

    public string PowerID { get; set; }

    public string State { get; set; }

    public string County { get; set; }

    public string Issuer { get; set; }

    public string Borrower { get; set; }

    public string Guarantor { get; set; }

    public string OpportunityType { get; set; }

    public Decimal? ParAmount { get; set; }

    public Decimal? SDCCreditPerc { get; set; }

    public string Purpose { get; set; }

    public string Market { get; set; }

    public string TransactionType { get; set; }

    public string SecurityType { get; set; }

    public string MaterialType { get; set; }

    public string BankQualified { get; set; }

    public string AMTTaxable { get; set; }

    public string FedTaxable { get; set; }

    public string FedTaxName { get; set; }

    public string StateTaxable { get; set; }

    public string FAEngaged { get; set; }

    public string CMRelationship { get; set; }

    public string BankRelationship { get; set; }

    public string InsuranceProvider { get; set; }

    public string ApprovedDerivativeMarketer { get; set; }

    public string MAExemptions { get; set; }

    public string IRMAIndependent { get; set; }

    public string G17Details { get; set; }

    public string IsNewOpportunity { get; set; }

    public string HybridSolutionIndicator { get; set; }

    public string DualProposalProposed { get; set; }

    public string InformationalMERGRequired { get; set; }

    public string ExpectedFirmRole { get; set; }

    public string AssignedFirmRole { get; set; }

    public Decimal? ExpectedFirmLiabilityPerc { get; set; }

    public Decimal? AssignedFirmLiabilityPerc { get; set; }

    public string InvestmentBankingTeam { get; set; }

    public string SupervisoryPrincipal { get; set; }

    public string SyndicateMembers { get; set; }

    public string AdvisoryAgents { get; set; }

    public string Counsels { get; set; }

    public string BankRM { get; set; }

    public string MoodyRating { get; set; }

    public string SPRating { get; set; }

    public string KrollRating { get; set; }

    public string FitchRating { get; set; }

    public string CreateDateValue { get; set; }

    [AbsoluteDate]
    public DateTime? ResponseDueDateTime { get; set; }

    public string ResponseDueDateTimeZone { get; set; }

    public string ResponseDueDateTimeValue { get; set; }

    [AbsoluteDate]
    public DateTime? SubmissionDateTime { get; set; }

    public string SubmissionDateTimeZone { get; set; }

    public string SubmissionDateTimeValue { get; set; }

    public string SentTo3Firms { get; set; }

    [AbsoluteDate]
    public DateTime? SaleDate { get; set; }

    public string SaleDateValue { get; set; }

    [AbsoluteDate]
    public DateTime? CloseDate { get; set; }

    public string CloseDateValue { get; set; }

    [AbsoluteDate]
    public DateTime? FinancingDate { get; set; }

    public string FinancingDateValue { get; set; }

    [AbsoluteDate]
    public DateTime? SupervisoryPrincipalApprovalDate { get; set; }

    public string SupervisoryPrincipalApprovalDateValue { get; set; }

    [AbsoluteDate]
    public DateTime? SupervisoryPrincipalReviewDate { get; set; }

    public string SupervisoryPrincipalReviewDateValue { get; set; }

    [AbsoluteDate]
    public DateTime? ClientLastContactedDate { get; set; }

    public string ClientLastContactedDateValue { get; set; }

    [AbsoluteDate]
    public DateTime? DateHired { get; set; }

    public string DateHiredValue { get; set; }

    public Decimal? GrossSpread { get; set; }

    public Decimal? EstGrossRev { get; set; }

    public string RateType { get; set; }

    public Decimal? TakeDownValue { get; set; }

    public string RFPType { get; set; }

    public string ConflictOfInterest { get; set; }

    public string DerivativesStrategy { get; set; }

    [AbsoluteDate]
    public DateTime? ResponseDueDate { get; set; }

    public string ResponseDueDateTimezone { get; set; }

    public Decimal? RFPFees { get; set; }

    public string AdditionalInformationForCommitmentCommittee { get; set; }

    public string AdditionalRFPDetails { get; set; }

    public string jobnumber { get; set; }

    public string WinningSyndicate { get; set; }

    public List<InternalPartner> InternalPartners { get; set; }

    public List<ExternalPartner> ExternalPartners { get; set; }

    public List<ExternalPartner> SyndicateExternalPartners { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedPricingDate { get; set; }

    public string ExpectedPricingDateValue { get; set; }

    public Decimal? ProposedManagementFee { get; set; }

    public Decimal? ProposedUnderwriterExpenses { get; set; }

    public Decimal? FirmMgmtFee { get; set; }

    public string Notes { get; set; }
  }
}
