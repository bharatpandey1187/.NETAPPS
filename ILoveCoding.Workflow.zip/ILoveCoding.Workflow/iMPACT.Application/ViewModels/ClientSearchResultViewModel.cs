﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ClientSearchResultViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ClientSearchResultViewModel
  {
    public string Name { get; set; }

    public string Address { get; set; }

    public string City { get; set; }

    public string State { get; set; }

    public string Zip { get; set; }

    public string TaxID { get; set; }

    public string CUSIP { get; set; }

    public string IsActive { get; set; }

    public string MAExempt { get; set; }

    public string KFUJName { get; set; }

    public string ExternalClientID { get; set; }

    public string IRMAIndependent { get; set; }

    public string IRMAPerfected { get; set; }

    public object MAExemptionStartDate { get; set; }

    public object MAExemptionEndDate { get; set; }

    public string IRMAScope { get; set; }
  }
}
