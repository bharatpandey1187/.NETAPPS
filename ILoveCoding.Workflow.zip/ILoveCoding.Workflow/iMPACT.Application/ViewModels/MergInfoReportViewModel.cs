﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MergInfoReportViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MergInfoReportViewModel
  {
    public int AppTransactionID { get; set; }

    public string DealNumber { get; set; }

    public string Issuer { get; set; }

    public string MaterialType { get; set; }

    public string LeadBanker { get; set; }

    public string Banker2 { get; set; }

    public string IssuerState { get; set; }

    public string GeneralCategory { get; set; }

    public string OpportunityDescription { get; set; }

    public string ExistingRelationship { get; set; }

    public string RfpMaExamption { get; set; }

    public DateTime RfpMaExamptionDate { get; set; }

    public string UwMaExamption { get; set; }

    public DateTime UwMaExamptionDate { get; set; }

    public string IrmaMaExamption { get; set; }

    public DateTime IrmaMaExamptionDate { get; set; }

    public DateTime DateApprovedByPrincipal { get; set; }

    public string PrincipalApproverName { get; set; }

    public string ApprovedDerivativeMarketer { get; set; }

    public DateTime OpportunityCreatedDate { get; set; }

    public DateTime RFPCreatedDate { get; set; }
  }
}
