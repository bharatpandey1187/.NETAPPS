﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.OpportunityViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class OpportunityViewModel : ViewModelBase
  {
    public long AppTransactionID { get; set; }

    public List<long> OpportunityStatus { get; set; }

    public string OpportunityStatusValue { get; set; }

    public string OpportunityReviewStatus { get; set; }

    public string OpportunityNbr { get; set; }

    public DateTime OpportunityDate { get; set; }

    public string OpportunityDateValue => this.OpportunityDate > DateTime.MinValue ? this.OpportunityDate.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;

    public string OpportunityPowerID { get; set; }

    [Required(ErrorMessage = "Opportunity Description cannot be blank.")]
    public string OpportunityName { get; set; }

    public IssuerState Issuer { get; set; }

    public long? IssuerID { get; set; }

    public string IssuerName { get; set; }

    public KeyPair Borrower { get; set; }

    public long? BorrowerID { get; set; }

    public string BorrowerName { get; set; }

    public KeyPair Guarantor { get; set; }

    public long? GuarantorID { get; set; }

    public string GuarantorName { get; set; }

    public KeyPair CepProvider { get; set; }

    public long? CepProviderID { get; set; }

    public string CepProviderName { get; set; }

    public List<KeyPair> OpportunityTypes { get; set; }

    public long? OpportunityType { get; set; }

    public List<KeyPair> States { get; set; }

    public long? State { get; set; }

    public string County { get; set; }

    public bool? IsNewOpportunity { get; set; }

    public List<KeyPair> MaterialTypes { get; set; }

    public long? MaterialType { get; set; }

    public bool? HybridSolutionIndicator { get; set; }

    public bool? DualProposalProposed { get; set; }

    public bool? InformationalMERGRequired { get; set; }

    public List<KeyPair> ApprovedDerivativeMarketers { get; set; }

    public long? ApprovedDerivativeMarketer { get; set; }

    public List<KeyPair> MAExemptions { get; set; }

    public List<MAExemptionDetail> MAExemptionDetails { get; set; }

    public List<PropertyDescriptor> MiscFieldsDetail { get; set; }

    public List<PropertySetValue> MiscFieldsValueDetail { get; set; }

    public Decimal? ParAmount { get; set; }

    public List<KeyPair> Roles { get; set; }

    public long? FirmRole { get; set; }

    public Decimal? FirmLiabilityPerc { get; set; }

    public Decimal? FirmMgmtFee { get; set; }

    public long? AssignedFirmRole { get; set; }

    public Decimal? AssignedFirmLiability { get; set; }

    public List<KeyPair> Purposes { get; set; }

    public long? Purpose { get; set; }

    public List<KeyPair> TransactionTypes { get; set; }

    public long? TransactionType { get; set; }

    public List<KeyPair> UseOfProceeds { get; set; }

    public long? UseOfProceed { get; set; }

    public List<KeyPair> SecurityTypes { get; set; }

    public long? SecurityType { get; set; }

    public List<KeyPair> InsuranceProviders { get; set; }

    public long? InsuranceProvider { get; set; }

    public long? FedTax { get; set; }

    public string StateTax { get; set; }

    public string AMT { get; set; }

    public bool? BankQualified { get; set; }

    public bool? FAEngaged { get; set; }

    public bool? CMRelationship { get; set; }

    public bool? BankRelationship { get; set; }

    public bool? ConflictOfInterest { get; set; }

    public bool? DerivativesStrategy { get; set; }

    public List<KeyPair> Markets { get; set; }

    public long? Market { get; set; }

    public string MarketTxt { get; set; }

    public List<KeyPair> RFPTypes { get; set; }

    public long? RFPType { get; set; }

    public List<KeyPair> RateTypes { get; set; }

    public long? RateType { get; set; }

    public Decimal? GrossSpread { get; set; }

    public Decimal? EstGrossRev { get; set; }

    [AbsoluteDate]
    public DateTime? DateHired { get; set; }

    [AbsoluteDate]
    public DateTime? SaleDate { get; set; }

    [AbsoluteDate]
    public DateTime? FinancingDate { get; set; }

    [AbsoluteDate]
    public DateTime? CloseDate { get; set; }

    [AbsoluteDate]
    public DateTime? G17SentDate { get; set; }

    [AbsoluteDate]
    public DateTime? G17AckDate { get; set; }

    [AbsoluteDate]
    public DateTime? SupervisoryPrincipalReviewDate { get; set; }

    [AbsoluteDate]
    public DateTime? SupervisoryPrincipalApprovalDate { get; set; }

    public bool? SentTo3Firms { get; set; }

    [AbsoluteDate]
    public DateTime? ResponseDueDateTime { get; set; }

    public string ResponseDueDateTimezone { get; set; }

    public string SubmissionDateTimezone { get; set; }

    [CurrentDate(ErrorMessage = "Client Last Contacted Date cannot be in future.")]
    [AbsoluteDate]
    public DateTime? ClientLastContactedDate { get; set; }

    public string AdditionalInformationForCommitmentCommittee { get; set; }

    public string AdditionalRFPDetails { get; set; }

    public List<KeyPair> MoodyRatings { get; set; }

    public long? MoodyRatingLT { get; set; }

    public List<KeyPair> SnPRatings { get; set; }

    public long? SPRatingLT { get; set; }

    public List<KeyPair> FitchRatings { get; set; }

    public long? FitchRatingLT { get; set; }

    public long? KrollRatingLT { get; set; }

    public List<KeyPair> KrollRatings { get; set; }

    public string Notes { get; set; }

    public string ReviewComments { get; set; }

    public DateTime CreatedOn { get; set; }

    public string CreatedBy { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public string DocumentLibraryURL { get; set; }

    public int Version { get; set; }

    public bool IsFreeze { get; set; }

    public string LastModifiedBy { get; set; }

    public List<IrisSoftware.iMPACT.Data.Notes> NotesCollection { get; set; }

    public List<IrisSoftware.iMPACT.Data.ReviewComments> ReviewCommentsCollection { get; set; }

    public List<InternalPartner> Bankers { get; set; }

    public List<InternalPartner> Analysts { get; set; }

    public List<InternalPartnerBankRM> BankRMs { get; set; }

    public List<InternalPartner> SupervisoryPrincipals { get; set; }

    public List<KeyPair> AdvisorAgentType { get; set; }

    public List<ExternalPartner> Advisors { get; set; }

    public List<KeyPair> CounselType { get; set; }

    public List<ExternalPartner> Counsels { get; set; }

    public List<AppTransactionClientContact> AppTransactionClientContacts { get; set; }

    public OpportunityContactDetailViewModel OpportunityContact { get; set; }

    public List<AuditTrailViewModel> AuditTrails { get; set; }

    public List<EmailTemplateViewModel> EmailTemplates { get; set; }

    public string[] Actions { get; set; }

    public bool IsViewOnly { get; set; }

    public bool ViewOpportunityInternalPartners { get; set; }

    public bool IsOpportunityInternalPartnersViewOnly { get; set; }

    public bool ViewOpportunityExternalPartners { get; set; }

    public bool IsOpportunityExternalPartnersViewOnly { get; set; }

    public bool ViewOpportunityDocuments { get; set; }

    public bool CanUploadOpportunityDocuments { get; set; }

    public bool IsOpportunityDocumentsViewOnly { get; set; }

    public bool ViewOpportunityContacts { get; set; }

    public bool ViewOpportunityReview { get; set; }

    public bool IsOpportunityReviewViewOnly { get; set; }

    public bool ViewOpportunityAuditTrail { get; set; }

    public bool ViewOpportunityMisc { get; set; }

    public bool DisableInitiateIssue { get; set; }

    public bool CanInitiateIssue { get; set; }

    public bool DisableOpportunityDetailEmail { get; set; }

    public bool ViewCopyOpportunity { get; set; }

    public bool IsOpportunityMiscViewOnly { get; set; }

    public bool IsAppTransactionClientContactEditable { get; set; }

    public List<AppTransactionStateTransition> WorkflowStateTransitions { get; set; }

    public bool? IsMERGInformed { get; set; }

    [AbsoluteDate]
    public DateTime? SubmittedToMERGDate { get; set; }

    public bool? HasIssueInitiated { get; set; }

    public bool? HasRFPInitiated { get; set; }

    public bool? HasDualProposalRequestedOrProposed { get; set; }

    public long? CreatorEmployeeId { get; set; }

    public List<KeyPair> GeneralCategorySpecifics { get; set; }

    public long? GeneralCategorySpecific { get; set; }

    public Decimal? SDCCreditPerc { get; set; }

    [AbsoluteDate]
    public DateTime? CommitmentCommitteeReviewDate { get; set; }

    [AbsoluteDate]
    public DateTime? CommitmentCommitteeApprovedDate { get; set; }

    [AbsoluteDate]
    public DateTime? ManagementReviewDate { get; set; }

    [AbsoluteDate]
    public DateTime? ManagementApprovedDate { get; set; }

    public List<KeyPair> DealTypes { get; set; }

    public long? DealType { get; set; }

    public List<KeyPair> G17Types { get; set; }

    public List<G17Detail> G17Details { get; set; }

    public List<KeyPair> GeneralCategories { get; set; }

    public List<KeyPair> SeriesFedTax { get; set; }

    public long? GeneralCategory { get; set; }

    [AbsoluteDate]
    public DateTime? SubmissionDateAndTime { get; set; }

    public Decimal? RFPFees { get; set; }

    public Decimal? ProposedManagementFee { get; set; }

    public Decimal? ProposedUnderwriterExpenses { get; set; }

    public bool? IsCommitmentCommitteeApproved { get; set; }

    public bool? IsManagementApproved { get; set; }

    public List<KeyPair> SyndicateMemberType { get; set; }

    public List<KeyPair> WinningSyndicateMemberType { get; set; }

    public List<ExternalPartner> SyndicateMembers { get; set; }

    public List<ExternalPartner> WinningSyndicateMembers { get; set; }

    public Decimal? TakeDownValue { get; set; }

    public string JobNumber { get; set; }

    public bool? HasRFPFeeChangedAfterManagementApprovalProcess { get; set; }

    public bool? IsManagementApprovedStateVisited { get; set; }

    public Decimal? OldRFPFees { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedPricingDate { get; set; }

    public string DealTypeName { get; set; }

    public string RFPTypeName { get; set; }

    public string OpportunityTypeName { get; set; }

    public string ExpectedFirmRoleValue { get; set; }

    public string Ratings { get; set; }

    public string FirmRoleValue { get; set; }

    public List<MsBankingGroupOpportunity> MSBankingGroupOpportunity { get; set; }

    public OpportunityViewModel()
    {
      this.OpportunityTypes = new List<KeyPair>();
      this.Issuer = new IssuerState();
      this.Borrower = new KeyPair();
      this.Guarantor = new KeyPair();
      this.States = new List<KeyPair>();
      this.MaterialTypes = new List<KeyPair>();
      this.ApprovedDerivativeMarketers = new List<KeyPair>();
      this.MAExemptions = new List<KeyPair>();
      this.MAExemptionDetails = new List<MAExemptionDetail>();
      this.Roles = new List<KeyPair>();
      this.Purposes = new List<KeyPair>();
      this.TransactionTypes = new List<KeyPair>();
      this.SecurityTypes = new List<KeyPair>();
      this.InsuranceProviders = new List<KeyPair>();
      this.Markets = new List<KeyPair>();
      this.RFPTypes = new List<KeyPair>();
      this.RateTypes = new List<KeyPair>();
      this.MoodyRatings = new List<KeyPair>();
      this.SnPRatings = new List<KeyPair>();
      this.FitchRatings = new List<KeyPair>();
      this.KrollRatings = new List<KeyPair>();
      this.NotesCollection = new List<IrisSoftware.iMPACT.Data.Notes>();
      this.ReviewCommentsCollection = new List<IrisSoftware.iMPACT.Data.ReviewComments>();
      this.Bankers = new List<InternalPartner>();
      this.Analysts = new List<InternalPartner>();
      this.SupervisoryPrincipals = new List<InternalPartner>();
      this.BankRMs = new List<InternalPartnerBankRM>();
      this.MiscFieldsDetail = new List<PropertyDescriptor>();
      this.Advisors = new List<ExternalPartner>();
      this.Counsels = new List<ExternalPartner>();
      this.SyndicateMembers = new List<ExternalPartner>();
      this.WinningSyndicateMembers = new List<ExternalPartner>();
      this.OpportunityContact = new OpportunityContactDetailViewModel();
      this.AuditTrails = new List<AuditTrailViewModel>();
      this.GeneralCategorySpecifics = new List<KeyPair>();
      this.DealTypes = new List<KeyPair>();
      this.G17Types = new List<KeyPair>();
      this.G17Details = new List<G17Detail>();
      this.GeneralCategories = new List<KeyPair>();
      this.UseOfProceeds = new List<KeyPair>();
    }

    public OpportunityViewModel(Opportunity oppty)
    {
      this.AppTransactionID = oppty.OpportunityDetail.AppTransactionID;
      this.OpportunityStatus = oppty.OpportunityDetail.OpportunityStatus;
      this.OpportunityStatusValue = oppty.OpportunityDetail.OpportunityStatusValue;
      this.OpportunityReviewStatus = oppty.OpportunityDetail.OpportunityReviewStatus;
      this.OpportunityNbr = oppty.OpportunityDetail.OpportunityNbr;
      this.OpportunityDate = oppty.OpportunityDetail.CreatedOn;
      this.OpportunityPowerID = oppty.OpportunityDetail.OpportunityPowerID;
      this.OpportunityName = oppty.OpportunityDetail.OpportunityName;
      this.IssuerID = oppty.OpportunityDetail.IssuerID;
      this.IssuerName = oppty.OpportunityDetail.IssuerName;
      if (oppty.OpportunityDetail.IssuerID.HasValue)
        this.Issuer = new IssuerState(oppty.OpportunityDetail.IssuerID.Value, oppty.OpportunityDetail.IssuerName, oppty.OpportunityDetail.State.HasValue ? oppty.OpportunityDetail.State.Value.ToString() : (string) null);
      this.BorrowerID = oppty.OpportunityDetail.BorrowerID;
      this.BorrowerName = oppty.OpportunityDetail.BorrowerName;
      if (oppty.OpportunityDetail.BorrowerID.HasValue)
        this.Borrower = new KeyPair(oppty.OpportunityDetail.BorrowerID.Value, oppty.OpportunityDetail.BorrowerName);
      this.GuarantorID = oppty.OpportunityDetail.GuarantorID;
      this.GuarantorName = oppty.OpportunityDetail.GuarantorName;
      if (oppty.OpportunityDetail.GuarantorID.HasValue)
        this.Guarantor = new KeyPair(oppty.OpportunityDetail.GuarantorID.Value, oppty.OpportunityDetail.GuarantorName);
      this.CepProviderID = oppty.OpportunityDetail.CepProviderID;
      this.CepProviderName = oppty.OpportunityDetail.CepProviderName;
      if (oppty.OpportunityDetail.CepProviderID.HasValue)
        this.CepProvider = new KeyPair(oppty.OpportunityDetail.CepProviderID.Value, oppty.OpportunityDetail.CepProviderName);
      this.OpportunityType = oppty.OpportunityDetail.OpportunityType;
      this.State = oppty.OpportunityDetail.State;
      this.County = oppty.OpportunityDetail.County;
      this.IsNewOpportunity = oppty.OpportunityDetail.IsNewOpportunity;
      this.MaterialType = oppty.OpportunityDetail.MaterialType;
      this.HybridSolutionIndicator = oppty.OpportunityDetail.HybridSolutionIndicator;
      this.DualProposalProposed = oppty.OpportunityDetail.DualProposalProposed;
      this.InformationalMERGRequired = oppty.OpportunityDetail.InformationalMERGRequired;
      this.ApprovedDerivativeMarketer = oppty.OpportunityDetail.ApprovedDerivativeMarketer;
      this.MAExemptionDetails = oppty.OpportunityDetail.MAExemptionDetails;
      this.MiscFieldsDetail = oppty.MiscFieldsDetail != null ? oppty.MiscFieldsDetail.ToList<PropertyDescriptor>() : new List<PropertyDescriptor>();
      this.ParAmount = oppty.OpportunityDetail.ParAmount;
      this.FirmRole = oppty.OpportunityDetail.FirmRole;
      this.FirmLiabilityPerc = oppty.OpportunityDetail.FirmLiabilityPerc;
      this.AssignedFirmRole = oppty.OpportunityDetail.AssignedFirmRole;
      this.AssignedFirmLiability = oppty.OpportunityDetail.AssignedFirmLiability;
      this.Purpose = oppty.OpportunityDetail.Purpose;
      this.TransactionType = oppty.OpportunityDetail.TransactionType;
      this.UseOfProceed = oppty.OpportunityDetail.TransactionType;
      this.SecurityType = oppty.OpportunityDetail.SecurityType;
      this.InsuranceProvider = oppty.OpportunityDetail.InsuranceProvider;
      this.FedTax = oppty.OpportunityDetail.FedTax;
      this.StateTax = oppty.OpportunityDetail.StateTaxable;
      this.AMT = oppty.OpportunityDetail.AMTTaxable;
      this.BankQualified = oppty.OpportunityDetail.BankQualified;
      this.FAEngaged = oppty.OpportunityDetail.FAEngaged;
      this.CMRelationship = oppty.OpportunityDetail.CMRelationship;
      this.BankRelationship = oppty.OpportunityDetail.BankRelationship;
      this.ConflictOfInterest = oppty.OpportunityDetail.ConflictOfInterest;
      this.DerivativesStrategy = oppty.OpportunityDetail.DerivativesStrategy;
      this.Market = oppty.OpportunityDetail.Market;
      this.MarketTxt = oppty.OpportunityDetail.MarketTxt;
      this.RFPType = oppty.OpportunityDetail.RFPType;
      this.RateType = oppty.OpportunityDetail.RateType;
      this.GrossSpread = oppty.OpportunityDetail.GrossSpread;
      this.EstGrossRev = oppty.OpportunityDetail.EstGrossRev;
      this.DateHired = oppty.OpportunityDetail.DateHired;
      this.SaleDate = oppty.OpportunityDetail.SaleDate;
      this.FinancingDate = oppty.OpportunityDetail.FinancingDate;
      this.CloseDate = oppty.OpportunityDetail.CloseDate;
      this.G17SentDate = oppty.OpportunityDetail.G17SentDate;
      this.G17AckDate = oppty.OpportunityDetail.G17AckDate;
      this.SupervisoryPrincipalReviewDate = oppty.OpportunityDetail.SupervisoryPrincipalReviewDate;
      this.SupervisoryPrincipalApprovalDate = oppty.OpportunityDetail.SupervisoryPrincipalApprovalDate;
      this.ClientLastContactedDate = oppty.OpportunityDetail.ClientLastContactedDate;
      this.AdditionalInformationForCommitmentCommittee = oppty.OpportunityDetail.AdditionalInformationForCommitmentCommittee;
      this.AdditionalRFPDetails = oppty.OpportunityDetail.AdditionalRFPDetails;
      this.SentTo3Firms = oppty.OpportunityDetail.SentTo3Firms;
      this.ResponseDueDateTime = oppty.OpportunityDetail.ResponseDueDateTime;
      this.ResponseDueDateTimezone = oppty.OpportunityDetail.ResponseDueDateTimezone;
      this.SubmissionDateTimezone = oppty.OpportunityDetail.SubmissionDateTimezone;
      this.MoodyRatingLT = oppty.OpportunityDetail.MoodyRatingLT;
      this.SPRatingLT = oppty.OpportunityDetail.SPRatingLT;
      this.FitchRatingLT = oppty.OpportunityDetail.FitchRatingLT;
      this.KrollRatingLT = oppty.OpportunityDetail.KrollRatingLT;
      this.Notes = oppty.OpportunityDetail.Notes;
      this.ReviewComments = oppty.OpportunityDetail.ReviewComments;
      this.CreatedBy = oppty.OpportunityDetail.CreatedBy;
      this.CreatedOn = oppty.OpportunityDetail.CreatedOn;
      this.ModifiedBy = oppty.OpportunityDetail.ModifiedBy;
      this.ModifiedOn = oppty.OpportunityDetail.ModifiedOn;
      this.DocumentLibraryURL = oppty.OpportunityDetail.DocumentLibraryURL;
      this.Version = oppty.OpportunityDetail.Version;
      this.IsFreeze = oppty.OpportunityDetail.IsFreeze;
      this.LastModifiedBy = oppty.OpportunityDetail.LastModifiedBy;
      this.NotesCollection = oppty.OpportunityDetail.NotesCollection;
      this.ReviewCommentsCollection = oppty.ReviewCommentsCollection;
      this.AppTransactionClientContacts = oppty.AppTransactionClientContacts;
      this.WorkflowStateTransitions = oppty.WorkflowStateTransitions;
      this.JobNumber = oppty.OpportunityDetail.JobNumber;
      if (oppty.InternalPartners != null && oppty.InternalPartners.Count > 0)
      {
        this.Bankers = oppty.InternalPartners == null ? new List<InternalPartner>() : oppty.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
        {
          long? roleTypeId = x.RoleTypeId;
          long int64 = Convert.ToInt64((object) Opportunity.RoleTypes.InvestmentBankingTeam);
          return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
        })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
        this.Analysts = oppty.InternalPartners == null ? new List<InternalPartner>() : oppty.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
        {
          long? roleTypeId = x.RoleTypeId;
          long int64 = Convert.ToInt64((object) Opportunity.RoleTypes.AnalystProfessionalSupport);
          return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
        })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
        this.BankRMs = oppty.InternalPartnerBankRMs == null ? new List<InternalPartnerBankRM>() : oppty.InternalPartnerBankRMs.OrderBy<InternalPartnerBankRM, string>((Func<InternalPartnerBankRM, string>) (x => x.Name)).ToList<InternalPartnerBankRM>();
        this.SupervisoryPrincipals = oppty.InternalPartners == null ? new List<InternalPartner>() : oppty.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
        {
          long? roleTypeId = x.RoleTypeId;
          long int64 = Convert.ToInt64((object) Opportunity.RoleTypes.SupervisoryPrincipal);
          return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
        })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      }
      if (oppty.ExternalPartners != null && oppty.ExternalPartners.Count > 0)
      {
        this.Advisors = oppty.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Advisory Agent Type")).OrderBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>();
        this.Counsels = oppty.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Counsel Type")).OrderBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>();
        this.SyndicateMembers = oppty.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Syndicate Member Role")).OrderByDescending<ExternalPartner, Decimal?>((Func<ExternalPartner, Decimal?>) (x => x.LiabilityPerc)).ThenBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>();
        this.WinningSyndicateMembers = oppty.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => x.LookupKey == "Winning Syndicate Member Role")).OrderByDescending<ExternalPartner, Decimal?>((Func<ExternalPartner, Decimal?>) (x => x.LiabilityPerc)).ThenBy<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToList<ExternalPartner>();
      }
      this.OpportunityContact = new OpportunityContactDetailViewModel(oppty);
      this.AuditTrails = new List<AuditTrailViewModel>();
      this.IsMERGInformed = oppty.OpportunityDetail.IsMERGInformed;
      this.SubmittedToMERGDate = oppty.OpportunityDetail.SubmittedToMERGDate;
      this.HasIssueInitiated = oppty.OpportunityDetail.HasIssueInitiated;
      this.HasRFPInitiated = oppty.OpportunityDetail.HasRFPInitiated;
      this.CreatorEmployeeId = oppty.OpportunityDetail.CreatorEmployeeId;
      this.GeneralCategorySpecific = oppty.OpportunityDetail.GeneralCategorySpecific;
      this.SDCCreditPerc = oppty.OpportunityDetail.SDCCreditPerc;
      this.CommitmentCommitteeReviewDate = oppty.OpportunityDetail.CommitmentCommitteeReviewDate;
      this.CommitmentCommitteeApprovedDate = oppty.OpportunityDetail.CommitmentCommitteeApprovedDate;
      this.ManagementReviewDate = oppty.OpportunityDetail.ManagementReviewDate;
      this.ManagementApprovedDate = oppty.OpportunityDetail.ManagementApprovedDate;
      this.DealType = oppty.OpportunityDetail.DealType;
      this.G17Details = oppty.OpportunityDetail.G17Details;
      this.GeneralCategory = oppty.OpportunityDetail.GeneralCategory;
      this.SubmissionDateAndTime = oppty.OpportunityDetail.SubmissionDateAndTime;
      this.RFPFees = oppty.OpportunityDetail.RFPFees;
      this.IsManagementApproved = oppty.OpportunityDetail.IsManagementApproved;
      this.IsCommitmentCommitteeApproved = oppty.OpportunityDetail.IsCommitmentCommitteeApproved;
      this.TakeDownValue = oppty.OpportunityDetail.TakeDownValue;
      this.HasRFPFeeChangedAfterManagementApprovalProcess = oppty.OpportunityDetail.HasRFPFeeChangedAfterManagementApprovalProcess;
      this.OldRFPFees = oppty.OpportunityDetail.OldRFPFees;
      this.IsManagementApprovedStateVisited = oppty.OpportunityDetail.IsManagementApprovedStateVisited;
      this.ExpectedPricingDate = oppty.OpportunityDetail.ExpectedPricingDate;
      this.FirmMgmtFee = oppty.OpportunityDetail.FirmMgmtFee;
      this.ProposedManagementFee = oppty.OpportunityDetail.ProposedManagementFee;
      this.ProposedUnderwriterExpenses = oppty.OpportunityDetail.ProposedUnderwriterExpenses;
      this.DealTypeName = oppty.OpportunityDetail.DealTypeName;
      this.RFPTypeName = oppty.OpportunityDetail.RFPTypeName;
      this.OpportunityTypeName = oppty.OpportunityDetail.OpportunityTypeName;
      this.ExpectedFirmRoleValue = oppty.OpportunityDetail.ExpectedFirmRoleValue;
      this.FirmRoleValue = oppty.OpportunityDetail.FirmRoleValue;
      this.Ratings = oppty.OpportunityDetail.Ratings;
      this.MSBankingGroupOpportunity = oppty.OpportunityDetail.MSBankingGroupOpportunity != null ? oppty.OpportunityDetail.MSBankingGroupOpportunity.ToList<MsBankingGroupOpportunity>() : new List<MsBankingGroupOpportunity>();
    }

    public Opportunity GetOpportunity()
    {
      Opportunity opportunity = new Opportunity()
      {
        OpportunityDetail = new OpportunityDetail()
      };
      opportunity.OpportunityDetail.AppTransactionID = this.AppTransactionID;
      opportunity.OpportunityDetail.OpportunityStatus = this.OpportunityStatus;
      opportunity.OpportunityDetail.OpportunityNbr = this.OpportunityNbr;
      opportunity.OpportunityDetail.OpportunityPowerID = this.OpportunityPowerID != null ? this.OpportunityPowerID.Trim() : this.OpportunityPowerID;
      opportunity.OpportunityDetail.OpportunityName = this.OpportunityName != null ? this.OpportunityName.Trim() : this.OpportunityName;
      opportunity.OpportunityDetail.JobNumber = this.JobNumber.IsNullOrWhiteSpace() ? (string) null : this.JobNumber.Trim();
      if (this.Issuer != null)
      {
        opportunity.OpportunityDetail.IssuerID = new long?(Convert.ToInt64(this.Issuer.Key));
        opportunity.OpportunityDetail.IssuerName = this.Issuer.Value;
      }
      else
      {
        opportunity.OpportunityDetail.IssuerID = new long?();
        opportunity.OpportunityDetail.IssuerName = string.Empty;
      }
      if (this.Borrower != null)
      {
        opportunity.OpportunityDetail.BorrowerID = new long?(Convert.ToInt64(this.Borrower.Key));
        opportunity.OpportunityDetail.BorrowerName = this.Borrower.Value;
      }
      else
      {
        opportunity.OpportunityDetail.BorrowerID = new long?();
        opportunity.OpportunityDetail.BorrowerName = string.Empty;
      }
      if (this.Guarantor != null)
      {
        opportunity.OpportunityDetail.GuarantorID = new long?(Convert.ToInt64(this.Guarantor.Key));
        opportunity.OpportunityDetail.GuarantorName = this.Guarantor.Value;
      }
      else
      {
        opportunity.OpportunityDetail.GuarantorID = new long?();
        opportunity.OpportunityDetail.GuarantorName = string.Empty;
      }
      if (this.CepProvider != null)
      {
        opportunity.OpportunityDetail.CepProviderID = new long?(Convert.ToInt64(this.CepProvider.Key));
        opportunity.OpportunityDetail.CepProviderName = this.CepProvider.Value;
      }
      else
      {
        opportunity.OpportunityDetail.CepProviderID = new long?();
        opportunity.OpportunityDetail.CepProviderName = string.Empty;
      }
      opportunity.OpportunityDetail.OpportunityType = this.OpportunityType;
      opportunity.OpportunityDetail.State = this.State;
      opportunity.OpportunityDetail.County = this.County != null ? this.County.Trim() : this.County;
      opportunity.OpportunityDetail.IsNewOpportunity = this.IsNewOpportunity;
      opportunity.OpportunityDetail.MaterialType = this.MaterialType;
      opportunity.OpportunityDetail.HybridSolutionIndicator = this.HybridSolutionIndicator;
      opportunity.OpportunityDetail.DualProposalProposed = this.DualProposalProposed;
      opportunity.OpportunityDetail.InformationalMERGRequired = this.InformationalMERGRequired;
      opportunity.OpportunityDetail.ApprovedDerivativeMarketer = this.ApprovedDerivativeMarketer;
      opportunity.OpportunityDetail.MAExemptionDetails = this.MAExemptionDetails;
      opportunity.OpportunityDetail.ParAmount = this.ParAmount;
      opportunity.OpportunityDetail.FirmRole = this.FirmRole;
      opportunity.OpportunityDetail.FirmLiabilityPerc = this.FirmLiabilityPerc;
      opportunity.OpportunityDetail.AssignedFirmRole = this.AssignedFirmRole;
      opportunity.OpportunityDetail.AssignedFirmLiability = this.AssignedFirmLiability;
      opportunity.OpportunityDetail.Purpose = this.Purpose;
      opportunity.OpportunityDetail.TransactionType = this.UseOfProceed;
      opportunity.OpportunityDetail.SecurityType = this.SecurityType;
      opportunity.OpportunityDetail.InsuranceProvider = this.InsuranceProvider;
      opportunity.OpportunityDetail.FedTax = this.FedTax;
      opportunity.OpportunityDetail.StateTaxable = this.StateTax;
      opportunity.OpportunityDetail.AMTTaxable = this.AMT;
      opportunity.OpportunityDetail.BankQualified = this.BankQualified;
      opportunity.OpportunityDetail.FAEngaged = this.FAEngaged;
      opportunity.OpportunityDetail.CMRelationship = this.CMRelationship;
      opportunity.OpportunityDetail.BankRelationship = this.BankRelationship;
      opportunity.OpportunityDetail.ConflictOfInterest = this.ConflictOfInterest;
      opportunity.OpportunityDetail.DerivativesStrategy = this.DerivativesStrategy;
      opportunity.OpportunityDetail.Market = this.Market;
      opportunity.OpportunityDetail.MarketTxt = this.MarketTxt;
      opportunity.OpportunityDetail.RFPType = this.RFPType;
      opportunity.OpportunityDetail.RateType = this.RateType;
      opportunity.OpportunityDetail.GrossSpread = this.GrossSpread;
      opportunity.OpportunityDetail.EstGrossRev = this.EstGrossRev;
      opportunity.OpportunityDetail.DateHired = this.DateHired;
      opportunity.OpportunityDetail.SaleDate = this.SaleDate;
      opportunity.OpportunityDetail.FinancingDate = this.FinancingDate;
      opportunity.OpportunityDetail.CloseDate = this.CloseDate;
      opportunity.OpportunityDetail.G17SentDate = this.G17SentDate;
      opportunity.OpportunityDetail.G17AckDate = this.G17AckDate;
      opportunity.OpportunityDetail.SupervisoryPrincipalReviewDate = this.SupervisoryPrincipalReviewDate;
      opportunity.OpportunityDetail.SupervisoryPrincipalApprovalDate = this.SupervisoryPrincipalApprovalDate;
      opportunity.OpportunityDetail.ClientLastContactedDate = this.ClientLastContactedDate;
      opportunity.OpportunityDetail.AdditionalInformationForCommitmentCommittee = this.AdditionalInformationForCommitmentCommittee;
      opportunity.OpportunityDetail.SentTo3Firms = this.SentTo3Firms;
      opportunity.OpportunityDetail.ResponseDueDateTime = this.ResponseDueDateTime;
      opportunity.OpportunityDetail.ResponseDueDateTimezone = !this.ResponseDueDateTime.HasValue ? (string) null : this.ResponseDueDateTimezone;
      opportunity.OpportunityDetail.MoodyRatingLT = this.MoodyRatingLT;
      opportunity.OpportunityDetail.SPRatingLT = this.SPRatingLT;
      opportunity.OpportunityDetail.FitchRatingLT = this.FitchRatingLT;
      opportunity.OpportunityDetail.KrollRatingLT = this.KrollRatingLT;
      opportunity.OpportunityDetail.Notes = this.Notes;
      opportunity.OpportunityDetail.ReviewComments = this.ReviewComments != null ? this.ReviewComments.Trim() : this.ReviewComments;
      opportunity.AppTransactionClientContacts = this.AppTransactionClientContacts;
      opportunity.OpportunityDetail.CreatedBy = this.CreatedBy;
      opportunity.OpportunityDetail.CreatedOn = this.CreatedOn;
      opportunity.OpportunityDetail.ModifiedBy = this.ModifiedBy;
      opportunity.OpportunityDetail.ModifiedOn = this.ModifiedOn;
      opportunity.OpportunityDetail.DocumentLibraryURL = this.DocumentLibraryURL;
      opportunity.OpportunityDetail.Version = this.Version;
      opportunity.OpportunityDetail.LastModifiedBy = this.LastModifiedBy;
      opportunity.InternalPartners = new List<InternalPartner>();
      if (this.Bankers != null && this.Bankers.Count > 0)
        opportunity.InternalPartners.AddRange((IEnumerable<InternalPartner>) this.Bankers);
      if (this.Analysts != null && this.Analysts.Count > 0)
        opportunity.InternalPartners.AddRange((IEnumerable<InternalPartner>) this.Analysts);
      if (this.BankRMs != null && this.BankRMs.Count > 0)
        opportunity.InternalPartnerBankRMs = this.BankRMs;
      if (this.SupervisoryPrincipals != null && this.SupervisoryPrincipals.Count > 0)
        opportunity.InternalPartners.AddRange((IEnumerable<InternalPartner>) this.SupervisoryPrincipals);
      opportunity.ExternalPartners = new List<ExternalPartner>();
      if (this.Advisors != null && this.Advisors.Count > 0)
        opportunity.ExternalPartners.AddRange((IEnumerable<ExternalPartner>) this.Advisors);
      if (this.Counsels != null && this.Counsels.Count > 0)
        opportunity.ExternalPartners.AddRange((IEnumerable<ExternalPartner>) this.Counsels);
      if (this.SyndicateMembers != null && this.SyndicateMembers.Count > 0)
        opportunity.ExternalPartners.AddRange((IEnumerable<ExternalPartner>) this.SyndicateMembers);
      if (this.WinningSyndicateMembers != null && this.WinningSyndicateMembers.Count > 0)
        opportunity.ExternalPartners.AddRange((IEnumerable<ExternalPartner>) this.WinningSyndicateMembers);
      opportunity.MiscFieldsValueDetail = (IEnumerable<PropertySetValue>) this.MiscFieldsValueDetail;
      opportunity.OpportunityDetail.IsMERGInformed = this.IsMERGInformed;
      opportunity.OpportunityDetail.SubmittedToMERGDate = this.SubmittedToMERGDate;
      opportunity.OpportunityDetail.HasIssueInitiated = this.HasIssueInitiated;
      opportunity.OpportunityDetail.HasRFPInitiated = this.HasRFPInitiated;
      opportunity.OpportunityDetail.GeneralCategorySpecific = this.GeneralCategorySpecific;
      opportunity.OpportunityDetail.SDCCreditPerc = this.SDCCreditPerc;
      opportunity.OpportunityDetail.CommitmentCommitteeReviewDate = this.CommitmentCommitteeReviewDate;
      opportunity.OpportunityDetail.CommitmentCommitteeApprovedDate = this.CommitmentCommitteeApprovedDate;
      opportunity.OpportunityDetail.ManagementReviewDate = this.ManagementReviewDate;
      opportunity.OpportunityDetail.ManagementApprovedDate = this.ManagementApprovedDate;
      opportunity.OpportunityDetail.DealType = this.DealType;
      opportunity.OpportunityDetail.G17Details = this.G17Details;
      opportunity.OpportunityDetail.GeneralCategory = this.GeneralCategory;
      opportunity.OpportunityDetail.SubmissionDateAndTime = this.SubmissionDateAndTime;
      opportunity.OpportunityDetail.SubmissionDateTimezone = this.SubmissionDateTimezone;
      opportunity.OpportunityDetail.RFPFees = this.RFPFees;
      opportunity.OpportunityDetail.IsManagementApproved = this.IsManagementApproved;
      opportunity.OpportunityDetail.IsCommitmentCommitteeApproved = this.IsCommitmentCommitteeApproved;
      opportunity.OpportunityDetail.TakeDownValue = this.TakeDownValue;
      opportunity.OpportunityDetail.HasRFPFeeChangedAfterManagementApprovalProcess = this.HasRFPFeeChangedAfterManagementApprovalProcess;
      opportunity.OpportunityDetail.OldRFPFees = this.OldRFPFees;
      opportunity.OpportunityDetail.IsManagementApprovedStateVisited = this.IsManagementApprovedStateVisited;
      opportunity.OpportunityDetail.ExpectedPricingDate = this.ExpectedPricingDate;
      opportunity.OpportunityDetail.AdditionalRFPDetails = this.AdditionalRFPDetails;
      opportunity.OpportunityDetail.ProposedManagementFee = this.ProposedManagementFee;
      opportunity.OpportunityDetail.ProposedUnderwriterExpenses = this.ProposedUnderwriterExpenses;
      opportunity.OpportunityDetail.FirmMgmtFee = this.FirmMgmtFee;
      opportunity.OpportunityDetail.ProposedUnderwriterExpenses = this.ProposedUnderwriterExpenses;
      opportunity.OpportunityDetail.DealTypeName = this.DealTypeName;
      opportunity.OpportunityDetail.RFPTypeName = this.RFPTypeName;
      opportunity.OpportunityDetail.OpportunityTypeName = this.OpportunityTypeName;
      opportunity.OpportunityDetail.ExpectedFirmRoleValue = this.ExpectedFirmRoleValue;
      opportunity.OpportunityDetail.FirmRoleValue = this.FirmRoleValue;
      opportunity.OpportunityDetail.Ratings = this.Ratings;
      opportunity.OpportunityDetail.MSBankingGroupOpportunity = this.MSBankingGroupOpportunity;
      return opportunity;
    }
  }
}
