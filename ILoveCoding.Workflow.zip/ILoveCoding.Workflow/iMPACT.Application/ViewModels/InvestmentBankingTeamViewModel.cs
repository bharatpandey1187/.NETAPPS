﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.InvestmentBankingTeamViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class InvestmentBankingTeamViewModel : ViewModelBase
  {
    public InvestmentBankingTeamViewModel()
    {
      this.IssueInvestmentBankingTeam = new List<InternalPartner>();
      this.IssueStatus = new List<long>();
      this.RevenuePercentage = new List<IrisSoftware.iMPACT.Data.RevenuePercentage>();
    }

    public List<InternalPartner> IssueInvestmentBankingTeam { get; set; }

    public InternalPartnerAutoCompleteViewModel InvestmentBankingTeamAutoComplete { get; set; }

    public bool InternalPartnerIsViewOnly { get; set; }

    public long AppTrasanctionId { get; set; }

    public List<long> IssueStatus { get; set; }

    public List<IrisSoftware.iMPACT.Data.RevenuePercentage> RevenuePercentage { get; set; }

    public string AttributionReviewed { get; set; }
  }
}
