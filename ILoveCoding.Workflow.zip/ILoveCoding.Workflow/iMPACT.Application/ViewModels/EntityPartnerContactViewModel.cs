﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.EntityPartnerContactViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class EntityPartnerContactViewModel : ViewModelBase
  {
    public EntityPartnerContactViewModel()
    {
    }

    public EntityPartnerContactViewModel(IssuePartnerContact issuePartnerContact)
    {
      this.PartnerContactID = issuePartnerContact.PartnerContactID;
      this.PartnerID = issuePartnerContact.PartnerID;
      this.PartnerName = issuePartnerContact.PartnerName;
      this.PartnerContactName = issuePartnerContact.PartnerContactName;
      this.Phone = issuePartnerContact.Phone;
      this.StreetAddress = issuePartnerContact.StreetAddress;
      this.City = issuePartnerContact.City;
      this.State = issuePartnerContact.State;
      this.StateName = issuePartnerContact.StateName;
      this.State = issuePartnerContact.State;
      this.Zip = issuePartnerContact.Zip;
      this.Title = issuePartnerContact.Title;
      this.Email = issuePartnerContact.Email;
      this.IsActive = issuePartnerContact.IsActive;
      this.IsDefault = issuePartnerContact.IsDefault;
      this.IsSelected = issuePartnerContact.IsSelected;
      this.PartnerContactAddressID = issuePartnerContact.PartnerContactAddressID;
      this.NameTitle = issuePartnerContact.NameTitle;
      this.FirstName = issuePartnerContact.FirstName;
      this.LastName = issuePartnerContact.LastName;
      this.Suffix = issuePartnerContact.Suffix;
      this.Mobile = issuePartnerContact.Mobile;
      this.Fax = issuePartnerContact.Fax;
    }

    public IssuePartnerContact GetIssuePartnerContactDetail() => new IssuePartnerContact()
    {
      PartnerContactID = this.PartnerContactID,
      PartnerID = this.PartnerID,
      PartnerName = this.PartnerName,
      PartnerContactName = this.PartnerContactName.Trim(),
      Title = this.Title.Trim(),
      StreetAddress = this.StreetAddress.Trim(),
      City = this.City.Trim(),
      StateName = this.StateName,
      State = this.State,
      Zip = this.Zip,
      Email = this.Email.Trim(),
      Phone = this.Phone,
      IsSelected = this.IsSelected,
      ExternalPartnerID = this.ExternalPartnerID,
      IsActive = this.IsActive,
      IsDefault = this.IsDefault,
      PartnerContactAddressID = this.PartnerContactAddressID,
      NameTitle = this.NameTitle,
      FirstName = this.FirstName,
      LastName = this.LastName,
      Suffix = this.Suffix,
      Mobile = this.Mobile,
      Fax = this.Fax
    };

    public IssuePartnerContact GetIssuePartnerContactDetail(
      EntityPartnerContactViewModel entityPartnerContactViewModel)
    {
      return new IssuePartnerContact()
      {
        PartnerContactID = entityPartnerContactViewModel.PartnerContactID,
        PartnerID = entityPartnerContactViewModel.PartnerID,
        PartnerName = entityPartnerContactViewModel.PartnerName,
        PartnerContactName = entityPartnerContactViewModel.PartnerContactName.Trim(),
        StreetAddress = entityPartnerContactViewModel.StreetAddress.Trim(),
        City = entityPartnerContactViewModel.City.Trim(),
        State = entityPartnerContactViewModel.State,
        StateName = entityPartnerContactViewModel.StateName,
        Zip = entityPartnerContactViewModel.Zip,
        Phone = entityPartnerContactViewModel.Phone,
        Title = entityPartnerContactViewModel.Title.Trim(),
        Email = entityPartnerContactViewModel.Email.Trim(),
        IsActive = entityPartnerContactViewModel.IsActive,
        IsDefault = entityPartnerContactViewModel.IsDefault,
        IsSelected = entityPartnerContactViewModel.IsSelected,
        ExternalPartnerID = entityPartnerContactViewModel.ExternalPartnerID,
        NameTitle = entityPartnerContactViewModel.NameTitle,
        FirstName = entityPartnerContactViewModel.FirstName,
        LastName = entityPartnerContactViewModel.LastName,
        Suffix = entityPartnerContactViewModel.Suffix,
        Fax = entityPartnerContactViewModel.Fax
      };
    }

    public long PartnerID { get; set; }

    public long PartnerContactID { get; set; }

    [Required(ErrorMessage = "Partner Name cannot be blank.")]
    [StringLength(300, ErrorMessage = "Partner Name length should be less than or equal to 300 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string PartnerName { get; set; }

    [Required(ErrorMessage = "Contact Name cannot be blank.")]
    [StringLength(80, ErrorMessage = "Contact Name length should be less than or equal to 80 characters.")]
    [RegexValidator("^$|(^[A-Za-z',. ]+$)", MessageTemplate = "Only alphabets and spaces ,.' are allowed.")]
    public string PartnerContactName { get; set; }

    public string NameTitle { get; set; }

    [Required(ErrorMessage = "First Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string FirstName { get; set; }

    [Required(ErrorMessage = "Last Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string LastName { get; set; }

    public string Suffix { get; set; }

    [RegexValidator("^$|(^[A-Za-z-\\\\,& ./]+$)", MessageTemplate = "Only alphabets, comma, slash, dash, &, period and space are allowed.")]
    [StringLength(100, ErrorMessage = "Contact Title length should be less than or equal to 100 characters.")]
    public string Title { get; set; }

    [StringLength(500, ErrorMessage = "Contact Street Address length should be less than or equal to 500 characters.")]
    public string StreetAddress { get; set; }

    [RegexValidator("^$|(^[A-Za-z'-. ]+$)", MessageTemplate = "Only alphabets, comma, dash, period, apostrophe and space are allowed.")]
    [StringLength(100, ErrorMessage = "Contact Length of City field for a Client should be less than or equal to 100 characters.")]
    public string City { get; set; }

    public string StateName { get; set; }

    public long? State { get; set; }

    [RegexValidator("^$|((^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$))", MessageTemplate = "ZIP Code for USA should be XXXXX or XXXXX-XXXX.")]
    [StringLength(12, ErrorMessage = "Contact Zip length should be less than or equal to 12 characters.")]
    public string Zip { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Contact Phone length should be less than or equal to 12 characters.")]
    public string Phone { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Mobile number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Contact Mobile length should be less than or equal to 12 characters.")]
    public string Mobile { get; set; }

    [StringLength(12, ErrorMessage = "Contact Fax length should be less than or equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Fax number should be in XXX-XXX-XXXX format.")]
    public string Fax { get; set; }

    [RegexValidator("^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", MessageTemplate = "Email address is not valid.")]
    [StringLength(100, ErrorMessage = "Contact Email length should be less than or equal to 100 characters.")]
    public string Email { get; set; }

    public bool IsActive { get; set; }

    public bool IsDefault { get; set; }

    public bool IsSelected { get; set; }

    public long ExternalPartnerID { get; set; }

    public long? PartnerContactAddressID { get; set; }
  }
}
