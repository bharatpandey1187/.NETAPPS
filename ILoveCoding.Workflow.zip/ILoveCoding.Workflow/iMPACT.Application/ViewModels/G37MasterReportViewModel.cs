﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.G37MasterReportViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class G37MasterReportViewModel
  {
    public long AppTransactionID { get; set; }

    public string IssueNbr { get; set; }

    public string IssueName { get; set; }

    public string Issuer { get; set; }

    public string CUSIP { get; set; }

    public string State { get; set; }

    public string TypeOfOffering { get; set; }

    public string LeadManager { get; set; }

    public Decimal HSEParticipation { get; set; }

    [AbsoluteDate]
    public DateTime? SaleDate { get; set; }

    [AbsoluteDate]
    public DateTime? G32SubmissionDate { get; set; }

    [AbsoluteDate]
    public DateTime? TransactionSettlementDate { get; set; }

    public string QtrReported { get; set; }

    public string Series { get; set; }
  }
}
