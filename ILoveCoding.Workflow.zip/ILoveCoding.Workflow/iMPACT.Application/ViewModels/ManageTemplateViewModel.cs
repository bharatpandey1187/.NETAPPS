﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ManageTemplateViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ManageTemplateViewModel : ViewModelBase
  {
    public ManageTemplateViewModel()
    {
    }

    public ManageTemplateViewModel(ManageTemplate manageTemplateItem)
    {
      this.EntityTemplateID = manageTemplateItem.EntityTemplateID;
      this.EntityID = manageTemplateItem.EntityID;
      this.DocumentID = manageTemplateItem.DocumentID;
      this.DocumentName = manageTemplateItem.DocumentName;
      this.Value = manageTemplateItem.Value;
      this.Title = manageTemplateItem.Title;
      this.URL = manageTemplateItem.URL;
      this.IsEditEnable = this.EntityTemplateID < 0L;
      this.IsDirty = false;
    }

    public ManageTemplate GetManageTemplateItem() => new ManageTemplate()
    {
      EntityTemplateID = this.EntityTemplateID,
      EntityID = this.EntityID,
      DocumentName = this.DocumentName,
      DocumentID = this.DocumentID,
      Value = this.Value,
      Title = this.Title,
      URL = this.URL
    };

    public long EntityTemplateID { get; set; }

    public long EntityID { get; set; }

    public long DocumentID { get; set; }

    public string Value { get; set; }

    public string DocumentName { get; set; }

    [Required(ErrorMessage = "Title cannot be blank.")]
    [StringLength(80, ErrorMessage = "Title length should be less than or equal to 80 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string Title { get; set; }

    [Required(ErrorMessage = "URL cannot be blank.")]
    [StringLength(1024, ErrorMessage = "URL length should be less than or equal to 1024 characters.")]
    [RegexValidator("^(http|ftp|https)://", MessageTemplate = "Invalid URL!!!")]
    public string URL { get; set; }

    public bool IsEditEnable { get; set; }
  }
}
