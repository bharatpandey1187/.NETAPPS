﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.TransactionAuditTrailViewModelComp
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class TransactionAuditTrailViewModelComp : ViewModelBase
  {
    public long AppTransactionID { get; set; }

    public string VersionNumber { get; set; }

    public string VersionInfo { get; set; }

    public string UserInfo { get; set; }

    public DateTime CreateDate { get; set; }

    [AbsoluteDate]
    public DateTime? SettlementDate { get; set; }

    [AbsoluteDate]
    public DateTime? G37SettlementDate { get; set; }

    public string WhenString => this.CreateDate > DateTime.MinValue ? this.CreateDate.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;

    public string IssueStatusValue { get; set; }

    public string IPREOStatusValue { get; set; }

    public string IPREOIssuerName { get; set; }

    public string ReviewStatusValue { get; set; }

    public string IssueNbr { get; set; }

    public string IssueName { get; set; }

    public string JobNumber { get; set; }

    public string IssuerName { get; set; }

    public string BorrowerName { get; set; }

    public string GuarantorName { get; set; }

    public string OfferingType { get; set; }

    public string State { get; set; }

    public string County { get; set; }

    [AbsoluteDate]
    public DateTime? DateHired { get; set; }

    [AbsoluteDate]
    public DateTime? G17SentDate { get; set; }

    [AbsoluteDate]
    public DateTime? G17AckDate { get; set; }

    public string RemarksForMUCC { get; set; }

    public string MAExemptions { get; set; }

    public string IRMAIndependent { get; set; }

    public string G17Details { get; set; }

    public string InvestmentBankingTeam { get; set; }

    public string SyndicateMembers { get; set; }

    public string SyndicateTeam { get; set; }

    public string AdvisoryAgents { get; set; }

    public string Counsels { get; set; }

    public string OtherExternalType { get; set; }

    public string FirmRole { get; set; }

    public string FirmOtherRoles { get; set; }

    public Decimal? FirmLiabilityPerc { get; set; }

    public Decimal? FirmMgmtFeePerc { get; set; }

    public Decimal? ParAmount { get; set; }

    public Decimal? SDCCreditPerc { get; set; }

    public string TransactionType { get; set; }

    public string GeneralCategory { get; set; }

    public string GeneralCategorySpecific { get; set; }

    [AbsoluteDate]
    public DateTime? PricingDate { get; set; }

    [AbsoluteDate]
    public DateTime? ROPDate { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedAwardDate { get; set; }

    [AbsoluteDate]
    public DateTime? ActualAwardDateTime { get; set; }

    public string ActualAwardDateTimeZone { get; set; }

    public Decimal? EstimatedRevenue { get; set; }

    public Decimal? GoodFaithAmount { get; set; }

    [AbsoluteDate]
    public DateTime? GoodFaithDate { get; set; }

    public string GoodFaithType { get; set; }

    public string AccountName { get; set; }

    public string AccountNumber { get; set; }

    public string ABANumber { get; set; }

    public bool? GFRequired { get; set; }

    public DateTime? GoodFaithDueDate { get; set; }

    public string GoodFaithApplied { get; set; }

    public string BankName { get; set; }

    public DateTime? GoodFaithIssueDate { get; set; }

    public DateTime? GoodFaithReturnedDate { get; set; }

    public string GoodFaithNotes { get; set; }

    public string GoodFaithInstructions { get; set; }

    [AbsoluteDate]
    public DateTime? DateCounselApprovedByLegal { get; set; }

    [AbsoluteDate]
    public DateTime? CommitmentCommitteeApprovalDate { get; set; }

    [AbsoluteDate]
    public DateTime? DateApprovedByMUCC { get; set; }

    [AbsoluteDate]
    public DateTime? FinalOSReceivedDateTime { get; set; }

    [AbsoluteDate]
    public DateTime? G32SubmissionDateTime { get; set; }

    public string AdvanceRefunding { get; set; }

    [AbsoluteDate]
    public DateTime? ARDSubmissionDate { get; set; }

    public string SupervisoryPrincipal { get; set; }

    public List<IrisSoftware.iMPACT.Data.Series> Series { get; set; }

    public List<InternalPartner> InternalPartners { get; set; }

    public List<ExternalPartner> ExternalPartners { get; set; }

    public List<ExternalPartner> SyndicateExternalPartners { get; set; }

    public string DealType { get; set; }

    [AbsoluteDate]
    public DateTime? FormalDueDiligenceDate { get; set; }

    [AbsoluteDate]
    public DateTime? IssuePriceCertReviewDate { get; set; }

    [AbsoluteDate]
    public DateTime? LiquidityAgreementUploadDate { get; set; }

    public string CrossSellValue { get; set; }

    public string CrossSellDetail { get; set; }

    [AbsoluteDate]
    public DateTime? DatedDate { get; set; }

    [AbsoluteDate]
    public DateTime? OSDeemedFinalDate { get; set; }

    public string ReasonOfHold { get; set; }
  }
}
