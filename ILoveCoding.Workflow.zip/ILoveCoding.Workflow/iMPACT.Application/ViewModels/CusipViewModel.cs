﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CusipViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CusipViewModel : ViewModelBase
  {
    public string SeriesID { get; set; }

    [AbsoluteDate]
    public DateTime? MaturityDate { get; set; }

    public string CUSIP { get; set; }

    public string Term { get; set; }

    public string AverageLife { get; set; }

    public string Amount { get; set; }

    public string Coupon { get; set; }

    public string Yield { get; set; }

    public string Price { get; set; }

    public string YTM { get; set; }

    public string CusipID { get; set; }

    [AbsoluteDate]
    public DateTime? CallDate { get; set; }

    public string Takedown { get; set; }

    public bool Insured { get; set; }
  }
}
