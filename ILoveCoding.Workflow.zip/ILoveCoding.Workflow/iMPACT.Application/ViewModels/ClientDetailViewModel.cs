﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ClientDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ClientDetailViewModel : ViewModelBase
  {
    public ClientDetailViewModel()
    {
    }

    public ClientDetailViewModel(ClientContact clientContact)
    {
      this.ClientContactID = clientContact.ClientContactID;
      this.ClientID = clientContact.ClientID;
      this.Name = clientContact.Name != null ? clientContact.Name.Trim() : "";
      this.StreetAddress = clientContact.StreetAddress != null ? clientContact.StreetAddress.Trim() : "";
      this.City = clientContact.City != null ? clientContact.City.Trim() : "";
      this.State = clientContact.State;
      this.StateName = clientContact.StateName;
      this.Zip = clientContact.Zip;
      this.Phone = clientContact.Phone;
      this.Fax = clientContact.Fax;
      this.Title = clientContact.Title != null ? clientContact.Title.Trim() : (string) null;
      this.Email = clientContact.Email.Trim();
      this.IsActive = clientContact.IsActive;
      this.IsDefault = clientContact.IsDefault;
      this.IsG17Contact = clientContact.IsG17Contact;
      this.ContactAddressID = clientContact.ContactAddressID;
      this.IsContactUsedInEntity = clientContact.IsContactUsedInEntity;
      this.NameTitle = clientContact.NameTitle;
      this.FirstName = clientContact.FirstName;
      this.LastName = clientContact.LastName;
      this.Suffix = clientContact.Suffix;
      this.Mobile = clientContact.Mobile;
    }

    public ClientContact GetClientContact() => new ClientContact()
    {
      ClientContactID = this.ClientContactID,
      ClientID = this.ClientID,
      Name = this.Name != null ? this.Name.Trim() : "",
      StreetAddress = this.StreetAddress != null ? this.StreetAddress.Trim() : "",
      City = this.City != null ? this.City.Trim() : "",
      State = this.State,
      StateName = this.StateName,
      Zip = this.Zip,
      Phone = this.Phone,
      Fax = this.Fax,
      Title = this.Title.Trim(),
      Email = this.Email.Trim(),
      IsActive = this.IsActive,
      IsDefault = this.IsDefault,
      ContactAddressID = this.ContactAddressID,
      IsG17Contact = this.IsG17Contact,
      NameTitle = this.NameTitle,
      FirstName = this.FirstName,
      LastName = this.LastName,
      Suffix = this.Suffix,
      Mobile = this.Mobile
    };

    public long ClientContactID { get; set; }

    public long ClientID { get; set; }

    [Required(ErrorMessage = "First Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string FirstName { get; set; }

    [Required(ErrorMessage = "Last Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string LastName { get; set; }

    [Required(ErrorMessage = "Full Name cannot be blank.")]
    [StringLength(100, ErrorMessage = "Length of Full Name field should be less than or equal to 100 characters.")]
    [RegexValidator("^$|(^[A-Za-z',. ]+$)", MessageTemplate = "Only alphabets and spaces ,.' are allowed.")]
    public string Name { get; set; }

    public int? NameTitle { get; set; }

    public string Suffix { get; set; }

    public string StreetAddress { get; set; }

    public string City { get; set; }

    public long? State { get; set; }

    public string StateName { get; set; }

    public string Zip { get; set; }

    [StringLength(12, ErrorMessage = "Length of Phone field for a Client should be less than or equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    public string Phone { get; set; }

    [StringLength(12, ErrorMessage = "Length of Mobile field for a Client should be less than or equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Mobile number should be in XXX-XXX-XXXX format.")]
    public string Mobile { get; set; }

    [StringLength(12, ErrorMessage = "Length of Fax field for a Client Contact should be less than or equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Fax number should be in XXX-XXX-XXXX format.")]
    public string Fax { get; set; }

    [RegexValidator("^$|(^[A-Za-z-\\\\,& ./]+$)", MessageTemplate = "Only alphabets, comma, slash, dash, &, period and space are allowed.")]
    [StringLength(100, ErrorMessage = "Length of Title field for a Client should be less than or equal to 100 characters.")]
    public string Title { get; set; }

    [RegexValidator("^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", MessageTemplate = "Email address is not valid.")]
    [StringLength(100, ErrorMessage = "Length of Email field for a Client should be less than or equal to 100 characters.")]
    public string Email { get; set; }

    public bool IsActive { get; set; }

    public bool IsDefault { get; set; }

    public bool IsG17Contact { get; set; }

    public long? ContactAddressID { get; set; }

    public bool IsContactUsedInEntity { get; set; }
  }
}
