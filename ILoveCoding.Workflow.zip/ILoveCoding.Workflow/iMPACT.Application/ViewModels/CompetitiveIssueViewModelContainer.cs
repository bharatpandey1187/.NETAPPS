﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CompetitiveIssueViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CompetitiveIssueViewModelContainer : ViewModelBase
  {
    public CompetitiveIssueViewModelContainer()
    {
      this.IsAdvanceRefundings = new List<KeyValuePair<long, string>>();
      this.FirmRole = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.CrossSell = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FirmOtherRole = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.PriorityOfOrders = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.TypeOfOffering = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.InsuranceProvider = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.States = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.Purposes = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.CreditEnhancementProgram = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.GeneralCategory = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.GeneralCategorySpecific = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.BidPlatform = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.BidCalc = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.TxtDateTime = new List<KeyPair>();
      this.G17Type = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.RateTypes = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.IssueDetail = new CompetitiveIssueDetailViewModel();
      this.TransactionReportDetail = new CompetitiveIssueTransactionReportViewModel();
      this.RestrictedCUSIPs = new List<RestrictedCUSIPViewModel>();
      this.IssueContactDetail = new IssueContactDetailViewModel();
      this.GoodFaithType = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.Mucc = new CompetitiveMucc();
      this.IssueRegulatoryCheckList = new CompetitiveIssueRegulatoryCheckList();
      this.FedTaxs = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
    }

    public CompetitiveIssueViewModelContainer(
      List<LookupItemMappings> lookupItems,
      CompetitiveIssue theIssue)
    {
      this.MAExemptions = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "MA Exemption".Trim().ToLower()));
      this.MERGReviewTypes = lookupItems.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MERG Review Type")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
      this.IsAdvanceRefundings = lookupItems.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key.Trim().ToLower() == "Is Advance Refunding".Trim().ToLower())).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
      this.FirmRole = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Firm Role".Trim().ToLower()));
      this.CrossSell = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Cross Sell".Trim().ToLower()));
      this.FirmOtherRole = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Additional Firm Role(s)".Trim().ToLower()));
      this.PriorityOfOrders = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Syndicate Structure".Trim().ToLower()));
      this.TypeOfOffering = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Type of Offering".Trim().ToLower()));
      this.InsuranceProvider = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Insurance Provider".Trim().ToLower()));
      this.States = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "State".Trim().ToLower()));
      this.DSRFs = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "DSRF".Trim().ToLower()));
      this.Purposes = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Purpose".Trim().ToLower()));
      this.TransactionTypes = lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Transaction Type".Trim().ToLower()));
      this.UseOfProceeds = lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Use of Proceeds".Trim().ToLower()));
      this.CreditEnhancementProgram = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Credit Enhancement Program"));
      this.GeneralCategory = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "MS Banking Group".Trim().ToLower()));
      this.GeneralCategorySpecific = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "General Category (Specific)".Trim().ToLower()));
      this.BidPlatform = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Bid Platform".Trim().ToLower()));
      this.BidCalc = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Bid Calc".Trim().ToLower()));
      this.G17Type = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "G-17 Type".Trim().ToLower()));
      this.GoodFaithType = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (X => X.Key.Trim().ToLower() == "Good Faith Type".Trim().ToLower()));
      this.IssueDetail = new CompetitiveIssueDetailViewModel(theIssue);
      this.TransactionReportDetail = new CompetitiveIssueTransactionReportViewModel(theIssue);
      this.RestrictedCUSIPs = theIssue.RestrictedCUSIP != null ? theIssue.RestrictedCUSIP.Select<RestrictedCUSIP, RestrictedCUSIPViewModel>((Func<RestrictedCUSIP, RestrictedCUSIPViewModel>) (x => new RestrictedCUSIPViewModel(x))).ToList<RestrictedCUSIPViewModel>() : new List<RestrictedCUSIPViewModel>();
      this.ExternalPartnerDetail = new IssueExternalPartnerViewModel(lookupItems, theIssue.ExternalPartners);
      this.InternalPartnerDetail = new IssueInternalPartnerViewModel(theIssue);
      this.IssueRatingDetail = new IssueRatingViewModel(lookupItems);
      this.UnderlyingRatingDetail = new List<UnderlyingRatingsViewModel>();
      this.EnhancedRatingDetail = new List<EnhancedRatingsViewModel>();
      this.IssueContactDetail = new IssueContactDetailViewModel(theIssue);
      this.IssuePricingDetail = new IssuePricingViewModel(lookupItems);
      this.IssuePricingDetailData = new List<PricingViewModel>();
      this.AppTransactionClientContacts = theIssue.AppTransactionClientContacts;
      this.MiscFieldsDetail = theIssue.MiscFieldsDetail;
      this.Mucc = theIssue.Mucc;
      this.RateTypes = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Interest Rate Type".Trim().ToLower()));
      this.FedTaxs = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Fed Tax".Trim().ToLower()));
      this.DealTypes = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Deal Type".Trim().ToLower()));
      this.IssueRegulatoryCheckList = theIssue.IssueRegulatoryCheckList;
      this.GoodFaithDetails = theIssue.GoodFaithDetails;
    }

    public CompetitiveIssueDetailViewModel IssueDetail { get; set; }

    public List<RestrictedCUSIPViewModel> RestrictedCUSIPs { get; set; }

    public CompetitiveIssueTransactionReportViewModel TransactionReportDetail { get; set; }

    public IssueExternalPartnerViewModel ExternalPartnerDetail { get; set; }

    public IssueInternalPartnerViewModel InternalPartnerDetail { get; set; }

    public bool IsRatingLoaded { get; set; }

    public IssueRatingViewModel IssueRatingDetail { get; set; }

    public List<UnderlyingRatingsViewModel> UnderlyingRatingDetail { get; set; }

    public List<EnhancedRatingsViewModel> EnhancedRatingDetail { get; set; }

    public IssueContactDetailViewModel IssueContactDetail { get; set; }

    public bool IsPricingLoaded { get; set; }

    public IssuePricingViewModel IssuePricingDetail { get; set; }

    public List<PricingViewModel> IssuePricingDetailData { get; set; }

    public List<AppTransactionStateTransition> WorkflowStateTransitions { get; set; }

    public List<AppTransactionClientContact> AppTransactionClientContacts { get; set; }

    public IEnumerable<PropertyDescriptor> MiscFieldsDetail { get; set; }

    public IEnumerable<PropertySetValue> MiscFieldsValueDetail { get; set; }

    public CompetitiveMucc Mucc { get; set; }

    public bool IsAuditTrailLoaded { get; set; }

    public bool IsBidDetailsLoaded { get; set; }

    public List<AuditTrailViewModel> AuditTrailDetail { get; set; }

    public string[] Actions { get; set; }

    public List<EmailTemplateViewModel> EmailTemplates { get; set; }

    public bool CanUploadIssueDocuments { get; set; }

    public bool CanAccessTransactionPnL { get; set; }

    public bool IsPnlSaved { get; set; }

    public CompetitiveIssueRegulatoryCheckList IssueRegulatoryCheckList { get; set; }

    public IEnumerable<LookupItemMappings> MAExemptions { get; set; }

    public List<KeyValuePair<long, string>> MERGReviewTypes { get; set; }

    public List<KeyValuePair<long, string>> IsAdvanceRefundings { get; set; }

    public IEnumerable<LookupItemMappings> FirmRole { get; set; }

    public IEnumerable<LookupItemMappings> CrossSell { get; set; }

    public IEnumerable<LookupItemMappings> FirmOtherRole { get; set; }

    public IEnumerable<LookupItemMappings> PriorityOfOrders { get; set; }

    public IEnumerable<LookupItemMappings> TypeOfOffering { get; set; }

    public IEnumerable<LookupItemMappings> InsuranceProvider { get; set; }

    public IEnumerable<LookupItemMappings> States { get; set; }

    public IEnumerable<LookupItemMappings> DSRFs { get; set; }

    public IEnumerable<LookupItemMappings> Purposes { get; set; }

    public List<LookupItemMappings> TransactionTypes { get; set; }

    public List<LookupItemMappings> UseOfProceeds { get; set; }

    public IEnumerable<LookupItemMappings> CreditEnhancementProgram { get; set; }

    public IEnumerable<LookupItemMappings> GeneralCategory { get; set; }

    public IEnumerable<LookupItemMappings> GeneralCategorySpecific { get; set; }

    public IEnumerable<LookupItemMappings> BidPlatform { get; set; }

    public IEnumerable<LookupItemMappings> BidCalc { get; set; }

    public IEnumerable<LookupItemMappings> G17Type { get; set; }

    public IEnumerable<LookupItemMappings> RateTypes { get; set; }

    public IEnumerable<LookupItemMappings> FedTaxs { get; set; }

    public IEnumerable<LookupItemMappings> DealTypes { get; set; }

    public List<KeyPair> TxtDateTime { get; set; }

    public IEnumerable<LookupItemMappings> GoodFaithType { get; set; }

    public BidDetail IssueBidDetails { get; set; }

    public CompetitiveGoodFaithDetail GoodFaithDetails { get; set; }
  }
}
