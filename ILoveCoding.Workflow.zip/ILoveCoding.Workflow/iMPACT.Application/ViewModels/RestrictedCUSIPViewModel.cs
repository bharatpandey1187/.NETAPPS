﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RestrictedCUSIPViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RestrictedCUSIPViewModel : ViewModelBase
  {
    public RestrictedCUSIPViewModel() => this.AppTransactionID = 1L;

    public RestrictedCUSIPViewModel(RestrictedCUSIP restrictedCUSIP)
    {
      this.RestrictedCUSIPID = restrictedCUSIP.RestrictedCUSIPID;
      this.AppTransactionID = restrictedCUSIP.AppTransactionID;
      this.DatedDate = restrictedCUSIP.DatedDate;
      this.CUSIP = restrictedCUSIP.CUSIP.Trim();
      this.Maturity = restrictedCUSIP.Maturity;
      this.ParAmout = restrictedCUSIP.ParAmout;
      this.Term = restrictedCUSIP.Term;
      this.CallDate = restrictedCUSIP.CallDate;
    }

    public RestrictedCUSIP GetRestrictedCUSIP() => new RestrictedCUSIP()
    {
      RestrictedCUSIPID = this.RestrictedCUSIPID,
      AppTransactionID = this.AppTransactionID,
      DatedDate = this.DatedDate,
      CUSIP = this.CUSIP.Trim(),
      Maturity = this.Maturity,
      ParAmout = this.ParAmout,
      Term = this.Term,
      CallDate = this.CallDate
    };

    public long RestrictedCUSIPID { get; set; }

    public long AppTransactionID { get; set; }

    public DateTime? DatedDate { get; set; }

    public string CUSIP { get; set; }

    public DateTime? Maturity { get; set; }

    public Decimal? ParAmout { get; set; }

    public string Term { get; set; }

    public DateTime? CallDate { get; set; }
  }
}
