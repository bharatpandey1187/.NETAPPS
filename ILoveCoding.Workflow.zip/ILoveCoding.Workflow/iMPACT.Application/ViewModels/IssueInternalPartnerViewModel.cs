﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueInternalPartnerViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueInternalPartnerViewModel : ViewModelBase
  {
    public IssueInternalPartnerViewModel(Issue issue)
    {
      this.AppTransactionID = issue.IssueDetail.AppTransactionID;
      this.IssueInvestmentBankingTeam = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.InvestmentBankingTeam);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueAnalystProfessionalSupport = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.AnalystProfessionalSupport);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueAnalystProfessionalSupport = this.IssueAnalystProfessionalSupport.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
      {
        x.IsPrimary = this.GetInternalPartnerIsPrimary(x.IsPrimary);
        return x;
      })).ToList<InternalPartner>();
      this.IssueUnderwritingTeam = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.UnderWritingTeam);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueSupervisoryPrincipal = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.SupervisoryPrincipal);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueBankRM = issue.InternalPartnerBankRMs;
    }

    public IssueInternalPartnerViewModel(CompetitiveIssue issue)
    {
      this.AppTransactionID = issue.IssueDetail.AppTransactionID;
      this.IssueInvestmentBankingTeam = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) CompetitiveIssueEnums.RoleTypes.InvestmentBankingTeam);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueAnalystProfessionalSupport = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) CompetitiveIssueEnums.RoleTypes.AnalystProfessionalSupport);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueUnderwritingTeam = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) CompetitiveIssueEnums.RoleTypes.UnderWritingTeam);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueSupervisoryPrincipal = issue.InternalPartners == null ? new List<InternalPartner>() : issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) CompetitiveIssueEnums.RoleTypes.SupervisoryPrincipal);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).OrderBy<InternalPartner, string>((Func<InternalPartner, string>) (x => x.FullName)).ToList<InternalPartner>();
      this.IssueBankRM = issue.InternalPartnerBankRMs;
    }

    public IssueInternalPartnerViewModel()
    {
      this.AppTransactionID = this.AppTransactionID;
      this.IssueInvestmentBankingTeam = new List<InternalPartner>();
      this.IssueAnalystProfessionalSupport = new List<InternalPartner>();
      this.IssueUnderwritingTeam = new List<InternalPartner>();
      this.InvestmentBankingTeamAutoComplete = new InternalPartnerAutoCompleteViewModel();
      this.AnalystProfessionalSupportAutoComplete = new InternalPartnerAutoCompleteViewModel();
      this.UnderwritingTeamAutoComplete = new InternalPartnerAutoCompleteViewModel();
      this.SupervisoryPrincipalAutoComplete = new InternalPartnerAutoCompleteViewModel();
      this.BankRMAutoComplete = new InternalPartnerAutoCompleteViewModel();
      this.IssueBankRM = new List<InternalPartnerBankRM>();
    }

    public IssueInternalPartnerViewModel(List<InternalPartner> issueInternalPartner)
    {
      this.IssueInvestmentBankingTeam = issueInternalPartner == null ? new List<InternalPartner>() : issueInternalPartner.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.InvestmentBankingTeam);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).ToList<InternalPartner>();
      this.IssueAnalystProfessionalSupport = issueInternalPartner == null ? new List<InternalPartner>() : issueInternalPartner.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.AnalystProfessionalSupport);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).ToList<InternalPartner>();
      this.IssueUnderwritingTeam = issueInternalPartner == null ? new List<InternalPartner>() : issueInternalPartner.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.UnderWritingTeam);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).ToList<InternalPartner>();
      this.IssueSupervisoryPrincipal = issueInternalPartner == null ? new List<InternalPartner>() : issueInternalPartner.Where<InternalPartner>((Func<InternalPartner, bool>) (x =>
      {
        long? roleTypeId = x.RoleTypeId;
        long int64 = Convert.ToInt64((object) IssueEnums.RoleTypes.SupervisoryPrincipal);
        return roleTypeId.GetValueOrDefault() == int64 && roleTypeId.HasValue;
      })).ToList<InternalPartner>();
    }

    public long AppTransactionID { get; set; }

    public bool InternalPartnerIsViewOnly { get; set; }

    public List<InternalPartner> IssueInvestmentBankingTeam { get; set; }

    public List<InternalPartner> IssueAnalystProfessionalSupport { get; set; }

    public List<InternalPartner> IssueUnderwritingTeam { get; set; }

    public List<InternalPartner> IssueSupervisoryPrincipal { get; set; }

    public List<InternalPartnerBankRM> IssueBankRM { get; set; }

    public InternalPartnerAutoCompleteViewModel InvestmentBankingTeamAutoComplete { get; set; }

    public InternalPartnerAutoCompleteViewModel AnalystProfessionalSupportAutoComplete { get; set; }

    public InternalPartnerAutoCompleteViewModel UnderwritingTeamAutoComplete { get; set; }

    public InternalPartnerAutoCompleteViewModel SupervisoryPrincipalAutoComplete { get; set; }

    public InternalPartnerAutoCompleteViewModel BankRMAutoComplete { get; set; }

    private string GetInternalPartnerIsPrimary(string isPrimary) => !(isPrimary == "0") ? "Yes" : "No";
  }
}
