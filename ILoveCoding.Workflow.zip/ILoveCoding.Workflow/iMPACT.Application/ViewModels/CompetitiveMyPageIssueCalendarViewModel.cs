﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CompetitiveMyPageIssueCalendarViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CompetitiveMyPageIssueCalendarViewModel
  {
    public long AppTransactionID { get; set; }

    public string IssueNumber { get; set; }

    public string IssueName { get; set; }

    public string IssuerName { get; set; }

    public string BorrowerName { get; set; }

    public string State { get; set; }

    public string TypeOfOffering { get; set; }

    public string IssueStatus { get; set; }

    public string ReviewStatus { get; set; }

    public Decimal? ParAmount { get; set; }

    public string FirmRole { get; set; }

    [AbsoluteDate]
    public DateTime? AwardDate { get; set; }

    [AbsoluteDate]
    public DateTime? PricingDate { get; set; }

    [AbsoluteDate]
    public DateTime? SettlementDate { get; set; }

    public string Task { get; set; }

    public List<CompetitiveMyPageSeriesViewModel> Series { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedAwardDateTime { get; set; }

    public string ExpectedAwardDate => this.ExpectedAwardDateTime.HasValue ? this.ExpectedAwardDateTime.Value.ToShortDateString() : string.Empty;

    public string PnLTask { get; set; }

    public string JobNumber { get; set; }
  }
}
