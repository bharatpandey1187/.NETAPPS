﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.InternalPartnerAutoCompleteViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class InternalPartnerAutoCompleteViewModel
  {
    public InternalPartnerAutoCompleteViewModel()
    {
    }

    public InternalPartnerAutoCompleteViewModel(Employee employee)
    {
      this.EmployeeID = employee.EmployeeID;
      this.FullName = employee.FullName;
      this.Phone = employee.Phone;
      this.Title = employee.Title;
      this.Email = employee.Email;
      this.PartnerType = employee.PlatformRole ?? 0L;
      this.PrincipalId = employee.Principal;
      this.LoginName = employee.WindowID;
      this.IsActive = employee.IsActive;
      this.WindowID = employee.WindowID;
      this.KerberosID = employee.KerberosID;
      this.CostCenter = employee.CostCenter;
      this.StreetAddress = employee.StreetAddress;
      this.Fax = employee.Fax;
      this.City = employee.City;
      this.State = employee.State;
      this.StateName = employee.StateName;
      this.Zip = employee.Zip;
    }

    public long EmployeeID { get; set; }

    public string FullName { get; set; }

    public string Phone { get; set; }

    public string Title { get; set; }

    public string Email { get; set; }

    public long PartnerType { get; set; }

    public int PrincipalId { get; set; }

    public string LoginName { get; set; }

    public bool IsActive { get; set; }

    public string WindowID { get; set; }

    public string KerberosID { get; set; }

    public string CostCenter { get; set; }

    public string StreetAddress { get; set; }

    public string Fax { get; set; }

    public string City { get; set; }

    public long? State { get; set; }

    public string StateName { get; set; }

    public string Zip { get; set; }
  }
}
