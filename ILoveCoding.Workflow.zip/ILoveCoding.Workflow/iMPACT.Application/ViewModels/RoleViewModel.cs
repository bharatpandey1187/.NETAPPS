﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RoleViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RoleViewModel
  {
    public RoleViewModel()
    {
    }

    public RoleViewModel(Role role)
    {
      this.RoleID = role.RoleID;
      this.RoleName = role.RoleName;
      this.Entity = role.Entity;
      if (role.Permissions != null && role.Permissions.Count > 0)
        this.Permissions = role.Permissions.Select<Permission, PermissionViewModel>((Func<Permission, PermissionViewModel>) (x => new PermissionViewModel(x))).ToList<PermissionViewModel>();
      else
        this.Permissions = new List<PermissionViewModel>();
    }

    public Role GetRole() => new Role()
    {
      RoleID = this.RoleID,
      RoleName = this.RoleName,
      Entity = this.Entity
    };

    public long RoleID { get; set; }

    public string RoleName { get; set; }

    public string Entity { get; set; }

    public List<PermissionViewModel> Permissions { get; set; }
  }
}
