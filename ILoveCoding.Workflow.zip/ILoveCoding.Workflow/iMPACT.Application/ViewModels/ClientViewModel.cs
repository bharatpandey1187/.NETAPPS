﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ClientViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ClientViewModel : ViewModelBase
  {
    public ClientViewModel()
    {
      this.MAExemptionDetails = new List<ClientMAExemptionDetail>();
      this.MAExemptions = new List<KeyPair>();
      this.IRMAIndependent = new List<KeyPair>();
      this.AdvisorAgentAutoComplete = new KeyPair();
    }

    public ClientViewModel(string strErrorMsg)
    {
      this.ErrorMessage = strErrorMsg;
      this.ClientContacts = new List<ClientDetailViewModel>();
    }

    public ClientViewModel(Client client)
    {
      this.ClientID = client.ClientID;
      this.ExternalClientID = client.ExternalClientID;
      this.Name = client.Name;
      this.KFUJName = client.KFUJName;
      this.StreetAddress = client.StreetAddress;
      this.City = client.City;
      this.State = client.State;
      this.StateName = client.StateName;
      this.Zip = client.Zip;
      this.CountryCode = client.CountryCode;
      this.CountryIncorporation = client.CountryIncorporation;
      this.Phone = client.Phone;
      this.Fax = client.Fax;
      this.TaxID = client.TaxID;
      this.IsActive = client.IsActive;
      this.CreatedBy = client.CreatedBy;
      this.CreatedOn = client.CreatedOn;
      this.ModifiedBy = client.ModifiedBy;
      this.ModifiedOn = client.ModifiedOn;
      this.Title = client.Title;
      this.FirstName = client.FirstName;
      this.LastName = client.LastName;
      this.Suffix = client.Suffix;
      this.Mobile = client.Mobile;
      this.WebsiteUrl = client.WebsiteUrl;
      this.MAExempt = client.MAExempt;
      this.MAExemptionDetails = client.MAExemptionDetails != null ? client.MAExemptionDetails.ToList<ClientMAExemptionDetail>() : new List<ClientMAExemptionDetail>();
      this.ClientContacts = client.ClientContacts == null || !client.ClientContacts.Any<ClientContact>() ? new List<ClientDetailViewModel>() : client.ClientContacts.Select<ClientContact, ClientDetailViewModel>((Func<ClientContact, ClientDetailViewModel>) (x => new ClientDetailViewModel(x))).ToList<ClientDetailViewModel>();
      this.ClientCUSIPPrefix = client.ClientCUSIPPrefix == null || client.ClientCUSIPPrefix.ToList<IrisSoftware.iMPACT.Data.ClientCUSIPPrefix>().Count <= 0 ? new List<ClientCUSIPPrefixViewModel>() : client.ClientCUSIPPrefix.Select<IrisSoftware.iMPACT.Data.ClientCUSIPPrefix, ClientCUSIPPrefixViewModel>((Func<IrisSoftware.iMPACT.Data.ClientCUSIPPrefix, ClientCUSIPPrefixViewModel>) (x => new ClientCUSIPPrefixViewModel(x))).ToList<ClientCUSIPPrefixViewModel>();
      this.ClientAlias = client.ClientAlias == null || client.ClientAlias.ToList<IrisSoftware.iMPACT.Data.ClientAlias>().Count <= 0 ? new List<ClientAliasViewModel>() : client.ClientAlias.Select<IrisSoftware.iMPACT.Data.ClientAlias, ClientAliasViewModel>((Func<IrisSoftware.iMPACT.Data.ClientAlias, ClientAliasViewModel>) (x => new ClientAliasViewModel(x))).ToList<ClientAliasViewModel>();
      this.ClientCRM = client.ClientCRM == null || client.ClientCRM.ToList<IrisSoftware.iMPACT.Data.ClientCRM>().Count <= 0 ? new List<ClientCRMViewModel>() : client.ClientCRM.Select<IrisSoftware.iMPACT.Data.ClientCRM, ClientCRMViewModel>((Func<IrisSoftware.iMPACT.Data.ClientCRM, ClientCRMViewModel>) (x => new ClientCRMViewModel(x))).ToList<ClientCRMViewModel>();
      this.ClientAddress = client.ClientAddress == null || client.ClientAddress.ToList<IrisSoftware.iMPACT.Data.ClientAddress>().Count <= 0 ? new List<ClientAddressViewModel>() : client.ClientAddress.Select<IrisSoftware.iMPACT.Data.ClientAddress, ClientAddressViewModel>((Func<IrisSoftware.iMPACT.Data.ClientAddress, ClientAddressViewModel>) (x => new ClientAddressViewModel(x))).ToList<ClientAddressViewModel>();
      this.ClientActiveAddress = client.ClientActiveAddress != null ? client.ClientActiveAddress.ToList<IrisSoftware.iMPACT.Data.ClientActiveAddress>() : new List<IrisSoftware.iMPACT.Data.ClientActiveAddress>();
    }

    public Client GetClientDetail(ClientViewModel clientViewModel) => new Client()
    {
      ClientID = clientViewModel.ClientID,
      ExternalClientID = clientViewModel.ExternalClientID,
      Name = clientViewModel.Name.Trim(),
      KFUJName = string.IsNullOrEmpty(clientViewModel.KFUJName) ? string.Empty : clientViewModel.KFUJName.Trim(),
      StreetAddress = clientViewModel.StreetAddress.Trim(),
      City = clientViewModel.City.Trim(),
      State = clientViewModel.State,
      StateName = clientViewModel.StateName,
      Zip = clientViewModel.Zip,
      CountryCode = clientViewModel.CountryCode,
      CountryIncorporation = clientViewModel.CountryIncorporation,
      Phone = clientViewModel.Phone,
      Fax = clientViewModel.Fax,
      TaxID = clientViewModel.TaxID,
      WebsiteUrl = clientViewModel.WebsiteUrl,
      IsActive = clientViewModel.IsActive,
      MAExempt = clientViewModel.MAExempt,
      CreatedBy = clientViewModel.CreatedBy,
      CreatedOn = clientViewModel.CreatedOn,
      ModifiedBy = clientViewModel.ModifiedBy,
      ModifiedOn = clientViewModel.ModifiedOn,
      Title = clientViewModel.Title,
      FirstName = clientViewModel.FirstName,
      LastName = clientViewModel.LastName,
      Suffix = clientViewModel.Suffix,
      Mobile = clientViewModel.Mobile,
      ClientContacts = clientViewModel.ClientContacts == null ? new List<ClientContact>() : clientViewModel.ClientContacts.Select<ClientDetailViewModel, ClientContact>((Func<ClientDetailViewModel, ClientContact>) (x => x.GetClientContact())).ToList<ClientContact>(),
      ClientCUSIPPrefix = clientViewModel.ClientCUSIPPrefix == null ? new List<IrisSoftware.iMPACT.Data.ClientCUSIPPrefix>() : clientViewModel.ClientCUSIPPrefix.Select<ClientCUSIPPrefixViewModel, IrisSoftware.iMPACT.Data.ClientCUSIPPrefix>((Func<ClientCUSIPPrefixViewModel, IrisSoftware.iMPACT.Data.ClientCUSIPPrefix>) (x => x.GetClientCUSIPPrefix())).ToList<IrisSoftware.iMPACT.Data.ClientCUSIPPrefix>(),
      ClientAlias = clientViewModel.ClientAlias == null ? new List<IrisSoftware.iMPACT.Data.ClientAlias>() : clientViewModel.ClientAlias.Select<ClientAliasViewModel, IrisSoftware.iMPACT.Data.ClientAlias>((Func<ClientAliasViewModel, IrisSoftware.iMPACT.Data.ClientAlias>) (x => x.GetClientAlias())).ToList<IrisSoftware.iMPACT.Data.ClientAlias>(),
      ClientCRM = clientViewModel.ClientCRM == null ? new List<IrisSoftware.iMPACT.Data.ClientCRM>() : clientViewModel.ClientCRM.Select<ClientCRMViewModel, IrisSoftware.iMPACT.Data.ClientCRM>((Func<ClientCRMViewModel, IrisSoftware.iMPACT.Data.ClientCRM>) (x => x.GetClientCRM())).ToList<IrisSoftware.iMPACT.Data.ClientCRM>(),
      ClientAddress = clientViewModel.ClientAddress == null ? new List<IrisSoftware.iMPACT.Data.ClientAddress>() : clientViewModel.ClientAddress.Select<ClientAddressViewModel, IrisSoftware.iMPACT.Data.ClientAddress>((Func<ClientAddressViewModel, IrisSoftware.iMPACT.Data.ClientAddress>) (x => x.GetClientAddress())).ToList<IrisSoftware.iMPACT.Data.ClientAddress>(),
      MAExemptionDetails = clientViewModel.MAExemptionDetails
    };

    public Client GetClientforRepositoryCreation(ClientViewModel clientViewModel) => new Client()
    {
      ClientID = clientViewModel.ClientID,
      Name = clientViewModel.Name.Trim(),
      KFUJName = string.IsNullOrEmpty(clientViewModel.KFUJName) ? string.Empty : clientViewModel.KFUJName.Trim(),
      CreatedOn = clientViewModel.CreatedOn,
      ModifiedOn = clientViewModel.ModifiedOn
    };

    public long ClientID { get; set; }

    public string ExternalClientID { get; set; }

    [Required(ErrorMessage = "Client Name cannot be blank.")]
    [StringLength(200, ErrorMessage = "Length of Client name field should be less than or equal to 200 characters.")]
    public string Name { get; set; }

    public string KFUJName { get; set; }

    public string Title { get; set; }

    public string FirstName { get; set; }

    public string LastName { get; set; }

    public string Suffix { get; set; }

    public string StreetAddress { get; set; }

    public string City { get; set; }

    public long? State { get; set; }

    public string StateName { get; set; }

    [RegexValidator("^[0-9-().]*$", MessageTemplate = "Only numeric values , () , . , -  are allowed.")]
    [StringLength(12, ErrorMessage = "Length of Phone field for a Client should be less than or equal to 12 characters.")]
    public string Phone { get; set; }

    [RegexValidator("^[0-9-().]*$", MessageTemplate = "Only numeric values , () , . , -  are allowed.")]
    [StringLength(12, ErrorMessage = "Length of Mobile field for a Client should be less than or equal to 12 characters.")]
    public string Mobile { get; set; }

    [RegexValidator("^$|((^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$))", MessageTemplate = "ZIP Code for USA should be XXXXX or XXXXX-XXXX.")]
    [StringLength(12, ErrorMessage = "Length of ZIP Code field for a Client should be less than or equal to 12 characters.")]
    public string Zip { get; set; }

    [StringLength(3, ErrorMessage = "Length of Country Code field should be less than or equal to 3 characters.")]
    [RegexValidator("^$|(^[A-Za-z]+$)", MessageTemplate = "Only alphabets are allowed in Country Code.")]
    public string CountryCode { get; set; }

    public string CountryIncorporation { get; set; }

    [RegexValidator("^[0-9-().]*$", MessageTemplate = "Only numeric values , () , . , -  are allowed.")]
    [StringLength(12, ErrorMessage = "Length of Fax field for a Client should be less than or equal to 12 characters.")]
    public string Fax { get; set; }

    [StringLength(12, ErrorMessage = "Length of TaxId field for a Client should be less than or equal to 12 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-]+$)", MessageTemplate = "Only alphanumeric characters and - are allowed in Tax ID.")]
    public string TaxID { get; set; }

    public string WebsiteUrl { get; set; }

    public bool IsActive { get; set; }

    public string MAExempt { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public bool IsViewOnly { get; set; }

    public bool IsAddClient { get; set; }

    public bool IsEditClient { get; set; }

    public bool IsAddContact { get; set; }

    public bool IsEditContact { get; set; }

    public bool CanEditFidOneDetails { get; set; }

    public List<ClientDetailViewModel> ClientContacts { get; set; }

    public List<ClientCUSIPPrefixViewModel> ClientCUSIPPrefix { get; set; }

    public List<ClientAliasViewModel> ClientAlias { get; set; }

    public bool IsClientIdUsedInEntity { get; set; }

    public List<ClientMAExemptionDetail> MAExemptionDetails { get; set; }

    public List<KeyPair> MAExemptions { get; set; }

    public List<KeyPair> IRMAIndependent { get; set; }

    public List<KeyPair> SecurityTypes { get; set; }

    public List<KeyPair> ContactTitle { get; set; }

    public List<KeyPair> AdvisoryAgentList { get; set; }

    public List<KeyPair> ContactTitles { get; set; }

    public List<ClientCRMViewModel> ClientCRM { get; set; }

    public List<ClientAddressViewModel> ClientAddress { get; set; }

    public List<IrisSoftware.iMPACT.Data.ClientActiveAddress> ClientActiveAddress { get; set; }

    public bool ViewClientCRM { get; set; }

    public bool ViewClientAlias { get; set; }

    public bool ViewClientDocuments { get; set; }

    public bool IsClientContactAdded { get; set; }

    public bool CanUploadClientDocuments { get; set; }

    public KeyPair AdvisorAgentAutoComplete { get; set; }
  }
}
