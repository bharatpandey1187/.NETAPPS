﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ReviewChecklistViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ReviewChecklistViewModel : ViewModelBase
  {
    public ReviewChecklistViewModel()
    {
    }

    public ReviewChecklistViewModel(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public string Name { get; set; }

    public string Number { get; set; }

    public Decimal ParAmount { get; set; }

    public string IssuerName { get; set; }

    public long ReviewChecklistID { get; set; }

    [Range(1.0, 9.22337203685478E+18, ErrorMessage = "Invalid request.")]
    public long AppTransactionID { get; set; }

    public long EntityID { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public string[] Actions { get; set; }

    public bool IsViewOnly { get; set; }

    public bool CanSaveReviewChecklist { get; set; }

    public bool IsParentViewOnly { get; set; }

    public bool IsBankerDisabled { get; set; }

    public bool IsUnderWriterDisabled { get; set; }

    public List<IrisSoftware.iMPACT.Application.ViewModels.ReviewChecklistCategoryViewModel> ReviewChecklistCategoryViewModel { get; set; }
  }
}
