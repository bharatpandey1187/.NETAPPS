﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.SaveResult
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using Microsoft.Practices.EnterpriseLibrary.Validation;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class SaveResult
  {
    public Dictionary<string, object> _errors = new Dictionary<string, object>();
    public static readonly SaveResult Success = new SaveResult();

    public long Id { get; set; }

    public bool IsSuccessful => this.Errors.Count == 0 && string.IsNullOrEmpty(this.ErrorMessage);

    public string ErrorMessage { get; private set; }

    public Dictionary<string, object> Errors => this._errors;

    public object ViewModel { get; set; }

    public static SaveResult Failure(string message) => new SaveResult()
    {
      ErrorMessage = message
    };

    public static SaveResult Failure(ValidationResults validationResults)
    {
      SaveResult saveResult = new SaveResult();
      foreach (ValidationResult validationResult in (IEnumerable<ValidationResult>) validationResults)
      {
        if (!saveResult.Errors.ContainsKey(validationResult.Key))
          saveResult.Errors.Add(validationResult.Key, (object) validationResult.Message);
        else if (saveResult.Errors[validationResult.Key].ToString().ToLower() != validationResult.Message.ToLower())
          saveResult.Errors[validationResult.Key] = (object) (saveResult.Errors[validationResult.Key].ToString() + " , " + validationResult.Message);
      }
      return saveResult;
    }

    public static SaveResult Failure(string key, string message) => new SaveResult()
    {
      Errors = {
        {
          key,
          (object) message
        }
      }
    };

    public static SaveResult Failure(long id, string key, string message) => new SaveResult()
    {
      Id = id,
      Errors = {
        {
          key,
          (object) message
        }
      }
    };

    public static SaveResult Failure(long id, string errorMessage, object viewModel) => new SaveResult()
    {
      Id = id,
      ViewModel = viewModel,
      ErrorMessage = errorMessage
    };
  }
}
