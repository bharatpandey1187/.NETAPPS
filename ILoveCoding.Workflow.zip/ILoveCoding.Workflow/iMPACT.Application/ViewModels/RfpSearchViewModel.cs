﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RfpSearchViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RfpSearchViewModel
  {
    public RfpSearchViewModel()
    {
      this.SelectedRfpStatuses = new List<KeyPair>();
      this.SelectedRfpStates = new List<KeyPair>();
      this.SelectedIssuerStates = new List<KeyPair>();
      this.SelectedExpectedFirmRoles = new List<KeyPair>();
      this.SelectedAssignedFirmRoles = new List<KeyPair>();
      this.SelectedMAExemptions = new List<KeyPair>();
      this.SelectedGeneralCategories = new List<KeyPair>();
      this.AdvisorAgents = new List<RfpAdvisorAgent>();
      this.RfpTypes = new List<KeyPair>();
      this.GeneralCategories = new List<KeyValuePair<long, string>>();
      this.MoodyLongTermRatings = new List<KeyPair>();
      this.SPLongTermRatings = new List<KeyPair>();
      this.KrollLongTermRatings = new List<KeyPair>();
      this.FitchLongTermRatings = new List<KeyPair>();
      this.Purposes = new List<KeyPair>();
      this.FirmRoles = new List<KeyValuePair<long, string>>();
      this.MAExemptions = new List<KeyValuePair<long, string>>();
      this.RfpStatuses = new List<KeyValuePair<long, string>>();
      this.States = new List<KeyValuePair<long, string>>();
      this.IsRfpStatusIn = true;
      this.IsIssuerStateIn = true;
      this.IsRfpStateIn = true;
      this.IsExpectedFirmRoleIn = true;
      this.IsAssignedFirmRoleIn = true;
      this.IsMAExemptionIn = true;
      this.IsGeneralCategoryIn = true;
      this.AdvisorAgentType = new List<KeyPair>();
      this.CounselType = new List<KeyPair>();
      this.ExternalPartners = new List<ExternalPartnerSearchModel>();
      this.InternalPartners = new List<InternalPartnerSearchModel>();
      this.AllFields = new List<SearchResultField>();
      this.SelectedAllFields = new List<SearchResultField>();
      this.SelectedFields = new List<SearchResultField>();
      this.FieldsToSelect = new List<SearchResultField>();
    }

    public List<KeyPair> SelectedRfpStatuses { get; set; }

    public bool IsRfpStatusIn { get; set; }

    public string RfpNumber { get; set; }

    public string RfpName { get; set; }

    public string Issuer { get; set; }

    public List<KeyPair> SelectedRfpStates { get; set; }

    public bool IsRfpStateIn { get; set; }

    public List<KeyPair> SelectedIssuerStates { get; set; }

    public bool IsIssuerStateIn { get; set; }

    public string ParAmountFrom { get; set; }

    public string ParAmountTo { get; set; }

    public DateTime? SupervisoryPrincipalReviewDateFrom { get; set; }

    public DateTime? SupervisoryPrincipalReviewDateTo { get; set; }

    public DateTime? SubmissionDateFrom { get; set; }

    public DateTime? SubmissionDateTo { get; set; }

    public DateTime? ResponseDueDateFrom { get; set; }

    public DateTime? ResponseDueDateTo { get; set; }

    public DateTime? CreateDateFrom { get; set; }

    public DateTime? CreateDateTo { get; set; }

    public string RfpType { get; set; }

    public string FedTaxable { get; set; }

    public string StateTaxable { get; set; }

    public List<KeyPair> SelectedExpectedFirmRoles { get; set; }

    public bool IsExpectedFirmRoleIn { get; set; }

    public List<KeyPair> SelectedAssignedFirmRoles { get; set; }

    public bool IsAssignedFirmRoleIn { get; set; }

    public string Purpose { get; set; }

    public string AMTTaxable { get; set; }

    public List<KeyPair> SelectedGeneralCategories { get; set; }

    public bool IsGeneralCategoryIn { get; set; }

    public bool? BankQualified { get; set; }

    public string MoodyLongTermRating { get; set; }

    public string SPLongTermRating { get; set; }

    public string KrollLongTermRating { get; set; }

    public string FitchLongTermRating { get; set; }

    public List<KeyValuePair<long, string>> RfpStatuses { get; set; }

    public List<KeyValuePair<long, string>> States { get; set; }

    public List<KeyPair> RfpTypes { get; set; }

    public List<KeyValuePair<long, string>> FirmRoles { get; set; }

    public List<KeyValuePair<long, string>> MAExemptions { get; set; }

    public List<KeyPair> SelectedMAExemptions { get; set; }

    public bool IsMAExemptionIn { get; set; }

    public List<KeyPair> Purposes { get; set; }

    public List<KeyValuePair<long, string>> GeneralCategories { get; set; }

    public List<KeyPair> MoodyLongTermRatings { get; set; }

    public List<KeyPair> SPLongTermRatings { get; set; }

    public List<KeyPair> KrollLongTermRatings { get; set; }

    public List<KeyPair> FitchLongTermRatings { get; set; }

    public List<KeyPair> AdvisorAgentType { get; set; }

    public List<RfpAdvisorAgent> AdvisorAgents { get; set; }

    public List<InternalPartnerSearchModel> InternalPartners { get; set; }

    public List<ExternalPartnerSearchModel> ExternalPartners { get; set; }

    public List<KeyPair> CounselType { get; set; }

    public List<SearchResultField> AllFields { get; set; }

    public List<SearchResultField> SelectedAllFields { get; set; }

    public List<SearchResultField> SelectedFields { get; set; }

    public List<SearchResultField> FieldsToSelect { get; set; }

    public bool CanCreatePublicBookmark { get; set; }
  }
}
