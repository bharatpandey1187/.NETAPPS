﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CheckListCategoryViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CheckListCategoryViewModel : ViewModelBase
  {
    public CheckListCategoryViewModel()
    {
    }

    public CheckListCategoryViewModel(CheckListCategory checkListCategory)
    {
      this.ChecklistCategoryID = checkListCategory.ChecklistCategoryID;
      this.Category = checkListCategory.Category;
      this.IsActive = checkListCategory.IsActive;
      this.EntityID = checkListCategory.EntityID;
      if (checkListCategory.CheckListCategoryItems != null && checkListCategory.CheckListCategoryItems.ToList<CheckListCategoryItems>().Count > 0)
        this.checkListCategoryItemsViewModel = checkListCategory.CheckListCategoryItems.Select<CheckListCategoryItems, CheckListCategoryItemsViewModel>((Func<CheckListCategoryItems, CheckListCategoryItemsViewModel>) (x => new CheckListCategoryItemsViewModel(x))).ToList<CheckListCategoryItemsViewModel>();
      else
        this.checkListCategoryItemsViewModel = new List<CheckListCategoryItemsViewModel>();
    }

    public CheckListCategory GetCheckListCategory(
      CheckListCategoryViewModel checkListCategoryViewModel)
    {
      return new CheckListCategory()
      {
        ChecklistCategoryID = checkListCategoryViewModel.ChecklistCategoryID,
        EntityID = checkListCategoryViewModel.EntityID,
        Category = checkListCategoryViewModel.Category.Trim(),
        IsActive = checkListCategoryViewModel.IsActive,
        CheckListCategoryItems = checkListCategoryViewModel.checkListCategoryItemsViewModel == null ? new List<CheckListCategoryItems>() : checkListCategoryViewModel.checkListCategoryItemsViewModel.Select<CheckListCategoryItemsViewModel, CheckListCategoryItems>((Func<CheckListCategoryItemsViewModel, CheckListCategoryItems>) (x => x.GetCheckListCategoryItems())).ToList<CheckListCategoryItems>()
      };
    }

    public long ChecklistCategoryID { get; set; }

    [Required(ErrorMessage = "Category name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Category name length should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string Category { get; set; }

    public bool IsActive { get; set; }

    public long EntityID { get; set; }

    public List<CheckListCategoryItemsViewModel> checkListCategoryItemsViewModel { get; set; }
  }
}
