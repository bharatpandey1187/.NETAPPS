﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DisclosureDiligenceRegChecklistViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DisclosureDiligenceRegChecklistViewModel : ViewModelBase
  {
    public long DisclosureDiligenceRegCheckListID { get; set; }

    public long AppTransactionID { get; set; }

    public bool? IsObtainedAndReviwedFinalDoc { get; set; }

    public string TypeOfDocument { get; set; }

    public string DateReceived { get; set; }

    public string DateReviewed { get; set; }

    public string ReasonForNotObtainingOrReviewFinalDoc { get; set; }

    public long? WasDisclosureDocumentAmended { get; set; }

    public DateTime? DocumentAmendedDate { get; set; }

    public bool? IsDueDilegenceReviewConducted { get; set; }

    public bool? IsDueDilegenceCallOrMeeting { get; set; }

    public DateTime? DueDilegenceMeetingDate { get; set; }

    public string DueDilegenceReviewMethod { get; set; }

    public long? DidOutSideCounselDiligence { get; set; }

    public string ReasonForNoDueDiligence { get; set; }

    public bool? HasIssuerObligorCovenanted { get; set; }

    public string IssuerObligorCovenanted { get; set; }

    public string ReasonForNoIssuerObligorCovenanted { get; set; }
  }
}
