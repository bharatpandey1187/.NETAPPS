﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ClientAddressViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ClientAddressViewModel : ViewModelBase
  {
    public ClientAddressViewModel()
    {
    }

    public long AddressID { get; set; }

    public long ClientID { get; set; }

    [StringLength(500, ErrorMessage = "Length of Street Address field for a Client Addres should be less than or equal to 500 characters.")]
    [Required(ErrorMessage = "Street Address cannot be blank.")]
    public string StreetAddress { get; set; }

    [StringLength(100, ErrorMessage = "Length of City field for a Client Addres should be less than or equal to 100 characters.")]
    public string City { get; set; }

    public long? State { get; set; }

    public string StateName { get; set; }

    [StringLength(12, ErrorMessage = "Length of ZIP Code field for a Client should be less than or equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$))", MessageTemplate = "ZIP Code for USA should be XXXXX or XXXXX-XXXX.")]
    public string Zip { get; set; }

    public bool AddressIsActive { get; set; }

    public bool IsDefault { get; set; }

    public string FullClientAddress { get; set; }

    public ClientAddressViewModel(ClientAddress clientAddress)
    {
      this.AddressID = clientAddress.AddressID;
      this.ClientID = clientAddress.ClientID;
      this.StreetAddress = clientAddress.StreetAddress;
      this.City = clientAddress.City;
      this.State = clientAddress.State;
      this.StateName = clientAddress.StateName;
      this.Zip = clientAddress.Zip;
      this.AddressIsActive = clientAddress.IsActive;
      this.IsDefault = clientAddress.IsDefault;
      this.IsDeleted = clientAddress.IsDeleted;
      this.IsDirty = clientAddress.IsDirty;
      this.FullClientAddress = clientAddress.FullClientAddress;
    }

    public ClientAddress GetClientAddress() => new ClientAddress()
    {
      AddressID = this.AddressID,
      ClientID = this.ClientID,
      StreetAddress = this.StreetAddress,
      City = this.City,
      State = this.State,
      StateName = this.StateName,
      Zip = this.Zip,
      IsActive = this.AddressIsActive,
      IsDefault = this.IsDefault,
      IsDeleted = this.IsDeleted,
      IsDirty = this.IsDirty
    };
  }
}
