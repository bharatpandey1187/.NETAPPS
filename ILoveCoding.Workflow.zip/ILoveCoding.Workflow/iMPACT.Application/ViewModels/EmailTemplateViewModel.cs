﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.EmailTemplateViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class EmailTemplateViewModel
  {
    public EmailTemplateViewModel()
    {
    }

    public EmailTemplateViewModel(EmailTemplate emailTemplate)
    {
      this.EmailTemplateID = emailTemplate.EmailTemplateID;
      this.Name = emailTemplate.Name;
      this.Description = emailTemplate.Description;
      this.UIName = emailTemplate.UIName;
    }

    public int EmailTemplateID { get; set; }

    public string Name { get; set; }

    public string UIName { get; set; }

    public string Description { get; set; }
  }
}
