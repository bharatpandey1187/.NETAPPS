﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DocumentSearchResultViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using Microsoft.Practices.Unity;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DocumentSearchResultViewModel
  {
    [InjectionConstructor]
    public DocumentSearchResultViewModel()
    {
    }

    public long EntityDocSetDocumentID { get; set; }

    public string AppTransactionID { get; set; }

    public string EntityTypeID { get; set; }

    public string DealNumber { get; set; }

    public string DealName { get; set; }

    public string DealIssuer { get; set; }

    public string DealIssuerName { get; set; }

    public string DealBorrowerName { get; set; }

    public string JobNumbers { get; set; }

    public string MSBankingGroup { get; set; }

    public string CategoryName { get; set; }

    public string TransactionDescription { get; set; }

    public string OpportunityDescription { get; set; }

    public string DealStatus { get; set; }

    public string DealFirmRole { get; set; }

    public Decimal? ParAmount { get; set; }

    public string DocumentName { get; set; }

    public string DocumentUrl { get; set; }

    public string DocumentType { get; set; }

    public string DocumentRepository { get; set; }

    public string Repository { get; set; }

    public DateTime UploadDate { get; set; }

    public string SourceLocation { get; set; }

    public string UploadDateString => this.UploadDate != DateTime.MinValue ? this.UploadDate.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;
  }
}
