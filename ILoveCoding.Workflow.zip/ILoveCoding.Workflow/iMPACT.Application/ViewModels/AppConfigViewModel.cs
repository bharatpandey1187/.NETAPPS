﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.AppConfigViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using Microsoft.Practices.Unity;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class AppConfigViewModel : ViewModelBase
  {
    [Dependency]
    public IUser AppUser { get; set; }

    public AppConfigViewModel()
    {
    }

    public AppConfigViewModel(AppConfig appConfig)
    {
      this.AppConfigID = appConfig.AppConfigID;
      this.Key = appConfig.Key;
      this.Value = appConfig.Value;
      this.Descr = appConfig.Descr;
      this.ModifiedBy = this.AppUser == null ? appConfig.ModifiedBy : this.AppUser.Name;
      this.AppConfigIsViewOnly = false;
      this.Type = appConfig.Type.Trim().ToLower();
    }

    public AppConfig GetAppConfigItem() => new AppConfig()
    {
      AppConfigID = this.AppConfigID,
      Value = this.Value,
      Descr = this.Descr,
      ModifiedBy = this.AppUser == null ? this.ModifiedBy : this.AppUser.Name,
      Type = this.Type.Trim().ToLower()
    };

    public bool AppConfigIsViewOnly { get; set; }

    [Required(ErrorMessage = "AppConfig Id is required.")]
    public long AppConfigID { get; set; }

    public string Key { get; set; }

    [StringLength(1000, ErrorMessage = "Value length cannot be greater than 1000 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string Value { get; set; }

    public string Descr { get; set; }

    public string ModifiedBy { get; set; }

    public string Type { get; set; }
  }
}
