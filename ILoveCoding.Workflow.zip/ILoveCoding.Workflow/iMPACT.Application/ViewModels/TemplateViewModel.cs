﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.TemplateViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class TemplateViewModel : ViewModelBase
  {
    public TemplateViewModel()
    {
    }

    public TemplateViewModel(Template template)
    {
      this.TemplateID = template.TemplateID;
      this.EntityID = template.EntityID;
      this.WithEffectFrom = template.WithEffectFrom;
      this.TemplateName = template.TemplateName;
      this.CreatedBy = template.CreatedBy;
      this.CreatedDate = template.CreatedDate;
      this.ModeifiedBy = template.ModeifiedBy;
      this.ModifiedDate = template.ModifiedDate;
    }

    public Template GetTemplate(TemplateViewModel checkListTemplateViewModel) => new Template()
    {
      TemplateID = checkListTemplateViewModel.TemplateID,
      EntityID = checkListTemplateViewModel.EntityID,
      WithEffectFrom = checkListTemplateViewModel.WithEffectFrom,
      TemplateName = checkListTemplateViewModel.TemplateName,
      CreatedBy = checkListTemplateViewModel.CreatedBy,
      CreatedDate = checkListTemplateViewModel.CreatedDate,
      ModeifiedBy = checkListTemplateViewModel.ModeifiedBy,
      ModifiedDate = checkListTemplateViewModel.ModifiedDate
    };

    public long TemplateID { get; set; }

    public long EntityID { get; set; }

    public DateTime WithEffectFrom { get; set; }

    public string TemplateName { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string ModeifiedBy { get; set; }

    public DateTime ModifiedDate { get; set; }

    public long CopyTemplateID { get; set; }
  }
}
