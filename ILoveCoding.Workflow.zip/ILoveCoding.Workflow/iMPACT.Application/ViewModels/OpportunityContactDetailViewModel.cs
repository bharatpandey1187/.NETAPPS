﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.OpportunityContactDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class OpportunityContactDetailViewModel
  {
    public OpportunityContactDetailViewModel()
    {
    }

    public OpportunityContactDetailViewModel(Opportunity oppty)
    {
      this.AdvisorMemberContact = oppty.OpportunityContact != null ? oppty.OpportunityContact.Where<IssueContact>((Func<IssueContact, bool>) (x => x.ContactType == 7L)).OrderBy<IssueContact, string>((Func<IssueContact, string>) (x => x.CompanyName)).ThenBy<IssueContact, string>((Func<IssueContact, string>) (x => x.PartnerType)).ThenBy<IssueContact, string>((Func<IssueContact, string>) (x => x.Name)).ToList<IssueContact>() : new List<IssueContact>();
      this.CounselMemberContact = oppty.OpportunityContact != null ? oppty.OpportunityContact.Where<IssueContact>((Func<IssueContact, bool>) (x => x.ContactType == 8L)).OrderBy<IssueContact, string>((Func<IssueContact, string>) (x => x.CompanyName)).ThenBy<IssueContact, string>((Func<IssueContact, string>) (x => x.PartnerType)).ThenBy<IssueContact, string>((Func<IssueContact, string>) (x => x.Name)).ToList<IssueContact>() : new List<IssueContact>();
      this.IssuerMemberContact = oppty.OpportunityContact != null ? oppty.OpportunityContact.Where<IssueContact>((Func<IssueContact, bool>) (x => x.MemberTypeName == string.Empty && x.PartnerType == "Issuer")).OrderBy<IssueContact, string>((Func<IssueContact, string>) (x => x.Name)).ToList<IssueContact>() : new List<IssueContact>();
      this.BorrowerMemberContact = oppty.OpportunityContact != null ? oppty.OpportunityContact.Where<IssueContact>((Func<IssueContact, bool>) (x => x.MemberTypeName == string.Empty && x.PartnerType == "Borrower")).OrderBy<IssueContact, string>((Func<IssueContact, string>) (x => x.Name)).ToList<IssueContact>() : new List<IssueContact>();
      this.GuarantorMemberContact = oppty.OpportunityContact != null ? oppty.OpportunityContact.Where<IssueContact>((Func<IssueContact, bool>) (x => x.MemberTypeName == string.Empty && x.PartnerType == "Guarantor")).OrderBy<IssueContact, string>((Func<IssueContact, string>) (x => x.Name)).ToList<IssueContact>() : new List<IssueContact>();
      this.SyndicateMemberContact = oppty.OpportunityContact != null ? oppty.OpportunityContact.Where<IssueContact>((Func<IssueContact, bool>) (x => x.ContactType == 6L)).OrderBy<IssueContact, string>((Func<IssueContact, string>) (x => x.CompanyName)).ThenBy<IssueContact, string>((Func<IssueContact, string>) (x => x.PartnerType)).ThenBy<IssueContact, string>((Func<IssueContact, string>) (x => x.Name)).ToList<IssueContact>() : new List<IssueContact>();
    }

    public long AppTransactionID { get; set; }

    public List<IssueContact> AdvisorMemberContact { get; set; }

    public List<IssueContact> CounselMemberContact { get; set; }

    public List<IssueContact> IssuerMemberContact { get; set; }

    public List<IssueContact> BorrowerMemberContact { get; set; }

    public List<IssueContact> GuarantorMemberContact { get; set; }

    public List<IssueContact> SyndicateMemberContact { get; set; }
  }
}
