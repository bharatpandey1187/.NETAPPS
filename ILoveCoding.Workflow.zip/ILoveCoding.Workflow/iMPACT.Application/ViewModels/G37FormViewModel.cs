﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.G37FormViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  [HasSelfValidation]
  public class G37FormViewModel : ViewModelBase
  {
    public G37FormViewModel()
    {
    }

    public G37FormViewModel(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public G37FormViewModel(G37Form g37Form)
    {
      this.AppTransactionID = g37Form.AppTransactionID;
      this.ParentAppTransactionID = g37Form.ParentAppTransactionID;
      this.CompBid = g37Form.CompBid.ToString();
      this.NegoBid = g37Form.NegoBid.ToString();
      this.PrivatePlacementBid = g37Form.PrivatePlacementBid.ToString();
      this.Cusip = g37Form.Cusip;
      this.Description = g37Form.Description;
      this.EsmtCheck = g37Form.EsmtCheck;
      this.AcctClosedDate = g37Form.AcctClosedDate;
      this.ActualAwardDateTime = g37Form.ActualAwardDateTime;
      this.OrdRetail = g37Form.OrdRetail;
      this.OrdPreSale = g37Form.OrdPreSale;
      this.OrdNetDesig = g37Form.OrdNetDesig;
      this.OrdGroupNet = g37Form.OrdGroupNet;
      this.OrdMember = g37Form.OrdMember;
      this.Deviation = g37Form.Deviation;
      this.CusipFee = g37Form.CusipFee;
      this.IpreoFee = g37Form.IpreoFee;
      this.InsuranceFee = g37Form.InsuranceFee;
      this.MacFee = g37Form.MacFee;
      this.BondCounselFee = g37Form.BondCounselFee;
      this.SetUpBy = g37Form.SetUpBy;
      this.SetUpDate = g37Form.SetUpDate;
      this.G37status = g37Form.G37Status;
      this.Version = g37Form.Version;
    }

    public long AppTransactionID { get; set; }

    [Range(1.0, 9.22337203685478E+18, ErrorMessage = "Invalid request.")]
    public long ParentAppTransactionID { get; set; }

    public string CompBid { get; set; }

    public string NegoBid { get; set; }

    public string PrivatePlacementBid { get; set; }

    public string Cusip { get; set; }

    [StringLength(3000, ErrorMessage = "Description field length should be less than or equal to 3000 characters.")]
    public string Description { get; set; }

    public int FirmRole { get; set; }

    public Decimal? ParAmount { get; set; }

    public Decimal? FirmLiabilityPerc { get; set; }

    [Range(0.0, 1.79769313486232E+308, ErrorMessage = "Invalid EsmtCheck value.")]
    public Decimal? EsmtCheck { get; set; }

    public DateTime? AcctClosedDate { get; set; }

    public DateTime? ActualAwardDateTime { get; set; }

    [Range(0, 255, ErrorMessage = "Invalid retail value.")]
    public byte? OrdRetail { get; set; }

    [Range(0, 255, ErrorMessage = "Invalid pre-sale value.")]
    public byte? OrdPreSale { get; set; }

    [Range(0, 255, ErrorMessage = "Invalid net designated value.")]
    public byte? OrdNetDesig { get; set; }

    [Range(0, 255, ErrorMessage = "Invalid group net value.")]
    public byte? OrdGroupNet { get; set; }

    [Range(0, 255, ErrorMessage = "Invalid member value.")]
    public byte? OrdMember { get; set; }

    [StringLength(1024, ErrorMessage = "Deviations field length should be less than or equal to 1024 characters.")]
    public string Deviation { get; set; }

    [Range(0.0, 1.79769313486232E+308, ErrorMessage = "Invalid CUSIP value.")]
    public Decimal? CusipFee { get; set; }

    [Range(0.0, 1.79769313486232E+308, ErrorMessage = "Invalid ipreo value.")]
    public Decimal? IpreoFee { get; set; }

    [Range(0.0, 1.79769313486232E+308, ErrorMessage = "Invalid Insurance value.")]
    public Decimal? InsuranceFee { get; set; }

    [Range(0.0, 1.79769313486232E+308, ErrorMessage = "Invalid MAC value.")]
    public Decimal? MacFee { get; set; }

    [Range(0.0, 1.79769313486232E+308, ErrorMessage = "Invalid Bond Counsel value.")]
    public Decimal? BondCounselFee { get; set; }

    public string SetUpBy { get; set; }

    public DateTime? SetUpDate { get; set; }

    public List<long> Issuestatus { get; set; }

    public List<long> G37status { get; set; }

    public string CommaSeperatedStateID { get; set; }

    public string CommaSeperatedIssueStateID { get; set; }

    public string G37StatusValue { get; set; }

    public string[] Actions { get; set; }

    public bool IsViewOnly { get; set; }

    public bool CanSaveG37Form { get; set; }

    public bool CanSubmitG37Form { get; set; }

    public long Version { get; set; }

    public List<G37SyndicateMemberViewModel> SyndicateMembers { get; set; }

    public List<AppTransactionStateTransition> WorkflowStateTransitions { get; set; }
  }
}
