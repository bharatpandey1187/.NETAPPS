﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssuePricingViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssuePricingViewModel : ViewModelBase
  {
    public IssuePricingViewModel()
    {
      this.SecTypesDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.SecTypesSpecificDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.AccrueFormDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FormDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.DayCountDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.CallFeatureDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.SeriesDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.IssuerPricing = new List<PricingViewModel>();
      this.CouponFreqencyDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.PricingStatuses = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.PricingStatus = new LookupItemMappings();
      this.PrincipalFreqencyDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.PriorityOfOrderDetails = (IEnumerable<PriorityOfOrderDetail>) new List<PriorityOfOrderDetail>();
      this.SeriesDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.IssuerPricing = new List<PricingViewModel>();
      this.PriorityOfOrdersDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FedTaxDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FirmRole = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
    }

    public IssuePricingViewModel(List<LookupItemMappings> lookupItems)
    {
      this.SecTypesDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Security Type (General)"));
      this.SecTypesSpecificDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Security Type (Specific)")).ToList<LookupItemMappings>().OrderBy<LookupItemMappings, long>((Func<LookupItemMappings, long>) (m => m.LookupItemID)).ToList<LookupItemMappings>();
      this.AccrueFormDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Pricing Accrue From"));
      this.FormDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Pricing Form"));
      this.DayCountDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Day Count"));
      this.CallFeatureDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Call Feature"));
      this.CouponFreqencyDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Coupon Frequency"));
      this.PricingStatuses = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Pricing Status"));
      this.PrincipalFreqencyDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Principal Freq"));
      this.PriorityOfOrdersDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Syndicate Structure".Trim().ToLower()));
      this.FirmRole = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Firm Role".Trim().ToLower()));
      this.SeriesDataSource = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.IssuerPricing = new List<PricingViewModel>();
    }

    public void InitializeLookupItems(List<LookupItemMappings> lookupItems)
    {
      this.SecTypesDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Security Type (General)"));
      this.SecTypesSpecificDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Security Type (Specific)")).ToList<LookupItemMappings>().OrderBy<LookupItemMappings, long>((Func<LookupItemMappings, long>) (m => m.LookupItemID)).ToList<LookupItemMappings>();
      this.AccrueFormDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Pricing Accrue From"));
      this.FormDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Pricing Form"));
      this.DayCountDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Day Count"));
      this.RateTypeDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Interest Rate Type"));
      this.CallFeatureDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Call Feature"));
      this.InsuranceDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Insurance"));
      this.CouponFreqencyDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Coupon Frequency"));
      this.PricingStatuses = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Pricing Status"));
      this.PrincipalFreqencyDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Principal Freq"));
      this.PriorityOfOrdersDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Syndicate Structure".Trim().ToLower()));
      this.FedTaxDataSource = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Fed Tax".Trim().ToLower()));
      this.FirmRole = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Firm Role".Trim().ToLower()));
    }

    public LookupItemMappings PricingStatus { get; set; }

    public IEnumerable<LookupItemMappings> SecTypesDataSource { get; set; }

    public IEnumerable<LookupItemMappings> SecTypesSpecificDataSource { get; set; }

    public IEnumerable<LookupItemMappings> AccrueFormDataSource { get; set; }

    public IEnumerable<LookupItemMappings> FormDataSource { get; set; }

    public IEnumerable<LookupItemMappings> DayCountDataSource { get; set; }

    public IEnumerable<LookupItemMappings> RateTypeDataSource { get; set; }

    public IEnumerable<LookupItemMappings> CallFeatureDataSource { get; set; }

    public IEnumerable<LookupItemMappings> InsuranceDataSource { get; set; }

    public IEnumerable<LookupItemMappings> SeriesDataSource { get; set; }

    public IEnumerable<LookupItemMappings> CouponFreqencyDataSource { get; set; }

    public IEnumerable<LookupItemMappings> PricingStatuses { get; set; }

    public IEnumerable<LookupItemMappings> PrincipalFreqencyDataSource { get; set; }

    public IEnumerable<LookupItemMappings> PriorityOfOrdersDataSource { get; set; }

    public IEnumerable<LookupItemMappings> FedTaxDataSource { get; set; }

    public IEnumerable<LookupItemMappings> FirmRole { get; set; }

    public IEnumerable<PriorityOfOrderDetail> PriorityOfOrderDetails { get; set; }

    public List<PricingViewModel> IssuerPricing { get; set; }

    public bool isPricingViewOnly { get; set; }

    public bool isSubmitPricing { get; set; }

    public bool isSendPricingEmailCalculated { get; set; }

    public bool isSendPricingEmail { get; set; }
  }
}
