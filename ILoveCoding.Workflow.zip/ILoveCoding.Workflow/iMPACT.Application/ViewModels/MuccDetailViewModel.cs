﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MuccDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MuccDetailViewModel : ViewModelBase
  {
    public MuccDetailViewModel()
    {
    }

    public MuccDetailViewModel(Mucc mucc)
    {
      this.AppTransactionID = mucc.MuccDetail.AppTransactionID;
      this.SyndicateCompensation = mucc.MuccDetail.SyndicateCompensation;
      this.MSSwapExposure = mucc.MuccDetail.MSSwapExposure;
      this.AgreedUponProceduresLetter = mucc.MuccDetail.AgreedUponProceduresLetter;
      this.StatusofDiligenceReview = mucc.MuccDetail.StatusofDiligenceReview;
      this.StatusofRegulatoryChecklist = mucc.MuccDetail.StatusofRegulatoryChecklist;
      this.LegalOptions = mucc.MuccDetail.LegalOptions;
      this.Covenants = mucc.MuccDetail.Covenants;
      this.KeyIssuesforMUCCConsideration = mucc.MuccDetail.KeyIssuesforMUCCConsideration;
      this.MorganStanleyRelationship = mucc.MuccDetail.MorganStanleyRelationship;
      this.IssuerBorrowerOverviewandCreditSummary = mucc.MuccDetail.IssuerBorrowerOverviewandCreditSummary;
      this.MaterialEventsandPotentialInvestorConcerns = mucc.MuccDetail.MaterialEventsandPotentialInvestorConcerns;
      this.FinancialInformation = mucc.MuccDetail.FinancialInformation;
      this.MuccManagementFee = mucc.MuccDetail.MuccManagementFee;
      this.MuccAverageTakedown = mucc.MuccDetail.MuccAverageTakedown;
      this.MuccExpenses = mucc.MuccDetail.MuccExpenses;
      this.AdditionalFeeDetail = mucc.MuccDetail.AdditionalFeeDetail;
      this.IsViewOnly = mucc.MuccDetail.IsViewOnly;
      this.CanSaveMuccChecklist = mucc.MuccDetail.CanSaveMuccChecklist;
    }

    public MuccDetailViewModel(CompetitiveMucc mucc)
    {
      this.AppTransactionID = mucc.MuccDetail.AppTransactionID;
      this.SyndicateCompensation = mucc.MuccDetail.SyndicateCompensation;
      this.MSSwapExposure = mucc.MuccDetail.MSSwapExposure;
      this.AgreedUponProceduresLetter = mucc.MuccDetail.AgreedUponProceduresLetter;
      this.StatusofDiligenceReview = mucc.MuccDetail.StatusofDiligenceReview;
      this.StatusofRegulatoryChecklist = mucc.MuccDetail.StatusofRegulatoryChecklist;
      this.LegalOptions = mucc.MuccDetail.LegalOptions;
      this.Covenants = mucc.MuccDetail.Covenants;
      this.KeyIssuesforMUCCConsideration = mucc.MuccDetail.KeyIssuesforMUCCConsideration;
      this.MorganStanleyRelationship = mucc.MuccDetail.MorganStanleyRelationship;
      this.IssuerBorrowerOverviewandCreditSummary = mucc.MuccDetail.IssuerBorrowerOverviewandCreditSummary;
      this.MaterialEventsandPotentialInvestorConcerns = mucc.MuccDetail.MaterialEventsandPotentialInvestorConcerns;
      this.FinancialInformation = mucc.MuccDetail.FinancialInformation;
      this.MuccManagementFee = mucc.MuccDetail.MuccManagementFee;
      this.MuccAverageTakedown = mucc.MuccDetail.MuccAverageTakedown;
      this.MuccExpenses = mucc.MuccDetail.MuccExpenses;
      this.AdditionalFeeDetail = mucc.MuccDetail.AdditionalFeeDetail;
      this.IsViewOnly = mucc.MuccDetail.IsViewOnly;
      this.CanSaveMuccChecklist = mucc.MuccDetail.CanSaveMuccChecklist;
    }

    public Mucc GetMuccDetail(MuccDetailViewModel muccDetailViewModel) => new Mucc();

    public long AppTransactionID { get; set; }

    public string SyndicateCompensation { get; set; }

    public string MSSwapExposure { get; set; }

    public string AgreedUponProceduresLetter { get; set; }

    public string StatusofDiligenceReview { get; set; }

    public string StatusofRegulatoryChecklist { get; set; }

    public string LegalOptions { get; set; }

    public string Covenants { get; set; }

    public string KeyIssuesforMUCCConsideration { get; set; }

    public string MorganStanleyRelationship { get; set; }

    public string IssuerBorrowerOverviewandCreditSummary { get; set; }

    public string MaterialEventsandPotentialInvestorConcerns { get; set; }

    public string FinancialInformation { get; set; }

    public string AdditionalFeeDetail { get; set; }

    public Decimal? MuccManagementFee { get; set; }

    public Decimal? MuccAverageTakedown { get; set; }

    public Decimal? MuccExpenses { get; set; }

    public bool IsViewOnly { get; set; }

    public bool CanSaveMuccChecklist { get; set; }
  }
}
