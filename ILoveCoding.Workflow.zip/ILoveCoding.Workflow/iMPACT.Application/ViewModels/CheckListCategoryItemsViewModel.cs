﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CheckListCategoryItemsViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CheckListCategoryItemsViewModel : ViewModelBase
  {
    public CheckListCategoryItemsViewModel()
    {
    }

    public CheckListCategoryItemsViewModel(CheckListCategoryItems checkListCategoryItems)
    {
      this.ChecklistItemID = new long?(checkListCategoryItems.ChecklistItemID);
      this.ChecklistCategoryID = checkListCategoryItems.ChecklistCategoryID;
      this.CategoryItemDescription = checkListCategoryItems.CategoryItemDescription.Trim();
      this.IsActive = checkListCategoryItems.IsActive;
      this.ItemOrder = checkListCategoryItems.ItemOrder;
      this.IsActive = checkListCategoryItems.IsActive;
    }

    public CheckListCategoryItems GetCheckListCategoryItems() => new CheckListCategoryItems()
    {
      ChecklistItemID = this.ChecklistItemID ?? 0L,
      ChecklistCategoryID = this.ChecklistCategoryID,
      CategoryItemDescription = this.CategoryItemDescription.Trim(),
      IsActive = this.IsActive,
      ItemOrder = this.ItemOrder
    };

    public long? ChecklistItemID { get; set; }

    [Range(0.0, 9.22337203685478E+18, ErrorMessage = "Value for {0} must be between {1} and {2}.")]
    public long ChecklistCategoryID { get; set; }

    [Required(ErrorMessage = "Category item description cannot be blank.")]
    [StringLength(256, ErrorMessage = "Category item description should be less than or equal to 256 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string CategoryItemDescription { get; set; }

    public int ItemOrder { get; set; }

    public bool IsActive { get; set; }
  }
}
