﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.BankerViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class BankerViewModel : ViewModelBase
  {
    public long AppTransactionID { get; set; }

    public string IssueNumber { get; set; }

    public string IssueName { get; set; }

    public string Issuer { get; set; }

    public string TypeOfOffering { get; set; }

    public Decimal? GoodFaithAmount { get; set; }

    [AbsoluteDate]
    public DateTime? GoodFaithDate { get; set; }

    public string State { get; set; }

    public string WireInfo { get; set; }

    public string GoodFaithInstructions { get; set; }

    public string AccountName { get; set; }

    public string AccountNumber { get; set; }

    public string ABANumber { get; set; }

    public string Notes { get; set; }

    public string GoodFaithType { get; set; }

    public bool IsGoodFaithViewReadOnly { get; set; }
  }
}
