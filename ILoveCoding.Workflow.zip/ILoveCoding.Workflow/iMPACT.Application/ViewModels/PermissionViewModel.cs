﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PermissionViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PermissionViewModel
  {
    public PermissionViewModel()
    {
    }

    public PermissionViewModel(Permission permission)
    {
      this.PermissionID = permission.PermissionID;
      this.Descr = permission.Descr;
      this.GroupName = permission.GroupName;
      this.ItemOrder = permission.ItemOrder;
    }

    public long PermissionID { get; set; }

    public string Descr { get; set; }

    public string GroupName { get; set; }

    public int ItemOrder { get; set; }

    public bool Selected { get; set; }
  }
}
