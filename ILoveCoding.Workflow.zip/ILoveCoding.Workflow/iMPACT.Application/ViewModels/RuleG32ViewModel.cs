﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RuleG32ViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RuleG32ViewModel
  {
    public long RuleG32RegCheckListID { get; set; }

    public bool? IsOfficialStatementPostedToEMMA { get; set; }

    [AbsoluteDate]
    public DateTime? OfficialStatementDate { get; set; }

    public string ReasonForNoPosting { get; set; }

    public long? IsEscrowfiledWithMSRB { get; set; }

    [AbsoluteDate]
    public DateTime? AggrementPostedDate { get; set; }

    public string ReasonForNoEscrowAggrement { get; set; }

    public long AppTransactionID { get; set; }

    public string G32SubmissionDateTimeZone { get; set; }
  }
}
