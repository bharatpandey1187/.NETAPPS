﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.KendoGridRequest
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public sealed class KendoGridRequest
  {
    public KendoGridRequest()
    {
      this.group = new KendoGridRequest.GroupObject[0];
      this.skip = (short) 0;
      this.take = 1000;
      this.page = 1;
      this.sort = new KendoGridRequest.SortObject[0];
      this.filter = new KendoGridRequest.FilterObject();
      this.columns = new KendoGridRequest.ColumnObject[0];
    }

    public KendoGridRequest request
    {
      set
      {
        this.group = value.group;
        this.skip = value.skip;
        this.take = value.take;
        this.sort = value.sort;
        this.filter = value.filter;
        this.columns = value.columns;
      }
    }

    public KendoGridRequest.GroupObject[] group { get; set; }

    public short skip { get; set; }

    public int take { get; set; }

    public int page { get; set; }

    public KendoGridRequest.SortObject[] sort { get; set; }

    public KendoGridRequest.FilterObject filter { get; set; }

    public KendoGridRequest.ColumnObject[] columns { get; set; }

    public sealed class ColumnObject
    {
      public string title { get; set; }

      public string field { get; set; }

      public string width { get; set; }

      public bool hidden { get; set; }

      public string format { get; set; }
    }

    public sealed class FilterObject
    {
      public FilterObject() => this.filters = new KendoGridRequest.FilterObject[0];

      public KendoGridRequest.FilterObject[] filters { get; set; }

      public string logic { get; set; }

      public string field { get; set; }

      public string @operator { get; set; }

      public string value { get; set; }
    }

    public sealed class GroupObject
    {
      public string field { get; set; }

      public string dir { get; set; }
    }

    public sealed class SortObject
    {
      public string field { get; set; }

      public string dir { get; set; }
    }
  }
}
