﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueSearchViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueSearchViewModel : ViewModelBase
  {
    public IssueSearchViewModel()
    {
      this.SelectedPnLStatuses = new List<KeyPair>();
      this.SelectedIssueStatuses = new List<KeyPair>();
      this.SelectedIssueStates = new List<KeyPair>();
      this.SelectedIssuerStates = new List<KeyPair>();
      this.SelectedFirmRoles = new List<KeyPair>();
      this.SelectedGeneralCategories = new List<KeyPair>();
      this.SelectedTypeOfOffering = new List<KeyPair>();
      this.SelectedPriorityOfOrder = new List<KeyPair>();
      this.SelectedMAExemptions = new List<KeyPair>();
      this.SelectedTypeOfOffering = new List<KeyPair>();
      this.SelectedIssuerStates = new List<KeyPair>();
      this.SelectedIssueStates = new List<KeyPair>();
      this.SelectedFirmRoles = new List<KeyPair>();
      this.CallFeatures = new List<KeyPair>();
      this.MoodyLongTermRatings = new List<KeyPair>();
      this.SPLongTermRatings = new List<KeyPair>();
      this.FitchLongTermRatings = new List<KeyPair>();
      this.KrollLongTermRatings = new List<KeyPair>();
      this.InsuranceProviders = new List<KeyPair>();
      this.GeneralCategories = new List<KeyPair>();
      this.SyndicateMemberType = new List<KeyPair>();
      this.AdvisorAgentType = new List<KeyPair>();
      this.CounselType = new List<KeyPair>();
      this.OtherPartnerType = new List<KeyPair>();
      this.PriorityOfOrders = new List<KeyPair>();
      this.FedTaxs = new List<KeyPair>();
      this.IssueStatuses = new List<KeyValuePair<long, string>>();
      this.States = new List<KeyValuePair<long, string>>();
      this.MAExemptions = new List<KeyValuePair<long, string>>();
      this.FirmRoles = new List<KeyValuePair<long, string>>();
      this.TypeOfOfferings = new List<KeyValuePair<long, string>>();
      this.Purposes = new List<KeyValuePair<long, string>>();
      this.DealTypes = new List<KeyValuePair<long, string>>();
      this.UseOfProceeds = new List<KeyValuePair<long, string>>();
      this.InterestRateTypes = new List<KeyValuePair<long, string>>();
      this.PnLStatuses = new List<KeyValuePair<long, string>>();
      this.CrossSells = new List<KeyValuePair<long, string>>();
      this.InternalPartners = new List<InternalPartnerSearchModel>();
      this.ExternalPartners = new List<ExternalPartnerSearchModel>();
      this.AllFields = new List<SearchResultField>();
      this.SelectedAllFields = new List<SearchResultField>();
      this.SelectedFields = new List<SearchResultField>();
      this.FieldsToSelect = new List<SearchResultField>();
      this.IsIssueStatusIn = true;
      this.IsPnLStatusIn = true;
      this.IsIssueStateIn = true;
      this.IsIssuerStateIn = true;
      this.IsFirmRoleIn = true;
      this.IsGeneralCategoryIn = true;
      this.IsTypeOfOfferingIn = true;
      this.IsPriorityOfOrderIn = true;
      this.IsMAExemptionIn = true;
    }

    [AbsoluteDate]
    public DateTime? PricingDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? PricingDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? ActualAwardDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? ActualAwardDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? SettlementDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? SettlementDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? DatedDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? DatedDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? G37SettlementDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? G37SettlementDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? CallDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? CallDateTo { get; set; }

    [AbsoluteDate]
    public DateTime? DateHiredFrom { get; set; }

    [AbsoluteDate]
    public DateTime? DateHiredTo { get; set; }

    public DateTime? CreateDateFrom { get; set; }

    public DateTime? CreateDateTo { get; set; }

    public DateTime? ROPDate { get; set; }

    public long? DealTypeID { get; set; }

    public long? TransactionTypeID { get; set; }

    public long? InterestRateTypeID { get; set; }

    public long? CrossSellID { get; set; }

    public string BorrowerName { get; set; }

    public string JobNumber { get; set; }

    public string ParAmountFrom { get; set; }

    public string ParAmountTo { get; set; }

    public string Purpose { get; set; }

    public string FedTax { get; set; }

    public string StateTaxable { get; set; }

    public string AMTTaxable { get; set; }

    public string CEProvider { get; set; }

    public string CEProviderName { get; set; }

    public string IssueSetupBy { get; set; }

    public string CallFeature { get; set; }

    public string MoodyLongTermRating { get; set; }

    public string SPLongTermRating { get; set; }

    public string KrollLongTermRating { get; set; }

    public string FitchLongTermRating { get; set; }

    public string InsuranceProvider { get; set; }

    public string IssueNumber { get; set; }

    public string IssueName { get; set; }

    public string IssuerName { get; set; }

    public bool ShowRevenue { get; set; }

    public bool IsMAExemptionIn { get; set; }

    public bool IsGeneralCategoryIn { get; set; }

    public bool IsPriorityOfOrderIn { get; set; }

    public bool IsTypeOfOfferingIn { get; set; }

    public bool? BankQualified { get; set; }

    public bool IsFirmRoleIn { get; set; }

    public bool IsPnLStatusIn { get; set; }

    public bool CanCreatePublicBookmark { get; set; }

    public DateTime? OSDeemedFinalDate { get; set; }

    public bool IsIssueStateIn { get; set; }

    public bool IsIssuerStateIn { get; set; }

    public bool IsIssueStatusIn { get; set; }

    public List<KeyValuePair<long, string>> IssueStatuses { get; set; }

    public List<KeyValuePair<long, string>> States { get; set; }

    public List<KeyValuePair<long, string>> FirmRoles { get; set; }

    public List<KeyValuePair<long, string>> MAExemptions { get; set; }

    public List<KeyValuePair<long, string>> TypeOfOfferings { get; set; }

    public List<KeyValuePair<long, string>> Purposes { get; set; }

    public List<KeyValuePair<long, string>> DealTypes { get; set; }

    public List<KeyValuePair<long, string>> UseOfProceeds { get; set; }

    public List<KeyValuePair<long, string>> InterestRateTypes { get; set; }

    public List<KeyValuePair<long, string>> PnLStatuses { get; set; }

    public List<KeyValuePair<long, string>> CrossSells { get; set; }

    public List<KeyPair> SelectedIssueStatuses { get; set; }

    public List<KeyPair> SelectedGeneralCategories { get; set; }

    public List<KeyPair> SelectedPriorityOfOrder { get; set; }

    public List<KeyPair> SelectedMAExemptions { get; set; }

    public List<KeyPair> MoodyLongTermRatings { get; set; }

    public List<KeyPair> SPLongTermRatings { get; set; }

    public List<KeyPair> KrollLongTermRatings { get; set; }

    public List<KeyPair> FitchLongTermRatings { get; set; }

    public List<KeyPair> InsuranceProviders { get; set; }

    public List<KeyPair> GeneralCategories { get; set; }

    public List<KeyPair> SyndicateMemberType { get; set; }

    public List<KeyPair> WinningSyndicateMemberType { get; set; }

    public List<KeyPair> AdvisorAgentType { get; set; }

    public List<KeyPair> CounselType { get; set; }

    public List<KeyPair> OtherPartnerType { get; set; }

    public List<KeyPair> PriorityOfOrders { get; set; }

    public List<KeyPair> CallFeatures { get; set; }

    public List<KeyPair> FedTaxs { get; set; }

    public List<KeyPair> SelectedPnLStatuses { get; set; }

    public List<KeyPair> SelectedTypeOfOffering { get; set; }

    public List<KeyPair> SelectedIssuerStates { get; set; }

    public List<KeyPair> SelectedIssueStates { get; set; }

    public List<KeyPair> SelectedFirmRoles { get; set; }

    public List<InternalPartnerSearchModel> InternalPartners { get; set; }

    public List<ExternalPartnerSearchModel> ExternalPartners { get; set; }

    public List<SearchResultField> AllFields { get; set; }

    public List<SearchResultField> SelectedAllFields { get; set; }

    public List<SearchResultField> SelectedFields { get; set; }

    public List<SearchResultField> FieldsToSelect { get; set; }

    public bool? AttributionReviewed { get; set; }
  }
}
