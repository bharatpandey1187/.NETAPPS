﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DealFileChecklistViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DealFileChecklistViewModel : ViewModelBase
  {
    public DealFileChecklistViewModel()
    {
    }

    public DealFileChecklistViewModel(DealFileChecklist DealChecklist)
    {
      this.AppTransactionID = DealChecklist.DealFileChecklistDetail.AppTransactionID;
      this.DealFileChecklistID = DealChecklist.DealFileChecklistDetail.DealFileChecklistID;
      this.DueDiligenceReviewStatus = DealChecklist.DealFileChecklistDetail.DueDiligenceReviewStatus;
      this.ReviewDate = DealChecklist.DealFileChecklistDetail.ReviewDate;
      this.ReviewingPersonnel = DealChecklist.DealFileChecklistDetail.ReviewingPersonnel;
      this.PreliminaryOfficialStatementStatus = DealChecklist.DealFileChecklistDetail.PreliminaryOfficialStatementStatus;
      this.FinalOfficialStatementStatus = DealChecklist.DealFileChecklistDetail.FinalOfficialStatementStatus;
      this.EvidenceFilingStatus = DealChecklist.DealFileChecklistDetail.EvidenceFilingStatus;
      this.ContinuingDisclosureUndertakingStatus = DealChecklist.DealFileChecklistDetail.ContinuingDisclosureUndertakingStatus;
      this.NoticeofSaleStatus = DealChecklist.DealFileChecklistDetail.NoticeofSaleStatus;
      this.FinalOperativeDocumentsStatus = DealChecklist.DealFileChecklistDetail.FinalOperativeDocumentsStatus;
      this.FinalBondInsuranceStatus = DealChecklist.DealFileChecklistDetail.FinalBondInsuranceStatus;
      this.LegalOpinionsStatus = DealChecklist.DealFileChecklistDetail.LegalOpinionsStatus;
      this.AgreedUponProceduresStatus = DealChecklist.DealFileChecklistDetail.AgreedUponProceduresStatus;
      this.ClosingCertificateStatus = DealChecklist.DealFileChecklistDetail.ClosingCertificateStatus;
      this.IssuePriceCertificateStatus = DealChecklist.DealFileChecklistDetail.IssuePriceCertificateStatus;
      this.ReceiptStatus = DealChecklist.DealFileChecklistDetail.ReceiptStatus;
      this.DealAnnouncementStatus = DealChecklist.DealFileChecklistDetail.DealAnnouncementStatus;
      this.CopyOfIpreoWiresStatus = DealChecklist.DealFileChecklistDetail.CopyOfIpreoWiresStatus;
      this.CopyOfOrdersStatus = DealChecklist.DealFileChecklistDetail.CopyOfOrdersStatus;
      this.CopyOfCheckWireStatus = DealChecklist.DealFileChecklistDetail.CopyOfCheckWireStatus;
      this.CusipStatus = DealChecklist.DealFileChecklistDetail.CusipStatus;
      this.WrittenCorrespondenceStatus = DealChecklist.DealFileChecklistDetail.WrittenCorrespondenceStatus;
      this.DealTranscriptStatus = DealChecklist.DealFileChecklistDetail.DealTranscriptStatus;
      this.CopySubmittedBidStatus = DealChecklist.DealFileChecklistDetail.CopySubmittedBidStatus;
      this.WorkingGroupListStatus = DealChecklist.DealFileChecklistDetail.WorkingGroupListStatus;
    }

    public long? DealFileChecklistID { get; set; }

    public long AppTransactionID { get; set; }

    public long? DueDiligenceReviewStatus { get; set; }

    [AbsoluteDate]
    public DateTime? ReviewDate { get; set; }

    public string ReviewingPersonnel { get; set; }

    public long? PreliminaryOfficialStatementStatus { get; set; }

    public long? FinalOfficialStatementStatus { get; set; }

    public long? EvidenceFilingStatus { get; set; }

    public long? ContinuingDisclosureUndertakingStatus { get; set; }

    public long? NoticeofSaleStatus { get; set; }

    public long? FinalOperativeDocumentsStatus { get; set; }

    public long? FinalBondInsuranceStatus { get; set; }

    public long? LegalOpinionsStatus { get; set; }

    public long? AgreedUponProceduresStatus { get; set; }

    public long? ClosingCertificateStatus { get; set; }

    public long? IssuePriceCertificateStatus { get; set; }

    public long? ReceiptStatus { get; set; }

    public long? DealAnnouncementStatus { get; set; }

    public long? CopyOfIpreoWiresStatus { get; set; }

    public long? CopyOfOrdersStatus { get; set; }

    public long? CopyOfCheckWireStatus { get; set; }

    public long? CusipStatus { get; set; }

    public long? WrittenCorrespondenceStatus { get; set; }

    public long? DealTranscriptStatus { get; set; }

    public long? CopySubmittedBidStatus { get; set; }

    public long? WorkingGroupListStatus { get; set; }
  }
}
