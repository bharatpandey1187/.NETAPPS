﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CurrentDateAttribute
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CurrentDateAttribute : ValidationAttribute
  {
    public override bool IsValid(object value)
    {
      DateTime? nullable1 = (DateTime?) value;
      if (nullable1.HasValue)
      {
        DateTime? nullable2 = nullable1;
        DateTime now = DateTime.Now;
        if ((nullable2.HasValue ? (nullable2.GetValueOrDefault() > now ? 1 : 0) : 0) != 0)
          return false;
      }
      return true;
    }
  }
}
