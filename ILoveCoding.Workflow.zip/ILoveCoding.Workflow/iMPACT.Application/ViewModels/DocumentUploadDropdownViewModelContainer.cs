﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DocumentUploadDropdownViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DocumentUploadDropdownViewModelContainer : ViewModelBase
  {
    public List<RepositoryViewModel> RepositoryDropDown { get; set; }

    public List<CategoryViewModel> CategoryDropDown { get; set; }

    public List<DocTypeViewModel> DocTypeDropDown { get; set; }

    public List<TagViewModel> TagDropDown { get; set; }

    public ShowDealDetails ShowDealDetail { get; set; }

    public ShowClientDetails ShowClientDetails { get; set; }

    public ShowContactDetails ShowContactDetails { get; set; }

    public DocumentUploadDropdownViewModelContainer()
    {
      this.RepositoryDropDown = new List<RepositoryViewModel>();
      this.CategoryDropDown = new List<CategoryViewModel>();
      this.DocTypeDropDown = new List<DocTypeViewModel>();
      this.TagDropDown = new List<TagViewModel>();
      this.ShowDealDetail = new ShowDealDetails();
      this.ShowClientDetails = new ShowClientDetails();
      this.ShowContactDetails = new ShowContactDetails();
    }
  }
}
