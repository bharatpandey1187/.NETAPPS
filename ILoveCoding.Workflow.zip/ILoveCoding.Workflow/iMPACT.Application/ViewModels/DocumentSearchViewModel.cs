﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DocumentSearchViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DocumentSearchViewModel : ViewModelBase
  {
    public DocumentSearchViewModel()
    {
      this.States = new List<KeyValuePair<long, string>>();
      this.GeneralCategories = new List<KeyValuePair<long, string>>();
      this.FirmRoles = new List<KeyValuePair<long, string>>();
      this.DocumentTags = new List<ManageDocumentTag>();
      this.SelectedDocumentsTags = new List<ManageDocumentTag>();
      this.SelectedDocumentRepository = new List<EntityDocSetType>();
      this.AllFields = new List<SearchResultField>();
      this.SelectedAllFields = new List<SearchResultField>();
      this.SelectedFields = new List<SearchResultField>();
      this.FieldsToSelect = new List<SearchResultField>();
    }

    public string Phrase { get; set; }

    public string FileName { get; set; }

    public List<EntityDocSetType> SelectedDocumentRepository { get; set; }

    public string DocumentCategory { get; set; }

    public string SelectedEntityType { get; set; }

    public string DocumentType { get; set; }

    public List<ManageDocumentTag> SelectedDocumentsTags { get; set; }

    public string DocumentTag { get; set; }

    public string DealNumber { get; set; }

    public string DealName { get; set; }

    public string DealIssuer { get; set; }

    public string DealIssuerName { get; set; }

    public string DealIssuerID { get; set; }

    public string DealState { get; set; }

    public string DealFirmRole { get; set; }

    public string EntityTypeID { get; set; }

    public DateTime? UploadDateFrom { get; set; }

    public DateTime? UploadDateTo { get; set; }

    public List<SearchResultField> AllFields { get; set; }

    public List<SearchResultField> SelectedAllFields { get; set; }

    public List<SearchResultField> SelectedFields { get; set; }

    public List<SearchResultField> FieldsToSelect { get; set; }

    public bool CanCreatePublicBookmark { get; set; }

    public List<KeyValuePair<long, string>> Entities { get; set; }

    public List<KeyValuePair<long, string>> States { get; set; }

    public List<KeyValuePair<long, string>> FirmRoles { get; set; }

    public List<EntityDocSetType> DocumentRepositories { get; set; }

    public List<UploadCategory> DocumentCategories { get; set; }

    public List<UploadDocType> DocumentTypes { get; set; }

    public List<ManageDocumentTag> DocumentTags { get; set; }

    public List<KeyValuePair<long, string>> EntityTypes { get; set; }

    public List<KeyValuePair<long, string>> GeneralCategories { get; set; }

    public string SelectedBankingGroup { get; set; }

    public string DealBorrower { get; set; }

    public string DealBorrowerId { get; set; }

    public string JobNumber { get; set; }
  }
}
