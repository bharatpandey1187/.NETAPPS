﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.TemplateFieldViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class TemplateFieldViewModel : ViewModelBase
  {
    public TemplateFieldViewModel()
    {
    }

    public TemplateFieldViewModel(TemplateField templateField)
    {
      this.FieldID = templateField.FieldID;
      this.Key = templateField.Key;
      this.Caption = templateField.Caption;
      this.DataType = templateField.DataType;
      this.DataTypeName = templateField.DataTypeName;
      this.Mandatory = templateField.Mandatory;
      this.Disable = templateField.Disable;
      this.Order = templateField.Order;
      this.TemplateId = templateField.TemplateId;
      this.CreatedBy = templateField.CreatedBy;
      this.CreatedDate = templateField.CreatedDate;
      this.ModeifiedBy = templateField.ModeifiedBy;
      this.ModifiedDate = templateField.ModifiedDate;
      this.IsDirty = false;
    }

    public TemplateField GetTemplateField() => new TemplateField()
    {
      FieldID = this.FieldID,
      Key = this.Key,
      Caption = this.Caption,
      DataType = this.DataType,
      Mandatory = this.Mandatory,
      Disable = this.Disable,
      Order = this.Order,
      TemplateId = this.TemplateId,
      CreatedBy = this.CreatedBy,
      CreatedDate = DateTime.Now,
      ModeifiedBy = this.ModeifiedBy,
      ModifiedDate = DateTime.Now
    };

    public long FieldID { get; set; }

    public string Key { get; set; }

    public string Caption { get; set; }

    public long DataType { get; set; }

    public string DataTypeName { get; set; }

    public bool Mandatory { get; set; }

    public bool Disable { get; set; }

    public int Order { get; set; }

    public long TemplateId { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string ModeifiedBy { get; set; }

    public DateTime ModifiedDate { get; set; }
  }
}
