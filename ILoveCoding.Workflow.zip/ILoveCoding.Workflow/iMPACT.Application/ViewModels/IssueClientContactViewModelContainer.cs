﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueClientContactViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueClientContactViewModelContainer : ViewModelBase
  {
    public IssueClientContactViewModelContainer()
    {
    }

    public IssueClientContactViewModelContainer(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public List<IssueClientContactViewModel> IssueClientContacts { get; set; }

    public List<IrisSoftware.iMPACT.Data.ClientActiveAddress> ClientActiveAddress { get; set; }

    public List<KeyPair> IssuerContactTitle { get; set; }

    public bool IsAddContact { get; set; }

    public bool IsEditContact { get; set; }
  }
}
