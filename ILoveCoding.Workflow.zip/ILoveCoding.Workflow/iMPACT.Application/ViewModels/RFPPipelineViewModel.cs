﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RFPPipelineViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RFPPipelineViewModel : ViewModelBase
  {
    public long AppTransactionID { get; set; }

    public string IssuerName { get; set; }

    public string RFPName { get; set; }

    public string State { get; set; }

    public string ParAmount { get; set; }

    public string ExpectedFirmRole { get; set; }

    public string FinancialAdvisorName { get; set; }

    public DateTime? ResponseDueDateTime { get; set; }

    public DateTime? SubmissionDateTime { get; set; }

    public string RFPStatusValue { get; set; }

    public string RFPReviewStatus { get; set; }

    public string LeadBanker { get; set; }
  }
}
