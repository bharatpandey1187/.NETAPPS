﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MuccExternalPartnerViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MuccExternalPartnerViewModel : ViewModelBase
  {
    public MuccExternalPartnerViewModel()
    {
    }

    public MuccExternalPartnerViewModel(ExternalContacts externalPartner)
    {
      this.RoleType = externalPartner.RoleType;
      this.Name = externalPartner.Name;
    }

    public MuccExternalPartnerViewModel(CompetitiveExternalContacts externalPartner)
    {
      this.RoleType = externalPartner.RoleType;
      this.Name = externalPartner.Name;
    }

    public string RoleType { get; set; }

    public string Name { get; set; }
  }
}
