﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CompetitiveSeriesPipelineViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CompetitiveSeriesPipelineViewModel
  {
    public long SeriesID { get; set; }

    public long AppTransactionID { get; set; }

    public string SeriesName { get; set; }

    public string ParAmount { get; set; }

    public string Rating { get; set; }

    public string EnhancedRating { get; set; }

    public string Structure { get; set; }

    public string Call { get; set; }

    public string Type { get; set; }
  }
}
