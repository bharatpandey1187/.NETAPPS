﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueManagementViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueManagementViewModel
  {
    public string IssueName { get; set; }

    public long IssueID { get; set; }

    public long ClientId { get; set; }

    public string IssuerName { get; set; }

    public string FirmRole { get; set; }

    public string ParAmount { get; set; }

    public string StateName { get; set; }

    public DateTime ActualSettlementDate { get; set; }

    public bool IsActive { get; set; }
  }
}
