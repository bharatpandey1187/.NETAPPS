﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PnlViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PnlViewModelContainer : ViewModelBase
  {
    public PnlHeaderInfoViewModel PnlHeaderInfo { get; set; }

    public List<Dictionary<string, object>> PnlAuditData { get; set; }

    public List<Dictionary<string, object>> PnlSummaryUnderWrittingHistory { get; set; }

    public List<string> JobNumbers { get; set; }

    public List<KeyValuePair<long, string>> PricingDesks { get; set; }

    public List<PnlSyndicateMember> SyndicateMembers { get; set; }

    public List<PnlSeriesViewModel> PnlSeries { get; set; }

    public List<IrisSoftware.iMPACT.Data.UniqueSection> UniqueSection { get; set; }

    public List<UniqueCategoryUnderSection> UniqueCategoriesUnderSection { get; set; }

    public List<UniqueRowUnderSection> UniqueRowsUnderSection { get; set; }

    public List<UniqueCategory> UniqueCategories { get; set; }

    public List<UniqueCategoryExistingTemplate> ExistingCategories { get; set; }

    public List<IrisSoftware.iMPACT.Data.PnLTemplateFields> PnLTemplateFields { get; set; }

    public int NumberOfVersions { get; set; }

    public int Version { get; set; }

    public List<PnlUserInfoViewModel> PnLUserInfo { get; set; }

    public string[] Actions { get; set; }

    public string SelectedJobNumber { get; set; }

    public List<AppTransactionStateTransition> WorkflowStateTransitions { get; set; }

    public List<KeyPair> States { get; set; }

    public bool CannotCalculateFees { get; set; }

    public Dictionary<string, object> PnlFieldDetails { get; set; }

    public PnLBO Pnl { get; set; }

    public bool IsUnderwritingCategoryProjectedViewOnly { get; set; }

    public bool IsUnderwritingCategoryActualViewOnly { get; set; }

    public bool IsUnderwritingCategoryDifferenceViewOnly { get; set; }

    public bool ISPnLNotesViewOnly { get; set; }

    public bool IsSaveDisabled { get; set; }

    public bool ShowPopupMessageWhenNewPnLTemplate { get; set; }

    public PnlViewModelContainer()
    {
      this.States = new List<KeyPair>();
      this.PnlFieldDetails = new Dictionary<string, object>();
      this.UniqueCategoriesUnderSection = new List<UniqueCategoryUnderSection>();
      this.JobNumbers = new List<string>();
    }

    public void BindUnderWritingSpreadViewModel(
      AppTransactionPnLUnderWritingSpread pnLUnderWritingSpread)
    {
      this.Pnl.ProjectedTakedownTotal = pnLUnderWritingSpread.ProjectedTakedownTotal;
      this.Pnl.ProjectedTakedownPerThousand = pnLUnderWritingSpread.ProjectedTakedownPerThousand;
      this.Pnl.ActualTakedownTotal = pnLUnderWritingSpread.ActualTakedownTotal;
      this.Pnl.ActualTakedownPerThousand = pnLUnderWritingSpread.ActualTakedownPerThousand;
      this.Pnl.TakedownDifference = pnLUnderWritingSpread.TakedownDifference;
      this.Pnl.ProjectedExpenseTotal = pnLUnderWritingSpread.ProjectedExpenseTotal;
      this.Pnl.ProjectedExpensePerThousand = pnLUnderWritingSpread.ProjectedExpensePerThousand;
      this.Pnl.ActualExpenseTotal = pnLUnderWritingSpread.ActualExpenseTotal;
      this.Pnl.ActualExpensePerThousand = pnLUnderWritingSpread.ActualExpensePerThousand;
      this.Pnl.ExpenseDifference = pnLUnderWritingSpread.ExpenseDifference;
      this.Pnl.ProjectedStructuringTotal = pnLUnderWritingSpread.ProjectedStructuringTotal;
      this.Pnl.ProjectedStructuringPerThousand = pnLUnderWritingSpread.ProjectedStructuringPerThousand;
      this.Pnl.ActualStructuringTotal = pnLUnderWritingSpread.ActualStructuringTotal;
      this.Pnl.ActualStructuringPerThousand = pnLUnderWritingSpread.ActualStructuringPerThousand;
      this.Pnl.StructuringDifference = pnLUnderWritingSpread.StructuringDifference;
      this.Pnl.ProjectedTotalGrossSpread = pnLUnderWritingSpread.ProjectedTotalGrossSpread;
      this.Pnl.ProjectedPerThousandGrossSpread = pnLUnderWritingSpread.ProjectedPerThousandGrossSpread;
      this.Pnl.ActualTotalGrossSpread = pnLUnderWritingSpread.ActualTotalGrossSpread;
      this.Pnl.ActualPerThousandGrossSpread = pnLUnderWritingSpread.ActualPerThousandGrossSpread;
      this.Pnl.DifferenceGrossSpread = pnLUnderWritingSpread.DifferenceGrossSpread;
    }

    public AppTransactionPnLUnderWritingSpread GetUnderWritingSpreadInfo() => new AppTransactionPnLUnderWritingSpread()
    {
      AppTransactionId = this.PnlHeaderInfo.AppTransactionId,
      ProjectedTakedownTotal = this.Pnl.ProjectedTakedownTotal,
      ProjectedTakedownPerThousand = this.Pnl.ProjectedTakedownPerThousand,
      ActualTakedownTotal = this.Pnl.ActualTakedownTotal,
      ActualTakedownPerThousand = this.Pnl.ActualTakedownPerThousand,
      TakedownDifference = this.Pnl.TakedownDifference,
      ProjectedExpenseTotal = this.Pnl.ProjectedExpenseTotal,
      ProjectedExpensePerThousand = this.Pnl.ProjectedExpensePerThousand,
      ActualExpenseTotal = this.Pnl.ActualExpenseTotal,
      ActualExpensePerThousand = this.Pnl.ActualExpensePerThousand,
      ExpenseDifference = this.Pnl.ExpenseDifference,
      ProjectedStructuringTotal = this.Pnl.ProjectedStructuringTotal,
      ProjectedStructuringPerThousand = this.Pnl.ProjectedStructuringPerThousand,
      ActualStructuringTotal = this.Pnl.ActualStructuringTotal,
      ActualStructuringPerThousand = this.Pnl.ActualStructuringPerThousand,
      StructuringDifference = this.Pnl.StructuringDifference,
      ProjectedTotalGrossSpread = this.Pnl.ProjectedTotalGrossSpread,
      ProjectedPerThousandGrossSpread = this.Pnl.ProjectedPerThousandGrossSpread,
      ActualTotalGrossSpread = this.Pnl.ActualTotalGrossSpread,
      ActualPerThousandGrossSpread = this.Pnl.ActualPerThousandGrossSpread,
      DifferenceGrossSpread = this.Pnl.DifferenceGrossSpread
    };

    public List<IrisSoftware.iMPACT.Data.PnlSeries> GetPnlSeries()
    {
      List<IrisSoftware.iMPACT.Data.PnlSeries> pnlSeriesList = new List<IrisSoftware.iMPACT.Data.PnlSeries>();
      foreach (PnlSeriesViewModel pnlSeriesViewModel in this.PnlSeries)
        pnlSeriesList.Add(new IrisSoftware.iMPACT.Data.PnlSeries()
        {
          AppTransactionID = pnlSeriesViewModel.AppTransactionID,
          IsSelected = pnlSeriesViewModel.IsSelected,
          JobNumber = pnlSeriesViewModel.JobNumber,
          ParAmount = pnlSeriesViewModel.ParAmount,
          SeriesCode = pnlSeriesViewModel.SeriesCode,
          SeriesID = pnlSeriesViewModel.SeriesID,
          SeriesName = pnlSeriesViewModel.SeriesName,
          Version = pnlSeriesViewModel.Version,
          SettlementDate = pnlSeriesViewModel.SettlementDate
        });
      return pnlSeriesList;
    }

    public PnlViewModelContainer(string strErrorMsg) => this.ErrorMessage = strErrorMsg;
  }
}
