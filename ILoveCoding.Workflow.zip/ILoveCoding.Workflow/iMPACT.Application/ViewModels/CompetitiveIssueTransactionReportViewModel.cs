﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CompetitiveIssueTransactionReportViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CompetitiveIssueTransactionReportViewModel : ViewModelBase
  {
    public CompetitiveIssueTransactionReportViewModel()
    {
      this.PaidCheckDetail = this.PaidCheckDetail;
      this.ReceivedCheckDetail = this.ReceivedCheckDetail;
      this.Partner = this.Partner;
      this.AppTransactionID = this.AppTransactionID;
      this.IssueFee = new IssueFee();
      this.Remarks = this.Remarks;
    }

    public CompetitiveIssueTransactionReportViewModel(CompetitiveIssue issue)
    {
      this.Partner = issue.ExternalPartners != null ? issue.ExternalPartners.FindAll((Predicate<ExternalPartner>) (x => x.LookupKey == "Syndicate Member Role")) : new List<ExternalPartner>();
      this.Partner.Sort((Comparison<ExternalPartner>) ((x, y) => string.Compare(x.Name, y.Name)));
      this.ReceivedCheckDetail = issue.ReceivedCheckDetail;
      this.PaidCheckDetail = issue.PaidCheckDetail;
      this.AppTransactionID = issue.IssueDetail.AppTransactionID;
      this.IssueFee = issue.IssueFee ?? new IssueFee();
    }

    public long AppTransactionID { get; set; }

    public string PartnerName { get; set; }

    [StringLength(2000, ErrorMessage = "Remarks length should be less than or equal to 2000 characters.")]
    public string Remarks { get; set; }

    public bool TransactionReportIsViewOnly { get; set; }

    public IssueFee IssueFee { get; set; }

    public List<ExternalPartner> Partner { get; set; }

    public List<CheckDetail> PaidCheckDetail { get; set; }

    public List<CheckDetail> ReceivedCheckDetail { get; set; }
  }
}
