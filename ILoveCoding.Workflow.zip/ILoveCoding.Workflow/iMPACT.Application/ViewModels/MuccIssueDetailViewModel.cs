﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MuccIssueDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MuccIssueDetailViewModel : ViewModelBase
  {
    public MuccIssueDetailViewModel()
    {
    }

    public MuccIssueDetailViewModel(Mucc mucc)
    {
      this.IssueName = mucc.MuccIssueDetail.IssueName;
      this.IssuerID = mucc.MuccIssueDetail.IssuerID;
      this.IssuerName = mucc.MuccIssueDetail.IssuerName;
      this.BorrowerName = mucc.MuccIssueDetail.BorrowerName;
      this.GuarantorName = mucc.MuccIssueDetail.GuarantorName;
      this.FirmLiabilityPerc = mucc.MuccIssueDetail.FirmLiabilityPerc;
      this.FirmMgmtFeePerc = mucc.MuccIssueDetail.FirmMgmtFeePerc;
      this.ParAmount = mucc.MuccIssueDetail.ParAmount;
      this.SDCCreditPerc = mucc.MuccIssueDetail.SDCCreditPerc;
      this.SeriesUnderlyingRating = mucc.MuccIssueDetail.UnderlyingRating;
      this.SeriesMaturity = mucc.MuccIssueDetail.Maturity;
      this.SeriesAMTType = mucc.MuccIssueDetail.AMTType;
      this.SeriesRateType = mucc.MuccIssueDetail.RateType;
      this.UseofProceeds = mucc.MuccIssueDetail.UseofProceeds;
      this.Pricing = mucc.MuccIssueDetail.PricingDate;
      this.Closing = mucc.MuccIssueDetail.SettlementDate;
      this.SyndicateStructure = mucc.MuccIssueDetail.SyndicateStructure;
      this.CommaSeperatedStateID = mucc.MuccIssueDetail.CommaSeperatedStateID;
      this.IssueStatus = mucc.MuccIssueDetail.IssueStatus;
      this.AppTransactionID = mucc.MuccIssueDetail.AppTransactionID;
      this.DealType = mucc.MuccIssueDetail.DealType;
    }

    public MuccIssueDetailViewModel(CompetitiveMucc mucc)
    {
      this.IssueName = mucc.MuccIssueDetail.IssueName;
      this.IssuerID = mucc.MuccIssueDetail.IssuerID;
      this.IssuerName = mucc.MuccIssueDetail.IssuerName;
      this.BorrowerName = mucc.MuccIssueDetail.BorrowerName;
      this.GuarantorName = mucc.MuccIssueDetail.GuarantorName;
      this.FirmLiabilityPerc = mucc.MuccIssueDetail.FirmLiabilityPerc;
      this.FirmMgmtFeePerc = mucc.MuccIssueDetail.FirmMgmtFeePerc;
      this.ParAmount = mucc.MuccIssueDetail.ParAmount;
      this.SDCCreditPerc = mucc.MuccIssueDetail.SDCCreditPerc;
      this.SeriesUnderlyingRating = mucc.MuccIssueDetail.UnderlyingRating;
      this.SeriesMaturity = mucc.MuccIssueDetail.Maturity;
      this.SeriesAMTType = mucc.MuccIssueDetail.AMTType;
      this.SeriesRateType = mucc.MuccIssueDetail.RateType;
      this.UseofProceeds = mucc.MuccIssueDetail.UseofProceeds;
      this.Pricing = mucc.MuccIssueDetail.PricingDate;
      this.Closing = mucc.MuccIssueDetail.SettlementDate;
      this.SyndicateStructure = mucc.MuccIssueDetail.SyndicateStructure;
      this.CommaSeperatedStateID = mucc.MuccIssueDetail.CommaSeperatedStateID;
      this.IssueStatus = mucc.MuccIssueDetail.IssueStatus;
      this.AppTransactionID = mucc.MuccIssueDetail.AppTransactionID;
      this.DealType = mucc.MuccIssueDetail.DealType;
    }

    public string IssueName { get; set; }

    public long? IssuerID { get; set; }

    public string IssuerName { get; set; }

    public string BorrowerName { get; set; }

    public string GuarantorName { get; set; }

    public Decimal? FirmLiabilityPerc { get; set; }

    public Decimal? FirmMgmtFeePerc { get; set; }

    public string UseofProceeds { get; set; }

    public Decimal? ParAmount { get; set; }

    public string SDCCreditPerc { get; set; }

    public string SeriesUnderlyingRating { get; set; }

    public string SeriesMaturity { get; set; }

    public string SeriesAMTType { get; set; }

    public string SeriesRateType { get; set; }

    public string Pricing { get; set; }

    public string Closing { get; set; }

    public string SyndicateStructure { get; set; }

    public string CommaSeperatedStateID { get; set; }

    public List<long> IssueStatus { get; set; }

    public long AppTransactionID { get; set; }

    public string DealType { get; set; }
  }
}
