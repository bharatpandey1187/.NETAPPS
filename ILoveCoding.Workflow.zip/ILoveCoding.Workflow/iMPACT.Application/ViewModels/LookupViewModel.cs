﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.LookupViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class LookupViewModel
  {
    public LookupViewModel()
    {
      this.LookupID = 0L;
      this.Key = string.Empty;
      this.IsActive = false;
      this.LookupItems = new List<LookupItemViewModel>();
    }

    public LookupViewModel(Lookup lookup)
    {
      this.LookupID = lookup.LookupID;
      this.Key = lookup.Key;
      this.IsActive = lookup.IsActive;
      if (lookup.LookupItems == null || lookup.LookupItems.ToList<LookupItem>().Count <= 0)
        return;
      this.LookupItems = lookup.LookupItems.Select<LookupItem, LookupItemViewModel>((Func<LookupItem, LookupItemViewModel>) (x => new LookupItemViewModel(x))).ToList<LookupItemViewModel>();
    }

    public long LookupID { get; set; }

    public string Key { get; set; }

    public bool IsActive { get; set; }

    public List<LookupItemViewModel> LookupItems { get; set; }
  }
}
