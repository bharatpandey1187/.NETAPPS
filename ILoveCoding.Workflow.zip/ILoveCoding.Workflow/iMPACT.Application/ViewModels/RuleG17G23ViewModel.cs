﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RuleG17G23ViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RuleG17G23ViewModel : ViewModelBase
  {
    public long RuleG17G23RegCheckListID { get; set; }

    public bool? IsDeliveredToIssuer { get; set; }

    [AbsoluteDate]
    public DateTime? DeliveryDateToIssuer { get; set; }

    [AbsoluteDate]
    public DateTime? DeliveryDateToObligor { get; set; }

    public bool? IsDeliveredToObligor { get; set; }

    public string RoleDisclosureSender { get; set; }

    public string RoleDisclosureMethodName { get; set; }

    public string RoleDisclosureReceipentName { get; set; }

    public bool? IsRoleDisclosureLetterCopyRetained { get; set; }

    public string ReasonForNonRetainingCopy { get; set; }

    public bool? IsRoleDisclosureAckReceived { get; set; }

    [AbsoluteDate]
    public DateTime? AckReceivedDate { get; set; }

    public string AckExecuterName { get; set; }

    public string AckMethodForRoleDisclosure { get; set; }

    public bool? IsCopyRetainedForRoleDisclosureAck { get; set; }

    public string ReasonForNotGettingAckForRoleDisclosre { get; set; }

    public bool? IsConflictDisclosureLetterDeliveredToIssuer { get; set; }

    public bool? IsConflictDisclosureLetterDeliveredToObligor { get; set; }

    [AbsoluteDate]
    public DateTime? ConflictDisclosreLetterDeliveryDateToIssuer { get; set; }

    [AbsoluteDate]
    public DateTime? ConflictDisclosreLetterDeliveryDateToObligor { get; set; }

    public string ConflictDisclosreLetterMethod { get; set; }

    public string ConflictDisclosureLetterReceipentName { get; set; }

    public bool? IsCopyRetainedForConflictDisclosure { get; set; }

    public string ReasonForNotRetaingCopyOfConflictDisclosure { get; set; }

    public bool? IsAckReceivedOfConflictDisclosure { get; set; }

    [AbsoluteDate]
    public DateTime? AckG17ReceivedDate { get; set; }

    public string AckConflictDisclosureExecuter { get; set; }

    public string AckConflictMethod { get; set; }

    public bool? IsAckCopyRetainedConflictDisclosure { get; set; }

    public string ReasonForNoConflictDisclosureAck { get; set; }

    public bool? IsG17StructureAndRoleLetterDeliveredIssuer { get; set; }

    public bool? IsG17StructureAndRoleLetterDeliveredObligor { get; set; }

    [AbsoluteDate]
    public DateTime? G17SturectureAndRoleLetterDateIssuer { get; set; }

    [AbsoluteDate]
    public DateTime? G17SturectureAndRoleLetterDateObligor { get; set; }

    public string G17SturectureAndRoleLetterSender { get; set; }

    public string G17StructureAndRoleLetterMethod { get; set; }

    public string G17StructureAndRoleLetterReceipent { get; set; }

    public bool? IsCopyRetainedForRoleDisclosure { get; set; }

    public string ReasonForNotRetaingCopyOfRoleAndSturucture { get; set; }

    public bool? IsAckG17RoleAndStuructureLetterReceived { get; set; }

    [AbsoluteDate]
    public DateTime? AckG17RoleAndStructureLetterDate { get; set; }

    public string AckG17RoleAndStructureExecuter { get; set; }

    public string AckG17RoleAndStructureMethod { get; set; }

    public bool? IsCopyRetainedG17RoleAndStructureAck { get; set; }

    public string ReasonForNoAckG17RoleAndStructure { get; set; }

    public long? isEMMAReviewed { get; set; }

    public bool? IsUnderWriterAssistedEMMAReview { get; set; }

    [AbsoluteDate]
    public DateTime? UnderWriterReviewDate { get; set; }

    public bool? IsUnderWriterPriceValid { get; set; }

    public bool? IsUnderWriterCertificateAmended { get; set; }

    public bool? IslegalAndComplianceConsulted { get; set; }

    [AbsoluteDate]
    public DateTime? LegalAndComplianceConsultedDate { get; set; }

    public string ReasonForNoEMMAReview { get; set; }

    public bool? isFirmPayingToMSA { get; set; }

    public bool? IsMSAReviewed { get; set; }

    public string ReasonForNOMSAReview { get; set; }

    public string MSAName { get; set; }

    public string MSACertification { get; set; }

    public long AppTransactionID { get; set; }

    public string RoleLetterExplain { get; set; }

    public string ConflictLetterExplain { get; set; }

    public string RoleDisclosureLetterExplain { get; set; }

    public string StructureExplain { get; set; }
  }
}
