﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ManageDocumentTagViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ManageDocumentTagViewModel : ViewModelBase
  {
    public ManageDocumentTagViewModel()
    {
    }

    public ManageDocumentTagViewModel(ManageDocumentTag manageDocumentTagItem)
    {
      this.EntityTypeDocTagID = manageDocumentTagItem.EntityTypeDocTagID;
      this.EntityTypeID = manageDocumentTagItem.EntityTypeID;
      this.Value = manageDocumentTagItem.Value;
      this.Tag = manageDocumentTagItem.Tag;
      this.IsActive = manageDocumentTagItem.IsActive;
      this.ItemOrder = manageDocumentTagItem.ItemOrder;
      this.IsDirty = false;
    }

    public ManageDocumentTag GetManageDocumentTagItem() => new ManageDocumentTag()
    {
      EntityTypeDocTagID = this.EntityTypeDocTagID,
      EntityTypeID = this.EntityTypeID,
      Value = this.Value,
      Tag = this.Tag,
      IsActive = this.IsActive,
      ItemOrder = this.ItemOrder
    };

    public long EntityTypeDocTagID { get; set; }

    public long EntityTypeID { get; set; }

    public string Value { get; set; }

    [Required(ErrorMessage = "Tag cannot be blank.")]
    [StringLength(80, ErrorMessage = "Tag length should be less than or equal to 80 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string Tag { get; set; }

    public int ItemOrder { get; set; }

    public bool IsActive { get; set; }

    public bool IsUsed { get; set; }
  }
}
