﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.LookupItemViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class LookupItemViewModel : ViewModelBase
  {
    public LookupItemViewModel()
    {
    }

    public LookupItemViewModel(LookupItem lookupItem)
    {
      this.LookupItemID = lookupItem.LookupItemID;
      this.LookupID = lookupItem.LookupID;
      this.Value = lookupItem.Value;
      this.IsActive = lookupItem.IsActive;
      this.ItemOrder = lookupItem.ItemOrder;
      this.IsDirty = false;
      this.IsEditable = lookupItem.IsEditable;
    }

    public LookupItem GetLookupItem() => new LookupItem()
    {
      LookupItemID = this.LookupItemID,
      LookupID = this.LookupID,
      Value = this.Value,
      IsActive = this.IsActive,
      ItemOrder = this.ItemOrder,
      IsEditable = this.IsEditable
    };

    public long LookupItemID { get; set; }

    public long LookupID { get; set; }

    [Required(ErrorMessage = "Reference data cannot be blank.")]
    [StringLength(100, ErrorMessage = "Reference Data length should be less than or equal to 100 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string Value { get; set; }

    public int ItemOrder { get; set; }

    public bool IsActive { get; set; }

    public bool IsEditable { get; set; }
  }
}
