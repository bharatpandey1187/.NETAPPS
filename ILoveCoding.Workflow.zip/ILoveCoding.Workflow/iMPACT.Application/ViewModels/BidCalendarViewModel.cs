﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.BidCalendarViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class BidCalendarViewModel : ViewModelBase
  {
    public long FeedFileImportIssueID { get; set; }

    public long AppTransactionID { get; set; }

    [AbsoluteDate]
    public DateTime? SaleDateTime { get; set; }

    public DateTime? SaleDate
    {
      get
      {
        if (!this.SaleDateTime.HasValue)
          return this.SaleDateTime;
        int year = this.SaleDateTime.Value.Year;
        DateTime? saleDateTime = this.SaleDateTime;
        DateTime dateTime = saleDateTime.Value;
        int month = dateTime.Month;
        saleDateTime = this.SaleDateTime;
        dateTime = saleDateTime.Value;
        int day = dateTime.Day;
        return new DateTime?(new DateTime(year, month, day));
      }
    }

    public string TimeZone { get; set; }

    public string IssuerName { get; set; }

    public string IssuerStateCode { get; set; }

    public string IssueDescription { get; set; }

    public Decimal IssueSize { get; set; }

    public string TaxStatus { get; set; }

    public string LeadManager { get; set; }

    public string StatusType { get; set; }

    public string OfferingType { get; set; }

    public string FinancialAdvisor { get; set; }

    public string PayingAgent { get; set; }

    public string Rating { get; set; }

    public bool IsBidShortlisted { get; set; }

    public string BidType { get; set; }

    [AbsoluteDate]
    public DateTime? FirstDueDate { get; set; }

    [AbsoluteDate]
    public DateTime? LastDueDate { get; set; }
  }
}
