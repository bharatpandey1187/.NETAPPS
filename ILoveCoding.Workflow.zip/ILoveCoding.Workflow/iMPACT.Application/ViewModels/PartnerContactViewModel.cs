﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PartnerContactViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PartnerContactViewModel : ViewModelBase
  {
    public PartnerContactViewModel()
    {
    }

    public PartnerContactViewModel(IssuePartnerContact partnerContact)
    {
      this.PartnerContactID = partnerContact.PartnerContactID;
      this.PartnerID = partnerContact.PartnerID;
      this.PartnerContactName = partnerContact.PartnerContactName;
      this.Phone = partnerContact.Phone;
      this.StreetAddress = partnerContact.StreetAddress;
      this.City = partnerContact.City;
      this.State = partnerContact.State;
      this.StateName = partnerContact.StateName;
      this.State = partnerContact.State;
      this.Zip = partnerContact.Zip;
      this.Title = partnerContact.Title;
      this.Email = partnerContact.Email;
      this.IsActive = partnerContact.IsActive;
      this.IsSelected = partnerContact.IsSelected;
    }

    public PartnerContactViewModel(PartnerContact partnerContact)
    {
      this.PartnerContactID = partnerContact.PartnerContactID;
      this.PartnerID = partnerContact.PartnerID;
      this.PartnerContactName = partnerContact.Name;
      this.Phone = partnerContact.Phone;
      this.StreetAddress = partnerContact.StreetAddress;
      this.City = partnerContact.City;
      this.State = partnerContact.State;
      this.StateName = partnerContact.StateName;
      this.State = partnerContact.State;
      this.Zip = partnerContact.Zip;
      this.Title = partnerContact.Title;
      this.Email = partnerContact.Email;
      this.IsActive = partnerContact.IsActive;
      this.IsDefault = partnerContact.IsDefault;
    }

    public PartnerContact GetPartnerContactDetail() => new PartnerContact()
    {
      PartnerContactID = this.PartnerContactID,
      PartnerID = this.PartnerID,
      Name = this.PartnerName,
      Title = this.Title,
      StreetAddress = this.StreetAddress,
      City = this.City,
      StateName = this.StateName,
      State = this.State,
      Zip = this.Zip,
      Email = this.Email,
      Phone = this.Phone,
      IsActive = this.IsActive,
      IsDefault = this.IsDefault
    };

    public PartnerContact GetPartnerContactDetail(
      PartnerContactViewModel partnerContactViewModel)
    {
      return new PartnerContact()
      {
        PartnerContactID = partnerContactViewModel.PartnerContactID,
        PartnerID = partnerContactViewModel.PartnerID,
        Name = partnerContactViewModel.PartnerName,
        StreetAddress = partnerContactViewModel.StreetAddress,
        City = partnerContactViewModel.City,
        State = partnerContactViewModel.State,
        StateName = partnerContactViewModel.StateName,
        Zip = partnerContactViewModel.Zip,
        Phone = partnerContactViewModel.Phone,
        Title = partnerContactViewModel.Title,
        Email = partnerContactViewModel.Email,
        IsActive = partnerContactViewModel.IsActive,
        IsDefault = partnerContactViewModel.IsDefault
      };
    }

    public long PartnerID { get; set; }

    public long PartnerContactID { get; set; }

    [Required(ErrorMessage = "Partner Name cannot be blank.")]
    [StringLength(300, ErrorMessage = "Length of Partner Name field should be less than or equal to 300 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string PartnerName { get; set; }

    [Required(ErrorMessage = "Contact Name cannot be blank.")]
    [StringLength(80, ErrorMessage = "Length of Contact Name field should be less than or equal to 80 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string PartnerContactName { get; set; }

    [RegexValidator("^$|(^[A-Za-z-\\\\,& ./]+$)", MessageTemplate = "Only alphabets, comma, slash, dash, &, period and space are allowed.")]
    [StringLength(100, ErrorMessage = "Length of Contact Title field should be less than or equal to 100 characters.")]
    public string Title { get; set; }

    [StringLength(500, ErrorMessage = "Length of Contact Street Address field should be less than or equal to 500 characters.")]
    public string StreetAddress { get; set; }

    [RegexValidator("^$|(^[A-Za-z'-. ]+$)", MessageTemplate = "Only alphabets, comma, dash, period, apostrophe and space are allowed.")]
    [StringLength(100, ErrorMessage = "Length of Contact City field for a Client should be less than or equal to 100 characters.")]
    public string City { get; set; }

    public string StateName { get; set; }

    public long? State { get; set; }

    [RegexValidator("^$|((^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$))", MessageTemplate = "ZIP Code for USA should be XXXXX or XXXXX-XXXX.")]
    [StringLength(12, ErrorMessage = "Length of Contact ZIP Code field should be less than or equal to 12 characters.")]
    public string Zip { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Length of Contact Phone field should be less than or equal to 12 characters.")]
    public string Phone { get; set; }

    [RegexValidator("^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", MessageTemplate = "Email address is not valid.")]
    [StringLength(100, ErrorMessage = "Length of Contact Email field should be less than or equal to 100 characters.")]
    public string Email { get; set; }

    public bool IsActive { get; set; }

    public bool IsDefault { get; set; }

    public bool IsSelected { get; set; }
  }
}
