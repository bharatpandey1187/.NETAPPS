﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.AuditTrailReportViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class AuditTrailReportViewModelContainer : ViewModelBase
  {
    public AuditTrailReportViewModelContainer()
    {
    }

    public AuditTrailReportViewModelContainer(string strErrorMsg)
    {
      this.ErrorMessage = strErrorMsg;
      this.AuditTrailReport = new List<AuditTrailReportViewModel>();
    }

    public List<AuditTrailReportViewModel> AuditTrailReport { get; set; }

    public List<IrisSoftware.iMPACT.Application.ViewModels.TransactionAuditTrailViewModel> TransactionAuditTrailViewModel { get; set; }

    public List<IrisSoftware.iMPACT.Application.ViewModels.OpportunityAuditTrailViewModel> OpportunityAuditTrailViewModel { get; set; }

    public List<SeriesAudit> SeriesAuditTrailViewModel { get; set; }

    public PnlViewModelContainer PnlAuditViewModel { get; set; }
  }
}
