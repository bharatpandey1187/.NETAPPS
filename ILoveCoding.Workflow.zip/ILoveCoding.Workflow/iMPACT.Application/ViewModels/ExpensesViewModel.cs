﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ExpensesViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ExpensesViewModel : ViewModelBase
  {
    public long ExpensesRegCheckListID { get; set; }

    public bool? IsSoleManaged { get; set; }

    public string LegalFeesNotes { get; set; }

    public string SyndicateNotes { get; set; }

    public string DTCChargesNotes { get; set; }

    public string IPREONotes { get; set; }

    public string CUSIPFeeNotes { get; set; }

    public string MSRBandStateSpecificFeeNotes { get; set; }

    public string AgentNotes { get; set; }

    public string TravelNotes { get; set; }

    public string MealsClientEntertainNotes { get; set; }

    public string InternetNotes { get; set; }

    public string PrintingNotes { get; set; }

    public string MailDeliveryExpensesNotes { get; set; }

    public string MarketingNotes { get; set; }

    public string CoManagerExpensesNotes { get; set; }

    public string OtherNotes { get; set; }

    public string LessExpenseReimbursementNotes { get; set; }

    public string TotalExpensesNotes { get; set; }

    public string TransactionExpensesNotes { get; set; }

    public string DealMementosNotes { get; set; }

    public string StateSpecificFeeNotes { get; set; }

    public bool? AreExpensesAuthorized { get; set; }

    public string ReasonForNonAutorization { get; set; }

    public bool? IsDocAttachedToCheckList { get; set; }

    public string ReasonForNotAttachingCheckList { get; set; }

    public string Discripiencies { get; set; }

    public int LeadMSBanker { get; set; }

    [AbsoluteDate]
    public DateTime? LeadMSBankerSignDate { get; set; }

    public string SeriesSupervisor { get; set; }

    [AbsoluteDate]
    public DateTime? SeriesSupervisorDate { get; set; }

    public long AppTransactionID { get; set; }
  }
}
