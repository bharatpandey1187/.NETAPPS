﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.EmployeeViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class EmployeeViewModel : ViewModelBase
  {
    public EmployeeViewModel()
    {
      this.IsActive = true;
      this.SelectedPlatformRoles = new List<IrisSoftware.iMPACT.Data.AppRoles>();
    }

    public EmployeeViewModel(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public EmployeeViewModel(Employee employee)
    {
      this.EmployeeID = employee.EmployeeID;
      this.EmpNbr = employee.EmpNbr;
      this.FullName = employee.FullName;
      this.Phone = employee.Phone;
      this.StreetAddress = employee.StreetAddress;
      this.City = employee.City;
      this.State = employee.State;
      this.StateName = employee.StateName;
      this.Zip = employee.Zip;
      this.Title = employee.Title;
      this.Email = employee.Email;
      this.WindowID = employee.WindowID;
      this.KerberosID = employee.KerberosID;
      this.CostCenter = employee.CostCenter;
      this.IsActive = employee.IsActive;
      this.Principal = employee.Principal;
      this.ROGroupPrincipal = employee.ROGroupPrincipal;
      this.SupportGroupPrincipal = employee.SupportGroupPrincipal;
      this.ROGroupPrincipal = employee.ROGroupPrincipal;
      this.SupportGroupPrincipal = employee.SupportGroupPrincipal;
      this.SelectedPlatformRoles = new List<IrisSoftware.iMPACT.Data.AppRoles>();
      this.Fax = employee.Fax;
      this.AppRoles = employee.AppRoles;
      this.GroupRoles = employee.GroupRoles;
      this.SelectedGroupRoles = new List<GroupRole>();
      foreach (GroupRole groupRole in employee.GroupRoles)
        this.SelectedGroupRoles.Add(new GroupRole()
        {
          GroupID = groupRole.GroupID,
          Name = groupRole.Name,
          IsEveryoneToBeApplied = groupRole.IsEveryoneToBeApplied
        });
      this.PlatformRoleValue = (string.Join("; ", this.SelectedPlatformRoles.Select<IrisSoftware.iMPACT.Data.AppRoles, string>((Func<IrisSoftware.iMPACT.Data.AppRoles, string>) (x => x.RoleName)).ToArray<string>()) + "; " + string.Join("; ", this.SelectedGroupRoles.Select<GroupRole, string>((Func<GroupRole, string>) (c => c.Name)).ToArray<string>())).Trim("; ".ToCharArray());
    }

    public Employee GetEmployeeDatail(EmployeeViewModel employeeModel) => new Employee()
    {
      EmployeeID = employeeModel.EmployeeID,
      EmpNbr = employeeModel.EmpNbr,
      FullName = employeeModel.FullName == null ? "" : employeeModel.FullName.Trim(),
      Phone = employeeModel.Phone,
      Title = employeeModel.Title == null ? "" : employeeModel.Title.Trim(),
      Email = employeeModel.Email,
      WindowID = employeeModel.WindowID,
      KerberosID = employeeModel.KerberosID,
      CostCenter = employeeModel.CostCenter,
      IsActive = employeeModel.IsActive,
      Principal = employeeModel.Principal,
      ROGroupPrincipal = employeeModel.ROGroupPrincipal,
      SupportGroupPrincipal = employeeModel.SupportGroupPrincipal,
      PlatformRoles = employeeModel.AppRoleValues,
      AppRoles = employeeModel.AppRoles,
      GroupRoles = employeeModel.GroupRoles,
      StreetAddress = employeeModel.StreetAddress == null ? "" : employeeModel.StreetAddress.Trim(),
      City = employeeModel.City,
      State = employeeModel.State,
      StateName = employeeModel.StateName,
      Zip = employeeModel.Zip,
      SysRolesValues = employeeModel.SysRoles,
      Fax = employeeModel.Fax
    };

    public long EmployeeID { get; set; }

    [NotNullValidator]
    [RegexValidator("^$|(^[A-Za-z0-9 ]+$)", MessageTemplate = "Only alphanumeric characters, space are allowed.")]
    public string EmpNbr { get; set; }

    [Required(ErrorMessage = "Full name cannot be blank.")]
    public string FullName { get; set; }

    public string Phone { get; set; }

    public string Title { get; set; }

    [Required(ErrorMessage = "Email cannot be blank.")]
    public string Email { get; set; }

    public long? Location { get; set; }

    public string LocationValue { get; set; }

    [Required(ErrorMessage = "Window ID cannot be blank.")]
    public string WindowID { get; set; }

    public string KerberosID { get; set; }

    public string CostCenter { get; set; }

    public long? PlatformRole { get; set; }

    public string PlatformRoleValue { get; set; }

    public List<IrisSoftware.iMPACT.Data.AppRoles> SelectedPlatformRoles { get; set; }

    public List<GroupRole> SelectedGroupRoles { get; set; }

    public List<KeyPair> PlatformRoles { get; set; }

    public List<KeyPair> States { get; set; }

    public List<EmployeeRole> EmployeeRoles { get; set; }

    public List<IrisSoftware.iMPACT.Data.AppRoles> AppRoles { get; set; }

    public List<GroupRole> GroupRoles { get; set; }

    [Required(ErrorMessage = "IsActive cannot be unselected.")]
    public bool IsActive { get; set; }

    public int Principal { get; set; }

    public int ROGroupPrincipal { get; set; }

    public int SupportGroupPrincipal { get; set; }

    public string StateName { get; set; }

    public string CreatedBy { get; set; }

    public string CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public string ModifiedOn { get; set; }

    [StringLength(500, ErrorMessage = "Address length should be less than or equal to 500 characters.")]
    public string StreetAddress { get; set; }

    public string City { get; set; }

    public long? State { get; set; }

    public string Zip { get; set; }

    public string AppRoleValues { get; set; }

    public string SysRoles { get; set; }

    public string Fax { get; set; }
  }
}
