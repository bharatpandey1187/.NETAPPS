﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueMuccDetailContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueMuccDetailContainer : ViewModelBase
  {
    public IssueMuccDetailContainer()
    {
      this.MuccDetail = new MuccDetailViewModel();
      this.MuccIssueDetailInfo = new MuccIssueDetailViewModel();
      this.MuccInternalPartners = new List<MuccInternalPartnerViewModel>();
      this.MuccExternalPartners = new List<MuccExternalPartnerViewModel>();
      this.MuccSyndicateMembers = new List<MuccSyndicateMemberViewModel>();
    }

    public IssueMuccDetailContainer(Mucc mucc)
    {
      this.MuccDetail = new MuccDetailViewModel(mucc);
      this.MuccIssueDetailInfo = mucc.MuccIssueDetail != null ? new MuccIssueDetailViewModel(mucc) : new MuccIssueDetailViewModel();
      this.MuccInternalPartners = mucc.MuccInternalPartner != null ? mucc.MuccInternalPartner.Select<KeyContacts, MuccInternalPartnerViewModel>((Func<KeyContacts, MuccInternalPartnerViewModel>) (x => new MuccInternalPartnerViewModel(x))).ToList<MuccInternalPartnerViewModel>() : new List<MuccInternalPartnerViewModel>();
      this.MuccExternalPartners = mucc.MuccExternalPartner != null ? mucc.MuccExternalPartner.Select<ExternalContacts, MuccExternalPartnerViewModel>((Func<ExternalContacts, MuccExternalPartnerViewModel>) (x => new MuccExternalPartnerViewModel(x))).ToList<MuccExternalPartnerViewModel>() : new List<MuccExternalPartnerViewModel>();
      this.MuccSyndicateMembers = mucc.MuccSyndicateMember != null ? mucc.MuccSyndicateMember.Select<MuccSyndicateMember, MuccSyndicateMemberViewModel>((Func<MuccSyndicateMember, MuccSyndicateMemberViewModel>) (x => new MuccSyndicateMemberViewModel(x))).ToList<MuccSyndicateMemberViewModel>() : new List<MuccSyndicateMemberViewModel>();
    }

    public IssueMuccDetailContainer(CompetitiveMucc mucc)
    {
      this.MuccDetail = new MuccDetailViewModel(mucc);
      this.MuccIssueDetailInfo = mucc.MuccIssueDetail != null ? new MuccIssueDetailViewModel(mucc) : new MuccIssueDetailViewModel();
      this.MuccInternalPartners = mucc.MuccInternalPartner != null ? mucc.MuccInternalPartner.Select<CompetitiveKeyContacts, MuccInternalPartnerViewModel>((Func<CompetitiveKeyContacts, MuccInternalPartnerViewModel>) (x => new MuccInternalPartnerViewModel(x))).ToList<MuccInternalPartnerViewModel>() : new List<MuccInternalPartnerViewModel>();
      this.MuccExternalPartners = mucc.MuccExternalPartner != null ? mucc.MuccExternalPartner.Select<CompetitiveExternalContacts, MuccExternalPartnerViewModel>((Func<CompetitiveExternalContacts, MuccExternalPartnerViewModel>) (x => new MuccExternalPartnerViewModel(x))).ToList<MuccExternalPartnerViewModel>() : new List<MuccExternalPartnerViewModel>();
      this.MuccSyndicateMembers = mucc.MuccSyndicateMember != null ? mucc.MuccSyndicateMember.Select<CompetitiveMuccSyndicateMember, MuccSyndicateMemberViewModel>((Func<CompetitiveMuccSyndicateMember, MuccSyndicateMemberViewModel>) (x => new MuccSyndicateMemberViewModel(x))).ToList<MuccSyndicateMemberViewModel>() : new List<MuccSyndicateMemberViewModel>();
    }

    public MuccDetailViewModel MuccDetail { get; set; }

    public MuccIssueDetailViewModel MuccIssueDetailInfo { get; set; }

    public List<MuccInternalPartnerViewModel> MuccInternalPartners { get; set; }

    public List<MuccExternalPartnerViewModel> MuccExternalPartners { get; set; }

    public List<MuccSyndicateMemberViewModel> MuccSyndicateMembers { get; set; }
  }
}
