﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DealReportViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DealReportViewModel
  {
    public int AppTransactionID { get; set; }

    public string IssueNbr { get; set; }

    public string Issuer { get; set; }

    public string Borrower { get; set; }

    public string Guarantor { get; set; }

    public string JobNumber { get; set; }

    public string LeadBanker { get; set; }

    public string Banker2 { get; set; }

    public string Banker3 { get; set; }

    public string SupervisoryPrincipal { get; set; }

    [AbsoluteDate]
    public DateTime? SaleDate { get; set; }

    [AbsoluteDate]
    public DateTime? SettlementDate { get; set; }

    public string ParAmount { get; set; }

    public string FirmRole { get; set; }

    public string FirmLiability { get; set; }

    public string RateStructure { get; set; }

    public string SecurityType { get; set; }

    public string TaxStatus { get; set; }

    public string BankQualified { get; set; }

    public string FedTax { get; set; }

    public string StateTaxable { get; set; }

    public string SPURating { get; set; }

    public string MoodyURating { get; set; }

    public string FitchURating { get; set; }

    public string KrollRating { get; set; }

    public string BondInsurer { get; set; }

    public string FinancialAdvisor { get; set; }

    public string BondCounsel { get; set; }

    public string UWCounsel { get; set; }

    public string Purpose { get; set; }

    public string BaseCUSIP { get; set; }

    public string LeadManager { get; set; }

    public string DesignationPolicy { get; set; }

    public string GrossUD { get; set; }

    public string AverageTakedown { get; set; }

    [AbsoluteDate]
    public DateTime FinalMaturity { get; set; }

    public string BondUnderwritten { get; set; }

    public string TotalRetailOrder { get; set; }

    public string TotalInstitutionalOrders { get; set; }

    public string TotalInstitutionalAllotments { get; set; }

    public string TotalMemberOrders { get; set; }

    public string TotalMemberAllotments { get; set; }

    public string TotalDesignationDollars { get; set; }
  }
}
