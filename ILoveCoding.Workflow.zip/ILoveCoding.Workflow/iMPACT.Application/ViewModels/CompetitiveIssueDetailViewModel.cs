﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.CompetitiveIssueDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class CompetitiveIssueDetailViewModel : ViewModelBase
  {
    public CompetitiveIssueDetailViewModel()
    {
    }

    public CompetitiveIssueDetailViewModel(CompetitiveIssue issue)
    {
      this.AppTransactionID = issue.IssueDetail.AppTransactionID;
      this.ParentOpportunityID = issue.IssueDetail.ParentOpportunityID;
      this.ParentOpportunityNumber = issue.IssueDetail.ParentOpportunityNumber;
      this.ParentRFPID = issue.IssueDetail.ParentRFPID;
      this.ParentRFPNumber = issue.IssueDetail.ParentRFPNumber;
      this.IssueStatus = issue.IssueDetail.IssueStatus;
      this.IssueStatusValue = issue.IssueDetail.IssueStatusValue;
      this.ReviewStatusValue = issue.IssueDetail.ReviewStatusValue;
      this.IssueNbr = issue.IssueDetail.IssueNbr;
      this.CreatedOn = issue.IssueDetail.CreatedOn;
      this.PowerID = issue.IssueDetail.PowerID;
      this.IssueName = issue.IssueDetail.IssueName;
      this.IssuerId = issue.IssueDetail.IssuerID;
      this.IssuerName = issue.IssueDetail.IssuerName;
      this.JobNumber = issue.IssueDetail.JobNumber;
      this.BorrowerId = issue.IssueDetail.BorrowerID;
      this.BorrowerName = issue.IssueDetail.BorrowerName;
      this.GuarantorId = issue.IssueDetail.GuarantorID;
      this.GuarantorName = issue.IssueDetail.GuarantorName;
      this.OfferingTypeId = issue.IssueDetail.OfferingType;
      this.StateID = issue.IssueDetail.State;
      this.HybridSolutionIndicator = issue.IssueDetail.HybridSolutionIndicator;
      this.DualProposalProposed = issue.IssueDetail.DualProposalProposed;
      this.DateHired = issue.IssueDetail.DateHired;
      this.G17SentDate = issue.IssueDetail.G17SentDate;
      this.G17AckDate = issue.IssueDetail.G17AckDate;
      this.MAExemptionDetails = issue.IssueDetail.MAExemptions != null ? issue.IssueDetail.MAExemptions.ToList<MAExemptionDetail>() : new List<MAExemptionDetail>();
      this.SelectedMERGReviewTypes = issue.IssueDetail.SelectedMERGReviewTypes != null ? issue.IssueDetail.SelectedMERGReviewTypes.Select<MERGReviewTypeDetail, KeyPair>((Func<MERGReviewTypeDetail, KeyPair>) (x => new KeyPair(x.MERGReviewType, ""))).ToList<KeyPair>() : new List<KeyPair>();
      this.PriorityOfOrderDetails = issue.IssueDetail.PriorityOfOrders != null ? issue.IssueDetail.PriorityOfOrders.ToList<PriorityOfOrderDetail>() : new List<PriorityOfOrderDetail>();
      this.RemarksForMERG = issue.IssueDetail.RemarksForMERG;
      this.RemarksForMUCC = issue.IssueDetail.RemarksForMUCC;
      this.FirmRoleId = issue.IssueDetail.FirmRole;
      this.FirmRoleValue = issue.IssueDetail.FirmRoleValue;
      this.CrossSellId = issue.IssueDetail.CrossSellId;
      this.CrossSellDetail = issue.IssueDetail.CrossSellDetail;
      this.FirmLiabilityPerc = issue.IssueDetail.FirmLiabilityPerc;
      this.FirmMgmtFeePerc = issue.IssueDetail.FirmMgmtFeePerc;
      this.FirmOtherRoles = issue.IssueDetail.FirmOtherRoles != null ? issue.IssueDetail.FirmOtherRoles.ToList<FirmOtherRole>() : new List<FirmOtherRole>();
      this.PriorityOfOrders = new List<string>();
      this.ParAmount = issue.IssueDetail.ParAmount;
      this.SDCCreditPerc = issue.IssueDetail.SDCCreditPerc;
      this.DSRF = issue.IssueDetail.DSRF;
      this.County = issue.IssueDetail.County;
      this.Purpose = issue.IssueDetail.Purpose;
      this.TransactionType = issue.IssueDetail.TransactionType;
      this.UseOfProceed = issue.IssueDetail.TransactionType;
      this.InsuranceProviderId = issue.IssueDetail.InsuranceProvider;
      this.GeneralCategoryId = issue.IssueDetail.GeneralCategory;
      this.GeneralCategoryTxt = issue.IssueDetail.GeneralCategoryTxt;
      this.OfferingTypeTxt = issue.IssueDetail.OfferingTypeTxt;
      this.DealTypeTxt = issue.IssueDetail.DealTypeTxt;
      this.CrossSellIdTxt = issue.IssueDetail.CrossSellIdTxt;
      this.GeneralCategorySpecificId = issue.IssueDetail.GeneralCategorySpecific;
      this.CreditEnhancementProgramId = issue.IssueDetail.CreditEnhancementProg;
      this.Security = issue.IssueDetail.Security;
      this.SecurityDetails = issue.IssueDetail.SecurityDetails;
      this.PricingDate = issue.IssueDetail.PricingDate;
      this.ROPDate = issue.IssueDetail.ROPDate;
      this.ExpectedAwardDate = issue.IssueDetail.ExpectedAwardDate;
      this.ExpectedAwardTxtDate = string.IsNullOrEmpty(issue.IssueDetail.ExpectedAwardTxtDate) ? "As of" : issue.IssueDetail.ExpectedAwardTxtDate.Trim();
      this.ActualAwardDateTime = issue.IssueDetail.ActualAwardDateTime;
      this.ActualAwardDateTimeZone = issue.IssueDetail.ActualAwardDateTimeZone;
      this.SettlementDate = issue.IssueDetail.SettlementDate;
      this.TicketExecDateTime = issue.IssueDetail.TicketExecDateTime;
      this.TicketExecDateTimeZone = issue.IssueDetail.TicketExecDateTimeZone;
      this.GoodFaithAmount = issue.IssueDetail.GoodFaithAmount;
      this.GoodFaithDate = issue.IssueDetail.GoodFaithDate;
      this.GoodFaithWireInfo = issue.IssueDetail.GoodFaithWireInfo;
      this.GoodFaithInstructions = issue.IssueDetail.GoodFaithInstructions;
      this.Series = issue.IssueDetail.Series != null ? issue.IssueDetail.Series.ToList<IrisSoftware.iMPACT.Data.Series>() : new List<IrisSoftware.iMPACT.Data.Series>();
      this.G17Details = issue.IssueDetail.G17Details != null ? issue.IssueDetail.G17Details.ToList<G17Detail>() : new List<G17Detail>();
      this.AccountName = issue.IssueDetail.AccountName;
      this.AccountNumber = issue.IssueDetail.AccountNumber;
      this.ABANumber = issue.IssueDetail.ABANumber;
      this.GoodFaithTypeId = issue.IssueDetail.GoodFaithType;
      this.GoodFaithNotes = issue.IssueDetail.GoodFaithNotes;
      if (issue.IssueDetail.Series != null)
      {
        this.SeriesView = issue.IssueDetail.Series.ToList<IrisSoftware.iMPACT.Data.Series>();
        foreach (IrisSoftware.iMPACT.Data.Series series in this.SeriesView)
        {
          if (!string.IsNullOrEmpty(series.MoodyRatingLT) || !string.IsNullOrEmpty(series.SPRatingLT) || !string.IsNullOrEmpty(series.FitchRatingLT))
          {
            series.MoodyRatingLT = string.IsNullOrEmpty(series.MoodyRatingLT) ? "-/" : series.MoodyRatingLT + "/";
            series.SPRatingLT = string.IsNullOrEmpty(series.SPRatingLT) ? "-/" : series.SPRatingLT + "/";
            series.FitchRatingLT = string.IsNullOrEmpty(series.FitchRatingLT) ? "-" : series.FitchRatingLT;
          }
          else if (!string.IsNullOrEmpty(series.MoodyRatingST) || !string.IsNullOrEmpty(series.SPRatingST) || !string.IsNullOrEmpty(series.FitchRatingST))
          {
            series.MoodyRatingLT = string.IsNullOrEmpty(series.MoodyRatingST) ? "-/" : series.MoodyRatingST + "/";
            series.SPRatingLT = string.IsNullOrEmpty(series.SPRatingST) ? "-/" : series.SPRatingST + "/";
            series.FitchRatingLT = string.IsNullOrEmpty(series.FitchRatingST) ? "-" : series.FitchRatingST;
          }
          else if (string.IsNullOrEmpty(series.UnderlyingRating))
            series.UnderlyingRating = string.Empty;
        }
      }
      this.NotesHistory = issue.IssueDetail.NotesHistory != null ? issue.IssueDetail.NotesHistory.ToList<IrisSoftware.iMPACT.Data.Notes>() : new List<IrisSoftware.iMPACT.Data.Notes>();
      this.ARDSubmissionDate = issue.IssueDetail.ARDSubmissionDate;
      this.LiquidityAgreementUploadDate = issue.IssueDetail.LiquidityAgreementUploadDate;
      this.G37SettlementDate = issue.IssueDetail.G37SettlementDate;
      this.FinalOSReceivedDateTime = issue.IssueDetail.FinalOSReceivedDateTime;
      this.FinalOSReceivedDateTimeZone = issue.IssueDetail.FinalOSReceivedDateTimeZone;
      this.DateCounselApprovedByLegal = issue.IssueDetail.DateCounselApprovedByLegal;
      this.DateApprovedByMERG = issue.IssueDetail.DateApprovedByMERG;
      this.DateApprovedByMUCC = issue.IssueDetail.DateApprovedByMUCC;
      this.G32SubmissionDateTime = issue.IssueDetail.G32SubmissionDateTime;
      this.G32SubmissionDateTimeZone = issue.IssueDetail.G32SubmissionDateTimeZone;
      this.BPASigningDate = issue.IssueDetail.BPASigningDate;
      this.CommitmentCommitteeApprovalDate = issue.IssueDetail.CommitmentCommitteeApprovalDate;
      this.AdvanceRefunding = issue.IssueDetail.AdvanceRefunding;
      this.G37Filed = issue.IssueDetail.G37Filed;
      this.Notes = issue.IssueDetail.Notes;
      this.IssueReviews = issue.IssueReviews != null ? issue.IssueReviews.ToList<IrisSoftware.iMPACT.Data.ReviewComments>() : new List<IrisSoftware.iMPACT.Data.ReviewComments>();
      this.NotesHistory = issue.IssueDetail.NotesHistory != null ? issue.IssueDetail.NotesHistory.ToList<IrisSoftware.iMPACT.Data.Notes>() : new List<IrisSoftware.iMPACT.Data.Notes>();
      this.PricingComments = issue.IssueDetail.PricingComments;
      this.RatingComments = issue.IssueDetail.RatingComments;
      this.ReviewComments = issue.IssueDetail.ReviewComments;
      this.NbrOfCusip = issue.IssueDetail.NbrOfCusip;
      this.BidCalcId = issue.IssueDetail.BidCalc;
      this.BidPlatformId = issue.IssueDetail.BidPlatform;
      this.BidPricingTxtDateTime = string.IsNullOrEmpty(issue.IssueDetail.BidTxtDateTime) ? "As of" : issue.IssueDetail.BidTxtDateTime.Trim();
      this.DocumentLibraryURL = issue.IssueDetail.DocumentLibraryURL;
      this.InRetention = issue.IssueDetail.InRetention;
      this.CreatedBy = issue.IssueDetail.CreatedBy;
      this.ModifiedBy = issue.IssueDetail.ModifiedBy;
      this.ModifiedOn = issue.IssueDetail.ModifiedOn;
      this.Version = issue.IssueDetail.Version;
      this.IsFreeze = issue.IssueDetail.IsFreeze;
      this.LastModifiedBy = issue.IssueDetail.LastModifiedBy;
      this.IsIssueInitiatedFromParentOpportunity = issue.IssueDetail.IsIssueInitiatedFromParentOpportunity;
      this.CreatorEmployeeId = issue.IssueDetail.CreatorEmployeeId;
      this.EstimatedRevenue = issue.IssueDetail.EstimatedRevenue;
      this.IsMuccUpdated = issue.IssueDetail.IsMuccUpdated;
      this.IsRequirementRegulatoryUpdated = issue.IssueDetail.IsRequirementRegulatoryUpdated;
      this.IsTransactionPriced = issue.IssueDetail.IsTransactionPriced;
      this.UploadedDocumentTypes = issue.UploadedDocumentTypes;
      this.DealType = issue.IssueDetail.DealType;
      this.FormalDueDiligenceDate = issue.IssueDetail.FormalDueDiligenceDate;
      this.IssuePriceCertReviewDate = issue.IssueDetail.IssuePriceCertReviewDate;
      this.DatedDate = issue.IssueDetail.DatedDate;
      this.OSDeemedFinalDate = issue.IssueDetail.OSDeemedFinalDate;
      this.MSBankingGroup = issue.IssueDetail.MSBankingGroup != null ? issue.IssueDetail.MSBankingGroup.ToList<CompetitiveMsBankingGroup>() : new List<CompetitiveMsBankingGroup>();
      this.ReasonOfHold = issue.IssueDetail.ReasonOfHold;
    }

    public long AppTransactionID { get; set; }

    public long? ParentOpportunityID { get; set; }

    public string ParentOpportunityNumber { get; set; }

    public long? ParentRFPID { get; set; }

    public string ParentRFPNumber { get; set; }

    public List<long> IssueStatus { get; set; }

    public string IssueStatusValue { get; set; }

    public string ReviewStatusValue { get; set; }

    public string IssueNbr { get; set; }

    public DateTime CreateDate { get; set; }

    public string PowerID { get; set; }

    [Required(ErrorMessage = "Transaction Description cannot be blank.")]
    [StringLength(300, ErrorMessage = "Transaction Description length cannot be greater than 300 characters.")]
    public string IssueName { get; set; }

    public long? IssuerId { get; set; }

    public string IssuerName { get; set; }

    public string JobNumber { get; set; }

    public long? BorrowerId { get; set; }

    public string BorrowerName { get; set; }

    public long? GuarantorId { get; set; }

    public string GuarantorName { get; set; }

    public long OfferingTypeId { get; set; }

    public long? StateID { get; set; }

    public bool? HybridSolutionIndicator { get; set; }

    public bool? DualProposalProposed { get; set; }

    [AbsoluteDate]
    public DateTime? DateHired { get; set; }

    [AbsoluteDate]
    public DateTime? G17SentDate { get; set; }

    [AbsoluteDate]
    public DateTime? G17AckDate { get; set; }

    public List<MAExemptionDetail> MAExemptionDetails { get; set; }

    public List<PriorityOfOrderDetail> PriorityOfOrderDetails { get; set; }

    public List<KeyPair> SelectedMERGReviewTypes { get; set; }

    public string RemarksForMERG { get; set; }

    public string RemarksForMUCC { get; set; }

    public long? FirmRoleId { get; set; }

    public string FirmRoleValue { get; set; }

    [Range(0, 100, ErrorMessage = "Value for {0} must be between {1} and {2}.")]
    public Decimal? FirmLiabilityPerc { get; set; }

    [Range(0, 100, ErrorMessage = "Value for {0} must be between {1} and {2}.")]
    public Decimal? FirmMgmtFeePerc { get; set; }

    public List<FirmOtherRole> FirmOtherRoles { get; set; }

    public List<string> PriorityOfOrders { get; set; }

    public Decimal? ParAmount { get; set; }

    [Range(0, 100, ErrorMessage = "Value for SDC Credit % must be between {1} and {2}.")]
    public Decimal? SDCCreditPerc { get; set; }

    public long? DSRF { get; set; }

    public string County { get; set; }

    public long? Purpose { get; set; }

    public long? TransactionType { get; set; }

    public long? UseOfProceed { get; set; }

    public long? InsuranceProviderId { get; set; }

    public long? GeneralCategoryId { get; set; }

    public string GeneralCategoryTxt { get; set; }

    public string OfferingTypeTxt { get; set; }

    public string DealTypeTxt { get; set; }

    public string CrossSellIdTxt { get; set; }

    public long? GeneralCategorySpecificId { get; set; }

    public long? CreditEnhancementProgramId { get; set; }

    public string Security { get; set; }

    public string SecurityDetails { get; set; }

    [AbsoluteDate]
    public DateTime? PricingDate { get; set; }

    [AbsoluteDate]
    public DateTime? ExpectedAwardDate { get; set; }

    public string ExpectedAwardTxtDate { get; set; }

    [AbsoluteDate]
    public DateTime? ActualAwardDateTime { get; set; }

    public string ActualAwardDateTimeZone { get; set; }

    [AbsoluteDate]
    public DateTime? SettlementDate { get; set; }

    [AbsoluteDate]
    public DateTime? TicketExecDateTime { get; set; }

    public string TicketExecDateTimeZone { get; set; }

    public Decimal? GoodFaithAmount { get; set; }

    [AbsoluteDate]
    public DateTime? GoodFaithDate { get; set; }

    public string GoodFaithWireInfo { get; set; }

    public string GoodFaithInstructions { get; set; }

    public List<IrisSoftware.iMPACT.Data.Series> Series { get; set; }

    public List<IrisSoftware.iMPACT.Data.Series> SeriesView { get; set; }

    [AbsoluteDate]
    public DateTime? ARDSubmissionDate { get; set; }

    [AbsoluteDate]
    public DateTime? LiquidityAgreementUploadDate { get; set; }

    [AbsoluteDate]
    public DateTime? G37SettlementDate { get; set; }

    [AbsoluteDate]
    public DateTime? FinalOSReceivedDateTime { get; set; }

    public string FinalOSReceivedDateTimeZone { get; set; }

    [AbsoluteDate]
    public DateTime? DateCounselApprovedByLegal { get; set; }

    [AbsoluteDate]
    public DateTime? DateApprovedByMERG { get; set; }

    [AbsoluteDate]
    public DateTime? DateApprovedByMUCC { get; set; }

    [AbsoluteDate]
    public DateTime? G32SubmissionDateTime { get; set; }

    public string G32SubmissionDateTimeZone { get; set; }

    [AbsoluteDate]
    public DateTime? BPASigningDate { get; set; }

    [AbsoluteDate]
    public DateTime? CommitmentCommitteeApprovalDate { get; set; }

    public long? AdvanceRefunding { get; set; }

    public bool? G37Filed { get; set; }

    public string Notes { get; set; }

    public List<IrisSoftware.iMPACT.Data.Notes> NotesHistory { get; set; }

    public string PricingComments { get; set; }

    public string RatingComments { get; set; }

    public string ReviewComments { get; set; }

    public int? NbrOfCusip { get; set; }

    public long? BidCalcId { get; set; }

    public long? BidPlatformId { get; set; }

    public string BidPricingTxtDateTime { get; set; }

    [AbsoluteDate]
    public DateTime? NetDesigDate { get; set; }

    [AbsoluteDate]
    public DateTime? GroupNetDate { get; set; }

    public string AdditionalComments { get; set; }

    public string DocumentLibraryURL { get; set; }

    public bool InRetention { get; set; }

    public long? PriorityOfOrdersId { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string CreatedOnValue => this.CreatedOn > DateTime.MinValue ? this.CreatedOn.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public List<IrisSoftware.iMPACT.Data.RestrictedCUSIP> RestrictedCUSIP { get; set; }

    public List<IrisSoftware.iMPACT.Data.ReviewComments> IssueReviews { get; set; }

    public List<IrisSoftware.iMPACT.Data.AuditTrail> AuditTrail { get; set; }

    public List<string> IssuseStatusValue { get; set; }

    public bool IsIssueDetailsViewOnly { get; set; }

    public bool IsRestrictedCusipViewOnly { get; set; }

    public bool IsMiscViewOnly { get; set; }

    public bool IsIssueDetailsVisible { get; set; }

    public bool IsInternalPartnerVisible { get; set; }

    public bool IsExternalPartnerVisible { get; set; }

    public bool IsIssueRatingVisible { get; set; }

    public bool IsIssuePricingVisible { get; set; }

    public bool IsRestrictedCusipVisible { get; set; }

    public bool IsTransactionReportVisible { get; set; }

    public bool IsIssueReviewVisible { get; set; }

    public bool IsAuditTrailVisible { get; set; }

    public bool IsPnlAuditTrailVisible { get; set; }

    public bool IsIssueDocumentsVisible { get; set; }

    public bool IsIssueContactsVisible { get; set; }

    public bool IsMiscVisible { get; set; }

    public bool IsIssueEditable { get; set; }

    public bool DisableIssueDetailEmail { get; set; }

    public bool IsIssuerContactEditable { get; set; }

    public bool ViewIssueDocument { get; set; }

    public bool ViewG37Form { get; set; }

    public bool ViewIssueClosureChecklist { get; set; }

    public int Version { get; set; }

    public bool IsFreeze { get; set; }

    public string LastModifiedBy { get; set; }

    public bool? IsIssueInitiatedFromParentOpportunity { get; set; }

    public bool? IsIssueInitiatedFromParentRFP { get; set; }

    public bool? HasDualProposalRequestedOrProposed { get; set; }

    public long? CreatorEmployeeId { get; set; }

    public bool ViewCopyIssue { get; set; }

    public long? G17Type { get; set; }

    public List<G17Detail> G17Details { get; set; }

    public string AccountName { get; set; }

    public string AccountNumber { get; set; }

    public string ABANumber { get; set; }

    public long? GoodFaithTypeId { get; set; }

    public string GoodFaithNotes { get; set; }

    public Decimal? EstimatedRevenue { get; set; }

    public Decimal? TakeDownValue { get; set; }

    public bool DisableGoodFaithEmail { get; set; }

    public bool? IsMuccUpdated { get; set; }

    public bool? IsRequirementRegulatoryUpdated { get; set; }

    public bool? IsTransactionPriced { get; set; }

    public List<UploadedDocumentType> UploadedDocumentTypes { get; set; }

    public bool IsIssueReviewViewOnly { get; set; }

    public long? DealType { get; set; }

    [AbsoluteDate]
    public DateTime? FormalDueDiligenceDate { get; set; }

    [AbsoluteDate]
    public DateTime? IssuePriceCertReviewDate { get; set; }

    public long? CrossSellId { get; set; }

    public string CrossSellDetail { get; set; }

    [AbsoluteDate]
    public DateTime? ROPDate { get; set; }

    [AbsoluteDate]
    public DateTime? DatedDate { get; set; }

    [AbsoluteDate]
    public DateTime? OSDeemedFinalDate { get; set; }

    public string ReasonOfHold { get; set; }

    public List<CompetitiveMsBankingGroup> MSBankingGroup { get; set; }

    public bool IsBidDetailsVisible { get; set; }
  }
}
