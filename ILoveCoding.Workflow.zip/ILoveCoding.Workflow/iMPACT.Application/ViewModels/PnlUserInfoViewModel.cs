﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PnlUserInfoViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PnlUserInfoViewModel
  {
    public string VersionInfo { get; set; }

    public string UserInfo { get; set; }

    public DateTime When { get; set; }

    public string RootStatus { get; set; }

    public string LeafStatus { get; set; }

    public string JobNumber { get; set; }

    public string PnlNotes { get; set; }

    public string PricingDesk { get; set; }

    public string ManagementFee { get; set; }

    public string PnlReviewComments { get; set; }

    public string WhenString
    {
      get => this.When > DateTime.MinValue ? this.When.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;
      set => this.WhenString = value;
    }

    public PnlUserInfoViewModel()
    {
    }

    public PnlUserInfoViewModel(PnlUserInfo pnlUserInfo)
    {
      this.VersionInfo = pnlUserInfo.VersionInfo;
      this.UserInfo = pnlUserInfo.UserInfo;
      this.When = pnlUserInfo.When;
      this.JobNumber = pnlUserInfo.JobNumber;
      this.RootStatus = pnlUserInfo.RootStatus;
      this.LeafStatus = pnlUserInfo.LeafStatus;
      this.PnlNotes = pnlUserInfo.PnlNotes;
      this.PricingDesk = pnlUserInfo.PricingDeskValue;
      this.ManagementFee = pnlUserInfo.ManagementFee;
      this.PnlReviewComments = pnlUserInfo.PnlReviewComments;
    }
  }
}
