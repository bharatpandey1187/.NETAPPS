﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PricingViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PricingViewModel : ViewModelBase
  {
    public PricingViewModel() => this.CUSIP = new List<CusipViewModel>();

    public string SeriesID { get; set; }

    public string SeriesName { get; set; }

    public string SeriesCode { get; set; }

    public string PricingStatus { get; set; }

    [AbsoluteDate]
    public DateTime? StructureDateFrom { get; set; }

    [AbsoluteDate]
    public DateTime? StructureDateTo { get; set; }

    public string CouponFreq { get; set; }

    public string ParAmount { get; set; }

    public string SecType { get; set; }

    [AbsoluteDate]
    public DateTime? DatedDate { get; set; }

    [AbsoluteDate]
    public DateTime? CouponDate { get; set; }

    [AbsoluteDate]
    public DateTime? SettlementDate { get; set; }

    public string AccureForm { get; set; }

    public string Form { get; set; }

    public string DayCount { get; set; }

    public string RateType { get; set; }

    public string CallFeature { get; set; }

    [AbsoluteDate]
    public DateTime? CallDate { get; set; }

    public string CallPrice { get; set; }

    public string Insurance { get; set; }

    public string FirmInventory { get; set; }

    public string AmtTax { get; set; }

    public string BankQualified { get; set; }

    public string FedTax { get; set; }

    public string StateTax { get; set; }

    public List<CusipViewModel> CUSIP { get; set; }

    public string PrincipalFreq { get; set; }

    public string SUMAmount { get; set; }

    public bool IsParAmountMisMatch { get; set; }

    public string Denomination { get; set; }

    public string Security { get; set; }

    public string SecurityDetails { get; set; }

    [AbsoluteDate]
    public DateTime? PutDate { get; set; }

    public string RecordDate { get; set; }

    public string GrossSpread { get; set; }

    public string Takedown { get; set; }

    public string InsuranceFee { get; set; }

    public string SecurityTypeSpecific { get; set; }

    public string PriorityOfOrders { get; set; }

    public string JobNumber { get; set; }

    [AbsoluteDate]
    public DateTime? PricingDate { get; set; }

    [AbsoluteDate]
    public DateTime? RetailOrderPeriodDate { get; set; }

    [AbsoluteDate]
    public DateTime? ActualAwardDate { get; set; }

    public string ActualAwardDateTimeZone { get; set; }

    public string SDCCredit { get; set; }

    public string FirmRole { get; set; }

    public string FirmLiability { get; set; }

    public string FirmMgtFee { get; set; }

    public bool IsPricingDateChange { get; set; }

    public bool IsRopDateChange { get; set; }

    public bool IsSettDateChange { get; set; }

    public bool IsAWDateChange { get; set; }

    public bool IsDatedDateChange { get; set; }

    public bool IsSDCCreditChange { get; set; }

    public bool IsFirmRoleChange { get; set; }

    public bool IsFirmLiabityChange { get; set; }

    public bool IsFirmMgtFeeChange { get; set; }

    public bool IsActualTimeZoneChange { get; set; }

    public string SeriesDataUpdate { get; set; }
  }
}
