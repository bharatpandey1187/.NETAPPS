﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RegulatoryCheckListCompetitiveViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RegulatoryCheckListCompetitiveViewModelContainer : ViewModelBase
  {
    public RegulatoryCheckListCompetitiveViewModelContainer()
    {
      this.IssueRegulatoryCheckListViewModel = new CompetitiveIssueRegulatoryCheckListViewModel();
      this.MunicipalAdvisorViewModel = new MunicipalAdvisorViewModel();
      this.Rule15c212ViewModel = new Rule15c212ViewModel();
      this.RuleG17G23ViewModel = new RuleG17G23ViewModel();
      this.RuleG34cViewModel = new RuleG34cViewModel();
      this.RuleG32ViewModel = new RuleG32ViewModel();
      this.ExpensesViewModel = new ExpensesViewModel();
      this.RegulatoryPnLViewModel = new RegulatoryPnLViewModel();
      this.DisclosureDiligenceRegChecklistViewModel = new DisclosureDiligenceRegChecklistViewModel();
      this.ClientMAExemptionDetail = new List<IrisSoftware.iMPACT.Data.ClientMAExemptionDetail>();
    }

    public CompetitiveIssueRegulatoryCheckListViewModel IssueRegulatoryCheckListViewModel { get; set; }

    public MunicipalAdvisorViewModel MunicipalAdvisorViewModel { get; set; }

    public Rule15c212ViewModel Rule15c212ViewModel { get; set; }

    public RuleG17G23ViewModel RuleG17G23ViewModel { get; set; }

    public RuleG34cViewModel RuleG34cViewModel { get; set; }

    public RuleG32ViewModel RuleG32ViewModel { get; set; }

    public ExpensesViewModel ExpensesViewModel { get; set; }

    public RegulatoryPnLViewModel RegulatoryPnLViewModel { get; set; }

    public DisclosureDiligenceRegChecklistViewModel DisclosureDiligenceRegChecklistViewModel { get; set; }

    public List<IrisSoftware.iMPACT.Data.ClientMAExemptionDetail> ClientMAExemptionDetail { get; set; }

    public bool EnableDisbleIRMAOtherReason { get; set; }
  }
}
