﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PropertyDescriptorViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PropertyDescriptorViewModel : ViewModelBase
  {
    public PropertyDescriptorViewModel()
    {
    }

    public PropertyDescriptorViewModel(PropertyDescriptor propertyDescriptor)
    {
      this.PropertyDescriptorID = propertyDescriptor.PropertyDescriptorID;
      this.Key = propertyDescriptor.Key;
      this.Caption = propertyDescriptor.Caption;
      this.DataType = propertyDescriptor.DataType;
      this.EntityID = propertyDescriptor.EntityID;
      this.Format = propertyDescriptor.Format;
      this.Order = propertyDescriptor.Order;
      this.EffectFrom = propertyDescriptor.EffectFrom;
      this.EffectTill = propertyDescriptor.EffectTill;
      this.CreatedBy = propertyDescriptor.CreatedBy;
      this.CreatedDate = propertyDescriptor.CreatedDate;
      this.ModifiedBy = propertyDescriptor.ModifiedBy;
      this.ModifiedDate = propertyDescriptor.ModifiedDate;
      this.IsDirty = false;
    }

    public PropertyDescriptor GetPropertyDescriptor() => new PropertyDescriptor()
    {
      PropertyDescriptorID = this.PropertyDescriptorID,
      Key = this.Key,
      Caption = this.Caption,
      DataType = this.DataType,
      EntityID = this.EntityID,
      Format = this.Format,
      Order = this.Order,
      EffectFrom = this.EffectFrom,
      EffectTill = this.EffectTill,
      CreatedBy = this.CreatedBy,
      CreatedDate = DateTime.Now,
      ModifiedBy = this.ModifiedBy,
      ModifiedDate = DateTime.Now
    };

    public long PropertyDescriptorID { get; set; }

    public string Key { get; set; }

    public string Caption { get; set; }

    public long EntityID { get; set; }

    public string DataType { get; set; }

    public string Format { get; set; }

    public int Order { get; set; }

    public DateTime EffectFrom { get; set; }

    public DateTime? EffectTill { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedDate { get; set; }
  }
}
