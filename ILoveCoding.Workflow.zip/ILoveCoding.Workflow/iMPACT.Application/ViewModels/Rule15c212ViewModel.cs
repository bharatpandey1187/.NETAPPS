﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.Rule15c212ViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class Rule15c212ViewModel
  {
    public long Rule15c212RegCheckListID { get; set; }

    public bool? IsObtainedAndReviwedStatement { get; set; }

    public string TypeOfDoc { get; set; }

    public string DateReviewed { get; set; }

    public string DateReceived { get; set; }

    public string MethodDocDeemedFinal { get; set; }

    [AbsoluteDate]
    public DateTime? DateDocDeemedFinal { get; set; }

    public string ReasonForNotObtainingOrReview { get; set; }

    public bool? HasMeetAdoptedGuideLines { get; set; }

    public string ReasonForNotAdoptingGuideLines { get; set; }

    public long? WasOfficialDocAmended { get; set; }

    [AbsoluteDate]
    public DateTime? DocAmendedDate { get; set; }

    public bool? IsSlaMeet { get; set; }

    public string IssuerAndObligorCovenantMade { get; set; }

    public string SlaViolationReason { get; set; }

    public bool? IsDilegenceReviewConducted { get; set; }

    public bool? IsDilegenceCallOrMeeting { get; set; }

    [AbsoluteDate]
    public DateTime? DilegenceMeetingDate { get; set; }

    public string DilegenceReviewMethod { get; set; }

    public long? DidOutSideCounselAssisted { get; set; }

    public string ReasonForNoAssistence { get; set; }

    public bool? IsIssuerAndObligorAreInAggrement { get; set; }

    public string IssuerAndObligorAggrementPlace { get; set; }

    public string IssuerAndObligorNonAggrementReason { get; set; }

    public bool? IsReviewedEMMAAndNRMSIR { get; set; }

    public bool? DidUnderWriterAssisted { get; set; }

    [AbsoluteDate]
    public DateTime? EMMAReviewDate { get; set; }

    public bool? IsIssuerAndObligorCompliance { get; set; }

    public string IncidentOfNonCompliance { get; set; }

    public bool? WasLegalAndComplianceConsulted { get; set; }

    [AbsoluteDate]
    public DateTime? LegalAndComplianceDate { get; set; }

    public string ReasonForNoLegalConsultaion { get; set; }

    public bool? WasCDAFindingsSatifactory { get; set; }

    public string CDAFindingsUnSatisfactoryReason { get; set; }

    public string WasLegalAndComplianceConsultedReason { get; set; }
  }
}
