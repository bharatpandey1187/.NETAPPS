﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PartnerDetailViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PartnerDetailViewModel : ViewModelBase
  {
    public PartnerDetailViewModel()
    {
    }

    public PartnerDetailViewModel(PartnerContact partnerContact)
    {
      this.PartnerContactID = partnerContact.PartnerContactID;
      this.PartnerID = partnerContact.PartnerID;
      this.Name = partnerContact.Name != null ? partnerContact.Name.Trim() : "";
      this.StreetAddress = partnerContact.StreetAddress != null ? partnerContact.StreetAddress.Trim() : "";
      this.City = partnerContact.City != null ? partnerContact.City.Trim() : "";
      this.Phone = partnerContact.Phone;
      this.Fax = partnerContact.Fax;
      this.Title = partnerContact.Title;
      this.Email = partnerContact.Email;
      this.Zip = partnerContact.Zip;
      this.IsActive = partnerContact.IsActive;
      this.IsDefault = partnerContact.IsDefault;
      this.State = partnerContact.State;
      this.StateName = partnerContact.StateName;
      this.IsContactUsedInEntity = partnerContact.IsContactUsedInEntity;
      this.PartnerContactAddressID = partnerContact.PartnerContactAddressID;
      this.NameTitle = partnerContact.NameTitle;
      this.FirstName = partnerContact.FirstName;
      this.LastName = partnerContact.LastName;
      this.Suffix = partnerContact.Suffix;
      this.Mobile = partnerContact.Mobile;
    }

    public PartnerContact GetPartnerContact() => new PartnerContact()
    {
      PartnerContactID = this.PartnerContactID,
      PartnerID = this.PartnerID,
      Name = this.Name != null ? this.Name.Trim() : "",
      Title = this.Title != null ? this.Title.Trim() : "",
      StreetAddress = this.StreetAddress != null ? this.StreetAddress.Trim() : "",
      City = this.City != null ? this.City.Trim() : "",
      Phone = this.Phone,
      Fax = this.Fax,
      Email = this.Email,
      State = this.State,
      StateName = this.StateName,
      Zip = this.Zip,
      IsActive = this.IsActive,
      IsDefault = this.IsDefault,
      PartnerContactAddressID = this.PartnerContactAddressID,
      NameTitle = this.NameTitle,
      FirstName = this.FirstName,
      LastName = this.LastName,
      Suffix = this.Suffix,
      Mobile = this.Mobile
    };

    public long PartnerContactID { get; set; }

    public long PartnerID { get; set; }

    [Required(ErrorMessage = "Partner Name cannot be blank.")]
    [StringLength(80, ErrorMessage = "Length of Partner Name field should be less than or equal to 80 characters.")]
    [RegexValidator("^$|(^[A-Za-z',. ]+$)", MessageTemplate = "Only alphabets and spaces ,.' are allowed.")]
    public string Name { get; set; }

    public string NameTitle { get; set; }

    [Required(ErrorMessage = "First Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string FirstName { get; set; }

    [Required(ErrorMessage = "Last Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string LastName { get; set; }

    public string Suffix { get; set; }

    [StringLength(12, ErrorMessage = "Length of Phone field should be equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    public string Phone { get; set; }

    [StringLength(12, ErrorMessage = "Length of Mobile field should be equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Mobile number should be in XXX-XXX-XXXX format.")]
    public string Mobile { get; set; }

    [StringLength(12, ErrorMessage = "Length of Fax field should be equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Fax number should be in XXX-XXX-XXXX format.")]
    public string Fax { get; set; }

    [RegexValidator("^$|(^[A-Za-z-\\\\,& ./]+$)", MessageTemplate = "Only alphabets, comma, slash, dash, &, period and space are allowed.")]
    [StringLength(100, ErrorMessage = "Length of Title field should be less than or equal to 100 characters.")]
    public string Title { get; set; }

    [RegexValidator("^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", MessageTemplate = "Email address is not valid.")]
    [StringLength(100, ErrorMessage = "Length of Email field should be less than or equal to 100 characters.")]
    public string Email { get; set; }

    public string StreetAddress { get; set; }

    public string City { get; set; }

    public long? State { get; set; }

    public string StateName { get; set; }

    public string Zip { get; set; }

    public bool IsActive { get; set; }

    public bool IsDefault { get; set; }

    public bool IsContactUsedInEntity { get; set; }

    public long? PartnerContactAddressID { get; set; }
  }
}
