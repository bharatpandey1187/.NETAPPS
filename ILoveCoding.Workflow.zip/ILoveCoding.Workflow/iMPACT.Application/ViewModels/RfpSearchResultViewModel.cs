﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.RfpSearchResultViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class RfpSearchResultViewModel
  {
    public long AppTransactionID { get; set; }

    public string RFPNumber { get; set; }

    public string RFPName { get; set; }

    public string RFPStatus { get; set; }

    public string RFPReviewStatus { get; set; }

    public string PowerID { get; set; }

    public string Issuer { get; set; }

    public string Borrower { get; set; }

    public string Guarantor { get; set; }

    public string RFPType { get; set; }

    public string State { get; set; }

    public string County { get; set; }

    public string MaterialType { get; set; }

    public string HybridSolutionIndicator { get; set; }

    public string DualProposalProposed { get; set; }

    public string InformationalMERGRequired { get; set; }

    public string RFPMAExemption { get; set; }

    public DateTime? RFPMAExemptionDate { get; set; }

    public string RFPMAExemptionDateValue { get; set; }

    public string IRMAMAExemption { get; set; }

    public DateTime? IRMAMAExemptionDate { get; set; }

    public string IRMAMAExemptionDateValue { get; set; }

    public string UWMAExemption { get; set; }

    public DateTime? UWMAExemptionDate { get; set; }

    public string UWMAExemptionDateValue { get; set; }

    public string ApprovedDerivativeMarketer { get; set; }

    public Decimal? ParAmount { get; set; }

    public string ExpectedFirmRole { get; set; }

    public Decimal? ExpectedFirmLiabilityPercentage { get; set; }

    public string AssignedFirmRole { get; set; }

    public Decimal? AssignedFirmLiabilityPercentage { get; set; }

    public string LeadBanker { get; set; }

    public string Banker { get; set; }

    public string LeadAnalyst { get; set; }

    public string Analyst { get; set; }

    public string SupervisoryPrincipal { get; set; }

    public string BankRM { get; set; }

    public string FinancialAdvisor { get; set; }

    public string EscrowVerificationAgent { get; set; }

    public string EscrowSecuritiesProvider { get; set; }

    public string EscrowAgentForRefundedBonds { get; set; }

    public string PayingAgent { get; set; }

    public string RemarketingAgent { get; set; }

    public string Trustee { get; set; }

    public string OtherAdvisorAgents { get; set; }

    public string BondCounsel { get; set; }

    public string UnderwriterCounsel { get; set; }

    public string DisclosureCounsel { get; set; }

    public string OtherCounsels { get; set; }

    public string Purpose { get; set; }

    public string TransactionType { get; set; }

    public string SecurityType { get; set; }

    public string GeneralCategory { get; set; }

    public string FedTaxable { get; set; }

    public string StateTaxable { get; set; }

    public string AMTTaxable { get; set; }

    public string BankQualified { get; set; }

    public Decimal? GrossSpread { get; set; }

    public Decimal? EstGrossRev { get; set; }

    public DateTime? CreatedOn { get; set; }

    public string CreatedOnValue { get; set; }

    public DateTime? ResponseDueDateTime { get; set; }

    public string ResponseDueDateTimeZone { get; set; }

    public string ResponseDueDateTimeValue { get; set; }

    public DateTime? SubmissionDateTime { get; set; }

    public string SubmissionDateTimeZone { get; set; }

    public string SubmissionDateTimeValue { get; set; }

    public DateTime? SupervisoryPrincipalReviewDate { get; set; }

    public string SupervisoryPrincipalReviewDateValue { get; set; }

    public DateTime? SupervisoryPrincipalApprovalDate { get; set; }

    public string SupervisoryPrincipalApprovalDateValue { get; set; }

    public string MoodyRatingLT { get; set; }

    public string SPRatingLT { get; set; }

    public string KrollRatingLT { get; set; }

    public string FitchRatingLT { get; set; }

    public string SentTo3Firms { get; set; }
  }
}
