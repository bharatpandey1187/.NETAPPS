﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ClientSearchViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ClientSearchViewModel : ViewModelBase
  {
    public ClientSearchViewModel()
    {
      this.States = new List<KeyValuePair<long, string>>();
      this.SelectedStates = new List<KeyPair>();
      this.IsStateIn = true;
      this.AllFields = new List<SearchResultField>();
      this.SelectedAllFields = new List<SearchResultField>();
      this.SelectedFields = new List<SearchResultField>();
      this.FieldsToSelect = new List<SearchResultField>();
    }

    public string Name { get; set; }

    public string City { get; set; }

    public List<KeyPair> SelectedStates { get; set; }

    public bool IsStateIn { get; set; }

    public string Zip { get; set; }

    public string TaxID { get; set; }

    public string CUSIP { get; set; }

    public string IsActive { get; set; }

    public string MAExempt { get; set; }

    public string ExternalClientID { get; set; }

    public List<SearchResultField> AllFields { get; set; }

    public List<SearchResultField> SelectedAllFields { get; set; }

    public List<SearchResultField> SelectedFields { get; set; }

    public List<SearchResultField> FieldsToSelect { get; set; }

    public bool CanCreatePublicBookmark { get; set; }

    public List<KeyValuePair<long, string>> States { get; set; }
  }
}
