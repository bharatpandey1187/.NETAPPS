﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.EntityGroupRoleViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class EntityGroupRoleViewModelContainer : ViewModelBase
  {
    public EntityGroupRoleViewModelContainer()
    {
      this.EntityTypes = new List<LookupItemViewModel>();
      this.RoleTypes = new List<RoleTypesViewModel>();
      this.EntityGroupRoles = new List<EntityGroupRoleViewModel>();
      this.Roles = new List<RoleViewModel>();
    }

    public EntityGroupRoleViewModelContainer(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public List<LookupItemViewModel> EntityTypes { get; set; }

    public List<RoleTypesViewModel> RoleTypes { get; set; }

    public List<EntityGroupRoleViewModel> EntityGroupRoles { get; set; }

    public List<RoleViewModel> Roles { get; set; }

    public long? EntityId { get; set; }

    public long? RoleTypesId { get; set; }

    public long? GroupId { get; set; }

    public string SelectedRoles { get; set; }
  }
}
