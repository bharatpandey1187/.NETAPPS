﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ExpenseRevenueViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ExpenseRevenueViewModel : ViewModelBase
  {
    public ExpenseRevenueViewModel()
    {
    }

    public ExpenseRevenueViewModel(ExpenseRevenue expenseRevenue)
    {
      this.ExpenseRevenueID = expenseRevenue.ExpenseRevenueID;
      this.AppTransactionID = expenseRevenue.AppTransactionID;
      this.ERNumber = expenseRevenue.ERNumber;
      this.IssueNumber = expenseRevenue.IssueNumber;
      this.IssueName = expenseRevenue.IssueName;
      this.IssueStatus = expenseRevenue.IssueStatus;
      this.ReviewStatus = expenseRevenue.ReviewStatus;
      this.ERStatus = expenseRevenue.ERStatus;
      this.IssuerId = expenseRevenue.IssuerId;
      this.IssuerName = expenseRevenue.IssuerName;
      this.StateName = expenseRevenue.StateName;
      this.StateId = expenseRevenue.StateId;
      this.FirmRole = expenseRevenue.FirmRole;
      this.FirmRoleId = expenseRevenue.FirmRoleId;
      this.OfferingType = expenseRevenue.OfferingType;
      this.OfferingTypeId = expenseRevenue.OfferingTypeId;
      this.SaleDate = expenseRevenue.SaleDate;
      this.SettlementClosingDate = expenseRevenue.SettlementClosingDate;
      this.ParAmount = expenseRevenue.ParAmount;
      this.NbrOfCusip = expenseRevenue.NbrOfCusip;
      this.NbrOfSeries = expenseRevenue.NbrOfSeries;
      this.FirmLiabilityPerc = expenseRevenue.FirmLiabilityPerc;
      this.FirmMgmtFeePerc = expenseRevenue.FirmMgmtFeePerc;
      this.SyndicateMember = expenseRevenue.SyndicateMember;
      this.ProjManagementFee = expenseRevenue.ProjManagementFee;
      this.ProjManagementFeePerThou = expenseRevenue.ProjManagementFeePerThou;
      this.ProjTakedown = expenseRevenue.ProjTakedown;
      this.ProjTakedownPerThou = expenseRevenue.ProjTakedownPerThou;
      this.ProjExpenses = expenseRevenue.ProjExpenses;
      this.ProjExpensesPerThou = expenseRevenue.ProjExpensesPerThou;
      this.ProjStructuringFee = expenseRevenue.ProjStructuringFee;
      this.ProjStructuringFeePerThou = expenseRevenue.ProjStructuringFeePerThou;
      this.ProjGrossSpread = expenseRevenue.ProjGrossSpread;
      this.ProjGrossSpreadPerThou = expenseRevenue.ProjGrossSpreadPerThou;
      this.ActManagementFee = expenseRevenue.ActManagementFee;
      this.ActManagementFeePerThou = expenseRevenue.ActManagementFeePerThou;
      this.ActTakedown = expenseRevenue.ActTakedown;
      this.ActTakedownPerThou = expenseRevenue.ActTakedownPerThou;
      this.ActExpenses = expenseRevenue.ActExpenses;
      this.ActExpensesPerThou = expenseRevenue.ActExpensesPerThou;
      this.ActStructuringFee = expenseRevenue.ActStructuringFee;
      this.ActStructuringFeePerThou = expenseRevenue.ActStructuringFeePerThou;
      this.ActGrossSpread = expenseRevenue.ActGrossSpread;
      this.ActGrossSpreadPerThou = expenseRevenue.ActGrossSpreadPerThou;
      this.ProjFirmUnderwritingRevenue = expenseRevenue.ProjFirmUnderwritingRevenue;
      this.ProjFinancialAdvisory = expenseRevenue.ProjFinancialAdvisory;
      this.ProjRemarketingFee = expenseRevenue.ProjRemarketingFee;
      this.ProjOtherFee = expenseRevenue.ProjOtherFee;
      this.ProjTotalRevenues = expenseRevenue.ProjTotalRevenues;
      this.ActFirmUnderwritingRevenue = expenseRevenue.ActFirmUnderwritingRevenue;
      this.ActFinancialAdvisory = expenseRevenue.ActFinancialAdvisory;
      this.ActRemarketingFee = expenseRevenue.ActRemarketingFee;
      this.ActOtherFee = expenseRevenue.ActOtherFee;
      this.ActTotalRevenues = expenseRevenue.ActTotalRevenues;
      this.ProjCUSIP = expenseRevenue.ProjCUSIP;
      this.ProjCalPSA = expenseRevenue.ProjCalPSA;
      this.ProjMSRB = expenseRevenue.ProjMSRB;
      this.ProjCDIAC = expenseRevenue.ProjCDIAC;
      this.ProjSIFMA = expenseRevenue.ProjSIFMA;
      this.ProjCalMuniStats = expenseRevenue.ProjCalMuniStats;
      this.ProjBookrunningCharges = expenseRevenue.ProjBookrunningCharges;
      this.ProjCMBDA = expenseRevenue.ProjCMBDA;
      this.ProjDayLoan = expenseRevenue.ProjDayLoan;
      this.ProjMACMI = expenseRevenue.ProjMACMI;
      this.ProjTicketing = expenseRevenue.ProjTicketing;
      this.ProjMIPF = expenseRevenue.ProjMIPF;
      this.ProjTelecommunication = expenseRevenue.ProjTelecommunication;
      this.ProjMACTX = expenseRevenue.ProjMACTX;
      this.ProjLegal = expenseRevenue.ProjLegal;
      this.ProjMACOH = expenseRevenue.ProjMACOH;
      this.ProjDTCCharges = expenseRevenue.ProjDTCCharges;
      this.ProjLessExpenseReimbursement = expenseRevenue.ProjLessExpenseReimbursement;
      this.ProjClearanceExpenses = expenseRevenue.ProjClearanceExpenses;
      this.ProjOtherExpenses = expenseRevenue.ProjOtherExpenses;
      this.ProjTotalFinancingExpenses = expenseRevenue.ProjTotalFinancingExpenses;
      this.ActCUSIP = expenseRevenue.ActCUSIP;
      this.ActCalPSA = expenseRevenue.ActCalPSA;
      this.ActMSRB = expenseRevenue.ActMSRB;
      this.ActCDIAC = expenseRevenue.ActCDIAC;
      this.ActSIFMA = expenseRevenue.ActSIFMA;
      this.ActCalMuniStats = expenseRevenue.ActCalMuniStats;
      this.ActBookrunningCharges = expenseRevenue.ActBookrunningCharges;
      this.ActCMBDA = expenseRevenue.ActCMBDA;
      this.ActDayLoan = expenseRevenue.ActDayLoan;
      this.ActMACMI = expenseRevenue.ActMACMI;
      this.ActTicketing = expenseRevenue.ActTicketing;
      this.ActMIPF = expenseRevenue.ActMIPF;
      this.ActTelecommunication = expenseRevenue.ActTelecommunication;
      this.ActMACTX = expenseRevenue.ActMACTX;
      this.ActLegal = expenseRevenue.ActLegal;
      this.ActMACOH = expenseRevenue.ActMACOH;
      this.ActDTCCharges = expenseRevenue.ActDTCCharges;
      this.ActLessExpenseReimbursement = expenseRevenue.ActLessExpenseReimbursement;
      this.ActClearanceExpenses = expenseRevenue.ActClearanceExpenses;
      this.ActOtherExpenses = expenseRevenue.ActOtherExpenses;
      this.ActTotalFinancingExpenses = expenseRevenue.ActTotalFinancingExpenses;
      this.ProjTotalRevenueBeforeExpenses = expenseRevenue.ProjTotalRevenueBeforeExpenses;
      this.ProjLessNetDealExpenses = expenseRevenue.ProjLessNetDealExpenses;
      this.ProjLessCoManagerDistributions = expenseRevenue.ProjLessCoManagerDistributions;
      this.ProjNetRevenues = expenseRevenue.ProjNetRevenues;
      this.ActTotalRevenueBeforeExpenses = expenseRevenue.ActTotalRevenueBeforeExpenses;
      this.ActLessNetDealExpenses = expenseRevenue.ActLessNetDealExpenses;
      this.ActLessCoManagerDistributions = expenseRevenue.ActLessCoManagerDistributions;
      this.ActNetRevenues = expenseRevenue.ActNetRevenues;
      this.ProjTakedownRevenues = expenseRevenue.ProjTakedownRevenues;
      this.ProjAdjustmentToTakedown = expenseRevenue.ProjAdjustmentToTakedown;
      this.ProjAdjustedTakedown = expenseRevenue.ProjAdjustedTakedown;
      this.ActTakedownRevenues = expenseRevenue.ActTakedownRevenues;
      this.ActAdjustmentToTakedown = expenseRevenue.ActAdjustmentToTakedown;
      this.ActAdjustedTakedown = expenseRevenue.ActAdjustedTakedown;
      this.ProjPublicFinance = expenseRevenue.ProjPublicFinance;
      this.ProjSalesTradingAndUnderwriting = expenseRevenue.ProjSalesTradingAndUnderwriting;
      this.ProjTotalRevenuesBreakdown = expenseRevenue.ProjTotalRevenuesBreakdown;
      this.ActPublicFinance = expenseRevenue.ActPublicFinance;
      this.ActSalesTradingAndUnderwriting = expenseRevenue.ActSalesTradingAndUnderwriting;
      this.ActTotalRevenuesBreakdown = expenseRevenue.ActTotalRevenuesBreakdown;
      this.CreatedBy = expenseRevenue.CreatedBy;
      this.CreatedOn = expenseRevenue.CreatedOn;
      this.ModifiedBy = expenseRevenue.ModifiedBy;
      this.ModifiedOn = expenseRevenue.ModifiedOn;
    }

    public ExpenseRevenue GetExpenseRevenue() => new ExpenseRevenue()
    {
      ExpenseRevenueID = this.ExpenseRevenueID,
      AppTransactionID = this.AppTransactionID,
      ERNumber = this.ERNumber,
      IssueNumber = this.IssueNumber,
      IssueStatus = this.IssueStatus,
      ReviewStatus = this.ReviewStatus,
      ERStatus = this.ERStatus,
      IssueName = this.IssueName,
      IssuerId = this.IssuerId,
      IssuerName = this.IssuerName,
      StateName = this.StateName,
      StateId = this.StateId,
      FirmRole = this.FirmRole,
      FirmRoleId = this.FirmRoleId,
      OfferingType = this.OfferingType,
      OfferingTypeId = this.OfferingTypeId,
      SaleDate = this.SaleDate,
      SettlementClosingDate = this.SettlementClosingDate,
      ParAmount = this.ParAmount,
      NbrOfCusip = this.NbrOfCusip,
      NbrOfSeries = this.NbrOfSeries,
      FirmLiabilityPerc = this.FirmLiabilityPerc,
      FirmMgmtFeePerc = this.FirmMgmtFeePerc,
      ProjManagementFee = this.ProjManagementFee,
      ProjManagementFeePerThou = this.ProjManagementFeePerThou,
      ProjTakedown = this.ProjTakedown,
      ProjTakedownPerThou = this.ProjTakedownPerThou,
      ProjExpenses = this.ProjExpenses,
      ProjExpensesPerThou = this.ProjExpensesPerThou,
      ProjStructuringFee = this.ProjStructuringFee,
      ProjStructuringFeePerThou = this.ProjStructuringFeePerThou,
      ProjGrossSpread = this.ProjGrossSpread,
      ProjGrossSpreadPerThou = this.ProjGrossSpreadPerThou,
      ActManagementFee = this.ActManagementFee,
      ActManagementFeePerThou = this.ActManagementFeePerThou,
      ActTakedown = this.ActTakedown,
      ActTakedownPerThou = this.ActTakedownPerThou,
      ActExpenses = this.ActExpenses,
      ActExpensesPerThou = this.ActExpensesPerThou,
      ActStructuringFee = this.ActStructuringFee,
      ActStructuringFeePerThou = this.ActStructuringFeePerThou,
      ActGrossSpread = this.ActGrossSpread,
      ActGrossSpreadPerThou = this.ActGrossSpreadPerThou,
      ProjFirmUnderwritingRevenue = this.ProjFirmUnderwritingRevenue,
      ProjFinancialAdvisory = this.ProjFinancialAdvisory,
      ProjRemarketingFee = this.ProjRemarketingFee,
      ProjOtherFee = this.ProjOtherFee,
      ProjTotalRevenues = this.ProjTotalRevenues,
      ActFirmUnderwritingRevenue = this.ActFirmUnderwritingRevenue,
      ActFinancialAdvisory = this.ActFinancialAdvisory,
      ActRemarketingFee = this.ActRemarketingFee,
      ActOtherFee = this.ActOtherFee,
      ActTotalRevenues = this.ActTotalRevenues,
      ProjCUSIP = this.ProjCUSIP,
      ProjCalPSA = this.ProjCalPSA,
      ProjMSRB = this.ProjMSRB,
      ProjCDIAC = this.ProjCDIAC,
      ProjSIFMA = this.ProjSIFMA,
      ProjCalMuniStats = this.ProjCalMuniStats,
      ProjBookrunningCharges = this.ProjBookrunningCharges,
      ProjCMBDA = this.ProjCMBDA,
      ProjDayLoan = this.ProjDayLoan,
      ProjMACMI = this.ProjMACMI,
      ProjTicketing = this.ProjTicketing,
      ProjMIPF = this.ProjMIPF,
      ProjTelecommunication = this.ProjTelecommunication,
      ProjMACTX = this.ProjMACTX,
      ProjLegal = this.ProjLegal,
      ProjMACOH = this.ProjMACOH,
      ProjDTCCharges = this.ProjDTCCharges,
      ProjLessExpenseReimbursement = this.ProjLessExpenseReimbursement,
      ProjClearanceExpenses = this.ProjClearanceExpenses,
      ProjOtherExpenses = this.ProjOtherExpenses,
      ProjTotalFinancingExpenses = this.ProjTotalFinancingExpenses,
      ActCUSIP = this.ActCUSIP,
      ActCalPSA = this.ActCalPSA,
      ActMSRB = this.ActMSRB,
      ActCDIAC = this.ActCDIAC,
      ActSIFMA = this.ActSIFMA,
      ActCalMuniStats = this.ActCalMuniStats,
      ActBookrunningCharges = this.ActBookrunningCharges,
      ActCMBDA = this.ActCMBDA,
      ActDayLoan = this.ActDayLoan,
      ActMACMI = this.ActMACMI,
      ActTicketing = this.ActTicketing,
      ActMIPF = this.ActMIPF,
      ActTelecommunication = this.ActTelecommunication,
      ActMACTX = this.ActMACTX,
      ActLegal = this.ActLegal,
      ActMACOH = this.ActMACOH,
      ActDTCCharges = this.ActDTCCharges,
      ActLessExpenseReimbursement = this.ActLessExpenseReimbursement,
      ActClearanceExpenses = this.ActClearanceExpenses,
      ActOtherExpenses = this.ActOtherExpenses,
      ActTotalFinancingExpenses = this.ActTotalFinancingExpenses,
      ProjTotalRevenueBeforeExpenses = this.ProjTotalRevenueBeforeExpenses,
      ProjLessNetDealExpenses = this.ProjLessNetDealExpenses,
      ProjLessCoManagerDistributions = this.ProjLessCoManagerDistributions,
      ProjNetRevenues = this.ProjNetRevenues,
      ActTotalRevenueBeforeExpenses = this.ActTotalRevenueBeforeExpenses,
      ActLessNetDealExpenses = this.ActLessNetDealExpenses,
      ActLessCoManagerDistributions = this.ActLessCoManagerDistributions,
      ActNetRevenues = this.ActNetRevenues,
      ProjTakedownRevenues = this.ProjTakedownRevenues,
      ProjAdjustmentToTakedown = this.ProjAdjustmentToTakedown,
      ProjAdjustedTakedown = this.ProjAdjustedTakedown,
      ActTakedownRevenues = this.ActTakedownRevenues,
      ActAdjustmentToTakedown = this.ActAdjustmentToTakedown,
      ActAdjustedTakedown = this.ActAdjustedTakedown,
      ProjPublicFinance = this.ProjPublicFinance,
      ProjSalesTradingAndUnderwriting = this.ProjSalesTradingAndUnderwriting,
      ProjTotalRevenuesBreakdown = this.ProjTotalRevenuesBreakdown,
      ActPublicFinance = this.ActPublicFinance,
      ActSalesTradingAndUnderwriting = this.ActSalesTradingAndUnderwriting,
      ActTotalRevenuesBreakdown = this.ActTotalRevenuesBreakdown,
      CreatedBy = this.CreatedBy,
      CreatedOn = this.CreatedOn,
      ModifiedBy = this.ModifiedBy,
      ModifiedOn = this.ModifiedOn,
      SyndicateMember = this.SyndicateMember
    };

    public long ExpenseRevenueID { get; set; }

    public long AppTransactionID { get; set; }

    public string IssueNumber { get; set; }

    public string IssueStatus { get; set; }

    public string ReviewStatus { get; set; }

    public string ERStatus { get; set; }

    public string ERNumber { get; set; }

    public string IssueName { get; set; }

    public long? IssuerId { get; set; }

    public string IssuerName { get; set; }

    public string StateName { get; set; }

    public long? StateId { get; set; }

    public string FirmRole { get; set; }

    public long FirmRoleId { get; set; }

    public string OfferingType { get; set; }

    public long? OfferingTypeId { get; set; }

    public DateTime? SaleDate { get; set; }

    public DateTime? SettlementClosingDate { get; set; }

    public Decimal? ParAmount { get; set; }

    public int? NbrOfCusip { get; set; }

    public int? NbrOfSeries { get; set; }

    public Decimal? FirmLiabilityPerc { get; set; }

    public Decimal? FirmMgmtFeePerc { get; set; }

    public List<ExpenseRevenueSyndicate> SyndicateMember { get; set; }

    public Decimal? ProjManagementFee { get; set; }

    public Decimal? ProjManagementFeePerThou { get; set; }

    public Decimal? ProjTakedown { get; set; }

    public Decimal? ProjTakedownPerThou { get; set; }

    public Decimal? ProjExpenses { get; set; }

    public Decimal? ProjExpensesPerThou { get; set; }

    public Decimal? ProjStructuringFee { get; set; }

    public Decimal? ProjStructuringFeePerThou { get; set; }

    public Decimal? ProjGrossSpread { get; set; }

    public Decimal? ProjGrossSpreadPerThou { get; set; }

    public Decimal? ActManagementFee { get; set; }

    public Decimal? ActManagementFeePerThou { get; set; }

    public Decimal? ActTakedown { get; set; }

    public Decimal? ActTakedownPerThou { get; set; }

    public Decimal? ActExpenses { get; set; }

    public Decimal? ActExpensesPerThou { get; set; }

    public Decimal? ActStructuringFee { get; set; }

    public Decimal? ActStructuringFeePerThou { get; set; }

    public Decimal? ActGrossSpread { get; set; }

    public Decimal? ActGrossSpreadPerThou { get; set; }

    public Decimal? ProjFirmUnderwritingRevenue { get; set; }

    public Decimal? ProjFinancialAdvisory { get; set; }

    public Decimal? ProjRemarketingFee { get; set; }

    public Decimal? ProjOtherFee { get; set; }

    public Decimal? ProjTotalRevenues { get; set; }

    public Decimal? ActFirmUnderwritingRevenue { get; set; }

    public Decimal? ActFinancialAdvisory { get; set; }

    public Decimal? ActRemarketingFee { get; set; }

    public Decimal? ActOtherFee { get; set; }

    public Decimal? ActTotalRevenues { get; set; }

    public Decimal? ProjCUSIP { get; set; }

    public Decimal? ProjCalPSA { get; set; }

    public Decimal? ProjMSRB { get; set; }

    public Decimal? ProjCDIAC { get; set; }

    public Decimal? ProjSIFMA { get; set; }

    public Decimal? ProjCalMuniStats { get; set; }

    public Decimal? ProjBookrunningCharges { get; set; }

    public Decimal? ProjCMBDA { get; set; }

    public Decimal? ProjDayLoan { get; set; }

    public Decimal? ProjMACMI { get; set; }

    public Decimal? ProjTicketing { get; set; }

    public Decimal? ProjMIPF { get; set; }

    public Decimal? ProjTelecommunication { get; set; }

    public Decimal? ProjMACTX { get; set; }

    public Decimal? ProjLegal { get; set; }

    public Decimal? ProjMACOH { get; set; }

    public Decimal? ProjDTCCharges { get; set; }

    public Decimal? ProjLessExpenseReimbursement { get; set; }

    public Decimal? ProjClearanceExpenses { get; set; }

    public Decimal? ProjOtherExpenses { get; set; }

    public Decimal? ProjTotalFinancingExpenses { get; set; }

    public Decimal? ActCUSIP { get; set; }

    public Decimal? ActCalPSA { get; set; }

    public Decimal? ActMSRB { get; set; }

    public Decimal? ActCDIAC { get; set; }

    public Decimal? ActSIFMA { get; set; }

    public Decimal? ActCalMuniStats { get; set; }

    public Decimal? ActBookrunningCharges { get; set; }

    public Decimal? ActCMBDA { get; set; }

    public Decimal? ActDayLoan { get; set; }

    public Decimal? ActMACMI { get; set; }

    public Decimal? ActTicketing { get; set; }

    public Decimal? ActMIPF { get; set; }

    public Decimal? ActTelecommunication { get; set; }

    public Decimal? ActMACTX { get; set; }

    public Decimal? ActLegal { get; set; }

    public Decimal? ActMACOH { get; set; }

    public Decimal? ActDTCCharges { get; set; }

    public Decimal? ActLessExpenseReimbursement { get; set; }

    public Decimal? ActClearanceExpenses { get; set; }

    public Decimal? ActOtherExpenses { get; set; }

    public Decimal? ActTotalFinancingExpenses { get; set; }

    public Decimal? ProjTotalRevenueBeforeExpenses { get; set; }

    public Decimal? ProjLessNetDealExpenses { get; set; }

    public Decimal? ProjLessCoManagerDistributions { get; set; }

    public Decimal? ProjNetRevenues { get; set; }

    public Decimal? ActTotalRevenueBeforeExpenses { get; set; }

    public Decimal? ActLessNetDealExpenses { get; set; }

    public Decimal? ActLessCoManagerDistributions { get; set; }

    public Decimal? ActNetRevenues { get; set; }

    public Decimal? ProjTakedownRevenues { get; set; }

    public Decimal? ProjAdjustmentToTakedown { get; set; }

    public Decimal? ProjAdjustedTakedown { get; set; }

    public Decimal? ActTakedownRevenues { get; set; }

    public Decimal? ActAdjustmentToTakedown { get; set; }

    public Decimal? ActAdjustedTakedown { get; set; }

    public Decimal? ProjPublicFinance { get; set; }

    public Decimal? ProjSalesTradingAndUnderwriting { get; set; }

    public Decimal? ProjTotalRevenuesBreakdown { get; set; }

    public Decimal? ActPublicFinance { get; set; }

    public Decimal? ActSalesTradingAndUnderwriting { get; set; }

    public Decimal? ActTotalRevenuesBreakdown { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }
  }
}
