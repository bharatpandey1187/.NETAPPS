﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.PNLTemplateViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class PNLTemplateViewModel : ViewModelBase
  {
    public PNLTemplateViewModel()
    {
    }

    public PNLTemplateViewModel(PNLTemplate pnlTemplate)
    {
      this.PNLTemplateName = pnlTemplate.PNLTemplateName;
      this.PNLTemplateID = pnlTemplate.PNLTemplateID;
      this.Key = pnlTemplate.Key;
      this.Formula = pnlTemplate.Formula;
      this.CanOverride = pnlTemplate.CanOverride;
      this.DataType = pnlTemplate.DataType;
      this.Format = pnlTemplate.Format;
      this.Notes = pnlTemplate.Notes;
      this.Indenting = pnlTemplate.Indenting;
      this.Operation = pnlTemplate.Operation;
      this.PnLSectionID = pnlTemplate.PnLSectionID;
      this.PnLSectionName = pnlTemplate.PnLSectionName;
      this.Id = pnlTemplate.Id;
      this.CategoryName = pnlTemplate.CategoryName;
      this.EvaluationSequence = pnlTemplate.EvaluationSequence;
    }

    public PNLTemplate GetPNLTemplateDetails() => new PNLTemplate()
    {
      PNLTemplateID = this.PNLTemplateID,
      PNLTemplateName = this.PNLTemplateName,
      EntityID = this.EntityID,
      SelectorFormula = this.SelectorFormula,
      WithEffectFrom = this.WithEffectFrom,
      CreatedBy = ""
    };

    public PNLTemplate GetPNLKeyDetails() => new PNLTemplate()
    {
      PNLTemplateID = this.PNLTemplateID,
      CategoryID = this.CategoryID,
      SectionID = this.SectionID,
      RowNumber = this.RowNumber,
      Caption = this.Caption,
      Key = this.Key,
      Formula = this.Formula,
      CanOverride = this.CanOverride,
      Format = this.Format,
      DataType = this.DataType,
      Notes = this.Notes,
      Operation = this.Operation,
      IsKeyUpdate = this.IsKeyUpdate,
      Indenting = this.Indenting
    };

    public int PNLTemplateID { get; set; }

    public int CategoryID { get; set; }

    public int RowNumber { get; set; }

    public string Caption { get; set; }

    public string PNLTemplateName { get; set; }

    public int EntityID { get; set; }

    public string SelectorFormula { get; set; }

    public DateTime WithEffectFrom { get; set; }

    public int SectionID { get; set; }

    public string Key { get; set; }

    public string Formula { get; set; }

    public bool CanOverride { get; set; }

    public string Notes { get; set; }

    public int Indenting { get; set; }

    public int Operation { get; set; }

    public string Format { get; set; }

    public string DataType { get; set; }

    public bool IsKeyUpdate { get; set; }

    public int PnLSectionID { get; set; }

    public string PnLSectionName { get; set; }

    public int Id { get; set; }

    public string CategoryName { get; set; }

    public int EvaluationSequence { get; set; }
  }
}
