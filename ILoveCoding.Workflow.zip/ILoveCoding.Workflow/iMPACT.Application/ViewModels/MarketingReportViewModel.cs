﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.MarketingReportViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class MarketingReportViewModel
  {
    public int AppTransactionID { get; set; }

    public string RFPNbr { get; set; }

    public string Issuer { get; set; }

    public string MaterialType { get; set; }

    public string LeadBanker { get; set; }

    public DateTime DateApprovedByPrincipal { get; set; }

    public DateTime DateSubmitted { get; set; }

    public string Status { get; set; }

    public string RfpMaExemption { get; set; }

    public DateTime RfpMaExemptionDate { get; set; }

    public string UwMaExemption { get; set; }

    public DateTime UwMaExemptionDate { get; set; }

    public string IrmaMaExemption { get; set; }

    public DateTime IrmaMaExemptionDate { get; set; }
  }
}
