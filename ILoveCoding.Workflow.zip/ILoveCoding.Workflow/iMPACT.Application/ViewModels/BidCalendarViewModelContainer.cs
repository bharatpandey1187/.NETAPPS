﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.BidCalendarViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class BidCalendarViewModelContainer : ViewModelBase
  {
    public BidCalendarViewModelContainer()
    {
    }

    public BidCalendarViewModelContainer(string strErrorMsg)
    {
      this.ErrorMessage = strErrorMsg;
      this.BidCalendars = new List<BidCalendarViewModel>();
    }

    public List<BidCalendarViewModel> BidCalendars { get; set; }

    public bool IsViewOnly { get; set; }

    public bool IsAllowShotlist { get; set; }
  }
}
