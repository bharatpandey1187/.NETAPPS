﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.UploadCategoryViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class UploadCategoryViewModel : ViewModelBase
  {
    public UploadCategoryViewModel()
    {
    }

    public UploadCategoryViewModel(UploadCategory uploadCategory)
    {
      this.EntityTypeDocTypeCategoryID = uploadCategory.EntityTypeDocTypeCategoryID;
      this.CategoryName = uploadCategory.CategoryName;
      this.EntityTypeID = uploadCategory.EntityTypeID;
      this.IsActive = uploadCategory.IsActive;
    }

    public UploadCategory GetDocumentCategory(
      UploadCategoryViewModel checkListCategoryViewModel)
    {
      return new UploadCategory()
      {
        EntityTypeDocTypeCategoryID = checkListCategoryViewModel.EntityTypeDocTypeCategoryID,
        EntityTypeID = checkListCategoryViewModel.EntityTypeID,
        CategoryName = checkListCategoryViewModel.CategoryName.Trim(),
        IsActive = checkListCategoryViewModel.IsActive
      };
    }

    public long EntityTypeDocTypeCategoryID { get; set; }

    [Required(ErrorMessage = "Category name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Category name length should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string CategoryName { get; set; }

    public long EntityTypeID { get; set; }

    public bool IsActive { get; set; }
  }
}
