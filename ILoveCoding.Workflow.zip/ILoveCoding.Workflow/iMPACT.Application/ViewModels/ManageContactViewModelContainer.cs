﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ManageContactViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ManageContactViewModelContainer : ViewModelBase
  {
    public ManageContactViewModelContainer()
    {
    }

    public ManageContactViewModelContainer(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public List<ManageContactViewModel> ManageContacts { get; set; }

    public List<LookupItemViewModel> States { get; set; }

    public string GoogleAppConfigValue { get; set; }

    public string OutlookAppConfigValue { get; set; }

    public bool IsViewOnly { get; set; }

    public bool IsAddManageContact { get; set; }

    public bool IsEditManageContact { get; set; }
  }
}
