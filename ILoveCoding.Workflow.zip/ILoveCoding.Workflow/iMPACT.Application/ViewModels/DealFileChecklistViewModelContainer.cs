﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DealFileChecklistViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DealFileChecklistViewModelContainer : ViewModelBase
  {
    public DealFileChecklistViewModelContainer()
    {
      this.DealChecklistDetail = new DealFileChecklistViewModel();
      this.DealFileChecklistIssue = new DealFileChecklistIssueViewModel();
      this.MandatoryStatusFile = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.OptionalStatusFile = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
    }

    public DealFileChecklistViewModelContainer(
      List<LookupItemMappings> lookupItems,
      DealFileChecklist DealFileChecklistInfo)
    {
      this.MandatoryStatusFile = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Mandatory Status of File".Trim().ToLower()));
      this.OptionalStatusFile = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key.Trim().ToLower() == "Optional Status of File".Trim().ToLower()));
      this.DealChecklistDetail = new DealFileChecklistViewModel(DealFileChecklistInfo);
      this.DealFileChecklistIssue = DealFileChecklistInfo.DealFileChecklistIssueDetail != null ? new DealFileChecklistIssueViewModel(DealFileChecklistInfo) : new DealFileChecklistIssueViewModel();
    }

    public DealFileChecklistViewModel DealChecklistDetail { get; set; }

    public DealFileChecklistIssueViewModel DealFileChecklistIssue { get; set; }

    public IEnumerable<LookupItemMappings> MandatoryStatusFile { get; set; }

    public IEnumerable<LookupItemMappings> OptionalStatusFile { get; set; }
  }
}
