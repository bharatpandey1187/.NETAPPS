﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueClientContactViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueClientContactViewModel : ViewModelBase
  {
    public IssueClientContactViewModel()
    {
    }

    public IssueClientContactViewModel(IssueClientContact issueClientContact)
    {
      this.ClientContactID = issueClientContact.ClientContactID;
      this.ClientID = issueClientContact.ClientID;
      this.ClientName = issueClientContact.ClientName;
      this.ClientContactName = issueClientContact.ClientContactName;
      this.Phone = issueClientContact.Phone;
      this.StreetAddress = issueClientContact.StreetAddress;
      this.City = issueClientContact.City;
      this.State = issueClientContact.State;
      this.StateName = issueClientContact.StateName;
      this.State = issueClientContact.State;
      this.Zip = issueClientContact.Zip;
      this.Title = issueClientContact.Title;
      this.Email = issueClientContact.Email;
      this.IsActive = issueClientContact.IsActive;
      this.IsDefault = issueClientContact.IsDefault;
      this.IsSelected = issueClientContact.IsSelected;
      this.ContactAddressID = issueClientContact.ContactAddressID;
      this.IsG17Contact = issueClientContact.IsG17Contact;
      this.NameTitle = issueClientContact.NameTitle;
      this.FirstName = issueClientContact.FirstName;
      this.LastName = issueClientContact.LastName;
      this.Suffix = issueClientContact.Suffix;
      this.Mobile = issueClientContact.Mobile;
      this.Fax = issueClientContact.Fax;
    }

    public IssueClientContact GetIssueClientContactDetail() => new IssueClientContact()
    {
      ClientContactID = this.ClientContactID,
      ClientID = this.ClientID,
      ClientName = this.ClientName,
      ClientContactName = this.ClientContactName.Trim(),
      Title = this.Title.Trim(),
      StreetAddress = this.StreetAddress.Trim(),
      City = this.City.Trim(),
      StateName = this.StateName,
      State = this.State,
      Zip = this.Zip,
      Email = this.Email.Trim(),
      Phone = this.Phone,
      IsSelected = this.IsSelected,
      IsActive = this.IsActive,
      IsDefault = this.IsDefault,
      ContactAddressID = this.ContactAddressID,
      IsG17Contact = this.IsG17Contact,
      NameTitle = this.NameTitle,
      FirstName = this.FirstName,
      LastName = this.LastName,
      Suffix = this.Suffix,
      Mobile = this.Mobile,
      Fax = this.Fax
    };

    public IssueClientContact GetIssueClientContactDetail(
      IssueClientContactViewModel issueClientContactViewModel)
    {
      return new IssueClientContact()
      {
        ClientContactID = issueClientContactViewModel.ClientContactID,
        ClientID = issueClientContactViewModel.ClientID,
        ClientName = issueClientContactViewModel.ClientName,
        ClientContactName = issueClientContactViewModel.ClientContactName.Trim(),
        StreetAddress = issueClientContactViewModel.StreetAddress.Trim(),
        City = issueClientContactViewModel.City.Trim(),
        State = issueClientContactViewModel.State,
        StateName = issueClientContactViewModel.StateName,
        Zip = issueClientContactViewModel.Zip,
        Phone = issueClientContactViewModel.Phone,
        Title = issueClientContactViewModel.Title.Trim(),
        Email = issueClientContactViewModel.Email.Trim(),
        IsActive = issueClientContactViewModel.IsActive,
        IsDefault = issueClientContactViewModel.IsDefault,
        IsSelected = issueClientContactViewModel.IsSelected,
        ContactAddressID = issueClientContactViewModel.ContactAddressID,
        IsG17Contact = issueClientContactViewModel.IsG17Contact,
        NameTitle = issueClientContactViewModel.NameTitle,
        FirstName = issueClientContactViewModel.FirstName,
        LastName = issueClientContactViewModel.LastName,
        Suffix = issueClientContactViewModel.Suffix,
        Mobile = issueClientContactViewModel.Mobile,
        Fax = issueClientContactViewModel.Fax
      };
    }

    public long ClientID { get; set; }

    public long ClientContactID { get; set; }

    [Required(ErrorMessage = "Client Name cannot be blank.")]
    [StringLength(300, ErrorMessage = "Length of Client Name field should be less than or equal to 300 characters.")]
    public string ClientName { get; set; }

    [Required(ErrorMessage = "Client Contact cannot be blank.")]
    [StringLength(100, ErrorMessage = "Length of Contact Name field should be less than or equal to 100 characters.")]
    [RegexValidator("^$|(^[A-Za-z',. ]+$)", MessageTemplate = "Only alphabets and spaces ,.' are allowed.")]
    public string ClientContactName { get; set; }

    public int? NameTitle { get; set; }

    [Required(ErrorMessage = "First Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string FirstName { get; set; }

    [Required(ErrorMessage = "Last Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string LastName { get; set; }

    public string Suffix { get; set; }

    [RegexValidator("^$|(^[A-Za-z-\\\\,& ./]+$)", MessageTemplate = "Only alphabets, comma, slash, dash, &, period and space are allowed.")]
    [StringLength(100, ErrorMessage = "Length of Contact Title field should be less than or equal to 100 characters.")]
    public string Title { get; set; }

    public string StreetAddress { get; set; }

    public string City { get; set; }

    public string StateName { get; set; }

    public long? State { get; set; }

    public string Zip { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Phone number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Length of Contact Phone field should be less than or equal to 12 characters.")]
    public string Phone { get; set; }

    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Mobile number should be in XXX-XXX-XXXX format.")]
    [StringLength(12, ErrorMessage = "Length of Contact Mobile field should be less than or equal to 12 characters.")]
    public string Mobile { get; set; }

    [StringLength(12, ErrorMessage = "Length of Contact Fax field should be less than or equal to 12 characters.")]
    [RegexValidator("^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))", MessageTemplate = "Fax number should be in XXX-XXX-XXXX format.")]
    public string Fax { get; set; }

    [RegexValidator("^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", MessageTemplate = "Email address is not valid.")]
    [StringLength(100, ErrorMessage = "Length of Contact Email field should be less than or equal to 100 characters.")]
    public string Email { get; set; }

    public bool IsActive { get; set; }

    public bool IsDefault { get; set; }

    public bool IsSelected { get; set; }

    public long? ContactAddressID { get; set; }

    public bool IsG17Contact { get; set; }
  }
}
