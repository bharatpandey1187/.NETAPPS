﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.Paged`1
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public sealed class Paged<T>
  {
    public Paged(IList<T> data, long total)
    {
      this.Data = data;
      this.Total = total;
    }

    public Paged(object data, long total)
    {
      this.JsonData = data;
      this.Total = total;
    }

    public IList<T> Data { get; set; }

    public object JsonData { get; set; }

    public long Total { get; set; }
  }
}
