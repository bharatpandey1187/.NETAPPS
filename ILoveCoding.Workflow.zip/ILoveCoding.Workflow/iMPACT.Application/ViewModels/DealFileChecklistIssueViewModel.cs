﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.DealFileChecklistIssueViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class DealFileChecklistIssueViewModel : ViewModelBase
  {
    public DealFileChecklistIssueViewModel()
    {
    }

    public DealFileChecklistIssueViewModel(DealFileChecklist DealChecklist)
    {
      this.IssueName = DealChecklist.DealFileChecklistIssueDetail.IssueName;
      this.IPREOIssuerName = DealChecklist.DealFileChecklistIssueDetail.IPREOIssuerName;
      this.UnderwriterSubmittingBid = DealChecklist.DealFileChecklistIssueDetail.UnderwriterSubmittingBid;
      this.SupportingDeskPersonnel = DealChecklist.DealFileChecklistIssueDetail.SupportingDeskPersonnel;
      this.PricingDate = DealChecklist.DealFileChecklistIssueDetail.PricingDate;
      this.ActualAwardDateTime = DealChecklist.DealFileChecklistIssueDetail.ActualAwardDateTime;
      this.FirstExecutionDateTime = DealChecklist.DealFileChecklistIssueDetail.FirstExecutionDateTime;
      this.DeliveryDate = DealChecklist.DealFileChecklistIssueDetail.DeliveryDate;
      this.CoBiddingBrokerDealers = DealChecklist.DealFileChecklistIssueDetail.CoBiddingBrokerDealers;
    }

    public string IssueName { get; set; }

    public string IPREOIssuerName { get; set; }

    public string UnderwriterSubmittingBid { get; set; }

    public string SupportingDeskPersonnel { get; set; }

    [AbsoluteDate]
    public DateTime? PricingDate { get; set; }

    [AbsoluteDate]
    public DateTime? ActualAwardDateTime { get; set; }

    [AbsoluteDate]
    public DateTime? FirstExecutionDateTime { get; set; }

    [AbsoluteDate]
    public DateTime? DeliveryDate { get; set; }

    public string CoBiddingBrokerDealers { get; set; }
  }
}
