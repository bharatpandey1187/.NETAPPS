﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ManageContactViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ManageContactViewModel : ViewModelBase
  {
    public ManageContactViewModel()
    {
    }

    public ManageContactViewModel(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public ManageContactViewModel(ManageContact manageContact)
    {
      this.ContactID = manageContact.ContactID;
      this.RefId = manageContact.RefId;
      this.RefName = manageContact.RefName;
      this.Type = manageContact.Type;
      this.Initials = manageContact.Initials;
      this.FirstName = manageContact.FirstName;
      this.MiddleName = manageContact.MiddleName;
      this.LastName = manageContact.LastName;
      this.Suffix = manageContact.Suffix;
      this.DisplayName = manageContact.DisplayName;
      this.Address = manageContact.Address;
      this.City = manageContact.City;
      this.State = manageContact.State;
      this.StateName = manageContact.StateName;
      this.Zip = manageContact.Zip;
      this.Title = manageContact.Title;
      this.Department = manageContact.Department;
      this.Phone = manageContact.Phone;
      this.Mobile = manageContact.Mobile;
      this.Email = manageContact.Email;
      this.IsActive = manageContact.IsActive;
      this.CreatedBy = manageContact.CreatedBy;
      this.CreatedOn = manageContact.CreatedOn;
      this.ModifiedBy = manageContact.ModifiedBy;
      this.ModifiedOn = manageContact.ModifiedOn;
      this.CityStateZip = string.Format("{0}{1}{2}", !(manageContact.City != "") || manageContact.City == null ? (object) "" : (object) (manageContact.City + ","), manageContact.StateName != null ? (object) (manageContact.StateName + ",") : (object) "", (object) manageContact.Zip);
    }

    public ManageContact GetManageContactDetail(
      ManageContactViewModel manageContactViewModel)
    {
      return new ManageContact()
      {
        ContactID = manageContactViewModel.ContactID,
        RefId = manageContactViewModel.RefId,
        RefName = manageContactViewModel.RefName,
        Type = manageContactViewModel.Type,
        Initials = manageContactViewModel.Initials,
        FirstName = manageContactViewModel.FirstName,
        MiddleName = manageContactViewModel.MiddleName,
        LastName = manageContactViewModel.LastName,
        Suffix = manageContactViewModel.Suffix,
        DisplayName = manageContactViewModel.DisplayName,
        Address = manageContactViewModel.Address,
        City = manageContactViewModel.City,
        State = manageContactViewModel.State,
        StateName = manageContactViewModel.StateName,
        Zip = manageContactViewModel.Zip,
        Title = manageContactViewModel.Title,
        Department = manageContactViewModel.Department,
        Phone = manageContactViewModel.Phone,
        Mobile = manageContactViewModel.Mobile,
        Email = manageContactViewModel.Email,
        IsActive = manageContactViewModel.IsActive,
        CreatedBy = manageContactViewModel.CreatedBy,
        CreatedOn = manageContactViewModel.CreatedOn,
        ModifiedBy = manageContactViewModel.ModifiedBy,
        ModifiedOn = manageContactViewModel.ModifiedOn
      };
    }

    public long ContactID { get; set; }

    public long? RefId { get; set; }

    public string RefName { get; set; }

    public string Type { get; set; }

    [StringLength(10, ErrorMessage = "Length of Initials field should be less than or equal to 10 characters.")]
    public string Initials { get; set; }

    [Required(ErrorMessage = "First Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string FirstName { get; set; }

    [StringLength(50, ErrorMessage = "Length of Middle Name field should be less than or equal to 50 characters.")]
    public string MiddleName { get; set; }

    [Required(ErrorMessage = "Last Name cannot be blank.")]
    [StringLength(50, ErrorMessage = "Length of First Name field should be less than or equal to 50 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string LastName { get; set; }

    [StringLength(12, ErrorMessage = "Length of Suffix field should be less than or equal to 12 characters.")]
    public string Suffix { get; set; }

    [Required(ErrorMessage = "Display Name cannot be blank.")]
    [StringLength(200, ErrorMessage = "Length of Display name field should be less than or equal to 200 characters.")]
    [RegexValidator("^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)", MessageTemplate = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.")]
    public string DisplayName { get; set; }

    [StringLength(500, ErrorMessage = "Length of  address field for a Manage Contact should be less than or equal to 500 characters.")]
    public string Address { get; set; }

    [RegexValidator("^$|(^[A-Za-z'-. ]+$)", MessageTemplate = "Only alphabets, comma, dash, period, apostrophe and space are allowed.")]
    [StringLength(100, ErrorMessage = "Length of City field for a  Manage Contact should be less than or equal to 100 characters.")]
    public string City { get; set; }

    [StringLength(20, ErrorMessage = "Length of State field should be less than or equal to 20 characters.")]
    public string State { get; set; }

    public string StateName { get; set; }

    [StringLength(20, ErrorMessage = "Length of Zip field for a Manage Contact should be less than or equal to 20 characters.")]
    public string Zip { get; set; }

    [StringLength(50, ErrorMessage = "Length of Title field for a Manage Contact should be less than or equal to 50 characters.")]
    public string Title { get; set; }

    [StringLength(100, ErrorMessage = "Length of Department field for a Manage Contact should be less than or equal to 100 characters.")]
    public string Department { get; set; }

    [StringLength(20, ErrorMessage = "Length of Phone field for a Manage Contact should be less than or equal to 12 characters.")]
    public string Phone { get; set; }

    [StringLength(20, ErrorMessage = "Length of Mobile field for a Manage Contact should be less than or equal to 12 characters.")]
    public string Mobile { get; set; }

    [Required(ErrorMessage = "Email cannot be blank.")]
    [RegexValidator("^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", MessageTemplate = "Email address is not valid.")]
    [StringLength(100, ErrorMessage = "Length of Email field for a Client should be less than or equal to 100 characters.")]
    public string Email { get; set; }

    public string CityStateZip { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; }

    public DateTime CreatedOn { get; set; }

    public string ModifiedBy { get; set; }

    public DateTime ModifiedOn { get; set; }

    public bool IsViewOnly { get; set; }

    public bool IsAddManageContact { get; set; }

    public bool IsEditManageContact { get; set; }

    public IEnumerable<PropertyDescriptor> MiscFieldsDetail { get; set; }

    public IEnumerable<PropertySetValue> MiscFieldsValueDetail { get; set; }
  }
}
