﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueRatingViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueRatingViewModel : ViewModelBase
  {
    public IssueRatingViewModel()
    {
      this.MoodyRatingLT = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.MoodyRatingLTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.MoodyRatingST = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.MoodyRatingSTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.SPRatingLT = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.SPRatingLTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.SPRatingST = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.SPRatingSTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.KrollRatingLT = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.KrollRatingLTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.KrollRatingST = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.KrollRatingSTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FitchRatingLT = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FitchRatingLTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FitchRatingST = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.FitchRatingSTOutlook = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.Series = new List<LookupItemMappings>();
      this.CreditEnhancementType = (IEnumerable<LookupItemMappings>) new List<LookupItemMappings>();
      this.UnderlyingRating = new List<UnderlyingRatingsViewModel>();
      this.EnhancedRating = new List<EnhancedRatingsViewModel>();
      this.SeriesData = new List<IrisSoftware.iMPACT.Data.SeriesData>();
    }

    public IssueRatingViewModel(List<LookupItemMappings> lookupItems)
    {
      this.MoodyRatingLT = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Moody's Long Term Rating"));
      this.MoodyRatingLTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Moody's Rating Outlook"));
      this.MoodyRatingST = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Moody's Short Term Rating"));
      this.MoodyRatingSTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Moody's Rating Outlook"));
      this.SPRatingLT = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "S&P Long Term Rating"));
      this.SPRatingLTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "S&P Rating Outlook"));
      this.SPRatingST = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "S&P Short Term Rating"));
      this.SPRatingSTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "S&P Rating Outlook"));
      this.KrollRatingLT = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Kroll Long Term Rating"));
      LookupItemMappings lookupItemMappings = this.KrollRatingLT.ToList<LookupItemMappings>().FirstOrDefault<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Value == "NR"));
      this.DefaultKrollRatingLT = lookupItemMappings != null ? lookupItemMappings.Value : string.Empty;
      this.KrollRatingLTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Kroll Rating Outlook"));
      this.KrollRatingST = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Kroll Short Term Rating"));
      this.KrollRatingSTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Kroll Rating Outlook"));
      this.FitchRatingLT = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Fitch Long Term Rating"));
      this.FitchRatingLTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Fitch Rating Outlook"));
      this.FitchRatingST = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Fitch Short Term Rating"));
      this.FitchRatingSTOutlook = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Fitch Rating Outlook"));
      this.CreditEnhancementType = (IEnumerable<LookupItemMappings>) lookupItems.FindAll((Predicate<LookupItemMappings>) (x => x.Key == "Credit Enhancement Type"));
      this.Series = new List<LookupItemMappings>();
      this.UnderlyingRating = new List<UnderlyingRatingsViewModel>();
      this.EnhancedRating = new List<EnhancedRatingsViewModel>();
      this.SeriesData = new List<IrisSoftware.iMPACT.Data.SeriesData>();
    }

    public IEnumerable<LookupItemMappings> MoodyRatingLT { get; set; }

    public IEnumerable<LookupItemMappings> MoodyRatingLTOutlook { get; set; }

    public IEnumerable<LookupItemMappings> MoodyRatingST { get; set; }

    public IEnumerable<LookupItemMappings> MoodyRatingSTOutlook { get; set; }

    public IEnumerable<LookupItemMappings> SPRatingLT { get; set; }

    public IEnumerable<LookupItemMappings> SPRatingLTOutlook { get; set; }

    public IEnumerable<LookupItemMappings> SPRatingST { get; set; }

    public IEnumerable<LookupItemMappings> SPRatingSTOutlook { get; set; }

    public IEnumerable<LookupItemMappings> KrollRatingLT { get; set; }

    public IEnumerable<LookupItemMappings> KrollRatingLTOutlook { get; set; }

    public IEnumerable<LookupItemMappings> KrollRatingST { get; set; }

    public IEnumerable<LookupItemMappings> KrollRatingSTOutlook { get; set; }

    public IEnumerable<LookupItemMappings> FitchRatingLT { get; set; }

    public IEnumerable<LookupItemMappings> FitchRatingLTOutlook { get; set; }

    public IEnumerable<LookupItemMappings> FitchRatingST { get; set; }

    public IEnumerable<LookupItemMappings> FitchRatingSTOutlook { get; set; }

    public List<LookupItemMappings> Series { get; set; }

    public IEnumerable<LookupItemMappings> CreditEnhancementType { get; set; }

    public List<UnderlyingRatingsViewModel> UnderlyingRating { get; set; }

    public List<EnhancedRatingsViewModel> EnhancedRating { get; set; }

    public List<IrisSoftware.iMPACT.Data.SeriesData> SeriesData { get; set; }

    public string DefaultKrollRatingLT { get; set; }

    public bool isRatingViewOnly { get; set; }
  }
}
