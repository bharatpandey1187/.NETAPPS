﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.EntityPartnerContactViewModelContainer
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class EntityPartnerContactViewModelContainer : ViewModelBase
  {
    public EntityPartnerContactViewModelContainer()
    {
    }

    public EntityPartnerContactViewModelContainer(string strErrorMsg) => this.ErrorMessage = strErrorMsg;

    public List<EntityPartnerContactViewModel> IssuePartnerContacts { get; set; }

    public List<IrisSoftware.iMPACT.Data.PartnerActiveAddress> PartnerActiveAddress { get; set; }

    public Partner IssuePartner { get; set; }

    public bool IsAddContact { get; set; }

    public bool IsEditContact { get; set; }

    public List<KeyPair> IssuerContactTitle { get; set; }
  }
}
