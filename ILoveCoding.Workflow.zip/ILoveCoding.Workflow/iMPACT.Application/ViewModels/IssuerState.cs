﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssuerState
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssuerState
  {
    public IssuerState()
    {
    }

    public IssuerState(long key, string value, string stateId)
    {
      this.Key = key.ToString();
      this.Value = value;
      this.StateID = stateId;
    }

    public IssuerState(string key, string value, string stateId)
    {
      this.Key = key;
      this.Value = value;
      this.StateID = stateId;
    }

    public string Key { get; set; }

    public string Value { get; set; }

    public string StateID { get; set; }
  }
}
