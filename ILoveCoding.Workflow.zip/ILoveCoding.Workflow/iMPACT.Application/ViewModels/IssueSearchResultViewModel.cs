﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueSearchResultViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueSearchResultViewModel
  {
    public long AppTransactionID { get; set; }

    public string IssueNumber { get; set; }

    public string CreatedBy { get; set; }

    public string IssueName { get; set; }

    public string IssueStatus { get; set; }

    public string ReviewStatus { get; set; }

    public string Issuer { get; set; }

    public string Borrower { get; set; }

    public string Guarantor { get; set; }

    public string TypeOfOffering { get; set; }

    public string State { get; set; }

    public DateTime? DateHired { get; set; }

    public string G17RoleLetter { get; set; }

    public DateTime? G17RoleLetterSentDate { get; set; }

    public DateTime? G17RoleLetterAckDate { get; set; }

    public string G17ConflictLetter { get; set; }

    public DateTime? G17ConflictLetterSentDate { get; set; }

    public DateTime? G17ConflictLetterAckDate { get; set; }

    public string G17RoleDisclosureLetter { get; set; }

    public DateTime? G17RoleDisclosureLetterSentDate { get; set; }

    public DateTime? G17RoleDisclosureLetterAckDate { get; set; }

    public string RFPMAExemption { get; set; }

    public DateTime? RFPMAExemptionStartDate { get; set; }

    public DateTime? RFPMAExemptionExpirationDate { get; set; }

    public string RFPMAName { get; set; }

    public string RFPMAScope { get; set; }

    public string RFPIRMAIndependent { get; set; }

    public string IRMAMAExemption { get; set; }

    public DateTime? IRMAMAExemptionStartDate { get; set; }

    public DateTime? IRMAMAExemptionExpirationDate { get; set; }

    public string UWMAExemption { get; set; }

    public DateTime? UWMAExemptionStartDate { get; set; }

    public DateTime? UWMAExemptionExpirationDate { get; set; }

    public string NoneMAExemption { get; set; }

    public DateTime? NoneMAExemptionStartDate { get; set; }

    public DateTime? NoneMAExemptionExpirationDate { get; set; }

    public string FirmRole { get; set; }

    public Decimal? LiabilityPercentage { get; set; }

    public Decimal? FirmManagementFeePercentage { get; set; }

    public string FirmOtherRoles { get; set; }

    public string LeadBanker { get; set; }

    public string Banker { get; set; }

    public string Quant { get; set; }

    public string SupervisoryPrincipal { get; set; }

    public string Underwriter { get; set; }

    public string SoleManager { get; set; }

    public string SeniorManager { get; set; }

    public string JointSeniorMgrBookRunning { get; set; }

    public string JointSeniorMgrNonBookRunning { get; set; }

    public string CoSeniorMgr { get; set; }

    public string CoManager { get; set; }

    public string SellingGroupMember { get; set; }

    public string PlacementAgent { get; set; }

    public string OtherSyndicateMembers { get; set; }

    public string FinancialAdvisor { get; set; }

    public string FedTaxName { get; set; }

    public string EscrowVerificationAgent { get; set; }

    public string EscrowSecuritiesProvider { get; set; }

    public string EscrowAgentForRefundedBonds { get; set; }

    public string PayingAgent { get; set; }

    public string RemarketingAgent { get; set; }

    public string OtherAdvisorAgents { get; set; }

    public string BondCounsel { get; set; }

    public string UnderwriterCounsel { get; set; }

    public string DisclosureCounsel { get; set; }

    public string OtherCounsels { get; set; }

    public string OtherPartners { get; set; }

    public Decimal? ParAmount { get; set; }

    public string AdvanceRefunding { get; set; }

    public string UseOfProceeds { get; set; }

    public string GeneralCategory { get; set; }

    public Decimal? GoodFaithAmount { get; set; }

    public DateTime? GoodFaithDate { get; set; }

    public DateTime? CommitmentCommitteeApprovalDate { get; set; }

    public DateTime? PricingDate { get; set; }

    public DateTime? ExpectedAwardDate { get; set; }

    public DateTime? ActualAwardDate { get; set; }

    public string ActualAwardDateTimeZone { get; set; }

    public DateTime? SettlementDate { get; set; }

    public DateTime? ARDSubmissionDate { get; set; }

    public DateTime? G37SettlementDate { get; set; }

    public DateTime? FinalOSReceivedDate { get; set; }

    public string FinalOSReceivedDateTimeZone { get; set; }

    public DateTime? DateApprovedByMUCC { get; set; }

    public DateTime? G32SubmissionDate { get; set; }

    public string G32SubmissionDateTimeZone { get; set; }

    public string SeriesName { get; set; }

    public string SeriesCode { get; set; }

    public Decimal? SeriesParAmount { get; set; }

    public string SecurityType { get; set; }

    public Decimal? Denomination { get; set; }

    public string MaturityPeriod { get; set; }

    public string Security { get; set; }

    public string SecurityDetails { get; set; }

    public DateTime? SeriesDatedDate { get; set; }

    public DateTime? FirstCouponDate { get; set; }

    public DateTime? SeriesSettlementDate { get; set; }

    public string SeriesFedTaxable { get; set; }

    public string SeriesStateTaxable { get; set; }

    public string SeriesBankQualified { get; set; }

    public string AccrueFrom { get; set; }

    public string Form { get; set; }

    public string CouponFreq { get; set; }

    public string DayCount { get; set; }

    public string RateType { get; set; }

    public string SeriesCallFeature { get; set; }

    public DateTime? SeriesCallDate { get; set; }

    public Decimal? CallPrice { get; set; }

    public string Insurance { get; set; }

    public string FirmInventory { get; set; }

    public DateTime? FirstMaturity { get; set; }

    public DateTime? FinalMaturity { get; set; }

    public string UnderlyingRating { get; set; }

    public string EnhancedRating { get; set; }

    public string CreditEnhancementProvider { get; set; }

    public string CEType { get; set; }

    public DateTime? CEExpirationDate { get; set; }

    public Decimal? Takedown { get; set; }

    public Decimal? EstimatedRevenue { get; set; }

    public Decimal? GrossSpread { get; set; }

    public Decimal? InsuranceFee { get; set; }

    public string JobNumber { get; set; }

    public string PriorityOfOrders { get; set; }

    public DateTime? OSDeemedFinalDate { get; set; }

    public DateTime? SeriesActualAwardDate { get; set; }

    public string SeriesActualAwardDateTimeZone { get; set; }

    public string RAAttributionReviewed { get; set; }

    public bool? AttributionReviewed { get; set; }
  }
}
