﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.ClientCRMViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class ClientCRMViewModel : ViewModelBase
  {
    public ClientCRMViewModel()
    {
    }

    public long ClientCrmID { get; set; }

    public long ClientID { get; set; }

    public string MeetingID { get; set; }

    [AbsoluteDate]
    public DateTime? MeetingDate { get; set; }

    public long? MeetingType { get; set; }

    public string MeetingTypeName { get; set; }

    public string MeetingNotes { get; set; }

    public ClientCRMViewModel(ClientCRM clientCRM)
    {
      this.ClientCrmID = clientCRM.ClientCrmID;
      this.ClientID = clientCRM.ClientID;
      this.MeetingID = clientCRM.MeetingID;
      this.MeetingDate = clientCRM.MeetingDate;
      this.MeetingType = clientCRM.MeetingType;
      this.MeetingTypeName = clientCRM.MeetingTypeName;
      this.MeetingNotes = clientCRM.MeetingNotes;
      this.IsDeleted = clientCRM.IsDeleted;
      this.IsDirty = clientCRM.IsDirty;
    }

    public ClientCRM GetClientCRM() => new ClientCRM()
    {
      ClientCrmID = this.ClientCrmID,
      ClientID = this.ClientID,
      MeetingID = this.MeetingID,
      MeetingDate = this.MeetingDate,
      MeetingType = this.MeetingType,
      MeetingTypeName = this.MeetingTypeName,
      MeetingNotes = this.MeetingNotes,
      IsDeleted = this.IsDeleted,
      IsDirty = this.IsDirty
    };
  }
}
