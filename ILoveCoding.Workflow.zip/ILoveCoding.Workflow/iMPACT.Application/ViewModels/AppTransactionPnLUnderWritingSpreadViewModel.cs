﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.AppTransactionPnLUnderWritingSpreadViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class AppTransactionPnLUnderWritingSpreadViewModel
  {
    public long AppTransactionId { get; set; }

    public Decimal? ProjectedTakedownTotal { get; set; }

    public Decimal? ProjectedTakedownPerThousand { get; set; }

    public Decimal? ActualTakedownTotal { get; set; }

    public Decimal? ActualTakedownPerThousand { get; set; }

    public Decimal? TakedownDifference { get; set; }

    public Decimal? ProjectedExpenseTotal { get; set; }

    public Decimal? ProjectedExpensePerThousand { get; set; }

    public Decimal? ActualExpenseTotal { get; set; }

    public Decimal? ActualExpensePerThousand { get; set; }

    public Decimal? ExpenseDifference { get; set; }

    public Decimal? ProjectedStructuringTotal { get; set; }

    public Decimal? ProjectedStructuringPerThousand { get; set; }

    public Decimal? ActualStructuringTotal { get; set; }

    public Decimal? ActualStructuringPerThousand { get; set; }

    public Decimal? StructuringDifference { get; set; }

    public Decimal? ProjectedTotalGrossSpread { get; set; }

    public Decimal? ProjectedPerThousandGrossSpread { get; set; }

    public Decimal? ActualTotalGrossSpread { get; set; }

    public Decimal? ActualPerThousandGrossSpread { get; set; }

    public Decimal? DifferenceGrossSpread { get; set; }
  }
}
