﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.IssueRegulatoryCheckListViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class IssueRegulatoryCheckListViewModel
  {
    public string IssuerName { get; set; }

    public string BorrowerName { get; set; }

    public string JobNumber { get; set; }

    public string IssueName { get; set; }

    public string FirmRoleName { get; set; }

    public long? FirmRole { get; set; }

    public string PricingDate { get; set; }

    public string ActualAwardDateTime { get; set; }

    public string SettlementDate { get; set; }

    public string LeadMSBanker { get; set; }

    public string SupportMSBanker { get; set; }

    public long AppTransactionID { get; set; }

    [AbsoluteDate]
    public DateTime? RoleSentDate { get; set; }

    [AbsoluteDate]
    public DateTime? RoleAckDate { get; set; }

    [AbsoluteDate]
    public DateTime? ConflictSentDate { get; set; }

    [AbsoluteDate]
    public DateTime? ConflictAckDate { get; set; }

    [AbsoluteDate]
    public DateTime? RoleDisclosureSentDate { get; set; }

    [AbsoluteDate]
    public DateTime? RoleDisclosureAckdate { get; set; }

    [AbsoluteDate]
    public DateTime? StructureLetterSentDate { get; set; }

    [AbsoluteDate]
    public DateTime? StructureLetterAckdate { get; set; }

    public string FinancialAdvisor { get; set; }

    public bool IsViewOnly { get; set; }

    public bool CanSaveRegulatoryChecklist { get; set; }

    public bool CannotGenerateRegulatoryChecklist { get; set; }

    public string LeadBanker { get; set; }

    public DateTime? LeadBankerApprovalDate { get; set; }

    public string LeadBankerApprovalDateValue
    {
      get
      {
        if (this.LeadBankerApprovalDate.HasValue)
        {
          DateTime? bankerApprovalDate = this.LeadBankerApprovalDate;
          DateTime minValue = DateTime.MinValue;
          if ((bankerApprovalDate.HasValue ? (bankerApprovalDate.GetValueOrDefault() > minValue ? 1 : 0) : 0) != 0)
          {
            bankerApprovalDate = this.LeadBankerApprovalDate;
            return bankerApprovalDate.Value.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/');
          }
        }
        return string.Empty;
      }
    }

    public string SupervisoryPrincipal { get; set; }

    public DateTime? SPApprovalDate { get; set; }

    public string SPApprovalDateValue
    {
      get
      {
        if (this.SPApprovalDate.HasValue)
        {
          DateTime? spApprovalDate = this.SPApprovalDate;
          DateTime minValue = DateTime.MinValue;
          if ((spApprovalDate.HasValue ? (spApprovalDate.GetValueOrDefault() > minValue ? 1 : 0) : 0) != 0)
          {
            spApprovalDate = this.SPApprovalDate;
            return spApprovalDate.Value.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/');
          }
        }
        return string.Empty;
      }
    }

    public string CommaSeperatedStateID { get; set; }

    public List<long> IssueStatus { get; set; }

    public string DealTypeName { get; set; }

    public long? DealType { get; set; }

    public string RoleTypeName { get; set; }

    public long? RoleType { get; set; }
  }
}
