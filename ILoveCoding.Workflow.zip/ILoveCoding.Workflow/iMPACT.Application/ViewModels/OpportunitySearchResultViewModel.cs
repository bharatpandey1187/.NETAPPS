﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.OpportunitySearchResultViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class OpportunitySearchResultViewModel
  {
    public long AppTransactionID { get; set; }

    public string OpportunityNbr { get; set; }

    public string OpportunityName { get; set; }

    public string OpportunityStatus { get; set; }

    public string ReviewStatus { get; set; }

    public string PowerID { get; set; }

    public string State { get; set; }

    public string County { get; set; }

    public string Issuer { get; set; }

    public string Borrower { get; set; }

    public string Guarantor { get; set; }

    public string OpportunityType { get; set; }

    public Decimal? ParAmount { get; set; }

    public string Purpose { get; set; }

    public string Market { get; set; }

    public string TransactionType { get; set; }

    public string SecurityType { get; set; }

    public string MaterialType { get; set; }

    public string BankQualified { get; set; }

    public string FedTaxName { get; set; }

    public string StateTaxable { get; set; }

    public string FAEngaged { get; set; }

    public string CMRelationship { get; set; }

    public string BankRelationship { get; set; }

    public string InsuranceProvider { get; set; }

    public string ApprovedDerivativeMarketer { get; set; }

    public string IsNewOpportunity { get; set; }

    public string HybridSolutionIndicator { get; set; }

    public string DualProposalProposed { get; set; }

    public string InformationalMERGRequired { get; set; }

    public string ExpectedFirmRole { get; set; }

    public string AssignedFirmRole { get; set; }

    public Decimal? ExpectedFirmLiabilityPerc { get; set; }

    public Decimal? AssignedFirmLiabilityPerc { get; set; }

    public string LeadBanker { get; set; }

    public string Banker { get; set; }

    public string Quant { get; set; }

    public string LeadAnalyst { get; set; }

    public string Analyst { get; set; }

    public string SupervisoryPrincipal { get; set; }

    public string BankRM { get; set; }

    public string FinancialAdvisor { get; set; }

    public string EscrowVerificationAgent { get; set; }

    public string EscrowSecuritiesProvider { get; set; }

    public string EscrowAgentForRefundedBonds { get; set; }

    public string PayingAgent { get; set; }

    public string RemarketingAgent { get; set; }

    public string Trustee { get; set; }

    public string OtherAdvisorAgents { get; set; }

    public string BondCounsel { get; set; }

    public string UnderwriterCounsel { get; set; }

    public string DisclosureCounsel { get; set; }

    public string OtherCounsels { get; set; }

    public string RFPMAExemption { get; set; }

    public DateTime? RFPMAExemptionDate { get; set; }

    public string RFPMAExemptionDateValue { get; set; }

    public DateTime? RFPMAExemptionExpirationDate { get; set; }

    public string RFPMAExemptionExpirationDateValue { get; set; }

    public string UWMAExemption { get; set; }

    public DateTime? UWMAExemptionDate { get; set; }

    public string UWMAExemptionDateValue { get; set; }

    public DateTime? UWMAExemptionExpirationDate { get; set; }

    public string UWMAExemptionExpirationDateValue { get; set; }

    public string IRMAMAExemption { get; set; }

    public DateTime? IRMAMAExemptionDate { get; set; }

    public string IRMAMAExemptionDateValue { get; set; }

    public DateTime? IRMAMAExemptionExpirationDate { get; set; }

    public string IRMAMAExemptionExpirationDateValue { get; set; }

    public string NoneMAExemption { get; set; }

    public DateTime? NoneMAExemptionStartDate { get; set; }

    public string NoneMAExemptionExpirationDate { get; set; }

    public string MoodyRating { get; set; }

    public string SPRating { get; set; }

    public string KrollRating { get; set; }

    public string FitchRating { get; set; }

    public DateTime? CreateDate { get; set; }

    public string CreateDateValue { get; set; }

    public DateTime? ResponseDueDateTime { get; set; }

    public string ResponseDueDateTimeZone { get; set; }

    public string ResponseDueDateTimeValue { get; set; }

    public DateTime? SubmissionDateTime { get; set; }

    public string SubmissionDateTimeZone { get; set; }

    public string SubmissionDateTimeValue { get; set; }

    public string SentTo3Firms { get; set; }

    public DateTime? SaleDate { get; set; }

    public string SaleDateValue { get; set; }

    public DateTime? CloseDate { get; set; }

    public string CloseDateValue { get; set; }

    public DateTime? FinancingDate { get; set; }

    public string FinancingDateValue { get; set; }

    public DateTime? SupervisoryPrincipalApprovalDate { get; set; }

    public string SupervisoryPrincipalApprovalDateValue { get; set; }

    public DateTime? SupervisoryPrincipalReviewDate { get; set; }

    public string SupervisoryPrincipalReviewDateValue { get; set; }

    public DateTime? ClientLastContactedDate { get; set; }

    public string ClientLastContactedDateValue { get; set; }

    public DateTime? DateHired { get; set; }

    public string DateHiredValue { get; set; }

    public DateTime? G17SentDate { get; set; }

    public string G17SentDateValue { get; set; }

    public DateTime? G17AckDate { get; set; }

    public string G17AckDateValue { get; set; }

    public Decimal? GrossSpread { get; set; }

    public Decimal? EstGrossRev { get; set; }

    public Decimal? TakeDownValue { get; set; }

    public string RateType { get; set; }

    public string RFPType { get; set; }

    public string JobNumber { get; set; }

    public Decimal? RFPFees { get; set; }

    public string CreatedBy { get; set; }

    public DateTime? ExpectedPricingDate { get; set; }

    public string ExpectedPricingDateValue { get; set; }
  }
}
