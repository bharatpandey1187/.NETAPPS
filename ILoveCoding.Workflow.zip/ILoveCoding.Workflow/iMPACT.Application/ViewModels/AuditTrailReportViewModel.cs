﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.ViewModels.AuditTrailReportViewModel
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.ViewModels
{
  public class AuditTrailReportViewModel
  {
    public long AppTransactionID { get; set; }

    public long AuditTrailID { get; set; }

    public string DealNumber { get; set; }

    public string IssueName { get; set; }

    public DateTime When { get; set; }

    public string What { get; set; }

    public string Who { get; set; }

    public string WhoEx { get; set; }

    public string Entity { get; set; }

    public string WhenString
    {
      get => this.When != DateTime.MinValue ? this.When.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/') : string.Empty;
      set => this.WhenString = value;
    }
  }
}
