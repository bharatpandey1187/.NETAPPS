﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.OpportunityPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.Core.Logging;
using IrisSoftware.Core.Reflection;
using IrisSoftware.Core.SearchCriteria;
using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using IrisSoftware.Reporting.ReportDefinition;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Transactions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (OpportunityPresenter))]
  public class OpportunityPresenter : PresenterBase
  {
    private const string OpportunitySaved = "Opportunity Created";
    private const string OpportunityUpdated = "Opportunity Updated";
    private const string OpportunityStatusChanged = "Status Changed From {0} to {1}";
    private static readonly HashSet<string> dateColumnsToAdjust = new HashSet<string>((IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)
    {
      "RFPMAExemptionDate",
      "RFPMAExemptionExpirationDate",
      "UWMAExemptionDate",
      "UWMAExemptionExpirationDate",
      "IRMAMAExemptionDate",
      "IRMAMAExemptionExpirationDate",
      "NoneMAExemptionStartDate",
      "NoneMAExemptionExpirationDate",
      "ResponseDueDate",
      "SaleDate",
      "CloseDate",
      "ClientLastContactedDate",
      "G17RoleLetterSentDate",
      "G17RoleLetterAckDate",
      "G17ConflictLetterSentDate",
      "G17ConflictLetterAckDate",
      "G17RoleDisclosureLetterSentDate",
      "G17RoleDisclosureLetterAckDate",
      "G17StructureLetterSentDate",
      "G17StructureLetterAckDate",
      "ExpectedPricingDate"
    };
    private string[] partnersEmailAddress = new string[4]
    {
      string.Empty,
      string.Empty,
      string.Empty,
      string.Empty
    };
    private StringBuilder InfoReceipts = new StringBuilder();
    private DateTime SharePointMinDate = new DateTime(1900, 1, 1);

    [Dependency]
    public IEventBus EventBus { get; set; }

    [Dependency]
    public IOpportunityWorkflowFactory WorkflowFactory { get; set; }

    [Dependency]
    public IOpportunityRepository OpportunityRepository { get; set; }

    [Dependency]
    public IAuditTrailRepository AuditTrailRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IUser UserRepository { get; set; }

    [Dependency]
    public IEntityStateRepository EntityStateRepository { get; set; }

    [Dependency]
    public IEmailTemplateRepository EmailTemplateRepository { get; set; }

    [Dependency]
    public RFPPresenter RFPPresenter { get; set; }

    [Dependency]
    public IssuePresenter IssuePresenter { get; set; }

    [Dependency]
    public IIssueRatingRepository IssueRatingRepository { get; set; }

    [Dependency]
    public IPropertyDescriptorRepository PropertyDescriptorRepository { get; set; }

    [Dependency]
    public AuditTrailReportPresenter AuditTrailReportPresenter { get; set; }

    [Dependency]
    public IPropertySetValueRepository PropertySetValueRepository { get; set; }

    public OpportunityViewModel Initialize(long appTransactionId)
    {
      try
      {
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (appTransactionId > 0L)
        {
          if (!this.HasUIPermissionForEntity(-33L, appTransactionId, "Opportunity Details", "View"))
          {
            OpportunityViewModel opportunityViewModel = new OpportunityViewModel();
            opportunityViewModel.ErrorMessage = "401";
            return opportunityViewModel;
          }
        }
        else if (!this.HasEntityPermission(-33L, "Opportunity Details", "Create"))
        {
          OpportunityViewModel opportunityViewModel = new OpportunityViewModel();
          opportunityViewModel.ErrorMessage = "401";
          return opportunityViewModel;
        }
        IrisSoftware.iMPACT.Data.Opportunity opportunity = this.OpportunityRepository.FetchByID(appTransactionId);
        object obj = this.AuditTrailReportPresenter.FetchLastValueForFieldByEntityIdAppTransactionId(appTransactionId, -33L, "RFPFees");
        if (appTransactionId > 0L && obj != null)
          opportunity.OpportunityDetail.OldRFPFees = new Decimal?(Convert.ToDecimal(obj));
        if (!string.IsNullOrEmpty(opportunity.OpportunityDetail.CommaSeperatedStateID))
          opportunity.OpportunityDetail.OpportunityStatus = ((IEnumerable<string>) opportunity.OpportunityDetail.CommaSeperatedStateID.Split(new string[1]
          {
            ","
          }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        else
          opportunity.OpportunityDetail.OpportunityStatus = new List<long>();
        return this.GetViewModel(opportunity, appTransactionId);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        OpportunityViewModel opportunityViewModel = new OpportunityViewModel();
        opportunityViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return opportunityViewModel;
      }
    }

    private OpportunityViewModel GetViewModel(
      IrisSoftware.iMPACT.Data.Opportunity opportunity,
      long appTransactionId,
      bool IsCopyOpportunity = false)
    {
      opportunity.MiscFieldsDetail = this.PropertyDescriptorRepository.FetchPropertyDescriptorsDataByEntity(appTransactionId, -33L);
      OpportunityViewModel opportunityViewModel = new OpportunityViewModel(opportunity);
      IWorkflow<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> workflow = this.WorkflowFactory.GetWorkflow(OpportunityPresenter.GetWorkflowType(opportunity));
      if (opportunity != null)
      {
        if (opportunity.OpportunityDetail.AppTransactionID > 0L)
        {
          this.OpportunityRepository.FetchHistoryByAppTransactionID(opportunity.OpportunityDetail.AppTransactionID);
          List<string> list = workflow.GetAllowedActions((IEnumerable<IrisSoftware.iMPACT.Data.Opportunity.Status>) this.GetOpptyStatusListFromStatusIDList(opportunity.OpportunityDetail.OpportunityStatus)).ToList<string>();
          IrisSoftware.iMPACT.Core.Security.Permission[] permissions = this.AuthorizationService.GetPermissions(this.AppUser, -33L, appTransactionId);
          IrisSoftware.iMPACT.Core.Security.Permission[] array = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) permissions).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "Opportunity Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
          opportunityViewModel.Actions = this.GetMatchingPermission(array, list.ToArray());
          IEnumerable<IrisSoftware.iMPACT.Data.EmailTemplate> source = ((IEnumerable<IrisSoftware.iMPACT.Data.EmailTemplate>) this.EmailTemplateRepository.FetchEntityTemplates(-33)).Join<IrisSoftware.iMPACT.Data.EmailTemplate, IrisSoftware.iMPACT.Core.Security.Permission, string, IrisSoftware.iMPACT.Data.EmailTemplate>((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) permissions, (Func<IrisSoftware.iMPACT.Data.EmailTemplate, string>) (emailtem => emailtem.UIName), (Func<IrisSoftware.iMPACT.Core.Security.Permission, string>) (permission => permission.UIName), (Func<IrisSoftware.iMPACT.Data.EmailTemplate, IrisSoftware.iMPACT.Core.Security.Permission, IrisSoftware.iMPACT.Data.EmailTemplate>) ((emailtem, permission) => emailtem));
          opportunityViewModel.EmailTemplates = source.Select<IrisSoftware.iMPACT.Data.EmailTemplate, EmailTemplateViewModel>((Func<IrisSoftware.iMPACT.Data.EmailTemplate, EmailTemplateViewModel>) (template => new EmailTemplateViewModel(template))).ToList<EmailTemplateViewModel>();
          opportunityViewModel.DisableOpportunityDetailEmail = true;
          if (!opportunityViewModel.EmailTemplates.Any<EmailTemplateViewModel>())
            opportunityViewModel.DisableOpportunityDetailEmail = false;
        }
        if (opportunity.InternalPartners != null && opportunity.InternalPartners.Count > 0)
        {
          opportunityViewModel.Analysts = opportunityViewModel.Analysts.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
          {
            x.IsPrimary = this.GetInternalPartnerIsPrimary(x.IsPrimary);
            return x;
          })).ToList<InternalPartner>();
          opportunityViewModel.SupervisoryPrincipals = opportunityViewModel.SupervisoryPrincipals.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
          {
            x.IsPrimary = this.GetInternalPartnerIsPrimary(x.IsPrimary);
            return x;
          })).ToList<InternalPartner>();
        }
        opportunityViewModel.BankRMs = opportunity.InternalPartnerBankRMs;
      }
      if (IsCopyOpportunity)
      {
        if (opportunity.InternalPartners != null && opportunity.InternalPartners.Count > 0)
        {
          opportunityViewModel.Bankers = opportunityViewModel.Bankers.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
          {
            x.IsDirty = true;
            return x;
          })).ToList<InternalPartner>();
          opportunityViewModel.Analysts = opportunityViewModel.Analysts.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
          {
            x.IsDirty = true;
            return x;
          })).ToList<InternalPartner>();
          opportunityViewModel.SupervisoryPrincipals = opportunityViewModel.SupervisoryPrincipals.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
          {
            x.IsDirty = true;
            return x;
          })).ToList<InternalPartner>();
        }
        if (opportunity.ExternalPartners != null && opportunity.ExternalPartners.Count > 0)
        {
          opportunityViewModel.Advisors = opportunityViewModel.Advisors.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (x =>
          {
            x.IsDirty = true;
            return x;
          })).ToList<ExternalPartner>();
          opportunityViewModel.Counsels = opportunityViewModel.Counsels.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (x =>
          {
            x.IsDirty = true;
            return x;
          })).ToList<ExternalPartner>();
          opportunityViewModel.SyndicateMembers = opportunityViewModel.SyndicateMembers.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (x =>
          {
            x.IsDirty = true;
            return x;
          })).ToList<ExternalPartner>();
          opportunityViewModel.WinningSyndicateMembers = opportunityViewModel.WinningSyndicateMembers.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (x =>
          {
            x.IsDirty = true;
            return x;
          })).ToList<ExternalPartner>();
        }
      }
      IEnumerable<LookupItemMappings> source1 = appTransactionId > 0L ? this.FetchLookupItemsByLookupKeys(opportunityViewModel) : this.FetchLookupItemsByLookupKeys();
      opportunityViewModel.OpportunityTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Type of Opportunity")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.MAExemptions = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MA Exemption")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.States = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "State")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.MaterialTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Material Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.ApprovedDerivativeMarketers = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Approved Derivative Marketer")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.Roles = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Firm Role")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.Purposes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Purpose")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.TransactionTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Transaction Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.UseOfProceeds = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Use of Proceeds")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.SecurityTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Security Type (General)")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.InsuranceProviders = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Insurance Provider")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).OrderBy<KeyPair, string>((Func<KeyPair, string>) (m => m.Value)).ToList<KeyPair>();
      opportunityViewModel.Markets = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MS Banking Group")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.RFPTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Oppty RFP Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.RateTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Interest Rate Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.AdvisorAgentType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Advisory Agent Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.SyndicateMemberType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Syndicate Member Role")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.WinningSyndicateMemberType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Winning Syndicate Member Role")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.CounselType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Counsel Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.DealTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Deal Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.G17Types = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "G-17 Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.GeneralCategories = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MS Banking Group")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.SeriesFedTax = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Fed Tax")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.GeneralCategorySpecifics = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "General Category (Specific)")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      opportunityViewModel.IsViewOnly = this.HasOpptyUIViewOnlyPermission(appTransactionId, "Opportunity Details", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewOpportunityInternalPartners = this.CanViewUI(appTransactionId, "Internal Partners", "View", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewOpportunityExternalPartners = this.CanViewUI(appTransactionId, "External Partners", "View", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewOpportunityDocuments = this.CanViewUI(appTransactionId, "Opportunity Documents", "View", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewOpportunityContacts = this.CanViewUI(appTransactionId, "Opportunity Contacts", "View", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewOpportunityReview = this.CanViewUI(appTransactionId, "Opportunity Review", "View", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewOpportunityAuditTrail = this.CanViewUI(appTransactionId, "Opportunity Audit Trail", "View", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewOpportunityMisc = this.CanViewUI(appTransactionId, "Misc", "View", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.CanInitiateIssue = this.CanInitiateIssue(appTransactionId);
      opportunityViewModel.CanUploadOpportunityDocuments = this.HasPermissionToUploadDoc(appTransactionId);
      opportunityViewModel.DisableInitiateIssue = !this.DisableInitiateIssue(opportunity, opportunityViewModel.CanInitiateIssue);
      opportunityViewModel.IsOpportunityInternalPartnersViewOnly = this.HasOpptyUIViewOnlyPermission(appTransactionId, "Internal Partners", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.IsOpportunityExternalPartnersViewOnly = this.HasOpptyUIViewOnlyPermission(appTransactionId, "External Partners", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.IsOpportunityDocumentsViewOnly = opportunityViewModel.ViewOpportunityDocuments && !opportunityViewModel.CanUploadOpportunityDocuments;
      opportunityViewModel.IsOpportunityReviewViewOnly = this.HasOpptyUIViewOnlyPermission(appTransactionId, "Opportunity Review", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.IsOpportunityMiscViewOnly = this.HasOpptyUIViewOnlyPermission(appTransactionId, "Misc", opportunity.OpportunityDetail.OpportunityStatus);
      opportunityViewModel.ViewCopyOpportunity = this.HasEntityPermission(-33L, "Opportunity Details", "Create");
      opportunityViewModel.IsAppTransactionClientContactEditable = this.HasAppTransactionClientContactEditable(opportunityViewModel);
      if (opportunityViewModel.SubmissionDateTimezone == null)
        opportunityViewModel.SubmissionDateTimezone = "ET";
      if (opportunityViewModel.ResponseDueDateTimezone == null)
        opportunityViewModel.ResponseDueDateTimezone = "ET";
      IEnumerable<KeyPair> first1 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Moody's Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      IEnumerable<KeyPair> second1 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Moody's Short Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      opportunityViewModel.MoodyRatings = first1.Concat<KeyPair>(second1).ToList<KeyPair>();
      IEnumerable<KeyPair> first2 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "S&P Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      IEnumerable<KeyPair> second2 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "S&P Short Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      opportunityViewModel.SnPRatings = first2.Concat<KeyPair>(second2).ToList<KeyPair>();
      IEnumerable<KeyPair> first3 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Fitch Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      IEnumerable<KeyPair> second3 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Fitch Short Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      opportunityViewModel.FitchRatings = first3.Concat<KeyPair>(second3).ToList<KeyPair>();
      IEnumerable<KeyPair> first4 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Kroll Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      IEnumerable<KeyPair> second4 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Kroll Short Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value)));
      opportunityViewModel.KrollRatings = first4.Concat<KeyPair>(second4).ToList<KeyPair>();
      if (opportunityViewModel.AppTransactionID == 0L)
      {
        KeyPair keyPair = opportunityViewModel.KrollRatings.FirstOrDefault<KeyPair>((Func<KeyPair, bool>) (x => x.Value == "NR"));
        long result;
        if (keyPair != null && long.TryParse(keyPair.Key, out result))
          opportunityViewModel.KrollRatingLT = new long?(result);
      }
      opportunityViewModel.AuditTrails = this.GetUpdateAuditTrails(appTransactionId);
      return opportunityViewModel;
    }

    private bool HasAppTransactionClientContactEditable(OpportunityViewModel opportunityModel) => this.HasIndependentPermission("Client Contact", "Edit") && this.HasIndependentPermission("Client Contact", "Add") && !opportunityModel.IsViewOnly;

    private bool HasPermissionToUploadDoc(long appTransactionId) => appTransactionId > 0L && this.HasUIPermissionForEntityStatusMultiple(appTransactionId, IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetOpportunity, "Upload");

    private bool CanInitiateIssue(long appTransID) => appTransID > 0L && ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, -33L, appTransID)).Any<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "Opportunity Action" && p.EntityPermission == "Edit" && p.Descr == OpportunityAction.InitiateIssue && !p.StateID.HasValue));

    private bool DisableInitiateIssue(IrisSoftware.iMPACT.Data.Opportunity opportunity, bool CanInitiateIssue) => CanInitiateIssue && opportunity.OpportunityDetail.OpportunityStatus != null && (opportunity.OpportunityDetail.OpportunityStatus.Count > 0 && opportunity.OpportunityDetail.OpportunityStatus.Contains(12L));

    private bool CanViewUI(
      long appTransID,
      string uiName,
      string permission,
      List<long> statusList)
    {
      return appTransID <= 0L ? this.HasEntityPermission(-33L, uiName, permission) : this.HasUIPermissionForEntityStatus(appTransID, uiName, permission, statusList);
    }

    private string GetInternalPartnerIsPrimary(string isPrimary) => !(isPrimary == "0") ? "Yes" : "No";

    private static string GetWorkflowType(IrisSoftware.iMPACT.Data.Opportunity oppty) => string.Empty;

    private List<WorkflowStateViewModel> GetWorkflowState(
      IEnumerable<Transition<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>> stateTransitions,
      IrisSoftware.iMPACT.Data.Opportunity oppty)
    {
      List<WorkflowStateViewModel> source = new List<WorkflowStateViewModel>();
      foreach (Transition<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> stateTransition in stateTransitions)
      {
        Transition<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transition = stateTransition;
        long fromStateId = (long) transition.FromState.Key;
        string valueDescription1 = ReflectionUtils.GetEnumValueDescription((System.Enum) transition.FromState.Key);
        foreach (IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> toState1 in transition.ToStates)
        {
          IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> toState = toState1;
          long toStateId = (long) toState.Key;
          string valueDescription2 = ReflectionUtils.GetEnumValueDescription((System.Enum) toState.Key);
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == fromStateId)))
          {
            bool flag1 = oppty.OpportunityDetail.OpportunityStatus.Contains((long) transition.FromState.Key);
            bool flag2 = oppty.WorkflowStateTransitions != null && oppty.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long key1 = (long) transition.FromState.Key;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((key1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long key2 = (long) transition.FromState.Key;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return key2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = fromStateId,
              StateName = valueDescription1,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == toStateId)))
          {
            bool flag1 = oppty.OpportunityDetail.OpportunityStatus.Contains((long) toState.Key);
            bool flag2 = oppty.WorkflowStateTransitions != null && oppty.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long key1 = (long) toState.Key;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((key1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long key2 = (long) toState.Key;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return key2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = toStateId,
              StateName = valueDescription2,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
        }
      }
      return source;
    }

    private List<WorkflowStateTransitionViewModel> GetWorkflowStateTransition(
      IEnumerable<Transition<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>> stateTransition,
      OpportunityViewModel opptyViewModel,
      IrisSoftware.iMPACT.Data.Opportunity oppty)
    {
      List<WorkflowStateTransitionViewModel> transitionViewModelList = new List<WorkflowStateTransitionViewModel>();
      foreach (Transition<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transition1 in stateTransition)
      {
        Transition<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transition = transition1;
        foreach (IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> toState1 in transition.ToStates)
        {
          IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> toState = toState1;
          transitionViewModelList.Add(new WorkflowStateTransitionViewModel()
          {
            FromState = (long) transition.FromState.Key,
            ToState = (long) toState.Key,
            IsVisited = oppty.WorkflowStateTransitions != null && oppty.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long? nullable = itm.FromStateID;
              long key1 = (long) transition.FromState.Key;
              if ((nullable.GetValueOrDefault() == key1 ? (nullable.HasValue ? 1 : 0) : 0) == 0)
                return false;
              nullable = itm.ToStateID;
              long key2 = (long) toState.Key;
              return nullable.GetValueOrDefault() == key2 && nullable.HasValue;
            }))
          });
        }
      }
      return transitionViewModelList;
    }

    private bool HasOpptyUIViewOnlyPermission(
      long appTransactionId,
      string uiName,
      List<long> statusList)
    {
      return appTransactionId <= 0L ? !this.HasEntityPermission(-33L, uiName, "Edit") && this.HasEntityPermission(-33L, uiName, "View") : !this.HasUIPermissionForEntityStatus(appTransactionId, uiName, "Edit", statusList) && this.HasUIPermissionForEntity(-33L, appTransactionId, uiName, "View");
    }

    private IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys() => this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetOpportunityLookupKeys());

    private IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys(
      OpportunityViewModel opportunity)
    {
      return this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetOpportunityLookupKeys(), this.GetOpportunityLookupItemsID(opportunity));
    }

    private string[] GetOpportunityLookupItemsID(OpportunityViewModel opportunity)
    {
      string[] strArray = new string[17];
      long? nullable;
      long num;
      string str1;
      if (!opportunity.OpportunityType.HasValue)
      {
        str1 = "0";
      }
      else
      {
        nullable = opportunity.OpportunityType;
        num = nullable.Value;
        str1 = num.ToString();
      }
      strArray[0] = str1;
      nullable = opportunity.State;
      string str2;
      if (!nullable.HasValue)
      {
        str2 = "0";
      }
      else
      {
        nullable = opportunity.State;
        num = nullable.Value;
        str2 = num.ToString();
      }
      strArray[1] = str2;
      nullable = opportunity.MaterialType;
      string str3;
      if (!nullable.HasValue)
      {
        str3 = "0";
      }
      else
      {
        nullable = opportunity.MaterialType;
        num = nullable.Value;
        str3 = num.ToString();
      }
      strArray[2] = str3;
      nullable = opportunity.ApprovedDerivativeMarketer;
      string str4;
      if (!nullable.HasValue)
      {
        str4 = "0";
      }
      else
      {
        nullable = opportunity.ApprovedDerivativeMarketer;
        num = nullable.Value;
        str4 = num.ToString();
      }
      strArray[3] = str4;
      nullable = opportunity.FirmRole;
      string str5;
      if (!nullable.HasValue)
      {
        str5 = "0";
      }
      else
      {
        nullable = opportunity.FirmRole;
        num = nullable.Value;
        str5 = num.ToString();
      }
      strArray[4] = str5;
      nullable = opportunity.Purpose;
      string str6;
      if (!nullable.HasValue)
      {
        str6 = "0";
      }
      else
      {
        nullable = opportunity.Purpose;
        num = nullable.Value;
        str6 = num.ToString();
      }
      strArray[5] = str6;
      nullable = opportunity.TransactionType;
      string str7;
      if (!nullable.HasValue)
      {
        str7 = "0";
      }
      else
      {
        nullable = opportunity.TransactionType;
        num = nullable.Value;
        str7 = num.ToString();
      }
      strArray[6] = str7;
      nullable = opportunity.SecurityType;
      string str8;
      if (!nullable.HasValue)
      {
        str8 = "0";
      }
      else
      {
        nullable = opportunity.SecurityType;
        num = nullable.Value;
        str8 = num.ToString();
      }
      strArray[7] = str8;
      nullable = opportunity.InsuranceProvider;
      string str9;
      if (!nullable.HasValue)
      {
        str9 = "0";
      }
      else
      {
        nullable = opportunity.InsuranceProvider;
        num = nullable.Value;
        str9 = num.ToString();
      }
      strArray[8] = str9;
      nullable = opportunity.Market;
      string str10;
      if (!nullable.HasValue)
      {
        str10 = "0";
      }
      else
      {
        nullable = opportunity.Market;
        num = nullable.Value;
        str10 = num.ToString();
      }
      strArray[9] = str10;
      nullable = opportunity.RFPType;
      string str11;
      if (!nullable.HasValue)
      {
        str11 = "0";
      }
      else
      {
        nullable = opportunity.RFPType;
        num = nullable.Value;
        str11 = num.ToString();
      }
      strArray[10] = str11;
      nullable = opportunity.RateType;
      string str12;
      if (!nullable.HasValue)
      {
        str12 = "0";
      }
      else
      {
        nullable = opportunity.RateType;
        num = nullable.Value;
        str12 = num.ToString();
      }
      strArray[11] = str12;
      nullable = opportunity.MoodyRatingLT;
      string str13;
      if (!nullable.HasValue)
      {
        str13 = "0";
      }
      else
      {
        nullable = opportunity.MoodyRatingLT;
        num = nullable.Value;
        str13 = num.ToString();
      }
      strArray[12] = str13;
      nullable = opportunity.SPRatingLT;
      string str14;
      if (!nullable.HasValue)
      {
        str14 = "0";
      }
      else
      {
        nullable = opportunity.SPRatingLT;
        num = nullable.Value;
        str14 = num.ToString();
      }
      strArray[13] = str14;
      nullable = opportunity.FitchRatingLT;
      string str15;
      if (!nullable.HasValue)
      {
        str15 = "0";
      }
      else
      {
        nullable = opportunity.FitchRatingLT;
        num = nullable.Value;
        str15 = num.ToString();
      }
      strArray[14] = str15;
      nullable = opportunity.DealType;
      string str16;
      if (!nullable.HasValue)
      {
        str16 = "0";
      }
      else
      {
        nullable = opportunity.DealType;
        num = nullable.Value;
        str16 = num.ToString();
      }
      strArray[15] = str16;
      nullable = opportunity.GeneralCategory;
      string str17;
      if (!nullable.HasValue)
      {
        str17 = "0";
      }
      else
      {
        nullable = opportunity.GeneralCategory;
        num = nullable.Value;
        str17 = num.ToString();
      }
      strArray[16] = str17;
      return ((IEnumerable<string>) strArray).Concat<string>((IEnumerable<string>) this.GetExternalPartnerIDs(opportunity.Advisors)).ToArray<string>();
    }

    private string[] GetExternalPartnerIDs(List<ExternalPartner> externalPartner)
    {
      if (externalPartner != null && externalPartner.Count<ExternalPartner>() > 0)
        return externalPartner.Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.MemberType.ToString())).ToArray<string>();
      return new string[1]{ "0" };
    }

    private string[] GetOpportunityLookupKeys() => new string[33]
    {
      "Type of Opportunity",
      "MA Exemption",
      "State",
      "Material Type",
      "Approved Derivative Marketer",
      "Firm Role",
      "Purpose",
      "Transaction Type",
      "Use of Proceeds",
      "Security Type (General)",
      "Insurance Provider",
      "Market",
      "Oppty RFP Type",
      "Interest Rate Type",
      "Moody's Long Term Rating",
      "S&P Long Term Rating",
      "Kroll Long Term Rating",
      "Fitch Long Term Rating",
      "Kroll Long Term Rating",
      "Advisory Agent Type",
      "Counsel Type",
      "Deal Type",
      "G-17 Type",
      "RFP Type",
      "MS Banking Group",
      "General Category (Specific)",
      "Syndicate Member Role",
      "Winning Syndicate Member Role",
      "Moody's Short Term Rating",
      "S&P Short Term Rating",
      "Kroll Short Term Rating",
      "Fitch Short Term Rating",
      "Fed Tax"
    };

    public SaveResult Save(
      OpportunityViewModel opportunityModel,
      string opportunityAction)
    {
      try
      {
        this.Log.Error(Modules.Opportunity, string.Format("PERFORMANCE :  Save called at {0} for AppTrsanctionId {1} ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID));
        this.GetSafeObject<OpportunityViewModel>(opportunityModel);
        TransitionResult<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transitionResult = (TransitionResult<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>) null;
        List<IrisSoftware.iMPACT.Data.Opportunity.Status> statusList = new List<IrisSoftware.iMPACT.Data.Opportunity.Status>();
        statusList.Add(IrisSoftware.iMPACT.Data.Opportunity.Status.Open);
        IrisSoftware.iMPACT.Data.Opportunity oldOpportunity = new IrisSoftware.iMPACT.Data.Opportunity();
        bool IsIssueInitiated = false;
        this.Log.Error(Modules.Opportunity, string.Format("PERFORMANCE : GetSafe executed and list object {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID));
        DateTime now;
        if (opportunityModel.AppTransactionID > 0L)
        {
          oldOpportunity = this.OpportunityRepository.FetchByID(opportunityModel.AppTransactionID);
          statusList.Clear();
          if (!string.IsNullOrEmpty(oldOpportunity.OpportunityDetail.CommaSeperatedStateID))
            oldOpportunity.OpportunityDetail.OpportunityStatus = ((IEnumerable<string>) oldOpportunity.OpportunityDetail.CommaSeperatedStateID.Split(new string[1]
            {
              ","
            }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>((Func<string, long>) (s => long.Parse(s))).ToList<long>();
          statusList = oldOpportunity.OpportunityDetail.OpportunityStatus.ConvertAll<IrisSoftware.iMPACT.Data.Opportunity.Status>((Converter<long, IrisSoftware.iMPACT.Data.Opportunity.Status>) (s => (IrisSoftware.iMPACT.Data.Opportunity.Status) s));
          Logger<Modules> log = this.Log;
          now = DateTime.Now;
          string message = string.Format("PERFORMANCE : Setting lstOldOpptyStatus with Old Opp Status at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
          log.Error(Modules.Opportunity, message);
        }
        SaveResult saveResult = opportunityModel.Validate<OpportunityViewModel>();
        if (saveResult.IsSuccessful && this.ValidateModel(opportunityModel, ref saveResult))
        {
          Logger<Modules> log1 = this.Log;
          now = DateTime.Now;
          string message1 = string.Format("PERFORMANCE : Modal validated  at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
          log1.Error(Modules.Opportunity, message1);
          IrisSoftware.iMPACT.Data.Opportunity opportunity = opportunityModel.GetOpportunity();
          opportunity.UploadedDocumentTypes = this.OpportunityRepository.FetchUploadedDocumentTypes(opportunityModel.AppTransactionID);
          IWorkflow<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> workflow = this.WorkflowFactory.GetWorkflow(OpportunityPresenter.GetWorkflowType(opportunity));
          long num = opportunityModel.AppTransactionID;
          opportunity.OpportunityDetail.SubmittedToMERGDate = oldOpportunity.OpportunityDetail.SubmittedToMERGDate;
          opportunity.OpportunityDetail.SupervisoryPrincipalApproverName = oldOpportunity.OpportunityDetail.SupervisoryPrincipalApproverName;
          opportunity.OpportunityDetail.CreatedOn = oldOpportunity.OpportunityDetail.CreatedOn;
          opportunity.OpportunityDetail.IsCommitmentCommitteeApproved = oldOpportunity.OpportunityDetail.IsCommitmentCommitteeApproved;
          opportunity.OpportunityDetail.IsManagementApproved = oldOpportunity.OpportunityDetail.IsManagementApproved;
          Dictionary<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status> dictionary = (Dictionary<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status>) null;
          if (num > 0L)
            dictionary = this.OpportunityRepository.FetchHistoryByAppTransactionID(num);
          if (dictionary != null && dictionary.Count < 1)
            dictionary = (Dictionary<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status>) null;
          Logger<Modules> log2 = this.Log;
          now = DateTime.Now;
          string message2 = string.Format("PERFORMANCE : Getting  GetWorkflowType,WorkflowFactory ,FetchHistoryByAppTransactionID  at  {0} for AppTrsanctionId {1} ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
          log2.Error(Modules.Opportunity, message2);
          opportunity.OpportunityDetail.ToSkipCase = false;
          bool? committeeApproved = opportunity.OpportunityDetail.IsCommitmentCommitteeApproved;
          bool flag1 = true;
          bool? nullable;
          if ((committeeApproved.GetValueOrDefault() == flag1 ? (committeeApproved.HasValue ? 1 : 0) : 0) != 0 && opportunityAction == string.Empty)
          {
            nullable = opportunity.OpportunityDetail.HasRFPFeeChangedAfterManagementApprovalProcess;
            bool flag2 = true;
            if ((nullable.GetValueOrDefault() == flag2 ? (nullable.HasValue ? 1 : 0) : 0) != 0 && oldOpportunity.OpportunityDetail.OpportunityStatusValue == ReflectionUtils.GetEnumValueDescription((System.Enum) IrisSoftware.iMPACT.Data.Opportunity.Status.CommitmentCommitteeReview))
              opportunity.OpportunityDetail.ToSkipCase = true;
          }
          if (!workflow.TryHandle(opportunity, (IEnumerable<IrisSoftware.iMPACT.Data.Opportunity.Status>) statusList, opportunityAction, (IDictionary<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status>) dictionary, out transitionResult))
            return SaveResult.Failure(transitionResult.Errors);
          Dictionary<int, int> history = this.AddHistory(transitionResult);
          List<int> transitionStateTracking = this.GetTransitionStateTracking(statusList, transitionResult);
          List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> fromToStateList;
          List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> stateAuditTrailList;
          if (num > 0L)
          {
            fromToStateList = EntityStateHelper.GetTransitionFromToState<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState, IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>(statusList, transitionResult);
            stateAuditTrailList = EntityStateHelper.GetAuditFromToState<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState, IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>(statusList, transitionResult);
          }
          else
          {
            fromToStateList = this.SetFromToStateList(transitionResult);
            stateAuditTrailList = new List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState>();
          }
          Logger<Modules> log3 = this.Log;
          now = DateTime.Now;
          string message3 = string.Format("PERFORMANCE : TryHandle Called- Set fromToStateList,stateAuditTrailList at  {0} for AppTrsanctionId {1} ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
          log3.Error(Modules.Opportunity, message3);
          bool flag3 = false;
          if (!string.IsNullOrEmpty(opportunityAction))
          {
            IrisSoftware.iMPACT.Core.Security.Permission[] array1 = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, -33L, opportunityModel.AppTransactionID)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "Opportunity Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
            List<long> longList = this.SetStatusList(opportunityModel);
            string[] array2 = workflow.GetAllowedActions((IEnumerable<IrisSoftware.iMPACT.Data.Opportunity.Status>) longList.ConvertAll<IrisSoftware.iMPACT.Data.Opportunity.Status>((Converter<long, IrisSoftware.iMPACT.Data.Opportunity.Status>) (s => (IrisSoftware.iMPACT.Data.Opportunity.Status) s))).ToArray<string>();
            opportunityModel.Actions = this.GetMatchingPermission(array1, array2);
            flag3 = ((IEnumerable<string>) opportunityModel.Actions).FirstOrDefault<string>((Func<string, bool>) (x => x == opportunityAction)) != null;
            Logger<Modules> log4 = this.Log;
            now = DateTime.Now;
            string message4 = string.Format("PERFORMANCE : Getting Permissions and workflow action based upon selected action at  {0} for AppTrsanctionId {1} ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
            log4.Error(Modules.Opportunity, message4);
          }
          List<InternalPartner> internalPartnerList = new List<InternalPartner>();
          List<InternalPartnerBankRM> internalPartnerBankRmList = new List<InternalPartnerBankRM>();
          using (TransactionScope transactionScope = new TransactionScope())
          {
            opportunity.OpportunityDetail.OpportunityStatus = transitionResult.ResultingStates.Select<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>, long>((Func<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>, long>) (s => (long) s.Key)).ToList<long>();
            OpportunityPresenter.OpportunityEditOnlyStatus opportunityEditOnlyStatus = this.SetOpportunityEditOnlyStatus(statusList, opportunity.OpportunityDetail.AppTransactionID);
            if (!opportunityEditOnlyStatus.isOpportunityDetailsEditable && !flag3)
            {
              string reviewComments = opportunity.OpportunityDetail.ReviewComments;
              opportunity.OpportunityDetail = oldOpportunity.OpportunityDetail;
              opportunity.OpportunityDetail.ReviewComments = reviewComments;
            }
            internalPartnerList = opportunity.InternalPartners;
            internalPartnerBankRmList = opportunity.InternalPartnerBankRMs;
            if (!opportunityEditOnlyStatus.isInternalPartnerEditable)
            {
              opportunity.InternalPartners = (List<InternalPartner>) null;
              opportunity.InternalPartnerBankRMs = (List<InternalPartnerBankRM>) null;
            }
            if (!opportunityEditOnlyStatus.isExternalPartnerEditable)
              opportunity.ExternalPartners = (List<ExternalPartner>) null;
            if (!opportunityEditOnlyStatus.isMiscEditable)
              opportunity.MiscFieldsValueDetail = (IEnumerable<PropertySetValue>) null;
            Logger<Modules> log4 = this.Log;
            now = DateTime.Now;
            string message4 = string.Format("PERFORMANCE : Checking edit/view permission  at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
            log4.Error(Modules.Opportunity, message4);
            num = this.OpportunityRepository.Save(opportunity, history, fromToStateList, stateAuditTrailList);
            Logger<Modules> log5 = this.Log;
            now = DateTime.Now;
            string message5 = string.Format("PERFORMANCE : Repository Save called  at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
            log5.Error(Modules.Opportunity, message5);
            if (num == -1L)
            {
              OpportunityViewModel opportunityViewModel = this.Initialize(opportunity.OpportunityDetail.AppTransactionID);
              string errorMessage = string.Format("{0} has updated the {1}. Please refresh your screen, re-enter your data and save. Press Yes to refresh the screen.", (object) opportunityViewModel.LastModifiedBy, (object) "Opportunity");
              transactionScope.Complete();
              Logger<Modules> log6 = this.Log;
              now = DateTime.Now;
              string message6 = string.Format("PERFORMANCE : Checking Overriding  at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunityModel.AppTransactionID);
              log6.Error(Modules.Opportunity, message6);
              return SaveResult.Failure(num, errorMessage, (object) opportunityViewModel);
            }
            opportunity.OpportunityDetail.AppTransactionID = num;
            if (num > 0L)
            {
              IrisSoftware.iMPACT.Data.Opportunity op = this.OpportunityRepository.FetchByID(num);
              this.SetOpportunityNumber(opportunity, op);
              this.SetMSBankingGroup(opportunity, op);
              this.SetLeadBanker(opportunity, op);
              opportunity.ReviewCommentsCollection = op.ReviewCommentsCollection;
            }
            this.PerformSharePointDocumentSetOperations(num, oldOpportunity, opportunity);
            Logger<Modules> log7 = this.Log;
            now = DateTime.Now;
            string message7 = string.Format("PERFORMANCE : PerformSharePointDocumentSetOperations called  at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunity.OpportunityDetail.AppTransactionID);
            log7.Error(Modules.Opportunity, message7);
            saveResult.Id = num;
            if (opportunityAction == "InitiateIssue" && opportunity.OpportunityDetail.OpportunityStatus != null && (opportunity.OpportunityDetail.OpportunityStatus.Count > 0 && opportunity.OpportunityDetail.OpportunityStatus.Contains(12L)) && opportunityModel.CanInitiateIssue)
            {
              nullable = opportunity.OpportunityDetail.HasRFPInitiated;
              if (!nullable.GetValueOrDefault())
              {
                this.Log.Error(Modules.Opportunity, string.Format("PERFORMANCE : Issue Initiated called from Oppty with AppTransactionID: {0} and User Name is : {1} and UserId is : {2} ", (object) num, (object) this.AppUser.Name, (object) this.AppUser.Id));
                SaveResult issueFromOpportunity = this.CreateIssueFromOpportunity(opportunityModel);
                this.FlushUserEntitySecurityPermissions();
                if (issueFromOpportunity.IsSuccessful)
                {
                  this.SaveAuditTrail(opportunityModel);
                  IsIssueInitiated = true;
                  this.Log.Error(Modules.Opportunity, string.Format("PERFORMANCE : Issue Initiated called from Oppty with AppTransactionID: {0} and User Name is : {1} and UserId is : {2} was successful", (object) num, (object) this.AppUser.Name, (object) this.AppUser.Id));
                }
                else
                {
                  this.Log.Error(Modules.Opportunity, string.Format("PERFORMANCE : Issue Initiated called from Oppty with AppTransactionID: {0} and User Name is : {1} and UserId is : {2} failed. The error was - {3}", (object) num, (object) this.AppUser.Name, (object) this.AppUser.Id, (object) issueFromOpportunity.ErrorMessage));
                  return issueFromOpportunity;
                }
              }
            }
            transactionScope.Complete();
            Logger<Modules> log8 = this.Log;
            now = DateTime.Now;
            string message8 = string.Format("PERFORMANCE : transaction complete  at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) opportunity.OpportunityDetail.AppTransactionID);
            log8.Error(Modules.Opportunity, message8);
          }
          opportunity.InternalPartners = internalPartnerList;
          opportunity.InternalPartnerBankRMs = internalPartnerBankRmList;
          opportunity.OpportunityDetail.RFPTypeName = opportunityModel.RFPTypeName;
          opportunity.OpportunityDetail.Ratings = opportunityModel.Ratings;
          opportunity.OpportunityDetail.ExpectedFirmRoleValue = opportunityModel.ExpectedFirmRoleValue;
          opportunity.OpportunityDetail.DealTypeName = opportunityModel.DealTypeName;
          opportunity.OpportunityDetail.OpportunityTypeName = opportunityModel.OpportunityTypeName;
          this.PublishEvents(opportunityModel, opportunityAction, statusList, oldOpportunity, IsIssueInitiated, saveResult, opportunity, num, fromToStateList, transitionStateTracking);
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public OpportunityViewModel CopyOpportunity(long appTransactionId)
    {
      try
      {
        if (appTransactionId > 0L)
        {
          if (!this.HasUIPermissionForEntity(-33L, appTransactionId, "Opportunity Details", "View"))
          {
            OpportunityViewModel opportunityViewModel = new OpportunityViewModel();
            opportunityViewModel.ErrorMessage = "401";
            return opportunityViewModel;
          }
        }
        else if (!this.HasEntityPermission(-33L, "Opportunity Details", "Create"))
        {
          OpportunityViewModel opportunityViewModel = new OpportunityViewModel();
          opportunityViewModel.ErrorMessage = "401";
          return opportunityViewModel;
        }
        return this.GetViewModel(this.OpportunityRepository.CopyOpportunity(appTransactionId), 0L, true);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        OpportunityViewModel opportunityViewModel = new OpportunityViewModel();
        opportunityViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return opportunityViewModel;
      }
    }

    public List<OpportunityPipelineViewModel> GetOpportunityPipeline()
    {
      try
      {
        List<OpportunityPipelineViewModel> pipelineViewModelList = new List<OpportunityPipelineViewModel>();
        IDataReader dataReader = this.OpportunityRepository.FetchOpportunityPipeline();
        IRowMapper<OpportunityPipelineViewModel> rowMapper = MapBuilder<OpportunityPipelineViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<OpportunityPipelineViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<OpportunityPipelineViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<OpportunityPipelineViewModel, string>>) (x => x.ErrorMessage)).Build();
        while (dataReader.Read())
          pipelineViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        return pipelineViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        return new List<OpportunityPipelineViewModel>();
      }
    }

    private string ConvertDateFormat(string value)
    {
      DateTime result;
      return !string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result) ? result.ToString("MM/dd/yyyy") : "";
    }

    private string ConvertDateFormat(DateTime? value) => !value.HasValue ? "" : value.Value.ToString("MM/dd/yyyy");

    private Decimal? ConvertToDecimal(string str) => string.IsNullOrEmpty(str) ? new Decimal?() : new Decimal?(Convert.ToDecimal(str));

    public List<string> GetOpportunityNames(string opportunityName)
    {
      try
      {
        return this.OpportunityRepository.FetchOpportunityNames(opportunityName).ToList<string>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<string>();
      }
    }

    public ExportResult Export(
      KendoGridRequest request,
      OpportunitySearchViewModel searchCriteria,
      string exportType,
      string timezoneOffSet)
    {
      try
      {
        bool isBlankSearch = false;
        DataTable searchResultsToExport = this.GetSearchResultsToExport(request, searchCriteria, out long _, ref isBlankSearch, timezoneOffSet);
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Opportunity Search", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        List<SearchResultField> list = searchCriteria.SelectedFields.OrderBy<SearchResultField, int>((Func<SearchResultField, int>) (x => x.Order)).ToList<SearchResultField>();
        string tzAbbreviation = this.GetTzAbbreviation(TimeZone.CurrentTimeZone.StandardName);
        foreach (SearchResultField searchResultField in list)
        {
          if (searchResultField.ExportColumns != null && searchResultField.IsTimezoneReq)
            tabularReportBuilder.AddColumn(searchResultField.Html.title + " (" + tzAbbreviation + ")", searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1, (IEnumerable<string>) searchResultField.ExportColumns);
          else if (searchResultField.ExportColumns != null && !searchResultField.IsTimezoneReq)
            tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1, (IEnumerable<string>) searchResultField.ExportColumns);
          else
            tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1);
        }
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "OpportunitySearch", (object) searchResultsToExport);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }

    public string GetTzAbbreviation(string timeZoneName)
    {
      StringBuilder stringBuilder = new StringBuilder();
      string str1 = timeZoneName;
      char[] chArray = new char[1]{ ' ' };
      foreach (string str2 in str1.Split(chArray))
      {
        if (str2[0] != '(')
          stringBuilder.Append(str2[0]);
        else
          stringBuilder.Append(str2);
      }
      return stringBuilder.ToString();
    }

    private string[] GetSearchLookupItemKeys() => new string[22]
    {
      "Opportunity Status",
      "State",
      "Type of Opportunity",
      "MA Exemption",
      "MS Banking Group",
      "Firm Role",
      "Purpose",
      "Market",
      "Moody's Long Term Rating",
      "S&P Long Term Rating",
      "Kroll Long Term Rating",
      "Fitch Long Term Rating",
      "Advisory Agent Type",
      "Counsel Type",
      "Security Type (General)",
      "Syndicate Member Role",
      "Winning Syndicate Member Role",
      "Fed Tax",
      "Deal Type",
      "RFP Type",
      "Interest Rate Type",
      "Use of Proceeds"
    };

    public OpportunitySearchViewModel InitializeSearchViewModel()
    {
      OpportunitySearchViewModel searchViewModel = new OpportunitySearchViewModel();
      IEnumerable<LookupItemMappings> lookupItems = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetSearchLookupItemKeys(), (string[]) null, false);
      this.PopulateLookupItems(ref searchViewModel, lookupItems);
      IEnumerable<EntityState> source = this.EntityStateRepository.FetchEntityStateByEntityID(-33L);
      searchViewModel.OpportunityStatuses = source.Select<EntityState, KeyValuePair<long, string>>((Func<EntityState, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.StateID, x.StateKey))).ToList<KeyValuePair<long, string>>();
      searchViewModel.CanCreatePublicBookmark = this.HasEntityPermission(-33L, "Public Bookmark", "Create");
      SearchSetting searchSetting = this.OpportunityRepository.FetchAllBookmarks().FirstOrDefault<SearchSetting>((Func<SearchSetting, bool>) (x => x.SearchSettingID == -1L));
      if (searchSetting == null)
      {
        List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
        List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
        List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
        List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
        searchViewModel.SelectedFields = list1;
        searchViewModel.AllFields = list2;
        searchViewModel.SelectedAllFields = list2;
        searchViewModel.FieldsToSelect = list1;
      }
      else
      {
        IssueSearchViewModel issueSearchViewModel = new JavaScriptSerializer().Deserialize<IssueSearchViewModel>(searchSetting.Criteria);
        if (issueSearchViewModel.SelectedFields != null && issueSearchViewModel.SelectedFields.Count > 0)
        {
          searchViewModel.SelectedFields = issueSearchViewModel.SelectedFields;
          searchViewModel.AllFields = issueSearchViewModel.AllFields;
          searchViewModel.SelectedAllFields = issueSearchViewModel.AllFields;
          searchViewModel.FieldsToSelect = issueSearchViewModel.FieldsToSelect;
        }
        else
        {
          List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
          List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
          List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
          List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
          searchViewModel.SelectedFields = list1;
          searchViewModel.AllFields = list2;
          searchViewModel.SelectedAllFields = list2;
          searchViewModel.FieldsToSelect = list1;
        }
      }
      return searchViewModel;
    }

    private void PopulateLookupItems(
      ref OpportunitySearchViewModel searchViewModel,
      IEnumerable<LookupItemMappings> lookupItems)
    {
      foreach (LookupItemMappings lookupItem in lookupItems)
      {
        KeyValuePair<long, string> keyValuePair = new KeyValuePair<long, string>(lookupItem.LookupItemID, lookupItem.Value);
        KeyPair keyPair1 = (KeyPair) null;
        switch (lookupItem.Key)
        {
          case "Advisory Agent Type":
            KeyPair keyPair2 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            searchViewModel.AdvisorAgentType.Add(keyPair2);
            continue;
          case "Counsel Type":
            KeyPair keyPair3 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            searchViewModel.CounselType.Add(keyPair3);
            continue;
          case "Deal Type":
            searchViewModel.DealTypes.Add(keyValuePair);
            continue;
          case "Fed Tax":
            keyPair1 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            searchViewModel.SeriesFedTax.Add(keyValuePair);
            continue;
          case "Firm Role":
            searchViewModel.FirmRoles.Add(keyValuePair);
            continue;
          case "Fitch Long Term Rating":
            KeyPair keyPair4 = new KeyPair(lookupItem.Value, lookupItem.Value);
            searchViewModel.MoodyLongTermRatings.Add(keyPair4);
            continue;
          case "Interest Rate Type":
            searchViewModel.InterestRateTypes.Add(keyValuePair);
            continue;
          case "Kroll Long Term Rating":
            KeyPair keyPair5 = new KeyPair(lookupItem.Value, lookupItem.Value);
            searchViewModel.KrollLongTermRatings.Add(keyPair5);
            continue;
          case "MA Exemption":
            searchViewModel.MAExemptions.Add(keyValuePair);
            continue;
          case "MS Banking Group":
            searchViewModel.Markets.Add(keyValuePair);
            continue;
          case "Moody's Long Term Rating":
            KeyPair keyPair6 = new KeyPair(lookupItem.Value, lookupItem.Value);
            searchViewModel.FitchLongTermRatings.Add(keyPair6);
            continue;
          case "Purpose":
            KeyPair keyPair7 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            searchViewModel.Purposes.Add(keyPair7);
            continue;
          case "RFP Type":
            searchViewModel.RFPTypes.Add(keyValuePair);
            continue;
          case "S&P Long Term Rating":
            KeyPair keyPair8 = new KeyPair(lookupItem.Value, lookupItem.Value);
            searchViewModel.SPLongTermRatings.Add(keyPair8);
            continue;
          case "Security Type (General)":
            KeyPair keyPair9 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            searchViewModel.SecurityTypes.Add(keyPair9);
            continue;
          case "State":
            searchViewModel.States.Add(keyValuePair);
            continue;
          case "Syndicate Member Role":
            KeyPair keyPair10 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            searchViewModel.SyndicateMember.Add(keyPair10);
            continue;
          case "Type of Opportunity":
            searchViewModel.OpportunityTypes.Add(keyValuePair);
            continue;
          case "Use of Proceeds":
            searchViewModel.UseOfProceeds.Add(keyValuePair);
            continue;
          case "Winning Syndicate Member Role":
            KeyPair keyPair11 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            searchViewModel.WinningSyndicateMember.Add(keyPair11);
            continue;
          default:
            continue;
        }
      }
    }

    public List<SearchSettingViewModel> GetAllBookmarks()
    {
      try
      {
        return this.OpportunityRepository.FetchAllBookmarks().Select<SearchSetting, SearchSettingViewModel>((Func<SearchSetting, SearchSettingViewModel>) (x => new SearchSettingViewModel(x))).ToList<SearchSettingViewModel>().Where<SearchSettingViewModel>((Func<SearchSettingViewModel, bool>) (x => x.SearchSettingID > 0L)).ToList<SearchSettingViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        return new List<SearchSettingViewModel>();
      }
    }

    public SaveResult SaveBookmark(SearchSettingViewModel searchSettingModel)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.OpportunityRepository.SaveBookmark(new SearchSetting()
          {
            SearchSettingID = searchSettingModel.SearchSettingID,
            Name = searchSettingModel.Name,
            Criteria = searchSettingModel.Criteria,
            GridSetting = searchSettingModel.GridSetting,
            Public = searchSettingModel.Public
          });
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult DeleteBookmark(long bookmarkId)
    {
      try
      {
        this.OpportunityRepository.DeleteBookmark(bookmarkId);
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SearchOpportunity(
      KendoGridRequest request,
      OpportunitySearchViewModel searchCriteria,
      string timeZoneOffset)
    {
      try
      {
        long total = 0;
        bool isBlankSearch = false;
        IEnumerable<Dictionary<string, object>> searchResults = this.GetSearchResults(request, searchCriteria, out total, ref isBlankSearch, timeZoneOffset);
        SaveResult saveResult1 = new SaveResult();
        SaveResult saveResult2;
        if (isBlankSearch)
        {
          saveResult2 = SaveResult.Failure("Please select one or more filter criteria to continue search.");
        }
        else
        {
          saveResult2 = SaveResult.Success;
          saveResult2.ViewModel = (object) new Paged<Dictionary<string, object>>((object) searchResults, total);
        }
        return saveResult2;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        return SaveResult.Failure(ex.Message);
      }
    }

    private static object FixDate(string name, object value) => value != null && !string.IsNullOrEmpty(value.ToString()) && (OpportunityPresenter.dateColumnsToAdjust.Contains(name) && DateTime.TryParse(value.ToString(), out DateTime _)) ? (object) string.Format("{0:yyyy}-{0:MM}-{0:dd}T{0:HH}:{0:mm}:00.00", (object) (DateTime) value) : value;

    private IEnumerable<Dictionary<string, object>> GetSearchResults(
      KendoGridRequest request,
      OpportunitySearchViewModel opportunitySearchCriteria,
      out long total,
      ref bool isBlankSearch,
      string timeZoneOffset)
    {
      List<Dictionary<string, object>> finalSearchResults = new List<Dictionary<string, object>>();
      using (IDataReader searchData = this.GetSearchData(request, opportunitySearchCriteria, out total, ref isBlankSearch, timeZoneOffset))
      {
        List<Dictionary<string, object>> searchResults = new List<Dictionary<string, object>>();
        List<string> stringList = new List<string>();
        if (searchData != null)
        {
          while (searchData.Read())
          {
            Dictionary<string, object> dictionary = searchData.ConvertToDictionary(new Func<string, object, object>(OpportunityPresenter.FixDate));
            searchResults.Add(dictionary);
            stringList.Add(searchData["AppTransactionID"].ToString());
          }
          if (searchData.NextResult() && searchData.Read())
            total = (long) searchData.GetInt32(0);
        }
        if (stringList.Count > 0)
        {
          string apptransactionIds = string.Join(",", stringList.ToArray());
          List<Dictionary<string, object>> miscSearchResults = new List<Dictionary<string, object>>();
          using (IDataReader dataReader = this.PropertySetValueRepository.FetchTransposedPropertySetValues(apptransactionIds))
          {
            if (dataReader != null)
            {
              while (dataReader.Read())
              {
                Dictionary<string, object> dictionary = dataReader.ConvertToDictionary(new Func<string, object, object>(OpportunityPresenter.FixDate));
                miscSearchResults.Add(dictionary);
              }
            }
          }
          if (miscSearchResults.Count > 0)
            this.AddToFinalSearchResults(searchResults, finalSearchResults, miscSearchResults);
          else
            finalSearchResults = searchResults;
        }
        else
          finalSearchResults = searchResults;
      }
      return (IEnumerable<Dictionary<string, object>>) finalSearchResults;
    }

    private IDataReader GetSearchData(
      KendoGridRequest request,
      OpportunitySearchViewModel searchCriteria,
      out long total,
      ref bool isBlankSearch,
      string timeZoneOffset)
    {
      total = 0L;
      if (searchCriteria.ExpectedPricingDateTo.HasValue)
        searchCriteria.ExpectedPricingDateTo = new DateTime?(searchCriteria.ExpectedPricingDateTo.Value.AddDays(1.0).AddSeconds(-1.0));
      DateTime? nullable1 = searchCriteria.CloseDateTo;
      if (nullable1.HasValue)
      {
        OpportunitySearchViewModel opportunitySearchViewModel = searchCriteria;
        nullable1 = searchCriteria.CloseDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        opportunitySearchViewModel.CloseDateTo = nullable2;
      }
      nullable1 = searchCriteria.CreateDateFrom;
      if (nullable1.HasValue)
      {
        OpportunitySearchViewModel opportunitySearchViewModel = searchCriteria;
        nullable1 = searchCriteria.CreateDateFrom;
        DateTime? nullable2 = new DateTime?(nullable1.Value.ToUniversalTime());
        opportunitySearchViewModel.CreateDateFrom = nullable2;
      }
      nullable1 = searchCriteria.CreateDateTo;
      if (nullable1.HasValue)
      {
        OpportunitySearchViewModel opportunitySearchViewModel1 = searchCriteria;
        nullable1 = searchCriteria.CreateDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.ToUniversalTime());
        opportunitySearchViewModel1.CreateDateTo = nullable2;
        OpportunitySearchViewModel opportunitySearchViewModel2 = searchCriteria;
        nullable1 = searchCriteria.CreateDateTo;
        DateTime? nullable3 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        opportunitySearchViewModel2.CreateDateTo = nullable3;
      }
      nullable1 = searchCriteria.ResponseDueDateTo;
      if (nullable1.HasValue)
      {
        OpportunitySearchViewModel opportunitySearchViewModel = searchCriteria;
        nullable1 = searchCriteria.ResponseDueDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        opportunitySearchViewModel.ResponseDueDateTo = nullable2;
      }
      IVisitableCriterion criterion1 = (IVisitableCriterion) EmptyCriterion.Instance;
      foreach (ExternalPartnerSearchModel externalPartner in searchCriteria.ExternalPartners)
        criterion1 = criterion1.Or("PartnerID".Equal(externalPartner.PartnerID).And("MemberType".Equal(externalPartner.Role)));
      IVisitableCriterion instance = (IVisitableCriterion) EmptyCriterion.Instance;
      IVisitableCriterion visitableCriterion1;
      if (searchCriteria.IsMAExemptionIn)
        visitableCriterion1 = instance.And("RFPMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "rfp")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn).Or("UWMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "underwriting")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).Or("IRMAMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "irma")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).Or("NONEMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "none")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)));
      else
        visitableCriterion1 = instance.And("RFPMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "rfp")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn).And("UWMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "underwriting")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).And("IRMAMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "irma")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).And("NONEMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "none")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)));
      List<SubQueryDefinition> subQueryDefinitionList = new List<SubQueryDefinition>();
      IVisitableCriterion criterion2 = (IVisitableCriterion) EmptyCriterion.Instance;
      bool flag = false;
      if (searchCriteria.SelectedOpportunityStatuses.Count > 0)
      {
        if (!searchCriteria.IsOpportunityStatusIn)
        {
          flag = true;
          subQueryDefinitionList.Add(new SubQueryDefinition()
          {
            Field = "OpportunityStatusID",
            Operator = "Out",
            Value = string.Join(",", searchCriteria.SelectedOpportunityStatuses.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>())
          });
        }
        else
          criterion2 = criterion2.And("OpportunityStatusID".AnyOf(searchCriteria.SelectedOpportunityStatuses.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsOpportunityStatusIn));
      }
      IVisitableCriterion visitableCriterion2 = Criterion.Contains("OpportunityNbr", string.IsNullOrEmpty(searchCriteria.OpportunityNumber) ? searchCriteria.OpportunityNumber : searchCriteria.OpportunityNumber.Trim()).And().And(Criterion.Contains("OpportunityName", string.IsNullOrEmpty(searchCriteria.OpportunityName) ? searchCriteria.OpportunityName : searchCriteria.OpportunityName.Trim())).And(Criterion.Contains("CreatedBy", string.IsNullOrEmpty(searchCriteria.CreatedBy) ? searchCriteria.CreatedBy : searchCriteria.CreatedBy.Trim())).And(criterion2).And("StateID".AnyOf(searchCriteria.SelectedOpportunityStates.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsOpportunityStateIn)).And(Criterion.Contains("Issuer", string.IsNullOrEmpty(searchCriteria.Issuer) ? searchCriteria.Issuer : searchCriteria.Issuer.Trim()).Or(Criterion.Contains("IssuerAliasName", string.IsNullOrEmpty(searchCriteria.Issuer) ? searchCriteria.Issuer : searchCriteria.Issuer.Trim()))).And(Criterion.Contains("Borrower", string.IsNullOrEmpty(searchCriteria.Borrower) ? searchCriteria.Borrower : searchCriteria.Borrower.Trim())).And("IssuerStateID".AnyOf(searchCriteria.SelectedIssuerStates.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsIssuerStateIn)).And("ParAmount".GreaterThanOrEqual<Decimal>(this.ConvertToDecimal(searchCriteria.ParAmountFrom))).And("ParAmount".LessThanOrEqual<Decimal>(this.ConvertToDecimal(searchCriteria.ParAmountTo))).And("ExpectedPricingDate".GreaterThanOrEqual<DateTime>(searchCriteria.ExpectedPricingDateFrom)).And("ExpectedPricingDate".LessThanOrEqual<DateTime>(searchCriteria.ExpectedPricingDateTo)).And("CloseDate".GreaterThanOrEqual<DateTime>(searchCriteria.CloseDateFrom)).And("CloseDate".LessThanOrEqual<DateTime>(searchCriteria.CloseDateTo)).And("CreateDate".GreaterThanOrEqual<DateTime>(searchCriteria.CreateDateFrom)).And("CreateDate".LessThanOrEqual<DateTime>(searchCriteria.CreateDateTo)).And("ResponseDueDate".GreaterThanOrEqual<DateTime>(searchCriteria.ResponseDueDateFrom)).And("ResponseDueDate".LessThanOrEqual<DateTime>(searchCriteria.ResponseDueDateTo)).And("OpportunityTypeID".AnyOf(searchCriteria.SelectedOpportunityTypes.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsOpportunityTypeIn)).And(visitableCriterion1).And("ExpectedFirmRoleID".AnyOf(searchCriteria.SelectedExpectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsExpectedFirmRoleIn)).And("PurposeID".Equal(string.IsNullOrEmpty(searchCriteria.Purpose) ? searchCriteria.Purpose : searchCriteria.Purpose.Trim())).And("SecurityTypeID".Equal(string.IsNullOrEmpty(searchCriteria.SecurityType) ? searchCriteria.SecurityType : searchCriteria.SecurityType.Trim())).And("MSBankingGroupID".AnyOf(searchCriteria.SelectedMarkets.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMarketIn)).And("RFPTypeID".Equal<long>(searchCriteria.RFPTypeID)).And("RateTypeID".Equal<long>(searchCriteria.RateTypeID)).And("TransactionTypeID".Equal<long>(searchCriteria.UseOfProceedsID)).And("FedTax".Equal(searchCriteria.FedTax)).And("StateTaxable".Equal(searchCriteria.StateTaxable)).And("IsBankQualified".Equal<bool>(searchCriteria.BankQualified)).And("DealTypeID".Equal<long>(searchCriteria.DealType)).And("MoodyRating".Equal(searchCriteria.MoodyLongTermRating)).And("SPRating".Equal(searchCriteria.SPLongTermRating)).And("KrollRating".Equal(searchCriteria.KrollLongTermRating)).And("FitchRating".Equal(searchCriteria.FitchLongTermRating)).And("LeadBankerId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "lead banker")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>()).Or("BankerId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "non lead banker")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("QuantId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "quant")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("SupervisoryPrincipalId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "supervisory principal")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>()))).And(criterion1);
      if (visitableCriterion2 == EmptyCriterion.Instance && !flag)
      {
        isBlankSearch = true;
        return (IDataReader) null;
      }
      IVisitableCriterion visitableCriterion3 = "Principal".AnyOf(((IEnumerable<int>) this.AppUser.GetEffectivePrincipalIds()).Select<int, string>((Func<int, string>) (x => x.ToString())).ToArray<string>()).And().And(visitableCriterion2);
      List<string> list = searchCriteria.SelectedFields.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Html.field)).ToList<string>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
        {
          KendoGridRequest.SortObject order = sortObject;
          if (searchCriteria.SelectedFields.Any<SearchResultField>((Func<SearchResultField, bool>) (x => x.Html.field == order.field && !x.IsMiscellaneous)))
            orderingList.Add(new Ordering()
            {
              PropertyName = order.field,
              Direction = order.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
            });
        }
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      List<OpportunitySearchResultViewModel> searchResultViewModelList = new List<OpportunitySearchResultViewModel>();
      return this.OpportunityRepository.Query(new QueryDefinition()
      {
        Criterion = visitableCriterion3,
        Order = orderingList.ToArray(),
        Projection = (IEnumerable<string>) list,
        SubQueryDefinitions = subQueryDefinitionList
      }, request.take, (int) request.skip);
    }

    private DataTable GetSearchResultsToExport(
      KendoGridRequest request,
      OpportunitySearchViewModel issueSearchCriteria,
      out long total,
      ref bool isBlankSearch,
      string timeZoneOffset)
    {
      IDataReader searchData = this.GetSearchData(request, issueSearchCriteria, out total, ref isBlankSearch, timeZoneOffset);
      DataTable dtblLeft = new DataTable();
      List<string> stringList = new List<string>();
      if (searchData != null)
      {
        dtblLeft.Load(searchData);
        DataTableReader dataReader = dtblLeft.CreateDataReader();
        while (dataReader.Read())
          stringList.Add(dataReader["AppTransactionID"].ToString());
        if (searchData.Read())
          total = (long) searchData.GetInt32(0);
      }
      string apptransactionIds = string.Join(",", stringList.ToArray());
      DataTable dtblRight = new DataTable();
      using (IDataReader reader = this.PropertySetValueRepository.FetchTransposedPropertySetValues(apptransactionIds))
      {
        Dictionary<string, object> dictionary = new Dictionary<string, object>();
        if (reader != null)
          dtblRight.Load(reader);
      }
      return OpportunityPresenter.JoinTwoDataTablesOnOneColumn(dtblLeft, dtblRight, "AppTransactionID", OpportunityPresenter.JoinType.Left);
    }

    public ExportResult ExportOpportunityPipeline(KendoGridRequest request)
    {
      try
      {
        List<OpportunityPipelineViewModel> opportunityPipeline = this.GetOpportunityPipeline();
        this.Log.Error(Modules.Opportunity, "ExportOpportunityPipeline-- Results Count: " + (object) opportunityPipeline.Count);
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType13<string, string, string, Decimal?, string, string, string, string, string, string, Decimal?, string, string, string, Decimal?, string, string, string, string, string, string, string, string, string, Decimal?, Decimal?, string, string, string, string>> datas = opportunityPipeline.Select(d =>
        {
          string borrower = d.Borrower;
          string issuer = d.Issuer;
          string opportunityName = d.OpportunityName;
          Decimal? size = d.Size;
          string purpose = d.Purpose;
          string transactionType = d.TransactionType;
          string bankQualified = d.BankQualified;
          string amtTaxable = d.AMTTaxable;
          string fedTaxable = d.FedTaxable;
          string statetaxable = d.Statetaxable;
          Decimal? nullable1 = this.ConvertToDecimal(d.ParAmount);
          string financialAdvisorName = d.FinancialAdvisorName;
          string insured = d.Insured;
          string expectedFirmRole = d.ExpectedFirmRole;
          Decimal? firmLiabilityPerc = d.ExpectedFirmLiabilityPerc;
          DateTime? nullable2;
          string str1;
          if (!d.ExpectedPricingDate.HasValue)
          {
            str1 = "";
          }
          else
          {
            nullable2 = d.ExpectedPricingDate;
            str1 = this.ConvertDateFormat(nullable2.ToString());
          }
          nullable2 = d.CloseDate;
          string str2;
          if (!nullable2.HasValue)
          {
            str2 = "";
          }
          else
          {
            nullable2 = d.CloseDate;
            str2 = this.ConvertDateFormat(nullable2.ToString());
          }
          string state = d.State;
          string leadBanker = d.LeadBanker;
          string analyst = d.Analyst;
          string bankRm = d.BankRM;
          nullable2 = d.DateHired;
          string str3;
          if (!nullable2.HasValue)
          {
            str3 = "";
          }
          else
          {
            nullable2 = d.DateHired;
            str3 = this.ConvertDateFormat(nullable2.ToString());
          }
          nullable2 = d.G17SentDate;
          string str4;
          if (!nullable2.HasValue)
          {
            str4 = "";
          }
          else
          {
            nullable2 = d.G17SentDate;
            str4 = this.ConvertDateFormat(nullable2.ToString());
          }
          nullable2 = d.G17AckDate;
          string str5;
          if (!nullable2.HasValue)
          {
            str5 = "";
          }
          else
          {
            nullable2 = d.G17AckDate;
            str5 = this.ConvertDateFormat(nullable2.ToString());
          }
          Decimal? grossSpread = d.GrossSpread;
          Decimal? estGrossRev = d.EstGrossRev;
          nullable2 = d.ClientLastContactedDate;
          string str6;
          if (!nullable2.HasValue)
          {
            str6 = "";
          }
          else
          {
            nullable2 = d.ClientLastContactedDate;
            str6 = this.ConvertDateFormat(nullable2.ToString());
          }
          string opportunityStatus = d.OpportunityStatus;
          string reviewStatus = d.ReviewStatus;
          string opportunityType = d.OpportunityType;
          return new
          {
            Borrower = borrower,
            Issuer = issuer,
            OpportunityName = opportunityName,
            Size = size,
            Purpose = purpose,
            TransactionType = transactionType,
            BankQualified = bankQualified,
            AMTTaxable = amtTaxable,
            FedTaxable = fedTaxable,
            StateTaxable = statetaxable,
            ParAmount = nullable1,
            FinancialAdvisorName = financialAdvisorName,
            Insured = insured,
            ExpectedFirmRole = expectedFirmRole,
            ExpectedFirmLiabilityPerc = firmLiabilityPerc,
            ExpectedPricingDate = str1,
            CloseDate = str2,
            State = state,
            LeadBanker = leadBanker,
            Analyst = analyst,
            BankRM = bankRm,
            DateHired = str3,
            DateG17Sent = str4,
            DateG17Ack = str5,
            GrossSpread = grossSpread,
            EstGrossRev = estGrossRev,
            ClientLastContacted = str6,
            OpportunityStatus = opportunityStatus,
            ReviewStatus = reviewStatus,
            OpportunityType = opportunityType
          };
        });
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Opportunity Pipeline", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".25cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        tabularReportBuilder.AddColumn("Borrower/Obligor", "Borrower", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Opportunity Description", "OpportunityName", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("State", "State", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Opportunity Status", "OpportunityStatus", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Review Status", "ReviewStatus", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Par Amount", "ParAmount", Unit.Parse("4cm"), "$#,##", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Expected Firm Role", "ExpectedFirmRole", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Lead Banker", "LeadBanker", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Expected Pricing Date", "ExpectedPricingDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Expected Delivery Date", "CloseDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Type of Opportunity", "OpportunityType", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        this.Log.Error(Modules.Opportunity, "ExportOpportunityPipeline-- added all columns in the builder");
        Report report = tabularReportBuilder.Build();
        this.Log.Error(Modules.Opportunity, "ExportOpportunityPipeline-- total items in the report:" + (object) ((IEnumerable<object>) report.Items).Count<object>());
        this.Log.Error(Modules.Opportunity, "ExportOpportunityPipeline-- Exporting the content to excel");
        ExportResult exportResult = new ReportExporter().Export(report, "excel", "OpportunityPipeline", (object) datas);
        this.Log.Error(Modules.Opportunity, "ExportOpportunityPipeline-- export successful!- exported file:" + exportResult.Filename + "mime type: " + exportResult.MimeType + "data length : " + (object) ((IEnumerable<byte>) exportResult.Data).Count<byte>());
        return exportResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return new ExportResult();
      }
    }

    private List<IrisSoftware.iMPACT.Data.Opportunity.Status> GetOpptyStatusListFromStatusIDList(
      List<long> lstOpptyStatusID)
    {
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> statusList = new List<IrisSoftware.iMPACT.Data.Opportunity.Status>();
      foreach (long num in lstOpptyStatusID)
        statusList.Add((IrisSoftware.iMPACT.Data.Opportunity.Status) num);
      return statusList;
    }

    private bool ValidateModel(OpportunityViewModel opptyViewModel, ref SaveResult saveResult)
    {
      long? nullable1 = opptyViewModel.FirmRole;
      long num1 = -12;
      Decimal? nullable2;
      if ((nullable1.GetValueOrDefault() == num1 ? (nullable1.HasValue ? 1 : 0) : 0) != 0)
      {
        nullable2 = opptyViewModel.FirmLiabilityPerc;
        Decimal num2 = (Decimal) 100;
        if ((nullable2.GetValueOrDefault() < num2 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
          saveResult.Errors.Add("Opportunity", (object) "Expected Firm Liability %  cannot be less than 100%.");
      }
      nullable2 = opptyViewModel.FirmLiabilityPerc;
      Decimal num3 = (Decimal) 100;
      if ((nullable2.GetValueOrDefault() > num3 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("Opportunity", (object) "Expected Firm Liability % value cannot be greater than 100%.");
      nullable2 = opptyViewModel.FirmMgmtFee;
      Decimal num4 = (Decimal) 100;
      if ((nullable2.GetValueOrDefault() > num4 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("Opportunity-FirmMgmtFee", (object) "Expected Firm Mgmt Fee % value cannot be greater than 100%.");
      nullable1 = opptyViewModel.AssignedFirmRole;
      long num5 = -12;
      if ((nullable1.GetValueOrDefault() == num5 ? (nullable1.HasValue ? 1 : 0) : 0) != 0)
      {
        nullable2 = opptyViewModel.AssignedFirmLiability;
        Decimal num2 = (Decimal) 100;
        if ((nullable2.GetValueOrDefault() < num2 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
          saveResult.Errors.Add("Opportunity", (object) "Assigned Firm Liability %  cannot be less than 100%.");
      }
      nullable2 = opptyViewModel.AssignedFirmLiability;
      Decimal num6 = (Decimal) 100;
      if ((nullable2.GetValueOrDefault() > num6 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("Opportunity", (object) "Assigned Firm Liability % value cannot be greater than 100%.");
      nullable2 = opptyViewModel.SDCCreditPerc;
      Decimal num7 = (Decimal) 100;
      if ((nullable2.GetValueOrDefault() > num7 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("Opportunity", (object) "SDC Credit % value cannot be greater than 100%.");
      return saveResult.IsSuccessful;
    }

    private List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> GetTransitionFromToState1(
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> oldStatusList,
      TransitionResult<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transitionResult)
    {
      List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> fromStateToStateList = new List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState>();
      IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> actionState = transitionResult.ActionState;
      IEnumerable<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>> intermediateStates = transitionResult.IntermediateStates;
      IEnumerable<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>> resultingStates = transitionResult.ResultingStates;
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> first = new List<IrisSoftware.iMPACT.Data.Opportunity.Status>();
      foreach (IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> state in resultingStates)
        first.Add(state.Key);
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> list = oldStatusList.Except<IrisSoftware.iMPACT.Data.Opportunity.Status>((IEnumerable<IrisSoftware.iMPACT.Data.Opportunity.Status>) first).ToList<IrisSoftware.iMPACT.Data.Opportunity.Status>();
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> filteredToState = first.Except<IrisSoftware.iMPACT.Data.Opportunity.Status>((IEnumerable<IrisSoftware.iMPACT.Data.Opportunity.Status>) oldStatusList).ToList<IrisSoftware.iMPACT.Data.Opportunity.Status>();
      if (intermediateStates.Count<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>>() > 0)
        list.Remove(actionState.Key);
      foreach (IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> state in intermediateStates)
      {
        fromStateToStateList.Add(new IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState(new IrisSoftware.iMPACT.Data.Opportunity.Status?(actionState.Key), state.Key));
        list.Add(state.Key);
      }
      foreach (KeyValuePair<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status> keyValuePair in list.SelectMany<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status, KeyValuePair<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status>>((Func<IrisSoftware.iMPACT.Data.Opportunity.Status, IEnumerable<IrisSoftware.iMPACT.Data.Opportunity.Status>>) (fromStatus => (IEnumerable<IrisSoftware.iMPACT.Data.Opportunity.Status>) filteredToState), (Func<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status, KeyValuePair<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status>>) ((fromStatus, toStatus) => new KeyValuePair<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity.Status>(fromStatus, toStatus))))
        fromStateToStateList.Add(new IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState(new IrisSoftware.iMPACT.Data.Opportunity.Status?(keyValuePair.Key), keyValuePair.Value));
      return fromStateToStateList;
    }

    private List<int> GetTransitionStateTracking(
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> oldStatusList,
      TransitionResult<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transitionResult)
    {
      List<int> intList = new List<int>();
      IEnumerable<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>> resultingStates = transitionResult.ResultingStates;
      IEnumerable<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>> intermediateStates = transitionResult.IntermediateStates;
      if (intermediateStates != null && intermediateStates.Count<IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>>() > 0)
      {
        IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> actionState = transitionResult.ActionState;
        foreach (IrisSoftware.iMPACT.Data.Opportunity.Status oldStatus in oldStatusList)
        {
          if (oldStatus != actionState.Key)
            intList.Add((int) oldStatus);
        }
        foreach (IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> state in intermediateStates)
          intList.Add((int) state.Key);
      }
      else
      {
        foreach (IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> state in resultingStates)
          intList.Add((int) state.Key);
      }
      return intList;
    }

    private List<SearchResultField> GetAllSearchResultFields()
    {
      List<SearchResultField> searchResultFieldList1 = new List<SearchResultField>();
      int num1 = 1;
      List<SearchResultField> searchResultFieldList2 = searchResultFieldList1;
      SearchResultField searchResultField1 = new SearchResultField();
      searchResultField1.Name = "Opportunity Number";
      searchResultField1.ExportField = "OpportunityNbr";
      int num2 = num1;
      int num3 = num2 + 1;
      searchResultField1.Order = num2;
      searchResultField1.Html = new SearchResultFieldHtml()
      {
        field = "OpportunityNbr",
        title = "Opportunity Number",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "4cm"
      };
      searchResultFieldList2.Add(searchResultField1);
      List<SearchResultField> searchResultFieldList3 = searchResultFieldList1;
      SearchResultField searchResultField2 = new SearchResultField();
      searchResultField2.Name = "Opportunity Description";
      searchResultField2.ExportField = "OpportunityName";
      int num4 = num3;
      int num5 = num4 + 1;
      searchResultField2.Order = num4;
      searchResultField2.IsMandatory = true;
      searchResultField2.Html = new SearchResultFieldHtml()
      {
        field = "OpportunityName",
        title = "Opportunity Description",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "6cm",
        template = "<a href='Opportunity.aspx?AppId=#= AppTransactionID #' target='_blank'>#= OpportunityName #</a>"
      };
      searchResultFieldList3.Add(searchResultField2);
      List<SearchResultField> searchResultFieldList4 = searchResultFieldList1;
      SearchResultField searchResultField3 = new SearchResultField();
      searchResultField3.Name = "Opportunity Status";
      searchResultField3.ExportField = "OpportunityStatus";
      int num6 = num5;
      int num7 = num6 + 1;
      searchResultField3.Order = num6;
      searchResultField3.Html = new SearchResultFieldHtml()
      {
        field = "OpportunityStatus",
        title = "Opportunity Status",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList4.Add(searchResultField3);
      List<SearchResultField> searchResultFieldList5 = searchResultFieldList1;
      SearchResultField searchResultField4 = new SearchResultField();
      searchResultField4.Name = "Review Status";
      searchResultField4.ExportField = "ReviewStatus";
      int num8 = num7;
      int num9 = num8 + 1;
      searchResultField4.Order = num8;
      searchResultField4.Html = new SearchResultFieldHtml()
      {
        field = "ReviewStatus",
        title = "Review Status",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "6cm"
      };
      searchResultFieldList5.Add(searchResultField4);
      List<SearchResultField> searchResultFieldList6 = searchResultFieldList1;
      SearchResultField searchResultField5 = new SearchResultField();
      searchResultField5.Name = "State";
      searchResultField5.ExportField = "State";
      int num10 = num9;
      int num11 = num10 + 1;
      searchResultField5.Order = num10;
      searchResultField5.Html = new SearchResultFieldHtml()
      {
        field = "State",
        title = "State",
        sortable = true,
        isLeftAligned = true,
        width = "50px",
        excelWidth = "2cm"
      };
      searchResultFieldList6.Add(searchResultField5);
      List<SearchResultField> searchResultFieldList7 = searchResultFieldList1;
      SearchResultField searchResultField6 = new SearchResultField();
      searchResultField6.Name = "Issuer";
      searchResultField6.ExportField = "Issuer";
      int num12 = num11;
      int num13 = num12 + 1;
      searchResultField6.Order = num12;
      searchResultField6.IsMandatory = true;
      searchResultField6.Html = new SearchResultFieldHtml()
      {
        field = "Issuer",
        title = "Issuer",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList7.Add(searchResultField6);
      List<SearchResultField> searchResultFieldList8 = searchResultFieldList1;
      SearchResultField searchResultField7 = new SearchResultField();
      searchResultField7.Name = "Borrower/Obligor";
      searchResultField7.ExportField = "Borrower";
      int num14 = num13;
      int num15 = num14 + 1;
      searchResultField7.Order = num14;
      searchResultField7.Html = new SearchResultFieldHtml()
      {
        field = "Borrower",
        title = "Borrower/Obligor",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList8.Add(searchResultField7);
      List<SearchResultField> searchResultFieldList9 = searchResultFieldList1;
      SearchResultField searchResultField8 = new SearchResultField();
      searchResultField8.Name = "Guarantor";
      searchResultField8.ExportField = "Guarantor";
      int num16 = num15;
      int num17 = num16 + 1;
      searchResultField8.Order = num16;
      searchResultField8.Html = new SearchResultFieldHtml()
      {
        field = "Guarantor",
        title = "Guarantor",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList9.Add(searchResultField8);
      List<SearchResultField> searchResultFieldList10 = searchResultFieldList1;
      SearchResultField searchResultField9 = new SearchResultField();
      searchResultField9.Name = "Type of Opportunity ";
      searchResultField9.ExportField = "OpportunityType";
      int num18 = num17;
      int num19 = num18 + 1;
      searchResultField9.Order = num18;
      searchResultField9.Html = new SearchResultFieldHtml()
      {
        field = "OpportunityType",
        title = "Type of Opportunity ",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "4cm"
      };
      searchResultFieldList10.Add(searchResultField9);
      List<SearchResultField> searchResultFieldList11 = searchResultFieldList1;
      SearchResultField searchResultField10 = new SearchResultField();
      searchResultField10.Name = "Par Amount";
      searchResultField10.ExportField = "ParAmount";
      int num20 = num19;
      int num21 = num20 + 1;
      searchResultField10.Order = num20;
      searchResultField10.Html = new SearchResultFieldHtml()
      {
        field = "ParAmount",
        title = "Par Amount",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c0}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0"
      };
      searchResultFieldList11.Add(searchResultField10);
      List<SearchResultField> searchResultFieldList12 = searchResultFieldList1;
      SearchResultField searchResultField11 = new SearchResultField();
      searchResultField11.Name = "MS Banking Group";
      searchResultField11.ExportField = "Market";
      int num22 = num21;
      int num23 = num22 + 1;
      searchResultField11.Order = num22;
      searchResultField11.Html = new SearchResultFieldHtml()
      {
        field = "Market",
        title = "MS Banking Group",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList12.Add(searchResultField11);
      List<SearchResultField> searchResultFieldList13 = searchResultFieldList1;
      SearchResultField searchResultField12 = new SearchResultField();
      searchResultField12.Name = "Deal Type";
      searchResultField12.ExportField = "DealType";
      int num24 = num23;
      int num25 = num24 + 1;
      searchResultField12.Order = num24;
      searchResultField12.Html = new SearchResultFieldHtml()
      {
        field = "DealType",
        title = "Deal Type",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2cm"
      };
      searchResultFieldList13.Add(searchResultField12);
      List<SearchResultField> searchResultFieldList14 = searchResultFieldList1;
      SearchResultField searchResultField13 = new SearchResultField();
      searchResultField13.Name = "Bank Qualified";
      searchResultField13.ExportField = "BankQualified";
      int num26 = num25;
      int num27 = num26 + 1;
      searchResultField13.Order = num26;
      searchResultField13.Html = new SearchResultFieldHtml()
      {
        field = "BankQualified",
        title = "Bank Qualified",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2cm"
      };
      searchResultFieldList14.Add(searchResultField13);
      List<SearchResultField> searchResultFieldList15 = searchResultFieldList1;
      SearchResultField searchResultField14 = new SearchResultField();
      searchResultField14.Name = "Bond Counsel";
      searchResultField14.ExportField = "BondCounsel";
      int num28 = num27;
      int num29 = num28 + 1;
      searchResultField14.Order = num28;
      searchResultField14.Html = new SearchResultFieldHtml()
      {
        field = "BondCounsel",
        title = "Bond Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList15.Add(searchResultField14);
      List<SearchResultField> searchResultFieldList16 = searchResultFieldList1;
      SearchResultField searchResultField15 = new SearchResultField();
      searchResultField15.Name = "Borrower's Counsel";
      searchResultField15.ExportField = "BorrowerCounsel";
      int num30 = num29;
      int num31 = num30 + 1;
      searchResultField15.Order = num30;
      searchResultField15.Html = new SearchResultFieldHtml()
      {
        field = "BorrowerCounsel",
        title = "Borrower's Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList16.Add(searchResultField15);
      List<SearchResultField> searchResultFieldList17 = searchResultFieldList1;
      SearchResultField searchResultField16 = new SearchResultField();
      searchResultField16.Name = "Co-Manager";
      searchResultField16.ExportField = "CoManager";
      int num32 = num31;
      int num33 = num32 + 1;
      searchResultField16.Order = num32;
      searchResultField16.Html = new SearchResultFieldHtml()
      {
        field = "CoManager",
        title = "Co-Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList17.Add(searchResultField16);
      List<SearchResultField> searchResultFieldList18 = searchResultFieldList1;
      SearchResultField searchResultField17 = new SearchResultField();
      searchResultField17.Name = "Co Senior Mgr";
      searchResultField17.ExportField = "CoSeniorMgr";
      int num34 = num33;
      int num35 = num34 + 1;
      searchResultField17.Order = num34;
      searchResultField17.Html = new SearchResultFieldHtml()
      {
        field = "CoSeniorMgr",
        title = "Co Senior Mgr",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList18.Add(searchResultField17);
      List<SearchResultField> searchResultFieldList19 = searchResultFieldList1;
      SearchResultField searchResultField18 = new SearchResultField();
      searchResultField18.Name = "Create Date";
      searchResultField18.ExportField = "=Format(fields!CreatedOn.Value, \"MM/dd/yyyy\")";
      searchResultField18.ExportColumns = new string[1]
      {
        "CreatedOn"
      };
      searchResultField18.IsTimezoneReq = true;
      SearchResultField searchResultField19 = searchResultField18;
      int num36 = num35;
      int num37 = num36 + 1;
      searchResultField19.Order = num36;
      searchResultField18.Html = new SearchResultFieldHtml()
      {
        field = "CreateDate",
        title = "Create Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertSearchDateToLocalDateOnly(CreateDate) #",
        groupHeaderTemplate = "#= convertSearchDateToLocalDateOnly(value) #"
      };
      SearchResultField searchResultField20 = searchResultField18;
      searchResultFieldList19.Add(searchResultField20);
      List<SearchResultField> searchResultFieldList20 = searchResultFieldList1;
      SearchResultField searchResultField21 = new SearchResultField();
      searchResultField21.Name = "Opportunity Setup By";
      searchResultField21.ExportField = "CreatedBy";
      int num38 = num37;
      int num39 = num38 + 1;
      searchResultField21.Order = num38;
      searchResultField21.Html = new SearchResultFieldHtml()
      {
        field = "CreatedBy",
        title = "Opportunity Setup By",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3.2cm"
      };
      searchResultFieldList20.Add(searchResultField21);
      List<SearchResultField> searchResultFieldList21 = searchResultFieldList1;
      SearchResultField searchResultField22 = new SearchResultField();
      searchResultField22.Name = "Disclosure Counsel";
      searchResultField22.ExportField = "DisclosureCounsel";
      int num40 = num39;
      int num41 = num40 + 1;
      searchResultField22.Order = num40;
      searchResultField22.Html = new SearchResultFieldHtml()
      {
        field = "DisclosureCounsel",
        title = "Disclosure Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList21.Add(searchResultField22);
      List<SearchResultField> searchResultFieldList22 = searchResultFieldList1;
      SearchResultField searchResultField23 = new SearchResultField();
      searchResultField23.Name = "Escrow Agent For Refunded Bonds";
      searchResultField23.ExportField = "EscrowAgentForRefundedBonds";
      int num42 = num41;
      int num43 = num42 + 1;
      searchResultField23.Order = num42;
      searchResultField23.Html = new SearchResultFieldHtml()
      {
        field = "EscrowAgentForRefundedBonds",
        title = "Escrow Agent for Refunded Bonds",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList22.Add(searchResultField23);
      List<SearchResultField> searchResultFieldList23 = searchResultFieldList1;
      SearchResultField searchResultField24 = new SearchResultField();
      searchResultField24.Name = "Escrow Securities Provider";
      searchResultField24.ExportField = "EscrowSecuritiesProvider";
      int num44 = num43;
      int num45 = num44 + 1;
      searchResultField24.Order = num44;
      searchResultField24.Html = new SearchResultFieldHtml()
      {
        field = "EscrowSecuritiesProvider",
        title = "Escrow Securities Provider",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList23.Add(searchResultField24);
      List<SearchResultField> searchResultFieldList24 = searchResultFieldList1;
      SearchResultField searchResultField25 = new SearchResultField();
      searchResultField25.Name = "Escrow Verification Agent";
      searchResultField25.ExportField = "EscrowVerificationAgent";
      int num46 = num45;
      int num47 = num46 + 1;
      searchResultField25.Order = num46;
      searchResultField25.Html = new SearchResultFieldHtml()
      {
        field = "EscrowVerificationAgent",
        title = "Escrow Verification Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList24.Add(searchResultField25);
      List<SearchResultField> searchResultFieldList25 = searchResultFieldList1;
      SearchResultField searchResultField26 = new SearchResultField();
      searchResultField26.Name = "Estimated Revenue";
      searchResultField26.ExportField = "EstGrossRev";
      int num48 = num47;
      int num49 = num48 + 1;
      searchResultField26.Order = num48;
      searchResultField26.Html = new SearchResultFieldHtml()
      {
        field = "EstGrossRev",
        title = "Estimated Revenue",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList25.Add(searchResultField26);
      List<SearchResultField> searchResultFieldList26 = searchResultFieldList1;
      SearchResultField searchResultField27 = new SearchResultField();
      searchResultField27.Name = "Expected Delivery Date";
      searchResultField27.ExportField = "=Format(fields!CloseDate.Value, \"MM/dd/yyyy\")";
      searchResultField27.ExportColumns = new string[1]
      {
        "CloseDate"
      };
      SearchResultField searchResultField28 = searchResultField27;
      int num50 = num49;
      int num51 = num50 + 1;
      searchResultField28.Order = num50;
      searchResultField27.Html = new SearchResultFieldHtml()
      {
        field = "CloseDate",
        title = "Expected Delivery Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(CloseDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField29 = searchResultField27;
      searchResultFieldList26.Add(searchResultField29);
      List<SearchResultField> searchResultFieldList27 = searchResultFieldList1;
      SearchResultField searchResultField30 = new SearchResultField();
      searchResultField30.Name = "Expected Firm Liability %";
      searchResultField30.ExportField = "ExpectedFirmLiabilityPerc";
      int num52 = num51;
      int num53 = num52 + 1;
      searchResultField30.Order = num52;
      searchResultField30.Html = new SearchResultFieldHtml()
      {
        field = "ExpectedFirmLiabilityPerc",
        title = "Expected Firm Liability %",
        sortable = true,
        isLeftAligned = false,
        width = "120px",
        excelWidth = "3.9cm",
        format = "{0:n3}",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList27.Add(searchResultField30);
      List<SearchResultField> searchResultFieldList28 = searchResultFieldList1;
      SearchResultField searchResultField31 = new SearchResultField();
      searchResultField31.Name = "Expected Firm Mgmt Fee %";
      searchResultField31.ExportField = "FirmMgmtFee";
      int num54 = num53;
      int num55 = num54 + 1;
      searchResultField31.Order = num54;
      searchResultField31.Html = new SearchResultFieldHtml()
      {
        field = "FirmMgmtFee",
        title = "Expected Firm Mgmt Fee %",
        sortable = true,
        isLeftAligned = false,
        width = "120px",
        excelWidth = "3.9cm",
        format = "{0:n3}",
        style = "text-align: right !important;",
        excelFormat = "#,#0.000"
      };
      searchResultFieldList28.Add(searchResultField31);
      List<SearchResultField> searchResultFieldList29 = searchResultFieldList1;
      SearchResultField searchResultField32 = new SearchResultField();
      searchResultField32.Name = "Expected Firm Role";
      searchResultField32.ExportField = "ExpectedFirmRole";
      int num56 = num55;
      int num57 = num56 + 1;
      searchResultField32.Order = num56;
      searchResultField32.Html = new SearchResultFieldHtml()
      {
        field = "ExpectedFirmRole",
        title = "Expected Firm Role",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList29.Add(searchResultField32);
      List<SearchResultField> searchResultFieldList30 = searchResultFieldList1;
      SearchResultField searchResultField33 = new SearchResultField();
      searchResultField33.Name = "Firm Role";
      searchResultField33.ExportField = "AssignedFirmRole";
      int num58 = num57;
      int num59 = num58 + 1;
      searchResultField33.Order = num58;
      searchResultField33.Html = new SearchResultFieldHtml()
      {
        field = "AssignedFirmRole",
        title = "Firm Role",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList30.Add(searchResultField33);
      List<SearchResultField> searchResultFieldList31 = searchResultFieldList1;
      SearchResultField searchResultField34 = new SearchResultField();
      searchResultField34.Name = "Fed Tax";
      searchResultField34.ExportField = "FedTaxName";
      int num60 = num59;
      int num61 = num60 + 1;
      searchResultField34.Order = num60;
      searchResultField34.Html = new SearchResultFieldHtml()
      {
        field = "FedTaxName",
        title = "Fed Tax",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm"
      };
      searchResultFieldList31.Add(searchResultField34);
      List<SearchResultField> searchResultFieldList32 = searchResultFieldList1;
      SearchResultField searchResultField35 = new SearchResultField();
      searchResultField35.Name = "Financial Advisor";
      searchResultField35.ExportField = "FinancialAdvisor";
      int num62 = num61;
      int num63 = num62 + 1;
      searchResultField35.Order = num62;
      searchResultField35.Html = new SearchResultFieldHtml()
      {
        field = "FinancialAdvisor",
        title = "Financial Advisor",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList32.Add(searchResultField35);
      List<SearchResultField> searchResultFieldList33 = searchResultFieldList1;
      SearchResultField searchResultField36 = new SearchResultField();
      searchResultField36.Name = "G-17 Conflict Letter";
      searchResultField36.ExportField = "G17ConflictLetter";
      int num64 = num63;
      int num65 = num64 + 1;
      searchResultField36.Order = num64;
      searchResultField36.Html = new SearchResultFieldHtml()
      {
        field = "G17ConflictLetter",
        title = "G-17 Conflict Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList33.Add(searchResultField36);
      List<SearchResultField> searchResultFieldList34 = searchResultFieldList1;
      SearchResultField searchResultField37 = new SearchResultField();
      searchResultField37.Name = "G-17 Conflict Letter Ack Date";
      searchResultField37.ExportField = "=Format(fields!G17ConflictLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField37.ExportColumns = new string[1]
      {
        "G17ConflictLetterAckDate"
      };
      SearchResultField searchResultField38 = searchResultField37;
      int num66 = num65;
      int num67 = num66 + 1;
      searchResultField38.Order = num66;
      searchResultField37.Html = new SearchResultFieldHtml()
      {
        field = "G17ConflictLetterAckDate",
        title = "G-17 Conflict Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17ConflictLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField39 = searchResultField37;
      searchResultFieldList34.Add(searchResultField39);
      List<SearchResultField> searchResultFieldList35 = searchResultFieldList1;
      SearchResultField searchResultField40 = new SearchResultField();
      searchResultField40.Name = "G-17 Conflict Letter Sent Date";
      searchResultField40.ExportField = "=Format(fields!G17ConflictLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField40.ExportColumns = new string[1]
      {
        "G17ConflictLetterSentDate"
      };
      SearchResultField searchResultField41 = searchResultField40;
      int num68 = num67;
      int num69 = num68 + 1;
      searchResultField41.Order = num68;
      searchResultField40.Html = new SearchResultFieldHtml()
      {
        field = "G17ConflictLetterSentDate",
        title = "G-17 Conflict Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17ConflictLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField42 = searchResultField40;
      searchResultFieldList35.Add(searchResultField42);
      List<SearchResultField> searchResultFieldList36 = searchResultFieldList1;
      SearchResultField searchResultField43 = new SearchResultField();
      searchResultField43.Name = "G-17 Role & Conflict Letter";
      searchResultField43.ExportField = "G17RoleDisclosureLetter";
      int num70 = num69;
      int num71 = num70 + 1;
      searchResultField43.Order = num70;
      searchResultField43.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleDisclosureLetter",
        title = "G-17 Role & Conflict Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList36.Add(searchResultField43);
      List<SearchResultField> searchResultFieldList37 = searchResultFieldList1;
      SearchResultField searchResultField44 = new SearchResultField();
      searchResultField44.Name = "G-17 Role & Conflict Letter Ack Date";
      searchResultField44.ExportField = "=Format(fields!G17RoleDisclosureLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField44.ExportColumns = new string[1]
      {
        "G17RoleDisclosureLetterAckDate"
      };
      SearchResultField searchResultField45 = searchResultField44;
      int num72 = num71;
      int num73 = num72 + 1;
      searchResultField45.Order = num72;
      searchResultField44.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleDisclosureLetterAckDate",
        title = "G-17 Role & Conflict Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleDisclosureLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField46 = searchResultField44;
      searchResultFieldList37.Add(searchResultField46);
      List<SearchResultField> searchResultFieldList38 = searchResultFieldList1;
      SearchResultField searchResultField47 = new SearchResultField();
      searchResultField47.Name = "G-17 Role & Conflict Letter Sent Date";
      searchResultField47.ExportField = "=Format(fields!G17RoleDisclosureLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField47.ExportColumns = new string[1]
      {
        "G17RoleDisclosureLetterSentDate"
      };
      SearchResultField searchResultField48 = searchResultField47;
      int num74 = num73;
      int num75 = num74 + 1;
      searchResultField48.Order = num74;
      searchResultField47.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleDisclosureLetterSentDate",
        title = "G-17 Role & Conflict Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleDisclosureLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField49 = searchResultField47;
      searchResultFieldList38.Add(searchResultField49);
      List<SearchResultField> searchResultFieldList39 = searchResultFieldList1;
      SearchResultField searchResultField50 = new SearchResultField();
      searchResultField50.Name = "G-17 Role Letter";
      searchResultField50.ExportField = "G17RoleLetter";
      int num76 = num75;
      int num77 = num76 + 1;
      searchResultField50.Order = num76;
      searchResultField50.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleLetter",
        title = "G-17 Role Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList39.Add(searchResultField50);
      List<SearchResultField> searchResultFieldList40 = searchResultFieldList1;
      SearchResultField searchResultField51 = new SearchResultField();
      searchResultField51.Name = "G-17 Role Letter Ack Date";
      searchResultField51.ExportField = "=Format(fields!G17RoleLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField51.ExportColumns = new string[1]
      {
        "G17RoleLetterAckDate"
      };
      SearchResultField searchResultField52 = searchResultField51;
      int num78 = num77;
      int num79 = num78 + 1;
      searchResultField52.Order = num78;
      searchResultField51.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleLetterAckDate",
        title = "G-17 Role Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField53 = searchResultField51;
      searchResultFieldList40.Add(searchResultField53);
      List<SearchResultField> searchResultFieldList41 = searchResultFieldList1;
      SearchResultField searchResultField54 = new SearchResultField();
      searchResultField54.Name = "G-17 Role Letter Sent Date";
      searchResultField54.ExportField = "=Format(fields!G17RoleLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField54.ExportColumns = new string[1]
      {
        "G17RoleLetterSentDate"
      };
      SearchResultField searchResultField55 = searchResultField54;
      int num80 = num79;
      int num81 = num80 + 1;
      searchResultField55.Order = num80;
      searchResultField54.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleLetterSentDate",
        title = "G-17 Role Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField56 = searchResultField54;
      searchResultFieldList41.Add(searchResultField56);
      List<SearchResultField> searchResultFieldList42 = searchResultFieldList1;
      SearchResultField searchResultField57 = new SearchResultField();
      searchResultField57.Name = "G-17 Structure Letter";
      searchResultField57.ExportField = "G17StructureLetter";
      int num82 = num81;
      int num83 = num82 + 1;
      searchResultField57.Order = num82;
      searchResultField57.Html = new SearchResultFieldHtml()
      {
        field = "G17StructureLetter",
        title = "G-17 Structure Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList42.Add(searchResultField57);
      List<SearchResultField> searchResultFieldList43 = searchResultFieldList1;
      SearchResultField searchResultField58 = new SearchResultField();
      searchResultField58.Name = "G-17 Structure Letter Ack Date";
      searchResultField58.ExportField = "=Format(fields!G17StructureLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField58.ExportColumns = new string[1]
      {
        "G17StructureLetterAckDate"
      };
      SearchResultField searchResultField59 = searchResultField58;
      int num84 = num83;
      int num85 = num84 + 1;
      searchResultField59.Order = num84;
      searchResultField58.Html = new SearchResultFieldHtml()
      {
        field = "G17StructureLetterAckDate",
        title = "G-17 Structure Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17StructureLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField60 = searchResultField58;
      searchResultFieldList43.Add(searchResultField60);
      List<SearchResultField> searchResultFieldList44 = searchResultFieldList1;
      SearchResultField searchResultField61 = new SearchResultField();
      searchResultField61.Name = "G-17 Structure Letter Sent Date";
      searchResultField61.ExportField = "=Format(fields!G17StructureLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField61.ExportColumns = new string[1]
      {
        "G17StructureLetterSentDate"
      };
      SearchResultField searchResultField62 = searchResultField61;
      int num86 = num85;
      int num87 = num86 + 1;
      searchResultField62.Order = num86;
      searchResultField61.Html = new SearchResultFieldHtml()
      {
        field = "G17StructureLetterSentDate",
        title = "G-17 Structure Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17StructureLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField63 = searchResultField61;
      searchResultFieldList44.Add(searchResultField63);
      List<SearchResultField> searchResultFieldList45 = searchResultFieldList1;
      SearchResultField searchResultField64 = new SearchResultField();
      searchResultField64.Name = "Proposed Gross Spread ($/1,000)";
      searchResultField64.ExportField = "GrossSpread";
      int num88 = num87;
      int num89 = num88 + 1;
      searchResultField64.Order = num88;
      searchResultField64.Html = new SearchResultFieldHtml()
      {
        field = "GrossSpread",
        title = "Proposed  Gross Spread ($/1,000)",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c3}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.000"
      };
      searchResultFieldList45.Add(searchResultField64);
      List<SearchResultField> searchResultFieldList46 = searchResultFieldList1;
      SearchResultField searchResultField65 = new SearchResultField();
      searchResultField65.Name = "IRMA MA Exemption";
      searchResultField65.ExportField = "IRMAMAExemption";
      int num90 = num89;
      int num91 = num90 + 1;
      searchResultField65.Order = num90;
      searchResultField65.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemption",
        title = "IRMA MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList46.Add(searchResultField65);
      List<SearchResultField> searchResultFieldList47 = searchResultFieldList1;
      SearchResultField searchResultField66 = new SearchResultField();
      searchResultField66.Name = "IRMA MA Exemption Start Date";
      searchResultField66.ExportField = "=Format(fields!IRMAMAExemptionDate.Value, \"MM/dd/yyyy\")";
      searchResultField66.ExportColumns = new string[1]
      {
        "IRMAMAExemptionDate"
      };
      SearchResultField searchResultField67 = searchResultField66;
      int num92 = num91;
      int num93 = num92 + 1;
      searchResultField67.Order = num92;
      searchResultField66.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemptionDate",
        title = "IRMA MA Exemption Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(IRMAMAExemptionDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField68 = searchResultField66;
      searchResultFieldList47.Add(searchResultField68);
      List<SearchResultField> searchResultFieldList48 = searchResultFieldList1;
      SearchResultField searchResultField69 = new SearchResultField();
      searchResultField69.Name = "IRMA MA Exemption Expiry Date";
      searchResultField69.ExportField = "=Format(fields!IRMAMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField69.ExportColumns = new string[1]
      {
        "IRMAMAExemptionExpirationDate"
      };
      SearchResultField searchResultField70 = searchResultField69;
      int num94 = num93;
      int num95 = num94 + 1;
      searchResultField70.Order = num94;
      searchResultField69.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemptionExpirationDate",
        title = "IRMA MA Exemption Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(IRMAMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField71 = searchResultField69;
      searchResultFieldList48.Add(searchResultField71);
      List<SearchResultField> searchResultFieldList49 = searchResultFieldList1;
      SearchResultField searchResultField72 = new SearchResultField();
      searchResultField72.Name = "Issuer's Counsel";
      searchResultField72.ExportField = "IssuerCounsel";
      int num96 = num95;
      int num97 = num96 + 1;
      searchResultField72.Order = num96;
      searchResultField72.Html = new SearchResultFieldHtml()
      {
        field = "IssuerCounsel",
        title = "Issuer's Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList49.Add(searchResultField72);
      List<SearchResultField> searchResultFieldList50 = searchResultFieldList1;
      SearchResultField searchResultField73 = new SearchResultField();
      searchResultField73.Name = "Joint Senior Mgr - Book Running";
      searchResultField73.ExportField = "JointSeniorMgrBookRunning";
      int num98 = num97;
      int num99 = num98 + 1;
      searchResultField73.Order = num98;
      searchResultField73.Html = new SearchResultFieldHtml()
      {
        field = "JointSeniorMgrBookRunning",
        title = "Joint Senior Mgr - Book Running",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList50.Add(searchResultField73);
      List<SearchResultField> searchResultFieldList51 = searchResultFieldList1;
      SearchResultField searchResultField74 = new SearchResultField();
      searchResultField74.Name = "Joint Senior Mgr - Non Book Running";
      searchResultField74.ExportField = "JointSeniorMgrNonBookRunning";
      int num100 = num99;
      int num101 = num100 + 1;
      searchResultField74.Order = num100;
      searchResultField74.Html = new SearchResultFieldHtml()
      {
        field = "JointSeniorMgrNonBookRunning",
        title = "Joint Senior Mgr - Non Book Running",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList51.Add(searchResultField74);
      List<SearchResultField> searchResultFieldList52 = searchResultFieldList1;
      SearchResultField searchResultField75 = new SearchResultField();
      searchResultField75.Name = "Lead Banker";
      searchResultField75.ExportField = "LeadBanker";
      int num102 = num101;
      int num103 = num102 + 1;
      searchResultField75.Order = num102;
      searchResultField75.Html = new SearchResultFieldHtml()
      {
        field = "LeadBanker",
        title = "Lead Banker",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList52.Add(searchResultField75);
      List<SearchResultField> searchResultFieldList53 = searchResultFieldList1;
      SearchResultField searchResultField76 = new SearchResultField();
      searchResultField76.Name = "Non Lead Banker";
      searchResultField76.ExportField = "Banker";
      int num104 = num103;
      int num105 = num104 + 1;
      searchResultField76.Order = num104;
      searchResultField76.Html = new SearchResultFieldHtml()
      {
        field = "Banker",
        title = "Non Lead Banker",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList53.Add(searchResultField76);
      List<SearchResultField> searchResultFieldList54 = searchResultFieldList1;
      SearchResultField searchResultField77 = new SearchResultField();
      searchResultField77.Name = "None MA Exemption";
      searchResultField77.ExportField = "NoneMAExemption";
      int num106 = num105;
      int num107 = num106 + 1;
      searchResultField77.Order = num106;
      searchResultField77.Html = new SearchResultFieldHtml()
      {
        field = "NoneMAExemption",
        title = "None MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList54.Add(searchResultField77);
      List<SearchResultField> searchResultFieldList55 = searchResultFieldList1;
      SearchResultField searchResultField78 = new SearchResultField();
      searchResultField78.Name = "None MA Exemption Start Date";
      searchResultField78.ExportField = "=Format(fields!NoneMAExemptionStartDate.Value, \"MM/dd/yyyy\")";
      searchResultField78.ExportColumns = new string[1]
      {
        "NoneMAExemptionStartDate"
      };
      SearchResultField searchResultField79 = searchResultField78;
      int num108 = num107;
      int num109 = num108 + 1;
      searchResultField79.Order = num108;
      searchResultField78.Html = new SearchResultFieldHtml()
      {
        field = "NoneMAExemptionStartDate",
        title = "None MA Exemption Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(NoneMAExemptionStartDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField80 = searchResultField78;
      searchResultFieldList55.Add(searchResultField80);
      List<SearchResultField> searchResultFieldList56 = searchResultFieldList1;
      SearchResultField searchResultField81 = new SearchResultField();
      searchResultField81.Name = "None MA Exemption Expiry Date";
      searchResultField81.ExportField = "=Format(fields!NoneMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField81.ExportColumns = new string[1]
      {
        "NoneMAExemptionExpirationDate"
      };
      SearchResultField searchResultField82 = searchResultField81;
      int num110 = num109;
      int num111 = num110 + 1;
      searchResultField82.Order = num110;
      searchResultField81.Html = new SearchResultFieldHtml()
      {
        field = "NoneMAExemptionExpirationDate",
        title = "None MA Exemption Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(NoneMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField83 = searchResultField81;
      searchResultFieldList56.Add(searchResultField83);
      List<SearchResultField> searchResultFieldList57 = searchResultFieldList1;
      SearchResultField searchResultField84 = new SearchResultField();
      searchResultField84.Name = "Other Advisor Agents";
      searchResultField84.ExportField = "OtherAdvisorAgents";
      int num112 = num111;
      int num113 = num112 + 1;
      searchResultField84.Order = num112;
      searchResultField84.Html = new SearchResultFieldHtml()
      {
        field = "OtherAdvisorAgents",
        title = "Other Advisor Agents",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList57.Add(searchResultField84);
      List<SearchResultField> searchResultFieldList58 = searchResultFieldList1;
      SearchResultField searchResultField85 = new SearchResultField();
      searchResultField85.Name = "Other Counsels";
      searchResultField85.ExportField = "OtherCounsels";
      int num114 = num113;
      int num115 = num114 + 1;
      searchResultField85.Order = num114;
      searchResultField85.Html = new SearchResultFieldHtml()
      {
        field = "OtherCounsels",
        title = "Other Counsels",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList58.Add(searchResultField85);
      List<SearchResultField> searchResultFieldList59 = searchResultFieldList1;
      SearchResultField searchResultField86 = new SearchResultField();
      searchResultField86.Name = "Other Syndicate Members";
      searchResultField86.ExportField = "OtherSyndicateMembers";
      int num116 = num115;
      int num117 = num116 + 1;
      searchResultField86.Order = num116;
      searchResultField86.Html = new SearchResultFieldHtml()
      {
        field = "OtherSyndicateMembers",
        title = "Other Syndicate Members",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList59.Add(searchResultField86);
      List<SearchResultField> searchResultFieldList60 = searchResultFieldList1;
      SearchResultField searchResultField87 = new SearchResultField();
      searchResultField87.Name = "Other Winning Syndicate Members";
      searchResultField87.ExportField = "OtherWinningSyndicateMembers";
      int num118 = num117;
      int num119 = num118 + 1;
      searchResultField87.Order = num118;
      searchResultField87.Html = new SearchResultFieldHtml()
      {
        field = "OtherWinningSyndicateMembers",
        title = "Other Winning Syndicate Members",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList60.Add(searchResultField87);
      List<SearchResultField> searchResultFieldList61 = searchResultFieldList1;
      SearchResultField searchResultField88 = new SearchResultField();
      searchResultField88.Name = "Paying Agent";
      searchResultField88.ExportField = "PayingAgent";
      int num120 = num119;
      int num121 = num120 + 1;
      searchResultField88.Order = num120;
      searchResultField88.Html = new SearchResultFieldHtml()
      {
        field = "PayingAgent",
        title = "Paying Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList61.Add(searchResultField88);
      List<SearchResultField> searchResultFieldList62 = searchResultFieldList1;
      SearchResultField searchResultField89 = new SearchResultField();
      searchResultField89.Name = "Quant";
      searchResultField89.ExportField = "Quant";
      int num122 = num121;
      int num123 = num122 + 1;
      searchResultField89.Order = num122;
      searchResultField89.Html = new SearchResultFieldHtml()
      {
        field = "Quant",
        title = "Quant",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList62.Add(searchResultField89);
      List<SearchResultField> searchResultFieldList63 = searchResultFieldList1;
      SearchResultField searchResultField90 = new SearchResultField();
      searchResultField90.Name = "Ratings - Fitch";
      searchResultField90.ExportField = "FitchRating";
      int num124 = num123;
      int num125 = num124 + 1;
      searchResultField90.Order = num124;
      searchResultField90.Html = new SearchResultFieldHtml()
      {
        field = "FitchRating",
        title = "Ratings - Fitch",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList63.Add(searchResultField90);
      List<SearchResultField> searchResultFieldList64 = searchResultFieldList1;
      SearchResultField searchResultField91 = new SearchResultField();
      searchResultField91.Name = "Ratings - Kroll";
      searchResultField91.ExportField = "KrollRating";
      int num126 = num125;
      int num127 = num126 + 1;
      searchResultField91.Order = num126;
      searchResultField91.Html = new SearchResultFieldHtml()
      {
        field = "KrollRating",
        title = "Ratings - Kroll",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList64.Add(searchResultField91);
      List<SearchResultField> searchResultFieldList65 = searchResultFieldList1;
      SearchResultField searchResultField92 = new SearchResultField();
      searchResultField92.Name = "Ratings - Moody's";
      searchResultField92.ExportField = "MoodyRating";
      int num128 = num127;
      int num129 = num128 + 1;
      searchResultField92.Order = num128;
      searchResultField92.Html = new SearchResultFieldHtml()
      {
        field = "MoodyRating",
        title = "Ratings - Moody's",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList65.Add(searchResultField92);
      List<SearchResultField> searchResultFieldList66 = searchResultFieldList1;
      SearchResultField searchResultField93 = new SearchResultField();
      searchResultField93.Name = "Ratings - S&P";
      searchResultField93.ExportField = "SPRating";
      int num130 = num129;
      int num131 = num130 + 1;
      searchResultField93.Order = num130;
      searchResultField93.Html = new SearchResultFieldHtml()
      {
        field = "SPRating",
        title = "Ratings - S&P",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList66.Add(searchResultField93);
      List<SearchResultField> searchResultFieldList67 = searchResultFieldList1;
      SearchResultField searchResultField94 = new SearchResultField();
      searchResultField94.Name = "Expected Pricing Date";
      searchResultField94.ExportField = "=Format(fields!ExpectedPricingDate.Value, \"MM/dd/yyyy\")";
      searchResultField94.ExportColumns = new string[1]
      {
        "ExpectedPricingDate"
      };
      SearchResultField searchResultField95 = searchResultField94;
      int num132 = num131;
      int num133 = num132 + 1;
      searchResultField95.Order = num132;
      searchResultField94.Html = new SearchResultFieldHtml()
      {
        field = "ExpectedPricingDate",
        title = "Expected Pricing Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(ExpectedPricingDate)#",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField96 = searchResultField94;
      searchResultFieldList67.Add(searchResultField96);
      List<SearchResultField> searchResultFieldList68 = searchResultFieldList1;
      SearchResultField searchResultField97 = new SearchResultField();
      searchResultField97.Name = "Remarketing Agent";
      searchResultField97.ExportField = "RemarketingAgent";
      int num134 = num133;
      int num135 = num134 + 1;
      searchResultField97.Order = num134;
      searchResultField97.Html = new SearchResultFieldHtml()
      {
        field = "RemarketingAgent",
        title = "Remarketing Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList68.Add(searchResultField97);
      List<SearchResultField> searchResultFieldList69 = searchResultFieldList1;
      SearchResultField searchResultField98 = new SearchResultField();
      searchResultField98.Name = "Response Due Date & Time";
      searchResultField98.ExportField = "=Format(fields!ResponseDueDate.Value, \"MM/dd/yyyy hh:mm tt\") & IIF(Len(fields!ResponseDueDateTimezone.Value)=0, \"\",\" (\") & fields!ResponseDueDateTimezone.Value & IIF(Len(fields!ResponseDueDateTimezone.Value)=0, \"\",\")\")";
      searchResultField98.ExportColumns = new string[2]
      {
        "ResponseDueDate",
        "ResponseDueDateTimezone"
      };
      SearchResultField searchResultField99 = searchResultField98;
      int num136 = num135;
      int num137 = num136 + 1;
      searchResultField99.Order = num136;
      searchResultField98.Html = new SearchResultFieldHtml()
      {
        field = "ResponseDueDate",
        title = "Response Due Date & Time",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToStringDateTime(ResponseDueDate,ResponseDueDateTimezone) #",
        groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
      };
      SearchResultField searchResultField100 = searchResultField98;
      searchResultFieldList69.Add(searchResultField100);
      List<SearchResultField> searchResultFieldList70 = searchResultFieldList1;
      SearchResultField searchResultField101 = new SearchResultField();
      searchResultField101.Name = "Proposed Average Takedown ($/1,000)";
      searchResultField101.ExportField = "RFPFees";
      int num138 = num137;
      int num139 = num138 + 1;
      searchResultField101.Order = num138;
      searchResultField101.Html = new SearchResultFieldHtml()
      {
        field = "RFPFees",
        title = "Proposed Average Takedown ($/1,000)",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c3}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.000"
      };
      searchResultFieldList70.Add(searchResultField101);
      List<SearchResultField> searchResultFieldList71 = searchResultFieldList1;
      SearchResultField searchResultField102 = new SearchResultField();
      searchResultField102.Name = "Proposed Underwriter's Expenses ($/1,000)";
      searchResultField102.ExportField = "ProposedUnderwriterExpenses";
      int num140 = num139;
      int num141 = num140 + 1;
      searchResultField102.Order = num140;
      searchResultField102.Html = new SearchResultFieldHtml()
      {
        field = "ProposedUnderwriterExpenses",
        title = "Proposed Underwriter's Expenses ($/1,000)",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c3}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.000"
      };
      searchResultFieldList71.Add(searchResultField102);
      List<SearchResultField> searchResultFieldList72 = searchResultFieldList1;
      SearchResultField searchResultField103 = new SearchResultField();
      searchResultField103.Name = "Proposed Management Fee ($/1,000)";
      searchResultField103.ExportField = "ProposedManagementFee";
      int num142 = num141;
      int num143 = num142 + 1;
      searchResultField103.Order = num142;
      searchResultField103.Html = new SearchResultFieldHtml()
      {
        field = "ProposedManagementFee",
        title = "Proposed Management Fee ($/1,000)",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c3}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.000"
      };
      searchResultFieldList72.Add(searchResultField103);
      List<SearchResultField> searchResultFieldList73 = searchResultFieldList1;
      SearchResultField searchResultField104 = new SearchResultField();
      searchResultField104.Name = "RFP MA Exemption";
      searchResultField104.ExportField = "RFPMAExemption";
      int num144 = num143;
      int num145 = num144 + 1;
      searchResultField104.Order = num144;
      searchResultField104.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemption",
        title = "RFP MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList73.Add(searchResultField104);
      List<SearchResultField> searchResultFieldList74 = searchResultFieldList1;
      SearchResultField searchResultField105 = new SearchResultField();
      searchResultField105.Name = "RFP MA Exemption Start Date";
      searchResultField105.ExportField = "=Format(fields!RFPMAExemptionDate.Value, \"MM/dd/yyyy\")";
      searchResultField105.ExportColumns = new string[1]
      {
        "RFPMAExemptionDate"
      };
      SearchResultField searchResultField106 = searchResultField105;
      int num146 = num145;
      int num147 = num146 + 1;
      searchResultField106.Order = num146;
      searchResultField105.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemptionDate",
        title = "RFP MA Exemption Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(RFPMAExemptionDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField107 = searchResultField105;
      searchResultFieldList74.Add(searchResultField107);
      List<SearchResultField> searchResultFieldList75 = searchResultFieldList1;
      SearchResultField searchResultField108 = new SearchResultField();
      searchResultField108.Name = "RFP MA Exemption Expiry Date";
      searchResultField108.ExportField = "=Format(fields!RFPMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField108.ExportColumns = new string[1]
      {
        "RFPMAExemptionExpirationDate"
      };
      SearchResultField searchResultField109 = searchResultField108;
      int num148 = num147;
      int num149 = num148 + 1;
      searchResultField109.Order = num148;
      searchResultField108.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemptionExpirationDate",
        title = "RFP MA Exemption Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(RFPMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField110 = searchResultField108;
      searchResultFieldList75.Add(searchResultField110);
      List<SearchResultField> searchResultFieldList76 = searchResultFieldList1;
      SearchResultField searchResultField111 = new SearchResultField();
      searchResultField111.Name = "Security Type (General)";
      searchResultField111.ExportField = "SecurityType";
      int num150 = num149;
      int num151 = num150 + 1;
      searchResultField111.Order = num150;
      searchResultField111.Html = new SearchResultFieldHtml()
      {
        field = "SecurityType",
        title = "Security Type (General)",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList76.Add(searchResultField111);
      List<SearchResultField> searchResultFieldList77 = searchResultFieldList1;
      SearchResultField searchResultField112 = new SearchResultField();
      searchResultField112.Name = "Selling Group Member";
      searchResultField112.ExportField = "SellingGroupMember";
      int num152 = num151;
      int num153 = num152 + 1;
      searchResultField112.Order = num152;
      searchResultField112.Html = new SearchResultFieldHtml()
      {
        field = "SellingGroupMember",
        title = "Selling Group Member",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList77.Add(searchResultField112);
      List<SearchResultField> searchResultFieldList78 = searchResultFieldList1;
      SearchResultField searchResultField113 = new SearchResultField();
      searchResultField113.Name = "Senior Manager";
      searchResultField113.ExportField = "SeniorManager";
      int num154 = num153;
      int num155 = num154 + 1;
      searchResultField113.Order = num154;
      searchResultField113.Html = new SearchResultFieldHtml()
      {
        field = "SeniorManager",
        title = "Senior Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList78.Add(searchResultField113);
      List<SearchResultField> searchResultFieldList79 = searchResultFieldList1;
      SearchResultField searchResultField114 = new SearchResultField();
      searchResultField114.Name = "Sole Manager";
      searchResultField114.ExportField = "SoleManager";
      int num156 = num155;
      int num157 = num156 + 1;
      searchResultField114.Order = num156;
      searchResultField114.Html = new SearchResultFieldHtml()
      {
        field = "SoleManager",
        title = "Sole Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList79.Add(searchResultField114);
      List<SearchResultField> searchResultFieldList80 = searchResultFieldList1;
      SearchResultField searchResultField115 = new SearchResultField();
      searchResultField115.Name = "State Taxable";
      searchResultField115.ExportField = "StateTaxable";
      int num158 = num157;
      int num159 = num158 + 1;
      searchResultField115.Order = num158;
      searchResultField115.Html = new SearchResultFieldHtml()
      {
        field = "StateTaxable",
        title = "State Taxable",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm"
      };
      searchResultFieldList80.Add(searchResultField115);
      List<SearchResultField> searchResultFieldList81 = searchResultFieldList1;
      SearchResultField searchResultField116 = new SearchResultField();
      searchResultField116.Name = "Supervisory Principal";
      searchResultField116.ExportField = "SupervisoryPrincipal";
      int num160 = num159;
      int num161 = num160 + 1;
      searchResultField116.Order = num160;
      searchResultField116.Html = new SearchResultFieldHtml()
      {
        field = "SupervisoryPrincipal",
        title = "Supervisory Principal",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList81.Add(searchResultField116);
      List<SearchResultField> searchResultFieldList82 = searchResultFieldList1;
      SearchResultField searchResultField117 = new SearchResultField();
      searchResultField117.Name = "Trustee";
      searchResultField117.ExportField = "Trustee";
      int num162 = num161;
      int num163 = num162 + 1;
      searchResultField117.Order = num162;
      searchResultField117.Html = new SearchResultFieldHtml()
      {
        field = "Trustee",
        title = "Trustee",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList82.Add(searchResultField117);
      List<SearchResultField> searchResultFieldList83 = searchResultFieldList1;
      SearchResultField searchResultField118 = new SearchResultField();
      searchResultField118.Name = "Underwriter's Counsel";
      searchResultField118.ExportField = "UnderwriterCounsel";
      int num164 = num163;
      int num165 = num164 + 1;
      searchResultField118.Order = num164;
      searchResultField118.Html = new SearchResultFieldHtml()
      {
        field = "UnderwriterCounsel",
        title = "Underwriter's Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList83.Add(searchResultField118);
      List<SearchResultField> searchResultFieldList84 = searchResultFieldList1;
      SearchResultField searchResultField119 = new SearchResultField();
      searchResultField119.Name = "Use of Proceeds";
      searchResultField119.ExportField = "TransactionType";
      int num166 = num165;
      int num167 = num166 + 1;
      searchResultField119.Order = num166;
      searchResultField119.Html = new SearchResultFieldHtml()
      {
        field = "TransactionType",
        title = "Use of Proceeds",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList84.Add(searchResultField119);
      List<SearchResultField> searchResultFieldList85 = searchResultFieldList1;
      SearchResultField searchResultField120 = new SearchResultField();
      searchResultField120.Name = "UW MA Exemption";
      searchResultField120.ExportField = "UWMAExemption";
      int num168 = num167;
      int num169 = num168 + 1;
      searchResultField120.Order = num168;
      searchResultField120.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemption",
        title = "UW MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList85.Add(searchResultField120);
      List<SearchResultField> searchResultFieldList86 = searchResultFieldList1;
      SearchResultField searchResultField121 = new SearchResultField();
      searchResultField121.Name = "UW MA Exemption Start Date";
      searchResultField121.ExportField = "=Format(fields!UWMAExemptionDate.Value, \"MM/dd/yyyy\")";
      searchResultField121.ExportColumns = new string[1]
      {
        "UWMAExemptionDate"
      };
      SearchResultField searchResultField122 = searchResultField121;
      int num170 = num169;
      int num171 = num170 + 1;
      searchResultField122.Order = num170;
      searchResultField121.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemptionDate",
        title = "UW MA Exemption Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(UWMAExemptionDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField123 = searchResultField121;
      searchResultFieldList86.Add(searchResultField123);
      List<SearchResultField> searchResultFieldList87 = searchResultFieldList1;
      SearchResultField searchResultField124 = new SearchResultField();
      searchResultField124.Name = "UW MA Exemption Expiry Date";
      searchResultField124.ExportField = "=Format(fields!UWMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField124.ExportColumns = new string[1]
      {
        "UWMAExemptionExpirationDate"
      };
      SearchResultField searchResultField125 = searchResultField124;
      int num172 = num171;
      int num173 = num172 + 1;
      searchResultField125.Order = num172;
      searchResultField124.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemptionExpirationDate",
        title = "UW MA Exemption Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(UWMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField126 = searchResultField124;
      searchResultFieldList87.Add(searchResultField126);
      List<SearchResultField> searchResultFieldList88 = searchResultFieldList1;
      SearchResultField searchResultField127 = new SearchResultField();
      searchResultField127.Name = "Winning Co-Manager";
      searchResultField127.ExportField = "WinningCoManager";
      int num174 = num173;
      int num175 = num174 + 1;
      searchResultField127.Order = num174;
      searchResultField127.Html = new SearchResultFieldHtml()
      {
        field = "WinningCoManager",
        title = "Winning Co-Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList88.Add(searchResultField127);
      List<SearchResultField> searchResultFieldList89 = searchResultFieldList1;
      SearchResultField searchResultField128 = new SearchResultField();
      searchResultField128.Name = "Winning Co-Senior Mgr";
      searchResultField128.ExportField = "WinningCoSeniorMgr";
      int num176 = num175;
      int num177 = num176 + 1;
      searchResultField128.Order = num176;
      searchResultField128.Html = new SearchResultFieldHtml()
      {
        field = "WinningCoSeniorMgr",
        title = "Winning Co-Senior Mgr",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList89.Add(searchResultField128);
      List<SearchResultField> searchResultFieldList90 = searchResultFieldList1;
      SearchResultField searchResultField129 = new SearchResultField();
      searchResultField129.Name = "Winning Joint Senior Mgr Book Running";
      searchResultField129.ExportField = "WinningJointSeniorMgrBookRunning";
      int num178 = num177;
      int num179 = num178 + 1;
      searchResultField129.Order = num178;
      searchResultField129.Html = new SearchResultFieldHtml()
      {
        field = "WinningJointSeniorMgrBookRunning",
        title = "Winning Joint Senior Mgr Book Running",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList90.Add(searchResultField129);
      List<SearchResultField> searchResultFieldList91 = searchResultFieldList1;
      SearchResultField searchResultField130 = new SearchResultField();
      searchResultField130.Name = "Winning Joint Senior Mgr Non Book Running";
      searchResultField130.ExportField = "WinningJointSeniorMgrNonBookRunning";
      int num180 = num179;
      int num181 = num180 + 1;
      searchResultField130.Order = num180;
      searchResultField130.Html = new SearchResultFieldHtml()
      {
        field = "WinningJointSeniorMgrNonBookRunning",
        title = "Winning Joint Senior Mgr Non Book Running",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList91.Add(searchResultField130);
      List<SearchResultField> searchResultFieldList92 = searchResultFieldList1;
      SearchResultField searchResultField131 = new SearchResultField();
      searchResultField131.Name = "Winning Selling Group Member";
      searchResultField131.ExportField = "WinningSellingGroupMember";
      int num182 = num181;
      int num183 = num182 + 1;
      searchResultField131.Order = num182;
      searchResultField131.Html = new SearchResultFieldHtml()
      {
        field = "WinningSellingGroupMember",
        title = "Winning Selling Group Member",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList92.Add(searchResultField131);
      List<SearchResultField> searchResultFieldList93 = searchResultFieldList1;
      SearchResultField searchResultField132 = new SearchResultField();
      searchResultField132.Name = "Winning Senior Manager";
      searchResultField132.ExportField = "WinningSeniorManager";
      int num184 = num183;
      int num185 = num184 + 1;
      searchResultField132.Order = num184;
      searchResultField132.Html = new SearchResultFieldHtml()
      {
        field = "WinningSeniorManager",
        title = "Winning Senior Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList93.Add(searchResultField132);
      List<SearchResultField> searchResultFieldList94 = searchResultFieldList1;
      SearchResultField searchResultField133 = new SearchResultField();
      searchResultField133.Name = "Winning Sole Manager";
      searchResultField133.ExportField = "WinningSoleManager";
      int num186 = num185;
      int num187 = num186 + 1;
      searchResultField133.Order = num186;
      searchResultField133.Html = new SearchResultFieldHtml()
      {
        field = "WinningSoleManager",
        title = "Winning Sole Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList94.Add(searchResultField133);
      List<SearchResultField> searchResultFieldList95 = searchResultFieldList1;
      SearchResultField searchResultField134 = new SearchResultField();
      searchResultField134.Name = "Winning Syndicate Notes";
      searchResultField134.ExportField = "Notes";
      int num188 = num187;
      int num189 = num188 + 1;
      searchResultField134.Order = num188;
      searchResultField134.Html = new SearchResultFieldHtml()
      {
        field = "Notes",
        title = "Winning Syndicate Notes",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList95.Add(searchResultField134);
      List<SearchResultField> searchResultFieldList96 = searchResultFieldList1;
      SearchResultField searchResultField135 = new SearchResultField();
      searchResultField135.Name = "Opportunity Lead Manager";
      searchResultField135.ExportField = "OpportunityLeadManager";
      int num190 = num189;
      int num191 = num190 + 1;
      searchResultField135.Order = num190;
      searchResultField135.Html = new SearchResultFieldHtml()
      {
        field = "OpportunityLeadManager",
        title = "Opportunity Lead Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList96.Add(searchResultField135);
      List<SearchResultField> searchResultFieldList97 = searchResultFieldList1;
      SearchResultField searchResultField136 = new SearchResultField();
      searchResultField136.Name = "Opportunity Non-Lead Manager";
      searchResultField136.ExportField = "OpportunityNonLeadManager";
      int num192 = num191;
      int num193 = num192 + 1;
      searchResultField136.Order = num192;
      searchResultField136.Html = new SearchResultFieldHtml()
      {
        field = "OpportunityNonLeadManager",
        title = "Opportunity Non-Lead Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList97.Add(searchResultField136);
      List<SearchResultField> searchResultFieldList98 = searchResultFieldList1;
      SearchResultField searchResultField137 = new SearchResultField();
      searchResultField137.Name = "Credit Enhancement Provider";
      searchResultField137.ExportField = "CepProviderName";
      int num194 = num193;
      int num195 = num194 + 1;
      searchResultField137.Order = num194;
      searchResultField137.Html = new SearchResultFieldHtml()
      {
        field = "CepProviderName",
        title = "Credit Enhancement Provider",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList98.Add(searchResultField137);
      List<SearchResultField> searchResultFieldList99 = searchResultFieldList1;
      SearchResultField searchResultField138 = new SearchResultField();
      searchResultField138.Name = "RFP Type";
      searchResultField138.ExportField = "RFPType";
      int num196 = num195;
      int num197 = num196 + 1;
      searchResultField138.Order = num196;
      searchResultField138.Html = new SearchResultFieldHtml()
      {
        field = "RFPType",
        title = "RFP Type",
        sortable = true,
        isLeftAligned = true,
        width = "130px",
        excelWidth = "3cm"
      };
      searchResultFieldList99.Add(searchResultField138);
      List<SearchResultField> searchResultFieldList100 = searchResultFieldList1;
      SearchResultField searchResultField139 = new SearchResultField();
      searchResultField139.Name = "Additional RFP Details";
      searchResultField139.ExportField = "AdditionalRFPDetails";
      int num198 = num197;
      int num199 = num198 + 1;
      searchResultField139.Order = num198;
      searchResultField139.Html = new SearchResultFieldHtml()
      {
        field = "AdditionalRFPDetails",
        title = "Additional RFP Details",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList100.Add(searchResultField139);
      List<SearchResultField> searchResultFieldList101 = searchResultFieldList1;
      SearchResultField searchResultField140 = new SearchResultField();
      searchResultField140.Name = "SDC Credit %";
      searchResultField140.ExportField = "SDCCreditPerc";
      int num200 = num199;
      int num201 = num200 + 1;
      searchResultField140.Order = num200;
      searchResultField140.Html = new SearchResultFieldHtml()
      {
        field = "SDCCreditPerc",
        title = "SDC Credit %",
        sortable = true,
        isLeftAligned = false,
        width = "120px",
        excelWidth = "2.3cm",
        format = "{0:n3}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.000"
      };
      searchResultFieldList101.Add(searchResultField140);
      List<SearchResultField> searchResultFieldList102 = searchResultFieldList1;
      SearchResultField searchResultField141 = new SearchResultField();
      searchResultField141.Name = "Interest Rate Type";
      searchResultField141.ExportField = "RateType";
      int num202 = num201;
      int num203 = num202 + 1;
      searchResultField141.Order = num202;
      searchResultField141.Html = new SearchResultFieldHtml()
      {
        field = "RateType",
        title = "Interest Rate Type",
        sortable = true,
        isLeftAligned = true,
        width = "130px",
        excelWidth = "3cm"
      };
      searchResultFieldList102.Add(searchResultField141);
      List<SearchResultField> searchResultFieldList103 = searchResultFieldList1;
      SearchResultField searchResultField142 = new SearchResultField();
      searchResultField142.Name = "Additional Information for Commitment Committee";
      searchResultField142.ExportField = "AdditionalInformationforCommitmentCommittee";
      int num204 = num203;
      int num205 = num204 + 1;
      searchResultField142.Order = num204;
      searchResultField142.Html = new SearchResultFieldHtml()
      {
        field = "AdditionalInformationforCommitmentCommittee",
        title = "Additional Information for Commitment Committee",
        sortable = true,
        isLeftAligned = true,
        width = "250px",
        excelWidth = "6cm"
      };
      searchResultFieldList103.Add(searchResultField142);
      List<PropertyDescriptor> propertyDescriptorList = new List<PropertyDescriptor>();
      foreach (PropertyDescriptor propertyDescriptor in (IEnumerable<PropertyDescriptor>) this.PropertyDescriptorRepository.FetchPropertyDescriptorsByEntity(-33L).ToList<PropertyDescriptor>())
      {
        string dataType = propertyDescriptor.DataType;
        if (!(dataType == "Decimal"))
        {
          if (!(dataType == "Date"))
          {
            if (dataType == "DateTime")
            {
              OpportunityPresenter.dateColumnsToAdjust.Add(propertyDescriptor.Key);
              searchResultFieldList1.Add(new SearchResultField()
              {
                Name = "#" + propertyDescriptor.Caption,
                ExportField = "=Format(fields!" + propertyDescriptor.Key + ".Value, \"MM/dd/yyyy hh:mm tt\")",
                ExportColumns = new string[1]
                {
                  propertyDescriptor.Key
                },
                Order = num205++,
                IsMiscellaneous = true,
                Html = new SearchResultFieldHtml()
                {
                  field = propertyDescriptor.Key,
                  title = propertyDescriptor.Caption,
                  sortable = true,
                  isLeftAligned = true,
                  width = "200px",
                  excelWidth = "5cm",
                  excelFormat = "{M/dd/yyyy}",
                  template = "#= convertDateToStringDateTime(" + propertyDescriptor.Key + ", '', '" + true.ToString() + "') #",
                  groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
                }
              });
            }
            else
              searchResultFieldList1.Add(new SearchResultField()
              {
                Name = "#" + propertyDescriptor.Caption,
                ExportField = propertyDescriptor.Key,
                Order = num205++,
                IsMiscellaneous = true,
                Html = new SearchResultFieldHtml()
                {
                  field = propertyDescriptor.Key,
                  title = propertyDescriptor.Caption,
                  sortable = true,
                  isLeftAligned = true,
                  width = "200px",
                  excelWidth = "5cm"
                }
              });
          }
          else
          {
            OpportunityPresenter.dateColumnsToAdjust.Add(propertyDescriptor.Key);
            searchResultFieldList1.Add(new SearchResultField()
            {
              Name = "#" + propertyDescriptor.Caption,
              ExportField = "=Format(fields!" + propertyDescriptor.Key + ".Value, \"MM/dd/yyyy\")",
              ExportColumns = new string[1]
              {
                propertyDescriptor.Key
              },
              Order = num205++,
              IsMiscellaneous = true,
              Html = new SearchResultFieldHtml()
              {
                field = propertyDescriptor.Key,
                title = propertyDescriptor.Caption,
                sortable = true,
                isLeftAligned = true,
                width = "120px",
                excelWidth = "3cm",
                excelFormat = "{M/dd/yyyy}",
                template = "#= convertDateToString(" + propertyDescriptor.Key + ", '', '" + true.ToString() + "') #",
                groupHeaderTemplate = "#= convertDateToString(value) #"
              }
            });
          }
        }
        else
          searchResultFieldList1.Add(new SearchResultField()
          {
            Name = "#" + propertyDescriptor.Caption,
            ExportField = propertyDescriptor.Key,
            IsMiscellaneous = true,
            Order = num205++,
            Html = new SearchResultFieldHtml()
            {
              field = propertyDescriptor.Key,
              title = propertyDescriptor.Caption,
              sortable = true,
              isLeftAligned = false,
              width = "200px",
              excelWidth = "5cm",
              format = propertyDescriptor.Format == "2 Decimal" ? "{0:n2}" : (propertyDescriptor.Format == "3 Decimal" ? "{0:n3}" : (propertyDescriptor.Format == "4 Decimal" ? "{0:n4}" : "{0:n}")),
              style = "text-align: right !important;",
              excelFormat = propertyDescriptor.Format == "2 Decimal" ? "#,##0.00" : (propertyDescriptor.Format == "3 Decimal" ? "#,##0.000" : (propertyDescriptor.Format == "4 Decimal" ? "#,##0.0000" : "#,##0.00"))
            }
          });
      }
      return searchResultFieldList1;
    }

    public List<AuditTrailViewModel> GetUpdateAuditTrails(
      long AppTrasanctionID)
    {
      return this.AuditTrailRepository.FetchByAppTransactionID(AppTrasanctionID).Select<AuditTrail, AuditTrailViewModel>((Func<AuditTrail, AuditTrailViewModel>) (x => new AuditTrailViewModel(x))).ToList<AuditTrailViewModel>();
    }

    public OpportunityContactDetailViewModel GetUpdateOpportunityContacts(
      long AppTransactionID)
    {
      return new OpportunityContactDetailViewModel(new IrisSoftware.iMPACT.Data.Opportunity()
      {
        OpportunityContact = this.OpportunityRepository.FetchOpportunityContact(AppTransactionID)
      });
    }

    public EmailTemplateDetailViewModel PrepareInfoEmail(
      long appTransID,
      int emailTemplateID)
    {
      try
      {
        IrisSoftware.iMPACT.Data.Opportunity opportunity = this.OpportunityRepository.FetchByID(appTransID);
        this.GetInternalPartnersEmailAddress(opportunity, out this.partnersEmailAddress);
        IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.FetchByKey(emailTemplateID);
        if (emailTemplate.EmailTemplateID != 0)
          emailTemplate.To = this.SetAppGroupRecipients(emailTemplate.To, appTransID);
        emailTemplate.Cc = this.SetAppGroupRecipients(emailTemplate.Cc, appTransID);
        emailTemplate.Subject = this.ResolvePlaceholders(emailTemplate.Subject, opportunity);
        emailTemplate.Body = this.ResolvePlaceholders(emailTemplate.Body, opportunity);
        emailTemplate.To = this.SetRecipients(emailTemplate.To);
        emailTemplate.Cc = this.SetRecipients(emailTemplate.Cc);
        return new EmailTemplateDetailViewModel(emailTemplate);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        EmailTemplateDetailViewModel templateDetailViewModel = new EmailTemplateDetailViewModel();
        templateDetailViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return templateDetailViewModel;
      }
    }

    private string SetAppGroupRecipients(string email, long AppTransactionID)
    {
      if (!string.IsNullOrEmpty(email))
      {
        StringBuilder stringBuilder1 = new StringBuilder();
        if (email.Contains("[COMPLIANCE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(3.ToString());
        }
        if (email.Contains("[LEGAL]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(18.ToString());
        }
        if (email.Contains("[MERG]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(19.ToString());
        }
        if (email.Contains("[COMMITMENTCOMMITTEE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(31.ToString());
        }
        if (email.Contains("[MANAGEMENT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(29.ToString());
        }
        if (email.Contains("[JOB-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(37.ToString());
        }
        if (email.Contains("[FIRMCREDIT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(34.ToString());
        }
        if (email.Contains("[OPERATIONS]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(6.ToString());
        }
        if (email.Contains("[PNL-APPROVER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(35.ToString());
        }
        if (email.Contains("[PNL-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(39.ToString());
        }
        if (email.Contains("[FINANCE-CONTROLLER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(36.ToString());
        }
        if (stringBuilder1.Length > 0)
        {
          StringBuilder stringBuilder2 = new StringBuilder();
          foreach (string str in this.EmailTemplateRepository.FetchEmailByRoleID(AppTransactionID, stringBuilder1.ToString()))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append(";");
            stringBuilder2.Append(str);
          }
          StringBuilder emailUpdated = new StringBuilder();
          foreach (string adr in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
          {
            switch (adr.ToUpper().Trim())
            {
              case "[COMMITMENTCOMMITTEE]":
              case "[COMPLIANCE]":
              case "[FINANCE-CONTROLLER]":
              case "[FIRMCREDIT]":
              case "[JOB-ADMINISTRATOR]":
              case "[LEGAL]":
              case "[MANAGEMENT]":
              case "[MERG]":
              case "[OPERATIONS]":
              case "[PNL-ADMINISTRATOR]":
              case "[PNL-APPROVER]":
                continue;
              default:
                this.ApplyDelimiter(emailUpdated, adr);
                continue;
            }
          }
          emailUpdated.Append(";" + (object) stringBuilder2);
          return emailUpdated.ToString();
        }
      }
      return email;
    }

    private string GetReviewComment(IrisSoftware.iMPACT.Data.Opportunity Opp)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (Opp.ReviewCommentsCollection != null && Opp.ReviewCommentsCollection.Any<ReviewComments>())
      {
        if (Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewComment != null)
          stringBuilder.Append(Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewComment);
        stringBuilder.Append(" (");
        if (Opp.ReviewCommentsCollection.First<ReviewComments>().UserName != null)
          stringBuilder.Append(Opp.ReviewCommentsCollection.First<ReviewComments>().UserName);
        stringBuilder.Append("; ");
        DateTime? reviewCommentDateTime = Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewCommentDateTime;
        if (reviewCommentDateTime.HasValue)
        {
          reviewCommentDateTime = Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewCommentDateTime;
          DateTime localTime = DateTime.SpecifyKind(reviewCommentDateTime.Value, DateTimeKind.Utc).ToLocalTime();
          stringBuilder.Append(localTime.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/'));
        }
        stringBuilder.Append(")");
      }
      return stringBuilder.ToString();
    }

    private string ResolvePlaceholders(string body, IrisSoftware.iMPACT.Data.Opportunity opportunity)
    {
      string str1 = HttpContext.Current.Request.UrlReferrer.AbsoluteUri;
      if (str1.ToUpper().Contains("?CAPPID"))
        str1 = HttpContext.Current.Request.UrlReferrer.AbsoluteUri.Split('?')[0] + "?AppID=" + (object) opportunity.OpportunityDetail.AppTransactionID;
      else if (!str1.ToUpper().Contains("APPID"))
        str1 = str1 + "?AppID=" + (object) opportunity.OpportunityDetail.AppTransactionID;
      string str2 = body.Replace("[OPPORTUNITY-DESCRIPTION]", opportunity.OpportunityDetail.OpportunityName).Replace("[OPPORTUNITY-DESCRIPTION-WITH-LINK]", "<a href='" + str1 + "'>" + opportunity.OpportunityDetail.OpportunityName + "</a>").Replace("[ISSUER-NAME]", opportunity.OpportunityDetail.IssuerName).Replace("[ISSUER-NAME-WITH-LINK]", "<a href='" + str1 + "'>" + opportunity.OpportunityDetail.IssuerName + "</a>");
      Decimal? nullable1;
      string newValue1;
      if (!opportunity.OpportunityDetail.ParAmount.HasValue)
      {
        newValue1 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.ParAmount;
        newValue1 = string.Format("{0:C0}", (object) nullable1.Value);
      }
      string str3 = str2.Replace("[PAR-AMT]", newValue1).Replace("[ADDITIONAL-RFP-DETAILS]", opportunity.OpportunityDetail.AdditionalRFPDetails);
      DateTime? nullable2 = opportunity.OpportunityDetail.ResponseDueDateTime;
      string newValue2;
      if (!nullable2.HasValue)
      {
        newValue2 = "";
      }
      else
      {
        nullable2 = opportunity.OpportunityDetail.ResponseDueDateTime;
        newValue2 = nullable2.Value.ToString("MM'/'dd'/'yyyy hh:mm tt");
      }
      body = str3.Replace("[RESPONSE-DUE-DATE]", newValue2).Replace("[RESPONSE-DUE-DATE-TIME-ZONE]", Convert.ToString(opportunity.OpportunityDetail.ResponseDueDateTimezone));
      string str4 = body;
      nullable1 = opportunity.OpportunityDetail.RFPFees;
      string newValue3;
      if (!nullable1.HasValue)
      {
        newValue3 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.RFPFees;
        newValue3 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str5 = str4.Replace("[PROPOSED-AVERAGE-TAKEDOWN]", newValue3);
      nullable1 = opportunity.OpportunityDetail.ProposedManagementFee;
      string newValue4;
      if (!nullable1.HasValue)
      {
        newValue4 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.ProposedManagementFee;
        newValue4 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str6 = str5.Replace("[PROPOSED-MANAGEMENT-FEE]", newValue4);
      nullable1 = opportunity.OpportunityDetail.ProposedUnderwriterExpenses;
      string newValue5;
      if (!nullable1.HasValue)
      {
        newValue5 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.ProposedUnderwriterExpenses;
        newValue5 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str7 = str6.Replace("[PROPOSED-UNDERWRITER-EXPENSES]", newValue5);
      nullable1 = opportunity.OpportunityDetail.GrossSpread;
      string newValue6;
      if (!nullable1.HasValue)
      {
        newValue6 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.GrossSpread;
        newValue6 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str8 = str7.Replace("[PROPOSE-GROSS-SPREAD]", newValue6);
      nullable1 = opportunity.OpportunityDetail.FirmLiabilityPerc;
      string newValue7;
      if (!nullable1.HasValue)
      {
        newValue7 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.FirmLiabilityPerc;
        newValue7 = string.Format("{0:n3}", (object) nullable1.Value);
      }
      string str9 = str8.Replace("[EXPECTED-FIRM-LIABILITY]", newValue7);
      nullable1 = opportunity.OpportunityDetail.FirmMgmtFee;
      string newValue8;
      if (!nullable1.HasValue)
      {
        newValue8 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.FirmMgmtFee;
        newValue8 = string.Format("{0:n3}", (object) nullable1.Value);
      }
      string str10 = str9.Replace("[EXPECTED-FIRM-MGMT-FEE]", newValue8);
      nullable1 = opportunity.OpportunityDetail.TakeDownValue;
      string newValue9;
      if (!nullable1.HasValue)
      {
        newValue9 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.TakeDownValue;
        newValue9 = string.Format("{0:C2}", (object) nullable1.Value);
      }
      string str11 = str10.Replace("[ESTIMATED-AVERAGE-TAKEDOWN]", newValue9);
      nullable1 = opportunity.OpportunityDetail.EstGrossRev;
      string newValue10;
      if (!nullable1.HasValue)
      {
        newValue10 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.EstGrossRev;
        newValue10 = string.Format("{0:C2}", (object) nullable1.Value);
      }
      string str12 = str11.Replace("[ESTIMATED-REVENUE]", newValue10).Replace("[ADDITIONAL-INFORMATION-FOR-COMMITMENT-COMMITTEE]", opportunity.OpportunityDetail.AdditionalInformationForCommitmentCommittee).Replace("[BORROWER/OBLIGOR]", opportunity.OpportunityDetail.BorrowerName).Replace("[DEAL-TYPE]", opportunity.OpportunityDetail.DealTypeName).Replace("[TYPE-OF-OPPORTUNITY]", opportunity.OpportunityDetail.OpportunityTypeName).Replace("[G-17-CONTACT-PREFIX]", opportunity.OpportunityDetail.G17ContactPrefix).Replace("[G-17-CONTACT-FIRST-NAME]", opportunity.OpportunityDetail.G17ContactFirstName).Replace("[G-17-CONTACT-LAST-NAME]", opportunity.OpportunityDetail.G17ContactLastName).Replace("[G17-CONTACT-SUFFIX]", opportunity.OpportunityDetail.G17ContactSuffix).Replace("[G-17-CONTACT-TITLE]", opportunity.OpportunityDetail.G17ContactJobTitle).Replace("[G17-CONTACT-EMAIL]", opportunity.OpportunityDetail.G17ContactEmail).Replace("[LEAD-BANKER]", opportunity.OpportunityDetail.LeadBanker).Replace("[G17-CONTACT-ADDRESS]", opportunity.OpportunityDetail.G17ContactAddress).Replace("[RATINGS]", opportunity.OpportunityDetail.Ratings).Replace("[EXPECTED-FIRM-ROLE]", opportunity.OpportunityDetail.ExpectedFirmRoleValue).Replace("[FIRM-ROLE]", opportunity.OpportunityDetail.FirmRoleValue).Replace("[RFP-TYPE]", opportunity.OpportunityDetail.RFPTypeName);
      nullable2 = opportunity.OpportunityDetail.ExpectedPricingDate;
      string newValue11;
      if (!nullable2.HasValue)
      {
        newValue11 = "";
      }
      else
      {
        nullable2 = opportunity.OpportunityDetail.ExpectedPricingDate;
        newValue11 = nullable2.Value.ToString("MM/dd/yyyy");
      }
      body = str12.Replace("[EXPECTED-PRICING-DATE]", newValue11);
      body = body.Replace("[MS-BANKING-GROUP]", opportunity.OpportunityDetail.MarketTxt);
      body = body.Replace("[WINNING-SYNDICATE-NOTES]", opportunity.OpportunityDetail.Notes);
      body = body.Replace("[REVIEW-COMMENT]", this.GetReviewComment(opportunity));
      if (opportunity.ExternalPartners != null && opportunity.ExternalPartners.Count > 0)
      {
        string source = string.Join("; ", opportunity.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.LookupKey == "Winning Syndicate Member Role" && !m.IsDeleted)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => !string.IsNullOrEmpty(x.Name) ? string.Format("{0} ({1})", (object) x.Name, (object) x.MemberTypeName) : string.Empty)).ToArray<string>());
        body = body.Replace("[WINNING-SYNDICATE-MEMBER-NAME-ROLE]", source.Any<char>() ? source : "");
      }
      else
        body = body.Replace("[WINNING-SYNDICATE-MEMBER-NAME-ROLE]", string.Empty);
      return body;
    }

    private void GetInternalPartnersEmailAddress(
      IrisSoftware.iMPACT.Data.Opportunity oppty,
      out string[] partnersEmailAddress)
    {
      partnersEmailAddress = new string[7]
      {
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty
      };
      if (oppty.InternalPartners == null || oppty.InternalPartners.Count <= 0)
        return;
      foreach (InternalPartner internalPartner in oppty.InternalPartners)
      {
        if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email) && internalPartner.IsActive)
        {
          switch (internalPartner.RoleTypeId.Value)
          {
            case 23:
              this.FillInvestmentBankingDetails(partnersEmailAddress, internalPartner);
              continue;
            case 24:
              this.FillAnalystDetails(partnersEmailAddress, internalPartner);
              continue;
            case 25:
              partnersEmailAddress[4] = string.Format("{0}{1};", (object) partnersEmailAddress[4], (object) internalPartner.Email);
              continue;
            case 26:
              partnersEmailAddress[5] = string.Format("{0}{1};", (object) partnersEmailAddress[5], (object) internalPartner.Email);
              continue;
            default:
              continue;
          }
        }
      }
    }

    private string SetRecipients(string recipients)
    {
      this.InfoReceipts.Length = 0;
      if (!string.IsNullOrEmpty(recipients))
      {
        foreach (string recipient in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
        {
          switch (recipient.Trim().ToUpper())
          {
            case "[INTERNAL-PARTNERS.ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[3]);
              continue;
            case "[INTERNAL-PARTNERS.BANKRM]":
              this.GetRecipients(this.partnersEmailAddress[5]);
              continue;
            case "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[1]);
              continue;
            case "[INTERNAL-PARTNERS.LEAD-ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[2]);
              continue;
            case "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[0]);
              continue;
            case "[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[6]);
              continue;
            case "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]":
              this.GetRecipients(this.partnersEmailAddress[4]);
              continue;
            case "[INTERNAL-PARTNERS.SYNDICATE]":
              continue;
            default:
              this.GetRecipients(recipient);
              continue;
          }
        }
      }
      return this.InfoReceipts.ToString();
    }

    public void GetRecipients(string recipient)
    {
      foreach (string str in recipient.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        if (!string.IsNullOrEmpty(str.Trim()) && !this.InfoReceipts.ToString().Contains(str))
          this.InfoReceipts.Append(str + ";");
      }
    }

    private bool IsUIEditable(long appTransactionID, string uiName, List<long> statusList) => appTransactionID == 0L ? this.HasEntityPermission(-33L, uiName, "Edit") : this.HasUIPermissionForEntityStatus(appTransactionID, uiName, "Edit", statusList);

    private OpportunityPresenter.OpportunityEditOnlyStatus SetOpportunityEditOnlyStatus(
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> opportunityStatusList,
      long appTransactionID)
    {
      OpportunityPresenter.OpportunityEditOnlyStatus opportunityEditOnlyStatus = new OpportunityPresenter.OpportunityEditOnlyStatus();
      List<long> statusList = opportunityStatusList.ConvertAll<long>((Converter<IrisSoftware.iMPACT.Data.Opportunity.Status, long>) (s => (long) s));
      opportunityEditOnlyStatus.isOpportunityDetailsEditable = this.IsUIEditable(appTransactionID, "Opportunity Details", statusList);
      opportunityEditOnlyStatus.isInternalPartnerEditable = this.IsUIEditable(appTransactionID, "Internal Partners", statusList);
      opportunityEditOnlyStatus.isExternalPartnerEditable = this.IsUIEditable(appTransactionID, "External Partners", statusList);
      opportunityEditOnlyStatus.isMiscEditable = this.IsUIEditable(appTransactionID, "Misc", statusList);
      return opportunityEditOnlyStatus;
    }

    private SaveResult CreateRFPFromOpportunity(OpportunityViewModel opportunityViewModel)
    {
      RFPViewModel rfpModel = new RFPViewModel()
      {
        ParentOpportunityID = new long?(opportunityViewModel.AppTransactionID),
        RFPName = opportunityViewModel.OpportunityName,
        PowerID = opportunityViewModel.OpportunityPowerID,
        IssuerID = opportunityViewModel.IssuerID,
        Issuer = new KeyPair(opportunityViewModel.Issuer.Key, opportunityViewModel.Issuer.Value),
        BorrowerID = opportunityViewModel.BorrowerID,
        Borrower = new KeyPair(opportunityViewModel.Issuer.Key, opportunityViewModel.Borrower.Value),
        GuarantorID = opportunityViewModel.GuarantorID,
        Guarantor = opportunityViewModel.Guarantor,
        State = opportunityViewModel.State,
        County = opportunityViewModel.County,
        ParAmount = opportunityViewModel.ParAmount,
        FirmRole = opportunityViewModel.FirmRole,
        AssignedFirmRole = opportunityViewModel.AssignedFirmRole,
        StateTax = opportunityViewModel.StateTax,
        AMT = opportunityViewModel.AMT,
        BankQualified = opportunityViewModel.BankQualified,
        Moody = opportunityViewModel.MoodyRatingLT,
        SP = opportunityViewModel.SPRatingLT,
        KrollRatingLT = opportunityViewModel.KrollRatingLT,
        Fitch = opportunityViewModel.FitchRatingLT,
        CreatedBy = opportunityViewModel.CreatedBy,
        MaterialType = opportunityViewModel.MaterialType,
        FirmLiabilityPerc = opportunityViewModel.FirmLiabilityPerc,
        AssignedFirmLiability = opportunityViewModel.AssignedFirmLiability,
        Purpose = opportunityViewModel.Purpose,
        TransactionType = opportunityViewModel.TransactionType,
        GrossSpread = opportunityViewModel.GrossSpread,
        EstGrossRev = opportunityViewModel.EstGrossRev,
        SecurityType = opportunityViewModel.SecurityType,
        ApprovedDerivativeMarketer = opportunityViewModel.ApprovedDerivativeMarketer,
        InformationalMERGRequired = opportunityViewModel.InformationalMERGRequired,
        HybridSolutionIndicator = opportunityViewModel.HybridSolutionIndicator,
        DualProposalProposed = opportunityViewModel.DualProposalProposed,
        RFPType = opportunityViewModel.RFPType
      };
      rfpModel.Bankers = this.GetRFPBankers(opportunityViewModel.Bankers);
      rfpModel.Analysts = this.GetRFPAnalysts(opportunityViewModel.Analysts);
      rfpModel.SupervisoryPrincipals = this.GetRFPSupervisoryPrincipals(opportunityViewModel.SupervisoryPrincipals);
      rfpModel.BankRMs = this.GetRFPBankRMs(opportunityViewModel.BankRMs);
      rfpModel.Advisors = this.GetRFPAdvisors(opportunityViewModel.Advisors, opportunityViewModel.OpportunityContact);
      rfpModel.Counsels = this.GetRFPCounsels(opportunityViewModel.Counsels, opportunityViewModel.OpportunityContact);
      rfpModel.AppTransactionClientContacts = this.GetRFPAppTransactionClientContacts(opportunityViewModel.OpportunityContact);
      rfpModel.MAExemptionDetails = opportunityViewModel.MAExemptionDetails;
      rfpModel.IsRFPInitiatedFromParentOpportunity = new bool?(true);
      return this.RFPPresenter.Save(rfpModel, string.Empty);
    }

    private List<InternalPartner> GetRFPBankers(
      List<InternalPartner> OpportunityBankers)
    {
      return OpportunityBankers == null ? new List<InternalPartner>() : OpportunityBankers.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (Banker => new InternalPartner()
      {
        InternalPartnerID = Banker.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = Banker.EmployeeID,
        PartnerType = Banker.PartnerType,
        RevenueAlloc = Banker.RevenueAlloc,
        IsPrimary = Banker.IsPrimary,
        IsDeleted = false,
        IncludeInDl = Banker.IncludeInDl,
        Type = Banker.Type,
        RoleTypeId = new long?(18L),
        IsDirty = true,
        FullName = Banker.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartner> GetRFPAnalysts(
      List<InternalPartner> OpportunityAnalysts)
    {
      return OpportunityAnalysts == null ? new List<InternalPartner>() : OpportunityAnalysts.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (Analyst => new InternalPartner()
      {
        InternalPartnerID = Analyst.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = Analyst.EmployeeID,
        PartnerType = Analyst.PartnerType,
        RevenueAlloc = Analyst.RevenueAlloc,
        IsPrimary = Analyst.IsPrimary,
        IsDeleted = false,
        IncludeInDl = Analyst.IncludeInDl,
        Type = Analyst.Type,
        RoleTypeId = new long?(19L),
        IsDirty = true,
        FullName = Analyst.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartner> GetRFPSupervisoryPrincipals(
      List<InternalPartner> OpportunitySupervisoryPrincipals)
    {
      return OpportunitySupervisoryPrincipals == null ? new List<InternalPartner>() : OpportunitySupervisoryPrincipals.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (SupervisoryPrincipal => new InternalPartner()
      {
        InternalPartnerID = SupervisoryPrincipal.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = SupervisoryPrincipal.EmployeeID,
        PartnerType = SupervisoryPrincipal.PartnerType,
        RevenueAlloc = SupervisoryPrincipal.RevenueAlloc,
        IsPrimary = SupervisoryPrincipal.IsPrimary,
        IsDeleted = false,
        IncludeInDl = SupervisoryPrincipal.IncludeInDl,
        Type = SupervisoryPrincipal.Type,
        RoleTypeId = new long?(20L),
        IsDirty = true,
        FullName = SupervisoryPrincipal.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartnerBankRM> GetRFPBankRMs(
      List<InternalPartnerBankRM> OpportunityBankRMs)
    {
      return OpportunityBankRMs == null ? new List<InternalPartnerBankRM>() : OpportunityBankRMs.Select<InternalPartnerBankRM, InternalPartnerBankRM>((Func<InternalPartnerBankRM, InternalPartnerBankRM>) (OpportunityBankRM => new InternalPartnerBankRM()
      {
        ID = OpportunityBankRM.ID * -1L,
        AppTransactionID = 0L,
        Name = OpportunityBankRM.Name,
        Title = OpportunityBankRM.Title,
        Email = OpportunityBankRM.Email,
        Phone = OpportunityBankRM.Phone,
        IncludeInDl = OpportunityBankRM.IncludeInDl,
        IsDeleted = false
      })).ToList<InternalPartnerBankRM>();
    }

    private List<ExternalPartner> GetRFPAdvisors(
      List<ExternalPartner> OpportunityAdvisors,
      OpportunityContactDetailViewModel OpportunityContacts)
    {
      return OpportunityAdvisors == null ? new List<ExternalPartner>() : OpportunityAdvisors.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (Advisor => new ExternalPartner()
      {
        ExternalPartnerID = Advisor.ExternalPartnerID * -1L,
        AppTransactionID = 0L,
        PartnerID = Advisor.PartnerID,
        MemberType = Advisor.MemberType,
        Descr = Advisor.Descr,
        LiabilityPerc = Advisor.LiabilityPerc,
        EstMgmtFee = Advisor.EstMgmtFee,
        IsDeleted = false,
        InsertedIssueContact = OpportunityContacts.AdvisorMemberContact.Where<IssueContact>((Func<IssueContact, bool>) (p => p.CompanyName == Advisor.Name)).Select<IssueContact, string>((Func<IssueContact, string>) (p => p.MainContactID.ToString())).Join<string>(","),
        DeletedIssueContact = string.Empty,
        IsDirty = true,
        Name = Advisor.Name
      })).ToList<ExternalPartner>();
    }

    private List<ExternalPartner> GetRFPCounsels(
      List<ExternalPartner> OpportunityCounsels,
      OpportunityContactDetailViewModel OpportunityContacts)
    {
      return OpportunityCounsels == null ? new List<ExternalPartner>() : OpportunityCounsels.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (Counsel => new ExternalPartner()
      {
        ExternalPartnerID = Counsel.ExternalPartnerID * -1L,
        AppTransactionID = 0L,
        PartnerID = Counsel.PartnerID,
        MemberType = Counsel.MemberType,
        Descr = Counsel.Descr,
        LiabilityPerc = Counsel.LiabilityPerc,
        EstMgmtFee = Counsel.EstMgmtFee,
        IsDeleted = false,
        InsertedIssueContact = OpportunityContacts.CounselMemberContact.Where<IssueContact>((Func<IssueContact, bool>) (p => p.CompanyName == Counsel.Name)).Select<IssueContact, string>((Func<IssueContact, string>) (p => p.MainContactID.ToString())).Join<string>(","),
        DeletedIssueContact = string.Empty,
        IsDirty = true,
        Name = Counsel.Name
      })).ToList<ExternalPartner>();
    }

    private List<AppTransactionClientContact> GetRFPAppTransactionClientContacts(
      OpportunityContactDetailViewModel OpportunityContacts)
    {
      List<AppTransactionClientContact> transactionClientContactList = new List<AppTransactionClientContact>();
      foreach (IssueContact issueContact in OpportunityContacts.IssuerMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      foreach (IssueContact issueContact in OpportunityContacts.BorrowerMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      foreach (IssueContact issueContact in OpportunityContacts.GuarantorMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      return transactionClientContactList;
    }

    private SaveResult CreateIssueFromOpportunity(
      OpportunityViewModel opportunityViewModel)
    {
      IssueViewModelContainer issueContainer = new IssueViewModelContainer();
      IssueDetailViewModel issueDetailViewModel = new IssueDetailViewModel()
      {
        ParentOpportunityID = new long?(opportunityViewModel.AppTransactionID),
        IssueName = opportunityViewModel.OpportunityName,
        IssuerId = opportunityViewModel.Issuer == null ? new long?() : new long?(Convert.ToInt64(opportunityViewModel.Issuer.Key)),
        IssuerName = opportunityViewModel.IssuerName,
        ParAmount = opportunityViewModel.ParAmount,
        StateID = opportunityViewModel.State,
        County = opportunityViewModel.County,
        FirmRoleId = opportunityViewModel.AssignedFirmRole,
        FirmLiabilityPerc = opportunityViewModel.AssignedFirmLiability,
        InsuranceProviderId = opportunityViewModel.InsuranceProvider,
        CreatedBy = opportunityViewModel.CreatedBy,
        BorrowerId = opportunityViewModel.Borrower != null ? new long?(Convert.ToInt64(opportunityViewModel.Borrower.Key)) : new long?(),
        GuarantorId = opportunityViewModel.Guarantor != null ? new long?(Convert.ToInt64(opportunityViewModel.Guarantor.Key)) : new long?(),
        OfferingTypeId = -54,
        PowerID = opportunityViewModel.OpportunityPowerID,
        HybridSolutionIndicator = opportunityViewModel.HybridSolutionIndicator,
        DualProposalProposed = opportunityViewModel.DualProposalProposed,
        TransactionType = opportunityViewModel.TransactionType,
        Purpose = opportunityViewModel.Purpose,
        DateHired = opportunityViewModel.DateHired,
        MAExemptionDetails = opportunityViewModel.MAExemptionDetails,
        G17Details = opportunityViewModel.G17Details,
        JobNumber = opportunityViewModel.JobNumber,
        GeneralCategoryId = opportunityViewModel.Market,
        EstimatedRevenue = opportunityViewModel.EstGrossRev,
        DealType = opportunityViewModel.DealType,
        MSBankingGroup = this.GetIssueMSBanking(opportunityViewModel.MSBankingGroupOpportunity),
        BorrowerName = opportunityViewModel.BorrowerName,
        GuarantorName = opportunityViewModel.GuarantorName,
        Series = new List<Series>()
        {
          new Series()
          {
            SeriesID = -1L,
            SeriesName = "SERIES",
            SeriesCode = "SERIES",
            GrossSpread = opportunityViewModel.GrossSpread,
            Takedown = opportunityViewModel.TakeDownValue,
            FirmRole = opportunityViewModel.AssignedFirmRole,
            SdcCredit = opportunityViewModel.SDCCreditPerc
          }
        },
        SDCCreditPerc = opportunityViewModel.SDCCreditPerc
      };
      IssueInternalPartnerViewModel partnerViewModel1 = new IssueInternalPartnerViewModel()
      {
        IssueInvestmentBankingTeam = this.GetIssueBankers(opportunityViewModel.Bankers),
        IssueAnalystProfessionalSupport = this.GetIssueAnalysts(opportunityViewModel.Analysts),
        IssueSupervisoryPrincipal = this.GetIssueSupervisoryPrincipals(opportunityViewModel.SupervisoryPrincipals),
        IssueBankRM = this.GetIssueBankRMs(opportunityViewModel.BankRMs)
      };
      IssueExternalPartnerViewModel partnerViewModel2 = new IssueExternalPartnerViewModel()
      {
        AdvisorAgent = this.GetIssueAdvisors(opportunityViewModel.Advisors, opportunityViewModel.OpportunityContact),
        Counsel = this.GetIssueCounsels(opportunityViewModel.Counsels, opportunityViewModel.OpportunityContact),
        SyndicateMember = this.GetSyndicateCounsels(opportunityViewModel.SyndicateMembers, opportunityViewModel.OpportunityContact),
        WinningSyndicateMember = this.GetSyndicateCounsels(opportunityViewModel.WinningSyndicateMembers, opportunityViewModel.OpportunityContact)
      };
      issueContainer.IssueDetail = issueDetailViewModel;
      issueContainer.TransactionReportDetail.IssueFee.GrossSpread = opportunityViewModel.GrossSpread;
      issueContainer.InternalPartnerDetail = partnerViewModel1;
      issueContainer.ExternalPartnerDetail = partnerViewModel2;
      issueContainer.AppTransactionClientContacts = this.GetIssueAppTransactionClientContacts(opportunityViewModel.OpportunityContact);
      issueContainer.TransactionReportDetail.IssueFee.EstimatedRevenue = opportunityViewModel.EstGrossRev;
      issueContainer.TransactionReportDetail.IssueFee.Takedown = opportunityViewModel.TakeDownValue;
      issueContainer.IssueDetail.IsIssueInitiatedFromParentOpportunity = new bool?(true);
      SaveResult saveResult = this.IssuePresenter.Save(issueContainer, string.Empty, 1);
      if (saveResult.Id > 0L)
      {
        using (IDataReader dataReader = this.IssueRatingRepository.FetchSeriesDetails(saveResult.Id))
        {
          if (dataReader != null)
          {
            while (dataReader.Read())
            {
              long int64 = Convert.ToInt64(dataReader["SeriesID"].ToString());
              if (int64 > 0L)
              {
                List<PricingViewModel> pricingViewModelList = new List<PricingViewModel>();
                PricingViewModel pricingViewModel = new PricingViewModel();
                pricingViewModel.ParAmount = opportunityViewModel.ParAmount.ToString();
                long? nullable = opportunityViewModel.SecurityType;
                pricingViewModel.SecType = nullable.ToString();
                nullable = opportunityViewModel.FedTax;
                pricingViewModel.FedTax = nullable.ToString();
                pricingViewModel.StateTax = opportunityViewModel.StateTax.ToString();
                pricingViewModel.AmtTax = opportunityViewModel.AMT.ToString();
                pricingViewModel.BankQualified = opportunityViewModel.BankQualified.ToString();
                nullable = opportunityViewModel.RateType;
                pricingViewModel.RateType = nullable.ToString();
                pricingViewModel.GrossSpread = Convert.ToString((object) opportunityViewModel.GrossSpread);
                pricingViewModel.Takedown = Convert.ToString((object) opportunityViewModel.TakeDownValue);
                pricingViewModel.SeriesID = int64.ToString();
                pricingViewModel.FirmRole = Convert.ToString((object) opportunityViewModel.AssignedFirmRole);
                pricingViewModel.SDCCredit = Convert.ToString((object) opportunityViewModel.SDCCreditPerc);
                pricingViewModel.Denomination = "5000";
                pricingViewModelList.Add(pricingViewModel);
                List<PricingViewModel> pricingViewModelCollection = pricingViewModelList;
                saveResult = this.GetPricingResult(saveResult, pricingViewModelCollection);
              }
            }
          }
        }
      }
      return saveResult;
    }

    private List<InternalPartner> GetIssueBankers(
      List<InternalPartner> OpportunityBankers)
    {
      return OpportunityBankers == null ? new List<InternalPartner>() : OpportunityBankers.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (Banker => new InternalPartner()
      {
        InternalPartnerID = Banker.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        Email = Banker.Email,
        EmployeeID = Banker.EmployeeID,
        PartnerType = Banker.PartnerType,
        RevenueAlloc = Banker.RevenueAlloc,
        IsPrimary = Banker.IsPrimary,
        IsDeleted = false,
        IncludeInDl = Banker.IncludeInDl,
        Type = "IBT",
        RoleTypeId = new long?(13L),
        IsDirty = true,
        FullName = Banker.FullName,
        IsActive = Banker.IsActive
      })).ToList<InternalPartner>();
    }

    private List<InternalPartner> GetIssueAnalysts(
      List<InternalPartner> OpportunityAnalysts)
    {
      return OpportunityAnalysts == null ? new List<InternalPartner>() : OpportunityAnalysts.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (Analyst => new InternalPartner()
      {
        InternalPartnerID = Analyst.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = Analyst.EmployeeID,
        PartnerType = Analyst.PartnerType,
        RevenueAlloc = Analyst.RevenueAlloc,
        IsPrimary = Analyst.IsPrimary,
        IsDeleted = false,
        IncludeInDl = Analyst.IncludeInDl,
        Type = Analyst.Type,
        RoleTypeId = new long?(14L),
        IsDirty = true,
        FullName = Analyst.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartner> GetIssueSupervisoryPrincipals(
      List<InternalPartner> OpportunitySupervisoryPrincipals)
    {
      return OpportunitySupervisoryPrincipals == null ? new List<InternalPartner>() : OpportunitySupervisoryPrincipals.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (SupervisoryPrincipal => new InternalPartner()
      {
        InternalPartnerID = SupervisoryPrincipal.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = SupervisoryPrincipal.EmployeeID,
        PartnerType = SupervisoryPrincipal.PartnerType,
        RevenueAlloc = SupervisoryPrincipal.RevenueAlloc,
        IsPrimary = SupervisoryPrincipal.IsPrimary,
        IsDeleted = false,
        IncludeInDl = SupervisoryPrincipal.IncludeInDl,
        Type = "SP",
        RoleTypeId = new long?(15L),
        IsDirty = true,
        FullName = SupervisoryPrincipal.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartnerBankRM> GetIssueBankRMs(
      List<InternalPartnerBankRM> OpportunityBankRMs)
    {
      return OpportunityBankRMs == null ? new List<InternalPartnerBankRM>() : OpportunityBankRMs.Select<InternalPartnerBankRM, InternalPartnerBankRM>((Func<InternalPartnerBankRM, InternalPartnerBankRM>) (OpportunityBankRM => new InternalPartnerBankRM()
      {
        ID = OpportunityBankRM.ID * -1L,
        AppTransactionID = 0L,
        Name = OpportunityBankRM.Name,
        Title = OpportunityBankRM.Title,
        Email = OpportunityBankRM.Email,
        Phone = OpportunityBankRM.Phone,
        IncludeInDl = OpportunityBankRM.IncludeInDl,
        IsDeleted = false
      })).ToList<InternalPartnerBankRM>();
    }

    private List<ExternalPartner> GetIssueAdvisors(
      List<ExternalPartner> OpportunityAdvisors,
      OpportunityContactDetailViewModel OpportunityContacts)
    {
      return OpportunityAdvisors == null ? new List<ExternalPartner>() : OpportunityAdvisors.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (Advisor => new ExternalPartner()
      {
        ExternalPartnerID = Advisor.ExternalPartnerID * -1L,
        AppTransactionID = 0L,
        PartnerID = Advisor.PartnerID,
        MemberType = Advisor.MemberType,
        Descr = Advisor.Descr,
        LiabilityPerc = Advisor.LiabilityPerc,
        EstMgmtFee = Advisor.EstMgmtFee,
        IsDeleted = false,
        InsertedIssueContact = OpportunityContacts.AdvisorMemberContact.Where<IssueContact>((Func<IssueContact, bool>) (p => p.CompanyName == Advisor.Name)).Select<IssueContact, string>((Func<IssueContact, string>) (p => p.MainContactID.ToString())).Join<string>(","),
        DeletedIssueContact = string.Empty,
        IsDirty = true,
        Name = Advisor.Name
      })).ToList<ExternalPartner>();
    }

    private List<ExternalPartner> GetIssueCounsels(
      List<ExternalPartner> OpportunityCounsels,
      OpportunityContactDetailViewModel OpportunityContacts)
    {
      return OpportunityCounsels == null ? new List<ExternalPartner>() : OpportunityCounsels.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (Counsel => new ExternalPartner()
      {
        ExternalPartnerID = Counsel.ExternalPartnerID * -1L,
        AppTransactionID = 0L,
        PartnerID = Counsel.PartnerID,
        MemberType = Counsel.MemberType,
        Descr = Counsel.Descr,
        LiabilityPerc = Counsel.LiabilityPerc,
        EstMgmtFee = Counsel.EstMgmtFee,
        IsDeleted = false,
        InsertedIssueContact = OpportunityContacts.CounselMemberContact.Where<IssueContact>((Func<IssueContact, bool>) (p => p.CompanyName == Counsel.Name)).Select<IssueContact, string>((Func<IssueContact, string>) (p => p.MainContactID.ToString())).Join<string>(","),
        DeletedIssueContact = string.Empty,
        IsDirty = true,
        Name = Counsel.Name
      })).ToList<ExternalPartner>();
    }

    private List<ExternalPartner> GetSyndicateCounsels(
      List<ExternalPartner> OpportunityCounsels,
      OpportunityContactDetailViewModel OpportunityContacts)
    {
      return OpportunityCounsels == null ? new List<ExternalPartner>() : OpportunityCounsels.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (Counsel => new ExternalPartner()
      {
        ExternalPartnerID = Counsel.ExternalPartnerID * -1L,
        AppTransactionID = 0L,
        PartnerID = Counsel.PartnerID,
        MemberType = Counsel.MemberType,
        Descr = Counsel.Descr,
        LiabilityPerc = Counsel.LiabilityPerc,
        EstMgmtFee = Counsel.EstMgmtFee,
        IsDeleted = false,
        InsertedIssueContact = OpportunityContacts.SyndicateMemberContact.Where<IssueContact>((Func<IssueContact, bool>) (p => p.CompanyName == Counsel.Name)).Select<IssueContact, string>((Func<IssueContact, string>) (p => p.MainContactID.ToString())).Join<string>(","),
        DeletedIssueContact = string.Empty,
        IsDirty = true,
        Name = Counsel.Name
      })).ToList<ExternalPartner>();
    }

    private List<AppTransactionClientContact> GetIssueAppTransactionClientContacts(
      OpportunityContactDetailViewModel OpportunityContacts)
    {
      List<AppTransactionClientContact> transactionClientContactList = new List<AppTransactionClientContact>();
      foreach (IssueContact issueContact in OpportunityContacts.IssuerMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      foreach (IssueContact issueContact in OpportunityContacts.BorrowerMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      foreach (IssueContact issueContact in OpportunityContacts.GuarantorMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      return transactionClientContactList;
    }

    public List<string> GetDealVersions() => new List<string>()
    {
      "version1",
      "version2",
      "version3",
      "version4",
      "version5"
    };

    public string DataTableToJSONWithStringBuilder(DataTable table)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (table.Rows.Count > 0)
      {
        stringBuilder.Append("[");
        for (int index1 = 0; index1 < table.Rows.Count; ++index1)
        {
          stringBuilder.Append("{");
          for (int index2 = 0; index2 < table.Columns.Count; ++index2)
          {
            if (index2 < table.Columns.Count - 1)
              stringBuilder.Append("\"" + table.Columns[index2].ColumnName.ToString() + "\":\"" + table.Rows[index1][index2].ToString() + "\",");
            else if (index2 == table.Columns.Count - 1)
              stringBuilder.Append("\"" + table.Columns[index2].ColumnName.ToString() + "\":\"" + table.Rows[index1][index2].ToString() + "\"");
          }
          if (index1 == table.Rows.Count - 1)
            stringBuilder.Append("}");
          else
            stringBuilder.Append("},");
        }
        stringBuilder.Append("]");
      }
      return stringBuilder.ToString();
    }

    public static DataTable JoinTwoDataTablesOnOneColumn(
      DataTable dtblLeft,
      DataTable dtblRight,
      string colToJoinOn,
      OpportunityPresenter.JoinType joinType)
    {
      string strTempColName = colToJoinOn + "_2";
      if (dtblRight.Columns.Contains(colToJoinOn))
        dtblRight.Columns[colToJoinOn].ColumnName = strTempColName;
      DataTable dtblResult = dtblLeft.Clone();
      IEnumerable<DataColumn> source = dtblRight.Columns.OfType<DataColumn>().Select<DataColumn, DataColumn>((Func<DataColumn, DataColumn>) (dc => new DataColumn(dc.ColumnName, dc.DataType, dc.Expression, dc.ColumnMapping))).AsEnumerable<DataColumn>().Where<DataColumn>((Func<DataColumn, bool>) (dc => !dtblResult.Columns.Contains(dc.ColumnName)));
      dtblResult.Columns.AddRange(source.ToArray<DataColumn>());
      if (!dtblLeft.Columns.Contains(colToJoinOn) || !dtblRight.Columns.Contains(colToJoinOn) && !dtblRight.Columns.Contains(strTempColName))
      {
        if (!dtblResult.Columns.Contains(colToJoinOn))
          dtblResult.Columns.Add(colToJoinOn);
        return dtblResult;
      }
      if (joinType == OpportunityPresenter.JoinType.Inner || joinType != OpportunityPresenter.JoinType.Left)
      {
        foreach (object[] objArray in dtblLeft.AsEnumerable().Join<DataRow, DataRow, object, object[]>((IEnumerable<DataRow>) dtblRight.AsEnumerable(), (Func<DataRow, object>) (rowLeft => rowLeft[colToJoinOn]), (Func<DataRow, object>) (rowRight => rowRight[strTempColName]), (Func<DataRow, DataRow, object[]>) ((rowLeft, rowRight) => ((IEnumerable<object>) rowLeft.ItemArray).Concat<object>((IEnumerable<object>) rowRight.ItemArray).ToArray<object>())))
          dtblResult.Rows.Add(objArray);
      }
      else
      {
        foreach (object[] objArray in dtblLeft.AsEnumerable().GroupJoin((IEnumerable<DataRow>) dtblRight.AsEnumerable(), (Func<DataRow, object>) (rowLeft => rowLeft[colToJoinOn]), (Func<DataRow, object>) (rowRight => rowRight[strTempColName]), (rowLeft, gj) => new
        {
          rowLeft = rowLeft,
          gj = gj
        }).SelectMany(_param1 => _param1.gj.DefaultIfEmpty<DataRow>(), (_param1, subRight) => ((IEnumerable<object>) _param1.rowLeft.ItemArray).Concat<object>(subRight == null ? (IEnumerable<object>) dtblRight.NewRow().ItemArray : (IEnumerable<object>) subRight.ItemArray).ToArray<object>()))
          dtblResult.Rows.Add(objArray);
      }
      dtblRight.Columns[strTempColName].ColumnName = colToJoinOn;
      dtblResult.Columns.Remove(strTempColName);
      return dtblResult;
    }

    private Dictionary<int, int> AddHistory(
      TransitionResult<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transitionResult)
    {
      Dictionary<int, int> dictionary = (Dictionary<int, int>) null;
      if (transitionResult.History.Count > 0)
      {
        dictionary = new Dictionary<int, int>();
        foreach (KeyValuePair<IrisSoftware.iMPACT.Data.Opportunity.Status, IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>> keyValuePair in (IEnumerable<KeyValuePair<IrisSoftware.iMPACT.Data.Opportunity.Status, IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity>>>) transitionResult.History)
        {
          IrisSoftware.iMPACT.Data.Opportunity.Status key1 = keyValuePair.Key;
          IrisSoftware.iMPACT.Data.Opportunity.Status key2 = keyValuePair.Value.Key;
          dictionary.Add((int) key1, (int) key2);
        }
      }
      return dictionary;
    }

    private List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> SetFromToStateList(
      TransitionResult<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> transitionResult)
    {
      List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> fromStateToStateList = new List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState>();
      foreach (IState<IrisSoftware.iMPACT.Data.Opportunity.Status, IrisSoftware.iMPACT.Data.Opportunity> resultingState in transitionResult.ResultingStates)
        fromStateToStateList.Add(new IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState(new IrisSoftware.iMPACT.Data.Opportunity.Status?(), resultingState.Key));
      return fromStateToStateList;
    }

    private List<long> SetStatusList(OpportunityViewModel opportunityModel)
    {
      List<long> longList = new List<long>();
      if (opportunityModel.OpportunityStatus != null && opportunityModel.OpportunityStatus.Count > 0)
        longList = opportunityModel.OpportunityStatus;
      return longList;
    }

    private void SetOpportunityNumber(IrisSoftware.iMPACT.Data.Opportunity newOpportunity, IrisSoftware.iMPACT.Data.Opportunity op)
    {
      if (op == null || string.IsNullOrEmpty(op.OpportunityDetail.OpportunityNbr))
        return;
      newOpportunity.OpportunityDetail.OpportunityNbr = op.OpportunityDetail.OpportunityNbr;
    }

    private void SetMSBankingGroup(IrisSoftware.iMPACT.Data.Opportunity newOpportunity, IrisSoftware.iMPACT.Data.Opportunity op)
    {
      if (op == null)
        return;
      newOpportunity.OpportunityDetail.MarketTxt = op.OpportunityDetail.MarketTxt;
    }

    private void SetLeadBanker(IrisSoftware.iMPACT.Data.Opportunity newOpportunity, IrisSoftware.iMPACT.Data.Opportunity op)
    {
      if (op == null)
        return;
      newOpportunity.OpportunityDetail.LeadBanker = op.OpportunityDetail.LeadBanker;
    }

    private void SaveAuditTrail(OpportunityViewModel opportunityModel) => this.AuditTrailRepository.Save(new AuditTrail()
    {
      AppTransactionID = new long?(opportunityModel.AppTransactionID),
      Entity = "Opportunity",
      What = "Issue Initiated"
    });

    private void PublishEvents(
      OpportunityViewModel opportunityModel,
      string opportunityAction,
      List<IrisSoftware.iMPACT.Data.Opportunity.Status> lstOldOpptyStatus,
      IrisSoftware.iMPACT.Data.Opportunity oldOpportunity,
      bool IsIssueInitiated,
      SaveResult saveResult,
      IrisSoftware.iMPACT.Data.Opportunity newOpportunity,
      long appTransactionID,
      List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> fromToStateList,
      List<int> stateTracking)
    {
      if (!saveResult.IsSuccessful)
        return;
      bool? nullable;
      DateTime now;
      if (opportunityModel.AppTransactionID > 0L)
      {
        if (!EntityStateHelper.IsStatusListEqual(lstOldOpptyStatus.ConvertAll<long>((Converter<IrisSoftware.iMPACT.Data.Opportunity.Status, long>) (s => (long) s)), newOpportunity.OpportunityDetail.OpportunityStatus))
        {
          List<Envelope<OpportunityStatusChangedEvent>> envelopeList = new List<Envelope<OpportunityStatusChangedEvent>>();
          envelopeList.Add((Envelope<OpportunityStatusChangedEvent>) new OpportunityStatusChangedEvent(newOpportunity, fromToStateList));
          envelopeList.Add((Envelope<OpportunityStatusChangedEvent>) new OpportunityStatusChangedEvent(stateTracking, appTransactionID));
          if (opportunityAction == "Mark Commitment Committee Approved" && newOpportunity.OpportunityDetail.OpportunityStatus != null && (newOpportunity.OpportunityDetail.OpportunityStatus.Count > 0 && newOpportunity.OpportunityDetail.OpportunityStatus.Contains(5L)))
          {
            nullable = newOpportunity.OpportunityDetail.IsCommitmentCommitteeApproved;
            if (!nullable.GetValueOrDefault())
              this.EventBus.Publish<OpportunityFieldUpdateEvent>((Envelope<OpportunityFieldUpdateEvent>) new OpportunityFieldUpdateEvent(appTransactionID, true, true, "IsCommitmentCommitteeApproved"));
          }
          if (opportunityAction == "Mark Management Approved" && newOpportunity.OpportunityDetail.OpportunityStatus != null && (newOpportunity.OpportunityDetail.OpportunityStatus.Count > 0 && newOpportunity.OpportunityDetail.OpportunityStatus.Contains(9L)))
          {
            nullable = newOpportunity.OpportunityDetail.IsManagementApproved;
            if (!nullable.GetValueOrDefault())
              this.EventBus.Publish<OpportunityFieldUpdateEvent>((Envelope<OpportunityFieldUpdateEvent>) new OpportunityFieldUpdateEvent(appTransactionID, true, true, "IsManagementApproved"));
          }
          this.EventBus.Publish<OpportunityStatusChangedEvent>((IEnumerable<Envelope<OpportunityStatusChangedEvent>>) envelopeList);
          this.EventBus.Publish<OpportunityUpdatedEvent>((Envelope<OpportunityUpdatedEvent>) new OpportunityUpdatedEvent(newOpportunity, oldOpportunity));
          this.Log.Error(Modules.Opportunity, string.Format("PERFORMANCE : Set opptyStatusChangedEventList,EventBus  at  {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) newOpportunity.OpportunityDetail.AppTransactionID));
        }
        else
        {
          this.EventBus.Publish<OpportunityUpdatedEvent>((Envelope<OpportunityUpdatedEvent>) new OpportunityUpdatedEvent(newOpportunity, oldOpportunity));
          this.Log.Error(Modules.Opportunity, string.Format("PERFORMANCE : Set EventBus  at  {0} ", (object) DateTime.Now));
        }
        if (IsIssueInitiated)
        {
          this.EventBus.Publish<OpportunityIssueInitiatedEvent>((Envelope<OpportunityIssueInitiatedEvent>) new OpportunityIssueInitiatedEvent(newOpportunity));
          Logger<Modules> log = this.Log;
          now = DateTime.Now;
          string message = string.Format("PERFORMANCE : Calling when Issue Initiating at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) newOpportunity.OpportunityDetail.AppTransactionID);
          log.Error(Modules.Opportunity, message);
        }
      }
      else
        this.EventBus.Publish<OpportunityCreatedEvent>((IEnumerable<Envelope<OpportunityCreatedEvent>>) new List<Envelope<OpportunityCreatedEvent>>()
        {
          (Envelope<OpportunityCreatedEvent>) new OpportunityCreatedEvent(newOpportunity),
          (Envelope<OpportunityCreatedEvent>) new OpportunityCreatedEvent(stateTracking, appTransactionID)
        });
      nullable = opportunityModel.HasDualProposalRequestedOrProposed;
      if (nullable.GetValueOrDefault())
        this.EventBus.Publish<OpportunityNotifyDualProposalRequestedProposedEvent>((Envelope<OpportunityNotifyDualProposalRequestedProposedEvent>) new OpportunityNotifyDualProposalRequestedProposedEvent(newOpportunity));
      Logger<Modules> log1 = this.Log;
      now = DateTime.Now;
      string message1 = string.Format("PERFORMANCE : Set opptyStatusChangedEventList,EventBus  at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) newOpportunity.OpportunityDetail.AppTransactionID);
      log1.Error(Modules.Opportunity, message1);
      saveResult.ViewModel = (object) this.Initialize(appTransactionID);
      Logger<Modules> log2 = this.Log;
      now = DateTime.Now;
      string message2 = string.Format("PERFORMANCE : Finally Initialize called   at  {0} for AppTrsanctionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) newOpportunity.OpportunityDetail.AppTransactionID);
      log2.Error(Modules.Opportunity, message2);
    }

    private void AddToFinalSearchResults(
      List<Dictionary<string, object>> searchResults,
      List<Dictionary<string, object>> finalSearchResults,
      List<Dictionary<string, object>> miscSearchResults)
    {
      int num = 0;
      for (int i = 0; i < searchResults.Count; i++)
      {
        for (int index = num; index < miscSearchResults.Count; ++index)
        {
          if (searchResults[i]["AppTransactionID"].ToString() == miscSearchResults[index]["AppTransactionID"].ToString())
          {
            Dictionary<string, object> dictionary = searchResults[i].Concat<KeyValuePair<string, object>>(miscSearchResults[index].Where<KeyValuePair<string, object>>((Func<KeyValuePair<string, object>, bool>) (x => !searchResults[i].Keys.Contains<string>(x.Key)))).ToDictionary<KeyValuePair<string, object>, string, object>((Func<KeyValuePair<string, object>, string>) (k => k.Key), (Func<KeyValuePair<string, object>, object>) (v => v.Value));
            finalSearchResults.Add(dictionary);
          }
        }
      }
    }

    private void ApplyDelimiter(StringBuilder emailUpdated, string adr)
    {
      if (emailUpdated.Length > 0)
        emailUpdated.Append(";");
      emailUpdated.Append(adr);
    }

    private void FillInvestmentBankingDetails(
      string[] partnersEmailAddress,
      InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[0] = string.Format("{0}{1};", (object) partnersEmailAddress[0], (object) partner.Email);
      else if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("2", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[6] = string.Format("{0}{1};", (object) partnersEmailAddress[6], (object) partner.Email);
      else
        partnersEmailAddress[1] = string.Format("{0}{1};", (object) partnersEmailAddress[1], (object) partner.Email);
    }

    private void FillAnalystDetails(string[] partnersEmailAddress, InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[2] = string.Format("{0}{1};", (object) partnersEmailAddress[2], (object) partner.Email);
      else
        partnersEmailAddress[3] = string.Format("{0}{1};", (object) partnersEmailAddress[3], (object) partner.Email);
    }

    private SaveResult GetPricingResult(
      SaveResult saveResult,
      List<PricingViewModel> pricingViewModelCollection)
    {
      SaveResult saveResult1 = this.IssuePresenter.SaveIssuePricing(pricingViewModelCollection, saveResult.Id);
      if (!saveResult1.IsSuccessful)
        saveResult = saveResult1;
      return saveResult;
    }

    private List<MsBankingGroup> GetIssueMSBanking(
      List<MsBankingGroupOpportunity> MSbankerOpportunity)
    {
      return MSbankerOpportunity == null ? new List<MsBankingGroup>() : MSbankerOpportunity.Select<MsBankingGroupOpportunity, MsBankingGroup>((Func<MsBankingGroupOpportunity, MsBankingGroup>) (MSGroup => new MsBankingGroup()
      {
        LookupItemID = MSGroup.Key,
        Value = MSGroup.Value
      })).ToList<MsBankingGroup>();
    }

    [Dependency]
    public UploadDocumentPresenter UploadDocPresenter { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    [Dependency]
    public IAppTransactionDocSetRepository AppTransactionDocSetRepository { get; set; }

    [Dependency]
    public IEntityDocSetTypeRepository EntityDocSetTypeRepository { get; set; }

    public void PerformSharePointDocumentSetOperations(
      long appTransactionId,
      IrisSoftware.iMPACT.Data.Opportunity oldOpportunity,
      IrisSoftware.iMPACT.Data.Opportunity newOpportunity)
    {
      try
      {
        bool hasAnyPropChanged;
        Hashtable properties = this.PopulateDocumentProperties(appTransactionId, oldOpportunity, newOpportunity, out hasAnyPropChanged);
        List<AppTransactionDocSet> transactionDocSetList = this.AppTransactionDocSetRepository.FetchByAppTransactionID(appTransactionId);
        List<EntityDocSetType> entityDocSetTypeList = this.EntityDocSetTypeRepository.FetchEntityDocSetTypeByEntityID(-33L);
        string libLocation = this.AppTransactionDocSetRepository.FetchLibraryURLByEntityTypeID(-33L);
        List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
        foreach (EntityDocSetType entityDocSetType in entityDocSetTypeList)
        {
          EntityDocSetType docSet = entityDocSetType;
          OpportunityPresenter.GetRepositoryLevelProperties_New(properties, docSet);
          List<DocSetPermission> docSetPermissions = this.GetDocSetPermissions(appTransactionId, docSet.EntityDocSetTypeID);
          int num;
          if (!transactionDocSetList.Exists((Predicate<AppTransactionDocSet>) (x =>
          {
            long? entityDocSetTypeId1 = x.EntityDocSetTypeID;
            long entityDocSetTypeId2 = docSet.EntityDocSetTypeID;
            return entityDocSetTypeId1.GetValueOrDefault() == entityDocSetTypeId2 && entityDocSetTypeId1.HasValue;
          })))
            this.CreateDocumentSet(appTransactionId, properties, libLocation, docSet, docSetPermissions);
          else if (newOpportunity.InternalPartners != null && newOpportunity.InternalPartners.Any<InternalPartner>((Func<InternalPartner, bool>) (x => x.IsDirty)))
          {
            UploadDocumentPresenter uploadDocPresenter = this.UploadDocPresenter;
            num = -33;
            string entityType = num.ToString();
            num = transactionDocSetList.Find((Predicate<AppTransactionDocSet>) (x => x.EntityDocSetTypeID.Value == docSet.EntityDocSetTypeID)).DocSetID;
            string docSetId = num.ToString();
            List<DocSetPermission> issueDocSetPermissions = docSetPermissions;
            Hashtable sharedFields = properties;
            uploadDocPresenter.ApplyPermission(entityType, docSetId, issueDocSetPermissions, sharedFields);
          }
          else if (hasAnyPropChanged)
          {
            UploadDocumentPresenter uploadDocPresenter = this.UploadDocPresenter;
            num = -33;
            string entityType = num.ToString();
            num = transactionDocSetList.Find((Predicate<AppTransactionDocSet>) (x => x.EntityDocSetTypeID.Value == docSet.EntityDocSetTypeID)).DocSetID;
            string docSetId = num.ToString();
            Hashtable sharedFields = properties;
            uploadDocPresenter.UpdateSharedFields(entityType, docSetId, sharedFields);
          }
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
      }
    }

    private static void GetRepositoryLevelProperties_New(
      Hashtable properties,
      EntityDocSetType repository)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) repository.DocSetName;
      else
        properties.Add((object) "Title", (object) repository.DocSetName);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) repository.EntityDocSetTypeID;
      else
        properties.Add((object) "iDocSetType", (object) repository.EntityDocSetTypeID);
    }

    private static void GetRepositoryLevelProperties(Hashtable properties, LookupItem repository)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) repository.Value;
      else
        properties.Add((object) "Title", (object) repository.Value);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) repository.LookupItemID;
      else
        properties.Add((object) "iDocSetType", (object) repository.LookupItemID);
    }

    private void CreateDocumentSet(
      long appTransactionId,
      Hashtable properties,
      string libLocation,
      EntityDocSetType entityDocSet,
      List<DocSetPermission> docSetPermissions)
    {
      DocSetInfo docSet = this.UploadDocPresenter.CreateDocSet(new DocSetInfo()
      {
        AppTransactionId = appTransactionId,
        DocSetName = entityDocSet.DocSetName,
        EntityType = -33.ToString(),
        URL = libLocation
      }, docSetPermissions, properties);
      this.SaveAppTransactionDetails(new AppTransactionDocSet()
      {
        EntityID = appTransactionId,
        EntityDocSetTypeID = new long?(entityDocSet.EntityDocSetTypeID),
        DocSetTypeValue = entityDocSet.DocSetName,
        URL = libLocation,
        DocSetID = Convert.ToInt32(docSet.DocSetId)
      });
    }

    private List<DocSetPermission> GetDocSetPermissions(
      long appId,
      long docSetType)
    {
      string empty = string.Empty;
      List<DocSetPermission> docSetPermissionList1 = new List<DocSetPermission>();
      List<DocSetPermission> docSetPermissionList2 = this.AppTransactionDocSetRepository.FetchOpptyRepositoryPermissionsByAppTransID(appId, -33);
      List<DocSetPermission> repositoryUploadPermissionList = docSetPermissionList2.FindAll((Predicate<DocSetPermission>) (p => p.RepositoryID == docSetType && p.Permission.ToLower() == "upload"));
      List<DocSetPermission> all = docSetPermissionList2.FindAll((Predicate<DocSetPermission>) (p => p.RepositoryID == docSetType && p.Permission.ToLower() == "view" && !repositoryUploadPermissionList.Exists((Predicate<DocSetPermission>) (u => u.PrincipalId == p.PrincipalId))));
      foreach (DocSetPermission docSetPermission in repositoryUploadPermissionList)
        docSetPermissionList1.Add(new DocSetPermission()
        {
          Permission = "Upload",
          PrincipalId = docSetPermission.PrincipalId,
          PermissionId = 0
        });
      foreach (DocSetPermission docSetPermission in all)
        docSetPermissionList1.Add(new DocSetPermission()
        {
          Permission = "view",
          PrincipalId = docSetPermission.PrincipalId,
          PermissionId = 0
        });
      return docSetPermissionList1;
    }

    private void SaveAppTransactionDetails(AppTransactionDocSet appTransactionDocSet) => this.AppTransactionDocSetRepository.Save(appTransactionDocSet);

    private Hashtable PopulateDocumentProperties(
      long appTransactionId,
      IrisSoftware.iMPACT.Data.Opportunity oldOpportunity,
      IrisSoftware.iMPACT.Data.Opportunity newOpportunity,
      out bool hasAnyPropChanged)
    {
      hasAnyPropChanged = false;
      Hashtable hashtable1 = this.PopulateProperties(appTransactionId, oldOpportunity);
      Hashtable hashtable2 = this.PopulateProperties(appTransactionId, newOpportunity);
      foreach (DictionaryEntry dictionaryEntry in hashtable2)
      {
        if (hashtable1.ContainsKey(dictionaryEntry.Key))
        {
          if (!hashtable1[dictionaryEntry.Key].Equals(dictionaryEntry.Value))
          {
            hasAnyPropChanged = true;
            break;
          }
        }
        else
        {
          hasAnyPropChanged = true;
          break;
        }
      }
      return hashtable2;
    }

    private Hashtable PopulateProperties(long appTransactionId, IrisSoftware.iMPACT.Data.Opportunity opportunity)
    {
      Hashtable hashtable1 = new Hashtable();
      string str = string.Empty;
      if (opportunity.OpportunityDetail.OpportunityStatus != null)
        str = string.Join(",", opportunity.OpportunityDetail.OpportunityStatus.Select<long, string>((Func<long, string>) (s => s.ToString())).ToArray<string>());
      hashtable1.Add((object) "iRefID", (object) (Convert.ToString(appTransactionId) ?? string.Empty));
      hashtable1.Add((object) "iEntityNbr", (object) (opportunity.OpportunityDetail.OpportunityNbr ?? string.Empty));
      hashtable1.Add((object) "iEntityName", (object) (opportunity.OpportunityDetail.OpportunityName ?? string.Empty));
      hashtable1.Add((object) "iEntityStatus", (object) str);
      hashtable1.Add((object) "iState", (object) (Convert.ToString((object) opportunity.OpportunityDetail.State) ?? string.Empty));
      Hashtable hashtable2 = hashtable1;
      long? nullable = opportunity.OpportunityDetail.FirmRole;
      string empty1;
      if (!nullable.HasValue)
      {
        empty1 = string.Empty;
      }
      else
      {
        nullable = opportunity.OpportunityDetail.FirmRole;
        empty1 = nullable.ToString();
      }
      hashtable2.Add((object) "iFirmRole", (object) empty1);
      Hashtable hashtable3 = hashtable1;
      nullable = opportunity.OpportunityDetail.IssuerID;
      string empty2;
      if (!nullable.HasValue)
      {
        empty2 = string.Empty;
      }
      else
      {
        nullable = opportunity.OpportunityDetail.IssuerID;
        empty2 = nullable.ToString();
      }
      hashtable3.Add((object) "iIssuerID", (object) empty2);
      Hashtable hashtable4 = hashtable1;
      nullable = opportunity.OpportunityDetail.BorrowerID;
      string empty3;
      if (!nullable.HasValue)
      {
        empty3 = string.Empty;
      }
      else
      {
        nullable = opportunity.OpportunityDetail.BorrowerID;
        empty3 = nullable.ToString();
      }
      hashtable4.Add((object) "iBorrowerID", (object) empty3);
      Hashtable hashtable5 = hashtable1;
      Decimal? parAmount = opportunity.OpportunityDetail.ParAmount;
      string empty4;
      if (!parAmount.HasValue)
      {
        empty4 = string.Empty;
      }
      else
      {
        parAmount = opportunity.OpportunityDetail.ParAmount;
        empty4 = parAmount.ToString();
      }
      hashtable5.Add((object) "iParAmount", (object) empty4);
      if (opportunity.OpportunityDetail.CreatedOn.Date == DateTime.MinValue.Date)
        hashtable1.Add((object) "iCreateDate", (object) DateTime.Now);
      return hashtable1;
    }

    private struct OpportunityEditOnlyStatus
    {
      public bool isOpportunityDetailsEditable;
      public bool isExternalPartnerEditable;
      public bool isInternalPartnerEditable;
      public bool isMiscEditable;
    }

    public enum JoinType
    {
      Inner,
      Left,
    }
  }
}
