﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ClientSearchPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.SearchCriteria;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (ClientSearchPresenter))]
  public class ClientSearchPresenter : PresenterBase
  {
    private static readonly HashSet<string> dateColumnsToAdjust = new HashSet<string>((IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)
    {
      "MAExemptionStartDate",
      "MAExemptionEndDate"
    };

    private static object FixDate(string name, object value) => value != null && !string.IsNullOrEmpty(value.ToString()) && (ClientSearchPresenter.dateColumnsToAdjust.Contains(name) && DateTime.TryParse(value.ToString(), out DateTime _)) ? (object) string.Format("{0:yyyy}-{0:MM}-{0:dd}T{0:HH}:{0:mm}:00.00", (object) (DateTime) value) : value;

    [Dependency]
    public IClientRepository ClientRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public SaveResult SearchClient(
      KendoGridRequest request,
      ClientSearchViewModel clientSearchCriteria)
    {
      try
      {
        long total = 0;
        bool isBlankSearch = false;
        List<Dictionary<string, object>> dictionaryList = new List<Dictionary<string, object>>();
        SaveResult saveResult1 = new SaveResult();
        using (IDataReader searchData = this.GetSearchData(request, clientSearchCriteria, out total, ref isBlankSearch))
        {
          if (searchData != null)
          {
            while (searchData.Read())
              dictionaryList.Add(searchData.ConvertToDictionary(new Func<string, object, object>(ClientSearchPresenter.FixDate)));
            if (searchData.NextResult())
            {
              if (searchData.Read())
                total = (long) searchData.GetInt32(0);
            }
          }
        }
        SaveResult saveResult2;
        if (isBlankSearch)
        {
          saveResult2 = SaveResult.Failure("Please select one or more filter criteria to continue search.");
        }
        else
        {
          saveResult2 = SaveResult.Success;
          saveResult2.ViewModel = (object) new Paged<ClientSearchResultViewModel>((object) dictionaryList, total);
        }
        return saveResult2;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure(ex.Message);
      }
    }

    public ClientSearchViewModel Initialize()
    {
      try
      {
        ClientSearchViewModel clientSearchViewModel = new ClientSearchViewModel();
        IEnumerable<LookupItemMappings> source = this.LookupRepository.FetchLookupItemsByLookupKeys(new string[1]
        {
          "State"
        }, (string[]) null, true);
        clientSearchViewModel.States = source.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "State")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
        clientSearchViewModel.CanCreatePublicBookmark = this.HasIndependentPermission("Client Public Bookmark", "Create");
        SearchSetting searchSetting = this.ClientRepository.FetchAllBookmarks().FirstOrDefault<SearchSetting>((Func<SearchSetting, bool>) (x => x.SearchSettingID == -4L));
        if (searchSetting == null)
        {
          List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
          List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
          List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
          List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
          clientSearchViewModel.SelectedFields = list1;
          clientSearchViewModel.AllFields = list2;
          clientSearchViewModel.SelectedAllFields = list2;
          clientSearchViewModel.FieldsToSelect = list1;
        }
        else
        {
          IssueSearchViewModel issueSearchViewModel = new JavaScriptSerializer().Deserialize<IssueSearchViewModel>(searchSetting.Criteria);
          if (issueSearchViewModel.SelectedFields != null && issueSearchViewModel.SelectedFields.Count > 0)
          {
            clientSearchViewModel.SelectedFields = issueSearchViewModel.SelectedFields;
            clientSearchViewModel.AllFields = issueSearchViewModel.AllFields;
            clientSearchViewModel.SelectedAllFields = issueSearchViewModel.AllFields;
            clientSearchViewModel.FieldsToSelect = issueSearchViewModel.FieldsToSelect;
          }
          else
          {
            List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
            List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
            List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
            List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
            clientSearchViewModel.SelectedFields = list1;
            clientSearchViewModel.AllFields = list2;
            clientSearchViewModel.SelectedAllFields = list2;
            clientSearchViewModel.FieldsToSelect = list1;
          }
        }
        return clientSearchViewModel;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        ClientSearchViewModel clientSearchViewModel = new ClientSearchViewModel();
        clientSearchViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return clientSearchViewModel;
      }
    }

    public List<SearchSettingViewModel> GetAllBookmarks()
    {
      try
      {
        return this.ClientRepository.FetchAllBookmarks().Select<SearchSetting, SearchSettingViewModel>((Func<SearchSetting, SearchSettingViewModel>) (x => new SearchSettingViewModel(x))).ToList<SearchSettingViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<SearchSettingViewModel>();
      }
    }

    public SaveResult SaveBookMark(SearchSettingViewModel searchSettingModel)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.ClientRepository.SaveBookMark(new SearchSetting()
          {
            SearchSettingID = searchSettingModel.SearchSettingID,
            Name = searchSettingModel.Name,
            Criteria = searchSettingModel.Criteria,
            GridSetting = searchSettingModel.GridSetting,
            Public = searchSettingModel.Public
          });
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult DeleteBookMark(long bookmarkId)
    {
      try
      {
        this.ClientRepository.DeleteBookMark(bookmarkId);
        return new SaveResult();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while deleting the data.");
      }
    }

    private IDataReader GetSearchData(
      KendoGridRequest request,
      ClientSearchViewModel clientSearchCriteria,
      out long total,
      ref bool isBlankSearch)
    {
      total = 0L;
      IVisitableCriterion visitableCriterion = Criterion.Contains("Name", string.IsNullOrEmpty(clientSearchCriteria.Name) ? clientSearchCriteria.Name : clientSearchCriteria.Name.Trim()).And(Criterion.Contains("City", string.IsNullOrEmpty(clientSearchCriteria.City) ? clientSearchCriteria.City : clientSearchCriteria.City.Trim())).And(Criterion.Contains("TaxID", string.IsNullOrEmpty(clientSearchCriteria.TaxID) ? clientSearchCriteria.TaxID : clientSearchCriteria.TaxID.Trim())).And(Criterion.Contains("CUSIP", string.IsNullOrEmpty(clientSearchCriteria.CUSIP) ? clientSearchCriteria.CUSIP : clientSearchCriteria.CUSIP.Trim())).And(Criterion.Contains("Zip", string.IsNullOrEmpty(clientSearchCriteria.Zip) ? clientSearchCriteria.Zip : (clientSearchCriteria.Zip.Trim().Last<char>() == '-' ? clientSearchCriteria.Zip.Replace("-", "").Trim() : clientSearchCriteria.Zip.Trim()))).And("StateID".AnyOf(clientSearchCriteria.SelectedStates.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!clientSearchCriteria.IsStateIn)).And("IsActive".Equal(clientSearchCriteria.IsActive)).And("MAExempt".Equal(clientSearchCriteria.MAExempt)).And("ExternalClientID".Equal(clientSearchCriteria.ExternalClientID));
      if (visitableCriterion == EmptyCriterion.Instance)
      {
        isBlankSearch = true;
        return (IDataReader) null;
      }
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      return this.ClientRepository.Query(new QueryDefinition()
      {
        Criterion = visitableCriterion,
        Order = orderingList.ToArray()
      }, request.take, (int) request.skip);
    }

    public ExportResult Export(
      KendoGridRequest request,
      ClientSearchViewModel searchCriteria,
      string exportType,
      string TimeZoneOffset)
    {
      try
      {
        bool isBlankSearch = false;
        DataTable dataTable = new DataTable();
        using (IDataReader searchData = this.GetSearchData(request, searchCriteria, out long _, ref isBlankSearch))
          dataTable.Load(searchData);
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Client Search", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".25cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        List<SearchResultField> list = searchCriteria.SelectedFields.OrderBy<SearchResultField, int>((Func<SearchResultField, int>) (x => x.Order)).ToList<SearchResultField>();
        string tzAbbreviation = this.GetTzAbbreviation(TimeZone.CurrentTimeZone.StandardName);
        foreach (SearchResultField searchResultField in list)
        {
          if (searchResultField.ExportColumns != null && searchResultField.IsTimezoneReq)
            tabularReportBuilder.AddColumn(searchResultField.Html.title + " (" + tzAbbreviation + ")", searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1, (IEnumerable<string>) searchResultField.ExportColumns);
          else if (searchResultField.ExportColumns != null && !searchResultField.IsTimezoneReq)
            tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1, (IEnumerable<string>) searchResultField.ExportColumns);
          else
            tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1);
        }
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "ClientSearch", (object) dataTable);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ExportResult();
      }
    }

    public string GetTzAbbreviation(string timeZoneName)
    {
      StringBuilder stringBuilder = new StringBuilder();
      string str1 = timeZoneName;
      char[] chArray = new char[1]{ ' ' };
      foreach (string str2 in str1.Split(chArray))
      {
        if (str2[0] != '(')
          stringBuilder.Append(str2[0]);
        else
          stringBuilder.Append(str2);
      }
      return stringBuilder.ToString();
    }

    private List<SearchResultField> GetAllSearchResultFields()
    {
      List<SearchResultField> searchResultFieldList1 = new List<SearchResultField>();
      int num1 = 1;
      List<SearchResultField> searchResultFieldList2 = searchResultFieldList1;
      SearchResultField searchResultField1 = new SearchResultField();
      searchResultField1.Name = "Full Name";
      searchResultField1.ExportField = "Name";
      int num2 = num1;
      int num3 = num2 + 1;
      searchResultField1.Order = num2;
      searchResultField1.IsMandatory = true;
      searchResultField1.Html = new SearchResultFieldHtml()
      {
        field = "Name",
        title = "Full Name",
        sortable = true,
        isLeftAligned = true,
        width = "280px",
        excelWidth = "7cm"
      };
      searchResultFieldList2.Add(searchResultField1);
      List<SearchResultField> searchResultFieldList3 = searchResultFieldList1;
      SearchResultField searchResultField2 = new SearchResultField();
      searchResultField2.Name = "Address";
      searchResultField2.ExportField = "Address";
      int num4 = num3;
      int num5 = num4 + 1;
      searchResultField2.Order = num4;
      searchResultField2.Html = new SearchResultFieldHtml()
      {
        field = "Address",
        title = "Address",
        sortable = true,
        isLeftAligned = true,
        width = "280px",
        excelWidth = "8cm"
      };
      searchResultFieldList3.Add(searchResultField2);
      List<SearchResultField> searchResultFieldList4 = searchResultFieldList1;
      SearchResultField searchResultField3 = new SearchResultField();
      searchResultField3.Name = "City";
      searchResultField3.ExportField = "City";
      int num6 = num5;
      int num7 = num6 + 1;
      searchResultField3.Order = num6;
      searchResultField3.Html = new SearchResultFieldHtml()
      {
        field = "City",
        title = "City",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "4cm"
      };
      searchResultFieldList4.Add(searchResultField3);
      List<SearchResultField> searchResultFieldList5 = searchResultFieldList1;
      SearchResultField searchResultField4 = new SearchResultField();
      searchResultField4.Name = "State";
      searchResultField4.ExportField = "State";
      int num8 = num7;
      int num9 = num8 + 1;
      searchResultField4.Order = num8;
      searchResultField4.Html = new SearchResultFieldHtml()
      {
        field = "State",
        title = "State",
        sortable = true,
        isLeftAligned = true,
        width = "60px",
        excelWidth = "1.5cm"
      };
      searchResultFieldList5.Add(searchResultField4);
      List<SearchResultField> searchResultFieldList6 = searchResultFieldList1;
      SearchResultField searchResultField5 = new SearchResultField();
      searchResultField5.Name = "ZIP Code";
      searchResultField5.ExportField = "Zip";
      int num10 = num9;
      int num11 = num10 + 1;
      searchResultField5.Order = num10;
      searchResultField5.Html = new SearchResultFieldHtml()
      {
        field = "Zip",
        title = "ZIP Code",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2.5cm"
      };
      searchResultFieldList6.Add(searchResultField5);
      List<SearchResultField> searchResultFieldList7 = searchResultFieldList1;
      SearchResultField searchResultField6 = new SearchResultField();
      searchResultField6.Name = "CUSIP";
      searchResultField6.ExportField = "CUSIP";
      int num12 = num11;
      int num13 = num12 + 1;
      searchResultField6.Order = num12;
      searchResultField6.Html = new SearchResultFieldHtml()
      {
        field = "CUSIP",
        title = "CUSIP",
        sortable = true,
        isLeftAligned = true,
        width = "130px",
        excelWidth = "3cm"
      };
      searchResultFieldList7.Add(searchResultField6);
      List<SearchResultField> searchResultFieldList8 = searchResultFieldList1;
      SearchResultField searchResultField7 = new SearchResultField();
      searchResultField7.Name = "External Client ID";
      searchResultField7.ExportField = "ExternalClientID";
      int num14 = num13;
      int num15 = num14 + 1;
      searchResultField7.Order = num14;
      searchResultField7.Html = new SearchResultFieldHtml()
      {
        field = "ExternalClientID",
        title = "External Client ID",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2.2cm"
      };
      searchResultFieldList8.Add(searchResultField7);
      List<SearchResultField> searchResultFieldList9 = searchResultFieldList1;
      SearchResultField searchResultField8 = new SearchResultField();
      searchResultField8.Name = "Is Active";
      searchResultField8.ExportField = "IsActive";
      int num16 = num15;
      int num17 = num16 + 1;
      searchResultField8.Order = num16;
      searchResultField8.Html = new SearchResultFieldHtml()
      {
        field = "IsActive",
        title = "Is Active",
        sortable = true,
        isLeftAligned = true,
        width = "90px",
        excelWidth = "1.5cm"
      };
      searchResultFieldList9.Add(searchResultField8);
      List<SearchResultField> searchResultFieldList10 = searchResultFieldList1;
      SearchResultField searchResultField9 = new SearchResultField();
      searchResultField9.Name = "Independent?";
      searchResultField9.ExportField = "IRMAIndependent";
      int num18 = num17;
      int num19 = num18 + 1;
      searchResultField9.Order = num18;
      searchResultField9.Html = new SearchResultFieldHtml()
      {
        field = "IRMAIndependent",
        title = "Independent?",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList10.Add(searchResultField9);
      List<SearchResultField> searchResultFieldList11 = searchResultFieldList1;
      SearchResultField searchResultField10 = new SearchResultField();
      searchResultField10.Name = "IRMA Perfected?";
      searchResultField10.ExportField = "IRMAPerfected";
      int num20 = num19;
      int num21 = num20 + 1;
      searchResultField10.Order = num20;
      searchResultField10.Html = new SearchResultFieldHtml()
      {
        field = "IRMAPerfected",
        title = "IRMA Perfected?",
        sortable = true,
        isLeftAligned = true,
        width = "180px",
        excelWidth = "3cm"
      };
      searchResultFieldList11.Add(searchResultField10);
      List<SearchResultField> searchResultFieldList12 = searchResultFieldList1;
      SearchResultField searchResultField11 = new SearchResultField();
      searchResultField11.Name = "MA Exempt";
      searchResultField11.ExportField = "MAExempt";
      int num22 = num21;
      int num23 = num22 + 1;
      searchResultField11.Order = num22;
      searchResultField11.Html = new SearchResultFieldHtml()
      {
        field = "MAExempt",
        title = "MA Exempt",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2.2cm"
      };
      searchResultFieldList12.Add(searchResultField11);
      List<SearchResultField> searchResultFieldList13 = searchResultFieldList1;
      SearchResultField searchResultField12 = new SearchResultField();
      searchResultField12.Name = "KFUJ Name";
      searchResultField12.ExportField = "KFUJName";
      int num24 = num23;
      int num25 = num24 + 1;
      searchResultField12.Order = num24;
      searchResultField12.Html = new SearchResultFieldHtml()
      {
        field = "KFUJName",
        title = "KFUJ Name",
        sortable = true,
        isLeftAligned = true,
        width = "280px",
        excelWidth = "7cm"
      };
      searchResultFieldList13.Add(searchResultField12);
      List<SearchResultField> searchResultFieldList14 = searchResultFieldList1;
      SearchResultField searchResultField13 = new SearchResultField();
      searchResultField13.Name = "IRMA Start Date";
      searchResultField13.ExportField = "=Format(fields!MAExemptionStartDate.Value, \"MM/dd/yyyy\")";
      searchResultField13.ExportColumns = new string[1]
      {
        "MAExemptionStartDate"
      };
      SearchResultField searchResultField14 = searchResultField13;
      int num26 = num25;
      int num27 = num26 + 1;
      searchResultField14.Order = num26;
      searchResultField13.Html = new SearchResultFieldHtml()
      {
        field = "MAExemptionStartDate",
        title = "IRMA Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "180px",
        excelWidth = "2.5cm",
        template = "#= convertDateToString(MAExemptionStartDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField15 = searchResultField13;
      searchResultFieldList14.Add(searchResultField15);
      List<SearchResultField> searchResultFieldList15 = searchResultFieldList1;
      SearchResultField searchResultField16 = new SearchResultField();
      searchResultField16.Name = "IRMA Expiry Date";
      searchResultField16.ExportField = "=Format(fields!MAExemptionEndDate.Value, \"MM/dd/yyyy\")";
      searchResultField16.ExportColumns = new string[1]
      {
        "MAExemptionEndDate"
      };
      SearchResultField searchResultField17 = searchResultField16;
      int num28 = num27;
      int num29 = num28 + 1;
      searchResultField17.Order = num28;
      searchResultField16.Html = new SearchResultFieldHtml()
      {
        field = "MAExemptionEndDate",
        title = "IRMA Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "180px",
        excelWidth = "2.5cm",
        template = "#= convertDateToString(MAExemptionEndDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField18 = searchResultField16;
      searchResultFieldList15.Add(searchResultField18);
      List<SearchResultField> searchResultFieldList16 = searchResultFieldList1;
      SearchResultField searchResultField19 = new SearchResultField();
      searchResultField19.Name = "IRMA Name";
      searchResultField19.ExportField = "NameOfIRMA";
      int num30 = num29;
      int num31 = num30 + 1;
      searchResultField19.Order = num30;
      searchResultField19.Html = new SearchResultFieldHtml()
      {
        field = "NameOfIRMA",
        title = "IRMA Name",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList16.Add(searchResultField19);
      List<SearchResultField> searchResultFieldList17 = searchResultFieldList1;
      SearchResultField searchResultField20 = new SearchResultField();
      searchResultField20.Name = "IRMA Scope";
      searchResultField20.ExportField = "IRMAScope";
      int num32 = num31;
      int num33 = num32 + 1;
      searchResultField20.Order = num32;
      searchResultField20.Html = new SearchResultFieldHtml()
      {
        field = "IRMAScope",
        title = "IRMA Scope",
        sortable = true,
        isLeftAligned = true,
        width = "110px",
        excelWidth = "2cm"
      };
      searchResultFieldList17.Add(searchResultField20);
      return searchResultFieldList1;
    }
  }
}
