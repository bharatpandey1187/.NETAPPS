﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.IssueManagementPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.SearchCriteria;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (IssueManagementPresenter))]
  public class IssueManagementPresenter : PresenterBase
  {
    [Dependency]
    public IIssueManagementRepository IssueManagementRepository { get; set; }

    public Paged<IssueManagementViewModel> SearchIssue(
      KendoGridRequest request,
      IssueManagementSearchViewModel issueSearchCriteria)
    {
      List<IssueManagementViewModel> managementViewModelList = new List<IssueManagementViewModel>();
      int num = 0;
      try
      {
        IssueManagementSearchViewModel managementSearchViewModel = issueSearchCriteria;
        DateTime? createDateTo = issueSearchCriteria.CreateDateTo;
        DateTime dateTime;
        if (!createDateTo.HasValue)
        {
          dateTime = DateTime.Today.AddDays(1.0).AddSeconds(-1.0);
        }
        else
        {
          createDateTo = issueSearchCriteria.CreateDateTo;
          dateTime = createDateTo.Value.AddDays(1.0).AddSeconds(-1.0);
        }
        DateTime? nullable = new DateTime?(dateTime);
        managementSearchViewModel.CreateDateTo = nullable;
        IVisitableCriterion visitableCriterion = Criterion.Contains("IssueName", issueSearchCriteria.IssueName).And(Criterion.Contains("IssuerName", issueSearchCriteria.IssuerName).Or(Criterion.Contains("IssuerName", issueSearchCriteria.IssuerName))).And("StateID".Equal(issueSearchCriteria.IssueState)).And("CreatedOn".GreaterThanOrEqual<DateTime>(issueSearchCriteria.CreateDateFrom)).And("CreatedOn".LessThanOrEqual<DateTime>(issueSearchCriteria.CreateDateTo));
        List<Ordering> orderingList = new List<Ordering>();
        if (request.sort.Length != 0)
        {
          foreach (KendoGridRequest.SortObject sortObject in request.sort)
            orderingList.Add(new Ordering()
            {
              PropertyName = sortObject.field,
              Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
            });
        }
        else
          orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
        using (IDataReader dataReader = this.IssueManagementRepository.Query(new QueryDefinition()
        {
          Criterion = visitableCriterion,
          Order = orderingList.ToArray()
        }, request.take, (int) request.skip))
        {
          if (dataReader != null)
          {
            IRowMapper<IssueManagementViewModel> rowMapper = MapBuilder<IssueManagementViewModel>.MapAllProperties().Build();
            while (dataReader.Read())
              managementViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
            if (dataReader.NextResult())
            {
              if (dataReader.Read())
                num = dataReader.GetInt32(0);
            }
          }
        }
        return new Paged<IssueManagementViewModel>((IList<IssueManagementViewModel>) managementViewModelList, (long) num);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new Paged<IssueManagementViewModel>((IList<IssueManagementViewModel>) managementViewModelList, (long) num);
      }
    }

    private DateTime? ConvertToDateTime(string str) => string.IsNullOrEmpty(str) ? new DateTime?() : new DateTime?(Convert.ToDateTime(str));

    public SaveResult DeleteIssues(string issueIds)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssueManagementRepository.Delete(issueIds);
          transactionScope.Complete();
          return new SaveResult();
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while deleting the data.");
      }
    }
  }
}
