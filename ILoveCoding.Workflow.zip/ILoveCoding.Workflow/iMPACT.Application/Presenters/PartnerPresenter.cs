﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.PartnerPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public class PartnerPresenter : PresenterBase
  {
    [Dependency]
    public IPartnerRepository PartnerRepository { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    [Dependency]
    public ReferenceDataPresenter Presenter { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public PartnerViewModelContainer GetAllPartner()
    {
      try
      {
        PartnerViewModelContainer viewModelContainer = new PartnerViewModelContainer();
        List<PartnerViewModel> partnerViewModelList = new List<PartnerViewModel>();
        using (IDataReader dataReader = this.PartnerRepository.FetchAll())
        {
          IRowMapper<PartnerViewModel> rowMapper = MapBuilder<PartnerViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsViewOnly)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsAddContact)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsAddPartner)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsEditPartner)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsEditContact)).DoNotMap<string>((Expression<Func<PartnerViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<List<PartnerDetailViewModel>>((Expression<Func<PartnerViewModel, List<PartnerDetailViewModel>>>) (x => x.PartnerContacts)).DoNotMap<List<PartnerRoles>>((Expression<Func<PartnerViewModel, List<PartnerRoles>>>) (x => x.PartnerToPartnerTypes)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsPartnerIdUsedInEntity)).DoNotMap<bool>((Expression<Func<PartnerViewModel, bool>>) (x => x.IsPartnerContactAdded)).Build();
          while (dataReader.Read())
            partnerViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        viewModelContainer.Partners = partnerViewModelList;
        viewModelContainer.States = this.Presenter.GetItemsByKey("State").ToList<LookupItemViewModel>();
        viewModelContainer.PartnerTypes = this.Presenter.GetItemsByKey("Partner Type").ToList<LookupItemViewModel>();
        viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Parnter", "Edit");
        viewModelContainer.IsAddPartner = !this.HasIndependentPermission("Parnter", "Add");
        viewModelContainer.IsEditPartner = !this.HasIndependentPermission("Parnter", "Edit");
        if (!viewModelContainer.IsViewOnly)
          viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Parnter", "Add");
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PartnerViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public PartnerViewModel GetPartnerById(long partnerId)
    {
      try
      {
        AppConfig appConfig = this.AppConfigRepository.FetchByKey(52);
        bool flag = false;
        if (appConfig != null && !string.IsNullOrEmpty(appConfig.Value) && appConfig.Value.Trim() == "0")
          flag = this.CheckPartnerIdUsedInEntity(partnerId);
        Partner partner = this.PartnerRepository.FetchByKey(partnerId);
        IEnumerable<LookupItemMappings> source = this.FetchLookupItemsByLookupKeys();
        return new PartnerViewModel(partner)
        {
          IsViewOnly = (!this.HasAnyPermissionOnSet(new List<Tuple<string, string>>((IEnumerable<Tuple<string, string>>) new Tuple<string, string>[4]
          {
            Tuple.Create<string, string>("Parnter", "Edit"),
            Tuple.Create<string, string>("Parnter", "Add"),
            Tuple.Create<string, string>("Partner Contacts", "Edit"),
            Tuple.Create<string, string>("Partner Contacts", "Add")
          })) ? 1 : 0) != 0,
          IsAddPartner = !this.HasIndependentPermission("Parnter", "Add"),
          IsEditPartner = !this.HasIndependentPermission("Parnter", "Edit"),
          IsAddContact = !this.HasIndependentPermission("Partner Contacts", "Add"),
          IsEditContact = !this.HasIndependentPermission("Partner Contacts", "Edit"),
          IsPartnerIdUsedInEntity = flag,
          ContactTitle = source.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Contact Title")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PartnerViewModel("An error occurred while fetching the data.");
      }
    }

    private bool CheckPartnerIdUsedInEntity(long partnerId) => this.PartnerRepository.CheckPartnerIdUsedInEntity(partnerId);

    public SaveResult Save(PartnerViewModel thePartner)
    {
      try
      {
        this.GetSafeObject<PartnerViewModel>(thePartner);
        long partnerId = thePartner.PartnerID;
        SaveResult saveResult = thePartner.IsPartnerContactAdded ? new SaveResult() : thePartner.Validate<PartnerViewModel>();
        saveResult.Id = partnerId;
        if (thePartner.PartnerContacts != null)
        {
          List<SaveResult> saveResultList = this.ValidateContacts(thePartner.PartnerContacts);
          if (saveResultList.Count > 0)
            saveResult.Errors.Add("Contacts", (object) saveResultList);
        }
        if (thePartner.PartnerContactAddress != null)
        {
          List<SaveResult> saveResultList = this.ValidateContactAddress(thePartner.PartnerContactAddress);
          if (saveResultList.Count > 0)
            saveResult.Errors.Add("PartnerAddress", (object) saveResultList);
        }
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.PartnerRepository.Save(thePartner.GetPartnerDatail(thePartner));
            saveResult.Id = num;
            if (num == -100L)
              saveResult.Errors.Add("Partner Name", (object) "Duplicate partner name.");
            if (num == -200L)
              saveResult.Errors.Add("Contact Email", (object) "Contacts cannot have same email address.");
            if (saveResult.IsSuccessful)
              transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private List<SaveResult> ValidateContacts(
      List<PartnerDetailViewModel> partnerDetailViewModel)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (PartnerDetailViewModel partnerDetailViewModel1 in partnerDetailViewModel)
      {
        SaveResult saveResult = partnerDetailViewModel1.Validate<PartnerDetailViewModel>();
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = partnerDetailViewModel1.PartnerContactID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    private List<SaveResult> ValidateContactAddress(
      List<PartnerContactDetailViewModel> partnerContactDetailViewModel)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (PartnerContactDetailViewModel contactDetailViewModel in partnerContactDetailViewModel)
      {
        SaveResult saveResult = contactDetailViewModel.Validate<PartnerContactDetailViewModel>();
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = contactDetailViewModel.PartnerContactAddressID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    public List<KeyPair> GetPartnersByType(
      string partnerName,
      string partnerTypeName,
      bool isAllRecords)
    {
      try
      {
        List<KeyPair> keyPairList = new List<KeyPair>();
        using (IDataReader dataReader = this.PartnerRepository.FetchPartnersByType(partnerName, partnerTypeName, isAllRecords))
        {
          if (dataReader != null)
          {
            IRowMapper<KeyPair> rowMapper = MapBuilder<KeyPair>.MapAllProperties().Map<string>((Expression<Func<KeyPair, string>>) (x => x.Key)).ToColumn("PartnerID").Map<string>((Expression<Func<KeyPair, string>>) (x => x.Value)).ToColumn("Name").Build();
            while (dataReader.Read())
              keyPairList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return keyPairList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<KeyPair>();
      }
    }

    public SaveResult UpdateContactDetails(PartnerDetailViewModel partnerDetailViewModel)
    {
      try
      {
        this.GetSafeObject<PartnerDetailViewModel>(partnerDetailViewModel);
        long partnerContactId = partnerDetailViewModel.PartnerContactID;
        SaveResult saveResult = partnerDetailViewModel.Validate<PartnerDetailViewModel>();
        saveResult.Id = partnerContactId;
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.PartnerRepository.UpdateContactDetails(partnerDetailViewModel.GetPartnerContact());
            saveResult.Id = num;
            if (num == -200L)
              saveResult.Errors.Add("Contact Email", (object) "Contacts cannot have same email address.");
            transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys() => this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetPartnerLookupKeys());

    private string[] GetPartnerLookupKeys() => new string[1]
    {
      "Contact Title"
    };
  }
}
