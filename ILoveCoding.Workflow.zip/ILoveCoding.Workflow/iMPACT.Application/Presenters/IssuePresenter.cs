﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.IssuePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.Core.Mail;
using IrisSoftware.Core.Reflection;
using IrisSoftware.Core.SearchCriteria;
using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using Microsoft.Reporting.WebForms;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (IssuePresenter))]
  public class IssuePresenter : PresenterBase
  {
    private DateTime SharePointMinDate = new DateTime(1900, 1, 1);
    private DataSet pipelineDS = new DataSet();
    private const string RepricingReportName = "RepricingReport.pdf";
    private const string FinalPricingReportName = "FinalPricingReport.pdf";
    private const string PreliminaryPricingReportName = "PreliminaryPricing Report.pdf";
    private List<IssueEnums.IssueStatus> issueCurrentStatus;
    private DataSet pricingDs = new DataSet();
    private string[] partnersEmailAddress;
    private string InfoReceipts = "";
    private List<long> rcIssueStatusList;
    private List<IssueEnums.IssueStatus> rcIssueCurrentStatus;
    private List<long> muccIssueStatusList;
    private List<IssueEnums.IssueStatus> muccIssueCurrentStatus;
    private static readonly HashSet<string> dateColumnsToAdjust = new HashSet<string>((IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)
    {
      "DateHired",
      "G17RoleLetterSentDate",
      "G17RoleLetterAckDate",
      "G17ConflictLetterSentDate",
      "G17ConflictLetterAckDate",
      "G17RoleDisclosureLetterSentDate",
      "G17RoleDisclosureLetterAckDate",
      "G17StructureLetterSentDate",
      "G17StructureLetterAckDate",
      "RFPMAExemptionStartDate",
      "RFPMAExemptionExpirationDate",
      "IRMAMAExemptionStartDate",
      "IRMAMAExemptionExpirationDate",
      "UWMAExemptionStartDate",
      "UWMAExemptionExpirationDate",
      "NoneMAExemptionStartDate",
      "NoneMAExemptionExpirationDate",
      "GoodFaithDate",
      "CommitmentCommitteeApprovalDate",
      "PricingDate",
      "ExpectedAwardDate",
      "ActualAwardDate",
      "SettlementDate",
      "ARDSubmissionDate",
      "G37SettlementDate",
      "DateCounselApprovedByLegal",
      "FinalOSReceivedDate",
      "DateApprovedByMUCC",
      "G32SubmissionDate",
      "SeriesDatedDate",
      "FirstCouponDate",
      "SeriesSettlementDate",
      "SeriesCallDate",
      "CEExpirationDate",
      "FinalMaturity",
      "FirstMaturity",
      "LiquidityAgreementUploadDate",
      "IssuePriceCertReviewDate",
      "ROPDate",
      "FormalDueDiligenceDate",
      "OSDeemedFinalDate",
      "SeriesActualAwardDate"
    };

    [Dependency]
    public UploadDocumentPresenter UploadDocPresenter { get; set; }

    [Dependency]
    public IEntityDocSetTypeRepository EntityDocSetTypeRepository { get; set; }

    [Dependency]
    public IAppTransactionDocSetRepository appTransactionDocSetRepository { get; set; }

    [Dependency]
    public IAppTransactionDocSetDocumentRepository appTransactionDocSetDocumentRepository { get; set; }

    [Dependency]
    public UploadDocumentPresenter uploadDocumentPresenter { get; set; }

    public void PerformSharePointDocumentSetOperations(
      long issueId,
      IrisSoftware.iMPACT.Data.Issue oldIssue,
      IrisSoftware.iMPACT.Data.Issue newIssue)
    {
      try
      {
        bool hasAnyPropChanged;
        Hashtable properties = this.PopulateDocumentProperties(issueId, oldIssue, newIssue, out hasAnyPropChanged);
        List<AppTransactionDocSet> transactionDocSetList = this.AppTransactionDocSetRepository.FetchByAppTransactionID(issueId);
        List<EntityDocSetType> entityDocSetTypeList = this.EntityDocSetTypeRepository.FetchEntityDocSetTypeByEntityID(-32L);
        string libLocation = this.AppTransactionDocSetRepository.FetchLibraryURLByEntityTypeID(-32L);
        List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
        foreach (EntityDocSetType entityDocSetType in entityDocSetTypeList)
        {
          EntityDocSetType docSetType = entityDocSetType;
          IssuePresenter.GetRepositoryLevelProperties_New(properties, docSetType);
          List<DocSetPermission> docSetPermissions = this.GetDocSetPermissions(issueId, docSetType.EntityDocSetTypeID);
          int num1;
          if (!transactionDocSetList.Exists((Predicate<AppTransactionDocSet>) (x =>
          {
            long? entityDocSetTypeId1 = x.EntityDocSetTypeID;
            long entityDocSetTypeId2 = docSetType.EntityDocSetTypeID;
            return entityDocSetTypeId1.GetValueOrDefault() == entityDocSetTypeId2 && entityDocSetTypeId1.HasValue;
          })))
          {
            this.CreateIssueDocumentSets(issueId, properties, libLocation, docSetType, docSetPermissions);
            long? nullable1 = newIssue.IssueDetail.IssuerID;
            if (nullable1.HasValue)
            {
              foreach (AppTransactionDocSet transactionDocSet in this.AppTransactionDocSetRepository.FetchByAppTransactionID(issueId))
              {
                nullable1 = transactionDocSet.EntityDocSetTypeID;
                long num2 = 20;
                if ((nullable1.GetValueOrDefault() == num2 ? (nullable1.HasValue ? 1 : 0) : 0) != 0)
                {
                  List<UploadDocumentViewModel> list = this.appTransactionDocSetRepository.FetchByKey(-1L, Convert.ToInt64((object) newIssue.IssueDetail.IssuerID), (long) this.AppUser.Id).Select<AppTransactionDocSet, UploadDocumentViewModel>((Func<AppTransactionDocSet, UploadDocumentViewModel>) (x => new UploadDocumentViewModel(x))).ToList<UploadDocumentViewModel>();
                  IClientRepository clientRepository = this.ClientRepository;
                  nullable1 = newIssue.IssueDetail.IssuerID;
                  long currentId = nullable1.Value;
                  Client client = clientRepository.FetchClientDetailsOnlyByKey(currentId);
                  this.CopyDocumentsToTransaction(list, issueId, Convert.ToInt64((object) newIssue.IssueDetail.IssuerID), Convert.ToString(transactionDocSet.DocSetID), docSetType.DocSetName, libLocation, client.ExternalClientID);
                }
              }
            }
            nullable1 = newIssue.IssueDetail.BorrowerID;
            if (nullable1.HasValue)
            {
              nullable1 = newIssue.IssueDetail.BorrowerID;
              long? issuerId = newIssue.IssueDetail.IssuerID;
              if ((nullable1.GetValueOrDefault() == issuerId.GetValueOrDefault() ? (nullable1.HasValue != issuerId.HasValue ? 1 : 0) : 1) != 0)
              {
                foreach (AppTransactionDocSet transactionDocSet in this.AppTransactionDocSetRepository.FetchByAppTransactionID(issueId))
                {
                  long? nullable2 = transactionDocSet.EntityDocSetTypeID;
                  long num2 = 20;
                  if ((nullable2.GetValueOrDefault() == num2 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
                  {
                    List<UploadDocumentViewModel> list = this.appTransactionDocSetRepository.FetchByKey(-1L, Convert.ToInt64((object) newIssue.IssueDetail.BorrowerID), (long) this.AppUser.Id).Select<AppTransactionDocSet, UploadDocumentViewModel>((Func<AppTransactionDocSet, UploadDocumentViewModel>) (x => new UploadDocumentViewModel(x))).ToList<UploadDocumentViewModel>();
                    IClientRepository clientRepository = this.ClientRepository;
                    nullable2 = newIssue.IssueDetail.BorrowerID;
                    long currentId = nullable2.Value;
                    Client client = clientRepository.FetchClientDetailsOnlyByKey(currentId);
                    this.CopyDocumentsToTransaction(list, issueId, Convert.ToInt64((object) newIssue.IssueDetail.BorrowerID), Convert.ToString(transactionDocSet.DocSetID), docSetType.DocSetName, libLocation, client.ExternalClientID);
                  }
                }
              }
            }
            bool? parentOpportunity = newIssue.IssueDetail.IsIssueInitiatedFromParentOpportunity;
            bool flag = true;
            if ((parentOpportunity.GetValueOrDefault() == flag ? (parentOpportunity.HasValue ? 1 : 0) : 0) != 0)
            {
              foreach (AppTransactionDocSet transactionDocSet in this.AppTransactionDocSetRepository.FetchByAppTransactionID(issueId))
              {
                long? entityDocSetTypeId = transactionDocSet.EntityDocSetTypeID;
                long num2 = 20;
                if ((entityDocSetTypeId.GetValueOrDefault() == num2 ? (entityDocSetTypeId.HasValue ? 1 : 0) : 0) != 0)
                  this.CopyDocumentsToTransaction(this.appTransactionDocSetRepository.FetchByKey(-33L, Convert.ToInt64((object) newIssue.IssueDetail.ParentOpportunityID), (long) this.AppUser.Id).Select<AppTransactionDocSet, UploadDocumentViewModel>((Func<AppTransactionDocSet, UploadDocumentViewModel>) (x => new UploadDocumentViewModel(x))).ToList<UploadDocumentViewModel>(), issueId, Convert.ToInt64((object) newIssue.IssueDetail.ParentOpportunityID), Convert.ToString(transactionDocSet.DocSetID), docSetType.DocSetName, libLocation);
              }
            }
          }
          else if (newIssue.InternalPartners != null && newIssue.InternalPartners.Any<InternalPartner>((Func<InternalPartner, bool>) (x => x.IsDirty)))
          {
            UploadDocumentPresenter uploadDocPresenter = this.UploadDocPresenter;
            num1 = -32;
            string entityType = num1.ToString();
            num1 = transactionDocSetList.Find((Predicate<AppTransactionDocSet>) (x => x.EntityDocSetTypeID.Value == docSetType.EntityDocSetTypeID)).DocSetID;
            string docSetId = num1.ToString();
            List<DocSetPermission> issueDocSetPermissions = docSetPermissions;
            Hashtable sharedFields = properties;
            uploadDocPresenter.ApplyPermission(entityType, docSetId, issueDocSetPermissions, sharedFields);
          }
          else if (hasAnyPropChanged)
          {
            UploadDocumentPresenter uploadDocPresenter = this.UploadDocPresenter;
            num1 = -32;
            string entityType = num1.ToString();
            num1 = transactionDocSetList.Find((Predicate<AppTransactionDocSet>) (x => x.EntityDocSetTypeID.Value == docSetType.EntityDocSetTypeID)).DocSetID;
            string docSetId = num1.ToString();
            Hashtable sharedFields = properties;
            uploadDocPresenter.UpdateSharedFields(entityType, docSetId, sharedFields);
          }
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
      }
    }

    private void CopyDocumentsToTransaction(
      List<UploadDocumentViewModel> uploadDocumentViewModel,
      long issueId,
      long issuerID,
      string docSetId,
      string docSetTypeName,
      string libLocation,
      string clientExternalID = null)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      IssuePresenter.\u003C\u003Ec__DisplayClass22_0 cDisplayClass220 = new IssuePresenter.\u003C\u003Ec__DisplayClass22_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass220.libLocation = libLocation;
      foreach (UploadDocumentViewModel documentViewModel in uploadDocumentViewModel)
      {
        foreach (Document document in this.appTransactionDocSetDocumentRepository.GetDocumentsToBeCopiedToTransaction(issuerID, documentViewModel.EntityDocSetTypeID.Value))
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          IssuePresenter.\u003C\u003Ec__DisplayClass22_1 cDisplayClass221 = new IssuePresenter.\u003C\u003Ec__DisplayClass22_1();
          // ISSUE: reference to a compiler-generated field
          cDisplayClass221.CS\u0024\u003C\u003E8__locals1 = cDisplayClass220;
          // ISSUE: reference to a compiler-generated field
          cDisplayClass221.doc = document;
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          IssuePresenter.\u003C\u003Ec__DisplayClass22_2 cDisplayClass222 = new IssuePresenter.\u003C\u003Ec__DisplayClass22_2();
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2 = cDisplayClass221;
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.bytes = (byte[]) null;
          // ISSUE: method pointer
          SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass222, __methodptr(\u003CCopyDocumentsToTransaction\u003Eb__0)));
          if (!string.IsNullOrEmpty(clientExternalID))
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.DocumentName = cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.DocumentName.Split('.')[0] + "_" + clientExternalID + "." + cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.DocumentName.Split('.')[1];
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.EntityID = issueId;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.DocSetId = docSetId;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.DocSetName = docSetTypeName;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.DocSetURL = cDisplayClass222.CS\u0024\u003C\u003E8__locals2.CS\u0024\u003C\u003E8__locals1.libLocation;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeID = cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeID;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeCategoryID = cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeCategoryID;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc.EntityType = -32.ToString();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          this.uploadDocumentPresenter.Upload(cDisplayClass222.CS\u0024\u003C\u003E8__locals2.doc, cDisplayClass222.bytes);
        }
      }
    }

    private void CopyClientDocumentsToTransaction(
      long issueId,
      long issuerID,
      string docSetId,
      string docSetTypeName,
      string libLocation)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      IssuePresenter.\u003C\u003Ec__DisplayClass23_0 cDisplayClass230 = new IssuePresenter.\u003C\u003Ec__DisplayClass23_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass230.libLocation = libLocation;
      foreach (UploadDocumentViewModel documentViewModel in this.appTransactionDocSetRepository.FetchByKey(-1L, issuerID, (long) this.AppUser.Id).Select<AppTransactionDocSet, UploadDocumentViewModel>((Func<AppTransactionDocSet, UploadDocumentViewModel>) (x => new UploadDocumentViewModel(x))).ToList<UploadDocumentViewModel>())
      {
        foreach (Document document in this.appTransactionDocSetDocumentRepository.GetDocumentsToBeCopiedToTransaction(issuerID, documentViewModel.EntityDocSetTypeID.Value))
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          IssuePresenter.\u003C\u003Ec__DisplayClass23_1 cDisplayClass231 = new IssuePresenter.\u003C\u003Ec__DisplayClass23_1();
          // ISSUE: reference to a compiler-generated field
          cDisplayClass231.CS\u0024\u003C\u003E8__locals1 = cDisplayClass230;
          // ISSUE: reference to a compiler-generated field
          cDisplayClass231.doc = document;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (cDisplayClass231.doc.EntityTypeDocTypeID == Convert.ToString(-4) || cDisplayClass231.doc.EntityTypeDocTypeID == Convert.ToString(-5) || cDisplayClass231.doc.EntityTypeDocTypeID == Convert.ToString(-6))
          {
            // ISSUE: object of a compiler-generated type is created
            // ISSUE: variable of a compiler-generated type
            IssuePresenter.\u003C\u003Ec__DisplayClass23_2 cDisplayClass232 = new IssuePresenter.\u003C\u003Ec__DisplayClass23_2();
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2 = cDisplayClass231;
            string empty = string.Empty;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeID == Convert.ToString(-4))
            {
              empty = Convert.ToString(-1);
            }
            else
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if (cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeID == Convert.ToString(-5))
              {
                empty = Convert.ToString(-2);
              }
              else
              {
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                if (cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeID == Convert.ToString(-6))
                  empty = Convert.ToString(-3);
              }
            }
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.bytes = (byte[]) null;
            // ISSUE: method pointer
            SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass232, __methodptr(\u003CCopyClientDocumentsToTransaction\u003Eb__1)));
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.EntityID = issueId;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.DocSetId = docSetId;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.DocSetName = docSetTypeName;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.DocSetURL = cDisplayClass232.CS\u0024\u003C\u003E8__locals2.CS\u0024\u003C\u003E8__locals1.libLocation;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeID = empty;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.EntityTypeDocTypeCategoryID = Convert.ToString(-1);
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc.EntityType = -32.ToString();
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            this.uploadDocumentPresenter.Upload(cDisplayClass232.CS\u0024\u003C\u003E8__locals2.doc, cDisplayClass232.bytes);
          }
        }
      }
    }

    private static void GetRepositoryLevelProperties_New(
      Hashtable properties,
      EntityDocSetType docSetType)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) docSetType.DocSetName;
      else
        properties.Add((object) "Title", (object) docSetType.DocSetName);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) docSetType.EntityDocSetTypeID;
      else
        properties.Add((object) "iDocSetType", (object) docSetType.EntityDocSetTypeID);
    }

    private static void GetRepositoryLevelProperties(Hashtable properties, LookupItem repository)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) repository.Value;
      else
        properties.Add((object) "Title", (object) repository.Value);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) repository.LookupItemID;
      else
        properties.Add((object) "iDocSetType", (object) repository.LookupItemID);
    }

    private void CreateIssueDocumentSets(
      long issueId,
      Hashtable properties,
      string libLocation,
      EntityDocSetType docSetType,
      List<DocSetPermission> docSetPermissions)
    {
      DocSetInfo docSet = this.UploadDocPresenter.CreateDocSet(new DocSetInfo()
      {
        AppTransactionId = issueId,
        DocSetName = docSetType.DocSetName,
        EntityType = -32.ToString(),
        URL = libLocation
      }, docSetPermissions, properties);
      this.SaveAppTransactionDetails(new AppTransactionDocSet()
      {
        EntityID = issueId,
        EntityDocSetTypeID = new long?(docSetType.EntityDocSetTypeID),
        DocSetTypeValue = docSetType.DocSetName,
        URL = libLocation,
        DocSetID = Convert.ToInt32(docSet.DocSetId)
      });
    }

    private List<DocSetPermission> GetDocSetPermissions(
      long appId,
      long docSetType)
    {
      string empty = string.Empty;
      List<DocSetPermission> docSetPermissionList1 = new List<DocSetPermission>();
      List<DocSetPermission> docSetPermissionList2 = this.AppTransactionDocSetRepository.FetchIssueRepositoryPermissionsByAppTransID(appId, -32);
      List<DocSetPermission> repositoryUploadPermissionList = docSetPermissionList2.FindAll((Predicate<DocSetPermission>) (p => p.RepositoryID == docSetType && p.Permission.ToLower() == "upload"));
      List<DocSetPermission> all = docSetPermissionList2.FindAll((Predicate<DocSetPermission>) (p => p.RepositoryID == docSetType && p.Permission.ToLower() == "view" && !repositoryUploadPermissionList.Exists((Predicate<DocSetPermission>) (u => u.PrincipalId == p.PrincipalId))));
      foreach (DocSetPermission docSetPermission in repositoryUploadPermissionList)
        docSetPermissionList1.Add(new DocSetPermission()
        {
          Permission = "Upload",
          PrincipalId = docSetPermission.PrincipalId,
          PermissionId = 0
        });
      foreach (DocSetPermission docSetPermission in all)
        docSetPermissionList1.Add(new DocSetPermission()
        {
          Permission = "view",
          PrincipalId = docSetPermission.PrincipalId,
          PermissionId = 0
        });
      return docSetPermissionList1;
    }

    private void SaveAppTransactionDetails(AppTransactionDocSet appTransactionDocSet) => this.AppTransactionDocSetRepository.Save(appTransactionDocSet);

    private Hashtable PopulateDocumentProperties(
      long issueId,
      IrisSoftware.iMPACT.Data.Issue oldIssue,
      IrisSoftware.iMPACT.Data.Issue newIssue,
      out bool hasAnyPropChanged)
    {
      hasAnyPropChanged = false;
      Hashtable hashtable1 = this.PopulateProperties(issueId, oldIssue);
      Hashtable hashtable2 = this.PopulateProperties(issueId, newIssue);
      foreach (DictionaryEntry dictionaryEntry in hashtable2)
      {
        if (hashtable1.ContainsKey(dictionaryEntry.Key))
        {
          if (!hashtable1[dictionaryEntry.Key].Equals(dictionaryEntry.Value))
          {
            hasAnyPropChanged = true;
            break;
          }
        }
        else
        {
          hasAnyPropChanged = true;
          break;
        }
      }
      return hashtable2;
    }

    private Hashtable PopulateProperties(long issueId, IrisSoftware.iMPACT.Data.Issue issue)
    {
      Hashtable hashtable1 = new Hashtable();
      string str = string.Empty;
      if (issue.IssueDetail.IssueStatus != null)
        str = string.Join(",", issue.IssueDetail.IssueStatus.Select<long, string>((Func<long, string>) (s => s.ToString())).ToArray<string>());
      hashtable1.Add((object) "iRefID", (object) (Convert.ToString(issueId) ?? string.Empty));
      hashtable1.Add((object) "iEntityNbr", (object) (issue.IssueDetail.IssueNbr ?? string.Empty));
      hashtable1.Add((object) "iEntityName", (object) (issue.IssueDetail.IssueName ?? string.Empty));
      hashtable1.Add((object) "iEntityStatus", (object) str);
      hashtable1.Add((object) "iState", (object) (Convert.ToString((object) issue.IssueDetail.State) ?? string.Empty));
      Hashtable hashtable2 = hashtable1;
      long? nullable = issue.IssueDetail.FirmRole;
      string empty1;
      if (!nullable.HasValue)
      {
        empty1 = string.Empty;
      }
      else
      {
        nullable = issue.IssueDetail.FirmRole;
        empty1 = nullable.ToString();
      }
      hashtable2.Add((object) "iFirmRole", (object) empty1);
      Hashtable hashtable3 = hashtable1;
      nullable = issue.IssueDetail.IssuerID;
      string empty2;
      if (!nullable.HasValue)
      {
        empty2 = string.Empty;
      }
      else
      {
        nullable = issue.IssueDetail.IssuerID;
        empty2 = nullable.ToString();
      }
      hashtable3.Add((object) "iIssuerID", (object) empty2);
      Hashtable hashtable4 = hashtable1;
      nullable = issue.IssueDetail.BorrowerID;
      string empty3;
      if (!nullable.HasValue)
      {
        empty3 = string.Empty;
      }
      else
      {
        nullable = issue.IssueDetail.BorrowerID;
        empty3 = nullable.ToString();
      }
      hashtable4.Add((object) "iBorrowerID", (object) empty3);
      Hashtable hashtable5 = hashtable1;
      Decimal? parAmount = issue.IssueDetail.ParAmount;
      string empty4;
      if (!parAmount.HasValue)
      {
        empty4 = string.Empty;
      }
      else
      {
        parAmount = issue.IssueDetail.ParAmount;
        empty4 = parAmount.ToString();
      }
      hashtable5.Add((object) "iParAmount", (object) empty4);
      if (issue.IssueDetail.CreatedOn.Date == DateTime.MinValue.Date)
        hashtable1.Add((object) "iCreateDate", (object) DateTime.Now);
      return hashtable1;
    }

    private void SaveDistributionListInRepository(
      long appTransactionID,
      ExportResult distributionListReport,
      out bool uploadResult)
    {
      uploadResult = false;
      List<AppTransactionDocSet> list = this.AppTransactionDocSetRepository.FetchByKey(-32L, appTransactionID).ToList<AppTransactionDocSet>();
      if (list == null || list.Count <= 0)
        return;
      DocumentInfo documentInfo = new DocumentInfo();
      AppTransactionDocSet transactionDocSet = list.Find((Predicate<AppTransactionDocSet>) (x =>
      {
        long? entityDocSetTypeId = x.EntityDocSetTypeID;
        long num = 20;
        return entityDocSetTypeId.GetValueOrDefault() == num && entityDocSetTypeId.HasValue;
      }));
      documentInfo.Category = Convert.ToString(14);
      documentInfo.Type = Convert.ToString(-59);
      if (transactionDocSet == null)
        return;
      this.UploadDocPresenter.Upload(new Document()
      {
        DocumentName = "DistributionListReport.xls",
        DocSetURL = transactionDocSet.URL,
        DocSetId = transactionDocSet.DocSetID.ToString(),
        EntityID = appTransactionID,
        EntityTypeDocTypeID = Convert.ToString(-59),
        Tags = string.Empty,
        EntityTypeDocTypeCategoryID = Convert.ToString(14),
        EntityType = -32.ToString()
      }, distributionListReport.Data);
      uploadResult = true;
    }

    private void SaveRegulatoryRequirementChecklistInRepository(
      long appTransactionID,
      ExportResult regulatoryCheckListReport,
      out bool uploadResult)
    {
      uploadResult = false;
      List<AppTransactionDocSet> list = this.AppTransactionDocSetRepository.FetchByKey(-32L, appTransactionID).ToList<AppTransactionDocSet>();
      if (list == null || list.Count <= 0)
        return;
      DocumentInfo documentInfo = new DocumentInfo();
      AppTransactionDocSet transactionDocSet = list.Find((Predicate<AppTransactionDocSet>) (x =>
      {
        long? entityDocSetTypeId = x.EntityDocSetTypeID;
        long num = 20;
        return entityDocSetTypeId.GetValueOrDefault() == num && entityDocSetTypeId.HasValue;
      }));
      documentInfo.Category = Convert.ToString(13);
      documentInfo.Type = Convert.ToString(-13);
      if (transactionDocSet == null)
        return;
      this.UploadDocPresenter.Upload(new Document()
      {
        DocumentName = "RegulatoryRequirementChecklist.pdf",
        DocSetURL = transactionDocSet.URL,
        DocSetId = transactionDocSet.DocSetID.ToString(),
        EntityID = appTransactionID,
        EntityTypeDocTypeID = Convert.ToString(-13),
        Tags = string.Empty,
        EntityTypeDocTypeCategoryID = Convert.ToString(13),
        EntityType = -32.ToString()
      }, regulatoryCheckListReport.Data);
      uploadResult = true;
    }

    private void SaveMUCCPresentationInRepository(
      long appTransactionID,
      ExportResult muccPresentationReport,
      out bool uploadResult)
    {
      uploadResult = false;
      List<AppTransactionDocSet> list = this.AppTransactionDocSetRepository.FetchByKey(-32L, appTransactionID).ToList<AppTransactionDocSet>();
      if (list == null || list.Count <= 0)
        return;
      DocumentInfo documentInfo = new DocumentInfo();
      AppTransactionDocSet transactionDocSet = list.Find((Predicate<AppTransactionDocSet>) (x =>
      {
        long? entityDocSetTypeId = x.EntityDocSetTypeID;
        long num = 20;
        return entityDocSetTypeId.GetValueOrDefault() == num && entityDocSetTypeId.HasValue;
      }));
      documentInfo.Category = Convert.ToString(13);
      documentInfo.Type = Convert.ToString(-1015);
      if (transactionDocSet == null)
        return;
      this.UploadDocPresenter.Upload(new Document()
      {
        DocumentName = "MUCCPresentation.pdf",
        DocSetURL = transactionDocSet.URL,
        DocSetId = transactionDocSet.DocSetID.ToString(),
        EntityID = appTransactionID,
        EntityTypeDocTypeID = Convert.ToString(-1015),
        Tags = string.Empty,
        EntityTypeDocTypeCategoryID = Convert.ToString(13),
        EntityType = -32.ToString()
      }, muccPresentationReport.Data);
      uploadResult = true;
    }

    private string GetPricingDocumentURL(long appTransID, string fileUrl)
    {
      List<AppTransactionDocSet> list = this.AppTransactionDocSetRepository.FetchByKey(-32L, appTransID).ToList<AppTransactionDocSet>();
      if (list != null && list.Count > 0)
      {
        AppTransactionDocSet transactionDocSet = list.Find((Predicate<AppTransactionDocSet>) (x =>
        {
          long? entityDocSetTypeId = x.EntityDocSetTypeID;
          long num = 20;
          return entityDocSetTypeId.GetValueOrDefault() == num && entityDocSetTypeId.HasValue;
        }));
        DocSetInfo docSetInfo = new DocSetInfo()
        {
          AppTransactionId = appTransID,
          DocSetId = transactionDocSet.DocSetID.ToString(),
          DocSetName = transactionDocSet.DocSetTypeValue,
          EntityType = -32.ToString(),
          URL = transactionDocSet.URL
        };
        Document document = this.UploadDocPresenter.GetDocuments(-32.ToString(), transactionDocSet.DocSetID.ToString()).Where<Document>((Func<Document, bool>) (x => x.DocumentName == "FinalPricingReport.pdf")).FirstOrDefault<Document>();
        if (document != null)
          fileUrl = document.DocumentURL;
      }
      return fileUrl;
    }

    private void SavePricingInRepository(
      long appTransactionID,
      long pricingStatus,
      string pricingStatusValue,
      ExportResult pricingReport)
    {
      List<AppTransactionDocSet> list = this.AppTransactionDocSetRepository.FetchByKey(-32L, appTransactionID).ToList<AppTransactionDocSet>();
      if (list == null || list.Count <= 0)
        return;
      Document doc = new Document();
      doc.EntityID = appTransactionID;
      doc.EntityType = -32.ToString();
      doc.Tags = string.Empty;
      AppTransactionDocSet transactionDocSet;
      if (-37L == pricingStatus)
      {
        transactionDocSet = list.Find((Predicate<AppTransactionDocSet>) (x =>
        {
          long? entityDocSetTypeId = x.EntityDocSetTypeID;
          long num = 20;
          return entityDocSetTypeId.GetValueOrDefault() == num && entityDocSetTypeId.HasValue;
        }));
        doc.DocumentName = "FinalPricingReport.pdf";
        doc.EntityTypeDocTypeCategoryID = Convert.ToString(14);
        doc.EntityTypeDocTypeID = Convert.ToString(-60);
      }
      else
      {
        transactionDocSet = list.Find((Predicate<AppTransactionDocSet>) (x =>
        {
          long? entityDocSetTypeId = x.EntityDocSetTypeID;
          long num = 20;
          return entityDocSetTypeId.GetValueOrDefault() == num && entityDocSetTypeId.HasValue;
        }));
        doc.EntityTypeDocTypeCategoryID = Convert.ToString(14);
        if (-35L == pricingStatus)
        {
          doc.DocumentName = "PreliminaryPricing Report.pdf";
          doc.EntityTypeDocTypeID = Convert.ToString(-61);
        }
        else if (-36L == pricingStatus)
        {
          doc.DocumentName = "RepricingReport.pdf";
          doc.EntityTypeDocTypeID = Convert.ToString(-62);
        }
      }
      if (transactionDocSet == null)
        return;
      doc.DocSetURL = transactionDocSet.URL;
      doc.DocSetId = transactionDocSet.DocSetID.ToString();
      this.UploadDocPresenter.Upload(doc, pricingReport.Data);
    }

    public IssuePipelineViewModel GetIssuePipeline()
    {
      try
      {
        return this.BindIssuePipelineFromReader(this.IssueRepository.FetchIssuePipeline(-43L));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        IssuePipelineViewModel pipelineViewModel = new IssuePipelineViewModel();
        pipelineViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return pipelineViewModel;
      }
    }

    public ExportResult ExportIssuePipeline(string type)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      IssuePresenter.\u003C\u003Ec__DisplayClass38_2 cDisplayClass382 = new IssuePresenter.\u003C\u003Ec__DisplayClass38_2();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass382.type = type;
      try
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        IssuePresenter.\u003C\u003Ec__DisplayClass38_0 cDisplayClass380 = new IssuePresenter.\u003C\u003Ec__DisplayClass38_0();
        // ISSUE: reference to a compiler-generated field
        cDisplayClass380.CS\u0024\u003C\u003E8__locals1 = cDisplayClass382;
        IDataReader reader = this.IssueRepository.FetchIssuePipeline(-43L);
        DataTable table1 = new DataTable();
        table1.TableName = "IssueData";
        DataTable table2 = new DataTable();
        table2.TableName = "SeriesData";
        this.pipelineDS.Tables.Add(table1);
        this.pipelineDS.Tables.Add(table2);
        this.pipelineDS.Load(reader, LoadOption.OverwriteChanges, table1, table2);
        // ISSUE: reference to a compiler-generated field
        cDisplayClass380.bytes = (byte[]) null;
        string empty = string.Empty;
        // ISSUE: reference to a compiler-generated field
        cDisplayClass380.mimeType = "";
        // ISSUE: reference to a compiler-generated field
        cDisplayClass380.extension = "";
        string genericSetupPath = SPUtility.GetGenericSetupPath("_layouts/iMPACT/Reports/TransactionPipelineReport.rdlc".Replace("_layouts", "TEMPLATE\\LAYOUTS"));
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        IssuePresenter.\u003C\u003Ec__DisplayClass38_1 cDisplayClass381 = new IssuePresenter.\u003C\u003Ec__DisplayClass38_1();
        // ISSUE: reference to a compiler-generated field
        cDisplayClass381.CS\u0024\u003C\u003E8__locals2 = cDisplayClass380;
        // ISSUE: reference to a compiler-generated field
        cDisplayClass381.report = new ReportViewer();
        try
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          IssuePresenter.\u003C\u003Ec__DisplayClass38_3 cDisplayClass383 = new IssuePresenter.\u003C\u003Ec__DisplayClass38_3();
          // ISSUE: reference to a compiler-generated field
          cDisplayClass383.CS\u0024\u003C\u003E8__locals3 = cDisplayClass381;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass383.CS\u0024\u003C\u003E8__locals3.report.set_ProcessingMode((ProcessingMode) 0);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass383.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().set_ReportPath(genericSetupPath);
          ReportDataSource reportDataSource1 = new ReportDataSource("IssueData", this.UpdateOfferingTypeIDs(this.pipelineDS.Tables[0]));
          ReportDataSource reportDataSource2 = new ReportDataSource("SeriesData", this.pipelineDS.Tables[1]);
          ReportParameter reportParameter = new ReportParameter("CurrentDateTime", DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)");
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass383.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Clear();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Report) cDisplayClass383.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport()).SetParameters((IEnumerable<ReportParameter>) new ReportParameter[1]
          {
            reportParameter
          });
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass383.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Add(reportDataSource1);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass383.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Add(reportDataSource2);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: method pointer
          cDisplayClass383.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().add_SubreportProcessing(new SubreportProcessingEventHandler((object) this, __methodptr(Report_SubreportProcessing)));
          // ISSUE: reference to a compiler-generated field
          cDisplayClass383.deviceInfo = (string) null;
          // ISSUE: method pointer
          SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass383, __methodptr(\u003CExportIssuePipeline\u003Eb__0)));
        }
        finally
        {
          // ISSUE: reference to a compiler-generated field
          if (cDisplayClass381.report != null)
          {
            // ISSUE: reference to a compiler-generated field
            ((IDisposable) cDisplayClass381.report).Dispose();
          }
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        return new ExportResult()
        {
          Data = cDisplayClass380.bytes,
          Filename = "TransactionPipelineReport." + cDisplayClass380.extension,
          MimeType = cDisplayClass380.mimeType
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return (ExportResult) null;
      }
    }

    private DataTable UpdateOfferingTypeIDs(DataTable dt)
    {
      foreach (DataRow row in (InternalDataCollectionBase) dt.Rows)
      {
        if (Convert.ToInt32(row["OfferingType"]) != -54)
        {
          row["OfferingType"] = (object) 108;
          row["OfferingTypeName"] = (object) "Other";
        }
      }
      dt.AcceptChanges();
      return dt;
    }

    private void Report_SubreportProcessing(object sender, SubreportProcessingEventArgs e) => ((Collection<ReportDataSource>) e.get_DataSources()).Add(new ReportDataSource("SeriesData", this.GetReportData(((ReadOnlyCollection<ReportParameterInfo>) e.get_Parameters())[0].get_Values()[0])));

    private DataTable GetReportData(string appTransactionId) => new DataView(this.pipelineDS.Tables[1])
    {
      RowFilter = ("appTransactionId = " + appTransactionId)
    }.ToTable();

    private IssuePipelineViewModel BindIssuePipelineFromReader(
      IDataReader reader)
    {
      List<PipelineViewModel> pipelineViewModelList = new List<PipelineViewModel>();
      List<SeriesPipelineViewModel> source = new List<SeriesPipelineViewModel>();
      if (reader != null)
      {
        IRowMapper<PipelineViewModel> rowMapper1 = MapBuilder<PipelineViewModel>.MapAllProperties().Build();
        while (reader.Read())
          pipelineViewModelList.Add(rowMapper1.MapRow((IDataRecord) reader));
        IRowMapper<SeriesPipelineViewModel> rowMapper2 = MapBuilder<SeriesPipelineViewModel>.MapAllProperties().Build();
        if (reader.NextResult())
        {
          while (reader.Read())
            source.Add(rowMapper2.MapRow((IDataRecord) reader));
        }
      }
      IssuePipelineViewModel pipelineViewModel1 = new IssuePipelineViewModel();
      if (pipelineViewModelList.Count > 0)
      {
        foreach (PipelineViewModel pipelineViewModel2 in pipelineViewModelList)
        {
          PipelineViewModel pipeline = pipelineViewModel2;
          pipeline.Series = source.Where<SeriesPipelineViewModel>((Func<SeriesPipelineViewModel, bool>) (x => x.AppTransactionID == pipeline.AppTransactionID)).ToList<SeriesPipelineViewModel>();
          pipeline.FA = string.IsNullOrEmpty(pipeline.FA) ? pipeline.FA : HttpUtility.HtmlDecode(pipeline.FA);
        }
        pipelineViewModel1.NegotiatedPipeline = pipelineViewModelList;
      }
      return pipelineViewModel1;
    }

    public ExportResult ExportMuccTemplate(string type, long appTransactionId)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      IssuePresenter.\u003C\u003Ec__DisplayClass43_2 cDisplayClass432 = new IssuePresenter.\u003C\u003Ec__DisplayClass43_2();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass432.type = type;
      try
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        IssuePresenter.\u003C\u003Ec__DisplayClass43_0 cDisplayClass430 = new IssuePresenter.\u003C\u003Ec__DisplayClass43_0();
        // ISSUE: reference to a compiler-generated field
        cDisplayClass430.CS\u0024\u003C\u003E8__locals1 = cDisplayClass432;
        IDataReader reader = this.IssueRepository.ExportMuccTemplate(appTransactionId);
        DataTable table1 = new DataTable();
        table1.TableName = "MuccIssueDetails";
        DataTable table2 = new DataTable();
        table2.TableName = "ds_MuccDetails";
        DataTable table3 = new DataTable();
        table3.TableName = "MuccSyndicateSturcture";
        DataTable table4 = new DataTable();
        table4.TableName = "MuccExternalPartner";
        DataTable table5 = new DataTable();
        table5.TableName = "MuccInternalPartner";
        this.pipelineDS.Tables.Add(table1);
        this.pipelineDS.Tables.Add(table2);
        this.pipelineDS.Tables.Add(table3);
        this.pipelineDS.Tables.Add(table4);
        this.pipelineDS.Tables.Add(table5);
        this.pipelineDS.Load(reader, LoadOption.OverwriteChanges, table1, table2, table3, table4, table5);
        // ISSUE: reference to a compiler-generated field
        cDisplayClass430.bytes = (byte[]) null;
        string empty = string.Empty;
        // ISSUE: reference to a compiler-generated field
        cDisplayClass430.mimeType = "";
        // ISSUE: reference to a compiler-generated field
        cDisplayClass430.extension = "";
        string genericSetupPath = SPUtility.GetGenericSetupPath("_layouts/iMPACT/Reports/MuccReport.rdlc".Replace("_layouts", "TEMPLATE\\LAYOUTS"));
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        IssuePresenter.\u003C\u003Ec__DisplayClass43_1 cDisplayClass431 = new IssuePresenter.\u003C\u003Ec__DisplayClass43_1();
        // ISSUE: reference to a compiler-generated field
        cDisplayClass431.CS\u0024\u003C\u003E8__locals2 = cDisplayClass430;
        // ISSUE: reference to a compiler-generated field
        cDisplayClass431.report = new ReportViewer();
        try
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          IssuePresenter.\u003C\u003Ec__DisplayClass43_3 cDisplayClass433 = new IssuePresenter.\u003C\u003Ec__DisplayClass43_3();
          // ISSUE: reference to a compiler-generated field
          cDisplayClass433.CS\u0024\u003C\u003E8__locals3 = cDisplayClass431;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.set_ProcessingMode((ProcessingMode) 0);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().set_ReportPath(genericSetupPath);
          ReportDataSource reportDataSource1 = new ReportDataSource("MuccIssueDetails1", this.pipelineDS.Tables[0]);
          ReportDataSource reportDataSource2 = new ReportDataSource("ds_MuccDetails", this.pipelineDS.Tables[1]);
          ReportDataSource reportDataSource3 = new ReportDataSource("MuccSyndicateSturcture", this.pipelineDS.Tables[2]);
          ReportDataSource reportDataSource4 = new ReportDataSource("MuccExternalPartner", this.pipelineDS.Tables[3]);
          ReportDataSource reportDataSource5 = new ReportDataSource("MuccInternalPartner", this.pipelineDS.Tables[4]);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Clear();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Add(reportDataSource1);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Add(reportDataSource2);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Add(reportDataSource3);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Add(reportDataSource4);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().get_DataSources()).Add(reportDataSource5);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: method pointer
          cDisplayClass433.CS\u0024\u003C\u003E8__locals3.report.get_LocalReport().add_SubreportProcessing(new SubreportProcessingEventHandler((object) this, __methodptr(Report_SubreportProcessing)));
          // ISSUE: reference to a compiler-generated field
          cDisplayClass433.deviceInfo = (string) null;
          // ISSUE: method pointer
          SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass433, __methodptr(\u003CExportMuccTemplate\u003Eb__0)));
        }
        finally
        {
          // ISSUE: reference to a compiler-generated field
          if (cDisplayClass431.report != null)
          {
            // ISSUE: reference to a compiler-generated field
            ((IDisposable) cDisplayClass431.report).Dispose();
          }
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        return new ExportResult()
        {
          Data = cDisplayClass430.bytes,
          Filename = "MUCC Presentation." + cDisplayClass430.extension,
          MimeType = cDisplayClass430.mimeType
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return (ExportResult) null;
      }
    }

    private DataTable UpdateIssueDetails(DataTable dt)
    {
      foreach (DataRow row in (InternalDataCollectionBase) dt.Rows)
      {
        if (Convert.ToInt32(row["OfferingType"]) != -54)
        {
          row["OfferingType"] = (object) 108;
          row["OfferingTypeName"] = (object) "Other";
        }
      }
      dt.AcceptChanges();
      return dt;
    }

    [Dependency]
    public IEventBus EventBus { get; set; }

    [Dependency]
    public IIssueWorkflowFactory WorkflowFactory { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IAuditTrailRepository AuditTrailRepository { get; set; }

    [Dependency]
    public IIssueRepository IssueRepository { get; set; }

    [Dependency]
    public IRestrictedCUSIPRepository RestrictedCUSIPRepository { get; set; }

    [Dependency]
    public IIssueRatingRepository IssueRatingRepository { get; set; }

    [Dependency]
    public IAppTransactionDocSetRepository AppTransactionDocSetRepository { get; set; }

    [Dependency]
    public IIssuePricingRepository IssuePricingRepository { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    [Dependency]
    public IEmailTemplateRepository EmailTemplateRepository { get; set; }

    [Dependency]
    public IMailSender Smtpsender { get; set; }

    [Dependency]
    public IClientRepository ClientRepository { get; set; }

    [Dependency]
    public IManageTemplateRepository ManageTemplateRepository { get; set; }

    [Dependency]
    public IEntityStateRepository EntityStateRepository { get; set; }

    [Dependency]
    public ITemplateRepository TemplateRepository { get; set; }

    [Dependency]
    public IPropertyDescriptorRepository PropertyDescriptorRepository { get; set; }

    [Dependency]
    public IPropertySetValueRepository PropertySetValueRepository { get; set; }

    [Dependency]
    public IPnlRepository PnLRepository { get; set; }

    [Dependency]
    public PnlPresenter PnlPresenter { get; set; }

    public IssueViewModelContainer GetIssueDetailsById(long issueId)
    {
      try
      {
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (issueId > 0L)
        {
          if (!this.HasUIPermissionForEntity(-32L, issueId, "Issue Detail", "View"))
          {
            IssueViewModelContainer viewModelContainer = new IssueViewModelContainer();
            viewModelContainer.ErrorMessage = "401";
            return viewModelContainer;
          }
        }
        else if (!this.HasEntityPermission(-32L, "Issue Detail", "Create"))
        {
          IssueViewModelContainer viewModelContainer = new IssueViewModelContainer();
          viewModelContainer.ErrorMessage = "401";
          return viewModelContainer;
        }
        IrisSoftware.iMPACT.Data.Issue issueDetails = this.FetchIssueByKey(issueId);
        if (!string.IsNullOrEmpty(issueDetails.IssueDetail.CommaSeperatedStateID))
          issueDetails.IssueDetail.IssueStatus = ((IEnumerable<string>) issueDetails.IssueDetail.CommaSeperatedStateID.Split(new string[1]
          {
            ","
          }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        else
          issueDetails.IssueDetail.IssueStatus = new List<long>();
        return this.GetIssueViewModel(issueDetails);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueViewModelContainer viewModelContainer = new IssueViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public IssueViewModelContainer CopyIssueById(long copyIssueId)
    {
      try
      {
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (copyIssueId > 0L)
        {
          if (!this.HasUIPermissionForEntity(-32L, copyIssueId, "Issue Detail", "View"))
          {
            IssueViewModelContainer viewModelContainer = new IssueViewModelContainer();
            viewModelContainer.ErrorMessage = "401";
            return viewModelContainer;
          }
        }
        else if (!this.HasEntityPermission(-32L, "Issue Detail", "Create"))
        {
          IssueViewModelContainer viewModelContainer = new IssueViewModelContainer();
          viewModelContainer.ErrorMessage = "401";
          return viewModelContainer;
        }
        IrisSoftware.iMPACT.Data.Issue issueDetails = this.FetchCopyIssueByKey(copyIssueId);
        if (!string.IsNullOrEmpty(issueDetails.IssueDetail.CommaSeperatedStateID))
          issueDetails.IssueDetail.IssueStatus = ((IEnumerable<string>) issueDetails.IssueDetail.CommaSeperatedStateID.Split(new string[1]
          {
            ","
          }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        else
          issueDetails.IssueDetail.IssueStatus = new List<long>();
        return this.GetIssueViewModel(issueDetails, true);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueViewModelContainer viewModelContainer = new IssueViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    private bool HasPermissionToUploadDoc(long appTransactionId) => appTransactionId > 0L && this.HasUIPermissionForEntityStatusMultiple(appTransactionId, IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetIssue, "Upload");

    public IssueViewModelContainer GetIssueViewModel(
      IrisSoftware.iMPACT.Data.Issue issueDetails,
      bool IsCopyIssue = false)
    {
      try
      {
        long appTransactionId = issueDetails.IssueDetail.AppTransactionID;
        IEnumerable<LookupItemMappings> source1 = appTransactionId > 0L ? this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetLookupItemKeys(), this.GetIncludeLookupItemsID(issueDetails)) : this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetLookupItemKeys());
        if (issueDetails.Partner == null)
          issueDetails.Partner = this.IssueRepository.FetchAllPartner().ToList<Partner>();
        issueDetails.MiscFieldsDetail = this.PropertyDescriptorRepository.FetchPropertyDescriptorsDataByEntity(appTransactionId, -32L);
        issueDetails.RestrictedCUSIP = (IEnumerable<RestrictedCUSIP>) this.RestrictedCUSIPRepository.FetchByIssueId(appTransactionId).ToList<RestrictedCUSIP>();
        issueDetails.UploadedDocumentTypes = this.IssueRepository.FetchUploadedDocumentTypes(appTransactionId);
        if (IsCopyIssue)
        {
          if (issueDetails.InternalPartners != null && issueDetails.InternalPartners.Count > 0)
            issueDetails.InternalPartners = issueDetails.InternalPartners.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
            {
              x.IsDirty = true;
              return x;
            })).ToList<InternalPartner>();
          if (issueDetails.ExternalPartners != null && issueDetails.ExternalPartners.Count > 0)
            issueDetails.ExternalPartners = issueDetails.ExternalPartners.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (x =>
            {
              x.IsDirty = true;
              return x;
            })).ToList<ExternalPartner>();
        }
        IssueViewModelContainer issueContainer = new IssueViewModelContainer(source1.ToList<LookupItemMappings>(), issueDetails);
        List<long> source2;
        if (issueDetails.IssueDetail.IssueStatus != null && issueDetails.IssueDetail.IssueStatus.Count > 0)
        {
          source2 = issueDetails.IssueDetail.IssueStatus;
          issueContainer.IssueDetail.IssuseStatusValue = source2.Select<long, string>((Func<long, string>) (s => ReflectionUtils.GetEnumValueDescription((System.Enum) (IssueEnums.IssueStatus) s))).ToList<string>();
          this.issueCurrentStatus = source2.ConvertAll<IssueEnums.IssueStatus>((Converter<long, IssueEnums.IssueStatus>) (s => (IssueEnums.IssueStatus) s)).ToList<IssueEnums.IssueStatus>();
        }
        else
          source2 = new List<long>();
        IrisSoftware.iMPACT.Core.Security.Permission[] permissions = this.AuthorizationService.GetPermissions(this.AppUser, -32L, appTransactionId);
        IWorkflow<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> workflow = this.WorkflowFactory.GetWorkflow("");
        issueContainer.WorkflowStateTransitions = issueDetails.WorkflowStateTransitions;
        AppTransactionStateTransition transactionStateTransition = (AppTransactionStateTransition) null;
        Dictionary<IssueEnums.IssueStatus, IssueEnums.IssueStatus> source3 = (Dictionary<IssueEnums.IssueStatus, IssueEnums.IssueStatus>) null;
        if (issueContainer.IssueDetail.AppTransactionID > 0L)
          source3 = this.IssueRepository.FetchHistoryByAppTransactionID(issueContainer.IssueDetail.AppTransactionID);
        if (issueContainer.WorkflowStateTransitions != null)
          transactionStateTransition = issueContainer.WorkflowStateTransitions.OrderBy<AppTransactionStateTransition, DateTime>((Func<AppTransactionStateTransition, DateTime>) (t => t.ModifiedOn)).Last<AppTransactionStateTransition>();
        List<IssueEnums.IssueStatus> issueStatusList = source2.ConvertAll<IssueEnums.IssueStatus>((Converter<long, IssueEnums.IssueStatus>) (s => (IssueEnums.IssueStatus) s));
        List<string> list = workflow.GetAllowedActions((IEnumerable<IssueEnums.IssueStatus>) issueStatusList).ToList<string>();
        if (source3 != null)
        {
          if (source3.Any<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>>((Func<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>, bool>) (h => h.Key == IssueEnums.IssueStatus.LeadBankerReview)))
          {
            list.Remove(IssueAction.MarkReActive);
            list.Remove(IssueAction.ReturnToMUCCApproved);
            list.Remove(IssueAction.ReturnToPrePricing);
          }
          else
            list.Remove(IssueAction.ReturnToLeadBankerReview);
          if (source3.Any<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>>((Func<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>, bool>) (h => h.Key == IssueEnums.IssueStatus.ComplianceLegalReview)) || source3.Any<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>>((Func<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>, bool>) (h => h.Key == IssueEnums.IssueStatus.SupervisoryPrincipalReview)) || (source3.Any<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>>((Func<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>, bool>) (h => h.Key == IssueEnums.IssueStatus.ManagementReview)) || source3.Any<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>>((Func<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>, bool>) (h => h.Key == IssueEnums.IssueStatus.FirmCreditReview))))
            list.Remove(IssueAction.ReturnToLeadBankerReview);
          else
            list.Remove(IssueAction.ReturnToMUCCReview);
          if (source3.Any<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>>((Func<KeyValuePair<IssueEnums.IssueStatus, IssueEnums.IssueStatus>, bool>) (h => h.Key == IssueEnums.IssueStatus.QuantitativeReview)))
          {
            list.Remove(IssueAction.MarkReActive);
            list.Remove(IssueAction.ReturnToLeadBankerReview);
            list.Remove(IssueAction.ReturnToMUCCReview);
            list.Remove(IssueAction.ReturnToMUCCApproved);
            list.Remove(IssueAction.ReturnToPrePricing);
          }
          else
            list.Remove(IssueAction.ReturnToQuantativeReview);
        }
        if (transactionStateTransition != null)
        {
          long? fromStateId = transactionStateTransition.FromStateID;
          if (fromStateId.HasValue)
          {
            long valueOrDefault = fromStateId.GetValueOrDefault();
            if (valueOrDefault != 2L)
            {
              switch (valueOrDefault - 27L)
              {
                case 0:
                  list.Remove(IssueAction.MarkReActive);
                  list.Remove(IssueAction.ReturnToPrePricing);
                  list.Remove(IssueAction.ReturnToMUCCReview);
                  long? toStateId1 = transactionStateTransition.ToStateID;
                  long num1 = 71;
                  if ((toStateId1.GetValueOrDefault() == num1 ? (toStateId1.HasValue ? 1 : 0) : 0) != 0)
                  {
                    list.Add(IssueAction.ReturnToMUCCApproved);
                    break;
                  }
                  break;
                case 1:
                  list.Remove(IssueAction.MarkReActive);
                  long? toStateId2 = transactionStateTransition.ToStateID;
                  long num2 = 71;
                  if ((toStateId2.GetValueOrDefault() == num2 ? (toStateId2.HasValue ? 1 : 0) : 0) != 0)
                    list.Add(IssueAction.ReturnToPrePricing);
                  list.Remove(IssueAction.ReturnToMUCCReview);
                  list.Remove(IssueAction.ReturnToMUCCApproved);
                  list.Remove(IssueAction.ReturnToLeadBankerReview);
                  break;
              }
            }
            else
            {
              list.Remove(IssueAction.ReturnToMUCCApproved);
              list.Remove(IssueAction.ReturnToPrePricing);
            }
          }
        }
        if (issueContainer.IssueDetail.AppTransactionID <= 0L)
        {
          list.Remove(IssueAction.MarkReActive);
          list.Remove(IssueAction.ReturnToLeadBankerReview);
          list.Remove(IssueAction.ReturnToMUCCReview);
          list.Remove(IssueAction.ReturnToMUCCApproved);
          list.Remove(IssueAction.ReturnToPrePricing);
          list.Remove(IssueAction.ReturnToQuantativeReview);
        }
        IrisSoftware.iMPACT.Core.Security.Permission[] array1 = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) permissions).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "Issue Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
        if (list != null && list.Count > 0)
        {
          string[] array2 = list.ToArray();
          issueContainer.Actions = this.GetMatchingPermission(array1, array2);
        }
        if (issueContainer.IssueDetail.IssueStatusValue == ReflectionUtils.GetEnumValueDescription((System.Enum) IssueEnums.IssueStatus.TransactionPriced) || issueContainer.IssueDetail.IssueStatusValue == ReflectionUtils.GetEnumValueDescription((System.Enum) IssueEnums.IssueStatus.RegulatoryChecklistReview) || (issueContainer.IssueDetail.IssueStatusValue == ReflectionUtils.GetEnumValueDescription((System.Enum) IssueEnums.IssueStatus.OperationsReconcile) || issueContainer.IssueDetail.IssueStatusValue == ReflectionUtils.GetEnumValueDescription((System.Enum) IssueEnums.IssueStatus.Complete)))
          issueContainer.IssueDetail.IsTransactionPriced = new bool?(true);
        this.SetIssuePermissions(issueContainer);
        IEnumerable<IrisSoftware.iMPACT.Data.EmailTemplate> source4 = ((IEnumerable<IrisSoftware.iMPACT.Data.EmailTemplate>) this.EmailTemplateRepository.FetchEntityTemplates(-32)).Join<IrisSoftware.iMPACT.Data.EmailTemplate, IrisSoftware.iMPACT.Core.Security.Permission, string, IrisSoftware.iMPACT.Data.EmailTemplate>((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) permissions, (Func<IrisSoftware.iMPACT.Data.EmailTemplate, string>) (emailtem => emailtem.UIName), (Func<IrisSoftware.iMPACT.Core.Security.Permission, string>) (permission => permission.UIName), (Func<IrisSoftware.iMPACT.Data.EmailTemplate, IrisSoftware.iMPACT.Core.Security.Permission, IrisSoftware.iMPACT.Data.EmailTemplate>) ((emailtem, permission) => emailtem));
        issueContainer.EmailTemplates = source4.Select<IrisSoftware.iMPACT.Data.EmailTemplate, EmailTemplateViewModel>((Func<IrisSoftware.iMPACT.Data.EmailTemplate, EmailTemplateViewModel>) (template => new EmailTemplateViewModel(template))).ToList<EmailTemplateViewModel>();
        if (!issueContainer.EmailTemplates.Any<EmailTemplateViewModel>())
          issueContainer.IssueDetail.DisableIssueDetailEmail = true;
        return issueContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueViewModelContainer viewModelContainer = new IssueViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    private List<WorkflowStateViewModel> GetWorkflowState(
      IEnumerable<Transition<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>> stateTransitions,
      IrisSoftware.iMPACT.Data.Issue issue)
    {
      List<WorkflowStateViewModel> source = new List<WorkflowStateViewModel>();
      foreach (Transition<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> stateTransition in stateTransitions)
      {
        Transition<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> transition = stateTransition;
        long fromStateId = (long) transition.FromState.Key;
        string valueDescription1 = ReflectionUtils.GetEnumValueDescription((System.Enum) transition.FromState.Key);
        foreach (IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> toState in transition.ToStates)
        {
          long toStateId = (long) toState.Key;
          string valueDescription2 = ReflectionUtils.GetEnumValueDescription((System.Enum) toState.Key);
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == fromStateId)))
          {
            bool flag1 = issue.IssueDetail.IssueStatus.Contains((long) transition.FromState.Key);
            bool flag2 = issue.WorkflowStateTransitions != null && issue.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long key1 = (long) transition.FromState.Key;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((key1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long key2 = (long) transition.FromState.Key;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return key2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = fromStateId,
              StateName = valueDescription1,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == toStateId)))
          {
            bool flag1 = issue.IssueDetail.IssueStatus.Contains(toStateId);
            bool flag2 = issue.WorkflowStateTransitions != null && issue.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long num1 = toStateId;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((num1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long num2 = toStateId;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return num2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = toStateId,
              StateName = valueDescription2,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
        }
      }
      return source;
    }

    private List<WorkflowStateTransitionViewModel> GetWorkflowStateTransition(
      IEnumerable<Transition<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>> stateTransition,
      IssueViewModelContainer issueViewModelContainer,
      IrisSoftware.iMPACT.Data.Issue issue)
    {
      List<WorkflowStateTransitionViewModel> transitionViewModelList = new List<WorkflowStateTransitionViewModel>();
      foreach (Transition<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> transition1 in stateTransition)
      {
        Transition<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> transition = transition1;
        foreach (IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> toState1 in transition.ToStates)
        {
          IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> toState = toState1;
          transitionViewModelList.Add(new WorkflowStateTransitionViewModel()
          {
            FromState = (long) transition.FromState.Key,
            ToState = (long) toState.Key,
            IsVisited = issue.WorkflowStateTransitions != null && issue.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long? nullable = itm.FromStateID;
              long key1 = (long) transition.FromState.Key;
              if ((nullable.GetValueOrDefault() == key1 ? (nullable.HasValue ? 1 : 0) : 0) == 0)
                return false;
              nullable = itm.ToStateID;
              long key2 = (long) toState.Key;
              return nullable.GetValueOrDefault() == key2 && nullable.HasValue;
            }))
          });
        }
      }
      return transitionViewModelList;
    }

    private IrisSoftware.iMPACT.Data.Issue FetchIssueByKey(long issueId)
    {
      IrisSoftware.iMPACT.Data.Issue issue = this.IssueRepository.FetchByKey(issueId);
      issue.Mucc = this.IssueRepository.FetchMuccDetailsByKey(issueId, -32L);
      return issue;
    }

    private IrisSoftware.iMPACT.Data.Issue FetchCopyIssueByKey(long copyIssueId) => this.IssueRepository.CopyIssueByKey(copyIssueId);

    private string[] GetIncludeLookupItemsID(IrisSoftware.iMPACT.Data.Issue issue)
    {
      string[] strArray = new string[17];
      strArray[0] = issue.IssueDetail.OfferingType.ToString();
      strArray[1] = issue.IssueDetail.State.ToString();
      long num;
      string str1;
      if (!issue.IssueDetail.FirmRole.HasValue)
      {
        str1 = "0";
      }
      else
      {
        num = issue.IssueDetail.FirmRole.Value;
        str1 = num.ToString();
      }
      strArray[2] = str1;
      long? nullable = issue.IssueDetail.Purpose;
      string str2;
      if (!nullable.HasValue)
      {
        str2 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.Purpose;
        num = nullable.Value;
        str2 = num.ToString();
      }
      strArray[3] = str2;
      nullable = issue.IssueDetail.GeneralCategory;
      string str3;
      if (!nullable.HasValue)
      {
        str3 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.GeneralCategory;
        num = nullable.Value;
        str3 = num.ToString();
      }
      strArray[4] = str3;
      nullable = issue.IssueDetail.GeneralCategorySpecific;
      string str4;
      if (!nullable.HasValue)
      {
        str4 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.GeneralCategorySpecific;
        num = nullable.Value;
        str4 = num.ToString();
      }
      strArray[5] = str4;
      nullable = issue.IssueDetail.InsuranceProvider;
      string str5;
      if (!nullable.HasValue)
      {
        str5 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.InsuranceProvider;
        num = nullable.Value;
        str5 = num.ToString();
      }
      strArray[6] = str5;
      nullable = issue.IssueDetail.CreditEnhancementProg;
      string str6;
      if (!nullable.HasValue)
      {
        str6 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.CreditEnhancementProg;
        num = nullable.Value;
        str6 = num.ToString();
      }
      strArray[7] = str6;
      nullable = issue.IssueDetail.BidPlatform;
      string str7;
      if (!nullable.HasValue)
      {
        str7 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.BidPlatform;
        num = nullable.Value;
        str7 = num.ToString();
      }
      strArray[8] = str7;
      nullable = issue.IssueDetail.BidCalc;
      string str8;
      if (!nullable.HasValue)
      {
        str8 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.BidCalc;
        num = nullable.Value;
        str8 = num.ToString();
      }
      strArray[9] = str8;
      nullable = issue.IssueDetail.MERGReviewType;
      string str9;
      if (!nullable.HasValue)
      {
        str9 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.MERGReviewType;
        num = nullable.Value;
        str9 = num.ToString();
      }
      strArray[10] = str9;
      nullable = issue.IssueDetail.AdvanceRefunding;
      string str10;
      if (!nullable.HasValue)
      {
        str10 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.AdvanceRefunding;
        num = nullable.Value;
        str10 = num.ToString();
      }
      strArray[11] = str10;
      nullable = issue.IssueDetail.G17Type;
      strArray[12] = nullable.ToString();
      nullable = issue.IssueDetail.GoodFaithType;
      string str11;
      if (!nullable.HasValue)
      {
        str11 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.GoodFaithType;
        str11 = nullable.ToString();
      }
      strArray[13] = str11;
      nullable = issue.IssueDetail.CrossSellId;
      string str12;
      if (!nullable.HasValue)
      {
        str12 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.CrossSellId;
        str12 = nullable.ToString();
      }
      strArray[14] = str12;
      nullable = issue.IssueDetail.DealType;
      string str13;
      if (!nullable.HasValue)
      {
        str13 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.DealType;
        num = nullable.Value;
        str13 = num.ToString();
      }
      strArray[15] = str13;
      nullable = issue.IssueDetail.TransactionType;
      string str14;
      if (!nullable.HasValue)
      {
        str14 = "0";
      }
      else
      {
        nullable = issue.IssueDetail.TransactionType;
        num = nullable.Value;
        str14 = num.ToString();
      }
      strArray[16] = str14;
      return ((IEnumerable<string>) strArray).Concat<string>((IEnumerable<string>) this.GetFirmOtherRoleIDs(issue.IssueDetail.FirmOtherRoles)).Concat<string>((IEnumerable<string>) this.GetExternalPartnerIDs((IEnumerable<ExternalPartner>) issue.ExternalPartners)).ToArray<string>();
    }

    private string[] GetFirmOtherRoleIDs(IEnumerable<IrisSoftware.iMPACT.Data.FirmOtherRole> firmOtherRoles)
    {
      if (firmOtherRoles != null && firmOtherRoles.Count<IrisSoftware.iMPACT.Data.FirmOtherRole>() > 0)
        return firmOtherRoles.Select<IrisSoftware.iMPACT.Data.FirmOtherRole, string>((Func<IrisSoftware.iMPACT.Data.FirmOtherRole, string>) (x => !x.OtherRole.HasValue ? "0" : x.OtherRole.Value.ToString())).ToArray<string>();
      return new string[1]{ "0" };
    }

    private string[] GetExternalPartnerIDs(IEnumerable<ExternalPartner> externalPartner)
    {
      if (externalPartner != null && externalPartner.Count<ExternalPartner>() > 0)
        return externalPartner.Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.MemberType.ToString())).ToArray<string>();
      return new string[1]{ "0" };
    }

    public IssueExternalPartnerViewModel FetchIssueExternalPartnerByIssueKey(
      long currentId)
    {
      try
      {
        IEnumerable<LookupItemMappings> source = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetExternalPartnerLookupItemKeys());
        List<ExternalPartner> list = this.IssueRepository.FetchIssueExternalPartnerByIssueKey(currentId).ToList<ExternalPartner>();
        return new IssueExternalPartnerViewModel(source.ToList<LookupItemMappings>(), list)
        {
          AppTransactionID = currentId
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueExternalPartnerViewModel partnerViewModel = new IssueExternalPartnerViewModel();
        partnerViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return partnerViewModel;
      }
    }

    public IssueInternalPartnerViewModel FetchIssueInternalPartnerByIssueKey(
      long currentId)
    {
      try
      {
        return new IssueInternalPartnerViewModel(this.IssueRepository.FetchIssueInternalPartnerByIssueKey(currentId).ToList<InternalPartner>())
        {
          AppTransactionID = currentId
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueInternalPartnerViewModel partnerViewModel = new IssueInternalPartnerViewModel();
        partnerViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return partnerViewModel;
      }
    }

    public SaveResult SaveExternalPartner(
      IssueExternalPartnerViewModel issueExternalPartnerViewModel)
    {
      try
      {
        this.GetSafeObject<IssueExternalPartnerViewModel>(issueExternalPartnerViewModel);
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssueRepository.SaveExternalPartner(this.GetExternalPartner(issueExternalPartnerViewModel));
          transactionScope.Complete();
        }
        return new SaveResult();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public IssueContactDetailViewModel FetchIssueContactsByIssueKey(
      long currentId)
    {
      try
      {
        return new IssueContactDetailViewModel(this.IssueRepository.FetchIssueContactsByIssueKey(currentId).ToList<IssueContact>())
        {
          AppTransactionID = currentId
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueContactDetailViewModel contactDetailViewModel = new IssueContactDetailViewModel();
        contactDetailViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return contactDetailViewModel;
      }
    }

    public List<AuditTrailReportViewModel> GetAuditTrailsForReport(
      long appTransactionID)
    {
      try
      {
        List<AuditTrailReportViewModel> trailReportViewModelList = new List<AuditTrailReportViewModel>();
        using (IDataReader dataReader = this.IssueRepository.FetchIssueAuditTrail(appTransactionID))
        {
          IRowMapper<AuditTrailReportViewModel> rowMapper = MapBuilder<AuditTrailReportViewModel>.MapAllProperties().Build();
          if (dataReader != null)
          {
            while (dataReader.Read())
              trailReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return trailReportViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<AuditTrailReportViewModel>();
      }
    }

    public List<string> GetIssueNames(string issueName)
    {
      try
      {
        return this.IssueRepository.FetchIssueNames(issueName).ToList<string>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<string>();
      }
    }

    public List<string> GetDealNames(string dealName)
    {
      try
      {
        return this.IssueRepository.FetchDealNames(dealName).ToList<string>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<string>();
      }
    }

    private Decimal ParseStringToDecimal(string Value)
    {
      Decimal result = 0M;
      Decimal.TryParse(Value, out result);
      return result;
    }

    public SaveResult Save(
      IssueViewModelContainer issueContainer,
      string issueAction,
      int currentTabIndex)
    {
      try
      {
        this.GetSafeObject<IssueViewModelContainer>(issueContainer);
        TransitionResult<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> transitionResult = (TransitionResult<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>) null;
        List<IssueEnums.IssueStatus> issueStatusList = new List<IssueEnums.IssueStatus>();
        issueStatusList.Add(IssueEnums.IssueStatus.Open);
        IrisSoftware.iMPACT.Data.Issue oldIssue = new IrisSoftware.iMPACT.Data.Issue();
        if (issueContainer.IssueDetail.AppTransactionID > 0L)
        {
          oldIssue = this.IssueRepository.FetchByKey(issueContainer.IssueDetail.AppTransactionID);
          issueContainer.IssueDetail.CreatedOn = oldIssue.IssueDetail.CreatedOn;
          issueContainer.IssueDetail.IsMuccUpdated = oldIssue.IssueDetail.IsMuccUpdated;
          issueContainer.IssueDetail.IsRequirementRegulatoryUpdated = oldIssue.IssueDetail.IsRequirementRegulatoryUpdated;
          issueStatusList.Clear();
          if (!string.IsNullOrEmpty(oldIssue.IssueDetail.CommaSeperatedStateID))
          {
            oldIssue.IssueDetail.IssueStatus = ((IEnumerable<string>) oldIssue.IssueDetail.CommaSeperatedStateID.Split(new string[1]
            {
              ","
            }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>((Func<string, long>) (s => long.Parse(s))).ToList<long>();
            issueStatusList = oldIssue.IssueDetail.IssueStatus.ConvertAll<IssueEnums.IssueStatus>((Converter<long, IssueEnums.IssueStatus>) (s => (IssueEnums.IssueStatus) s));
          }
        }
        SaveResult saveResult = issueContainer.IssueDetail.Validate<IssueDetailViewModel>();
        if (!saveResult.IsSuccessful || !this.ValidateModel(issueContainer, ref saveResult))
          return saveResult;
        IrisSoftware.iMPACT.Data.Issue modelFromViewModel = this.GetModelFromViewModel(issueContainer);
        modelFromViewModel.UploadedDocumentTypes = this.IssueRepository.FetchUploadedDocumentTypes(issueContainer.IssueDetail.AppTransactionID);
        if (modelFromViewModel != null && modelFromViewModel.InternalPartners.Count<InternalPartner>() == 0 && (oldIssue.InternalPartners != null && oldIssue.InternalPartners.Count<InternalPartner>() > 0))
          modelFromViewModel.InternalPartners = oldIssue.InternalPartners;
        if (modelFromViewModel != null && modelFromViewModel.ExternalPartners.Count<ExternalPartner>() == 0 && (oldIssue.ExternalPartners != null && oldIssue.ExternalPartners.Count<ExternalPartner>() > 0))
          modelFromViewModel.ExternalPartners = oldIssue.ExternalPartners;
        modelFromViewModel.IssueDetail.IsJobAdminInformed = oldIssue.IssueDetail.IsJobAdminInformed;
        DataTable pricingDt = (DataTable) null;
        DataTable cusipDt = (DataTable) null;
        if (issueContainer.IssuePricingDetailData != null)
          this.ReturnIssuePricingDataTable(issueContainer.IssuePricingDetailData, out pricingDt, out cusipDt);
        DataTable underlyingRatingDetail = (DataTable) null;
        if (issueContainer.UnderlyingRatingDetail != null)
          underlyingRatingDetail = this.ReturnUnderlyingRatingsDataTable(issueContainer.UnderlyingRatingDetail);
        modelFromViewModel.pricingDetail = pricingDt;
        modelFromViewModel.cusipDetail = cusipDt;
        modelFromViewModel.underlyingRatingDetail = underlyingRatingDetail;
        IWorkflow<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> workflow = this.WorkflowFactory.GetWorkflow("");
        Dictionary<IssueEnums.IssueStatus, IssueEnums.IssueStatus> dictionary = (Dictionary<IssueEnums.IssueStatus, IssueEnums.IssueStatus>) null;
        if (issueContainer.IssueDetail.AppTransactionID > 0L)
        {
          dictionary = this.IssueRepository.FetchHistoryByAppTransactionID(issueContainer.IssueDetail.AppTransactionID);
          modelFromViewModel.PnLStatusData = this.PnLRepository.FetchAllPnLStatusByIssueId(issueContainer.IssueDetail.AppTransactionID);
          modelFromViewModel.IssueDetail.IsPnLExistForAllJobNumbers = new bool?(this.IssueRepository.IsPnLExistForAllJobNumbers(issueContainer.IssueDetail.AppTransactionID));
        }
        modelFromViewModel.IssueRegulatoryCheckList = this.IssueRepository.FetchIssueRegulatoryCheckList(issueContainer.IssueDetail.AppTransactionID);
        if (!workflow.TryHandle(modelFromViewModel, (IEnumerable<IssueEnums.IssueStatus>) issueStatusList, issueAction, (IDictionary<IssueEnums.IssueStatus, IssueEnums.IssueStatus>) dictionary, out transitionResult))
          return SaveResult.Failure(transitionResult.Errors);
        Dictionary<int, int> history = this.AddHistory(transitionResult);
        List<IssueFromStateToState> fromToStateList1 = new List<IssueFromStateToState>();
        List<IssueFromStateToState> fromStateToStateList = new List<IssueFromStateToState>();
        List<int> transitionStateTracking = this.GetTransitionStateTracking(issueStatusList, transitionResult);
        List<IssueFromStateToState> fromToStateList2;
        List<IssueFromStateToState> stateAuditTrailList;
        if (issueContainer.IssueDetail.AppTransactionID > 0L)
        {
          fromToStateList2 = EntityStateHelper.GetTransitionFromToState<IssueFromStateToState, IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>(issueStatusList, transitionResult);
          stateAuditTrailList = EntityStateHelper.GetAuditFromToState<IssueFromStateToState, IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>(issueStatusList, transitionResult);
        }
        else
        {
          fromToStateList2 = this.SetFromToStateList(transitionResult, fromToStateList1);
          stateAuditTrailList = new List<IssueFromStateToState>();
        }
        bool flag1 = false;
        if (!string.IsNullOrEmpty(issueAction))
        {
          IrisSoftware.iMPACT.Core.Security.Permission[] array1 = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, -32L, issueContainer.IssueDetail.AppTransactionID)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "Issue Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
          List<long> longList = this.SetStatusList(issueContainer);
          string[] array2 = workflow.GetAllowedActions((IEnumerable<IssueEnums.IssueStatus>) longList.ConvertAll<IssueEnums.IssueStatus>((Converter<long, IssueEnums.IssueStatus>) (s => (IssueEnums.IssueStatus) s))).ToArray<string>();
          issueContainer.Actions = this.GetMatchingPermission(array1, array2);
          flag1 = ((IEnumerable<string>) issueContainer.Actions).FirstOrDefault<string>((Func<string, bool>) (x => x == issueAction)) != null;
        }
        List<InternalPartner> internalPartnerList = new List<InternalPartner>();
        List<InternalPartnerBankRM> internalPartnerBankRmList = new List<InternalPartnerBankRM>();
        using (TransactionScope transactionScope = new TransactionScope())
        {
          long num1 = 0;
          modelFromViewModel.IssueDetail.IssueStatus = transitionResult.ResultingStates.Select<IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>, long>((Func<IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>, long>) (s => (long) s.Key)).ToList<long>();
          IssuePresenter.IssueEditOnlyStatus issueEditOnlyStatus = this.SetIssueEditOnlyStatus(issueStatusList, modelFromViewModel.IssueDetail.AppTransactionID);
          if (issueContainer.IssueDetail.AppTransactionID > 0L)
            num1 = issueContainer.IssueDetail.AppTransactionID;
          if (!issueEditOnlyStatus.isIssueDetailsEditable && !flag1)
            modelFromViewModel.IssueDetail = oldIssue.IssueDetail;
          List<InternalPartner> internalPartners = modelFromViewModel.InternalPartners;
          internalPartnerBankRmList = modelFromViewModel.InternalPartnerBankRMs;
          if (!issueEditOnlyStatus.isInternalPartnerEditable)
          {
            modelFromViewModel.InternalPartners = (List<InternalPartner>) null;
            modelFromViewModel.InternalPartnerBankRMs = (List<InternalPartnerBankRM>) null;
          }
          if (!issueEditOnlyStatus.isExternalPartnerEditable)
            modelFromViewModel.ExternalPartners = (List<ExternalPartner>) null;
          if (!issueEditOnlyStatus.isTransactionReportEditable)
          {
            modelFromViewModel.PaidCheckDetail = (List<CheckDetail>) null;
            modelFromViewModel.ReceivedCheckDetail = (List<CheckDetail>) null;
            modelFromViewModel.IssueFee = (IssueFee) null;
          }
          if (!issueEditOnlyStatus.isMiscEditable)
            modelFromViewModel.MiscFieldsValueDetail = (IEnumerable<PropertySetValue>) null;
          long num2 = this.IssueRepository.Save(modelFromViewModel, history, fromToStateList2, stateAuditTrailList, pricingDt, underlyingRatingDetail);
          saveResult.Id = num2;
          if (num2 == -1L)
          {
            IssueViewModelContainer issueDetailsById = this.GetIssueDetailsById(modelFromViewModel.IssueDetail.AppTransactionID);
            string errorMessage = string.Format("{0} has updated the {1}. Please refresh your screen, re-enter your data and save. Press Yes to refresh the screen.", (object) issueDetailsById.IssueDetail.LastModifiedBy, (object) "Transaction");
            transactionScope.Complete();
            return SaveResult.Failure(num2, errorMessage, (object) issueDetailsById);
          }
          if (issueEditOnlyStatus.isRestrictedCusipEditable)
            this.SaveRestrictedCusips(issueContainer.RestrictedCUSIPs);
          if (issueEditOnlyStatus.isIssueRatingEditable && issueContainer.UnderlyingRatingDetail != null && issueContainer.EnhancedRatingDetail != null)
            this.IssueRatingRepository.SaveIssueRatings(this.ReturnUnderlyingRatingsDataTable(issueContainer.UnderlyingRatingDetail), num2, this.ReturnEnhancedRatingsDataTable(issueContainer.EnhancedRatingDetail));
          if (issueEditOnlyStatus.isIssuePricingEditable && issueContainer.IssuePricingDetailData != null)
            this.SaveIssuePricing(issueContainer.IssuePricingDetailData, num2);
          if (num2 > 0L)
          {
            IrisSoftware.iMPACT.Data.Issue Is = this.IssueRepository.FetchByKey(num2);
            this.SetIssueNumber(modelFromViewModel, Is);
            this.SetG17Details(modelFromViewModel, Is);
            this.SetMSBankinngGroup(modelFromViewModel, Is);
            modelFromViewModel.InternalPartners = Is.InternalPartners;
            modelFromViewModel.IssueReviews = Is.IssueReviews;
          }
          this.PerformSharePointDocumentSetOperations(num2, oldIssue, modelFromViewModel);
          saveResult.Id = num2;
          this.IssueRepository.Save(saveResult.Id);
          transactionScope.Complete();
        }
        modelFromViewModel.InternalPartnerBankRMs = internalPartnerBankRmList;
        if (saveResult.IsSuccessful)
        {
          bool flag2 = this.SaveIssuePnl(saveResult.Id);
          this.PublishEvents(issueContainer, issueStatusList, oldIssue, modelFromViewModel, fromToStateList2, transitionStateTracking, saveResult.Id);
          this.FlushUserEntitySecurityPermissions();
          IssueViewModelContainer issueDetailsById = this.GetIssueDetailsById(saveResult.Id);
          issueDetailsById.IsPnlSaved = flag2;
          switch (currentTabIndex)
          {
            case 4:
              issueDetailsById.IsRatingLoaded = true;
              issueDetailsById.IssueRatingDetail = this.GetIssueRatingDetails(saveResult.Id);
              break;
            case 5:
              issueDetailsById.IsPricingLoaded = true;
              issueDetailsById.IssuePricingDetail = this.GetIssuePricingDetails(saveResult.Id);
              break;
            case 10:
              issueDetailsById.IsAuditTrailLoaded = true;
              issueDetailsById.AuditTrailDetail = this.GetAuditTrailsForIssue(saveResult.Id);
              break;
          }
          saveResult.ViewModel = (object) issueDetailsById;
          this.EventBus.Publish<IssueUpdatedEvent>((Envelope<IssueUpdatedEvent>) new IssueUpdatedEvent(modelFromViewModel, oldIssue));
        }
        return saveResult;
      }
      catch (SqlException ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return ex.State == (byte) 1 && ex.Class == (byte) 16 && ex.Number == 50000 ? SaveResult.Failure(ex.Message) : SaveResult.Failure("An error occurred while saving the data.");
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private bool SaveIssuePnl(long appTransactionId)
    {
      bool flag = false;
      PnlViewModelContainer pnlContainer = this.PnlPresenter.Initialize(appTransactionId, (string) null, 0L);
      foreach (string jobNumber in pnlContainer.JobNumbers)
      {
        if (jobNumber == pnlContainer.SelectedJobNumber)
        {
          if (pnlContainer.PnlHeaderInfo.AppTransactionId > 0L && this.SaveSelectedPnl(pnlContainer))
            flag = true;
        }
        else
        {
          pnlContainer = this.PnlPresenter.Initialize(appTransactionId, jobNumber, 0L);
          if (pnlContainer.PnlHeaderInfo.AppTransactionId > 0L && this.SaveSelectedPnl(pnlContainer))
            flag = true;
        }
      }
      return flag;
    }

    public bool SaveSelectedPnl(PnlViewModelContainer pnlContainer)
    {
      Dictionary<string, object> dictionary = new Dictionary<string, object>((IDictionary<string, object>) pnlContainer.PnlFieldDetails);
      this.PnLRepository.EvaluateFormula(this.PnLRepository.FetchPnlDetailsById(pnlContainer.PnlHeaderInfo.IssueId, pnlContainer.PnlHeaderInfo.JobNumber, pnlContainer.PnlHeaderInfo.PnlTemplateId).PnLFields, pnlContainer.Pnl, pnlContainer.PnlFieldDetails, pnlContainer.PnLTemplateFields);
      this.PnlPresenter.Save(pnlContainer, string.Empty);
      return true;
    }

    private bool Compare(Decimal oldValue, Decimal newValue) => oldValue.Equals(newValue);

    private bool Compare(int oldValue, int newValue) => oldValue.Equals(newValue);

    private bool Compare(long oldValue, long newValue) => oldValue.Equals(newValue);

    private bool Compare(object oldValue, object newValue)
    {
      if (oldValue.GetType() == typeof (Decimal))
        return this.Compare(Convert.ToDecimal(oldValue), Convert.ToDecimal(newValue));
      if (oldValue.GetType() == typeof (int))
        return this.Compare(Convert.ToInt32(oldValue), Convert.ToInt32(newValue));
      return oldValue.GetType() == typeof (long) ? this.Compare(Convert.ToInt64(oldValue), Convert.ToInt64(newValue)) : oldValue.Equals(newValue);
    }

    private void PublishEvents(
      IssueViewModelContainer issueContainer,
      List<IssueEnums.IssueStatus> oldIssueStatus,
      IrisSoftware.iMPACT.Data.Issue oldIssue,
      IrisSoftware.iMPACT.Data.Issue newIssue,
      List<IssueFromStateToState> fromToStateList,
      List<int> stateTracking,
      long appTransID)
    {
      bool flag = false;
      int num = issueContainer.IssueDetail.AppTransactionID <= 0L ? 1 : 0;
      List<IssueEnums.IssueStatus> list = newIssue.IssueDetail.IssueStatus.ConvertAll<IssueEnums.IssueStatus>((Converter<long, IssueEnums.IssueStatus>) (s => (IssueEnums.IssueStatus) s)).ToList<IssueEnums.IssueStatus>();
      if (num != 0)
      {
        newIssue.IssueDetail.AppTransactionID = appTransID;
        this.EventBus.Publish<IssueCreatedEvent>((IEnumerable<Envelope<IssueCreatedEvent>>) new List<Envelope<IssueCreatedEvent>>()
        {
          (Envelope<IssueCreatedEvent>) new IssueCreatedEvent(newIssue),
          (Envelope<IssueCreatedEvent>) new IssueCreatedEvent(stateTracking, appTransID)
        });
      }
      else
        flag = !EntityStateHelper.IsStatusListEqual(oldIssueStatus, list);
      if (flag)
        this.EventBus.Publish<IssueStatusChangedEvent>((IEnumerable<Envelope<IssueStatusChangedEvent>>) new List<Envelope<IssueStatusChangedEvent>>()
        {
          (Envelope<IssueStatusChangedEvent>) new IssueStatusChangedEvent(newIssue, fromToStateList),
          (Envelope<IssueStatusChangedEvent>) new IssueStatusChangedEvent(stateTracking, issueContainer.IssueDetail.AppTransactionID)
        });
      if (false)
        this.EventBus.Publish<FOSUpdatedEvent>((Envelope<FOSUpdatedEvent>) new FOSUpdatedEvent(newIssue));
      if (!issueContainer.IssueDetail.HasDualProposalRequestedOrProposed.GetValueOrDefault())
        return;
      this.EventBus.Publish<IssueNotifyDualProposalRequestedProposedEvent>((Envelope<IssueNotifyDualProposalRequestedProposedEvent>) new IssueNotifyDualProposalRequestedProposedEvent(newIssue));
    }

    public ClientViewModel GetClientDetailsByKey(long clientId) => new ClientViewModel(this.ClientRepository.FetchByKey(clientId));

    private string[] GetLookupItemKeys() => new string[31]
    {
      "Issue Status",
      "MA Exemption",
      "Firm Role",
      "Additional Firm Role(s)",
      "Syndicate Structure",
      "Type of Offering",
      "Insurance Provider",
      "State",
      "DSRF",
      "Purpose",
      "Transaction Type",
      "Use of Proceeds",
      "Credit Enhancement Program",
      "MS Banking Group",
      "Bid Platform",
      "Bid Calc",
      "Syndicate Member Role",
      "Advisory Agent Type",
      "Counsel Type",
      "Other Partner Type",
      "Issue Status",
      "MERG Review Type",
      "Is Advance Refunding",
      "Market",
      "G-17 Type",
      "Good Faith Type",
      "General Category (Specific)",
      "Interest Rate Type",
      "Deal Type",
      "Cross Sell",
      "Fed Tax"
    };

    private string[] GetPricingLookupItemKeys() => new string[14]
    {
      "Security Type (General)",
      "Pricing Accrue From",
      "Pricing Form",
      "Day Count",
      "Interest Rate Type",
      "Call Feature",
      "Coupon Frequency",
      "Insurance",
      "Pricing Status",
      "Principal Freq",
      "Syndicate Structure",
      "Security Type (Specific)",
      "Fed Tax",
      "Firm Role"
    };

    private string[] GetRatingLookupItemKeys() => new string[13]
    {
      "Moody's Long Term Rating",
      "Moody's Short Term Rating",
      "Moody's Rating Outlook",
      "S&P Long Term Rating",
      "S&P Short Term Rating",
      "S&P Rating Outlook",
      "Kroll Long Term Rating",
      "Kroll Short Term Rating",
      "Kroll Rating Outlook",
      "Fitch Long Term Rating",
      "Fitch Short Term Rating",
      "Fitch Rating Outlook",
      "Credit Enhancement Type"
    };

    private string[] GetExternalPartnerLookupItemKeys() => new string[5]
    {
      "Syndicate Member Role",
      "Advisory Agent Type",
      "Counsel Type",
      "Other Partner Type",
      "Winning Syndicate Member Role"
    };

    private List<ExternalPartner> GetExternalPartner(
      IssueExternalPartnerViewModel issueExternalPartnerViewModel)
    {
      List<ExternalPartner> externalPartnerList = new List<ExternalPartner>();
      if (issueExternalPartnerViewModel != null)
      {
        externalPartnerList.AddRange((IEnumerable<ExternalPartner>) issueExternalPartnerViewModel.SyndicateMember.ToList<ExternalPartner>());
        externalPartnerList.AddRange((IEnumerable<ExternalPartner>) issueExternalPartnerViewModel.AdvisorAgent.ToList<ExternalPartner>());
        externalPartnerList.AddRange((IEnumerable<ExternalPartner>) issueExternalPartnerViewModel.Counsel.ToList<ExternalPartner>());
        externalPartnerList.AddRange((IEnumerable<ExternalPartner>) issueExternalPartnerViewModel.OtherPartner.ToList<ExternalPartner>());
      }
      return externalPartnerList;
    }

    private List<InternalPartner> GetInternalPartner(
      IssueInternalPartnerViewModel issueInternalPartnerViewModel)
    {
      List<InternalPartner> internalPartnerList = new List<InternalPartner>();
      if (issueInternalPartnerViewModel != null)
      {
        internalPartnerList.AddRange((IEnumerable<InternalPartner>) issueInternalPartnerViewModel.IssueInvestmentBankingTeam.ToList<InternalPartner>());
        internalPartnerList.AddRange((IEnumerable<InternalPartner>) issueInternalPartnerViewModel.IssueAnalystProfessionalSupport.ToList<InternalPartner>());
        internalPartnerList.AddRange((IEnumerable<InternalPartner>) issueInternalPartnerViewModel.IssueUnderwritingTeam.ToList<InternalPartner>());
        internalPartnerList.AddRange((IEnumerable<InternalPartner>) issueInternalPartnerViewModel.IssueSupervisoryPrincipal.ToList<InternalPartner>());
      }
      return internalPartnerList;
    }

    private List<IssueContact> GetIssueContact(
      IssueContactDetailViewModel issueContactDetailViewModel)
    {
      List<IssueContact> issueContactList = new List<IssueContact>();
      if (issueContactDetailViewModel != null)
      {
        issueContactList.AddRange((IEnumerable<IssueContact>) issueContactDetailViewModel.AdvisorMemberContact.ToList<IssueContact>());
        issueContactList.AddRange((IEnumerable<IssueContact>) issueContactDetailViewModel.CounselMemberContact.ToList<IssueContact>());
        issueContactList.AddRange((IEnumerable<IssueContact>) issueContactDetailViewModel.SyndicateMemberContact.ToList<IssueContact>());
        issueContactList.AddRange((IEnumerable<IssueContact>) issueContactDetailViewModel.OtherMemberContact.ToList<IssueContact>());
        issueContactList.AddRange((IEnumerable<IssueContact>) issueContactDetailViewModel.IssuerMemberContact.ToList<IssueContact>());
        issueContactList.AddRange((IEnumerable<IssueContact>) issueContactDetailViewModel.BorrowerMemberContact.ToList<IssueContact>());
        issueContactList.AddRange((IEnumerable<IssueContact>) issueContactDetailViewModel.GuarantorMemberContact.ToList<IssueContact>());
      }
      return issueContactList;
    }

    private IrisSoftware.iMPACT.Data.Issue GetModelFromViewModel(
      IssueViewModelContainer issueContainer)
    {
      IrisSoftware.iMPACT.Data.Issue issue1 = new IrisSoftware.iMPACT.Data.Issue(this.IssueRepository);
      IssueDetail issueDetail = new IssueDetail();
      issueDetail.AppTransactionID = issueContainer.IssueDetail.AppTransactionID;
      issueDetail.ParentOpportunityNumber = issueContainer.IssueDetail.ParentOpportunityNumber;
      issueDetail.ParentRFPNumber = issueContainer.IssueDetail.ParentRFPNumber;
      issueDetail.IssueStatus = issueContainer.IssueDetail.IssueStatus;
      issueDetail.IssueNbr = issueContainer.IssueDetail.IssueNbr;
      issueDetail.CreatedOn = issueContainer.IssueDetail.CreatedOn;
      issueDetail.PowerID = issueContainer.IssueDetail.PowerID == null ? (string) null : issueContainer.IssueDetail.PowerID.Trim();
      issueDetail.IssueName = issueContainer.IssueDetail.IssueName != null ? issueContainer.IssueDetail.IssueName.Trim() : issueContainer.IssueDetail.IssueName;
      issueDetail.IssuerID = issueContainer.IssueDetail.IssuerId;
      issueDetail.IssuerName = issueContainer.IssueDetail.IssuerName;
      issueDetail.JobNumber = issueContainer.IssueDetail.JobNumber;
      issueDetail.BorrowerID = issueContainer.IssueDetail.BorrowerId;
      issueDetail.BorrowerName = issueContainer.IssueDetail.BorrowerName;
      issueDetail.GuarantorID = issueContainer.IssueDetail.GuarantorId;
      issueDetail.GuarantorName = issueContainer.IssueDetail.GuarantorName;
      issueDetail.OfferingType = issueContainer.IssueDetail.OfferingTypeId;
      issueDetail.State = issueContainer.IssueDetail.StateID;
      issueDetail.HybridSolutionIndicator = issueContainer.IssueDetail.HybridSolutionIndicator;
      issueDetail.DualProposalProposed = issueContainer.IssueDetail.DualProposalProposed;
      issueDetail.DateHired = issueContainer.IssueDetail.DateHired;
      issueDetail.G17SentDate = issueContainer.IssueDetail.G17SentDate;
      issueDetail.G17AckDate = issueContainer.IssueDetail.G17AckDate;
      issueDetail.MAExemptions = (IEnumerable<MAExemptionDetail>) issueContainer.IssueDetail.MAExemptionDetails;
      issueDetail.G17Details = (IEnumerable<G17Detail>) issueContainer.IssueDetail.G17Details;
      issueDetail.PriorityOfOrders = (IEnumerable<PriorityOfOrderDetail>) issueContainer.IssueDetail.PriorityOfOrderDetails;
      issueDetail.RemarksForMERG = issueContainer.IssueDetail.RemarksForMERG != null ? issueContainer.IssueDetail.RemarksForMERG.Trim() : "";
      issueDetail.RemarksForMUCC = issueContainer.IssueDetail.RemarksForMUCC != null ? issueContainer.IssueDetail.RemarksForMUCC.Trim() : "";
      issueDetail.FirmRole = issueContainer.IssueDetail.FirmRoleId;
      Decimal? nullable1 = issueContainer.IssueDetail.FirmLiabilityPerc;
      Decimal? nullable2;
      if (!nullable1.HasValue)
      {
        nullable1 = new Decimal?();
        nullable2 = nullable1;
      }
      else
        nullable2 = issueContainer.IssueDetail.FirmLiabilityPerc;
      issueDetail.FirmLiabilityPerc = nullable2;
      issueDetail.FirmMgmtFeePerc = issueContainer.IssueDetail.FirmMgmtFeePerc;
      issueDetail.FirmOtherRoles = (IEnumerable<IrisSoftware.iMPACT.Data.FirmOtherRole>) issueContainer.IssueDetail.FirmOtherRoles;
      nullable1 = issueContainer.IssueDetail.ParAmount;
      Decimal? nullable3;
      if (!nullable1.HasValue)
      {
        nullable1 = new Decimal?();
        nullable3 = nullable1;
      }
      else
        nullable3 = issueContainer.IssueDetail.ParAmount;
      issueDetail.ParAmount = nullable3;
      issueDetail.SDCCreditPerc = issueContainer.IssueDetail.SDCCreditPerc;
      issueDetail.DSRF = issueContainer.IssueDetail.DSRF;
      issueDetail.County = issueContainer.IssueDetail.County == null ? (string) null : issueContainer.IssueDetail.County.Trim();
      issueDetail.Purpose = issueContainer.IssueDetail.Purpose;
      issueDetail.TransactionType = issueContainer.IssueDetail.UseOfProceed;
      issueDetail.InsuranceProvider = issueContainer.IssueDetail.InsuranceProviderId;
      issueDetail.GeneralCategory = issueContainer.IssueDetail.GeneralCategoryId;
      issueDetail.GeneralCategoryTxt = issueContainer.IssueDetail.GeneralCategoryTxt;
      issueDetail.OfferingTypeTxt = issueContainer.IssueDetail.OfferingTypeTxt;
      issueDetail.DealTypeTxt = issueContainer.IssueDetail.DealTypeTxt;
      issueDetail.CrossSellIdTxt = issueContainer.IssueDetail.CrossSellIdTxt;
      issueDetail.GeneralCategorySpecific = issueContainer.IssueDetail.GeneralCategorySpecificId;
      issueDetail.CreditEnhancementProg = issueContainer.IssueDetail.CreditEnhancementProgramId;
      issueDetail.Security = issueContainer.IssueDetail.Security;
      issueDetail.SecurityDetails = issueContainer.IssueDetail.SecurityDetails;
      issueDetail.PricingDate = issueContainer.IssueDetail.PricingDate;
      issueDetail.ROPDate = issueContainer.IssueDetail.ROPDate;
      issueDetail.ExpectedAwardDate = issueContainer.IssueDetail.ExpectedAwardDate;
      DateTime? nullable4 = issueContainer.IssueDetail.ExpectedAwardDate;
      issueDetail.ExpectedAwardTxtDate = !nullable4.HasValue ? (string) null : issueContainer.IssueDetail.ExpectedAwardTxtDate;
      issueDetail.ActualAwardDateTime = issueContainer.IssueDetail.ActualAwardDateTime;
      nullable4 = issueContainer.IssueDetail.ActualAwardDateTime;
      issueDetail.ActualAwardDateTimeZone = !nullable4.HasValue ? (string) null : issueContainer.IssueDetail.ActualAwardDateTimeZone;
      issueDetail.SettlementDate = issueContainer.IssueDetail.SettlementDate;
      issueDetail.TicketExecDateTime = issueContainer.IssueDetail.TicketExecDateTime;
      nullable4 = issueContainer.IssueDetail.TicketExecDateTime;
      issueDetail.TicketExecDateTimeZone = !nullable4.HasValue ? (string) null : issueContainer.IssueDetail.TicketExecDateTimeZone;
      nullable1 = issueContainer.IssueDetail.GoodFaithAmount;
      Decimal? nullable5;
      if (!nullable1.HasValue)
      {
        nullable1 = new Decimal?();
        nullable5 = nullable1;
      }
      else
        nullable5 = issueContainer.IssueDetail.GoodFaithAmount;
      issueDetail.GoodFaithAmount = nullable5;
      issueDetail.GoodFaithDate = issueContainer.IssueDetail.GoodFaithDate;
      issueDetail.GoodFaithWireInfo = issueContainer.IssueDetail.GoodFaithWireInfo;
      issueDetail.GoodFaithInstructions = issueContainer.IssueDetail.GoodFaithInstructions;
      issueDetail.AccountName = issueContainer.IssueDetail.AccountName;
      issueDetail.AccountNumber = issueContainer.IssueDetail.AccountNumber;
      issueDetail.ABANumber = issueContainer.IssueDetail.ABANumber;
      issueDetail.GoodFaithType = issueContainer.IssueDetail.GoodFaithTypeId;
      issueDetail.GoodFaithNotes = issueContainer.IssueDetail.GoodFaithNotes;
      issueDetail.Series = (IEnumerable<Series>) issueContainer.IssueDetail.Series;
      issueDetail.ARDSubmissionDate = issueContainer.IssueDetail.ARDSubmissionDate;
      issueDetail.LiquidityAgreementUploadDate = issueContainer.IssueDetail.LiquidityAgreementUploadDate;
      issueDetail.G37SettlementDate = issueContainer.IssueDetail.G37SettlementDate;
      issueDetail.FinalOSReceivedDateTime = issueContainer.IssueDetail.FinalOSReceivedDateTime;
      nullable4 = issueContainer.IssueDetail.FinalOSReceivedDateTime;
      issueDetail.FinalOSReceivedDateTimeZone = !nullable4.HasValue ? (string) null : issueContainer.IssueDetail.FinalOSReceivedDateTimeZone;
      issueDetail.DateCounselApprovedByLegal = issueContainer.IssueDetail.DateCounselApprovedByLegal;
      issueDetail.DateApprovedByMERG = issueContainer.IssueDetail.DateApprovedByMERG;
      issueDetail.DateApprovedByMUCC = issueContainer.IssueDetail.DateApprovedByMUCC;
      issueDetail.G32SubmissionDateTime = issueContainer.IssueDetail.G32SubmissionDateTime;
      nullable4 = issueContainer.IssueDetail.G32SubmissionDateTime;
      issueDetail.G32SubmissionDateTimeZone = !nullable4.HasValue ? (string) null : issueContainer.IssueDetail.G32SubmissionDateTimeZone;
      issueDetail.BPASigningDate = issueContainer.IssueDetail.BPASigningDate;
      issueDetail.CommitmentCommitteeApprovalDate = issueContainer.IssueDetail.CommitmentCommitteeApprovalDate;
      issueDetail.AdvanceRefunding = issueContainer.IssueDetail.AdvanceRefunding;
      issueDetail.G37Filed = issueContainer.IssueDetail.G37Filed;
      issueDetail.Notes = issueContainer.IssueDetail.Notes;
      issueDetail.PricingComments = issueContainer.IssueDetail.PricingComments != null ? issueContainer.IssueDetail.PricingComments.Trim() : "";
      issueDetail.RatingComments = issueContainer.IssueDetail.RatingComments != null ? issueContainer.IssueDetail.RatingComments.Trim() : "";
      issueDetail.ReviewComments = issueContainer.IssueDetail.ReviewComments != null ? issueContainer.IssueDetail.ReviewComments.Trim() : "";
      issueDetail.NbrOfCusip = issueContainer.IssueDetail.NbrOfCusip;
      issueDetail.BidCalc = issueContainer.IssueDetail.BidCalcId;
      issueDetail.BidPlatform = issueContainer.IssueDetail.BidPlatformId;
      issueDetail.DocumentLibraryURL = issueContainer.IssueDetail.DocumentLibraryURL;
      issueDetail.InRetention = issueContainer.IssueDetail.InRetention;
      issueDetail.CreatedBy = issueContainer.IssueDetail.CreatedBy;
      issueDetail.ModifiedBy = issueContainer.IssueDetail.ModifiedBy;
      issueDetail.ModifiedOn = issueContainer.IssueDetail.ModifiedOn;
      issueDetail.BidTxtDateTime = issueContainer.IssueDetail.BidPricingTxtDateTime;
      issueDetail.Version = issueContainer.IssueDetail.Version;
      issueDetail.LastModifiedBy = issueContainer.IssueDetail.LastModifiedBy;
      issueDetail.IsIssueInitiatedFromParentOpportunity = issueContainer.IssueDetail.IsIssueInitiatedFromParentOpportunity;
      issueDetail.IsIssueInitiatedFromParentRFP = issueContainer.IssueDetail.IsIssueInitiatedFromParentRFP;
      issueDetail.ParentOpportunityID = issueContainer.IssueDetail.ParentOpportunityID;
      issueDetail.ParentRFPID = issueContainer.IssueDetail.ParentRFPID;
      issueDetail.EstimatedRevenue = issueContainer.IssueDetail.EstimatedRevenue;
      issueDetail.IsMuccUpdated = issueContainer.IssueDetail.IsMuccUpdated;
      issueDetail.IsRequirementRegulatoryUpdated = issueContainer.IssueDetail.IsRequirementRegulatoryUpdated;
      issueDetail.DealType = issueContainer.IssueDetail.DealType;
      issueDetail.FormalDueDiligenceDate = issueContainer.IssueDetail.FormalDueDiligenceDate;
      issueDetail.IssuePriceCertReviewDate = issueContainer.IssueDetail.IssuePriceCertReviewDate;
      issueDetail.CrossSellId = issueContainer.IssueDetail.CrossSellId;
      issueDetail.CrossSellDetail = issueContainer.IssueDetail.CrossSellDetail;
      issueDetail.FirmRoleValue = issueContainer.IssueDetail.FirmRoleValue;
      issueDetail.DatedDate = issueContainer.IssueDetail.DatedDate;
      issueDetail.OSDeemedFinalDate = issueContainer.IssueDetail.OSDeemedFinalDate;
      issueDetail.MSBankingGroup = (IEnumerable<MsBankingGroup>) issueContainer.IssueDetail.MSBankingGroup;
      issueDetail.ReasonOfHold = issueContainer.IssueDetail.ReasonOfHold;
      issue1.IssueDetail = issueDetail;
      issue1.AuditTrail = (IEnumerable<AuditTrail>) issueContainer.IssueDetail.AuditTrail;
      issue1.ExternalPartners = this.GetExternalPartner(issueContainer.ExternalPartnerDetail);
      issue1.InternalPartners = this.GetInternalPartner(issueContainer.InternalPartnerDetail);
      issue1.InternalPartnerBankRMs = issueContainer.InternalPartnerDetail.IssueBankRM;
      issue1.PaidCheckDetail = issueContainer.TransactionReportDetail.PaidCheckDetail;
      issue1.ReceivedCheckDetail = issueContainer.TransactionReportDetail.ReceivedCheckDetail;
      issue1.IssueFee = issueContainer.TransactionReportDetail.IssueFee;
      issue1.AppTransactionClientContacts = issueContainer.AppTransactionClientContacts;
      issue1.RestrictedCUSIP = issueContainer.RestrictedCUSIPs != null ? (IEnumerable<RestrictedCUSIP>) issueContainer.RestrictedCUSIPs.Select<RestrictedCUSIPViewModel, RestrictedCUSIP>((Func<RestrictedCUSIPViewModel, RestrictedCUSIP>) (x => x.GetRestrictedCUSIP())).ToList<RestrictedCUSIP>() : (IEnumerable<RestrictedCUSIP>) new List<RestrictedCUSIP>();
      issue1.MiscFieldsValueDetail = issueContainer.MiscFieldsValueDetail;
      issue1.Mucc = issueContainer.Mucc;
      IrisSoftware.iMPACT.Data.Issue issue2 = issue1;
      if (issueContainer.IssueDetail.SelectedMERGReviewTypes != null)
      {
        List<MERGReviewTypeDetail> reviewTypeDetailList = new List<MERGReviewTypeDetail>();
        foreach (KeyPair selectedMergReviewType in issueContainer.IssueDetail.SelectedMERGReviewTypes)
        {
          reviewTypeDetailList.Add(new MERGReviewTypeDetail()
          {
            AppTransactionID = issueContainer.IssueDetail.AppTransactionID,
            MERGReviewType = Convert.ToInt64(selectedMergReviewType.Key)
          });
          issue2.IssueDetail.SelectedMERGReviewTypes = (IEnumerable<MERGReviewTypeDetail>) reviewTypeDetailList;
        }
      }
      return issue2;
    }

    private void SaveRestrictedCusips(List<RestrictedCUSIPViewModel> restrictedCusipsVM)
    {
      List<RestrictedCUSIPViewModel> list1 = restrictedCusipsVM.Where<RestrictedCUSIPViewModel>((Func<RestrictedCUSIPViewModel, bool>) (x => !x.IsDeleted)).ToList<RestrictedCUSIPViewModel>();
      List<string> list2 = restrictedCusipsVM.Where<RestrictedCUSIPViewModel>((Func<RestrictedCUSIPViewModel, bool>) (x => x.IsDeleted)).Select<RestrictedCUSIPViewModel, string>((Func<RestrictedCUSIPViewModel, string>) (x => x.RestrictedCUSIPID.ToString())).ToList<string>();
      string restrictedCUSIPIDs = string.Empty;
      if (list2 != null && list2.Count > 0)
        restrictedCUSIPIDs = string.Join(",", list2.ToArray());
      this.RestrictedCUSIPRepository.Save(list1.Select<RestrictedCUSIPViewModel, RestrictedCUSIP>((Func<RestrictedCUSIPViewModel, RestrictedCUSIP>) (x => x.GetRestrictedCUSIP())).ToList<RestrictedCUSIP>(), restrictedCUSIPIDs);
    }

    private IssueTransactionReport GetIssueTransactionReportModelFromViewModel(
      IssueTransactionReportViewModel issueTransactionReportViewModel)
    {
      return new IssueTransactionReport()
      {
        AppTransactionID = issueTransactionReportViewModel.AppTransactionID,
        Remarks = issueTransactionReportViewModel.Remarks,
        PaidCheckDetail = issueTransactionReportViewModel.PaidCheckDetail == null ? new List<CheckDetail>() : issueTransactionReportViewModel.PaidCheckDetail,
        ReceivedCheckDetail = issueTransactionReportViewModel.ReceivedCheckDetail == null ? new List<CheckDetail>() : issueTransactionReportViewModel.ReceivedCheckDetail
      };
    }

    private bool ValidateModel(IssueViewModelContainer issueContainer, ref SaveResult saveResult)
    {
      if (issueContainer.IssuePricingDetailData != null)
      {
        List<PricingViewModel> list1 = issueContainer.IssuePricingDetailData.Join((IEnumerable<Series>) issueContainer.IssueDetail.Series, (Func<PricingViewModel, string>) (pricingDetailData => pricingDetailData.SeriesID), (Func<Series, string>) (series => series.SeriesID.ToString()), (pricingDetailData, series) => new
        {
          pricingDetailData = pricingDetailData,
          series = series
        }).Where(_param1 => _param1.pricingDetailData.JobNumber == _param1.series.JobNumber).Select(_param1 => _param1.pricingDetailData).ToList<PricingViewModel>();
        IEnumerable<string> duplicateJobNumberKeys = list1.GroupBy<PricingViewModel, string>((Func<PricingViewModel, string>) (x => x.JobNumber)).Where<IGrouping<string, PricingViewModel>>((Func<IGrouping<string, PricingViewModel>, bool>) (group => group.Count<PricingViewModel>() > 1)).Select<IGrouping<string, PricingViewModel>, string>((Func<IGrouping<string, PricingViewModel>, string>) (group => group.Key));
        List<PricingViewModel> list2 = list1.FindAll((Predicate<PricingViewModel>) (p => duplicateJobNumberKeys.Contains<string>(p.JobNumber))).ToList<PricingViewModel>();
        List<PricingViewModel> source = new List<PricingViewModel>();
        if (list2 != null)
        {
          foreach (PricingViewModel pricingViewModel in list2)
          {
            PricingViewModel item = pricingViewModel;
            if (source.Where<PricingViewModel>((Func<PricingViewModel, bool>) (x =>
            {
              if (!(x.JobNumber == item.JobNumber))
                return false;
              if (x.FirmRole != item.FirmRole || this.ParseStringToDecimal(x.FirmLiability) != this.ParseStringToDecimal(item.FirmLiability) || this.ParseStringToDecimal(x.FirmMgtFee) != this.ParseStringToDecimal(item.FirmMgtFee))
                return true;
              DateTime? pricingDate1 = x.PricingDate;
              DateTime? pricingDate2 = item.PricingDate;
              if (pricingDate1.HasValue != pricingDate2.HasValue)
                return true;
              return pricingDate1.HasValue && pricingDate1.GetValueOrDefault() != pricingDate2.GetValueOrDefault();
            })).FirstOrDefault<PricingViewModel>() == null)
              source.Add(item);
            else if (!saveResult.Errors.ContainsKey("IssuePricingDetails-" + item.JobNumber ?? ""))
              saveResult.Errors.Add("IssuePricingDetails-" + item.JobNumber ?? "", (object) (item.JobNumber + ": MS Role, Liability, MS Management Fee and Pricing Date fields must be consistent within Job Number"));
          }
        }
      }
      long? nullable = issueContainer.IssueDetail.FirmRoleId;
      long num1 = -12;
      if ((nullable.GetValueOrDefault() == num1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
      {
        Decimal? firmLiabilityPerc = issueContainer.IssueDetail.FirmLiabilityPerc;
        Decimal num2 = (Decimal) 100;
        if ((firmLiabilityPerc.GetValueOrDefault() < num2 ? (firmLiabilityPerc.HasValue ? 1 : 0) : 0) != 0)
          saveResult.Errors.Add("IssueDetails", (object) "Firm Liability % cannot be less than 100%.");
      }
      if (issueContainer.IssuePricingDetailData != null)
      {
        DataTable cusipDt;
        this.ReturnIssuePricingDataTable(issueContainer.IssuePricingDetailData, out DataTable _, out cusipDt);
        string str = this.IssuePricingRepository.CheckDuplicateCusip(issueContainer.IssueDetail.AppTransactionID, cusipDt);
        if (!string.IsNullOrEmpty(str))
          saveResult.Errors.Add("CUSIP is duplicate in Series Maturity Grid", (object) ("Please validate CUSIP(s): " + str + ". These are already associated with one of the existing transactions."));
      }
      if (!string.IsNullOrEmpty(issueContainer.TransactionReportDetail.Remarks) && issueContainer.TransactionReportDetail.Remarks.Length > 1024)
        saveResult.Errors.Add("IssueDetails Transaction report", (object) "Transaction report remarks field length should be less than or equal to 1024 characters.");
      this.ValidateExternalPartnerModel(issueContainer.ExternalPartnerDetail, issueContainer.IssueDetail, ref saveResult);
      nullable = issueContainer.IssueDetail.DealType;
      long minValue = (long) sbyte.MinValue;
      if ((nullable.GetValueOrDefault() == minValue ? (nullable.HasValue ? 1 : 0) : 0) != 0)
        IssuePresenter.ValidateUnderwritingExemptionValidations(issueContainer, ref saveResult);
      this.ValidateInternalPartnerModel(issueContainer.InternalPartnerDetail, ref saveResult);
      return saveResult.IsSuccessful;
    }

    private static void ValidateUnderwritingExemptionValidations(
      IssueViewModelContainer issueContainer,
      ref SaveResult saveResult)
    {
      bool? nullable1 = new bool?();
      bool? nullable2 = new bool?();
      DateTime? dateHired = issueContainer.IssueDetail.DateHired;
      MAExemptionDetail maExemptionDetail = issueContainer.IssueDetail.MAExemptionDetails.Find((Predicate<MAExemptionDetail>) (t => t.MAExemptionType == -69L));
      G17Detail g17Detail1 = issueContainer.IssueDetail.G17Details.Where<G17Detail>((Func<G17Detail, bool>) (t => t.G17Type == -70L)).FirstOrDefault<G17Detail>();
      G17Detail g17Detail2 = issueContainer.IssueDetail.G17Details.Where<G17Detail>((Func<G17Detail, bool>) (t => t.G17Type == -71L)).FirstOrDefault<G17Detail>();
      G17Detail g17Detail3 = issueContainer.IssueDetail.G17Details.Where<G17Detail>((Func<G17Detail, bool>) (t => t.G17Type == -72L)).FirstOrDefault<G17Detail>();
      if (maExemptionDetail == null)
        return;
      long? nullable3 = issueContainer.IssueDetail.IssuerId;
      if (nullable3.HasValue)
      {
        nullable3 = issueContainer.IssueDetail.BorrowerId;
        if (nullable3.HasValue)
        {
          nullable3 = issueContainer.IssueDetail.IssuerId;
          long? borrowerId = issueContainer.IssueDetail.BorrowerId;
          if ((nullable3.GetValueOrDefault() == borrowerId.GetValueOrDefault() ? (nullable3.HasValue == borrowerId.HasValue ? 1 : 0) : 0) != 0)
          {
            if ((g17Detail1 == null || g17Detail2 == null) && g17Detail3 == null)
              saveResult.Errors.Add("IssueValidationCombinationMandatory", (object) "MSRB Rule G-17 Role and Conflict letter(s) must be sent in order to perfect an Underwriting exemption. Please add these letter(s) to the G-17 Grid.");
            DateTime? nullable4;
            if (dateHired.HasValue && (g17Detail1 != null && g17Detail2 != null || g17Detail3 != null))
            {
              DateTime? maExemptionDate = maExemptionDetail.MAExemptionDate;
              nullable4 = dateHired;
              if ((maExemptionDate.HasValue & nullable4.HasValue ? (maExemptionDate.GetValueOrDefault() < nullable4.GetValueOrDefault() ? 1 : 0) : 0) != 0)
              {
                saveResult.Errors.Add("IssueValidationCase1Failed", (object) "Underwriting MA Exemption Start Date should be greater than or equal to Date Hired.");
                return;
              }
            }
            DateTime? nullable5;
            if (g17Detail1 != null && g17Detail2 != null)
            {
              nullable4 = maExemptionDetail.MAExemptionDate;
              nullable5 = g17Detail1.G17SentDate;
              if ((nullable4.HasValue & nullable5.HasValue ? (nullable4.GetValueOrDefault() >= nullable5.GetValueOrDefault() ? 1 : 0) : 0) != 0)
              {
                nullable5 = maExemptionDetail.MAExemptionDate;
                nullable4 = g17Detail2.G17SentDate;
                if ((nullable5.HasValue & nullable4.HasValue ? (nullable5.GetValueOrDefault() >= nullable4.GetValueOrDefault() ? 1 : 0) : 0) != 0)
                  goto label_13;
              }
              saveResult.Errors.Add("IssueValidationCase1Failed", (object) "An Underwriting exemption will be received after being awarded the transaction and the MSRB Rule G-17 Role and Conflict letter(s) have been sent. Please correct your Underwriting exemption start date or contact Legal/Compliance.");
              nullable1 = new bool?(true);
              goto label_17;
            }
label_13:
            if (maExemptionDetail != null && g17Detail1 != null && g17Detail2 != null)
            {
              nullable4 = maExemptionDetail.MAExemptionDate;
              nullable5 = g17Detail1.G17SentDate;
              if ((nullable4.HasValue & nullable5.HasValue ? (nullable4.GetValueOrDefault() >= nullable5.GetValueOrDefault() ? 1 : 0) : 0) != 0)
              {
                nullable5 = maExemptionDetail.MAExemptionDate;
                nullable4 = g17Detail2.G17SentDate;
                if ((nullable5.HasValue & nullable4.HasValue ? (nullable5.GetValueOrDefault() >= nullable4.GetValueOrDefault() ? 1 : 0) : 0) != 0)
                  nullable1 = new bool?(false);
              }
            }
label_17:
            if (g17Detail3 != null)
            {
              nullable4 = maExemptionDetail.MAExemptionDate;
              nullable5 = g17Detail3.G17SentDate;
              if ((nullable4.HasValue & nullable5.HasValue ? (nullable4.GetValueOrDefault() >= nullable5.GetValueOrDefault() ? 1 : 0) : 0) == 0)
              {
                saveResult.Errors.Add("IssueValidationCase2Failed", (object) "An Underwriting exemption will be received after being awarded the transaction and the MSRB Rule G-17 Role and Conflict letter(s) have been sent. Please correct your Underwriting exemption start date or contact Legal/Compliance.");
                nullable2 = new bool?(true);
                goto label_23;
              }
            }
            if (g17Detail3 != null)
            {
              nullable5 = maExemptionDetail.MAExemptionDate;
              nullable4 = g17Detail3.G17SentDate;
              if ((nullable5.HasValue & nullable4.HasValue ? (nullable5.GetValueOrDefault() >= nullable4.GetValueOrDefault() ? 1 : 0) : 0) != 0)
                nullable2 = new bool?(false);
            }
label_23:
            bool? nullable6 = nullable1;
            bool flag1 = false;
            if ((nullable6.GetValueOrDefault() == flag1 ? (nullable6.HasValue ? 1 : 0) : 0) != 0)
            {
              bool? nullable7 = nullable2;
              bool flag2 = true;
              if ((nullable7.GetValueOrDefault() == flag2 ? (nullable7.HasValue ? 1 : 0) : 0) != 0)
                goto label_27;
            }
            bool? nullable8 = nullable1;
            bool flag3 = true;
            if ((nullable8.GetValueOrDefault() == flag3 ? (nullable8.HasValue ? 1 : 0) : 0) != 0)
            {
              bool? nullable7 = nullable2;
              bool flag2 = false;
              if ((nullable7.GetValueOrDefault() == flag2 ? (nullable7.HasValue ? 1 : 0) : 0) == 0)
                goto label_28;
            }
            else
              goto label_28;
label_27:
            saveResult.Errors.Remove("IssueValidationCase1Failed");
            saveResult.Errors.Remove("IssueValidationCase2Failed");
label_28:
            bool? nullable9 = nullable1;
            bool flag4 = true;
            if ((nullable9.GetValueOrDefault() == flag4 ? (nullable9.HasValue ? 1 : 0) : 0) == 0)
              return;
            bool? nullable10 = nullable2;
            bool flag5 = true;
            if ((nullable10.GetValueOrDefault() == flag5 ? (nullable10.HasValue ? 1 : 0) : 0) == 0)
              return;
            saveResult.Errors.Remove("IssueValidationCase1Failed");
            return;
          }
          if (!dateHired.HasValue)
            return;
          DateTime? maExemptionDate1 = maExemptionDetail.MAExemptionDate;
          DateTime? nullable11 = dateHired;
          if ((maExemptionDate1.HasValue == nullable11.HasValue ? (maExemptionDate1.HasValue ? (maExemptionDate1.GetValueOrDefault() != nullable11.GetValueOrDefault() ? 1 : 0) : 0) : 1) == 0)
            return;
          saveResult.Errors.Add("IssueValidationCase1Failed", (object) "For a conduit transaction, please ensure that the Underwriting exemption start date is the Date Hired.");
          return;
        }
      }
      if (!dateHired.HasValue)
        return;
      DateTime? maExemptionDate2 = maExemptionDetail.MAExemptionDate;
      DateTime? nullable12 = dateHired;
      if ((maExemptionDate2.HasValue == nullable12.HasValue ? (maExemptionDate2.HasValue ? (maExemptionDate2.GetValueOrDefault() != nullable12.GetValueOrDefault() ? 1 : 0) : 0) : 1) == 0)
        return;
      saveResult.Errors.Add("IssueDetails Validation when Issuer Null", (object) "For a conduit transaction, please ensure that the Underwriting exemption start date is the Date Hired.");
    }

    private void ValidateInternalPartnerModel(
      IssueInternalPartnerViewModel internalPartnerDetail,
      ref SaveResult saveResult)
    {
      internalPartnerDetail.IssueInvestmentBankingTeam.Where<InternalPartner>((Func<InternalPartner, bool>) (x => !x.IsDeleted)).GroupBy<InternalPartner, string>((Func<InternalPartner, string>) (i => i.FullName)).Where<IGrouping<string, InternalPartner>>((Func<IGrouping<string, InternalPartner>, bool>) (g => g.Count<InternalPartner>() > 1));
      IEnumerable<IGrouping<string, InternalPartner>> source1 = internalPartnerDetail.IssueAnalystProfessionalSupport.Where<InternalPartner>((Func<InternalPartner, bool>) (x => !x.IsDeleted)).GroupBy<InternalPartner, string>((Func<InternalPartner, string>) (i => i.FullName)).Where<IGrouping<string, InternalPartner>>((Func<IGrouping<string, InternalPartner>, bool>) (g => g.Count<InternalPartner>() > 1));
      IEnumerable<IGrouping<string, InternalPartner>> source2 = internalPartnerDetail.IssueUnderwritingTeam.Where<InternalPartner>((Func<InternalPartner, bool>) (x => !x.IsDeleted)).GroupBy<InternalPartner, string>((Func<InternalPartner, string>) (i => i.FullName)).Where<IGrouping<string, InternalPartner>>((Func<IGrouping<string, InternalPartner>, bool>) (g => g.Count<InternalPartner>() > 1));
      IEnumerable<IGrouping<string, InternalPartner>> source3 = internalPartnerDetail.IssueSupervisoryPrincipal.Where<InternalPartner>((Func<InternalPartner, bool>) (x => !x.IsDeleted)).GroupBy<InternalPartner, string>((Func<InternalPartner, string>) (i => i.FullName)).Where<IGrouping<string, InternalPartner>>((Func<IGrouping<string, InternalPartner>, bool>) (g => g.Count<InternalPartner>() > 1));
      IEnumerable<IGrouping<string, InternalPartnerBankRM>> source4 = internalPartnerDetail.IssueBankRM.Where<InternalPartnerBankRM>((Func<InternalPartnerBankRM, bool>) (x => !x.IsDeleted)).GroupBy<InternalPartnerBankRM, string>((Func<InternalPartnerBankRM, string>) (i => i.Name)).Where<IGrouping<string, InternalPartnerBankRM>>((Func<IGrouping<string, InternalPartnerBankRM>, bool>) (g => g.Count<InternalPartnerBankRM>() > 1));
      internalPartnerDetail.IssueInvestmentBankingTeam.Where<InternalPartner>((Func<InternalPartner, bool>) (x => !x.IsDeleted && x.IsPrimary == "1"));
      if (source1.Count<IGrouping<string, InternalPartner>>() > 0)
        saveResult.Errors.Add("Analytical Team", (object) "Selected Analytical Agent has already been added.");
      if (source2.Count<IGrouping<string, InternalPartner>>() > 0)
        saveResult.Errors.Add("Underwriter Team", (object) "Selected Underwriter Agent has already been added.");
      if (source3.Count<IGrouping<string, InternalPartner>>() > 0)
        saveResult.Errors.Add("Supervisory Principal Team", (object) "Selected Supervisory Principal Agent has already been added.");
      if (source4.Count<IGrouping<string, InternalPartnerBankRM>>() <= 0)
        return;
      saveResult.Errors.Add("Bank RM", (object) "Selected Bank RM Agent has already been added.");
    }

    private void ValidateExternalPartnerModel(
      IssueExternalPartnerViewModel externalPartnerDetail,
      IssueDetailViewModel issueDetail,
      ref SaveResult saveResult)
    {
      IEnumerable<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>> source1 = externalPartnerDetail.AdvisorAgent.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => !x.IsDeleted)).GroupBy(i => new
      {
        Name = i.Name,
        MemberType = i.MemberType
      }).Where<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>(g => g.Count<ExternalPartner>() > 1);
      IEnumerable<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>> source2 = externalPartnerDetail.Counsel.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => !x.IsDeleted)).GroupBy(i => new
      {
        Name = i.Name,
        MemberType = i.MemberType
      }).Where<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>(g => g.Count<ExternalPartner>() > 1);
      IEnumerable<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>> source3 = externalPartnerDetail.OtherPartner.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => !x.IsDeleted)).GroupBy(i => new
      {
        Name = i.Name,
        MemberType = i.MemberType
      }).Where<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>(g => g.Count<ExternalPartner>() > 1);
      externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => (i.MemberType == -3L || i.MemberType == -4L) && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => (i.MemberType == -3L || i.MemberType == -4L || i.MemberType == -5L) && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      IEnumerable<long> source4 = externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => i.MemberType == -3L && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      IEnumerable<long> source5 = externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => i.MemberType == -4L && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => i.MemberType == -7L && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => i.MemberType == -3L && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      IEnumerable<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>> source6 = externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (x => !x.IsDeleted)).GroupBy(i => new
      {
        Name = i.Name,
        MemberType = i.MemberType
      }).Where<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>(g => g.Count<ExternalPartner>() > 1);
      externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => i.MemberType != -9L && i.MemberType != -8L && !i.LiabilityPerc.HasValue && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      IEnumerable<long> source7 = externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => (i.MemberType == -9L || i.MemberType == -8L) && i.LiabilityPerc.HasValue && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      IEnumerable<long> source8 = externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => (i.MemberType == -9L || i.MemberType == -8L) && i.EstMgmtFee.HasValue && !i.IsDeleted)).Select<ExternalPartner, long>((Func<ExternalPartner, long>) (i => i.MemberType));
      Decimal? nullable1 = externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => !i.IsDeleted)).Select<ExternalPartner, Decimal?>((Func<ExternalPartner, Decimal?>) (i => i.LiabilityPerc)).Sum();
      Decimal? nullable2 = externalPartnerDetail.SyndicateMember.Where<ExternalPartner>((Func<ExternalPartner, bool>) (i => !i.IsDeleted)).Select<ExternalPartner, Decimal?>((Func<ExternalPartner, Decimal?>) (i => i.EstMgmtFee)).Sum();
      Decimal? nullable3 = nullable1;
      Decimal? firmLiabilityPerc = issueDetail.FirmLiabilityPerc;
      Decimal? nullable4 = nullable3.HasValue & firmLiabilityPerc.HasValue ? new Decimal?(nullable3.GetValueOrDefault() + firmLiabilityPerc.GetValueOrDefault()) : new Decimal?();
      Decimal? nullable5 = nullable2;
      nullable3 = issueDetail.FirmMgmtFeePerc;
      Decimal? nullable6 = nullable5.HasValue & nullable3.HasValue ? new Decimal?(nullable5.GetValueOrDefault() + nullable3.GetValueOrDefault()) : new Decimal?();
      long? firmRoleId;
      if (source4.Count<long>() >= 1)
      {
        firmRoleId = issueDetail.FirmRoleId;
        long num = -12;
        if ((firmRoleId.GetValueOrDefault() == num ? (firmRoleId.HasValue ? 1 : 0) : 0) != 0)
        {
          saveResult.Errors.Add("ExternalPartner Syndicate agent type", (object) "There can be only one Sole Mgr/Senior Mgr.");
          goto label_6;
        }
      }
      if (source5.Count<long>() >= 1)
      {
        firmRoleId = issueDetail.FirmRoleId;
        long num = -13;
        if ((firmRoleId.GetValueOrDefault() == num ? (firmRoleId.HasValue ? 1 : 0) : 0) != 0)
          saveResult.Errors.Add("ExternalPartner Syndicate agent type", (object) "There can be only one Sole Mgr/Senior Mgr.");
      }
label_6:
      if (source6.Count<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>() > 0)
        saveResult.Errors.Add("ExternalPartner Syndicate Agent", (object) "Duplicate Syndicate agent.");
      nullable3 = nullable4;
      Decimal num1 = (Decimal) 100;
      if ((nullable3.GetValueOrDefault() > num1 ? (nullable3.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("ExternalPartner participation %", (object) "The sum of Liability % cannot exceed 100%.");
      nullable3 = nullable6;
      Decimal num2 = (Decimal) 100;
      if ((nullable3.GetValueOrDefault() > num2 ? (nullable3.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("ExternalPartner Est. mgmt fee ", (object) "The sum of Management Fee % cannot exceed 100%.");
      if (source7.Count<long>() > 0)
        saveResult.Errors.Add("ExternalPartner Syndicate Member Liability not applicable", (object) "Syndicate Member Liability % is not applicable on selling group member(s) and participant(s).");
      if (source8.Count<long>() > 0)
        saveResult.Errors.Add("ExternalPartner Syndicate member estimation management not applicable", (object) "Syndicate Member Management Fee % is not applicable on selling group member(s) and participant(s).");
      if (source1.Count<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>() > 0)
        saveResult.Errors.Add("ExternalPartner Advisor Agent", (object) "Duplicate Advisor/Agent.");
      if (source2.Count<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>() > 0)
        saveResult.Errors.Add("ExternalPartner Counsel", (object) "Duplicate Counsel.");
      if (source3.Count<IGrouping<\u003C\u003Ef__AnonymousType7<string, long>, ExternalPartner>>() <= 0)
        return;
      saveResult.Errors.Add("ExternalPartner Other Partner", (object) "Duplicate Other Partner.");
    }

    private void SetIssuePermissions(IssueViewModelContainer issueContainer)
    {
      if (issueContainer.IssueDetail.AppTransactionID == 0L && (issueContainer.IssueDetail.IssueStatus == null || issueContainer.IssueDetail.IssueStatus.Count == 0))
      {
        issueContainer.IssueDetail.IssueStatus = new List<long>()
        {
          1L
        };
        if (this.issueCurrentStatus == null)
          this.issueCurrentStatus = new List<IssueEnums.IssueStatus>();
        this.issueCurrentStatus.Add(IssueEnums.IssueStatus.Open);
      }
      IssuePresenter.IssueEditOnlyStatus editOnlyStatus = this.SetIssueEditOnlyStatus(this.issueCurrentStatus, issueContainer.IssueDetail.AppTransactionID);
      issueContainer.IssueDetail.IsIssueDetailsViewOnly = !editOnlyStatus.isIssueDetailsEditable;
      issueContainer.IssueDetail.IsRestrictedCusipViewOnly = !editOnlyStatus.isRestrictedCusipEditable;
      issueContainer.IssueDetail.IsMiscViewOnly = !editOnlyStatus.isMiscEditable;
      issueContainer.InternalPartnerDetail.InternalPartnerIsViewOnly = !editOnlyStatus.isInternalPartnerEditable;
      issueContainer.ExternalPartnerDetail.ExternalPartnerIsViewOnly = !editOnlyStatus.isExternalPartnerEditable;
      issueContainer.TransactionReportDetail.TransactionReportIsViewOnly = !editOnlyStatus.isTransactionReportEditable;
      issueContainer.IssueDetail.IsIssueReviewViewOnly = !editOnlyStatus.isIssueReviewEditable;
      IssuePresenter.IssueViewOnlyStatus issueViewOnlyStatus = this.SetIssueViewOnlyStatus(issueContainer.IssueDetail.AppTransactionID, issueContainer.IssueDetail.IssueStatus);
      issueContainer.IssueDetail.IsIssueDetailsVisible = issueViewOnlyStatus.isIssueDetailsVisible;
      issueContainer.IssueDetail.IsInternalPartnerVisible = issueViewOnlyStatus.isInternalPartnerVisible;
      issueContainer.IssueDetail.IsExternalPartnerVisible = issueViewOnlyStatus.isExternalPartnerVisible;
      issueContainer.IssueDetail.IsIssueRatingVisible = issueViewOnlyStatus.isIssueRatingVisible;
      issueContainer.IssueDetail.IsIssuePricingVisible = issueViewOnlyStatus.isIssuePricingVisible;
      issueContainer.IssueDetail.IsRestrictedCusipVisible = issueViewOnlyStatus.isRestrictedCusipVisible;
      issueContainer.IssueDetail.IsTransactionReportVisible = issueViewOnlyStatus.isTransactionReportVisible;
      issueContainer.IssueDetail.IsIssueReviewVisible = issueViewOnlyStatus.isIssueReviewVisible;
      issueContainer.IssueDetail.IsAuditTrailVisible = issueViewOnlyStatus.isAuditTrailVisible;
      issueContainer.IssueDetail.IsMiscVisible = issueViewOnlyStatus.isMiscVisible;
      issueContainer.IssueDetail.IsIssueDocumentsVisible = issueViewOnlyStatus.isIssueDocumentsVisible;
      issueContainer.IssueDetail.IsIssueContactsVisible = issueViewOnlyStatus.isIssueContactsVisible;
      issueContainer.IssueDetail.IsIssueEditable = this.FetchIssueEditableStatus(editOnlyStatus);
      issueContainer.IssueDetail.IsIssuerContactEditable = this.FetchIssuerContactEditableStatus(editOnlyStatus.isIssueDetailsEditable);
      issueContainer.IssueDetail.ViewIssueDocument = this.HasUIPermissionForEntityStatus(issueContainer.IssueDetail.AppTransactionID, "Issue Documents", "View", issueContainer.IssueDetail.IssueStatus);
      issueContainer.IssueDetail.ViewG37Form = this.HasUIPermissionForEntity(0L, issueContainer.IssueDetail.AppTransactionID, "Issue G-37 Form", "View");
      issueContainer.IssueDetail.ViewIssueClosureChecklist = this.HasUIPermissionForEntity(-32L, issueContainer.IssueDetail.AppTransactionID, "Issue Closure Checklist", "View");
      issueContainer.IssueDetail.ViewCopyIssue = this.HasEntityPermission(-32L, "Issue Detail", "Create");
      issueContainer.CanUploadIssueDocuments = this.HasPermissionToUploadDoc(issueContainer.IssueDetail.AppTransactionID);
      issueContainer.CanAccessTransactionPnL = this.AuthorizationService.HasSecurityPermission(this.AppUser, -34L, "PnL Form", "View");
      issueContainer.IssueDetail.IsPnlAuditTrailVisible = this.AuthorizationService.HasSecurityPermission(this.AppUser, -34L, "PnL Audit Trail", "View");
    }

    private bool CanViewUI(
      long appTransID,
      string uiName,
      string permission,
      List<long> statusList)
    {
      return appTransID <= 0L ? this.HasEntityPermission(1L, uiName, permission) : this.HasUIPermissionForEntityStatus(appTransID, uiName, permission, statusList);
    }

    private bool FetchViewIssueDocumentStatus(long appTransactionID, List<long> statusList) => appTransactionID <= 0L ? this.HasEntityPermission(-32L, "Issue Documents", "View") : this.HasUIPermissionForEntityStatus(appTransactionID, "Issue Documents", "View", statusList);

    private bool FetchIssueEditableStatus(IssuePresenter.IssueEditOnlyStatus editOnlyStatus) => !editOnlyStatus.isIssueDetailsEditable && !editOnlyStatus.isInternalPartnerEditable && (!editOnlyStatus.isExternalPartnerEditable && !editOnlyStatus.isIssueRatingEditable) && (!editOnlyStatus.isIssuePricingEditable && !editOnlyStatus.isTransactionReportEditable && (!editOnlyStatus.isRestrictedCusipEditable && !editOnlyStatus.isMiscEditable)) && !editOnlyStatus.isIssueReviewEditable;

    private bool FetchIssuerContactEditableStatus(bool isIssueDetailEditable)
    {
      if (!isIssueDetailEditable)
        return false;
      return this.HasIndependentPermission("Client Contact", "Add") || this.HasIndependentPermission("Client Contact", "Edit");
    }

    private bool IsUIEditable(long appTransactionID, string uiName, List<long> statusList) => appTransactionID == 0L ? this.HasEntityPermission(-32L, uiName, "Edit") : this.HasUIPermissionForEntityStatus(appTransactionID, uiName, "Edit", statusList);

    private bool IsUIVisible(long appTransactionID, string uiName, List<long> statusList) => appTransactionID <= 0L ? this.HasEntityPermission(-32L, uiName, "View") : this.HasUIPermissionForEntityStatus(appTransactionID, uiName, "View", statusList);

    private IssuePresenter.IssueEditOnlyStatus SetIssueEditOnlyStatus(
      List<IssueEnums.IssueStatus> issueStatusList,
      long appTransactionID)
    {
      IssuePresenter.IssueEditOnlyStatus issueEditOnlyStatus = new IssuePresenter.IssueEditOnlyStatus();
      List<long> statusList = issueStatusList.ConvertAll<long>((Converter<IssueEnums.IssueStatus, long>) (s => (long) s));
      issueEditOnlyStatus.isIssueDetailsEditable = this.IsUIEditable(appTransactionID, "Issue Detail", statusList);
      issueEditOnlyStatus.isInternalPartnerEditable = this.IsUIEditable(appTransactionID, "Internal Partners", statusList);
      issueEditOnlyStatus.isExternalPartnerEditable = this.IsUIEditable(appTransactionID, "External Partners", statusList);
      issueEditOnlyStatus.isIssueRatingEditable = this.IsUIEditable(appTransactionID, "Issue Ratings", statusList);
      issueEditOnlyStatus.isIssuePricingEditable = this.IsUIEditable(appTransactionID, "Pricing", statusList);
      issueEditOnlyStatus.isRestrictedCusipEditable = this.IsUIEditable(appTransactionID, "Restricted Cusip", statusList);
      issueEditOnlyStatus.isTransactionReportEditable = this.IsUIEditable(appTransactionID, "Transaction Report", statusList);
      issueEditOnlyStatus.isMiscEditable = this.IsUIEditable(appTransactionID, "Misc", statusList);
      issueEditOnlyStatus.isIssueReviewEditable = this.IsUIEditable(appTransactionID, "Issue Review", statusList);
      return issueEditOnlyStatus;
    }

    private IssuePresenter.IssueViewOnlyStatus SetIssueViewOnlyStatus(
      long appTransactionID,
      List<long> statusList)
    {
      return new IssuePresenter.IssueViewOnlyStatus()
      {
        isIssueDetailsVisible = this.IsUIVisible(appTransactionID, "Issue Detail", statusList),
        isInternalPartnerVisible = this.IsUIVisible(appTransactionID, "Issue Detail", statusList),
        isExternalPartnerVisible = this.IsUIVisible(appTransactionID, "External Partners", statusList),
        isIssueRatingVisible = this.IsUIVisible(appTransactionID, "Issue Ratings", statusList),
        isIssuePricingVisible = this.IsUIVisible(appTransactionID, "Pricing", statusList),
        isRestrictedCusipVisible = this.IsUIVisible(appTransactionID, "Restricted Cusip", statusList),
        isTransactionReportVisible = this.IsUIVisible(appTransactionID, "Transaction Report", statusList),
        isAuditTrailVisible = this.IsUIVisible(appTransactionID, "Issue Audit Trail", statusList),
        isIssueDocumentsVisible = this.IsUIVisible(appTransactionID, "Issue Documents", statusList),
        isIssueContactsVisible = this.IsUIVisible(appTransactionID, "Issue Contacts", statusList),
        isIssueReviewVisible = this.IsUIVisible(appTransactionID, "Issue Review", statusList),
        isMiscVisible = this.IsUIVisible(appTransactionID, "Misc", statusList)
      };
    }

    private List<int> GetTransitionStateTracking(
      List<IssueEnums.IssueStatus> oldStatusList,
      TransitionResult<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> transitionResult)
    {
      List<int> intList = new List<int>();
      IEnumerable<IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>> resultingStates = transitionResult.ResultingStates;
      IEnumerable<IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>> intermediateStates = transitionResult.IntermediateStates;
      if (intermediateStates != null && intermediateStates.Count<IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>>() > 0)
      {
        IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> actionState = transitionResult.ActionState;
        foreach (IssueEnums.IssueStatus oldStatus in oldStatusList)
        {
          if (actionState != null && oldStatus != actionState.Key)
            intList.Add((int) oldStatus);
        }
        foreach (IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> state in intermediateStates)
          intList.Add((int) state.Key);
      }
      else
      {
        foreach (IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> state in resultingStates)
          intList.Add((int) state.Key);
      }
      return intList;
    }

    public IssueRatingViewModel GetIssueRatingDetails(long appTransID)
    {
      try
      {
        if (appTransID == 0L)
        {
          if (!this.HasEntityPermission(-32L, "Issue Ratings", "View"))
          {
            IssueRatingViewModel issueRatingViewModel = new IssueRatingViewModel();
            issueRatingViewModel.ErrorMessage = "You are not authorized to access this resource.";
            return issueRatingViewModel;
          }
        }
        else if (!this.HasUIPermissionForEntity(-32L, appTransID, "Issue Ratings", "View"))
        {
          IssueRatingViewModel issueRatingViewModel = new IssueRatingViewModel();
          issueRatingViewModel.ErrorMessage = "You are not authorized to access this resource.";
          return issueRatingViewModel;
        }
        IssueRatingViewModel issueRatingViewModel1 = new IssueRatingViewModel(this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetRatingLookupItemKeys()).ToList<LookupItemMappings>());
        using (IDataReader dataReader = this.IssuePricingRepository.FetchIssueStatusByAppTransactionID(appTransID))
        {
          if (this.issueCurrentStatus == null)
            this.issueCurrentStatus = new List<IssueEnums.IssueStatus>();
          while (dataReader.Read())
            this.issueCurrentStatus.Add((IssueEnums.IssueStatus) Convert.ToInt64(dataReader["StateID"]));
          if (this.issueCurrentStatus.Count == 0)
            this.issueCurrentStatus.Add(IssueEnums.IssueStatus.Open);
        }
        IssuePresenter.IssueEditOnlyStatus issueEditOnlyStatus = this.SetIssueEditOnlyStatus(this.issueCurrentStatus, appTransID);
        issueRatingViewModel1.isRatingViewOnly = !issueEditOnlyStatus.isIssueRatingEditable;
        using (IDataReader dataReader = this.IssueRatingRepository.FetchSeriesDetails(appTransID))
        {
          if (dataReader != null)
          {
            while (dataReader.Read())
            {
              List<LookupItemMappings> series = issueRatingViewModel1.Series;
              LookupItemMappings lookupItemMappings = new LookupItemMappings();
              lookupItemMappings.Key = dataReader["SeriesID"].ToString();
              lookupItemMappings.Value = dataReader["SeriesName"].ToString();
              lookupItemMappings.IsActive = true;
              series.Add(lookupItemMappings);
              issueRatingViewModel1.SeriesData.Add(new SeriesData()
              {
                SeriesID = Convert.ToInt64(dataReader["SeriesID"].ToString()),
                SeriesName = dataReader["SeriesName"].ToString(),
                SeriesCode = dataReader["SeriesCode"].ToString()
              });
              issueRatingViewModel1.UnderlyingRating.Add(new UnderlyingRatingsViewModel()
              {
                Series = dataReader["SeriesCode"].ToString(),
                SeriesId = Convert.ToInt64(dataReader["SeriesID"].ToString()),
                MoodyRatingLT = dataReader["MoodyRatingLT"].ToString(),
                MoodyRatingLTOutlook = dataReader["MoodyRatingLTOutlook"].ToString(),
                MoodyRatingST = dataReader["MoodyRatingST"].ToString(),
                MoodyRatingSTOutlook = dataReader["MoodyRatingSTOutlook"].ToString(),
                SPRatingLT = dataReader["SPRatingLT"].ToString(),
                SPRatingLTOutlook = dataReader["SPRatingLTOutlook"].ToString(),
                SPRatingST = dataReader["SPRatingST"].ToString(),
                SPRatingSTOutlook = dataReader["SPRatingSTOutlook"].ToString(),
                KrollRatingLT = dataReader["KrollRatingLT"].ToString(),
                KrollRatingLTOutlook = dataReader["KrollRatingLTOutlook"].ToString(),
                KrollRatingST = dataReader["KrollRatingST"].ToString(),
                KrollRatingSTOutlook = dataReader["KrollRatingSTOutlook"].ToString(),
                FitchRatingLT = dataReader["FitchRatingLT"].ToString(),
                FitchRatingLTOutlook = dataReader["FitchRatingLTOutlook"].ToString(),
                FitchRatingST = dataReader["FitchRatingST"].ToString(),
                FitchRatingSTOutlook = dataReader["FitchRatingSTOutlook"].ToString()
              });
            }
          }
        }
        using (IDataReader dataReader = this.IssueRatingRepository.FetchEnhancedRatingDetails(appTransID))
        {
          if (dataReader != null)
          {
            while (dataReader.Read())
              issueRatingViewModel1.EnhancedRating.Add(new EnhancedRatingsViewModel()
              {
                EnhancedRatingID = Convert.ToInt64(dataReader["EnhancedRatingID"]),
                SeriesId = Convert.ToInt64(dataReader["SeriesID"]),
                MoodyRatingLT = dataReader["EnMoodyRatingLT"].ToString(),
                MoodyRatingLTOutlook = dataReader["EnMoodyRatingLTOutlook"].ToString(),
                MoodyRatingST = dataReader["EnMoodyRatingST"].ToString(),
                MoodyRatingSTOutlook = dataReader["EnMoodyRatingSTOutlook"].ToString(),
                SPRatingLT = dataReader["EnSPRatingLT"].ToString(),
                SPRatingLTOutlook = dataReader["EnSPRatingLTOutlook"].ToString(),
                SPRatingST = dataReader["EnSPRatingST"].ToString(),
                SPRatingSTOutlook = dataReader["EnSPRatingSTOutlook"].ToString(),
                KrollRatingLT = dataReader["EnKrollRatingLT"].ToString(),
                KrollRatingLTOutlook = dataReader["EnKrollRatingLTOutlook"].ToString(),
                KrollRatingST = dataReader["EnKrollRatingST"].ToString(),
                KrollRatingSTOutlook = dataReader["EnKrollRatingSTOutlook"].ToString(),
                FitchRatingLT = dataReader["EnFitchRatingLT"].ToString(),
                FitchRatingLTOutlook = dataReader["EnFitchRatingLTOutlook"].ToString(),
                FitchRatingST = dataReader["EnFitchRatingST"].ToString(),
                FitchRatingSTOutlook = dataReader["EnFitchRatingSTOutlook"].ToString(),
                CreditEnhancementProviderText = dataReader["CreditEnhancementProvider"].ToString(),
                Series = dataReader["SeriesCode"].ToString(),
                CreditEnhancementProvider = new KeyPair()
                {
                  Key = dataReader["CreditEnhancementProvider"] == null ? string.Empty : dataReader["CreditEnhancementProvider"].ToString(),
                  Value = dataReader["CreditEnhancementProvider"] == null ? string.Empty : dataReader["CreditEnhancementProviderName"].ToString()
                },
                CreditEnhancementType = dataReader["CreditEnhancementType"] == null ? string.Empty : dataReader["CreditEnhancementType"].ToString(),
                CreditEnhancementTypeText = dataReader["CreditEnhancementTypeText"] == null ? string.Empty : dataReader["CreditEnhancementTypeText"].ToString(),
                OtherCreditEnhancementType = dataReader["OtherCreditEnhancementType"] == null ? string.Empty : dataReader["OtherCreditEnhancementType"].ToString(),
                CEExpirationDate = dataReader["CEExpirationDate"] == DBNull.Value ? new DateTime?() : new DateTime?(Convert.ToDateTime(dataReader["CEExpirationDate"]))
              });
          }
        }
        return issueRatingViewModel1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueRatingViewModel issueRatingViewModel = new IssueRatingViewModel();
        issueRatingViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return issueRatingViewModel;
      }
    }

    private DataTable ReturnEnhancedRatingsDataTable(
      List<EnhancedRatingsViewModel> enhancedRatings)
    {
      DataTable dataTable = new DataTable("EnhancedRatingsViewModel");
      dataTable.Columns.Add(new DataColumn("seriesID", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementprovider", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementProviderText", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementType", typeof (long)));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementTypeText", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("Series", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("IsDirty", Type.GetType("System.Boolean")));
      dataTable.Columns.Add(new DataColumn("IsDeleted", Type.GetType("System.Boolean")));
      dataTable.Columns.Add(new DataColumn("OtherCreditEnhancementType", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("CEExpirationDate", Type.GetType("System.DateTime")));
      foreach (EnhancedRatingsViewModel enhancedRating in enhancedRatings)
      {
        DataRow row = dataTable.NewRow();
        row["seriesID"] = (object) enhancedRating.SeriesId;
        row["MoodyRatingLT"] = (object) enhancedRating.MoodyRatingLT;
        row["MoodyRatingLTOutlook"] = (object) enhancedRating.MoodyRatingLTOutlook;
        row["MoodyRatingST"] = (object) enhancedRating.MoodyRatingST;
        row["MoodyRatingSTOutlook"] = (object) enhancedRating.MoodyRatingSTOutlook;
        row["SPRatingLT"] = (object) enhancedRating.SPRatingLT;
        row["SPRatingLTOutlook"] = (object) enhancedRating.SPRatingLTOutlook;
        row["SPRatingST"] = (object) enhancedRating.SPRatingST;
        row["SPRatingSTOutlook"] = (object) enhancedRating.SPRatingSTOutlook;
        row["KrollRatingLT"] = (object) enhancedRating.KrollRatingLT;
        row["KrollRatingLTOutlook"] = (object) enhancedRating.KrollRatingLTOutlook;
        row["KrollRatingST"] = (object) enhancedRating.KrollRatingST;
        row["KrollRatingSTOutlook"] = (object) enhancedRating.KrollRatingSTOutlook;
        row["FitchRatingLT"] = (object) enhancedRating.FitchRatingLT;
        row["FitchRatingLTOutlook"] = (object) enhancedRating.FitchRatingLTOutlook;
        row["FitchRatingST"] = (object) enhancedRating.FitchRatingST;
        row["FitchRatingSTOutlook"] = (object) enhancedRating.FitchRatingSTOutlook;
        row["CreditEnhancementprovider"] = !string.IsNullOrEmpty(enhancedRating.CreditEnhancementProvider.Key) ? (object) enhancedRating.CreditEnhancementProvider.Key : (object) DBNull.Value;
        row["CreditEnhancementProviderText"] = (object) enhancedRating.CreditEnhancementProviderText;
        if (string.IsNullOrEmpty(enhancedRating.CreditEnhancementType))
        {
          row["CreditEnhancementType"] = (object) DBNull.Value;
          row["CreditEnhancementTypeText"] = (object) DBNull.Value;
        }
        else
        {
          row["CreditEnhancementType"] = (object) enhancedRating.CreditEnhancementType;
          row["CreditEnhancementTypeText"] = (object) enhancedRating.CreditEnhancementTypeText;
        }
        row["OtherCreditEnhancementType"] = (object) enhancedRating.OtherCreditEnhancementType;
        DateTime? ceExpirationDate = enhancedRating.CEExpirationDate;
        row["CEExpirationDate"] = !ceExpirationDate.HasValue ? (object) DBNull.Value : (object) enhancedRating.CEExpirationDate;
        row["Series"] = (object) enhancedRating.Series;
        row["IsDirty"] = (object) enhancedRating.IsDirty;
        row["IsDeleted"] = (object) enhancedRating.IsDeleted;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    private DataTable ReturnUnderlyingRatingsDataTable(
      List<UnderlyingRatingsViewModel> underlyingRatings)
    {
      DataTable dataTable = new DataTable("UnderlyingRatingsViewModel");
      dataTable.Columns.Add(new DataColumn("seriesID", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("Series", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("IsDirty", Type.GetType("System.Boolean")));
      dataTable.Columns.Add(new DataColumn("IsDeleted", Type.GetType("System.Boolean")));
      foreach (UnderlyingRatingsViewModel underlyingRating in underlyingRatings)
      {
        DataRow row = dataTable.NewRow();
        row["seriesID"] = (object) underlyingRating.SeriesId;
        row["MoodyRatingLT"] = (object) underlyingRating.MoodyRatingLT;
        row["MoodyRatingLTOutlook"] = (object) underlyingRating.MoodyRatingLTOutlook;
        row["MoodyRatingST"] = (object) underlyingRating.MoodyRatingST;
        row["MoodyRatingSTOutlook"] = (object) underlyingRating.MoodyRatingSTOutlook;
        row["SPRatingLT"] = (object) underlyingRating.SPRatingLT;
        row["SPRatingLTOutlook"] = (object) underlyingRating.SPRatingLTOutlook;
        row["SPRatingST"] = (object) underlyingRating.SPRatingST;
        row["SPRatingSTOutlook"] = (object) underlyingRating.SPRatingSTOutlook;
        row["KrollRatingLT"] = (object) underlyingRating.KrollRatingLT;
        row["KrollRatingLTOutlook"] = (object) underlyingRating.KrollRatingLTOutlook;
        row["KrollRatingST"] = (object) underlyingRating.KrollRatingST;
        row["KrollRatingSTOutlook"] = (object) underlyingRating.KrollRatingSTOutlook;
        row["FitchRatingLT"] = (object) underlyingRating.FitchRatingLT;
        row["FitchRatingLTOutlook"] = (object) underlyingRating.FitchRatingLTOutlook;
        row["FitchRatingST"] = (object) underlyingRating.FitchRatingST;
        row["FitchRatingSTOutlook"] = (object) underlyingRating.FitchRatingSTOutlook;
        row["Series"] = (object) underlyingRating.Series;
        row["IsDirty"] = (object) underlyingRating.IsDirty;
        row["IsDeleted"] = (object) underlyingRating.IsDeleted;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    private List<Series> GetSeriesDataFromUnderlyingRatings(
      List<UnderlyingRatingsViewModel> underlyingRatings,
      long appTransactionID)
    {
      List<Series> seriesList = new List<Series>();
      foreach (UnderlyingRatingsViewModel underlyingRating in underlyingRatings)
        seriesList.Add(new Series()
        {
          AppTransactionID = appTransactionID,
          KrollRatingLT = underlyingRating.KrollRatingLT,
          KrollRatingLTOutlook = underlyingRating.KrollRatingLTOutlook,
          KrollRatingST = underlyingRating.KrollRatingST,
          KrollRatingSTOutlook = underlyingRating.KrollRatingSTOutlook,
          FitchRatingLT = underlyingRating.FitchRatingLT,
          FitchRatingLTOutlook = underlyingRating.FitchRatingLTOutlook,
          FitchRatingST = underlyingRating.FitchRatingST,
          FitchRatingSTOutlook = underlyingRating.FitchRatingSTOutlook,
          MoodyRatingLT = underlyingRating.MoodyRatingLT,
          MoodyRatingLTOutlook = underlyingRating.MoodyRatingLTOutlook,
          MoodyRatingST = underlyingRating.MoodyRatingST,
          MoodyRatingSTOutlook = underlyingRating.MoodyRatingSTOutlook,
          SeriesName = underlyingRating.Series,
          SPRatingLT = underlyingRating.SPRatingLT,
          SPRatingLTOutlook = underlyingRating.SPRatingLTOutlook,
          SPRatingST = underlyingRating.SPRatingST,
          SPRatingSTOutlook = underlyingRating.SPRatingSTOutlook
        });
      return seriesList;
    }

    public List<KeyPair> GetCEProviders(string providerName)
    {
      try
      {
        List<KeyPair> keyPairList = new List<KeyPair>();
        using (IDataReader dataReader = this.IssueRatingRepository.FetchCEProvidersByName(providerName))
        {
          if (dataReader != null)
          {
            IRowMapper<KeyPair> rowMapper = MapBuilder<KeyPair>.MapAllProperties().Map<string>((Expression<Func<KeyPair, string>>) (x => x.Key)).ToColumn("PartnerID").Map<string>((Expression<Func<KeyPair, string>>) (x => x.Value)).ToColumn("Name").Build();
            while (dataReader.Read())
              keyPairList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return keyPairList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<KeyPair>();
      }
    }

    public IssuePricingViewModel GetIssuePricingDetails(
      long appTransID,
      bool IsCopyIssue = false)
    {
      try
      {
        if (appTransID == 0L)
        {
          if (!this.HasEntityPermission(-32L, "Pricing", "View"))
          {
            IssuePricingViewModel pricingViewModel = new IssuePricingViewModel();
            pricingViewModel.ErrorMessage = "You are not authorized to access this resource.";
            return pricingViewModel;
          }
        }
        else if (!this.HasUIPermissionForEntity(-32L, appTransID, "Pricing", "View"))
        {
          IssuePricingViewModel pricingViewModel = new IssuePricingViewModel();
          pricingViewModel.ErrorMessage = "You are not authorized to access this resource.";
          return pricingViewModel;
        }
        IssuePricingViewModel pricingViewModel1 = new IssuePricingViewModel();
        long pricingStatus = 0;
        using (IDataReader reader = this.IssuePricingRepository.FetchIssuePricings(appTransID, IsCopyIssue))
        {
          if (reader != null)
          {
            IRowMapper<PricingViewModel> rowMapper1 = MapBuilder<PricingViewModel>.MapAllProperties().Map<DateTime?>((Expression<Func<PricingViewModel, DateTime?>>) (x => x.CouponDate)).ToColumn("FirstCouponDate").Map<string>((Expression<Func<PricingViewModel, string>>) (x => x.AmtTax)).ToColumn("AMTTaxable").Map<string>((Expression<Func<PricingViewModel, string>>) (x => x.StateTax)).ToColumn("StateTaxable").Map<string>((Expression<Func<PricingViewModel, string>>) (x => x.AccureForm)).ToColumn("AccrueFrom").DoNotMap<bool>((Expression<Func<PricingViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PricingViewModel, string>>) (x => x.SeriesDataUpdate)).DoNotMap<bool>((Expression<Func<PricingViewModel, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<PricingViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<string>((Expression<Func<PricingViewModel, string>>) (x => x.SUMAmount)).DoNotMap<bool>((Expression<Func<PricingViewModel, bool>>) (x => x.IsParAmountMisMatch)).Build();
            IRowMapper<CusipViewModel> rowMapper2 = MapBuilder<CusipViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<CusipViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<CusipViewModel, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<CusipViewModel, string>>) (x => x.ErrorMessage)).Build();
            while (reader.Read())
              pricingViewModel1.IssuerPricing.Add(rowMapper1.MapRow((IDataRecord) reader));
            List<CusipViewModel> cusipViewModelList = new List<CusipViewModel>();
            if (reader.NextResult())
            {
              while (reader.Read())
                cusipViewModelList.Add(rowMapper2.MapRow((IDataRecord) reader));
            }
            if (reader.NextResult() && reader.Read() && !reader.IsDBNull(0))
              pricingStatus = reader.GetInt64(0);
            if (reader.NextResult())
              pricingViewModel1.PriorityOfOrderDetails = this.GetPriorityOfOrderDetails(reader);
            foreach (PricingViewModel pricingViewModel2 in pricingViewModel1.IssuerPricing)
            {
              PricingViewModel v = pricingViewModel2;
              v.CUSIP = cusipViewModelList.FindAll((Predicate<CusipViewModel>) (x => x.SeriesID == v.SeriesID));
              v.SUMAmount = string.Format("{0}", (object) v.CUSIP.Sum<CusipViewModel>((Func<CusipViewModel, double>) (x => Convert.ToDouble(x.Amount))));
              v.IsParAmountMisMatch = Convert.ToDouble(v.SUMAmount) == Convert.ToDouble(v.ParAmount);
              if (v.CUSIP.Count == 0)
              {
                v.CUSIP = new List<CusipViewModel>()
                {
                  new CusipViewModel()
                  {
                    Amount = "",
                    AverageLife = "",
                    Coupon = "",
                    CUSIP = "",
                    Price = "",
                    SeriesID = v.SeriesID,
                    Term = "",
                    Yield = "",
                    YTM = ""
                  }
                };
              }
              else
              {
                foreach (CusipViewModel cusipViewModel in v.CUSIP)
                {
                  cusipViewModel.Amount = !string.IsNullOrEmpty(cusipViewModel.Amount) ? ((long) Convert.ToDecimal(cusipViewModel.Amount)).ToString("#,##0") : cusipViewModel.Amount;
                  cusipViewModel.Price = !string.IsNullOrEmpty(cusipViewModel.Price) ? Convert.ToDecimal(cusipViewModel.Price).ToString("N3") : cusipViewModel.Price;
                  cusipViewModel.AverageLife = !string.IsNullOrEmpty(cusipViewModel.AverageLife) ? Convert.ToDecimal(cusipViewModel.AverageLife).ToString("N3") : cusipViewModel.AverageLife;
                  cusipViewModel.YTM = !string.IsNullOrEmpty(cusipViewModel.YTM) ? Convert.ToDecimal(cusipViewModel.YTM).ToString("N3") : cusipViewModel.YTM;
                  cusipViewModel.Takedown = !string.IsNullOrEmpty(cusipViewModel.Takedown) ? Convert.ToDecimal(cusipViewModel.Takedown).ToString("N4") : cusipViewModel.Takedown;
                }
              }
            }
          }
        }
        IEnumerable<LookupItemMappings> source = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetPricingLookupItemKeys(), this.GetPricingLookupItemsID(pricingViewModel1.IssuerPricing));
        pricingViewModel1.InitializeLookupItems(source.ToList<LookupItemMappings>());
        pricingViewModel1.PricingStatus = pricingViewModel1.PricingStatuses.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.LookupItemID == pricingStatus)).FirstOrDefault<LookupItemMappings>();
        using (IDataReader dataReader = this.IssuePricingRepository.FetchIssueStatusByAppTransactionID(appTransID))
        {
          if (this.issueCurrentStatus == null)
            this.issueCurrentStatus = new List<IssueEnums.IssueStatus>();
          while (dataReader.Read())
            this.issueCurrentStatus.Add((IssueEnums.IssueStatus) Convert.ToInt64(dataReader["StateID"]));
          if (this.issueCurrentStatus.Count == 0)
            this.issueCurrentStatus.Add(IssueEnums.IssueStatus.Open);
        }
        IssuePresenter.IssueEditOnlyStatus issueEditOnlyStatus = this.SetIssueEditOnlyStatus(this.issueCurrentStatus, appTransID);
        pricingViewModel1.isPricingViewOnly = !issueEditOnlyStatus.isIssuePricingEditable;
        pricingViewModel1.isSubmitPricing = this.SetIssuePricingSubmitPermission(appTransID, issueEditOnlyStatus.isIssuePricingEditable);
        pricingViewModel1.isSendPricingEmailCalculated = this.SetIssuePricingEmailPermission(appTransID, pricingViewModel1.PricingStatus == null ? 0L : pricingViewModel1.PricingStatus.LookupItemID, issueEditOnlyStatus.isIssuePricingEditable);
        pricingViewModel1.isSendPricingEmail = !this.HasUIPermissionForEntity(-32L, appTransID, "Pricing", "SendEmail");
        this.GetPricingLookupItemsID(pricingViewModel1.IssuerPricing);
        if (!pricingViewModel1.isSendPricingEmail)
        {
          IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.FetchByKey(53);
          if (emailTemplate == null || !emailTemplate.IsActive)
            pricingViewModel1.isSendPricingEmail = true;
        }
        return pricingViewModel1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssuePricingViewModel pricingViewModel = new IssuePricingViewModel();
        pricingViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return pricingViewModel;
      }
    }

    private IEnumerable<PriorityOfOrderDetail> GetPriorityOfOrderDetails(
      IDataReader reader)
    {
      List<PriorityOfOrderDetail> priorityOfOrderDetailList = new List<PriorityOfOrderDetail>();
      IRowMapper<PriorityOfOrderDetail> rowMapper = MapBuilder<PriorityOfOrderDetail>.MapAllProperties().Build();
      while (reader.Read())
        priorityOfOrderDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return (IEnumerable<PriorityOfOrderDetail>) priorityOfOrderDetailList;
    }

    private string[] GetPricingLookupItemsID(List<PricingViewModel> pricingView)
    {
      List<string> stringList = new List<string>();
      foreach (PricingViewModel pricingViewModel in pricingView)
      {
        if (!string.IsNullOrEmpty(pricingViewModel.SecType))
          stringList.Add(pricingViewModel.SecType);
        if (!string.IsNullOrEmpty(pricingViewModel.AccureForm))
          stringList.Add(pricingViewModel.AccureForm);
        if (!string.IsNullOrEmpty(pricingViewModel.Form))
          stringList.Add(pricingViewModel.Form);
        if (!string.IsNullOrEmpty(pricingViewModel.CouponFreq))
          stringList.Add(pricingViewModel.CouponFreq);
        if (!string.IsNullOrEmpty(pricingViewModel.DayCount))
          stringList.Add(pricingViewModel.DayCount);
        if (!string.IsNullOrEmpty(pricingViewModel.PrincipalFreq))
          stringList.Add(pricingViewModel.PrincipalFreq);
        if (!string.IsNullOrEmpty(pricingViewModel.PricingStatus))
          stringList.Add(pricingViewModel.PricingStatus);
        if (!string.IsNullOrEmpty(pricingViewModel.PriorityOfOrders))
          stringList.Add(pricingViewModel.PriorityOfOrders);
        if (!string.IsNullOrEmpty(pricingViewModel.FirmRole))
          stringList.Add(pricingViewModel.FirmRole);
      }
      return stringList.ToArray();
    }

    private bool SetIssuePricingSubmitPermission(long appTransactionID, bool isPricingEditable) => !isPricingEditable || !this.HasUIPermissionForEntity(-32L, appTransactionID, "Pricing", "Publish");

    private bool SetIssuePricingEmailPermission(
      long appTransactionID,
      long lookupItemID,
      bool isPricingEditable)
    {
      return !isPricingEditable || !this.HasUIPermissionForEntity(-32L, appTransactionID, "Issue Detail", "SendEmail") || -37L != lookupItemID;
    }

    public SaveResult SaveIssuePricing(
      List<PricingViewModel> pricing,
      long appTransactionID)
    {
      try
      {
        DataTable pricingDt;
        DataTable cusipDt;
        this.ReturnIssuePricingDataTable(pricing, out pricingDt, out cusipDt);
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssuePricingRepository.SaveIssuePricings(appTransactionID, pricingDt, cusipDt);
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private void ReturnIssuePricingDataTable(
      List<PricingViewModel> pricing,
      out DataTable pricingDt,
      out DataTable cusipDt)
    {
      pricingDt = new DataTable("PricingViewModel");
      pricingDt.Columns.Add(new DataColumn("SeriesID", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("ParAmount", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("SecType", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("DatedDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("CouponDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("SettlementDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("FedTax", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("StateTax", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("AmtTax", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("BankQualified", typeof (bool)));
      pricingDt.Columns.Add(new DataColumn("AccureForm", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("Form", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("DayCount", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("RateType", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("CallFeature", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("CallDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("CallPrice", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("CouponFreq", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("Insurance", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("FirmInventory", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("StructureDateFrom", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("StructureDateTo", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("PrincipalFreq", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("Denomination", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("Security", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("SecurityDetails", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("PutDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("RecordDate", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("GrossSpread", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("Takedown", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("InsuranceFee", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("SecurityTypeSpecific", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("PriorityOfOrders", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("PricingDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("RetailOrderPeriodDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("ActualAwardDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("ActualAwardDateTimeZone", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("FirmRole", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("FirmLiability", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("FirmMgtFee", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("SDCCredit", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("SeriesDataUpdate", typeof (string)));
      cusipDt = new DataTable("CusipViewModel");
      cusipDt.Columns.Add(new DataColumn("SeriesID", typeof (double)));
      cusipDt.Columns.Add(new DataColumn("MaturityDate", typeof (DateTime)));
      cusipDt.Columns.Add(new DataColumn("CUSIP", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("Term", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("AverageLife", typeof (float)));
      cusipDt.Columns.Add(new DataColumn("Amount", typeof (Decimal)));
      cusipDt.Columns.Add(new DataColumn("Coupon", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("Yield", typeof (float)));
      cusipDt.Columns.Add(new DataColumn("Price", typeof (Decimal)));
      cusipDt.Columns.Add(new DataColumn("YTM", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("CallDate", typeof (DateTime)));
      cusipDt.Columns.Add(new DataColumn("Takedown", typeof (Decimal)));
      cusipDt.Columns.Add(new DataColumn("Insured", typeof (bool)));
      foreach (PricingViewModel pricingViewModel in pricing)
      {
        DataRow row1 = pricingDt.NewRow();
        row1["SeriesID"] = (object) pricingViewModel.SeriesID;
        row1["ParAmount"] = string.IsNullOrEmpty(pricingViewModel.ParAmount) ? (object) DBNull.Value : (object) pricingViewModel.ParAmount;
        row1["SecType"] = string.IsNullOrEmpty(pricingViewModel.SecType) ? (object) DBNull.Value : (object) pricingViewModel.SecType;
        DataRow dataRow1 = row1;
        DateTime? nullable = pricingViewModel.DatedDate;
        object obj1 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow1["DatedDate"] = obj1;
        DataRow dataRow2 = row1;
        nullable = pricingViewModel.CouponDate;
        object obj2 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow2["CouponDate"] = obj2;
        DataRow dataRow3 = row1;
        nullable = pricingViewModel.SettlementDate;
        object obj3 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow3["SettlementDate"] = obj3;
        row1["FedTax"] = string.IsNullOrEmpty(pricingViewModel.FedTax) ? (object) DBNull.Value : (object) pricingViewModel.FedTax;
        row1["StateTax"] = string.IsNullOrEmpty(pricingViewModel.StateTax) ? (object) DBNull.Value : (object) pricingViewModel.StateTax;
        row1["AmtTax"] = string.IsNullOrEmpty(pricingViewModel.AmtTax) ? (object) DBNull.Value : (object) pricingViewModel.AmtTax;
        row1["BankQualified"] = string.IsNullOrEmpty(pricingViewModel.BankQualified) ? (object) DBNull.Value : (object) pricingViewModel.BankQualified;
        row1["AccureForm"] = string.IsNullOrEmpty(pricingViewModel.AccureForm) ? (object) DBNull.Value : (object) pricingViewModel.AccureForm;
        row1["Form"] = string.IsNullOrEmpty(pricingViewModel.Form) ? (object) DBNull.Value : (object) pricingViewModel.Form;
        row1["DayCount"] = string.IsNullOrEmpty(pricingViewModel.DayCount) ? (object) DBNull.Value : (object) pricingViewModel.DayCount;
        row1["RateType"] = string.IsNullOrEmpty(pricingViewModel.RateType) ? (object) DBNull.Value : (object) pricingViewModel.RateType;
        row1["CallFeature"] = string.IsNullOrEmpty(pricingViewModel.CallFeature) ? (object) DBNull.Value : (object) pricingViewModel.CallFeature;
        DataRow dataRow4 = row1;
        nullable = pricingViewModel.CallDate;
        object obj4 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow4["CallDate"] = obj4;
        row1["CallPrice"] = string.IsNullOrEmpty(pricingViewModel.CallPrice) ? (object) DBNull.Value : (object) pricingViewModel.CallPrice;
        row1["CouponFreq"] = string.IsNullOrEmpty(pricingViewModel.CouponFreq) ? (object) DBNull.Value : (object) pricingViewModel.CouponFreq;
        row1["Insurance"] = string.IsNullOrEmpty(pricingViewModel.Insurance) ? (object) DBNull.Value : (object) pricingViewModel.Insurance;
        row1["FirmInventory"] = string.IsNullOrEmpty(pricingViewModel.FirmInventory) ? (object) DBNull.Value : (object) pricingViewModel.FirmInventory;
        DataRow dataRow5 = row1;
        nullable = pricingViewModel.StructureDateFrom;
        object obj5 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow5["StructureDateFrom"] = obj5;
        DataRow dataRow6 = row1;
        nullable = pricingViewModel.StructureDateTo;
        object obj6 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow6["StructureDateTo"] = obj6;
        row1["PrincipalFreq"] = string.IsNullOrEmpty(pricingViewModel.PrincipalFreq) ? (object) DBNull.Value : (object) pricingViewModel.PrincipalFreq;
        row1["Denomination"] = string.IsNullOrEmpty(pricingViewModel.Denomination) ? (object) DBNull.Value : (object) pricingViewModel.Denomination;
        row1["Security"] = string.IsNullOrEmpty(pricingViewModel.Security) ? (object) DBNull.Value : (object) pricingViewModel.Security;
        row1["SecurityDetails"] = string.IsNullOrEmpty(pricingViewModel.SecurityDetails) ? (object) DBNull.Value : (object) pricingViewModel.SecurityDetails;
        DataRow dataRow7 = row1;
        nullable = pricingViewModel.PutDate;
        object obj7 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow7["PutDate"] = obj7;
        row1["RecordDate"] = string.IsNullOrEmpty(pricingViewModel.RecordDate) ? (object) DBNull.Value : (object) pricingViewModel.RecordDate;
        row1["GrossSpread"] = string.IsNullOrEmpty(pricingViewModel.GrossSpread) ? (object) DBNull.Value : (object) pricingViewModel.GrossSpread;
        row1["Takedown"] = string.IsNullOrEmpty(pricingViewModel.Takedown) ? (object) DBNull.Value : (object) pricingViewModel.Takedown;
        row1["InsuranceFee"] = string.IsNullOrEmpty(pricingViewModel.InsuranceFee) ? (object) DBNull.Value : (object) pricingViewModel.InsuranceFee;
        row1["SecurityTypeSpecific"] = string.IsNullOrEmpty(pricingViewModel.SecurityTypeSpecific) ? (object) DBNull.Value : (object) pricingViewModel.SecurityTypeSpecific;
        row1["PriorityOfOrders"] = string.IsNullOrEmpty(pricingViewModel.PriorityOfOrders) ? (object) DBNull.Value : (object) pricingViewModel.PriorityOfOrders;
        DataRow dataRow8 = row1;
        nullable = pricingViewModel.PricingDate;
        object obj8 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow8["PricingDate"] = obj8;
        DataRow dataRow9 = row1;
        nullable = pricingViewModel.RetailOrderPeriodDate;
        object obj9 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow9["RetailOrderPeriodDate"] = obj9;
        DataRow dataRow10 = row1;
        nullable = pricingViewModel.ActualAwardDate;
        object obj10 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow10["ActualAwardDate"] = obj10;
        DataRow dataRow11 = row1;
        nullable = pricingViewModel.ActualAwardDate;
        object obj11 = !nullable.HasValue ? (object) null : (string.IsNullOrEmpty(pricingViewModel.ActualAwardDateTimeZone) ? (object) DBNull.Value : (object) pricingViewModel.ActualAwardDateTimeZone);
        dataRow11["ActualAwardDateTimeZone"] = obj11;
        row1["FirmRole"] = string.IsNullOrEmpty(pricingViewModel.FirmRole) ? (object) DBNull.Value : (object) pricingViewModel.FirmRole;
        row1["FirmLiability"] = string.IsNullOrEmpty(pricingViewModel.FirmLiability) ? (object) DBNull.Value : (object) pricingViewModel.FirmLiability;
        row1["FirmMgtFee"] = string.IsNullOrEmpty(pricingViewModel.FirmMgtFee) ? (object) DBNull.Value : (object) pricingViewModel.FirmMgtFee;
        row1["SDCCredit"] = string.IsNullOrEmpty(pricingViewModel.SDCCredit) ? (object) DBNull.Value : (object) pricingViewModel.SDCCredit;
        row1["SeriesDataUpdate"] = string.IsNullOrEmpty(pricingViewModel.SeriesDataUpdate) ? (object) DBNull.Value : (object) pricingViewModel.SeriesDataUpdate;
        pricingDt.Rows.Add(row1);
        foreach (CusipViewModel cusipViewModel in pricingViewModel.CUSIP)
        {
          if (!cusipViewModel.IsDeleted)
          {
            DataRow row2 = cusipDt.NewRow();
            row2["SeriesID"] = (object) cusipViewModel.SeriesID;
            DataRow dataRow12 = row2;
            nullable = cusipViewModel.MaturityDate;
            object obj12 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
            dataRow12["MaturityDate"] = obj12;
            row2["CUSIP"] = string.IsNullOrEmpty(cusipViewModel.CUSIP) ? (object) DBNull.Value : (object) cusipViewModel.CUSIP;
            row2["Term"] = string.IsNullOrEmpty(cusipViewModel.Term) ? (object) DBNull.Value : (object) cusipViewModel.Term;
            row2["AverageLife"] = string.IsNullOrEmpty(cusipViewModel.AverageLife) ? (object) DBNull.Value : (object) cusipViewModel.AverageLife;
            row2["Amount"] = string.IsNullOrEmpty(cusipViewModel.Amount) ? (object) DBNull.Value : (object) cusipViewModel.Amount;
            row2["Coupon"] = string.IsNullOrEmpty(cusipViewModel.Coupon) ? (object) DBNull.Value : (object) string.Format("{0:0.000}", (object) Convert.ToDouble(cusipViewModel.Coupon));
            row2["Yield"] = string.IsNullOrEmpty(cusipViewModel.Yield) ? (object) DBNull.Value : (object) cusipViewModel.Yield;
            row2["Price"] = string.IsNullOrEmpty(cusipViewModel.Price) ? (object) DBNull.Value : (object) cusipViewModel.Price;
            row2["YTM"] = string.IsNullOrEmpty(cusipViewModel.YTM) ? (object) DBNull.Value : (object) cusipViewModel.YTM.Trim();
            DataRow dataRow13 = row2;
            nullable = cusipViewModel.CallDate;
            object obj13 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
            dataRow13["CallDate"] = obj13;
            row2["Takedown"] = string.IsNullOrEmpty(cusipViewModel.Takedown) ? (object) DBNull.Value : (object) cusipViewModel.Takedown;
            row2["Insured"] = (object) cusipViewModel.Insured;
            cusipDt.Rows.Add(row2);
          }
        }
      }
    }

    public SaveResult SavePricingStatus(
      long pricingStatus,
      string pricingStatusValue,
      long appTransactionID)
    {
      try
      {
        if (!this.HasUIPermissionForEntity(-32L, appTransactionID, "Pricing", "View"))
          return SaveResult.Failure("You are not authorized to access this resource.");
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssuePricingRepository.SavePricingStatus(pricingStatus, appTransactionID);
          this.AuditTrailRepository.Save(new AuditTrail()
          {
            AppTransactionID = new long?(appTransactionID),
            Entity = "Issue.Pricing",
            What = "Issue Pricing status changed to " + pricingStatusValue
          });
          transactionScope.Complete();
        }
        ExportResult pricingReport = this.ExportPricingDocument(pricingStatusValue, appTransactionID);
        this.SavePricingInRepository(appTransactionID, pricingStatus, pricingStatusValue, pricingReport);
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public ExportResult ExportPricingDocument(string fileName, long appTransactionID)
    {
      try
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        IssuePresenter.\u003C\u003Ec__DisplayClass199_0 displayClass1990 = new IssuePresenter.\u003C\u003Ec__DisplayClass199_0();
        this.pricingDs = this.IssueRepository.FetchFinalPricingReport(appTransactionID);
        // ISSUE: reference to a compiler-generated field
        displayClass1990.bytes = (byte[]) null;
        string empty = string.Empty;
        // ISSUE: reference to a compiler-generated field
        displayClass1990.mimeType = "";
        // ISSUE: reference to a compiler-generated field
        displayClass1990.extension = "";
        string genericSetupPath = SPUtility.GetGenericSetupPath("_layouts/iMPACT/Reports/MS-FinalPricingReport.rdlc".Replace("_layouts", "TEMPLATE\\LAYOUTS"));
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        IssuePresenter.\u003C\u003Ec__DisplayClass199_1 displayClass1991 = new IssuePresenter.\u003C\u003Ec__DisplayClass199_1();
        // ISSUE: reference to a compiler-generated field
        displayClass1991.CS\u0024\u003C\u003E8__locals1 = displayClass1990;
        // ISSUE: reference to a compiler-generated field
        displayClass1991.report = new ReportViewer();
        try
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          IssuePresenter.\u003C\u003Ec__DisplayClass199_2 displayClass1992 = new IssuePresenter.\u003C\u003Ec__DisplayClass199_2();
          // ISSUE: reference to a compiler-generated field
          displayClass1992.CS\u0024\u003C\u003E8__locals2 = displayClass1991;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          displayClass1992.CS\u0024\u003C\u003E8__locals2.report.set_ProcessingMode((ProcessingMode) 0);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          displayClass1992.CS\u0024\u003C\u003E8__locals2.report.get_LocalReport().set_ReportPath(genericSetupPath);
          ReportDataSource reportDataSource1 = new ReportDataSource("dtFinalPricing1", this.pricingDs.Tables[0]);
          ReportDataSource reportDataSource2 = new ReportDataSource("dtFinalPricing2", this.UpdatePricingCusipData(this.pricingDs.Tables[1]));
          ReportDataSource reportDataSource3 = new ReportDataSource("dtFinalPricing3", this.pricingDs.Tables[2]);
          ReportDataSource reportDataSource4 = new ReportDataSource("dtFinalPricing4", this.pricingDs.Tables[3]);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) displayClass1992.CS\u0024\u003C\u003E8__locals2.report.get_LocalReport().get_DataSources()).Clear();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) displayClass1992.CS\u0024\u003C\u003E8__locals2.report.get_LocalReport().get_DataSources()).Add(reportDataSource1);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) displayClass1992.CS\u0024\u003C\u003E8__locals2.report.get_LocalReport().get_DataSources()).Add(reportDataSource2);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) displayClass1992.CS\u0024\u003C\u003E8__locals2.report.get_LocalReport().get_DataSources()).Add(reportDataSource3);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          ((Collection<ReportDataSource>) displayClass1992.CS\u0024\u003C\u003E8__locals2.report.get_LocalReport().get_DataSources()).Add(reportDataSource4);
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: method pointer
          displayClass1992.CS\u0024\u003C\u003E8__locals2.report.get_LocalReport().add_SubreportProcessing(new SubreportProcessingEventHandler((object) this, __methodptr(Report_PricingSubReportProcessing)));
          // ISSUE: reference to a compiler-generated field
          displayClass1992.deviceInfo = (string) null;
          // ISSUE: method pointer
          SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) displayClass1992, __methodptr(\u003CExportPricingDocument\u003Eb__0)));
        }
        finally
        {
          // ISSUE: reference to a compiler-generated field
          if (displayClass1991.report != null)
          {
            // ISSUE: reference to a compiler-generated field
            ((IDisposable) displayClass1991.report).Dispose();
          }
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        return new ExportResult()
        {
          Data = displayClass1990.bytes,
          Filename = fileName.Replace(" ", ""),
          MimeType = displayClass1990.mimeType
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return (ExportResult) null;
      }
    }

    private DataTable UpdatePricingCusipData(DataTable dt)
    {
      foreach (DataRow row in (InternalDataCollectionBase) dt.Rows)
      {
        DataRow dataRow1 = row;
        Decimal num;
        object obj1;
        if (string.IsNullOrEmpty(Convert.ToString(row["Amount"])))
        {
          obj1 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Amount"]);
          obj1 = (object) num.ToString("N2");
        }
        dataRow1["Amount"] = obj1;
        DataRow dataRow2 = row;
        object obj2;
        if (string.IsNullOrEmpty(Convert.ToString(row["Price"])))
        {
          obj2 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Price"]);
          obj2 = (object) num.ToString("N3");
        }
        dataRow2["Price"] = obj2;
        DataRow dataRow3 = row;
        object obj3;
        if (string.IsNullOrEmpty(Convert.ToString(row["Takedown"])))
        {
          obj3 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Takedown"]);
          obj3 = (object) num.ToString("N4");
        }
        dataRow3["Takedown"] = obj3;
        DataRow dataRow4 = row;
        object obj4;
        if (string.IsNullOrEmpty(Convert.ToString(row["Yield"])))
        {
          obj4 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Yield"]);
          obj4 = (object) num.ToString("N3");
        }
        dataRow4["Yield"] = obj4;
      }
      dt.AcceptChanges();
      return dt;
    }

    public void Report_PricingSubReportProcessing(object sender, SubreportProcessingEventArgs e)
    {
      string SeriesID = e.get_Parameters().get_Item("SeriesID").get_Values()[0];
      if (e.get_ReportPath() == "MS-FinalPricingSeriesSubReport")
      {
        DataTable dataTable = new DataTable();
        if (this.pricingDs.Tables[0].AsEnumerable().Any<DataRow>((Func<DataRow, bool>) (r => r.Field<long>("SeriesID") == Convert.ToInt64(SeriesID))))
          dataTable = this.pricingDs.Tables[0].AsEnumerable().Where<DataRow>((Func<DataRow, bool>) (r => r.Field<long>("SeriesID") == Convert.ToInt64(SeriesID))).CopyToDataTable<DataRow>();
        ((Collection<ReportDataSource>) e.get_DataSources()).Add(new ReportDataSource("dtFinalPricing1", dataTable));
      }
      else
      {
        DataTable dataTable = new DataTable();
        if (this.pricingDs.Tables[3].AsEnumerable().Any<DataRow>((Func<DataRow, bool>) (r => r.Field<long>("SeriesID") == Convert.ToInt64(SeriesID))))
          dataTable = this.pricingDs.Tables[3].AsEnumerable().Where<DataRow>((Func<DataRow, bool>) (r => r.Field<long>("SeriesID") == Convert.ToInt64(SeriesID))).CopyToDataTable<DataRow>();
        ((Collection<ReportDataSource>) e.get_DataSources()).Add(new ReportDataSource("dtFinalPricing4", dataTable));
      }
    }

    public SaveResult SaveAuditTrailForFinalPricingEmail(long appTransactionID)
    {
      try
      {
        if (!this.HasUIPermissionForEntity(-32L, appTransactionID, "Pricing", "SendEmail"))
          return new SaveResult()
          {
            Errors = {
              {
                "Resources",
                (object) "You are not authorized to access this resource."
              }
            }
          };
        this.AuditTrailRepository.Save(new AuditTrail()
        {
          AppTransactionID = new long?(appTransactionID),
          Entity = "Issue.Pricing",
          What = "Pricing email sent"
        });
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private ExportResult GetReportStream(
      string reportPath,
      string fileName,
      long appTransactionID)
    {
      DataSet dataSet = this.IssueRepository.FetchFinalPricingReport(appTransactionID);
      foreach (DataRow row in (InternalDataCollectionBase) dataSet.Tables[1].Rows)
      {
        DataRow dataRow1 = row;
        Decimal num;
        object obj1;
        if (string.IsNullOrEmpty(Convert.ToString(row["Amount"])))
        {
          obj1 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Amount"]);
          obj1 = (object) num.ToString("N2");
        }
        dataRow1["Amount"] = obj1;
        DataRow dataRow2 = row;
        object obj2;
        if (string.IsNullOrEmpty(Convert.ToString(row["Price"])))
        {
          obj2 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Price"]);
          obj2 = (object) num.ToString("N3");
        }
        dataRow2["Price"] = obj2;
        DataRow dataRow3 = row;
        object obj3;
        if (string.IsNullOrEmpty(Convert.ToString(row["Takedown"])))
        {
          obj3 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Takedown"]);
          obj3 = (object) num.ToString("N2");
        }
        dataRow3["Takedown"] = obj3;
        DataRow dataRow4 = row;
        object obj4;
        if (string.IsNullOrEmpty(Convert.ToString(row["Yield"])))
        {
          obj4 = (object) DBNull.Value;
        }
        else
        {
          num = Convert.ToDecimal(row["Yield"]);
          obj4 = (object) num.ToString("N3");
        }
        dataRow4["Yield"] = obj4;
      }
      int num1 = 0;
      foreach (DataTable table in (InternalDataCollectionBase) dataSet.Tables)
      {
        ++num1;
        string str = "dtFinalPricing" + (object) num1;
        table.TableName = str;
      }
      return new ReportExporter().Export(reportPath, "pdf", fileName.Replace(" ", ""), (object) dataSet);
    }

    private void AddDummyRows(DataSet dataSource)
    {
      DataTable table1 = dataSource.Tables[0];
      DataTable table2 = dataSource.Tables[1];
      if (table1.Rows.Count <= 0 || table2.Rows.Count <= 0)
        return;
      DataTable dataTable = new DataTable();
      DataTable table3 = table1.DefaultView.ToTable(true, "SeriesID");
      int num1 = table1.Rows.Count > 0 ? (int) Convert.ToInt16(table1.Compute("MAX(ID)", "")) : 0;
      for (int index1 = 0; index1 < table3.Rows.Count; ++index1)
      {
        DataRow[] dataRowArray1 = table2.Select("SeriesID = " + table3.Rows[index1]["SeriesID"]);
        DataRow[] dataRowArray2 = table1.Select("SeriesID = " + table3.Rows[index1]["SeriesID"]);
        if (dataRowArray1 != null && dataRowArray1.Length != 0 && (dataRowArray2 != null && dataRowArray2.Length != 0))
        {
          int num2 = dataRowArray1.Length - dataRowArray2.Length;
          if (num2 > 0)
          {
            for (int index2 = 0; index2 < num2; ++index2)
            {
              DataRow row = table1.NewRow();
              row["ID"] = (object) ++num1;
              row["AppTransactionID"] = dataRowArray2[0]["AppTransactionID"];
              row["SeriesID"] = dataRowArray2[0]["SeriesID"];
              row["LabelName"] = (object) string.Empty;
              row["LabelValue"] = (object) string.Empty;
              table1.Rows.Add(row);
            }
          }
        }
      }
    }

    public EmailTemplateDetailViewModel PreparePricingEmailContent(
      long appTransID)
    {
      try
      {
        if (!this.HasUIPermissionForEntity(-32L, appTransID, "Pricing", "SendEmail"))
        {
          EmailTemplateDetailViewModel templateDetailViewModel = new EmailTemplateDetailViewModel();
          templateDetailViewModel.ErrorMessage = "You are not authorized to access this resource.";
          return templateDetailViewModel;
        }
        IrisSoftware.iMPACT.Data.Issue issue = this.IssueRepository.FetchByKey(appTransID);
        this.GetInternalPartnersEmailAddress(issue, out this.partnersEmailAddress);
        IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.FetchByKey(53);
        emailTemplate.To = this.SetAppGroupRecipients(emailTemplate.To, appTransID);
        emailTemplate.Cc = this.SetAppGroupRecipients(emailTemplate.Cc, appTransID);
        emailTemplate.Subject = this.ResolvePlaceholders(emailTemplate.Subject, issue);
        emailTemplate.Body = this.ResolvePlaceholders(emailTemplate.Body, issue);
        emailTemplate.To = this.SetRecipients(emailTemplate.To);
        emailTemplate.Cc = this.SetRecipients(emailTemplate.Cc);
        EmailTemplateDetailViewModel templateDetailViewModel1 = new EmailTemplateDetailViewModel(emailTemplate);
        string empty = string.Empty;
        templateDetailViewModel1.AttachmentURL = this.GetPricingDocumentURL(appTransID, empty);
        return templateDetailViewModel1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        EmailTemplateDetailViewModel templateDetailViewModel = new EmailTemplateDetailViewModel();
        templateDetailViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return templateDetailViewModel;
      }
    }

    public List<AuditTrailViewModel> GetAuditTrailsForIssue(
      long appTransactionID)
    {
      try
      {
        List<AuditTrail> source = new List<AuditTrail>();
        using (IDataReader dataReader = this.IssueRepository.FetchIssueAuditTrail(appTransactionID))
        {
          IRowMapper<AuditTrail> rowMapper = MapBuilder<AuditTrail>.MapAllProperties().Build();
          if (dataReader != null)
          {
            while (dataReader.Read())
              source.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return source.Select<AuditTrail, AuditTrailViewModel>((Func<AuditTrail, AuditTrailViewModel>) (x => new AuditTrailViewModel(x))).ToList<AuditTrailViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<AuditTrailViewModel>();
      }
    }

    public List<AuditTrailViewModel> GetPnlAuditTrailForIssue(
      long appTransactionID)
    {
      try
      {
        List<AuditTrail> source = new List<AuditTrail>();
        using (IDataReader dataReader = this.IssueRepository.FetchPnlAuditTrail(appTransactionID))
        {
          IRowMapper<AuditTrail> rowMapper = MapBuilder<AuditTrail>.MapAllProperties().Build();
          if (dataReader != null)
          {
            while (dataReader.Read())
              source.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return source.Select<AuditTrail, AuditTrailViewModel>((Func<AuditTrail, AuditTrailViewModel>) (x => new AuditTrailViewModel(x))).ToList<AuditTrailViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<AuditTrailViewModel>();
      }
    }

    public SaveResult SaveDistributionList(long appTransactionID)
    {
      try
      {
        bool uploadResult = false;
        string empty = string.Empty;
        ExportResult listReportStream = this.GetDistributionListReportStream("~/_layouts/iMPACT/Reports/DistributionListReport.rdlc", "DistributionListReport", appTransactionID);
        this.SaveDistributionListInRepository(appTransactionID, listReportStream, out uploadResult);
        if (!uploadResult)
          return SaveResult.Failure("There was an error in generating distribution list.");
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.AuditTrailRepository.Save(new AuditTrail()
          {
            AppTransactionID = new long?(appTransactionID),
            Entity = "Issue",
            What = "Transaction Distribution List published"
          });
          transactionScope.Complete();
          return SaveResult.Success;
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private ExportResult GetDistributionListReportStream(
      string reportPath,
      string fileName,
      long appTransactionID)
    {
      DataSet dataSet = this.IssueRepository.FetchDistributionListReport(appTransactionID);
      dataSet.Tables[0].TableName = "Issuer";
      dataSet.Tables[1].TableName = "DistributionList";
      dataSet.Tables[2].TableName = "EmailList";
      return new ReportExporter().Export(reportPath, "excel", fileName.Replace(" ", ""), (object) dataSet);
    }

    public EmailTemplateDetailViewModel PrepareInfoEmail(
      long appTransID,
      int emailTemplateID)
    {
      try
      {
        IrisSoftware.iMPACT.Data.Issue issue = this.IssueRepository.FetchByKey(appTransID);
        this.GetInternalPartnersEmailAddress(issue, out this.partnersEmailAddress);
        IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.FetchByKey(emailTemplateID);
        emailTemplate.To = this.SetAppGroupRecipients(emailTemplate.To, appTransID);
        emailTemplate.Cc = this.SetAppGroupRecipients(emailTemplate.Cc, appTransID);
        emailTemplate.Subject = this.ResolvePlaceholders(emailTemplate.Subject, issue);
        emailTemplate.Body = this.ResolvePlaceholders(emailTemplate.Body, issue);
        emailTemplate.To = this.SetRecipients(emailTemplate.To);
        emailTemplate.Cc = this.SetRecipients(emailTemplate.Cc);
        return new EmailTemplateDetailViewModel(emailTemplate);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        EmailTemplateDetailViewModel templateDetailViewModel = new EmailTemplateDetailViewModel();
        templateDetailViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return templateDetailViewModel;
      }
    }

    private string SetAppGroupRecipients(string email, long AppTransactionID)
    {
      if (!string.IsNullOrEmpty(email))
      {
        StringBuilder stringBuilder1 = new StringBuilder();
        if (email.Contains("[COMPLIANCE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(3.ToString());
        }
        if (email.Contains("[LEGAL]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(18.ToString());
        }
        if (email.Contains("[MERG]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(19.ToString());
        }
        if (email.Contains("[COMMITMENTCOMMITTEE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(31.ToString());
        }
        if (email.Contains("[MANAGEMENT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(29.ToString());
        }
        if (email.Contains("[JOB-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(37.ToString());
        }
        if (email.Contains("[FIRMCREDIT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(34.ToString());
        }
        if (email.Contains("[OPERATIONS]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(6.ToString());
        }
        if (email.Contains("[PNL-APPROVER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(35.ToString());
        }
        if (email.Contains("[PNL-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(39.ToString());
        }
        if (email.Contains("[FINANCE-CONTROLLER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(36.ToString());
        }
        if (stringBuilder1.Length > 0)
        {
          StringBuilder stringBuilder2 = new StringBuilder();
          foreach (string str in this.EmailTemplateRepository.FetchEmailByRoleID(AppTransactionID, stringBuilder1.ToString()))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append(";");
            stringBuilder2.Append(str);
          }
          StringBuilder emailUpdated = new StringBuilder();
          foreach (string adr in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
          {
            switch (adr.ToUpper().Trim())
            {
              case "[COMMITMENTCOMMITTEE]":
              case "[COMPLIANCE]":
              case "[FINANCE-CONTROLLER]":
              case "[FIRMCREDIT]":
              case "[JOB-ADMINISTRATOR]":
              case "[LEGAL]":
              case "[MANAGEMENT]":
              case "[MERG]":
              case "[OPERATIONS]":
              case "[PNL-ADMINISTRATOR]":
              case "[PNL-APPROVER]":
                continue;
              default:
                this.ApplyDelimiter(emailUpdated, adr);
                continue;
            }
          }
          emailUpdated.Append(";" + (object) stringBuilder2);
          return emailUpdated.ToString();
        }
      }
      return email;
    }

    private string SetRecipients(string recipients)
    {
      this.InfoReceipts = "";
      if (!string.IsNullOrEmpty(recipients))
      {
        foreach (string recipient in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
        {
          switch (recipient.Trim().ToUpper())
          {
            case "[INTERNAL-PARTNERS.ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[3]);
              break;
            case "[INTERNAL-PARTNERS.BANKRM]":
              this.GetRecipients(this.partnersEmailAddress[6]);
              break;
            case "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[1]);
              break;
            case "[INTERNAL-PARTNERS.LEAD-ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[2]);
              break;
            case "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[0]);
              break;
            case "[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[7]);
              break;
            case "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]":
              this.GetRecipients(this.partnersEmailAddress[4]);
              break;
            case "[INTERNAL-PARTNERS.SYNDICATE]":
              this.GetRecipients(this.partnersEmailAddress[5]);
              break;
            default:
              this.GetRecipients(recipient);
              break;
          }
        }
      }
      return this.InfoReceipts;
    }

    public void GetRecipients(string recipient)
    {
      foreach (string str in recipient.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        if (!string.IsNullOrEmpty(str.Trim()) && !this.InfoReceipts.Contains(str))
          this.InfoReceipts = this.InfoReceipts + str + ";";
      }
    }

    private string GetEmailSeriesBodyLabel(string Placeholder)
    {
      if (Placeholder.Contains("[SERIES-DELIVERY-DATE]"))
        return "Series Delivery Date";
      if (Placeholder.Contains("[INSURANCE]"))
        return "Insurance";
      if (Placeholder.Contains("[FINAL-MATURITY]"))
        return "Final Maturity";
      if (Placeholder.Contains("[EXPECTED-CALL-FEATURE]"))
        return "Call Feature";
      if (Placeholder.Contains("[UNDERLYING-RATING]"))
        return "Underlying Rating";
      if (Placeholder.Contains("[SHORT-TERM-UNDERLYING-RATING]"))
        return "Short Term Underlying Rating";
      if (Placeholder.Contains("[DENOMINATIONS]"))
        return "Minimum Denomination";
      if (Placeholder.Contains("[SERIES-INFO]"))
        return "Series";
      if (Placeholder.Contains("[SERIES-CODE]"))
        return "Series Code";
      if (Placeholder.Contains("[SERIES-JOB-NUMBER]"))
        return "Job Number";
      if (Placeholder.Contains("[SERIES-PAR-AMT]"))
        return "Amount";
      if (Placeholder.Contains("[STATE-TAXABLE]"))
        return "State Tax";
      if (Placeholder.Contains("[FED-TAXABLE]"))
        return "Fed Tax";
      if (Placeholder.Contains("[BANK-QUALIFIED]"))
        return "Bank Qualified";
      if (Placeholder.Contains("[SECURITY-TYPE-GENERAL]"))
        return "Security Type (General)";
      if (Placeholder.Contains("[SECURITY]"))
        return "Security";
      if (Placeholder.Contains("[SECURITY-DETAILS]"))
        return "Security Details";
      if (Placeholder.Contains("[FIRST-COUPON]"))
        return "1st Coupon";
      if (Placeholder.Contains("[ACCRUE-FROM]"))
        return "Accrue From";
      if (Placeholder.Contains("[FORM]"))
        return "Form";
      if (Placeholder.Contains("[COUPON-FREQ]"))
        return "Coupon Frequency";
      if (Placeholder.Contains("[DAY-COUNT]"))
        return "Day Count";
      if (Placeholder.Contains("[RATE-TYPE]"))
        return "Interest Rate Type";
      if (Placeholder.Contains("[CALL-DATE]"))
        return "Call Date";
      if (Placeholder.Contains("[CALL-PRICE]"))
        return "Call Price";
      if (Placeholder.Contains("[FIRM-INVENTORY]"))
        return "Firm Inventory";
      if (Placeholder.Contains("[SERIES-DATED-DATE]"))
        return "Series Dated Date";
      if (Placeholder.Contains("[SERIES-PRICING-DATE]"))
        return "Series Pricing Date";
      if (Placeholder.Contains("[SERIES-ROP-DATE]"))
        return "Series Retail Order Period Date";
      if (Placeholder.Contains("[SERIES-ACTUAL-AWARD-DATE]"))
        return "Series Actual Award Date & Time";
      if (Placeholder.Contains("[SERIES-FIRM-ROLE]"))
        return "Series Firm Role";
      if (Placeholder.Contains("[SERIES-FIRM-LIABILITY]"))
        return "Series Firm Liability %";
      if (Placeholder.Contains("[SERIES-FIRM-MGT-FEE]"))
        return "Series Firm Mgmt Fee %";
      return Placeholder.Contains("[SERIES-SDC-CREDIT]") ? "Series SDC Credit %" : "&nbsp;";
    }

    private string GenerateEmailSeriesBody(string placeholderStr, IrisSoftware.iMPACT.Data.Issue issue)
    {
      if (string.IsNullOrEmpty(placeholderStr))
        return placeholderStr;
      placeholderStr = placeholderStr.Replace("&nbsp;", string.Empty).Trim();
      placeholderStr = placeholderStr.Replace("&NBSP;", string.Empty).Trim();
      string[] strArray = placeholderStr.Split(';');
      StringBuilder stringBuilder1 = new StringBuilder();
      StringBuilder stringBuilder2 = new StringBuilder();
      StringBuilder stringBuilder3 = new StringBuilder();
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      string empty5 = string.Empty;
      string empty6 = string.Empty;
      string empty7 = string.Empty;
      string empty8 = string.Empty;
      string empty9 = string.Empty;
      int num1 = 0;
      int num2 = 0;
      int num3 = 50;
      string format = "MM'/'dd'/'yyyy";
      if (issue.IssueDetail.Series != null && issue.IssueDetail.Series.Count<Series>() > 0)
      {
        num2 = 100 / (issue.IssueDetail.Series.Count<Series>() + 1);
        if (issue.IssueDetail.Series.Count<Series>() >= 3)
          num3 = 100;
      }
      foreach (string Placeholder in strArray)
      {
        if (!string.IsNullOrEmpty(Placeholder) && !string.IsNullOrEmpty(Placeholder.Trim()))
        {
          int num4 = 0;
          stringBuilder2.Length = 0;
          if (issue.IssueDetail.Series == null || issue.IssueDetail.Series.Count<Series>() <= 0)
          {
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(" " + Placeholder);
            else
              stringBuilder1.Append(Placeholder);
          }
          else
          {
            foreach (Series series in issue.IssueDetail.Series)
            {
              string str1 = Placeholder;
              string str2 = string.Empty;
              string str3 = string.Empty;
              string str4 = string.Empty;
              string str5 = string.Empty;
              if (!string.IsNullOrEmpty(series.MoodyRatingLT) || !string.IsNullOrEmpty(series.SPRatingLT) || (!string.IsNullOrEmpty(series.FitchRatingLT) || !string.IsNullOrEmpty(series.KrollRatingLT)))
              {
                str2 = string.IsNullOrEmpty(series.MoodyRatingLT) ? "-/" : series.MoodyRatingLT + "/";
                str3 = string.IsNullOrEmpty(series.SPRatingLT) ? "-/" : series.SPRatingLT + "/";
                str4 = string.IsNullOrEmpty(series.FitchRatingLT) ? "-/" : series.FitchRatingLT + "/";
                str5 = string.IsNullOrEmpty(series.KrollRatingLT) ? "-" : series.KrollRatingLT;
              }
              else if (!string.IsNullOrEmpty(series.MoodyRatingST) || !string.IsNullOrEmpty(series.SPRatingST) || (!string.IsNullOrEmpty(series.FitchRatingST) || !string.IsNullOrEmpty(series.KrollRatingST)))
              {
                str2 = string.IsNullOrEmpty(series.MoodyRatingST) ? "-/" : series.MoodyRatingST + "/";
                str3 = string.IsNullOrEmpty(series.SPRatingST) ? "-/" : series.SPRatingST + "/";
                str4 = string.IsNullOrEmpty(series.FitchRatingST) ? "-/" : series.FitchRatingST + "/";
                str5 = string.IsNullOrEmpty(series.KrollRatingST) ? "-" : series.KrollRatingST;
              }
              string str6 = string.Format("{0}{1}{2}{3}", (object) str2, (object) str3, (object) str4, (object) str5);
              string str7 = string.Empty;
              string str8 = string.Empty;
              string str9 = string.Empty;
              string str10 = string.Empty;
              if (!string.IsNullOrEmpty(series.MoodyRatingST) || !string.IsNullOrEmpty(series.SPRatingST) || (!string.IsNullOrEmpty(series.FitchRatingST) || !string.IsNullOrEmpty(series.KrollRatingST)))
              {
                str7 = string.IsNullOrEmpty(series.MoodyRatingST) ? "-/" : series.MoodyRatingST + "/";
                str8 = string.IsNullOrEmpty(series.SPRatingST) ? "-/" : series.SPRatingST + "/";
                str9 = string.IsNullOrEmpty(series.FitchRatingST) ? "-/" : series.FitchRatingST + "/";
                str10 = string.IsNullOrEmpty(series.KrollRatingST) ? "-" : series.KrollRatingST;
              }
              string str11 = string.Format("{0}{1}{2}{3}", (object) str7, (object) str8, (object) str9, (object) str10);
              StringBuilder stringBuilder4 = new StringBuilder();
              StringBuilder stringBuilder5 = new StringBuilder();
              StringBuilder stringBuilder6 = new StringBuilder();
              if (series.EnhancementRatingBySeries != null)
              {
                foreach (EnhancementRatingBySeries enhancementRatingBySeries in series.EnhancementRatingBySeries)
                {
                  if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementProvider))
                  {
                    if (stringBuilder4.Length > 0)
                      stringBuilder4.Append("; ");
                    stringBuilder4.Append(enhancementRatingBySeries.CreditEnhancementProvider);
                  }
                  if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementType))
                  {
                    if (stringBuilder5.Length > 0)
                      stringBuilder5.Append("; ");
                    stringBuilder5.Append(enhancementRatingBySeries.CreditEnhancementType);
                  }
                  if (!string.IsNullOrEmpty(enhancementRatingBySeries.EnhancedRating))
                  {
                    if (stringBuilder6.Length > 0)
                      stringBuilder6.Append("; ");
                    stringBuilder6.Append(enhancementRatingBySeries.EnhancedRating);
                  }
                }
              }
              string str12 = str1;
              DateTime? nullable1 = series.SettlementDate;
              string empty10;
              if (nullable1.HasValue)
              {
                nullable1 = series.SettlementDate;
                empty10 = nullable1.Value.ToString(format);
              }
              else
                empty10 = string.Empty;
              string str13 = str12.Replace("[SERIES-DELIVERY-DATE]", empty10).Replace("[INSURANCE]", series.InsuranceName);
              nullable1 = series.StructureDateTo;
              string empty11;
              if (nullable1.HasValue)
              {
                nullable1 = series.StructureDateTo;
                empty11 = nullable1.Value.ToString(format);
              }
              else
                empty11 = string.Empty;
              string str14 = str13.Replace("[FINAL-MATURITY]", empty11).Replace("[EXPECTED-CALL-FEATURE]", series.CallFeature).Replace("[UNDERLYING-RATING]", str6.ToString()).Replace("[SHORT-TERM-UNDERLYING-RATING]", str11.ToString()).Replace("[DENOMINATIONS]", !series.Denomination.HasValue ? string.Empty : string.Format("{0:C0}", (object) series.Denomination));
              Decimal? nullable2 = series.ParAmount;
              string newValue1 = string.IsNullOrEmpty(nullable2.ToString()) ? "$0" : string.Format("{0:C0}", (object) series.ParAmount);
              string str15 = str14.Replace("[SERIES-INFO]", series.SeriesName).Replace("[SERIES-CODE]", series.SeriesCode).Replace("[SERIES-JOB-NUMBER]", series.JobNumber).Replace("[SERIES-PAR-AMT]", newValue1).Replace("[STATE-TAXABLE]", string.IsNullOrEmpty(series.StateTaxable) ? string.Empty : series.StateTaxable.Trim()).Replace("[FED-TAXABLE]", string.IsNullOrEmpty(series.FedTaxName) ? string.Empty : series.FedTaxName.Trim());
              string newValue2;
              if (series.BankQualified.HasValue)
              {
                bool? bankQualified = series.BankQualified;
                bool flag = true;
                newValue2 = (bankQualified.GetValueOrDefault() == flag ? (bankQualified.HasValue ? 1 : 0) : 0) != 0 ? "Yes" : "No";
              }
              else
                newValue2 = string.Empty;
              string str16 = str15.Replace("[BANK-QUALIFIED]", newValue2).Replace("[SECURITY-TYPE-GENERAL]", string.IsNullOrEmpty(series.SecTypeName) ? string.Empty : series.SecTypeName.Trim()).Replace("[SECURITY]", string.IsNullOrEmpty(series.Security) ? string.Empty : series.Security.Trim()).Replace("[SECURITY-DETAILS]", string.IsNullOrEmpty(series.SecurityDetails) ? string.Empty : series.SecurityDetails.Trim());
              nullable1 = series.FirstCouponDate;
              string empty12;
              if (nullable1.HasValue)
              {
                nullable1 = series.FirstCouponDate;
                empty12 = nullable1.Value.ToString(format);
              }
              else
                empty12 = string.Empty;
              string str17 = str16.Replace("[FIRST-COUPON]", empty12).Replace("[ACCRUE-FROM]", string.IsNullOrEmpty(series.AccrueFromName) ? string.Empty : series.AccrueFromName.Trim()).Replace("[FORM]", string.IsNullOrEmpty(series.PricingFromName) ? string.Empty : series.PricingFromName.Trim()).Replace("[COUPON-FREQ]", string.IsNullOrEmpty(series.CouponFreqName) ? string.Empty : series.CouponFreqName.Trim()).Replace("[DAY-COUNT]", string.IsNullOrEmpty(series.DayCountName) ? string.Empty : series.DayCountName.Trim()).Replace("[RATE-TYPE]", string.IsNullOrEmpty(series.RateTypeName) ? string.Empty : series.RateTypeName.Trim());
              nullable1 = series.CallDate;
              string empty13;
              if (nullable1.HasValue)
              {
                nullable1 = series.CallDate;
                empty13 = nullable1.Value.ToString(format);
              }
              else
                empty13 = string.Empty;
              string str18 = str17.Replace("[CALL-DATE]", empty13);
              nullable2 = series.CallPrice;
              string empty14;
              if (!nullable2.HasValue)
              {
                empty14 = string.Empty;
              }
              else
              {
                nullable2 = series.CallPrice;
                empty14 = nullable2.Value.ToString("N3");
              }
              string str19 = str18.Replace("[CALL-PRICE]", empty14);
              nullable2 = series.FirmInventory;
              string newValue3 = !nullable2.HasValue ? string.Empty : string.Format("{0:C0}", (object) series.FirmInventory);
              string str20 = str19.Replace("[FIRM-INVENTORY]", newValue3);
              string empty15 = string.Empty;
              nullable1 = series.ActualAwardDate;
              string empty16;
              if (!nullable1.HasValue)
              {
                empty16 = string.Empty;
              }
              else
              {
                nullable1 = series.ActualAwardDate;
                empty16 = nullable1.Value.ToString("MM'/'dd'/'yyyy hh:mm tt");
              }
              string str21 = string.IsNullOrEmpty(series.ActualAwardDateTimeZone) ? "ET" : " " + series.ActualAwardDateTimeZone;
              string newValue4 = empty16 + str21;
              string str22 = str20;
              nullable1 = series.DatedDate;
              string empty17;
              if (nullable1.HasValue)
              {
                nullable1 = series.DatedDate;
                empty17 = nullable1.Value.ToString(format);
              }
              else
                empty17 = string.Empty;
              string str23 = str22.Replace("[SERIES-DATED-DATE]", empty17);
              nullable1 = series.PricingDate;
              string empty18;
              if (nullable1.HasValue)
              {
                nullable1 = series.PricingDate;
                empty18 = nullable1.Value.ToString(format);
              }
              else
                empty18 = string.Empty;
              string str24 = str23.Replace("[SERIES-PRICING-DATE]", empty18);
              nullable1 = series.RetailOrderPeriodDate;
              string empty19;
              if (nullable1.HasValue)
              {
                nullable1 = series.RetailOrderPeriodDate;
                empty19 = nullable1.Value.ToString(format);
              }
              else
                empty19 = string.Empty;
              string str25 = str24.Replace("[SERIES-ROP-DATE]", empty19).Replace("[SERIES-ACTUAL-AWARD-DATE]", newValue4).Replace("[SERIES-FIRM-ROLE]", string.IsNullOrEmpty(series.FirmRoleName) ? string.Empty : series.FirmRoleName);
              nullable2 = series.FirmLiability;
              string empty20;
              if (!nullable2.HasValue)
              {
                empty20 = string.Empty;
              }
              else
              {
                nullable2 = series.FirmLiability;
                empty20 = nullable2.Value.ToString();
              }
              string str26 = str25.Replace("[SERIES-FIRM-LIABILITY]", empty20);
              nullable2 = series.FirmMgtFee;
              string empty21;
              if (!nullable2.HasValue)
              {
                empty21 = string.Empty;
              }
              else
              {
                nullable2 = series.FirmMgtFee;
                empty21 = nullable2.Value.ToString();
              }
              string str27 = str26.Replace("[SERIES-FIRM-MGT-FEE]", empty21);
              nullable2 = series.SdcCredit;
              string empty22;
              if (!nullable2.HasValue)
              {
                empty22 = string.Empty;
              }
              else
              {
                nullable2 = series.SdcCredit;
                empty22 = nullable2.Value.ToString();
              }
              string str28 = str27.Replace("[SERIES-SDC-CREDIT]", empty22);
              if (num1 == 0)
                stringBuilder2.Append("<style>.tableStyle td{padding:2px; border:1px solid #000;}</style> <table class='tableStyle' style='border-collapse:collapse;width:" + num3.ToString() + "%;margin-bottom:0;' border='1' cellspacing='0' cellpadding='0'>");
              if (num4 == 0)
                stringBuilder2.Append("<tr><td  style='padding:2px 2px;width:" + num2.ToString() + "%;'><b>" + this.GetEmailSeriesBodyLabel(Placeholder) + "</b></td>");
              stringBuilder2.Append("<td  style='padding:2px 2px;width:" + num2.ToString() + "%;'>" + str28 + "</td>");
              ++num4;
              ++num1;
            }
            if (stringBuilder2.Length > 0)
              stringBuilder1.Append((object) stringBuilder2.Append("</tr>"));
          }
        }
      }
      if (stringBuilder1.Length > 0 && issue.IssueDetail.Series != null && issue.IssueDetail.Series.Count<Series>() > 0)
        stringBuilder1.Append("</table>");
      return stringBuilder1.ToString();
    }

    private string UpdateEmailSeriesData(string _body, IrisSoftware.iMPACT.Data.Issue issue)
    {
      StringBuilder stringBuilder1 = new StringBuilder(_body);
      string format = "MM'/'dd'/'yyyy";
      if (stringBuilder1.ToString().Contains("[STATE-TAXABLE]") || stringBuilder1.ToString().Contains("[FED-TAXABLE]") || (stringBuilder1.ToString().Contains("[BANK-QUALIFIED]") || stringBuilder1.ToString().Contains("[SERIES-INFO]")) || (stringBuilder1.ToString().Contains("[SERIES-CODE]") || stringBuilder1.ToString().Contains("[SERIES-JOB-NUMBER]") || (stringBuilder1.ToString().Contains("[UNDERLYING-RATING]") || stringBuilder1.ToString().Contains("[SHORT-TERM-UNDERLYING-RATING]"))) || (stringBuilder1.ToString().Contains("[DENOMINATIONS]") || stringBuilder1.ToString().Contains("[SERIES-PAR-AMT]") || (stringBuilder1.ToString().Contains("[INSURANCE]") || stringBuilder1.ToString().Contains("[FINAL-MATURITY]")) || (stringBuilder1.ToString().Contains("[EXPECTED-CALL-FEATURE]") || stringBuilder1.ToString().Contains("[SECURITY-TYPE-GENERAL]") || (stringBuilder1.ToString().Contains("[SECURITY]") || stringBuilder1.ToString().Contains("[SECURITY-DETAILS]")))) || (stringBuilder1.ToString().Contains("[FIRST-COUPON]") || stringBuilder1.ToString().Contains("[ACCRUE-FROM]") || (stringBuilder1.ToString().Contains("[FORM]") || stringBuilder1.ToString().Contains("[COUPON-FREQ]")) || (stringBuilder1.ToString().Contains("[DAY-COUNT]") || stringBuilder1.ToString().Contains("[RATE-TYPE]") || (stringBuilder1.ToString().Contains("[CALL-DATE]") || stringBuilder1.ToString().Contains("[CALL-PRICE]"))) || (stringBuilder1.ToString().Contains("[FIRM-INVENTORY]") || stringBuilder1.ToString().Contains("[SERIES-PRICING-DATE]") || (stringBuilder1.ToString().Contains("[SERIES-ROP-DATE]") || stringBuilder1.ToString().Contains("[SERIES-ACTUAL-AWARD-DATE]")) || (stringBuilder1.ToString().Contains("[SERIES-FIRM-ROLE]") || stringBuilder1.ToString().Contains("[SERIES-FIRM-LIABILITY]") || (stringBuilder1.ToString().Contains("[SERIES-FIRM-MGT-FEE]") || stringBuilder1.ToString().Contains("[SERIES-SDC-CREDIT]"))))) || (stringBuilder1.ToString().Contains("[SERIES-DATED-DATE]") || stringBuilder1.ToString().Contains("[SERIES-DELIVERY-DATE]")))
      {
        string pattern = "\\[GRID\\](.*?)\\[\\/GRID\\]";
        MatchCollection matchCollection = Regex.Matches(_body, pattern);
        if (matchCollection.Count > 0)
        {
          foreach (Match match in matchCollection)
          {
            if (match.Groups != null && match.Groups.Count > 0)
              stringBuilder1 = stringBuilder1.Replace(match.Groups[0].ToString(), this.GenerateEmailSeriesBody(match.Groups[1].ToString(), issue));
          }
        }
        if (stringBuilder1.ToString().Contains("[STATE-TAXABLE]") || stringBuilder1.ToString().Contains("[FED-TAXABLE]") || (stringBuilder1.ToString().Contains("[BANK-QUALIFIED]") || stringBuilder1.ToString().Contains("[SERIES-INFO]")) || (stringBuilder1.ToString().Contains("[SERIES-CODE]") || stringBuilder1.ToString().Contains("[SERIES-JOB-NUMBER]") || (stringBuilder1.ToString().Contains("[UNDERLYING-RATING]") || stringBuilder1.ToString().Contains("[SHORT-TERM-UNDERLYING-RATING]"))) || (stringBuilder1.ToString().Contains("[DENOMINATIONS]") || stringBuilder1.ToString().Contains("[SERIES-PAR-AMT]") || (stringBuilder1.ToString().Contains("[INSURANCE]") || stringBuilder1.ToString().Contains("[FINAL-MATURITY]")) || (stringBuilder1.ToString().Contains("[EXPECTED-CALL-FEATURE]") || stringBuilder1.ToString().Contains("[SECURITY-TYPE-GENERAL]") || (stringBuilder1.ToString().Contains("[SECURITY]") || stringBuilder1.ToString().Contains("[SECURITY-DETAILS]")))) || (stringBuilder1.ToString().Contains("[FIRST-COUPON]") || stringBuilder1.ToString().Contains("[ACCRUE-FROM]") || (stringBuilder1.ToString().Contains("[FORM]") || stringBuilder1.ToString().Contains("[COUPON-FREQ]")) || (stringBuilder1.ToString().Contains("[DAY-COUNT]") || stringBuilder1.ToString().Contains("[RATE-TYPE]") || (stringBuilder1.ToString().Contains("[CALL-DATE]") || stringBuilder1.ToString().Contains("[CALL-PRICE]"))) || (stringBuilder1.ToString().Contains("[FIRM-INVENTORY]") || stringBuilder1.ToString().Contains("[SERIES-PRICING-DATE]") || (stringBuilder1.ToString().Contains("[SERIES-ROP-DATE]") || stringBuilder1.ToString().Contains("[SERIES-ACTUAL-AWARD-DATE]")) || (stringBuilder1.ToString().Contains("[SERIES-FIRM-ROLE]") || stringBuilder1.ToString().Contains("[SERIES-FIRM-LIABILITY]") || (stringBuilder1.ToString().Contains("[SERIES-FIRM-MGT-FEE]") || stringBuilder1.ToString().Contains("[SERIES-SDC-CREDIT]"))))) || (stringBuilder1.ToString().Contains("[SERIES-DATED-DATE]") || stringBuilder1.ToString().Contains("[SERIES-DELIVERY-DATE]")))
        {
          string empty1 = string.Empty;
          string empty2 = string.Empty;
          string empty3 = string.Empty;
          string empty4 = string.Empty;
          string empty5 = string.Empty;
          string empty6 = string.Empty;
          string empty7 = string.Empty;
          string empty8 = string.Empty;
          using (IEnumerator<Series> enumerator = issue.IssueDetail.Series.GetEnumerator())
          {
            if (enumerator.MoveNext())
            {
              Series current = enumerator.Current;
              string str1 = string.Empty;
              string str2 = string.Empty;
              string str3 = string.Empty;
              string str4 = string.Empty;
              if (!string.IsNullOrEmpty(current.MoodyRatingLT) || !string.IsNullOrEmpty(current.SPRatingLT) || (!string.IsNullOrEmpty(current.FitchRatingLT) || !string.IsNullOrEmpty(current.KrollRatingLT)))
              {
                str1 = string.IsNullOrEmpty(current.MoodyRatingLT) ? "-/" : current.MoodyRatingLT + "/";
                str2 = string.IsNullOrEmpty(current.SPRatingLT) ? "-/" : current.SPRatingLT + "/";
                str3 = string.IsNullOrEmpty(current.FitchRatingLT) ? "-/" : current.FitchRatingLT + "/";
                str4 = string.IsNullOrEmpty(current.KrollRatingLT) ? "-" : current.KrollRatingLT;
              }
              else if (!string.IsNullOrEmpty(current.MoodyRatingST) || !string.IsNullOrEmpty(current.SPRatingST) || (!string.IsNullOrEmpty(current.FitchRatingST) || !string.IsNullOrEmpty(current.KrollRatingST)))
              {
                str1 = string.IsNullOrEmpty(current.MoodyRatingST) ? "-/" : current.MoodyRatingST + "/";
                str2 = string.IsNullOrEmpty(current.SPRatingST) ? "-/" : current.SPRatingST + "/";
                str3 = string.IsNullOrEmpty(current.FitchRatingST) ? "-/" : current.FitchRatingST + "/";
                str4 = string.IsNullOrEmpty(current.KrollRatingST) ? "-" : current.KrollRatingST;
              }
              string str5 = string.Format("{0}{1}{2}{3}", (object) str1, (object) str2, (object) str3, (object) str4);
              string str6 = string.Empty;
              string str7 = string.Empty;
              string str8 = string.Empty;
              string str9 = string.Empty;
              if (!string.IsNullOrEmpty(current.MoodyRatingST) || !string.IsNullOrEmpty(current.SPRatingST) || (!string.IsNullOrEmpty(current.FitchRatingST) || !string.IsNullOrEmpty(current.KrollRatingST)))
              {
                str6 = string.IsNullOrEmpty(current.MoodyRatingST) ? "-/" : current.MoodyRatingST + "/";
                str7 = string.IsNullOrEmpty(current.SPRatingST) ? "-/" : current.SPRatingST + "/";
                str8 = string.IsNullOrEmpty(current.FitchRatingST) ? "-/" : current.FitchRatingST + "/";
                str9 = string.IsNullOrEmpty(current.KrollRatingST) ? "-" : current.KrollRatingST;
              }
              string str10 = string.Format("{0}{1}{2}{3}", (object) str6, (object) str7, (object) str8, (object) str9);
              StringBuilder stringBuilder2 = new StringBuilder();
              StringBuilder stringBuilder3 = new StringBuilder();
              StringBuilder stringBuilder4 = new StringBuilder();
              if (current.EnhancementRatingBySeries != null)
              {
                foreach (EnhancementRatingBySeries enhancementRatingBySeries in current.EnhancementRatingBySeries)
                {
                  if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementProvider))
                  {
                    if (stringBuilder2.Length > 0)
                      stringBuilder2.Append("; ");
                    stringBuilder2.Append(enhancementRatingBySeries.CreditEnhancementProvider);
                  }
                  if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementType))
                  {
                    if (stringBuilder3.Length > 0)
                      stringBuilder3.Append("; ");
                    stringBuilder3.Append(enhancementRatingBySeries.CreditEnhancementType);
                  }
                  if (!string.IsNullOrEmpty(enhancementRatingBySeries.EnhancedRating))
                  {
                    if (stringBuilder4.Length > 0)
                      stringBuilder4.Append("; ");
                    stringBuilder4.Append(enhancementRatingBySeries.EnhancedRating);
                  }
                }
              }
              stringBuilder1 = stringBuilder1.Replace("[INSURANCE]", current.InsuranceName);
              StringBuilder stringBuilder5 = stringBuilder1;
              DateTime? nullable1 = current.StructureDateTo;
              string empty9;
              if (nullable1.HasValue)
              {
                nullable1 = current.StructureDateTo;
                empty9 = nullable1.Value.ToString(format);
              }
              else
                empty9 = string.Empty;
              stringBuilder1 = stringBuilder5.Replace("[FINAL-MATURITY]", empty9);
              stringBuilder1 = stringBuilder1.Replace("[EXPECTED-CALL-FEATURE]", current.CallFeature);
              stringBuilder1 = stringBuilder1.Replace("[UNDERLYING-RATING]", str5.ToString());
              stringBuilder1 = stringBuilder1.Replace("[SHORT-TERM-UNDERLYING-RATING]", str10.ToString());
              StringBuilder stringBuilder6 = stringBuilder1;
              Decimal? nullable2 = current.Denomination;
              string newValue1 = !nullable2.HasValue ? string.Empty : string.Format("{0:C0}", (object) current.Denomination);
              stringBuilder1 = stringBuilder6.Replace("[DENOMINATIONS]", newValue1);
              nullable2 = current.ParAmount;
              string newValue2 = string.IsNullOrEmpty(nullable2.ToString()) ? "$0" : string.Format("{0:C0}", (object) current.ParAmount);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-INFO]", current.SeriesName);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-CODE]", current.SeriesCode);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-JOB-NUMBER]", current.JobNumber);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-PAR-AMT]", newValue2);
              stringBuilder1 = stringBuilder1.Replace("[STATE-TAXABLE]", string.IsNullOrEmpty(current.StateTaxable) ? string.Empty : current.StateTaxable.Trim());
              stringBuilder1 = stringBuilder1.Replace("[FED-TAXABLE]", string.IsNullOrEmpty(current.FedTaxName) ? string.Empty : current.FedTaxName.Trim());
              StringBuilder stringBuilder7 = stringBuilder1;
              string newValue3;
              if (current.BankQualified.HasValue)
              {
                bool? bankQualified = current.BankQualified;
                bool flag = true;
                newValue3 = (bankQualified.GetValueOrDefault() == flag ? (bankQualified.HasValue ? 1 : 0) : 0) != 0 ? "Yes" : "No";
              }
              else
                newValue3 = string.Empty;
              stringBuilder1 = stringBuilder7.Replace("[BANK-QUALIFIED]", newValue3);
              stringBuilder1 = stringBuilder1.Replace("[SECURITY-TYPE-GENERAL]", string.IsNullOrEmpty(current.SecTypeName) ? string.Empty : current.SecTypeName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[SECURITY]", string.IsNullOrEmpty(current.Security) ? string.Empty : current.Security.Trim());
              stringBuilder1 = stringBuilder1.Replace("[SECURITY-DETAILS]", string.IsNullOrEmpty(current.SecurityDetails) ? string.Empty : current.SecurityDetails.Trim());
              StringBuilder stringBuilder8 = stringBuilder1;
              nullable1 = current.FirstCouponDate;
              string empty10;
              if (nullable1.HasValue)
              {
                nullable1 = current.FirstCouponDate;
                empty10 = nullable1.Value.ToString(format);
              }
              else
                empty10 = string.Empty;
              stringBuilder1 = stringBuilder8.Replace("[FIRST-COUPON]", empty10);
              stringBuilder1 = stringBuilder1.Replace("[ACCRUE-FROM]", string.IsNullOrEmpty(current.AccrueFromName) ? string.Empty : current.AccrueFromName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[FORM]", string.IsNullOrEmpty(current.PricingFromName) ? string.Empty : current.PricingFromName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[COUPON-FREQ]", string.IsNullOrEmpty(current.CouponFreqName) ? string.Empty : current.CouponFreqName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[DAY-COUNT]", string.IsNullOrEmpty(current.DayCountName) ? string.Empty : current.DayCountName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[RATE-TYPE]", string.IsNullOrEmpty(current.RateTypeName) ? string.Empty : current.RateTypeName.Trim());
              StringBuilder stringBuilder9 = stringBuilder1;
              nullable1 = current.CallDate;
              string empty11;
              if (nullable1.HasValue)
              {
                nullable1 = current.CallDate;
                empty11 = nullable1.Value.ToString(format);
              }
              else
                empty11 = string.Empty;
              stringBuilder1 = stringBuilder9.Replace("[CALL-DATE]", empty11);
              StringBuilder stringBuilder10 = stringBuilder1;
              nullable2 = current.CallPrice;
              Decimal num;
              string empty12;
              if (!nullable2.HasValue)
              {
                empty12 = string.Empty;
              }
              else
              {
                nullable2 = current.CallPrice;
                num = nullable2.Value;
                empty12 = num.ToString("N3");
              }
              stringBuilder1 = stringBuilder10.Replace("[CALL-PRICE]", empty12);
              StringBuilder stringBuilder11 = stringBuilder1;
              nullable2 = current.FirmInventory;
              string newValue4 = !nullable2.HasValue ? string.Empty : string.Format("{0:C0}", (object) current.FirmInventory);
              stringBuilder1 = stringBuilder11.Replace("[FIRM-INVENTORY]", newValue4);
              string empty13 = string.Empty;
              nullable1 = current.ActualAwardDate;
              DateTime dateTime;
              string empty14;
              if (!nullable1.HasValue)
              {
                empty14 = string.Empty;
              }
              else
              {
                nullable1 = current.ActualAwardDate;
                dateTime = nullable1.Value;
                empty14 = dateTime.ToString("MM'/'dd'/'yyyy hh:mm tt");
              }
              string str11 = string.IsNullOrEmpty(current.ActualAwardDateTimeZone) ? "ET" : " " + current.ActualAwardDateTimeZone;
              string newValue5 = empty14 + str11;
              StringBuilder stringBuilder12 = stringBuilder1;
              nullable1 = current.DatedDate;
              string empty15;
              if (nullable1.HasValue)
              {
                nullable1 = current.DatedDate;
                dateTime = nullable1.Value;
                empty15 = dateTime.ToString(format);
              }
              else
                empty15 = string.Empty;
              stringBuilder1 = stringBuilder12.Replace("[SERIES-DATED-DATE]", empty15);
              StringBuilder stringBuilder13 = stringBuilder1;
              nullable1 = current.PricingDate;
              string empty16;
              if (nullable1.HasValue)
              {
                nullable1 = current.PricingDate;
                dateTime = nullable1.Value;
                empty16 = dateTime.ToString(format);
              }
              else
                empty16 = string.Empty;
              stringBuilder1 = stringBuilder13.Replace("[SERIES-PRICING-DATE]", empty16);
              StringBuilder stringBuilder14 = stringBuilder1;
              nullable1 = current.RetailOrderPeriodDate;
              string empty17;
              if (nullable1.HasValue)
              {
                nullable1 = current.RetailOrderPeriodDate;
                dateTime = nullable1.Value;
                empty17 = dateTime.ToString(format);
              }
              else
                empty17 = string.Empty;
              stringBuilder1 = stringBuilder14.Replace("[SERIES-ROP-DATE]", empty17);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-ACTUAL-AWARD-DATE]", newValue5);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-FIRM-ROLE]", string.IsNullOrEmpty(current.FirmRoleName) ? string.Empty : current.FirmRoleName);
              StringBuilder stringBuilder15 = stringBuilder1;
              nullable2 = current.FirmLiability;
              string empty18;
              if (!nullable2.HasValue)
              {
                empty18 = string.Empty;
              }
              else
              {
                nullable2 = current.FirmLiability;
                num = nullable2.Value;
                empty18 = num.ToString();
              }
              stringBuilder1 = stringBuilder15.Replace("[SERIES-FIRM-LIABILITY]", empty18);
              StringBuilder stringBuilder16 = stringBuilder1;
              nullable2 = current.FirmMgtFee;
              string empty19;
              if (!nullable2.HasValue)
              {
                empty19 = string.Empty;
              }
              else
              {
                nullable2 = current.FirmMgtFee;
                num = nullable2.Value;
                empty19 = num.ToString();
              }
              stringBuilder1 = stringBuilder16.Replace("[SERIES-FIRM-MGT-FEE]", empty19);
              StringBuilder stringBuilder17 = stringBuilder1;
              nullable2 = current.SdcCredit;
              string empty20;
              if (!nullable2.HasValue)
              {
                empty20 = string.Empty;
              }
              else
              {
                nullable2 = current.SdcCredit;
                num = nullable2.Value;
                empty20 = num.ToString();
              }
              stringBuilder1 = stringBuilder17.Replace("[SERIES-SDC-CREDIT]", empty20);
              StringBuilder stringBuilder18 = stringBuilder1;
              nullable1 = current.SettlementDate;
              string empty21;
              if (nullable1.HasValue)
              {
                nullable1 = current.SettlementDate;
                dateTime = nullable1.Value;
                empty21 = dateTime.ToString(format);
              }
              else
                empty21 = string.Empty;
              stringBuilder1 = stringBuilder18.Replace("[SERIES-DELIVERY-DATE]", empty21);
            }
          }
          stringBuilder1 = stringBuilder1.Replace("[INSURANCE]", string.Empty).Replace("[FINAL-MATURITY]", string.Empty).Replace("[EXPECTED-CALL-FEATURE]", string.Empty).Replace("[UNDERLYING-RATING]", string.Empty).Replace("[SHORT-TERM-UNDERLYING-RATING]", string.Empty).Replace("[DENOMINATIONS]", string.Empty).Replace("[SERIES-INFO]", string.Empty).Replace("[SERIES-CODE]", string.Empty).Replace("[SERIES-JOB-NUMBER]", string.Empty).Replace("[SERIES-PAR-AMT]", string.Empty).Replace("[STATE-TAXABLE]", string.Empty).Replace("[FED-TAXABLE]", string.Empty).Replace("[BANK-QUALIFIED]", string.Empty).Replace("[SECURITY-TYPE-GENERAL]", string.Empty).Replace("[SECURITY]", string.Empty).Replace("[SECURITY-DETAILS]", string.Empty).Replace("[FIRST-COUPON]", string.Empty).Replace("[ACCRUE-FROM]", string.Empty).Replace("[FORM]", string.Empty).Replace("[COUPON-FREQ]", string.Empty).Replace("[DAY-COUNT]", string.Empty).Replace("[RATE-TYPE]", string.Empty).Replace("[CALL-DATE]", string.Empty).Replace("[CALL-PRICE]", string.Empty).Replace("[FIRM-INVENTORY]", string.Empty).Replace("[SERIES-PRICING-DATE]", string.Empty).Replace("[SERIES-ROP-DATE]", string.Empty).Replace("[SERIES-ACTUAL-AWARD-DATE]", string.Empty).Replace("[SERIES-FIRM-ROLE]", string.Empty).Replace("[SERIES-FIRM-LIABILITY]", string.Empty).Replace("[SERIES-FIRM-MGT-FEE]", string.Empty).Replace("[SERIES-SDC-CREDIT]", string.Empty).Replace("[SERIES-DELIVERY-DATE]", string.Empty).Replace("[SERIES-DATED-DATE]", string.Empty);
        }
      }
      return stringBuilder1.ToString();
    }

    private string GetConcatenatedSeriesValue(IrisSoftware.iMPACT.Data.Issue issue, string PlcHlderValue)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (!string.IsNullOrEmpty(PlcHlderValue) && issue.IssueDetail.Series != null)
      {
        string empty = string.Empty;
        foreach (Series series in issue.IssueDetail.Series)
        {
          if (stringBuilder.Length > 0)
            stringBuilder.Append("<br />");
          stringBuilder.Append(PlcHlderValue);
          string newValue = string.IsNullOrEmpty(series.ParAmount.ToString()) ? "$0" : string.Format("{0:C0}", (object) series.ParAmount);
          stringBuilder = stringBuilder.Replace("[SERIES-INFO]", series.SeriesName);
          stringBuilder = stringBuilder.Replace("[SERIES-PAR-AMT]", newValue);
          stringBuilder = stringBuilder.Replace("[FED-TAXABLE]", "(" + (string.IsNullOrEmpty(series.FedTaxName) ? string.Empty : series.FedTaxName.Trim()) + ")");
        }
      }
      return stringBuilder.ToString();
    }

    private string GetConcatenatedSeriesValueDiff(IrisSoftware.iMPACT.Data.Issue issue, string PlcHlder)
    {
      string str1 = string.Empty;
      StringBuilder stringBuilder1 = new StringBuilder();
      int num1 = 0;
      string format1 = "MM'/'dd'/'yyyy";
      string format2 = "MM'/'dd'/'yyyy hh:mm tt";
      string str2 = "ET";
      if (!string.IsNullOrEmpty(PlcHlder) && issue.IssueDetail != null && (issue.IssueDetail.Series != null && issue.IssueDetail.Series.Any<Series>()))
      {
        switch (PlcHlder)
        {
          case "[CONC-SERIES-ACTUAL-AWARD-DATE]":
            DateTime dateTime1;
            string empty1;
            if (!issue.IssueDetail.ActualAwardDateTime.HasValue)
            {
              empty1 = string.Empty;
            }
            else
            {
              dateTime1 = issue.IssueDetail.ActualAwardDateTime.Value;
              empty1 = dateTime1.ToString(format2);
            }
            string str3 = string.IsNullOrEmpty(issue.IssueDetail.ActualAwardDateTimeZone) ? str2 : " " + issue.IssueDetail.ActualAwardDateTimeZone;
            string str4 = empty1 + str3;
            foreach (Series series in issue.IssueDetail.Series)
            {
              DateTime? nullable = issue.IssueDetail.ActualAwardDateTime;
              if (nullable.HasValue)
              {
                nullable = series.ActualAwardDate;
                if (nullable.HasValue)
                {
                  nullable = issue.IssueDetail.ActualAwardDateTime;
                  dateTime1 = nullable.Value;
                  string str5 = dateTime1.ToString(format2);
                  nullable = series.ActualAwardDate;
                  dateTime1 = nullable.Value;
                  string str6 = dateTime1.ToString(format2);
                  if (!(str5 != str6) && !((string.IsNullOrEmpty(issue.IssueDetail.ActualAwardDateTimeZone) ? str2 : issue.IssueDetail.ActualAwardDateTimeZone.ToUpper()) != (string.IsNullOrEmpty(series.ActualAwardDateTimeZone) ? str2 : series.ActualAwardDateTimeZone.ToUpper())))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string[] strArray = new string[5]
                {
                  "; ",
                  string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode,
                  ": ",
                  null,
                  null
                };
                nullable = series.ActualAwardDate;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.ActualAwardDate;
                  dateTime1 = nullable.Value;
                  empty2 = dateTime1.ToString(format2);
                }
                strArray[3] = empty2;
                strArray[4] = string.IsNullOrEmpty(series.ActualAwardDateTimeZone) ? str2 : " " + series.ActualAwardDateTimeZone;
                string str5 = string.Concat(strArray);
                stringBuilder2.Append(str5);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string[] strArray = new string[5]
                {
                  " ",
                  string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode,
                  ": ",
                  null,
                  null
                };
                nullable = series.ActualAwardDate;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.ActualAwardDate;
                  dateTime1 = nullable.Value;
                  empty2 = dateTime1.ToString(format2);
                }
                strArray[3] = empty2;
                strArray[4] = string.IsNullOrEmpty(series.ActualAwardDateTimeZone) ? str2 : " " + series.ActualAwardDateTimeZone;
                string str5 = string.Concat(strArray);
                stringBuilder2.Append(str5);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str4) ? string.Empty : str4) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-DATED-DATE]":
            DateTime dateTime2;
            string str7;
            if (!issue.IssueDetail.DatedDate.HasValue)
            {
              str7 = "";
            }
            else
            {
              dateTime2 = issue.IssueDetail.DatedDate.Value;
              str7 = dateTime2.ToString(format1);
            }
            string str8 = str7;
            foreach (Series series in issue.IssueDetail.Series)
            {
              DateTime? datedDate = issue.IssueDetail.DatedDate;
              if (datedDate.HasValue)
              {
                datedDate = series.DatedDate;
                if (datedDate.HasValue)
                {
                  datedDate = issue.IssueDetail.DatedDate;
                  dateTime2 = datedDate.Value;
                  DateTime date1 = dateTime2.Date;
                  datedDate = series.DatedDate;
                  dateTime2 = datedDate.Value;
                  DateTime date2 = dateTime2.Date;
                  if (!(date1 != date2))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                datedDate = series.DatedDate;
                string empty2;
                if (!datedDate.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  datedDate = series.DatedDate;
                  dateTime2 = datedDate.Value;
                  empty2 = dateTime2.ToString(format1);
                }
                string str6 = "; " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                datedDate = series.DatedDate;
                string empty2;
                if (!datedDate.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  datedDate = series.DatedDate;
                  dateTime2 = datedDate.Value;
                  empty2 = dateTime2.ToString(format1);
                }
                string str6 = " " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str8) ? string.Empty : str8) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-DELIVERY-DATE]":
            DateTime dateTime3;
            string str9;
            if (!issue.IssueDetail.SettlementDate.HasValue)
            {
              str9 = "";
            }
            else
            {
              dateTime3 = issue.IssueDetail.SettlementDate.Value;
              str9 = dateTime3.ToString(format1);
            }
            string str10 = str9;
            foreach (Series series in issue.IssueDetail.Series)
            {
              DateTime? settlementDate = issue.IssueDetail.SettlementDate;
              if (settlementDate.HasValue)
              {
                settlementDate = series.SettlementDate;
                if (settlementDate.HasValue)
                {
                  settlementDate = issue.IssueDetail.SettlementDate;
                  dateTime3 = settlementDate.Value;
                  DateTime date1 = dateTime3.Date;
                  settlementDate = series.SettlementDate;
                  dateTime3 = settlementDate.Value;
                  DateTime date2 = dateTime3.Date;
                  if (!(date1 != date2))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                settlementDate = series.SettlementDate;
                string empty2;
                if (!settlementDate.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  settlementDate = series.SettlementDate;
                  dateTime3 = settlementDate.Value;
                  empty2 = dateTime3.ToString(format1);
                }
                string str6 = "; " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                settlementDate = series.SettlementDate;
                string empty2;
                if (!settlementDate.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  settlementDate = series.SettlementDate;
                  dateTime3 = settlementDate.Value;
                  empty2 = dateTime3.ToString(format1);
                }
                string str6 = " " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str10) ? string.Empty : str10) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-FIRM-LIABILITY]":
            Decimal num2;
            string str11;
            if (!issue.IssueDetail.FirmLiabilityPerc.HasValue)
            {
              str11 = "";
            }
            else
            {
              num2 = issue.IssueDetail.FirmLiabilityPerc.Value;
              str11 = num2.ToString();
            }
            string str12 = str11;
            foreach (Series series in issue.IssueDetail.Series)
            {
              Decimal? nullable = issue.IssueDetail.FirmLiabilityPerc;
              if (nullable.HasValue)
              {
                nullable = series.FirmLiability;
                if (nullable.HasValue)
                {
                  nullable = issue.IssueDetail.FirmLiabilityPerc;
                  Decimal num3 = nullable.Value;
                  nullable = series.FirmLiability;
                  Decimal num4 = nullable.Value;
                  if (!(num3 != num4))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.FirmLiability;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.FirmLiability;
                  num2 = nullable.Value;
                  empty2 = num2.ToString();
                }
                string str6 = "; " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.FirmLiability;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.FirmLiability;
                  num2 = nullable.Value;
                  empty2 = num2.ToString();
                }
                string str6 = " " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str12) ? string.Empty : str12) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-FIRM-MGT-FEE]":
            Decimal num5;
            string str13;
            if (!issue.IssueDetail.FirmMgmtFeePerc.HasValue)
            {
              str13 = "";
            }
            else
            {
              num5 = issue.IssueDetail.FirmMgmtFeePerc.Value;
              str13 = num5.ToString();
            }
            string str14 = str13;
            foreach (Series series in issue.IssueDetail.Series)
            {
              Decimal? nullable = issue.IssueDetail.FirmMgmtFeePerc;
              if (nullable.HasValue)
              {
                nullable = series.FirmMgtFee;
                if (nullable.HasValue)
                {
                  nullable = issue.IssueDetail.FirmMgmtFeePerc;
                  Decimal num3 = nullable.Value;
                  nullable = series.FirmMgtFee;
                  Decimal num4 = nullable.Value;
                  if (!(num3 != num4))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.FirmMgtFee;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.FirmMgtFee;
                  num5 = nullable.Value;
                  empty2 = num5.ToString();
                }
                string str6 = "; " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.FirmMgtFee;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.FirmMgtFee;
                  num5 = nullable.Value;
                  empty2 = num5.ToString();
                }
                string str6 = " " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str14) ? string.Empty : str14) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-FIRM-ROLE]":
            string str15 = string.IsNullOrEmpty(issue.IssueDetail.FirmRoleValue) ? string.Empty : issue.IssueDetail.FirmRoleValue.ToString();
            foreach (Series series in issue.IssueDetail.Series)
            {
              if (issue.IssueDetail.FirmRoleValue == null || string.IsNullOrEmpty(series.FirmRoleName) || issue.IssueDetail.FirmRoleValue != series.FirmRoleName)
              {
                if (stringBuilder1.Length <= 0)
                  stringBuilder1.Append(" (Except");
                if (num1 > 0)
                  stringBuilder1.Append("; " + (string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode) + ": " + (string.IsNullOrEmpty(series.FirmRoleName) ? string.Empty : series.FirmRoleName));
                else
                  stringBuilder1.Append(" " + (string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode) + ": " + (string.IsNullOrEmpty(series.FirmRoleName) ? string.Empty : series.FirmRoleName));
                ++num1;
              }
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str15) ? string.Empty : str15) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-PRICING-DATE]":
            DateTime dateTime4;
            string str16;
            if (!issue.IssueDetail.PricingDate.HasValue)
            {
              str16 = "";
            }
            else
            {
              dateTime4 = issue.IssueDetail.PricingDate.Value;
              str16 = dateTime4.ToString(format1);
            }
            string str17 = str16;
            foreach (Series series in issue.IssueDetail.Series)
            {
              DateTime? pricingDate = issue.IssueDetail.PricingDate;
              if (pricingDate.HasValue)
              {
                pricingDate = series.PricingDate;
                if (pricingDate.HasValue)
                {
                  pricingDate = issue.IssueDetail.PricingDate;
                  dateTime4 = pricingDate.Value;
                  DateTime date1 = dateTime4.Date;
                  pricingDate = series.PricingDate;
                  dateTime4 = pricingDate.Value;
                  DateTime date2 = dateTime4.Date;
                  if (!(date1 != date2))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                pricingDate = series.PricingDate;
                string empty2;
                if (!pricingDate.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  pricingDate = series.PricingDate;
                  dateTime4 = pricingDate.Value;
                  empty2 = dateTime4.ToString(format1);
                }
                string str6 = "; " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                pricingDate = series.PricingDate;
                string empty2;
                if (!pricingDate.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  pricingDate = series.PricingDate;
                  dateTime4 = pricingDate.Value;
                  empty2 = dateTime4.ToString(format1);
                }
                string str6 = " " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str17) ? string.Empty : str17) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-ROP-DATE]":
            DateTime dateTime5;
            string str18;
            if (!issue.IssueDetail.ROPDate.HasValue)
            {
              str18 = "";
            }
            else
            {
              dateTime5 = issue.IssueDetail.ROPDate.Value;
              str18 = dateTime5.ToString(format1);
            }
            string str19 = str18;
            foreach (Series series in issue.IssueDetail.Series)
            {
              DateTime? nullable = issue.IssueDetail.ROPDate;
              if (nullable.HasValue)
              {
                nullable = series.RetailOrderPeriodDate;
                if (nullable.HasValue)
                {
                  nullable = issue.IssueDetail.ROPDate;
                  dateTime5 = nullable.Value;
                  DateTime date1 = dateTime5.Date;
                  nullable = series.RetailOrderPeriodDate;
                  dateTime5 = nullable.Value;
                  DateTime date2 = dateTime5.Date;
                  if (!(date1 != date2))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.RetailOrderPeriodDate;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.RetailOrderPeriodDate;
                  dateTime5 = nullable.Value;
                  empty2 = dateTime5.ToString(format1);
                }
                string str6 = "; " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.RetailOrderPeriodDate;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.RetailOrderPeriodDate;
                  dateTime5 = nullable.Value;
                  empty2 = dateTime5.ToString(format1);
                }
                string str6 = " " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str19) ? string.Empty : str19) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
          case "[CONC-SERIES-SDC-CREDIT]":
            Decimal num6;
            string empty3;
            if (!issue.IssueDetail.SDCCreditPerc.HasValue)
            {
              empty3 = string.Empty;
            }
            else
            {
              num6 = issue.IssueDetail.SDCCreditPerc.Value;
              empty3 = num6.ToString();
            }
            string str20 = empty3;
            foreach (Series series in issue.IssueDetail.Series)
            {
              Decimal? nullable = issue.IssueDetail.SDCCreditPerc;
              if (nullable.HasValue)
              {
                nullable = series.SdcCredit;
                if (nullable.HasValue)
                {
                  nullable = issue.IssueDetail.SDCCreditPerc;
                  Decimal num3 = nullable.Value;
                  nullable = series.SdcCredit;
                  Decimal num4 = nullable.Value;
                  if (!(num3 != num4))
                    continue;
                }
              }
              if (stringBuilder1.Length <= 0)
                stringBuilder1.Append(" (Except");
              if (num1 > 0)
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.SdcCredit;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.SdcCredit;
                  num6 = nullable.Value;
                  empty2 = num6.ToString();
                }
                string str6 = "; " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              else
              {
                StringBuilder stringBuilder2 = stringBuilder1;
                string str5 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
                nullable = series.SdcCredit;
                string empty2;
                if (!nullable.HasValue)
                {
                  empty2 = string.Empty;
                }
                else
                {
                  nullable = series.SdcCredit;
                  num6 = nullable.Value;
                  empty2 = num6.ToString();
                }
                string str6 = " " + str5 + ": " + empty2;
                stringBuilder2.Append(str6);
              }
              ++num1;
            }
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append(")");
            str1 = (string.IsNullOrEmpty(str20) ? string.Empty : str20) + (string.IsNullOrEmpty(stringBuilder1.ToString()) ? string.Empty : stringBuilder1.ToString());
            break;
        }
      }
      return str1;
    }

    private string GetSeriesPlaceholderfromConcatenatedValue(IrisSoftware.iMPACT.Data.Issue issue, string PlcHlder)
    {
      string PlcHlderValue = string.Empty;
      if (PlcHlder == "[SERIES_PAR-DESC-TAX]")
        PlcHlderValue = "[SERIES-PAR-AMT] [SERIES-INFO] [FED-TAXABLE]";
      return this.GetConcatenatedSeriesValue(issue, PlcHlderValue);
    }

    private string GetReviewComment(IrisSoftware.iMPACT.Data.Issue issue)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (issue.IssueReviews != null && issue.IssueReviews.Any<ReviewComments>())
      {
        if (issue.IssueReviews.First<ReviewComments>().ReviewComment != null)
          stringBuilder.Append(issue.IssueReviews.First<ReviewComments>().ReviewComment);
        stringBuilder.Append(" (");
        if (issue.IssueReviews.First<ReviewComments>().UserName != null)
          stringBuilder.Append(issue.IssueReviews.First<ReviewComments>().UserName);
        stringBuilder.Append("; ");
        DateTime? reviewCommentDateTime = issue.IssueReviews.First<ReviewComments>().ReviewCommentDateTime;
        if (reviewCommentDateTime.HasValue)
        {
          reviewCommentDateTime = issue.IssueReviews.First<ReviewComments>().ReviewCommentDateTime;
          DateTime localTime = DateTime.SpecifyKind(reviewCommentDateTime.Value, DateTimeKind.Utc).ToLocalTime();
          stringBuilder.Append(localTime.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/'));
        }
        stringBuilder.Append(")");
      }
      return stringBuilder.ToString();
    }

    private string GetLT_ST_CombinedRatings(IrisSoftware.iMPACT.Data.Issue issue)
    {
      StringBuilder stringBuilder = new StringBuilder();
      string str1 = string.Empty;
      string str2 = string.Empty;
      bool flag1 = true;
      bool flag2 = true;
      if (issue != null && issue.IssueDetail.Series != null)
      {
        List<Series> list = issue.IssueDetail.Series.ToList<Series>();
        for (int index = 0; index < issue.IssueDetail.Series.Count<Series>(); ++index)
        {
          if (index == 0)
          {
            str1 = (string.IsNullOrEmpty(list[index].MoodyRatingLT) ? "-/" : list[index].MoodyRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingLT) ? "-/" : list[index].SPRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingLT) ? "-/" : list[index].FitchRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingLT) ? "-" : list[index].KrollRatingLT.Trim());
            str2 = (string.IsNullOrEmpty(list[index].MoodyRatingST) ? "-/" : list[index].MoodyRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingST) ? "-/" : list[index].SPRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingST) ? "-/" : list[index].FitchRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingST) ? "-" : list[index].KrollRatingST.Trim());
          }
          if (index > 0)
          {
            if (str1 != (string.IsNullOrEmpty(list[index].MoodyRatingLT) ? "-/" : list[index].MoodyRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingLT) ? "-/" : list[index].SPRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingLT) ? "-/" : list[index].FitchRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingLT) ? "-" : list[index].KrollRatingLT.Trim()))
            {
              flag1 = false;
              break;
            }
            if (str2 != (string.IsNullOrEmpty(list[index].MoodyRatingST) ? "-/" : list[index].MoodyRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingST) ? "-/" : list[index].SPRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingST) ? "-/" : list[index].FitchRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingST) ? "-" : list[index].KrollRatingST.Trim()))
            {
              flag2 = false;
              break;
            }
          }
        }
        if (flag1 & flag2)
        {
          if (!string.IsNullOrEmpty(str1) && str1 != "-/-/-/-")
          {
            stringBuilder.Append("(L/T): ");
            stringBuilder.Append(str1);
          }
          if (!string.IsNullOrEmpty(str2) && str2 != "-/-/-/-")
          {
            if (stringBuilder.Length > 0)
            {
              stringBuilder.Append(";");
              stringBuilder.Append("<br />");
            }
            stringBuilder.Append("(S/T): ");
            stringBuilder.Append(str2);
          }
        }
        else
        {
          string empty = string.Empty;
          foreach (Series series in issue.IssueDetail.Series)
          {
            string str3 = (string.IsNullOrEmpty(series.MoodyRatingLT) ? "-/" : series.MoodyRatingLT.Trim() + "/") + (string.IsNullOrEmpty(series.SPRatingLT) ? "-/" : series.SPRatingLT.Trim() + "/") + (string.IsNullOrEmpty(series.FitchRatingLT) ? "-/" : series.FitchRatingLT.Trim() + "/") + (string.IsNullOrEmpty(series.KrollRatingLT) ? "-" : series.KrollRatingLT.Trim());
            if (str3 != "-/-/-/-")
            {
              if (stringBuilder.Length > 0)
              {
                stringBuilder.Append(";");
                stringBuilder.Append("<br />");
              }
              stringBuilder.Append(series.SeriesCode + " (L/T): " + str3);
            }
            string str4 = (string.IsNullOrEmpty(series.MoodyRatingST) ? "-/" : series.MoodyRatingST.Trim() + "/") + (string.IsNullOrEmpty(series.SPRatingST) ? "-/" : series.SPRatingST.Trim() + "/") + (string.IsNullOrEmpty(series.FitchRatingST) ? "-/" : series.FitchRatingST.Trim() + "/") + (string.IsNullOrEmpty(series.KrollRatingST) ? "-" : series.KrollRatingST.Trim());
            if (str4 != "-/-/-/-")
            {
              if (stringBuilder.Length > 0)
              {
                stringBuilder.Append(";");
                stringBuilder.Append("<br />");
              }
              stringBuilder.Append(series.SeriesCode + " (S/T): " + str4);
            }
          }
        }
      }
      return stringBuilder.ToString();
    }

    public string ResolvePlaceholders(string _body, IrisSoftware.iMPACT.Data.Issue issue)
    {
      string str1 = HttpContext.Current.Request.UrlReferrer.AbsoluteUri;
      string newValue1 = string.Empty;
      string format = "MM'/'dd'/'yyyy";
      if (str1.ToUpper().Contains("?CISSUEID"))
        str1 = HttpContext.Current.Request.UrlReferrer.AbsoluteUri.Split('?')[0] + "?IssueID=" + (object) issue.IssueDetail.AppTransactionID;
      else if (issue != null && !HttpContext.Current.Request.UrlReferrer.Query.ToUpper().Contains("ISSUEID"))
        str1 = str1 + "?IssueID=" + (object) issue.IssueDetail.AppTransactionID;
      if (!HttpContext.Current.Request.UrlReferrer.Query.ToLower().Contains("tab"))
        newValue1 = str1 + "&tab=7";
      string newValue2 = string.Empty;
      DateTime? nullable1 = issue.IssueDetail.ExpectedAwardDate;
      if (nullable1.HasValue)
      {
        nullable1 = issue.IssueDetail.ExpectedAwardDate;
        newValue2 = nullable1.Value.ToString(format);
        if (issue.IssueDetail.ExpectedAwardTxtDate.Trim().ToUpper() != "AS OF")
          newValue2 = newValue2 + " " + issue.IssueDetail.ExpectedAwardTxtDate;
      }
      _body = this.UpdateEmailSeriesData(_body, issue);
      StringBuilder stringBuilder1 = new StringBuilder(_body);
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string newValue3 = string.IsNullOrEmpty(issue.IssueDetail.FirmRoleValue) ? string.Empty : issue.IssueDetail.FirmRoleValue;
      string str2 = string.IsNullOrEmpty(issue.IssueDetail.FirmRoleValue) ? string.Empty : issue.IssueDetail.FirmRoleValue;
      Decimal? nullable2 = issue.IssueDetail.FirmLiabilityPerc;
      Decimal num1;
      string str3;
      if (!nullable2.HasValue)
      {
        str3 = string.Empty;
      }
      else
      {
        nullable2 = issue.IssueDetail.FirmLiabilityPerc;
        num1 = nullable2.Value;
        str3 = " (" + num1.ToString() + "%)";
      }
      string newValue4 = str2 + str3;
      string empty3 = string.Empty;
      nullable1 = issue.IssueDetail.ActualAwardDateTime;
      string empty4;
      if (!nullable1.HasValue)
      {
        empty4 = string.Empty;
      }
      else
      {
        nullable1 = issue.IssueDetail.ActualAwardDateTime;
        empty4 = nullable1.Value.ToString("MM'/'dd'/'yyyy hh:mm tt");
      }
      string str4 = string.IsNullOrEmpty(issue.IssueDetail.ActualAwardDateTimeZone) ? "ET" : " " + issue.IssueDetail.ActualAwardDateTimeZone;
      string newValue5 = empty4 + str4;
      StringBuilder stringBuilder2 = stringBuilder1.Replace("[TRANSACTION-DESCRIPTION]", issue.IssueDetail.IssueName).Replace("[TRANSACTION-DESCRIPTION-WITH-LINK]", this.GetIssueLink(issue.IssueDetail.AppTransactionID, issue.IssueDetail.IssueName)).Replace("[ISSUER-NAME]", issue.IssueDetail.IssuerName).Replace("[ISSUER-NAME-WITH-LINK]", this.GetIssueLink(issue.IssueDetail.AppTransactionID, issue.IssueDetail.IssuerName));
      nullable2 = issue.IssueDetail.ParAmount;
      string newValue6;
      if (!nullable2.HasValue)
      {
        newValue6 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.ParAmount;
        newValue6 = string.Format("{0:C0}", (object) nullable2.Value);
      }
      StringBuilder stringBuilder3 = stringBuilder2.Replace("[PAR-AMT]", newValue6);
      nullable2 = issue.IssueDetail.GoodFaithAmount;
      string newValue7;
      if (!nullable2.HasValue)
      {
        newValue7 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.GoodFaithAmount;
        newValue7 = string.Format("{0:C}", (object) nullable2.Value);
      }
      StringBuilder stringBuilder4 = stringBuilder3.Replace("[GOOD-FAITH-AMT]", newValue7).Replace("[EXPECTED-AWARD-DATE]", newValue2);
      nullable1 = issue.IssueDetail.TicketExecDateTime;
      string newValue8;
      if (!nullable1.HasValue)
      {
        newValue8 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.TicketExecDateTime;
        newValue8 = nullable1.Value.ToString("MM'/'dd'/'yyyy hh:mm tt");
      }
      StringBuilder stringBuilder5 = stringBuilder4.Replace("[TICKET-DATE]", newValue8).Replace("[LINK-TO-PLATFORM-DOCUMENTS]", newValue1);
      nullable1 = issue.IssueDetail.GoodFaithDate;
      string newValue9;
      if (!nullable1.HasValue)
      {
        newValue9 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.GoodFaithDate;
        newValue9 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder6 = stringBuilder5.Replace("[GOOD-FAITH-DATE]", newValue9).Replace("[GOOD-FAITH-TYPE]", issue.IssueDetail.GoodFaithTypeValue).Replace("[ACCOUNT-NAME]", issue.IssueDetail.AccountName).Replace("[ACCOUNT-NUMBER]", issue.IssueDetail.AccountNumber).Replace("[ABA-NUMBER]", issue.IssueDetail.ABANumber).Replace("[NOTES]", issue.IssueDetail.GoodFaithNotes).Replace("[GOOD-FAITH-INSTRUCTIONS]", issue.IssueDetail.GoodFaithInstructions).Replace("[G-17-CONTACT-PREFIX]", issue.IssueDetail.G17ContactPrefix).Replace("[G-17-CONTACT-FIRST-NAME]", issue.IssueDetail.G17ContactFirstName).Replace("[G-17-CONTACT-LAST-NAME]", issue.IssueDetail.G17ContactLastName).Replace("[G17-CONTACT-SUFFIX]", issue.IssueDetail.G17ContactSuffix).Replace("[G-17-CONTACT-TITLE]", issue.IssueDetail.G17ContactJobTitle).Replace("[G17-CONTACT-EMAIL]", issue.IssueDetail.G17ContactEmail).Replace("[G17-CONTACT-ADDRESS]", issue.IssueDetail.G17ContactAddress).Replace("[TAX-STATUS]", issue.IssueDetail.TaxStatus).Replace("[ISSUE-UNDERLYING-RATING]", issue.IssueDetail.IssueUnderlyingRating).Replace("[ISSUER-ADDRESS]", issue.IssueDetail.IssuerAddress).Replace("[ACTUAL-AWARD-DATE]", newValue5);
      nullable1 = issue.IssueDetail.ROPDate;
      string newValue10;
      if (!nullable1.HasValue)
      {
        newValue10 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.ROPDate;
        newValue10 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder7 = stringBuilder6.Replace("[ROP-DATE]", newValue10).Replace("[MS-ROLE]", newValue3);
      nullable1 = issue.IssueDetail.DatedDate;
      string newValue11;
      if (!nullable1.HasValue)
      {
        newValue11 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.DatedDate;
        newValue11 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder8 = stringBuilder7.Replace("[DATED-DATE]", newValue11);
      nullable2 = issue.IssueDetail.FirmLiabilityPerc;
      string newValue12;
      if (!nullable2.HasValue)
      {
        newValue12 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.FirmLiabilityPerc;
        num1 = nullable2.Value;
        newValue12 = num1.ToString();
      }
      StringBuilder stringBuilder9 = stringBuilder8.Replace("[FIRM-LIABILITY]", newValue12);
      nullable2 = issue.IssueDetail.FirmMgmtFeePerc;
      string newValue13;
      if (!nullable2.HasValue)
      {
        newValue13 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.FirmMgmtFeePerc;
        num1 = nullable2.Value;
        newValue13 = num1.ToString();
      }
      StringBuilder stringBuilder10 = stringBuilder9.Replace("[FIRM-MGT-FEE]", newValue13);
      nullable2 = issue.IssueDetail.SDCCreditPerc;
      string newValue14;
      if (!nullable2.HasValue)
      {
        newValue14 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.SDCCreditPerc;
        num1 = nullable2.Value;
        newValue14 = num1.ToString();
      }
      StringBuilder stringBuilder11 = stringBuilder10.Replace("[SDC-CREDIT]", newValue14).Replace("[SERIES_PAR-DESC-TAX]", this.GetSeriesPlaceholderfromConcatenatedValue(issue, "[SERIES_PAR-DESC-TAX]")).Replace("[CONC-SERIES-DELIVERY-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-DELIVERY-DATE]")).Replace("[CONC-SERIES-DATED-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-DATED-DATE]")).Replace("[CONC-SERIES-PRICING-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-PRICING-DATE]")).Replace("[CONC-SERIES-ROP-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-ROP-DATE]")).Replace("[CONC-SERIES-ACTUAL-AWARD-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-ACTUAL-AWARD-DATE]")).Replace("[CONC-SERIES-FIRM-ROLE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-FIRM-ROLE]")).Replace("[CONC-SERIES-FIRM-LIABILITY]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-FIRM-LIABILITY]")).Replace("[CONC-SERIES-FIRM-MGT-FEE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-FIRM-MGT-FEE]")).Replace("[CONC-SERIES-SDC-CREDIT]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-SDC-CREDIT]")).Replace("[ISSUER-NAME]", issue.IssueDetail.IssuerName).Replace("[BORROWER/OBLIGOR]", issue.IssueDetail.BorrowerName);
      nullable1 = issue.IssueDetail.PricingDate;
      string newValue15;
      if (!nullable1.HasValue)
      {
        newValue15 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.PricingDate;
        newValue15 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder12 = stringBuilder11.Replace("[PRICING-DATE]", newValue15);
      nullable1 = issue.IssueDetail.BPASigningDate;
      string newValue16;
      if (!nullable1.HasValue)
      {
        newValue16 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.BPASigningDate;
        newValue16 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder13 = stringBuilder12.Replace("[EXPECTED-BPA-SIGNING]", newValue16).Replace("[MS-ROLE-AND-LIABILITY]", newValue4);
      nullable1 = issue.IssueDetail.SettlementDate;
      string newValue17;
      if (!nullable1.HasValue)
      {
        newValue17 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.SettlementDate;
        newValue17 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder14 = stringBuilder13.Replace("[DELIVERY-DATE]", newValue17).Replace("[PURPOSE]", issue.IssueDetail.PurposeTxt).Replace("[REASON-OF-ON-HOLD]", issue.IssueDetail.ReasonOfHold).Replace("[MS-BANKING-GROUP]", issue.IssueDetail.GeneralCategoryTxt);
      nullable1 = issue.IssueDetail.DateHired;
      string newValue18;
      if (!nullable1.HasValue)
      {
        newValue18 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.DateHired;
        newValue18 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder15 = stringBuilder14.Replace("[DATE-HIRED]", newValue18).Replace("[TYPE-OF-OFFERING]", issue.IssueDetail.OfferingTypeTxt).Replace("[DEAL-TYPE]", issue.IssueDetail.DealTypeTxt).Replace("[CROSS-SELL]", issue.IssueDetail.CrossSellIdTxt).Replace("[CROSS-SELL-DETAILS]", issue.IssueDetail.CrossSellDetail);
      nullable1 = issue.IssueDetail.OSDeemedFinalDate;
      string newValue19;
      if (!nullable1.HasValue)
      {
        newValue19 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.OSDeemedFinalDate;
        newValue19 = nullable1.Value.ToString(format);
      }
      StringBuilder stringBuilder16 = stringBuilder15.Replace("[OS-DEEMED-FINAL-DATE]", newValue19).Replace("[REVIEW-COMMENT]", this.GetReviewComment(issue)).Replace("[LT-ST-Underlying-Rating]", this.GetLT_ST_CombinedRatings(issue));
      StringBuilder stringBuilder17;
      if (issue.ExternalPartners != null)
      {
        string str5 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -3L || m.MemberType == -4L || m.MemberType == -10L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x =>
        {
          string str5 = string.IsNullOrEmpty(x.Name) ? string.Empty : x.Name;
          Decimal? liabilityPerc = x.LiabilityPerc;
          string str6;
          if (liabilityPerc.HasValue)
          {
            liabilityPerc = x.LiabilityPerc;
            str6 = " (" + liabilityPerc.Value.ToString() + "%)";
          }
          else
            str6 = string.Empty;
          return str5 + str6;
        })).ToArray<string>());
        string str8 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -11L || m.MemberType == -5L || m.MemberType == -7L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x =>
        {
          string str5 = string.IsNullOrEmpty(x.Name) ? string.Empty : x.Name;
          Decimal? liabilityPerc = x.LiabilityPerc;
          string str6;
          if (liabilityPerc.HasValue)
          {
            liabilityPerc = x.LiabilityPerc;
            str6 = " (" + liabilityPerc.Value.ToString() + "%)";
          }
          else
            str6 = string.Empty;
          return str5 + str6;
        })).ToArray<string>());
        long? firmRole = issue.IssueDetail.FirmRole;
        long num2 = -12;
        if ((firmRole.GetValueOrDefault() == num2 ? (firmRole.HasValue ? 1 : 0) : 0) == 0)
        {
          firmRole = issue.IssueDetail.FirmRole;
          long num3 = -13;
          if ((firmRole.GetValueOrDefault() == num3 ? (firmRole.HasValue ? 1 : 0) : 0) == 0)
          {
            firmRole = issue.IssueDetail.FirmRole;
            long num4 = -20;
            if ((firmRole.GetValueOrDefault() == num4 ? (firmRole.HasValue ? 1 : 0) : 0) == 0)
            {
              firmRole = issue.IssueDetail.FirmRole;
              long num5 = -21;
              if ((firmRole.GetValueOrDefault() == num5 ? (firmRole.HasValue ? 1 : 0) : 0) == 0)
              {
                firmRole = issue.IssueDetail.FirmRole;
                long num6 = -14;
                if ((firmRole.GetValueOrDefault() == num6 ? (firmRole.HasValue ? 1 : 0) : 0) == 0)
                {
                  firmRole = issue.IssueDetail.FirmRole;
                  long num7 = -16;
                  if ((firmRole.GetValueOrDefault() == num7 ? (firmRole.HasValue ? 1 : 0) : 0) == 0)
                    goto label_76;
                }
              }
              if (!string.IsNullOrEmpty(str8))
                str8 += "; ";
              AppConfig appConfig = this.AppConfigRepository.FetchByKey(1);
              string str6 = str8;
              string str7 = appConfig == null || appConfig.Value == null ? string.Empty : appConfig.Value;
              nullable2 = issue.IssueDetail.FirmLiabilityPerc;
              string str9;
              if (nullable2.HasValue)
              {
                nullable2 = issue.IssueDetail.FirmLiabilityPerc;
                str9 = " (" + nullable2.ToString() + "%)";
              }
              else
                str9 = string.Empty;
              str8 = str6 + str7 + str9;
              goto label_76;
            }
          }
        }
        if (!string.IsNullOrEmpty(str5))
          str5 += "; ";
        AppConfig appConfig1 = this.AppConfigRepository.FetchByKey(1);
        string str10 = str5;
        string str11 = appConfig1 == null || appConfig1.Value == null ? string.Empty : appConfig1.Value;
        nullable2 = issue.IssueDetail.FirmLiabilityPerc;
        string str12;
        if (nullable2.HasValue)
        {
          nullable2 = issue.IssueDetail.FirmLiabilityPerc;
          str12 = " (" + nullable2.ToString() + "%)";
        }
        else
          str12 = string.Empty;
        str5 = str10 + str11 + str12;
label_76:
        StringBuilder stringBuilder18 = stringBuilder16.Replace("[LEAD-MANAGER]", str5 ?? "").Replace("[OTHER-CO-MANAGERS]", str8 ?? "");
        string newValue20 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -43L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToArray<string>());
        string newValue21 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -44L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToArray<string>());
        stringBuilder17 = stringBuilder18.Replace("[FINANCIAL-ADVISOR]", newValue20).Replace("[PAYING-AGENT]", newValue21);
      }
      else
        stringBuilder17 = stringBuilder16.Replace("[LEAD-MANAGER]", string.Empty).Replace("[OTHER-CO-MANAGERS]", string.Empty).Replace("[FINANCIAL-ADVISOR]", string.Empty).Replace("[PAYING-AGENT]", string.Empty);
      StringBuilder stringBuilder19 = stringBuilder17.Replace("[JOB-NUMBER]", issue.IssueDetail.JobNumber);
      StringBuilder stringBuilder20;
      if (issue.InternalPartners != null)
      {
        string str5 = string.Join("; ", issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (m => m.IsPrimary == "1" && m.Type == "IBT")).Select<InternalPartner, string>((Func<InternalPartner, string>) (x => !string.IsNullOrEmpty(x.FullName) ? x.FullName : string.Empty)).ToArray<string>());
        string str6 = string.Join("; ", issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (m => m.IsPrimary != "1" && m.Type == "IBT")).Select<InternalPartner, string>((Func<InternalPartner, string>) (x => !string.IsNullOrEmpty(x.FullName) ? x.FullName : string.Empty)).ToArray<string>());
        string str7 = string.Join("; ", issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (m => m.Type == "IBT")).Select<InternalPartner, string>((Func<InternalPartner, string>) (x => !string.IsNullOrEmpty(x.FullName) ? x.FullName : string.Empty)).Distinct<string>().ToArray<string>());
        stringBuilder20 = stringBuilder19.Replace("[LEAD-BANKER]", str5 ?? "").Replace("[SUPPORTING-BANKER]", str6 ?? "").Replace("[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]", str7 ?? "");
      }
      else
        stringBuilder20 = stringBuilder19.Replace("[LEAD-BANKER]", string.Empty).Replace("[SUPPORTING-BANKER]", string.Empty);
      return stringBuilder20.ToString();
    }

    private string GetIssueLink(long appTransactionId, string text)
    {
      string[] segments = HttpContext.Current.Request.UrlReferrer.Segments;
      if (segments.Length > 3)
      {
        segments[0] = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + "/";
        segments[segments.Length - 2] = "Issue/";
        segments[segments.Length - 1] = "Issue.aspx";
      }
      return string.Format("<a href='{0}?IssueId={1}'>{2}</a>", (object) string.Join(string.Empty, segments), (object) appTransactionId, (object) text);
    }

    private string GetSeriesData(IrisSoftware.iMPACT.Data.Issue issue)
    {
      string str = string.Empty;
      foreach (Series series in issue.IssueDetail.Series)
        str = str + string.Format("{0:C}", (object) series.ParAmount) + " " + series.SeriesName + "</br>";
      return str;
    }

    private void GetInternalPartnersEmailAddress(IrisSoftware.iMPACT.Data.Issue issue, out string[] partnersEmailAddress)
    {
      partnersEmailAddress = new string[8]
      {
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty
      };
      if (issue.InternalPartners == null || issue.InternalPartners.Count <= 0)
        return;
      foreach (InternalPartner internalPartner in issue.InternalPartners)
      {
        if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email) && internalPartner.IsActive)
        {
          switch ((IssueEnums.RoleTypes) internalPartner.RoleTypeId.Value)
          {
            case IssueEnums.RoleTypes.InvestmentBankingTeam:
              this.FillInvestmentBankingDetails(partnersEmailAddress, internalPartner);
              continue;
            case IssueEnums.RoleTypes.AnalystProfessionalSupport:
              this.FillAnalystDetails(partnersEmailAddress, internalPartner);
              continue;
            case IssueEnums.RoleTypes.SupervisoryPrincipal:
              partnersEmailAddress[4] = string.Format("{0}{1};", (object) partnersEmailAddress[4], (object) internalPartner.Email);
              continue;
            case IssueEnums.RoleTypes.BankRM:
              partnersEmailAddress[6] = string.Format("{0}{1};", (object) partnersEmailAddress[6], (object) internalPartner.Email);
              continue;
            case IssueEnums.RoleTypes.UnderWritingTeam:
              partnersEmailAddress[5] = string.Format("{0}{1};", (object) partnersEmailAddress[5], (object) internalPartner.Email);
              continue;
            default:
              continue;
          }
        }
      }
    }

    public RegulatoryCheckListViewModelContainer InitializeRegulatoryCheckList(
      long appTransactionId)
    {
      try
      {
        if (this.HasUIPermissionForEntity(-32L, appTransactionId, "Regulatory Requirement Checklist", "View"))
          return this.FetchIssueRegulatoryCheckListModelContainer(appTransactionId);
        RegulatoryCheckListViewModelContainer viewModelContainer = new RegulatoryCheckListViewModelContainer();
        viewModelContainer.ErrorMessage = "401";
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        RegulatoryCheckListViewModelContainer viewModelContainer = new RegulatoryCheckListViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    private bool ValidateRegCheckListModel(
      RegulatoryCheckListViewModelContainer modelContainer,
      ref SaveResult saveResult)
    {
      return saveResult.IsSuccessful;
    }

    private IssueRegulatoryCheckList GetRegulatoryCheckListModelFromViewModel(
      RegulatoryCheckListViewModelContainer issueContainer)
    {
      return new IssueRegulatoryCheckList()
      {
        MunicipalAdvisorRegCheckList = new MunicipalAdvisorRegCheckList()
        {
          WasRFP = issueContainer.MunicipalAdvisorViewModel.WasRFP,
          IsRegisteredMunicipalAdvisor = issueContainer.MunicipalAdvisorViewModel.IsRegisteredMunicipalAdvisor,
          IsIRMACertificationReceived = issueContainer.MunicipalAdvisorViewModel.IsIRMACertificationReceived,
          IRMACertificationDate = issueContainer.MunicipalAdvisorViewModel.IRMACertificationDate,
          IRMACertificationExpiryDate = issueContainer.MunicipalAdvisorViewModel.IRMACertificationExpiryDate,
          IsIRMAReprentativeSentToClientAndIssuer = issueContainer.MunicipalAdvisorViewModel.IsIRMAReprentativeSentToClientAndIssuer,
          IRMAPresentationDate = issueContainer.MunicipalAdvisorViewModel.IRMAPresentationDate,
          IsIRMAPresentationCopyRetained = issueContainer.MunicipalAdvisorViewModel.IsIRMAPresentationCopyRetained,
          ReasonForNoCopyRetained = issueContainer.MunicipalAdvisorViewModel.ReasonForNoCopyRetained,
          UnderWriterOrRemarketingAgentMethod = issueContainer.MunicipalAdvisorViewModel.UnderWriterOrRemarketingAgentMethod,
          EngagementDate = issueContainer.MunicipalAdvisorViewModel.EngagementDate,
          IssuerID = issueContainer.MunicipalAdvisorViewModel.IssuerID,
          EvidenceOfEngagement = issueContainer.MunicipalAdvisorViewModel.EvidenceOfEngagement,
          AppTransactionID = issueContainer.MunicipalAdvisorViewModel.AppTransactionID,
          EarlistDateOfEngagement = issueContainer.MunicipalAdvisorViewModel.EarlistDateOfEngagement,
          IRMANotPerfect = issueContainer.MunicipalAdvisorViewModel.IRMANotPerfect,
          FinancialAdvisor = issueContainer.MunicipalAdvisorViewModel.FinancialAdvisor
        },
        Rule15c212RegCheckList = new Rule15c212RegCheckList()
        {
          IsObtainedAndReviwedStatement = issueContainer.Rule15c212ViewModel.IsObtainedAndReviwedStatement,
          TypeOfDoc = issueContainer.Rule15c212ViewModel.TypeOfDoc,
          DateReceived = issueContainer.Rule15c212ViewModel.DateReceived,
          DateReviewed = issueContainer.Rule15c212ViewModel.DateReviewed,
          MethodDocDeemedFinal = issueContainer.Rule15c212ViewModel.MethodDocDeemedFinal,
          DateDocDeemedFinal = issueContainer.Rule15c212ViewModel.DateDocDeemedFinal,
          ReasonForNotObtainingOrReview = issueContainer.Rule15c212ViewModel.ReasonForNotObtainingOrReview,
          HasMeetAdoptedGuideLines = issueContainer.Rule15c212ViewModel.HasMeetAdoptedGuideLines,
          ReasonForNotAdoptingGuideLines = issueContainer.Rule15c212ViewModel.ReasonForNotAdoptingGuideLines,
          WasOfficialDocAmended = issueContainer.Rule15c212ViewModel.WasOfficialDocAmended,
          DocAmendedDate = issueContainer.Rule15c212ViewModel.DocAmendedDate,
          IsSlaMeet = issueContainer.Rule15c212ViewModel.IsSlaMeet,
          IssuerAndObligorCovenantMade = issueContainer.Rule15c212ViewModel.IssuerAndObligorCovenantMade,
          SlaViolationReason = issueContainer.Rule15c212ViewModel.SlaViolationReason,
          IsDilegenceReviewConducted = issueContainer.Rule15c212ViewModel.IsDilegenceReviewConducted,
          IsDilegenceCallOrMeeting = issueContainer.Rule15c212ViewModel.IsDilegenceCallOrMeeting,
          DilegenceMeetingDate = issueContainer.Rule15c212ViewModel.DilegenceMeetingDate,
          DilegenceReviewMethod = issueContainer.Rule15c212ViewModel.DilegenceReviewMethod,
          DidOutSideCounselAssisted = issueContainer.Rule15c212ViewModel.DidOutSideCounselAssisted,
          ReasonForNoAssistence = issueContainer.Rule15c212ViewModel.ReasonForNoAssistence,
          IsIssuerAndObligorAreInAggrement = issueContainer.Rule15c212ViewModel.IsIssuerAndObligorAreInAggrement,
          IssuerAndObligorAggrementPlace = issueContainer.Rule15c212ViewModel.IssuerAndObligorAggrementPlace,
          IssuerAndObligorNonAggrementReason = issueContainer.Rule15c212ViewModel.IssuerAndObligorNonAggrementReason,
          IsReviewedEMMAAndNRMSIR = issueContainer.Rule15c212ViewModel.IsReviewedEMMAAndNRMSIR,
          DidUnderWriterAssisted = issueContainer.Rule15c212ViewModel.DidUnderWriterAssisted,
          EMMAReviewDate = issueContainer.Rule15c212ViewModel.EMMAReviewDate,
          IsIssuerAndObligorCompliance = issueContainer.Rule15c212ViewModel.IsIssuerAndObligorCompliance,
          IncidentOfNonCompliance = issueContainer.Rule15c212ViewModel.IncidentOfNonCompliance,
          WasLegalAndComplianceConsulted = issueContainer.Rule15c212ViewModel.WasLegalAndComplianceConsulted,
          LegalAndComplianceDate = issueContainer.Rule15c212ViewModel.LegalAndComplianceDate,
          ReasonForNoLegalConsultaion = issueContainer.Rule15c212ViewModel.ReasonForNoLegalConsultaion,
          WasCDAFindingsSatifactory = issueContainer.Rule15c212ViewModel.WasCDAFindingsSatifactory,
          CDAFindingsUnSatisfactoryReason = issueContainer.Rule15c212ViewModel.CDAFindingsUnSatisfactoryReason,
          WasLegalAndComplianceConsultedReason = issueContainer.Rule15c212ViewModel.WasLegalAndComplianceConsultedReason
        },
        RuleG17G23ResulatoryCheckList = new RuleG17G23ResulatoryCheckList()
        {
          IsDeliveredToIssuer = issueContainer.RuleG17G23ViewModel.IsDeliveredToIssuer,
          DeliveryDateToIssuer = issueContainer.RuleG17G23ViewModel.DeliveryDateToIssuer,
          DeliveryDateToObligor = issueContainer.RuleG17G23ViewModel.DeliveryDateToObligor,
          IsDeliveredToObligor = issueContainer.RuleG17G23ViewModel.IsDeliveredToObligor,
          RoleDisclosureSender = issueContainer.RuleG17G23ViewModel.RoleDisclosureSender,
          RoleDisclosureMethodName = issueContainer.RuleG17G23ViewModel.RoleDisclosureMethodName,
          RoleDisclosureReceipentName = issueContainer.RuleG17G23ViewModel.RoleDisclosureReceipentName,
          IsRoleDisclosureLetterCopyRetained = issueContainer.RuleG17G23ViewModel.IsRoleDisclosureLetterCopyRetained,
          ReasonForNonRetainingCopy = issueContainer.RuleG17G23ViewModel.ReasonForNonRetainingCopy,
          IsRoleDisclosureAckReceived = issueContainer.RuleG17G23ViewModel.IsRoleDisclosureAckReceived,
          AckReceivedDate = issueContainer.RuleG17G23ViewModel.AckReceivedDate,
          AckExecuterName = issueContainer.RuleG17G23ViewModel.AckExecuterName,
          AckMethodForRoleDisclosure = issueContainer.RuleG17G23ViewModel.AckMethodForRoleDisclosure,
          IsCopyRetainedForRoleDisclosureAck = issueContainer.RuleG17G23ViewModel.IsCopyRetainedForRoleDisclosureAck,
          ReasonForNotGettingAckForRoleDisclosre = issueContainer.RuleG17G23ViewModel.ReasonForNotGettingAckForRoleDisclosre,
          IsConflictDisclosureLetterDeliveredToIssuer = issueContainer.RuleG17G23ViewModel.IsConflictDisclosureLetterDeliveredToIssuer,
          IsConflictDisclosureLetterDeliveredToObligor = issueContainer.RuleG17G23ViewModel.IsConflictDisclosureLetterDeliveredToObligor,
          ConflictDisclosreLetterDeliveryDateToIssuer = issueContainer.RuleG17G23ViewModel.ConflictDisclosreLetterDeliveryDateToIssuer,
          ReasonForNotRetaingCopyOfConflictDisclosure = issueContainer.RuleG17G23ViewModel.ReasonForNotRetaingCopyOfConflictDisclosure,
          IsAckReceivedOfConflictDisclosure = issueContainer.RuleG17G23ViewModel.IsAckReceivedOfConflictDisclosure,
          AckG17ReceivedDate = issueContainer.RuleG17G23ViewModel.AckG17ReceivedDate,
          AckConflictDisclosureExecuter = issueContainer.RuleG17G23ViewModel.AckConflictDisclosureExecuter,
          AckConflictMethod = issueContainer.RuleG17G23ViewModel.AckConflictMethod,
          IsAckCopyRetainedConflictDisclosure = issueContainer.RuleG17G23ViewModel.IsAckCopyRetainedConflictDisclosure,
          IsG17StructureAndRoleLetterDeliveredObligor = issueContainer.RuleG17G23ViewModel.IsG17StructureAndRoleLetterDeliveredObligor,
          G17SturectureAndRoleLetterDateIssuer = issueContainer.RuleG17G23ViewModel.G17SturectureAndRoleLetterDateIssuer,
          G17SturectureAndRoleLetterDateObligor = issueContainer.RuleG17G23ViewModel.G17SturectureAndRoleLetterDateObligor,
          G17SturectureAndRoleLetterSender = issueContainer.RuleG17G23ViewModel.G17SturectureAndRoleLetterSender,
          G17StructureAndRoleLetterMethod = issueContainer.RuleG17G23ViewModel.G17StructureAndRoleLetterMethod,
          G17StructureAndRoleLetterReceipent = issueContainer.RuleG17G23ViewModel.G17StructureAndRoleLetterReceipent,
          IsCopyRetainedForRoleDisclosure = issueContainer.RuleG17G23ViewModel.IsCopyRetainedForRoleDisclosure,
          ReasonForNotRetaingCopyOfRoleAndSturucture = issueContainer.RuleG17G23ViewModel.ReasonForNotRetaingCopyOfRoleAndSturucture,
          IsAckG17RoleAndStuructureLetterReceived = issueContainer.RuleG17G23ViewModel.IsAckG17RoleAndStuructureLetterReceived,
          AckG17RoleAndStructureLetterDate = issueContainer.RuleG17G23ViewModel.AckG17RoleAndStructureLetterDate,
          AckG17RoleAndStructureExecuter = issueContainer.RuleG17G23ViewModel.AckG17RoleAndStructureExecuter,
          AckG17RoleAndStructureMethod = issueContainer.RuleG17G23ViewModel.AckG17RoleAndStructureMethod,
          IsCopyRetainedG17RoleAndStructureAck = issueContainer.RuleG17G23ViewModel.IsCopyRetainedG17RoleAndStructureAck,
          ReasonForNoAckG17RoleAndStructure = issueContainer.RuleG17G23ViewModel.ReasonForNoAckG17RoleAndStructure,
          isEMMAReviewed = issueContainer.RuleG17G23ViewModel.isEMMAReviewed,
          IsUnderWriterAssistedEMMAReview = issueContainer.RuleG17G23ViewModel.IsUnderWriterAssistedEMMAReview,
          UnderWriterReviewDate = issueContainer.RuleG17G23ViewModel.UnderWriterReviewDate,
          IsUnderWriterPriceValid = issueContainer.RuleG17G23ViewModel.IsUnderWriterPriceValid,
          IsUnderWriterCertificateAmended = issueContainer.RuleG17G23ViewModel.IsUnderWriterCertificateAmended,
          IslegalAndComplianceConsulted = issueContainer.RuleG17G23ViewModel.IslegalAndComplianceConsulted,
          LegalAndComplianceConsultedDate = issueContainer.RuleG17G23ViewModel.LegalAndComplianceConsultedDate,
          ReasonForNoEMMAReview = issueContainer.RuleG17G23ViewModel.ReasonForNoEMMAReview,
          isFirmPayingToMSA = issueContainer.RuleG17G23ViewModel.isFirmPayingToMSA,
          IsMSAReviewed = issueContainer.RuleG17G23ViewModel.IsMSAReviewed,
          ReasonForNOMSAReview = issueContainer.RuleG17G23ViewModel.ReasonForNOMSAReview,
          MSAName = issueContainer.RuleG17G23ViewModel.MSAName,
          MSACertification = issueContainer.RuleG17G23ViewModel.MSACertification,
          AppTransactionID = issueContainer.RuleG17G23ViewModel.AppTransactionID,
          RoleLetterExplain = issueContainer.RuleG17G23ViewModel.RoleLetterExplain,
          ConflictLetterExplain = issueContainer.RuleG17G23ViewModel.ConflictLetterExplain,
          RoleDisclosureLetterExplain = issueContainer.RuleG17G23ViewModel.RoleDisclosureLetterExplain,
          StructureExplain = issueContainer.RuleG17G23ViewModel.StructureExplain
        },
        RuleG32RegulatoryCheckList = new RuleG32RegulatoryCheckList()
        {
          IsOfficialStatementPostedToEMMA = issueContainer.RuleG32ViewModel.IsOfficialStatementPostedToEMMA,
          OfficialStatementDate = issueContainer.RuleG32ViewModel.OfficialStatementDate,
          ReasonForNoPosting = issueContainer.RuleG32ViewModel.ReasonForNoPosting,
          IsEscrowfiledWithMSRB = issueContainer.RuleG32ViewModel.IsEscrowfiledWithMSRB,
          AggrementPostedDate = issueContainer.RuleG32ViewModel.AggrementPostedDate,
          ReasonForNoEscrowAggrement = issueContainer.RuleG32ViewModel.ReasonForNoEscrowAggrement,
          AppTransactionID = issueContainer.RuleG32ViewModel.AppTransactionID
        },
        RuleG34cRegulatoryCheckList = new RuleG34cRegulatoryCheckList()
        {
          IsLiquidyCommentsPosted = issueContainer.RuleG34cViewModel.IsLiquidyCommentsPosted,
          DocumentPostedDate = issueContainer.RuleG34cViewModel.DocumentPostedDate,
          ReasonForNoPosting = issueContainer.RuleG34cViewModel.ReasonForNoPosting,
          AppTransactionID = issueContainer.RuleG34cViewModel.AppTransactionID
        },
        ExpenseRegulatoryCheckList = new ExpenseRegulatoryCheckList()
        {
          IsSoleManaged = issueContainer.ExpensesViewModel.IsSoleManaged,
          LegalFeesNotes = issueContainer.ExpensesViewModel.LegalFeesNotes,
          SyndicateNotes = issueContainer.ExpensesViewModel.SyndicateNotes,
          DTCChargesNotes = issueContainer.ExpensesViewModel.DTCChargesNotes,
          IPREONotes = issueContainer.ExpensesViewModel.IPREONotes,
          CUSIPFeeNotes = issueContainer.ExpensesViewModel.CUSIPFeeNotes,
          MSRBandStateSpecificFeeNotes = issueContainer.ExpensesViewModel.MSRBandStateSpecificFeeNotes,
          AgentNotes = issueContainer.ExpensesViewModel.AgentNotes,
          TravelNotes = issueContainer.ExpensesViewModel.TravelNotes,
          MealsClientEntertainNotes = issueContainer.ExpensesViewModel.MealsClientEntertainNotes,
          InternetNotes = issueContainer.ExpensesViewModel.InternetNotes,
          PrintingNotes = issueContainer.ExpensesViewModel.PrintingNotes,
          MailDeliveryExpensesNotes = issueContainer.ExpensesViewModel.MailDeliveryExpensesNotes,
          MarketingNotes = issueContainer.ExpensesViewModel.MarketingNotes,
          CoManagerExpensesNotes = issueContainer.ExpensesViewModel.CoManagerExpensesNotes,
          OtherNotes = issueContainer.ExpensesViewModel.OtherNotes,
          LessExpenseReimbursementNotes = issueContainer.ExpensesViewModel.LessExpenseReimbursementNotes,
          TotalExpensesNotes = issueContainer.ExpensesViewModel.TotalExpensesNotes,
          TransactionExpensesNotes = issueContainer.ExpensesViewModel.TransactionExpensesNotes,
          DealMementosNotes = issueContainer.ExpensesViewModel.DealMementosNotes,
          StateSpecificFeeNotes = issueContainer.ExpensesViewModel.StateSpecificFeeNotes,
          AreExpensesAuthorized = issueContainer.ExpensesViewModel.AreExpensesAuthorized,
          ReasonForNonAutorization = issueContainer.ExpensesViewModel.ReasonForNonAutorization,
          IsDocAttachedToCheckList = issueContainer.ExpensesViewModel.IsDocAttachedToCheckList,
          ReasonForNotAttachingCheckList = issueContainer.ExpensesViewModel.ReasonForNotAttachingCheckList,
          Discripiencies = issueContainer.ExpensesViewModel.Discripiencies,
          LeadMSBanker = issueContainer.ExpensesViewModel.LeadMSBanker,
          LeadMSBankerSignDate = issueContainer.ExpensesViewModel.LeadMSBankerSignDate,
          SeriesSupervisor = issueContainer.ExpensesViewModel.SeriesSupervisor,
          SeriesSupervisorDate = issueContainer.ExpensesViewModel.SeriesSupervisorDate,
          AppTransactionID = issueContainer.ExpensesViewModel.ExpensesRegCheckListID
        },
        RegulatoryPnLCheckList = new RegulatoryPnLChecklist()
        {
          ActualSyndicate = issueContainer.RegulatoryPnLViewModel.ActualSyndicate,
          ProjectSyndicate = issueContainer.RegulatoryPnLViewModel.ProjectSyndicate,
          ActualLegal = issueContainer.RegulatoryPnLViewModel.ActualLegal,
          ProjectLegal = issueContainer.RegulatoryPnLViewModel.ProjectLegal,
          ActualDTCCharges = issueContainer.RegulatoryPnLViewModel.ActualDTCCharges,
          ProjectDTCCharges = issueContainer.RegulatoryPnLViewModel.ProjectDTCCharges,
          ActualCUSIPFees = issueContainer.RegulatoryPnLViewModel.ActualCUSIPFees,
          ProjectCUSIPFees = issueContainer.RegulatoryPnLViewModel.ProjectCUSIPFees,
          ActualIPREO = issueContainer.RegulatoryPnLViewModel.ActualIPREO,
          ProjectIPREO = issueContainer.RegulatoryPnLViewModel.ProjectIPREO,
          ActualMSRBAndStateSpecificFee = issueContainer.RegulatoryPnLViewModel.ActualMSRBAndStateSpecificFee,
          ProjectMSRBAndStateSpecificFee = issueContainer.RegulatoryPnLViewModel.ProjectMSRBAndStateSpecificFee,
          ActualCalcAgentAnalysis = issueContainer.RegulatoryPnLViewModel.ActualCalcAgentAnalysis,
          ProjectCalcAgentAnalysis = issueContainer.RegulatoryPnLViewModel.ProjectCalcAgentAnalysis,
          ActualTravelExpenses = issueContainer.RegulatoryPnLViewModel.ActualTravelExpenses,
          ProjectTravelExpenses = issueContainer.RegulatoryPnLViewModel.ProjectTravelExpenses,
          ActualMealsClientEntertaing = issueContainer.RegulatoryPnLViewModel.ActualMealsClientEntertaing,
          ProjectMealsClientEntertaing = issueContainer.RegulatoryPnLViewModel.ProjectMealsClientEntertaing,
          ActualInternetRoadShow = issueContainer.RegulatoryPnLViewModel.ActualInternetRoadShow,
          ProjectInternetRoadShow = issueContainer.RegulatoryPnLViewModel.ProjectInternetRoadShow,
          ActualPrintingCharges = issueContainer.RegulatoryPnLViewModel.ActualPrintingCharges,
          ProjectPrintingCharges = issueContainer.RegulatoryPnLViewModel.ProjectPrintingCharges,
          ActualDeliveryExpenses = issueContainer.RegulatoryPnLViewModel.ActualDeliveryExpenses,
          ProjectDeliveryExpenses = issueContainer.RegulatoryPnLViewModel.ProjectDeliveryExpenses,
          ActualMarketing = issueContainer.RegulatoryPnLViewModel.ActualMarketing,
          ProjectMarketing = issueContainer.RegulatoryPnLViewModel.ProjectMarketing,
          ActualCoManagerExpenses = issueContainer.RegulatoryPnLViewModel.ActualCoManagerExpenses,
          ProjectCoManagerExpenses = issueContainer.RegulatoryPnLViewModel.ProjectCoManagerExpenses,
          ActualOtherExpenses = issueContainer.RegulatoryPnLViewModel.ActualOtherExpenses,
          ProjectOtherExpenses = issueContainer.RegulatoryPnLViewModel.ProjectOtherExpenses,
          ActualLessExpenseReimbursement = issueContainer.RegulatoryPnLViewModel.ActualLessExpenseReimbursement,
          ProjectLessExpenseReimbursement = issueContainer.RegulatoryPnLViewModel.ProjectLessExpenseReimbursement,
          ActualTotalExpenses = issueContainer.RegulatoryPnLViewModel.ActualTotalExpenses,
          ProjectTotalExpenses = issueContainer.RegulatoryPnLViewModel.ProjectTotalExpenses,
          ActualTransactionExpenses = issueContainer.RegulatoryPnLViewModel.ActualTransactionExpenses,
          ProjectTransactionExpenses = issueContainer.RegulatoryPnLViewModel.ProjectTransactionExpenses,
          ProjectDealMementos = issueContainer.RegulatoryPnLViewModel.ProjectDealMementos,
          ActualDealMementos = issueContainer.RegulatoryPnLViewModel.ActualDealMementos,
          ProjectStateSpecificFee = issueContainer.RegulatoryPnLViewModel.ProjectStateSpecificFee,
          ActualStateSpecificFee = issueContainer.RegulatoryPnLViewModel.ActualStateSpecificFee
        },
        DisclosureDiligenceRegChecklist = new DisclosureDiligenceRegChecklist()
        {
          DisclosureDiligenceRegCheckListID = issueContainer.DisclosureDiligenceRegChecklistViewModel.DisclosureDiligenceRegCheckListID,
          AppTransactionID = issueContainer.DisclosureDiligenceRegChecklistViewModel.AppTransactionID,
          IsObtainedAndReviwedFinalDoc = issueContainer.DisclosureDiligenceRegChecklistViewModel.IsObtainedAndReviwedFinalDoc,
          TypeOfDocument = issueContainer.DisclosureDiligenceRegChecklistViewModel.TypeOfDocument,
          DateReceived = issueContainer.DisclosureDiligenceRegChecklistViewModel.DateReceived,
          DateReviewed = issueContainer.DisclosureDiligenceRegChecklistViewModel.DateReviewed,
          ReasonForNotObtainingOrReviewFinalDoc = issueContainer.DisclosureDiligenceRegChecklistViewModel.ReasonForNotObtainingOrReviewFinalDoc,
          WasDisclosureDocumentAmended = issueContainer.DisclosureDiligenceRegChecklistViewModel.WasDisclosureDocumentAmended,
          DocumentAmendedDate = issueContainer.DisclosureDiligenceRegChecklistViewModel.DocumentAmendedDate,
          IsDueDilegenceReviewConducted = issueContainer.DisclosureDiligenceRegChecklistViewModel.IsDueDilegenceReviewConducted,
          IsDueDilegenceCallOrMeeting = issueContainer.DisclosureDiligenceRegChecklistViewModel.IsDueDilegenceCallOrMeeting,
          DueDilegenceMeetingDate = issueContainer.DisclosureDiligenceRegChecklistViewModel.DueDilegenceMeetingDate,
          DueDilegenceReviewMethod = issueContainer.DisclosureDiligenceRegChecklistViewModel.DueDilegenceReviewMethod,
          DidOutSideCounselDiligence = issueContainer.DisclosureDiligenceRegChecklistViewModel.DidOutSideCounselDiligence,
          ReasonForNoDueDiligence = issueContainer.DisclosureDiligenceRegChecklistViewModel.ReasonForNoDueDiligence,
          HasIssuerObligorCovenanted = issueContainer.DisclosureDiligenceRegChecklistViewModel.HasIssuerObligorCovenanted,
          IssuerObligorCovenanted = issueContainer.DisclosureDiligenceRegChecklistViewModel.IssuerObligorCovenanted,
          ReasonForNoIssuerObligorCovenanted = issueContainer.DisclosureDiligenceRegChecklistViewModel.ReasonForNoIssuerObligorCovenanted
        }
      };
    }

    public SaveResult SaveRegulatoryCheckList(
      RegulatoryCheckListViewModelContainer checkListContainer)
    {
      long appTransactionId = checkListContainer.IssueRegulatoryCheckListViewModel.AppTransactionID;
      try
      {
        this.GetSafeObject<RegulatoryCheckListViewModelContainer>(checkListContainer);
        SaveResult saveResult = checkListContainer.Validate<RegulatoryCheckListViewModelContainer>();
        if (saveResult.IsSuccessful && this.ValidateRegCheckListModel(checkListContainer, ref saveResult))
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            if (this.IssueRepository.SaveRegulatoryCheckList(this.GetRegulatoryCheckListModelFromViewModel(checkListContainer), appTransactionId))
              transactionScope.Complete();
            saveResult.Id = appTransactionId;
          }
        }
        if (saveResult.IsSuccessful)
          saveResult.ViewModel = (object) this.FetchIssueRegulatoryCheckListModelContainer(appTransactionId);
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private RegulatoryCheckListViewModelContainer FetchIssueRegulatoryCheckListModelContainer(
      long appTransactionId)
    {
      IssueRegulatoryCheckList issueRegulatoryCheckList = this.IssueRepository.FetchIssueRegulatoryCheckList(appTransactionId);
      if (!string.IsNullOrEmpty(issueRegulatoryCheckList.IssueDetailCheckList.CommaSeperatedStateID))
        issueRegulatoryCheckList.IssueDetailCheckList.IssueStatus = ((IEnumerable<string>) issueRegulatoryCheckList.IssueDetailCheckList.CommaSeperatedStateID.Split(new string[1]
        {
          ","
        }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
      else
        issueRegulatoryCheckList.IssueDetailCheckList.IssueStatus = new List<long>();
      return this.GetViewModelFromDataModel(issueRegulatoryCheckList);
    }

    public RegulatoryCheckListViewModelContainer GetViewModelFromDataModel(
      IssueRegulatoryCheckList issueRegulatoryCheckList)
    {
      int num = -32;
      RegulatoryCheckListViewModelContainer regulatoryCheckListContainer = new RegulatoryCheckListViewModelContainer();
      regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel = this.GetissudeDetailRegulatoryCheckList(issueRegulatoryCheckList.IssueDetailCheckList);
      regulatoryCheckListContainer.MunicipalAdvisorViewModel = this.GetMunicipalAdvisorViewModel(issueRegulatoryCheckList.MunicipalAdvisorRegCheckList);
      regulatoryCheckListContainer.Rule15c212ViewModel = this.GetRule15c212ViewModel(issueRegulatoryCheckList.Rule15c212RegCheckList);
      regulatoryCheckListContainer.RuleG17G23ViewModel = this.GetRuleG17G23ViewModel(issueRegulatoryCheckList.RuleG17G23ResulatoryCheckList);
      regulatoryCheckListContainer.RuleG34cViewModel = this.GetRuleG34cViewModel(issueRegulatoryCheckList.RuleG34cRegulatoryCheckList);
      regulatoryCheckListContainer.RuleG32ViewModel = this.GetRuleG32ViewModel(issueRegulatoryCheckList.RuleG32RegulatoryCheckList);
      regulatoryCheckListContainer.ExpensesViewModel = this.GetExpensesRegulatoryCheckListViewModel(issueRegulatoryCheckList.ExpenseRegulatoryCheckList);
      regulatoryCheckListContainer.RegulatoryPnLViewModel = this.GetPnLRegulatoryCheckListViewModel(issueRegulatoryCheckList.RegulatoryPnLCheckList);
      regulatoryCheckListContainer.DisclosureDiligenceRegChecklistViewModel = this.GetDisclosureDiligenceRegChecklistViewModel(issueRegulatoryCheckList.DisclosureDiligenceRegChecklist);
      regulatoryCheckListContainer.ClientMAExemptionDetail = issueRegulatoryCheckList.ClientMAExemptionDetail;
      if (issueRegulatoryCheckList.IssueDetailCheckList.IssueStatus != null && issueRegulatoryCheckList.IssueDetailCheckList.IssueStatus.Count > 0)
      {
        this.rcIssueStatusList = issueRegulatoryCheckList.IssueDetailCheckList.IssueStatus;
        this.rcIssueCurrentStatus = this.rcIssueStatusList.ConvertAll<IssueEnums.IssueStatus>((Converter<long, IssueEnums.IssueStatus>) (s => (IssueEnums.IssueStatus) s)).ToList<IssueEnums.IssueStatus>();
      }
      else
        this.rcIssueStatusList = new List<long>();
      this.SetRegulatoryPermissions(regulatoryCheckListContainer, (long) num);
      return regulatoryCheckListContainer;
    }

    private IssueRegulatoryCheckListViewModel GetissudeDetailRegulatoryCheckList(
      IssueDetailCheckList issueRegulatoryCheckListViewModel)
    {
      return new IssueRegulatoryCheckListViewModel()
      {
        IssuerName = issueRegulatoryCheckListViewModel.BorrowerName != null ? issueRegulatoryCheckListViewModel.IssuerName + " / " + issueRegulatoryCheckListViewModel.BorrowerName : issueRegulatoryCheckListViewModel.IssuerName,
        JobNumber = issueRegulatoryCheckListViewModel.JobNumber,
        IssueName = issueRegulatoryCheckListViewModel.IssueName,
        FirmRoleName = issueRegulatoryCheckListViewModel.FirmRoleName,
        PricingDate = issueRegulatoryCheckListViewModel.PricingDate,
        ActualAwardDateTime = issueRegulatoryCheckListViewModel.ActualAwardDateTime,
        SettlementDate = issueRegulatoryCheckListViewModel.SettlementDate,
        LeadMSBanker = issueRegulatoryCheckListViewModel.LeadMSBanker,
        SupportMSBanker = issueRegulatoryCheckListViewModel.SupportMSBanker,
        AppTransactionID = issueRegulatoryCheckListViewModel.AppTransactionID,
        RoleSentDate = issueRegulatoryCheckListViewModel.RoleSentDate,
        RoleAckDate = issueRegulatoryCheckListViewModel.RoleAckDate,
        ConflictSentDate = issueRegulatoryCheckListViewModel.ConflictSentDate,
        ConflictAckDate = issueRegulatoryCheckListViewModel.ConflictAckDate,
        RoleDisclosureSentDate = issueRegulatoryCheckListViewModel.RoleDisclosureSentDate,
        RoleDisclosureAckdate = issueRegulatoryCheckListViewModel.RoleDisclosureAckdate,
        StructureLetterSentDate = issueRegulatoryCheckListViewModel.StructureLetterSentDate,
        StructureLetterAckdate = issueRegulatoryCheckListViewModel.StructureLetterAckdate,
        FinancialAdvisor = issueRegulatoryCheckListViewModel.FinancialAdvisor,
        IsViewOnly = issueRegulatoryCheckListViewModel.IsViewOnly,
        CanSaveRegulatoryChecklist = issueRegulatoryCheckListViewModel.CanSaveRegulatoryChecklist,
        CannotGenerateRegulatoryChecklist = issueRegulatoryCheckListViewModel.CannotGenerateRegulatoryChecklist,
        LeadBanker = issueRegulatoryCheckListViewModel.LeadBanker,
        SupervisoryPrincipal = issueRegulatoryCheckListViewModel.SupervisoryPrincipal,
        LeadBankerApprovalDate = issueRegulatoryCheckListViewModel.LeadBankerApprovalDate,
        SPApprovalDate = issueRegulatoryCheckListViewModel.SPApprovalDate,
        CommaSeperatedStateID = issueRegulatoryCheckListViewModel.CommaSeperatedStateID,
        IssueStatus = issueRegulatoryCheckListViewModel.IssueStatus,
        FirmRole = issueRegulatoryCheckListViewModel.FirmRole,
        DealType = issueRegulatoryCheckListViewModel.DealType,
        DealTypeName = issueRegulatoryCheckListViewModel.DealTypeName
      };
    }

    private MunicipalAdvisorViewModel GetMunicipalAdvisorViewModel(
      MunicipalAdvisorRegCheckList municipalAdvisorRegCheckList)
    {
      if (municipalAdvisorRegCheckList == null)
        return new MunicipalAdvisorViewModel();
      return new MunicipalAdvisorViewModel()
      {
        WasRFP = municipalAdvisorRegCheckList.WasRFP,
        IsRegisteredMunicipalAdvisor = municipalAdvisorRegCheckList.IsRegisteredMunicipalAdvisor,
        IsIRMACertificationReceived = municipalAdvisorRegCheckList.IsIRMACertificationReceived,
        IRMACertificationDate = municipalAdvisorRegCheckList.IRMACertificationDate,
        IRMACertificationExpiryDate = municipalAdvisorRegCheckList.IRMACertificationExpiryDate,
        IsIRMAReprentativeSentToClientAndIssuer = municipalAdvisorRegCheckList.IsIRMAReprentativeSentToClientAndIssuer,
        IRMAPresentationDate = municipalAdvisorRegCheckList.IRMAPresentationDate,
        IsIRMAPresentationCopyRetained = municipalAdvisorRegCheckList.IsIRMAPresentationCopyRetained,
        ReasonForNoCopyRetained = municipalAdvisorRegCheckList.ReasonForNoCopyRetained,
        UnderWriterOrRemarketingAgentMethod = municipalAdvisorRegCheckList.UnderWriterOrRemarketingAgentMethod,
        EngagementDate = municipalAdvisorRegCheckList.EngagementDate,
        IssuerID = municipalAdvisorRegCheckList.IssuerID,
        EvidenceOfEngagement = municipalAdvisorRegCheckList.EvidenceOfEngagement,
        AppTransactionID = municipalAdvisorRegCheckList.AppTransactionID,
        IRMANotPerfect = municipalAdvisorRegCheckList.IRMANotPerfect,
        EarlistDateOfEngagement = municipalAdvisorRegCheckList.EarlistDateOfEngagement,
        FinancialAdvisor = municipalAdvisorRegCheckList.FinancialAdvisor
      };
    }

    private Rule15c212ViewModel GetRule15c212ViewModel(
      Rule15c212RegCheckList rule15c212RegCheckList)
    {
      if (rule15c212RegCheckList == null)
        return new Rule15c212ViewModel();
      return new Rule15c212ViewModel()
      {
        IsObtainedAndReviwedStatement = rule15c212RegCheckList.IsObtainedAndReviwedStatement,
        TypeOfDoc = rule15c212RegCheckList.TypeOfDoc,
        DateReceived = rule15c212RegCheckList.DateReceived,
        DateReviewed = rule15c212RegCheckList.DateReviewed,
        MethodDocDeemedFinal = rule15c212RegCheckList.MethodDocDeemedFinal,
        DateDocDeemedFinal = rule15c212RegCheckList.DateDocDeemedFinal,
        ReasonForNotObtainingOrReview = rule15c212RegCheckList.ReasonForNotObtainingOrReview,
        HasMeetAdoptedGuideLines = rule15c212RegCheckList.HasMeetAdoptedGuideLines,
        ReasonForNotAdoptingGuideLines = rule15c212RegCheckList.ReasonForNotAdoptingGuideLines,
        WasOfficialDocAmended = rule15c212RegCheckList.WasOfficialDocAmended,
        DocAmendedDate = rule15c212RegCheckList.DocAmendedDate,
        IsSlaMeet = rule15c212RegCheckList.IsSlaMeet,
        IssuerAndObligorCovenantMade = rule15c212RegCheckList.IssuerAndObligorCovenantMade,
        SlaViolationReason = rule15c212RegCheckList.SlaViolationReason,
        IsDilegenceReviewConducted = rule15c212RegCheckList.IsDilegenceReviewConducted,
        IsDilegenceCallOrMeeting = rule15c212RegCheckList.IsDilegenceCallOrMeeting,
        DilegenceMeetingDate = rule15c212RegCheckList.DilegenceMeetingDate,
        DilegenceReviewMethod = rule15c212RegCheckList.DilegenceReviewMethod,
        DidOutSideCounselAssisted = rule15c212RegCheckList.DidOutSideCounselAssisted,
        ReasonForNoAssistence = rule15c212RegCheckList.ReasonForNoAssistence,
        IsIssuerAndObligorAreInAggrement = rule15c212RegCheckList.IsIssuerAndObligorAreInAggrement,
        IssuerAndObligorAggrementPlace = rule15c212RegCheckList.IssuerAndObligorAggrementPlace,
        IssuerAndObligorNonAggrementReason = rule15c212RegCheckList.IssuerAndObligorNonAggrementReason,
        IsReviewedEMMAAndNRMSIR = rule15c212RegCheckList.IsReviewedEMMAAndNRMSIR,
        DidUnderWriterAssisted = rule15c212RegCheckList.DidUnderWriterAssisted,
        EMMAReviewDate = rule15c212RegCheckList.EMMAReviewDate,
        IsIssuerAndObligorCompliance = rule15c212RegCheckList.IsIssuerAndObligorCompliance,
        IncidentOfNonCompliance = rule15c212RegCheckList.IncidentOfNonCompliance,
        WasLegalAndComplianceConsulted = rule15c212RegCheckList.WasLegalAndComplianceConsulted,
        LegalAndComplianceDate = rule15c212RegCheckList.LegalAndComplianceDate,
        ReasonForNoLegalConsultaion = rule15c212RegCheckList.ReasonForNoLegalConsultaion,
        WasCDAFindingsSatifactory = rule15c212RegCheckList.WasCDAFindingsSatifactory,
        CDAFindingsUnSatisfactoryReason = rule15c212RegCheckList.CDAFindingsUnSatisfactoryReason,
        WasLegalAndComplianceConsultedReason = rule15c212RegCheckList.WasLegalAndComplianceConsultedReason
      };
    }

    private RuleG17G23ViewModel GetRuleG17G23ViewModel(
      RuleG17G23ResulatoryCheckList ruleG17G23ResulatoryCheckList)
    {
      if (ruleG17G23ResulatoryCheckList == null)
        return new RuleG17G23ViewModel();
      return new RuleG17G23ViewModel()
      {
        IsDeliveredToIssuer = ruleG17G23ResulatoryCheckList.IsDeliveredToIssuer,
        DeliveryDateToIssuer = ruleG17G23ResulatoryCheckList.DeliveryDateToIssuer,
        DeliveryDateToObligor = ruleG17G23ResulatoryCheckList.DeliveryDateToObligor,
        IsDeliveredToObligor = ruleG17G23ResulatoryCheckList.IsDeliveredToObligor,
        RoleDisclosureSender = ruleG17G23ResulatoryCheckList.RoleDisclosureSender,
        RoleDisclosureMethodName = ruleG17G23ResulatoryCheckList.RoleDisclosureMethodName,
        RoleDisclosureReceipentName = ruleG17G23ResulatoryCheckList.RoleDisclosureReceipentName,
        IsRoleDisclosureLetterCopyRetained = ruleG17G23ResulatoryCheckList.IsRoleDisclosureLetterCopyRetained,
        ReasonForNonRetainingCopy = ruleG17G23ResulatoryCheckList.ReasonForNonRetainingCopy,
        IsRoleDisclosureAckReceived = ruleG17G23ResulatoryCheckList.IsRoleDisclosureAckReceived,
        AckReceivedDate = ruleG17G23ResulatoryCheckList.AckReceivedDate,
        AckExecuterName = ruleG17G23ResulatoryCheckList.AckExecuterName,
        AckMethodForRoleDisclosure = ruleG17G23ResulatoryCheckList.AckMethodForRoleDisclosure,
        IsCopyRetainedForRoleDisclosureAck = ruleG17G23ResulatoryCheckList.IsCopyRetainedForRoleDisclosureAck,
        ReasonForNotGettingAckForRoleDisclosre = ruleG17G23ResulatoryCheckList.ReasonForNotGettingAckForRoleDisclosre,
        IsConflictDisclosureLetterDeliveredToIssuer = ruleG17G23ResulatoryCheckList.IsConflictDisclosureLetterDeliveredToIssuer,
        IsConflictDisclosureLetterDeliveredToObligor = ruleG17G23ResulatoryCheckList.IsConflictDisclosureLetterDeliveredToObligor,
        ConflictDisclosreLetterDeliveryDateToIssuer = ruleG17G23ResulatoryCheckList.ConflictDisclosreLetterDeliveryDateToIssuer,
        ReasonForNotRetaingCopyOfConflictDisclosure = ruleG17G23ResulatoryCheckList.ReasonForNotRetaingCopyOfConflictDisclosure,
        IsAckReceivedOfConflictDisclosure = ruleG17G23ResulatoryCheckList.IsAckReceivedOfConflictDisclosure,
        AckG17ReceivedDate = ruleG17G23ResulatoryCheckList.AckG17ReceivedDate,
        AckConflictDisclosureExecuter = ruleG17G23ResulatoryCheckList.AckConflictDisclosureExecuter,
        AckConflictMethod = ruleG17G23ResulatoryCheckList.AckConflictMethod,
        IsAckCopyRetainedConflictDisclosure = ruleG17G23ResulatoryCheckList.IsAckCopyRetainedConflictDisclosure,
        IsG17StructureAndRoleLetterDeliveredObligor = ruleG17G23ResulatoryCheckList.IsG17StructureAndRoleLetterDeliveredObligor,
        G17SturectureAndRoleLetterDateIssuer = ruleG17G23ResulatoryCheckList.G17SturectureAndRoleLetterDateIssuer,
        G17SturectureAndRoleLetterDateObligor = ruleG17G23ResulatoryCheckList.G17SturectureAndRoleLetterDateObligor,
        G17SturectureAndRoleLetterSender = ruleG17G23ResulatoryCheckList.G17SturectureAndRoleLetterSender,
        G17StructureAndRoleLetterMethod = ruleG17G23ResulatoryCheckList.G17StructureAndRoleLetterMethod,
        G17StructureAndRoleLetterReceipent = ruleG17G23ResulatoryCheckList.G17StructureAndRoleLetterReceipent,
        IsCopyRetainedForRoleDisclosure = ruleG17G23ResulatoryCheckList.IsCopyRetainedForRoleDisclosure,
        ReasonForNotRetaingCopyOfRoleAndSturucture = ruleG17G23ResulatoryCheckList.ReasonForNotRetaingCopyOfRoleAndSturucture,
        IsAckG17RoleAndStuructureLetterReceived = ruleG17G23ResulatoryCheckList.IsAckG17RoleAndStuructureLetterReceived,
        AckG17RoleAndStructureLetterDate = ruleG17G23ResulatoryCheckList.AckG17RoleAndStructureLetterDate,
        AckG17RoleAndStructureExecuter = ruleG17G23ResulatoryCheckList.AckG17RoleAndStructureExecuter,
        AckG17RoleAndStructureMethod = ruleG17G23ResulatoryCheckList.AckG17RoleAndStructureMethod,
        IsCopyRetainedG17RoleAndStructureAck = ruleG17G23ResulatoryCheckList.IsCopyRetainedG17RoleAndStructureAck,
        ReasonForNoAckG17RoleAndStructure = ruleG17G23ResulatoryCheckList.ReasonForNoAckG17RoleAndStructure,
        isEMMAReviewed = ruleG17G23ResulatoryCheckList.isEMMAReviewed,
        IsUnderWriterAssistedEMMAReview = ruleG17G23ResulatoryCheckList.IsUnderWriterAssistedEMMAReview,
        UnderWriterReviewDate = ruleG17G23ResulatoryCheckList.UnderWriterReviewDate,
        IsUnderWriterPriceValid = ruleG17G23ResulatoryCheckList.IsUnderWriterPriceValid,
        IsUnderWriterCertificateAmended = ruleG17G23ResulatoryCheckList.IsUnderWriterCertificateAmended,
        IslegalAndComplianceConsulted = ruleG17G23ResulatoryCheckList.IslegalAndComplianceConsulted,
        LegalAndComplianceConsultedDate = ruleG17G23ResulatoryCheckList.LegalAndComplianceConsultedDate,
        ReasonForNoEMMAReview = ruleG17G23ResulatoryCheckList.ReasonForNoEMMAReview,
        isFirmPayingToMSA = ruleG17G23ResulatoryCheckList.isFirmPayingToMSA,
        IsMSAReviewed = ruleG17G23ResulatoryCheckList.IsMSAReviewed,
        ReasonForNOMSAReview = ruleG17G23ResulatoryCheckList.ReasonForNOMSAReview,
        MSAName = ruleG17G23ResulatoryCheckList.MSAName,
        MSACertification = ruleG17G23ResulatoryCheckList.MSACertification,
        AppTransactionID = ruleG17G23ResulatoryCheckList.AppTransactionID,
        RoleLetterExplain = ruleG17G23ResulatoryCheckList.RoleLetterExplain,
        ConflictLetterExplain = ruleG17G23ResulatoryCheckList.ConflictLetterExplain,
        RoleDisclosureLetterExplain = ruleG17G23ResulatoryCheckList.RoleDisclosureLetterExplain,
        StructureExplain = ruleG17G23ResulatoryCheckList.StructureExplain
      };
    }

    private RuleG34cViewModel GetRuleG34cViewModel(
      RuleG34cRegulatoryCheckList ruleG34cRegulatoryCheckList)
    {
      if (ruleG34cRegulatoryCheckList == null)
        return new RuleG34cViewModel();
      return new RuleG34cViewModel()
      {
        IsLiquidyCommentsPosted = ruleG34cRegulatoryCheckList.IsLiquidyCommentsPosted,
        DocumentPostedDate = ruleG34cRegulatoryCheckList.DocumentPostedDate,
        ReasonForNoPosting = ruleG34cRegulatoryCheckList.ReasonForNoPosting,
        AppTransactionID = ruleG34cRegulatoryCheckList.AppTransactionID
      };
    }

    private RuleG32ViewModel GetRuleG32ViewModel(
      RuleG32RegulatoryCheckList ruleG32RegulatoryCheckList)
    {
      if (ruleG32RegulatoryCheckList == null)
        return new RuleG32ViewModel();
      return new RuleG32ViewModel()
      {
        IsOfficialStatementPostedToEMMA = ruleG32RegulatoryCheckList.IsOfficialStatementPostedToEMMA,
        OfficialStatementDate = ruleG32RegulatoryCheckList.OfficialStatementDate,
        ReasonForNoPosting = ruleG32RegulatoryCheckList.ReasonForNoPosting,
        IsEscrowfiledWithMSRB = ruleG32RegulatoryCheckList.IsEscrowfiledWithMSRB,
        AggrementPostedDate = ruleG32RegulatoryCheckList.AggrementPostedDate,
        ReasonForNoEscrowAggrement = ruleG32RegulatoryCheckList.ReasonForNoEscrowAggrement,
        AppTransactionID = ruleG32RegulatoryCheckList.AppTransactionID,
        G32SubmissionDateTimeZone = ruleG32RegulatoryCheckList.G32SubmissionDateTimeZone
      };
    }

    private ExpensesViewModel GetExpensesRegulatoryCheckListViewModel(
      ExpenseRegulatoryCheckList expenseRegulatoryCheckList)
    {
      if (expenseRegulatoryCheckList == null)
        return new ExpensesViewModel();
      return new ExpensesViewModel()
      {
        IsSoleManaged = expenseRegulatoryCheckList.IsSoleManaged,
        LegalFeesNotes = expenseRegulatoryCheckList.LegalFeesNotes,
        SyndicateNotes = expenseRegulatoryCheckList.SyndicateNotes,
        DTCChargesNotes = expenseRegulatoryCheckList.DTCChargesNotes,
        IPREONotes = expenseRegulatoryCheckList.IPREONotes,
        CUSIPFeeNotes = expenseRegulatoryCheckList.CUSIPFeeNotes,
        MSRBandStateSpecificFeeNotes = expenseRegulatoryCheckList.MSRBandStateSpecificFeeNotes,
        AgentNotes = expenseRegulatoryCheckList.AgentNotes,
        TravelNotes = expenseRegulatoryCheckList.TravelNotes,
        MealsClientEntertainNotes = expenseRegulatoryCheckList.MealsClientEntertainNotes,
        InternetNotes = expenseRegulatoryCheckList.InternetNotes,
        PrintingNotes = expenseRegulatoryCheckList.PrintingNotes,
        MailDeliveryExpensesNotes = expenseRegulatoryCheckList.MailDeliveryExpensesNotes,
        MarketingNotes = expenseRegulatoryCheckList.MarketingNotes,
        CoManagerExpensesNotes = expenseRegulatoryCheckList.CoManagerExpensesNotes,
        OtherNotes = expenseRegulatoryCheckList.OtherNotes,
        LessExpenseReimbursementNotes = expenseRegulatoryCheckList.LessExpenseReimbursementNotes,
        TotalExpensesNotes = expenseRegulatoryCheckList.TotalExpensesNotes,
        TransactionExpensesNotes = expenseRegulatoryCheckList.TransactionExpensesNotes,
        DealMementosNotes = expenseRegulatoryCheckList.DealMementosNotes,
        StateSpecificFeeNotes = expenseRegulatoryCheckList.StateSpecificFeeNotes,
        AreExpensesAuthorized = expenseRegulatoryCheckList.AreExpensesAuthorized,
        ReasonForNonAutorization = expenseRegulatoryCheckList.ReasonForNonAutorization,
        IsDocAttachedToCheckList = expenseRegulatoryCheckList.IsDocAttachedToCheckList,
        ReasonForNotAttachingCheckList = expenseRegulatoryCheckList.ReasonForNotAttachingCheckList,
        Discripiencies = expenseRegulatoryCheckList.Discripiencies,
        LeadMSBanker = expenseRegulatoryCheckList.LeadMSBanker,
        LeadMSBankerSignDate = expenseRegulatoryCheckList.LeadMSBankerSignDate,
        SeriesSupervisor = expenseRegulatoryCheckList.SeriesSupervisor,
        SeriesSupervisorDate = expenseRegulatoryCheckList.SeriesSupervisorDate,
        AppTransactionID = expenseRegulatoryCheckList.ExpensesRegCheckListID
      };
    }

    private RegulatoryPnLViewModel GetPnLRegulatoryCheckListViewModel(
      RegulatoryPnLChecklist pnlRegulatoryCheckList)
    {
      if (pnlRegulatoryCheckList == null)
        return new RegulatoryPnLViewModel();
      return new RegulatoryPnLViewModel()
      {
        ActualSyndicate = pnlRegulatoryCheckList.ActualSyndicate,
        ProjectSyndicate = pnlRegulatoryCheckList.ProjectSyndicate,
        ActualLegal = pnlRegulatoryCheckList.ActualLegal,
        ProjectLegal = pnlRegulatoryCheckList.ProjectLegal,
        ActualDTCCharges = pnlRegulatoryCheckList.ActualDTCCharges,
        ProjectDTCCharges = pnlRegulatoryCheckList.ProjectDTCCharges,
        ActualIPREO = pnlRegulatoryCheckList.ActualIPREO,
        ProjectIPREO = pnlRegulatoryCheckList.ProjectIPREO,
        ActualCUSIPFees = pnlRegulatoryCheckList.ActualCUSIPFees,
        ProjectCUSIPFees = pnlRegulatoryCheckList.ProjectCUSIPFees,
        ActualMSRBAndStateSpecificFee = pnlRegulatoryCheckList.ActualMSRBAndStateSpecificFee,
        ProjectMSRBAndStateSpecificFee = pnlRegulatoryCheckList.ProjectMSRBAndStateSpecificFee,
        ActualCalcAgentAnalysis = pnlRegulatoryCheckList.ActualCalcAgentAnalysis,
        ProjectCalcAgentAnalysis = pnlRegulatoryCheckList.ProjectCalcAgentAnalysis,
        ActualTravelExpenses = pnlRegulatoryCheckList.ActualTravelExpenses,
        ProjectTravelExpenses = pnlRegulatoryCheckList.ProjectTravelExpenses,
        ActualMealsClientEntertaing = pnlRegulatoryCheckList.ActualMealsClientEntertaing,
        ProjectMealsClientEntertaing = pnlRegulatoryCheckList.ProjectMealsClientEntertaing,
        ActualInternetRoadShow = pnlRegulatoryCheckList.ActualInternetRoadShow,
        ProjectInternetRoadShow = pnlRegulatoryCheckList.ProjectInternetRoadShow,
        ActualPrintingCharges = pnlRegulatoryCheckList.ActualPrintingCharges,
        ProjectPrintingCharges = pnlRegulatoryCheckList.ProjectPrintingCharges,
        ActualDeliveryExpenses = pnlRegulatoryCheckList.ActualDeliveryExpenses,
        ProjectDeliveryExpenses = pnlRegulatoryCheckList.ProjectDeliveryExpenses,
        ActualMarketing = pnlRegulatoryCheckList.ActualMarketing,
        ProjectMarketing = pnlRegulatoryCheckList.ProjectMarketing,
        ActualCoManagerExpenses = pnlRegulatoryCheckList.ActualCoManagerExpenses,
        ProjectCoManagerExpenses = pnlRegulatoryCheckList.ProjectCoManagerExpenses,
        ActualOtherExpenses = pnlRegulatoryCheckList.ActualOtherExpenses,
        ProjectOtherExpenses = pnlRegulatoryCheckList.ProjectOtherExpenses,
        ActualLessExpenseReimbursement = pnlRegulatoryCheckList.ActualLessExpenseReimbursement,
        ProjectLessExpenseReimbursement = pnlRegulatoryCheckList.ProjectLessExpenseReimbursement,
        ActualTotalExpenses = pnlRegulatoryCheckList.ActualTotalExpenses,
        ProjectTotalExpenses = pnlRegulatoryCheckList.ProjectTotalExpenses,
        ActualTransactionExpenses = pnlRegulatoryCheckList.ActualTransactionExpenses,
        ProjectTransactionExpenses = pnlRegulatoryCheckList.ProjectTransactionExpenses,
        ProjectDealMementos = pnlRegulatoryCheckList.ProjectDealMementos,
        ActualDealMementos = pnlRegulatoryCheckList.ActualDealMementos,
        ProjectStateSpecificFee = pnlRegulatoryCheckList.ProjectStateSpecificFee,
        ActualStateSpecificFee = pnlRegulatoryCheckList.ActualStateSpecificFee
      };
    }

    private DisclosureDiligenceRegChecklistViewModel GetDisclosureDiligenceRegChecklistViewModel(
      DisclosureDiligenceRegChecklist disclosureDiligenceRegChecklist)
    {
      if (disclosureDiligenceRegChecklist == null)
        return new DisclosureDiligenceRegChecklistViewModel();
      return new DisclosureDiligenceRegChecklistViewModel()
      {
        DisclosureDiligenceRegCheckListID = disclosureDiligenceRegChecklist.DisclosureDiligenceRegCheckListID,
        AppTransactionID = disclosureDiligenceRegChecklist.AppTransactionID,
        IsObtainedAndReviwedFinalDoc = disclosureDiligenceRegChecklist.IsObtainedAndReviwedFinalDoc,
        TypeOfDocument = disclosureDiligenceRegChecklist.TypeOfDocument,
        DateReceived = disclosureDiligenceRegChecklist.DateReceived,
        DateReviewed = disclosureDiligenceRegChecklist.DateReviewed,
        ReasonForNotObtainingOrReviewFinalDoc = disclosureDiligenceRegChecklist.ReasonForNotObtainingOrReviewFinalDoc,
        WasDisclosureDocumentAmended = disclosureDiligenceRegChecklist.WasDisclosureDocumentAmended,
        DocumentAmendedDate = disclosureDiligenceRegChecklist.DocumentAmendedDate,
        IsDueDilegenceReviewConducted = disclosureDiligenceRegChecklist.IsDueDilegenceReviewConducted,
        IsDueDilegenceCallOrMeeting = disclosureDiligenceRegChecklist.IsDueDilegenceCallOrMeeting,
        DueDilegenceMeetingDate = disclosureDiligenceRegChecklist.DueDilegenceMeetingDate,
        DueDilegenceReviewMethod = disclosureDiligenceRegChecklist.DueDilegenceReviewMethod,
        DidOutSideCounselDiligence = disclosureDiligenceRegChecklist.DidOutSideCounselDiligence,
        ReasonForNoDueDiligence = disclosureDiligenceRegChecklist.ReasonForNoDueDiligence,
        HasIssuerObligorCovenanted = disclosureDiligenceRegChecklist.HasIssuerObligorCovenanted,
        IssuerObligorCovenanted = disclosureDiligenceRegChecklist.IssuerObligorCovenanted,
        ReasonForNoIssuerObligorCovenanted = disclosureDiligenceRegChecklist.ReasonForNoIssuerObligorCovenanted
      };
    }

    public SaveResult SaveRegulatoryCheckListDocument(
      long appTransactionID,
      string ReqChecklistType)
    {
      try
      {
        bool uploadResult = false;
        string empty = string.Empty;
        ExportResult regulatoryCheckListReport = this.ExportRegulatoryCheckList("pdf", appTransactionID, ReqChecklistType);
        this.SaveRegulatoryRequirementChecklistInRepository(appTransactionID, regulatoryCheckListReport, out uploadResult);
        if (!uploadResult)
          return SaveResult.Failure("There was an error in generating regulatory requirement checklist.");
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.AuditTrailRepository.Save(new AuditTrail()
          {
            AppTransactionID = new long?(appTransactionID),
            Entity = "Issue",
            What = "Transaction Regulatory Requirement Checklist published"
          });
          transactionScope.Complete();
          return SaveResult.Success;
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public ExportResult ExportRegulatoryCheckList(
      string type,
      long AppTransactionId,
      string ReqChecklistType)
    {
      try
      {
        string reportPath = string.Empty;
        IDataReader regulatoryCheckListReader = this.IssueRepository.GetIssueRegulatoryCheckListReader(AppTransactionId);
        DataTable table1 = new DataTable();
        table1.TableName = "IssueDetail";
        DataTable table2 = new DataTable();
        table2.TableName = "MunicipalAdvisorRegCheckList";
        DataTable table3 = new DataTable();
        table3.TableName = "Rule15c12RegCheckList";
        DataTable table4 = new DataTable();
        table4.TableName = "RuleG17G23RegCheckList";
        DataTable table5 = new DataTable();
        table5.TableName = "RuleG32RegCheckList";
        DataTable table6 = new DataTable();
        table6.TableName = "RuleG34cRegCheckList";
        DataTable table7 = new DataTable();
        table7.TableName = "ExpensesRegCheckList";
        DataTable table8 = new DataTable();
        table8.TableName = "RegulatoryPnLViewModel";
        DataTable table9 = new DataTable();
        table9.TableName = "DisclosureDiligenceRegChecklist";
        DataTable table10 = new DataTable();
        table10.TableName = "RegClientIRMA";
        this.pipelineDS.Tables.Add(table1);
        this.pipelineDS.Tables.Add(table2);
        this.pipelineDS.Tables.Add(table3);
        this.pipelineDS.Tables.Add(table4);
        this.pipelineDS.Tables.Add(table5);
        this.pipelineDS.Tables.Add(table6);
        this.pipelineDS.Tables.Add(table7);
        this.pipelineDS.Tables.Add(table8);
        this.pipelineDS.Tables.Add(table9);
        this.pipelineDS.Tables.Add(table10);
        this.pipelineDS.Load(regulatoryCheckListReader, LoadOption.OverwriteChanges, table1, table2, table3, table4, table5, table6, table7, table8, table9, table10);
        if (ReqChecklistType == "Main Checklist")
          reportPath = this.GetMainChecklistReportPath();
        else if (ReqChecklistType == "Corporate Deal Checklist")
          reportPath = this.GetCorporateDealChecklistReportPath();
        else if (ReqChecklistType == "Remarketing Takeover checklist")
          reportPath = this.GetRemarketingTakeoverChecklistReportPath();
        return new ReportExporter().Export(reportPath, "pdf", "RegulatoryRequirementChecklist", (object) this.pipelineDS);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return (ExportResult) null;
      }
    }

    public string GetMainChecklistReportPath() => "~/_layouts/iMPACT/Reports/RegulatoryRequirmentsChecklistMain.rdlc";

    public string GetCorporateDealChecklistReportPath() => "~/_layouts/iMPACT/Reports/CorporateRegChecklist.rdlc";

    public string GetRemarketingTakeoverChecklistReportPath() => "~/_layouts/iMPACT/Reports/RemarketingTakeOverRegChecklist.rdlc";

    public IssueMuccDetailContainer GetMuccTemplateDetailsById(
      long issueId,
      long entityId)
    {
      try
      {
        if (!this.HasUIPermissionForEntity(-32L, issueId, "MUCC Checklist", "View"))
        {
          IssueMuccDetailContainer muccDetailContainer = new IssueMuccDetailContainer();
          muccDetailContainer.ErrorMessage = "401";
          return muccDetailContainer;
        }
        Mucc muccDetails = this.FetchMuccByKey(issueId, entityId);
        if (!string.IsNullOrEmpty(muccDetails.MuccIssueDetail.CommaSeperatedStateID))
          muccDetails.MuccIssueDetail.IssueStatus = ((IEnumerable<string>) muccDetails.MuccIssueDetail.CommaSeperatedStateID.Split(new string[1]
          {
            ","
          }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        else
          muccDetails.MuccIssueDetail.IssueStatus = new List<long>();
        return this.GetMuccViewModel(muccDetails, entityId);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueMuccDetailContainer muccDetailContainer = new IssueMuccDetailContainer();
        muccDetailContainer.ErrorMessage = "An error occurred while fetching the data.";
        return muccDetailContainer;
      }
    }

    private Mucc FetchMuccByKey(long issueId, long entityId) => this.IssueRepository.FetchMuccDetailsByKey(issueId, entityId);

    public IssueMuccDetailContainer GetMuccViewModel(
      Mucc muccDetails,
      long entityId)
    {
      try
      {
        long appTransactionId = muccDetails.MuccDetail.AppTransactionID;
        IssueMuccDetailContainer muccContainer = new IssueMuccDetailContainer(muccDetails);
        if (muccDetails.MuccIssueDetail.IssueStatus != null && muccDetails.MuccIssueDetail.IssueStatus.Count > 0)
        {
          this.muccIssueStatusList = muccDetails.MuccIssueDetail.IssueStatus;
          this.muccIssueCurrentStatus = this.muccIssueStatusList.ConvertAll<IssueEnums.IssueStatus>((Converter<long, IssueEnums.IssueStatus>) (s => (IssueEnums.IssueStatus) s)).ToList<IssueEnums.IssueStatus>();
        }
        else
          this.muccIssueStatusList = new List<long>();
        this.SetMuccPermissions(muccContainer, entityId);
        return muccContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueMuccDetailContainer muccDetailContainer = new IssueMuccDetailContainer();
        muccDetailContainer.ErrorMessage = "An error occurred while fetching the data.";
        return muccDetailContainer;
      }
    }

    public SaveResult SaveMucc(IssueMuccDetailContainer muccContainer)
    {
      try
      {
        this.GetSafeObject<IssueMuccDetailContainer>(muccContainer);
        SaveResult saveResult = muccContainer.MuccDetail.Validate<MuccDetailViewModel>();
        if (!saveResult.IsSuccessful || !this.ValidateMuccModel(muccContainer, ref saveResult))
          return saveResult;
        using (TransactionScope transactionScope = new TransactionScope())
        {
          long num = this.IssueRepository.SaveMucc(this.GetMuccModelFromViewModel(muccContainer));
          saveResult.Id = num;
          transactionScope.Complete();
        }
        if (saveResult.IsSuccessful)
        {
          IssueMuccDetailContainer templateDetailsById = this.GetMuccTemplateDetailsById(saveResult.Id, -32L);
          saveResult.ViewModel = (object) templateDetailsById;
        }
        return saveResult;
      }
      catch (SqlException ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return ex.State == (byte) 1 && ex.Class == (byte) 16 && ex.Number == 50000 ? SaveResult.Failure(ex.Message) : SaveResult.Failure("An error occurred while saving the data.");
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private bool ValidateMuccModel(
      IssueMuccDetailContainer muccContainer,
      ref SaveResult saveResult)
    {
      if (!string.IsNullOrEmpty(muccContainer.MuccDetail.SyndicateCompensation) && muccContainer.MuccDetail.SyndicateCompensation.Length > 256)
        saveResult.Errors.Add("MuccDetails", (object) "Syndicate Compensation field length should be less than or equal to 256 characters.");
      if (!string.IsNullOrEmpty(muccContainer.MuccDetail.IssuerBorrowerOverviewandCreditSummary) && muccContainer.MuccDetail.IssuerBorrowerOverviewandCreditSummary.Length > 4096)
        saveResult.Errors.Add("MuccDetails", (object) "Issuer/Borrower Overview and Credit Summary field length should be less than or equal to 4096 characters.");
      if (!string.IsNullOrEmpty(muccContainer.MuccDetail.KeyIssuesforMUCCConsideration) && muccContainer.MuccDetail.KeyIssuesforMUCCConsideration.Length > 4096)
        saveResult.Errors.Add("MuccDetails", (object) "Key Issues for MUCC Consideration field length should be less than or equal to 4096 characters.");
      if (!string.IsNullOrEmpty(muccContainer.MuccDetail.MaterialEventsandPotentialInvestorConcerns) && muccContainer.MuccDetail.MaterialEventsandPotentialInvestorConcerns.Length > 4096)
        saveResult.Errors.Add("MuccDetails", (object) "Material Events and Potential Investor Concerns field length should be less than or equal to 4096 characters.");
      if (!string.IsNullOrEmpty(muccContainer.MuccDetail.MorganStanleyRelationship) && muccContainer.MuccDetail.MorganStanleyRelationship.Length > 4096)
        saveResult.Errors.Add("MuccDetails", (object) "Morgan Stanley Relationship field length should be less than or equal to 4096 characters.");
      if (!string.IsNullOrEmpty(muccContainer.MuccDetail.FinancialInformation) && muccContainer.MuccDetail.FinancialInformation.Length > 4096)
        saveResult.Errors.Add("MuccDetails", (object) "Financial Information field length should be less than or equal to 4096 characters.");
      return saveResult.IsSuccessful;
    }

    private Mucc GetMuccModelFromViewModel(IssueMuccDetailContainer muccContainer) => new Mucc(this.IssueRepository)
    {
      MuccDetail = new MuccDetails()
      {
        AppTransactionID = muccContainer.MuccDetail.AppTransactionID,
        SyndicateCompensation = muccContainer.MuccDetail.SyndicateCompensation,
        MSSwapExposure = muccContainer.MuccDetail.MSSwapExposure,
        AgreedUponProceduresLetter = muccContainer.MuccDetail.AgreedUponProceduresLetter,
        StatusofDiligenceReview = muccContainer.MuccDetail.StatusofDiligenceReview,
        StatusofRegulatoryChecklist = muccContainer.MuccDetail.StatusofRegulatoryChecklist,
        LegalOptions = muccContainer.MuccDetail.LegalOptions,
        Covenants = muccContainer.MuccDetail.Covenants,
        KeyIssuesforMUCCConsideration = muccContainer.MuccDetail.KeyIssuesforMUCCConsideration,
        MorganStanleyRelationship = muccContainer.MuccDetail.MorganStanleyRelationship,
        IssuerBorrowerOverviewandCreditSummary = muccContainer.MuccDetail.IssuerBorrowerOverviewandCreditSummary,
        MaterialEventsandPotentialInvestorConcerns = muccContainer.MuccDetail.MaterialEventsandPotentialInvestorConcerns,
        FinancialInformation = muccContainer.MuccDetail.FinancialInformation,
        AdditionalFeeDetail = muccContainer.MuccDetail.AdditionalFeeDetail,
        MuccManagementFee = muccContainer.MuccDetail.MuccManagementFee,
        MuccAverageTakedown = muccContainer.MuccDetail.MuccAverageTakedown,
        MuccExpenses = muccContainer.MuccDetail.MuccExpenses
      }
    };

    private void SetMuccPermissions(IssueMuccDetailContainer muccContainer, long entityId)
    {
      string uiName = string.Empty;
      if (entityId == -32L)
        uiName = "MUCC Checklist";
      if (muccContainer.MuccIssueDetailInfo.AppTransactionID == 0L && (muccContainer.MuccIssueDetailInfo.IssueStatus == null || muccContainer.MuccIssueDetailInfo.IssueStatus.Count == 0))
      {
        muccContainer.MuccIssueDetailInfo.IssueStatus = new List<long>()
        {
          1L
        };
        if (this.muccIssueCurrentStatus == null)
          this.muccIssueCurrentStatus = new List<IssueEnums.IssueStatus>();
        this.muccIssueCurrentStatus.Add(IssueEnums.IssueStatus.Open);
      }
      IssuePresenter.MUCCEditOnlyStatus muccEditOnlyStatus = this.SetMUCCEditOnlyStatus(this.muccIssueCurrentStatus, muccContainer.MuccIssueDetailInfo.AppTransactionID, uiName);
      muccContainer.MuccDetail.IsViewOnly = !muccEditOnlyStatus.isMUCCDetailsEditable;
    }

    private void SetRegulatoryPermissions(
      RegulatoryCheckListViewModelContainer regulatoryCheckListContainer,
      long entityId)
    {
      string uiName = string.Empty;
      if (entityId == -32L)
        uiName = "Regulatory Requirement Checklist";
      if (regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.AppTransactionID == 0L && (regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.IssueStatus == null || regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.IssueStatus.Count == 0))
      {
        regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.IssueStatus = new List<long>()
        {
          1L
        };
        if (this.rcIssueCurrentStatus == null)
          this.rcIssueCurrentStatus = new List<IssueEnums.IssueStatus>();
        this.rcIssueCurrentStatus.Add(IssueEnums.IssueStatus.Open);
      }
      IssuePresenter.RegulatoryChacklistEditOnlyStatus chacklistEditOnlyStatus = this.SetRegulatoryChacklistEditOnlyStatus(this.rcIssueCurrentStatus, regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.AppTransactionID, uiName);
      regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.IsViewOnly = !chacklistEditOnlyStatus.isRegulatoryChacklistEditable;
      regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.CannotGenerateRegulatoryChecklist = !this.HasUIPermissionForEntity(-32L, regulatoryCheckListContainer.IssueRegulatoryCheckListViewModel.AppTransactionID, "Regulatory Requirement Checklist", "Publish");
    }

    private IssuePresenter.RegulatoryChacklistEditOnlyStatus SetRegulatoryChacklistEditOnlyStatus(
      List<IssueEnums.IssueStatus> issueStatusList,
      long appTransactionID,
      string uiName)
    {
      IssuePresenter.RegulatoryChacklistEditOnlyStatus chacklistEditOnlyStatus = new IssuePresenter.RegulatoryChacklistEditOnlyStatus();
      List<long> statusList = issueStatusList.ConvertAll<long>((Converter<IssueEnums.IssueStatus, long>) (s => (long) s));
      chacklistEditOnlyStatus.isRegulatoryChacklistEditable = this.IsUIEditable(appTransactionID, uiName, statusList);
      return chacklistEditOnlyStatus;
    }

    public SaveResult SaveMUCCDocument(long appTransactionID)
    {
      try
      {
        bool uploadResult = false;
        string empty = string.Empty;
        ExportResult muccPresentationReport = this.ExportMUCCPresentation("pdf", appTransactionID);
        this.SaveMUCCPresentationInRepository(appTransactionID, muccPresentationReport, out uploadResult);
        if (!uploadResult)
          return SaveResult.Failure("There was an error in generating MUCC Presentation.");
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.AuditTrailRepository.Save(new AuditTrail()
          {
            AppTransactionID = new long?(appTransactionID),
            Entity = "Issue",
            What = "Transaction MUCC Presentation published"
          });
          transactionScope.Complete();
          return SaveResult.Success;
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public ExportResult ExportMUCCPresentation(string type, long AppTransactionId)
    {
      try
      {
        IDataReader reader = this.IssueRepository.ExportMuccTemplate(AppTransactionId);
        DataTable table1 = new DataTable();
        table1.TableName = "MuccIssueDetails1";
        DataTable table2 = new DataTable();
        table2.TableName = "ds_MuccDetails";
        DataTable table3 = new DataTable();
        table3.TableName = "MuccSyndicateSturcture";
        DataTable table4 = new DataTable();
        table4.TableName = "MuccExternalPartner";
        DataTable table5 = new DataTable();
        table5.TableName = "MuccInternalPartner";
        this.pipelineDS.Tables.Add(table1);
        this.pipelineDS.Tables.Add(table2);
        this.pipelineDS.Tables.Add(table3);
        this.pipelineDS.Tables.Add(table4);
        this.pipelineDS.Tables.Add(table5);
        this.pipelineDS.Load(reader, LoadOption.OverwriteChanges, table1, table2, table3, table4, table5);
        string empty = string.Empty;
        return new ReportExporter().Export("~/_layouts/iMPACT/Reports/MuccReport.rdlc", "pdf", "MUCCPresentation", (object) this.pipelineDS);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return (ExportResult) null;
      }
    }

    public InvestmentBankingTeamViewModel getInvestmentBankingTeamByAppId(
      long AppID)
    {
      try
      {
        if (!this.HasUIPermissionForEntity(-32L, AppID, "Revenue Attribution", "View"))
        {
          InvestmentBankingTeamViewModel bankingTeamViewModel = new InvestmentBankingTeamViewModel();
          bankingTeamViewModel.InternalPartnerIsViewOnly = true;
          bankingTeamViewModel.ErrorMessage = "401";
          return bankingTeamViewModel;
        }
        List<IssueEnums.IssueStatus> issueStatusList = new List<IssueEnums.IssueStatus>();
        RevenueAttribution revenueAttribution = this.IssueRepository.FetchInvestmentBankingTeamByAppID(AppID);
        InvestmentBankingTeamViewModel bankingTeamViewModel1 = new InvestmentBankingTeamViewModel();
        bankingTeamViewModel1.IssueInvestmentBankingTeam = revenueAttribution.InternalPartner;
        bankingTeamViewModel1.IssueStatus = ((IEnumerable<string>) revenueAttribution.CommaSeperatedStateID.Split(new string[1]
        {
          ","
        }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        bankingTeamViewModel1.RevenuePercentage = revenueAttribution.RevenuePercentage;
        bankingTeamViewModel1.AttributionReviewed = revenueAttribution.AttributionReviewed;
        if (bankingTeamViewModel1.IssueInvestmentBankingTeam.Count > 0 || bankingTeamViewModel1.RevenuePercentage.Count > 0)
        {
          string uiName = "Revenue Attribution";
          List<long> statusList = bankingTeamViewModel1.IssueStatus == null ? new List<long>() : bankingTeamViewModel1.IssueStatus;
          bankingTeamViewModel1.InternalPartnerIsViewOnly = !this.IsUIEditable(AppID, uiName, statusList);
        }
        else
          bankingTeamViewModel1.InternalPartnerIsViewOnly = true;
        return bankingTeamViewModel1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        InvestmentBankingTeamViewModel bankingTeamViewModel = new InvestmentBankingTeamViewModel();
        bankingTeamViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return bankingTeamViewModel;
      }
    }

    public SaveResult SaveInvestmentBankingTeam(
      InvestmentBankingTeamViewModel investmentBankingTeam)
    {
      try
      {
        this.GetSafeObject<InvestmentBankingTeamViewModel>(investmentBankingTeam);
        SaveResult saveResult = investmentBankingTeam.Validate<InvestmentBankingTeamViewModel>();
        if (!saveResult.IsSuccessful || !this.ValidateInvestmentBankingTeamModel(investmentBankingTeam, ref saveResult))
          return saveResult;
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssueRepository.SaveInvestmentBankingTeam(investmentBankingTeam.IssueInvestmentBankingTeam, investmentBankingTeam.AppTrasanctionId, investmentBankingTeam.RevenuePercentage, investmentBankingTeam.AttributionReviewed);
          transactionScope.Complete();
        }
        if (saveResult.IsSuccessful)
        {
          InvestmentBankingTeamViewModel bankingTeamViewModel = new InvestmentBankingTeamViewModel();
          InvestmentBankingTeamViewModel bankingTeamByAppId = this.getInvestmentBankingTeamByAppId(investmentBankingTeam.AppTrasanctionId);
          saveResult.ViewModel = (object) bankingTeamByAppId;
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private bool ValidateInvestmentBankingTeamModel(
      InvestmentBankingTeamViewModel investmentBankingTeam,
      ref SaveResult saveResult)
    {
      if (investmentBankingTeam != null)
      {
        foreach (InternalPartner internalPartner in investmentBankingTeam.IssueInvestmentBankingTeam)
        {
          Decimal? percentage = internalPartner.Percentage;
          Decimal num = (Decimal) 100;
          if ((percentage.GetValueOrDefault() > num ? (percentage.HasValue ? 1 : 0) : 0) != 0)
            saveResult.Errors.Add("RevenueAttribution", (object) "Revenue Attribution (%) cannot be more than 100%.");
        }
        Decimal? nullable = investmentBankingTeam.IssueInvestmentBankingTeam.Sum<InternalPartner>((Func<InternalPartner, Decimal?>) (m => m.Percentage));
        Decimal num1 = (Decimal) 100;
        if ((nullable.GetValueOrDefault() > num1 ? (nullable.HasValue ? 1 : 0) : 0) != 0 && investmentBankingTeam.IssueInvestmentBankingTeam.Count > 0)
          saveResult.Errors.Add("TotalRevenueAttribution", (object) "Sum of Revenue Attribution (%) cannot be more than 100%.");
        nullable = investmentBankingTeam.IssueInvestmentBankingTeam.Sum<InternalPartner>((Func<InternalPartner, Decimal?>) (m => m.Percentage));
        Decimal num2 = (Decimal) 100;
        if ((nullable.GetValueOrDefault() < num2 ? (nullable.HasValue ? 1 : 0) : 0) != 0 && investmentBankingTeam.IssueInvestmentBankingTeam.Count > 0)
          saveResult.Errors.Add("TotalRevenueAttributionLess", (object) "Sum of Revenue Attribution (%) cannot be less than 100%.");
      }
      return saveResult.IsSuccessful;
    }

    private IssuePresenter.MUCCEditOnlyStatus SetMUCCEditOnlyStatus(
      List<IssueEnums.IssueStatus> issueStatusList,
      long appTransactionID,
      string uiName)
    {
      IssuePresenter.MUCCEditOnlyStatus muccEditOnlyStatus = new IssuePresenter.MUCCEditOnlyStatus();
      List<long> statusList = issueStatusList.ConvertAll<long>((Converter<IssueEnums.IssueStatus, long>) (s => (long) s));
      muccEditOnlyStatus.isMUCCDetailsEditable = this.IsUIEditable(appTransactionID, uiName, statusList);
      return muccEditOnlyStatus;
    }

    private Dictionary<int, int> AddHistory(
      TransitionResult<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> transitionResult)
    {
      Dictionary<int, int> dictionary = (Dictionary<int, int>) null;
      if (transitionResult.History.Count > 0)
      {
        dictionary = new Dictionary<int, int>();
        foreach (KeyValuePair<IssueEnums.IssueStatus, IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>> keyValuePair in (IEnumerable<KeyValuePair<IssueEnums.IssueStatus, IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue>>>) transitionResult.History)
        {
          IssueEnums.IssueStatus key1 = keyValuePair.Key;
          IssueEnums.IssueStatus key2 = keyValuePair.Value.Key;
          dictionary.Add((int) key1, (int) key2);
        }
      }
      return dictionary;
    }

    private List<IssueFromStateToState> SetFromToStateList(
      TransitionResult<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> transitionResult,
      List<IssueFromStateToState> fromToStateList)
    {
      fromToStateList = new List<IssueFromStateToState>();
      foreach (IState<IssueEnums.IssueStatus, IrisSoftware.iMPACT.Data.Issue> resultingState in transitionResult.ResultingStates)
        fromToStateList.Add(new IssueFromStateToState(new IssueEnums.IssueStatus?(), resultingState.Key));
      return fromToStateList;
    }

    private List<long> SetStatusList(IssueViewModelContainer issueContainer)
    {
      List<long> longList = new List<long>();
      if (issueContainer.IssueDetail.IssueStatus != null && issueContainer.IssueDetail.IssueStatus.Count > 0)
        longList = issueContainer.IssueDetail.IssueStatus;
      return longList;
    }

    private void SetIssueNumber(IrisSoftware.iMPACT.Data.Issue newIssue, IrisSoftware.iMPACT.Data.Issue Is)
    {
      if (Is == null || string.IsNullOrEmpty(Is.IssueDetail.IssueNbr))
        return;
      newIssue.IssueDetail.IssueNbr = Is.IssueDetail.IssueNbr;
      newIssue.IssueDetail.Series = Is.IssueDetail.Series;
    }

    private void SetMSBankinngGroup(IrisSoftware.iMPACT.Data.Issue newIssue, IrisSoftware.iMPACT.Data.Issue Is)
    {
      if (Is == null)
        return;
      newIssue.IssueDetail.GeneralCategoryTxt = Is.IssueDetail.GeneralCategoryTxt;
    }

    private void SetG17Details(IrisSoftware.iMPACT.Data.Issue newIssue, IrisSoftware.iMPACT.Data.Issue Is)
    {
      if (Is == null)
        return;
      newIssue.IssueDetail.G17ContactPrefix = Is.IssueDetail.G17ContactPrefix;
      newIssue.IssueDetail.G17ContactFirstName = Is.IssueDetail.G17ContactFirstName;
      newIssue.IssueDetail.G17ContactLastName = Is.IssueDetail.G17ContactLastName;
      newIssue.IssueDetail.G17ContactSuffix = Is.IssueDetail.G17ContactSuffix;
      newIssue.IssueDetail.G17ContactJobTitle = Is.IssueDetail.G17ContactJobTitle;
      newIssue.IssueDetail.G17ContactEmail = Is.IssueDetail.G17ContactEmail;
      newIssue.IssueDetail.G17ContactAddress = Is.IssueDetail.G17ContactAddress;
      newIssue.IssueDetail.IssueUnderlyingRating = Is.IssueDetail.IssueUnderlyingRating;
    }

    private void FillAnalystDetails(string[] partnersEmailAddress, InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[2] = string.Format("{0}{1};", (object) partnersEmailAddress[2], (object) partner.Email);
      else
        partnersEmailAddress[3] = string.Format("{0}{1};", (object) partnersEmailAddress[3], (object) partner.Email);
    }

    private void FillInvestmentBankingDetails(
      string[] partnersEmailAddress,
      InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[0] = string.Format("{0}{1};", (object) partnersEmailAddress[0], (object) partner.Email);
      else if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("2", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[7] = string.Format("{0}{1};", (object) partnersEmailAddress[7], (object) partner.Email);
      else
        partnersEmailAddress[1] = string.Format("{0}{1};", (object) partnersEmailAddress[1], (object) partner.Email);
    }

    private void ApplyDelimiter(StringBuilder emailUpdated, string adr)
    {
      if (emailUpdated.Length > 0)
        emailUpdated.Append(";");
      emailUpdated.Append(adr);
    }

    private static object FixDate(string name, object value) => value != null && !string.IsNullOrEmpty(value.ToString()) && (IssuePresenter.dateColumnsToAdjust.Contains(name) && DateTime.TryParse(value.ToString(), out DateTime _)) ? (object) string.Format("{0:yyyy}-{0:MM}-{0:dd}T{0:HH}:{0:mm}:00.00", (object) (DateTime) value) : value;

    public SaveResult SearchIssue(
      KendoGridRequest request,
      IssueSearchViewModel issueSearchCriteria,
      string TimeZoneOffset)
    {
      try
      {
        long total = 0;
        bool isBlankSearch = false;
        IEnumerable<Dictionary<string, object>> searchResults = this.GetSearchResults(request, issueSearchCriteria, out total, ref isBlankSearch, TimeZoneOffset);
        SaveResult saveResult1 = new SaveResult();
        SaveResult saveResult2;
        if (isBlankSearch)
        {
          saveResult2 = SaveResult.Failure("Please select one or more filter criteria to continue search.");
        }
        else
        {
          saveResult2 = SaveResult.Success;
          saveResult2.ViewModel = (object) new Paged<Dictionary<string, object>>((object) searchResults, total);
        }
        return saveResult2;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure(ex.Message);
      }
    }

    private Decimal? ConvertToDecimal(string str) => string.IsNullOrEmpty(str) ? new Decimal?() : new Decimal?(Convert.ToDecimal(str));

    public IssueSearchViewModel Initialize()
    {
      try
      {
        IssueSearchViewModel issueSearchViewModel1 = new IssueSearchViewModel();
        CommaDelimitedStringCollection stringCollection = new CommaDelimitedStringCollection();
        stringCollection.Add(Convert.ToString(-32));
        stringCollection.Add(Convert.ToString(-34));
        IEnumerable<LookupItemMappings> lookupItems = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetSearchLookupItemKeys(), (string[]) null, false);
        IEnumerable<EntityState> entityStates = this.EntityStateRepository.FetchEntityStatesByEntityIDs(stringCollection.ToString());
        this.PopulateLookupItems(ref issueSearchViewModel1, lookupItems);
        this.PopulateEntityStates(entityStates, ref issueSearchViewModel1);
        issueSearchViewModel1.CanCreatePublicBookmark = this.HasEntityPermission(-32L, "Public Bookmark", "Create");
        SearchSetting searchSetting = this.IssueRepository.FetchAllBookmarks().FirstOrDefault<SearchSetting>((Func<SearchSetting, bool>) (x => x.SearchSettingID == -3L));
        if (searchSetting == null)
        {
          List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
          List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
          List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
          List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
          issueSearchViewModel1.SelectedFields = list1;
          issueSearchViewModel1.AllFields = list2;
          issueSearchViewModel1.SelectedAllFields = list2;
          issueSearchViewModel1.FieldsToSelect = list1;
        }
        else
        {
          IssueSearchViewModel issueSearchViewModel2 = new JavaScriptSerializer().Deserialize<IssueSearchViewModel>(searchSetting.Criteria);
          if (issueSearchViewModel2.SelectedFields != null && issueSearchViewModel2.SelectedFields.Count > 0)
          {
            issueSearchViewModel1.SelectedFields = issueSearchViewModel2.SelectedFields;
            issueSearchViewModel1.AllFields = issueSearchViewModel2.AllFields;
            issueSearchViewModel1.SelectedAllFields = issueSearchViewModel2.AllFields;
            issueSearchViewModel1.FieldsToSelect = issueSearchViewModel2.FieldsToSelect;
          }
          else
          {
            List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
            List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
            List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
            List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
            issueSearchViewModel1.SelectedFields = list1;
            issueSearchViewModel1.AllFields = list2;
            issueSearchViewModel1.SelectedAllFields = list2;
            issueSearchViewModel1.FieldsToSelect = list1;
          }
        }
        return issueSearchViewModel1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssueSearchViewModel issueSearchViewModel = new IssueSearchViewModel();
        issueSearchViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return issueSearchViewModel;
      }
    }

    private void PopulateLookupItems(
      ref IssueSearchViewModel issueSearchViewModel,
      IEnumerable<LookupItemMappings> lookupItems)
    {
      lookupItems = (IEnumerable<LookupItemMappings>) lookupItems.OrderBy<LookupItemMappings, long>((Func<LookupItemMappings, long>) (x => x.LookupID));
      foreach (LookupItemMappings lookupItem in lookupItems)
      {
        KeyValuePair<long, string> keyValuePair = new KeyValuePair<long, string>(lookupItem.LookupItemID, lookupItem.Value);
        switch (lookupItem.Key)
        {
          case "Additional Firm Role(s)":
          case "Firm Role":
            issueSearchViewModel.FirmRoles.Add(keyValuePair);
            continue;
          case "Advisory Agent Type":
            KeyPair keyPair1 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.AdvisorAgentType.Add(keyPair1);
            continue;
          case "Call Feature":
            KeyPair keyPair2 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.CallFeatures.Add(keyPair2);
            continue;
          case "Counsel Type":
            KeyPair keyPair3 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.CounselType.Add(keyPair3);
            continue;
          case "Cross Sell":
            issueSearchViewModel.CrossSells.Add(keyValuePair);
            continue;
          case "Deal Type":
            issueSearchViewModel.DealTypes.Add(keyValuePair);
            continue;
          case "Fed Tax":
            KeyPair keyPair4 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.FedTaxs.Add(keyPair4);
            continue;
          case "Fitch Long Term Rating":
            KeyPair keyPair5 = new KeyPair(lookupItem.Value, lookupItem.Value);
            issueSearchViewModel.FitchLongTermRatings.Add(keyPair5);
            continue;
          case "Insurance Provider":
            KeyPair keyPair6 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.InsuranceProviders.Add(keyPair6);
            continue;
          case "Interest Rate Type":
            issueSearchViewModel.InterestRateTypes.Add(keyValuePair);
            continue;
          case "Issue Status":
            issueSearchViewModel.IssueStatuses.Add(keyValuePair);
            continue;
          case "Kroll Long Term Rating":
            KeyPair keyPair7 = new KeyPair(lookupItem.Value, lookupItem.Value);
            issueSearchViewModel.KrollLongTermRatings.Add(keyPair7);
            continue;
          case "MA Exemption":
            issueSearchViewModel.MAExemptions.Add(keyValuePair);
            continue;
          case "MS Banking Group":
            KeyPair keyPair8 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.GeneralCategories.Add(keyPair8);
            continue;
          case "Moody's Long Term Rating":
            KeyPair keyPair9 = new KeyPair(lookupItem.Value, lookupItem.Value);
            issueSearchViewModel.MoodyLongTermRatings.Add(keyPair9);
            continue;
          case "Other Partner Type":
            KeyPair keyPair10 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.OtherPartnerType.Add(keyPair10);
            continue;
          case "Purpose":
            issueSearchViewModel.Purposes.Add(keyValuePair);
            continue;
          case "S&P Long Term Rating":
            KeyPair keyPair11 = new KeyPair(lookupItem.Value, lookupItem.Value);
            issueSearchViewModel.SPLongTermRatings.Add(keyPair11);
            continue;
          case "State":
            issueSearchViewModel.States.Add(keyValuePair);
            continue;
          case "Syndicate Member Role":
            KeyPair keyPair12 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.SyndicateMemberType.Add(keyPair12);
            continue;
          case "Syndicate Structure":
            KeyPair keyPair13 = new KeyPair(lookupItem.LookupItemID, lookupItem.Value);
            issueSearchViewModel.PriorityOfOrders.Add(keyPair13);
            continue;
          case "Type of Offering":
            issueSearchViewModel.TypeOfOfferings.Add(keyValuePair);
            continue;
          case "Use of Proceeds":
            issueSearchViewModel.UseOfProceeds.Add(keyValuePair);
            continue;
          default:
            continue;
        }
      }
    }

    private void PopulateEntityStates(
      IEnumerable<EntityState> entityStates,
      ref IssueSearchViewModel issueSearchViewModel)
    {
      issueSearchViewModel.IssueStatuses = issueSearchViewModel.IssueStatuses ?? new List<KeyValuePair<long, string>>();
      issueSearchViewModel.PnLStatuses = issueSearchViewModel.PnLStatuses ?? new List<KeyValuePair<long, string>>();
      foreach (EntityState entityState in entityStates)
      {
        switch (entityState.EntityID)
        {
          case -34:
            issueSearchViewModel.PnLStatuses.Add(new KeyValuePair<long, string>(entityState.StateID, entityState.StateKey));
            continue;
          case -32:
            issueSearchViewModel.IssueStatuses.Add(new KeyValuePair<long, string>(entityState.StateID, entityState.StateKey));
            continue;
          default:
            continue;
        }
      }
    }

    private List<SearchResultField> GetAllSearchResultFields()
    {
      List<SearchResultField> searchResultFieldList1 = new List<SearchResultField>();
      int num1 = 1;
      List<SearchResultField> searchResultFieldList2 = searchResultFieldList1;
      SearchResultField searchResultField1 = new SearchResultField();
      searchResultField1.Name = "Transaction Number";
      searchResultField1.ExportField = "IssueNumber";
      int num2 = num1;
      int num3 = num2 + 1;
      searchResultField1.Order = num2;
      searchResultField1.Html = new SearchResultFieldHtml()
      {
        field = "IssueNumber",
        title = "Transaction Number",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "4cm"
      };
      searchResultFieldList2.Add(searchResultField1);
      List<SearchResultField> searchResultFieldList3 = searchResultFieldList1;
      SearchResultField searchResultField2 = new SearchResultField();
      searchResultField2.Name = "Transaction Description";
      searchResultField2.ExportField = "IssueName";
      int num4 = num3;
      int num5 = num4 + 1;
      searchResultField2.Order = num4;
      searchResultField2.IsMandatory = true;
      searchResultField2.Html = new SearchResultFieldHtml()
      {
        field = "IssueName",
        title = "Transaction Description",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "6cm",
        template = "<a href='Issue.aspx?issueId=#= AppTransactionID #' target='_blank'>#= IssueName #</a>"
      };
      searchResultFieldList3.Add(searchResultField2);
      List<SearchResultField> searchResultFieldList4 = searchResultFieldList1;
      SearchResultField searchResultField3 = new SearchResultField();
      searchResultField3.Name = "Transaction Status";
      searchResultField3.ExportField = "IssueStatus";
      int num6 = num5;
      int num7 = num6 + 1;
      searchResultField3.Order = num6;
      searchResultField3.Html = new SearchResultFieldHtml()
      {
        field = "IssueStatus",
        title = "Transaction Status",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList4.Add(searchResultField3);
      List<SearchResultField> searchResultFieldList5 = searchResultFieldList1;
      SearchResultField searchResultField4 = new SearchResultField();
      searchResultField4.Name = "Review History";
      searchResultField4.ExportField = "ReviewStatus";
      int num8 = num7;
      int num9 = num8 + 1;
      searchResultField4.Order = num8;
      searchResultField4.Html = new SearchResultFieldHtml()
      {
        field = "ReviewStatus",
        title = "Review Status",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "6cm"
      };
      searchResultFieldList5.Add(searchResultField4);
      List<SearchResultField> searchResultFieldList6 = searchResultFieldList1;
      SearchResultField searchResultField5 = new SearchResultField();
      searchResultField5.Name = "Issuer";
      searchResultField5.ExportField = "Issuer";
      int num10 = num9;
      int num11 = num10 + 1;
      searchResultField5.Order = num10;
      searchResultField5.IsMandatory = true;
      searchResultField5.Html = new SearchResultFieldHtml()
      {
        field = "Issuer",
        title = "Issuer",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList6.Add(searchResultField5);
      List<SearchResultField> searchResultFieldList7 = searchResultFieldList1;
      SearchResultField searchResultField6 = new SearchResultField();
      searchResultField6.Name = "Borrower/Obligor";
      searchResultField6.ExportField = "Borrower";
      int num12 = num11;
      int num13 = num12 + 1;
      searchResultField6.Order = num12;
      searchResultField6.Html = new SearchResultFieldHtml()
      {
        field = "Borrower",
        title = "Borrower/Obligor",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList7.Add(searchResultField6);
      List<SearchResultField> searchResultFieldList8 = searchResultFieldList1;
      SearchResultField searchResultField7 = new SearchResultField();
      searchResultField7.Name = "Guarantor";
      searchResultField7.ExportField = "Guarantor";
      int num14 = num13;
      int num15 = num14 + 1;
      searchResultField7.Order = num14;
      searchResultField7.Html = new SearchResultFieldHtml()
      {
        field = "Guarantor",
        title = "Guarantor",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "7cm"
      };
      searchResultFieldList8.Add(searchResultField7);
      List<SearchResultField> searchResultFieldList9 = searchResultFieldList1;
      SearchResultField searchResultField8 = new SearchResultField();
      searchResultField8.Name = "Type of Offering";
      searchResultField8.ExportField = "TypeOfOffering";
      int num16 = num15;
      int num17 = num16 + 1;
      searchResultField8.Order = num16;
      searchResultField8.Html = new SearchResultFieldHtml()
      {
        field = "TypeOfOffering",
        title = "Type of Offering",
        sortable = true,
        isLeftAligned = true,
        width = "250px",
        excelWidth = "5cm"
      };
      searchResultFieldList9.Add(searchResultField8);
      List<SearchResultField> searchResultFieldList10 = searchResultFieldList1;
      SearchResultField searchResultField9 = new SearchResultField();
      searchResultField9.Name = "State";
      searchResultField9.ExportField = "State";
      int num18 = num17;
      int num19 = num18 + 1;
      searchResultField9.Order = num18;
      searchResultField9.Html = new SearchResultFieldHtml()
      {
        field = "State",
        title = "State",
        sortable = true,
        isLeftAligned = true,
        width = "60px",
        excelWidth = "2cm"
      };
      searchResultFieldList10.Add(searchResultField9);
      List<SearchResultField> searchResultFieldList11 = searchResultFieldList1;
      SearchResultField searchResultField10 = new SearchResultField();
      searchResultField10.Name = "Date Hired";
      searchResultField10.ExportField = "=Format(fields!DateHired.Value, \"MM/dd/yyyy\")";
      searchResultField10.ExportColumns = new string[1]
      {
        "DateHired"
      };
      SearchResultField searchResultField11 = searchResultField10;
      int num20 = num19;
      int num21 = num20 + 1;
      searchResultField11.Order = num20;
      searchResultField10.Html = new SearchResultFieldHtml()
      {
        field = "DateHired",
        title = "Date Hired",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2.5cm",
        template = "#= convertDateToString(DateHired) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField12 = searchResultField10;
      searchResultFieldList11.Add(searchResultField12);
      List<SearchResultField> searchResultFieldList12 = searchResultFieldList1;
      SearchResultField searchResultField13 = new SearchResultField();
      searchResultField13.Name = "1st Coupon Date";
      searchResultField13.ExportField = "=Format(fields!FirstCouponDate.Value, \"MM/dd/yyyy\")";
      searchResultField13.ExportColumns = new string[1]
      {
        "FirstCouponDate"
      };
      SearchResultField searchResultField14 = searchResultField13;
      int num22 = num21;
      int num23 = num22 + 1;
      searchResultField14.Order = num22;
      searchResultField13.Html = new SearchResultFieldHtml()
      {
        field = "FirstCouponDate",
        title = "1st Coupon Date",
        sortable = true,
        isLeftAligned = true,
        width = "130px",
        excelWidth = "2.2cm",
        template = "#= convertDateToString(FirstCouponDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField15 = searchResultField13;
      searchResultFieldList12.Add(searchResultField15);
      List<SearchResultField> searchResultFieldList13 = searchResultFieldList1;
      SearchResultField searchResultField16 = new SearchResultField();
      searchResultField16.Name = "Accrue From";
      searchResultField16.ExportField = "AccrueFrom";
      int num24 = num23;
      int num25 = num24 + 1;
      searchResultField16.Order = num24;
      searchResultField16.Html = new SearchResultFieldHtml()
      {
        field = "AccrueFrom",
        title = "Accrue From",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3.5cm"
      };
      searchResultFieldList13.Add(searchResultField16);
      List<SearchResultField> searchResultFieldList14 = searchResultFieldList1;
      SearchResultField searchResultField17 = new SearchResultField();
      searchResultField17.Name = "Actual Award Date & Time";
      searchResultField17.ExportField = "=Format(fields!ActualAwardDate.Value, \"MM/dd/yyyy hh:mm tt\") & IIF(Len(fields!ActualAwardDateTimeZone.Value)=0, \"\",\" (\") & fields!ActualAwardDateTimeZone.Value & IIF(Len(fields!ActualAwardDateTimeZone.Value)=0, \"\",\")\")";
      searchResultField17.ExportColumns = new string[2]
      {
        "ActualAwardDate",
        "ActualAwardDateTimeZone"
      };
      SearchResultField searchResultField18 = searchResultField17;
      int num26 = num25;
      int num27 = num26 + 1;
      searchResultField18.Order = num26;
      searchResultField17.Html = new SearchResultFieldHtml()
      {
        field = "ActualAwardDate",
        title = "Actual Award Date & Time",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        excelFormat = "{M/dd/yyyy}",
        template = "#= convertDateToStringDateTime(ActualAwardDate,ActualAwardDateTimeZone) #",
        groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
      };
      SearchResultField searchResultField19 = searchResultField17;
      searchResultFieldList14.Add(searchResultField19);
      List<SearchResultField> searchResultFieldList15 = searchResultFieldList1;
      SearchResultField searchResultField20 = new SearchResultField();
      searchResultField20.Name = "Additional Firm Role(s)";
      searchResultField20.ExportField = "FirmOtherRoles";
      int num28 = num27;
      int num29 = num28 + 1;
      searchResultField20.Order = num28;
      searchResultField20.Html = new SearchResultFieldHtml()
      {
        field = "FirmOtherRoles",
        title = "Additional Firm Role(s)",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList15.Add(searchResultField20);
      List<SearchResultField> searchResultFieldList16 = searchResultFieldList1;
      SearchResultField searchResultField21 = new SearchResultField();
      searchResultField21.Name = "Amount";
      searchResultField21.ExportField = "SeriesParAmount";
      int num30 = num29;
      int num31 = num30 + 1;
      searchResultField21.Order = num30;
      searchResultField21.Html = new SearchResultFieldHtml()
      {
        field = "SeriesParAmount",
        title = "Amount",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c0}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0"
      };
      searchResultFieldList16.Add(searchResultField21);
      List<SearchResultField> searchResultFieldList17 = searchResultFieldList1;
      SearchResultField searchResultField22 = new SearchResultField();
      searchResultField22.Name = "ARD Submission Date";
      searchResultField22.ExportField = "=Format(fields!ARDSubmissionDate.Value, \"MM/dd/yyyy\")";
      searchResultField22.ExportColumns = new string[1]
      {
        "ARDSubmissionDate"
      };
      SearchResultField searchResultField23 = searchResultField22;
      int num32 = num31;
      int num33 = num32 + 1;
      searchResultField23.Order = num32;
      searchResultField22.Html = new SearchResultFieldHtml()
      {
        field = "ARDSubmissionDate",
        title = "ARD Submission Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(ARDSubmissionDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField24 = searchResultField22;
      searchResultFieldList17.Add(searchResultField24);
      List<SearchResultField> searchResultFieldList18 = searchResultFieldList1;
      SearchResultField searchResultField25 = new SearchResultField();
      searchResultField25.Name = "Bank Qualified";
      searchResultField25.ExportField = "SeriesBankQualified";
      int num34 = num33;
      int num35 = num34 + 1;
      searchResultField25.Order = num34;
      searchResultField25.Html = new SearchResultFieldHtml()
      {
        field = "SeriesBankQualified",
        title = "Bank Qualified",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2cm"
      };
      searchResultFieldList18.Add(searchResultField25);
      List<SearchResultField> searchResultFieldList19 = searchResultFieldList1;
      SearchResultField searchResultField26 = new SearchResultField();
      searchResultField26.Name = "Bond Counsel";
      searchResultField26.ExportField = "BondCounsel";
      int num36 = num35;
      int num37 = num36 + 1;
      searchResultField26.Order = num36;
      searchResultField26.Html = new SearchResultFieldHtml()
      {
        field = "BondCounsel",
        title = "Bond Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList19.Add(searchResultField26);
      List<SearchResultField> searchResultFieldList20 = searchResultFieldList1;
      SearchResultField searchResultField27 = new SearchResultField();
      searchResultField27.Name = "Borrower's Counsel";
      searchResultField27.ExportField = "BorrowerCounsel";
      int num38 = num37;
      int num39 = num38 + 1;
      searchResultField27.Order = num38;
      searchResultField27.Html = new SearchResultFieldHtml()
      {
        field = "BorrowerCounsel",
        title = "Borrower's Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList20.Add(searchResultField27);
      List<SearchResultField> searchResultFieldList21 = searchResultFieldList1;
      SearchResultField searchResultField28 = new SearchResultField();
      searchResultField28.Name = "Call Date";
      searchResultField28.ExportField = "=Format(fields!SeriesCallDate.Value, \"MM/dd/yyyy\")";
      searchResultField28.ExportColumns = new string[1]
      {
        "SeriesCallDate"
      };
      SearchResultField searchResultField29 = searchResultField28;
      int num40 = num39;
      int num41 = num40 + 1;
      searchResultField29.Order = num40;
      searchResultField28.Html = new SearchResultFieldHtml()
      {
        field = "SeriesCallDate",
        title = "Call Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "2.3cm",
        template = "#= convertDateToString(SeriesCallDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField30 = searchResultField28;
      searchResultFieldList21.Add(searchResultField30);
      List<SearchResultField> searchResultFieldList22 = searchResultFieldList1;
      SearchResultField searchResultField31 = new SearchResultField();
      searchResultField31.Name = "Call Feature";
      searchResultField31.ExportField = "SeriesCallFeature";
      int num42 = num41;
      int num43 = num42 + 1;
      searchResultField31.Order = num42;
      searchResultField31.Html = new SearchResultFieldHtml()
      {
        field = "SeriesCallFeature",
        title = "Call Feature",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList22.Add(searchResultField31);
      List<SearchResultField> searchResultFieldList23 = searchResultFieldList1;
      SearchResultField searchResultField32 = new SearchResultField();
      searchResultField32.Name = "Call Price";
      searchResultField32.ExportField = "CallPrice";
      int num44 = num43;
      int num45 = num44 + 1;
      searchResultField32.Order = num44;
      searchResultField32.Html = new SearchResultFieldHtml()
      {
        field = "CallPrice",
        title = "Call Price",
        sortable = true,
        isLeftAligned = false,
        width = "100px",
        excelWidth = "3cm",
        format = "{0:N3}",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList23.Add(searchResultField32);
      List<SearchResultField> searchResultFieldList24 = searchResultFieldList1;
      SearchResultField searchResultField33 = new SearchResultField();
      searchResultField33.Name = "CE Expiration Date";
      searchResultField33.ExportField = "=Format(fields!CEExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField33.ExportColumns = new string[1]
      {
        "CEExpirationDate"
      };
      SearchResultField searchResultField34 = searchResultField33;
      int num46 = num45;
      int num47 = num46 + 1;
      searchResultField34.Order = num46;
      searchResultField33.Html = new SearchResultFieldHtml()
      {
        field = "CEExpirationDate",
        title = "CE Expiration Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(CEExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField35 = searchResultField33;
      searchResultFieldList24.Add(searchResultField35);
      List<SearchResultField> searchResultFieldList25 = searchResultFieldList1;
      SearchResultField searchResultField36 = new SearchResultField();
      searchResultField36.Name = "Co-Manager";
      searchResultField36.ExportField = "CoManager";
      int num48 = num47;
      int num49 = num48 + 1;
      searchResultField36.Order = num48;
      searchResultField36.Html = new SearchResultFieldHtml()
      {
        field = "CoManager",
        title = "Co-Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList25.Add(searchResultField36);
      List<SearchResultField> searchResultFieldList26 = searchResultFieldList1;
      SearchResultField searchResultField37 = new SearchResultField();
      searchResultField37.Name = "Co Senior Mgr";
      searchResultField37.ExportField = "CoSeniorMgr";
      int num50 = num49;
      int num51 = num50 + 1;
      searchResultField37.Order = num50;
      searchResultField37.Html = new SearchResultFieldHtml()
      {
        field = "CoSeniorMgr",
        title = "Co Senior Mgr",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList26.Add(searchResultField37);
      List<SearchResultField> searchResultFieldList27 = searchResultFieldList1;
      SearchResultField searchResultField38 = new SearchResultField();
      searchResultField38.Name = "Commitment Committee Approval Date";
      searchResultField38.ExportField = "=Format(fields!CommitmentCommitteeApprovalDate.Value, \"MM/dd/yyyy\")";
      searchResultField38.ExportColumns = new string[1]
      {
        "CommitmentCommitteeApprovalDate"
      };
      SearchResultField searchResultField39 = searchResultField38;
      int num52 = num51;
      int num53 = num52 + 1;
      searchResultField39.Order = num52;
      searchResultField38.Html = new SearchResultFieldHtml()
      {
        field = "CommitmentCommitteeApprovalDate",
        title = "Commitment Committee Approval Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "4cm",
        template = "#= convertDateToString(CommitmentCommitteeApprovalDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField40 = searchResultField38;
      searchResultFieldList27.Add(searchResultField40);
      List<SearchResultField> searchResultFieldList28 = searchResultFieldList1;
      SearchResultField searchResultField41 = new SearchResultField();
      searchResultField41.Name = "Coupon Frequency";
      searchResultField41.ExportField = "CouponFreq";
      int num54 = num53;
      int num55 = num54 + 1;
      searchResultField41.Order = num54;
      searchResultField41.Html = new SearchResultFieldHtml()
      {
        field = "CouponFreq",
        title = "Coupon Frequency",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList28.Add(searchResultField41);
      List<SearchResultField> searchResultFieldList29 = searchResultFieldList1;
      SearchResultField searchResultField42 = new SearchResultField();
      searchResultField42.Name = "Create Date";
      searchResultField42.ExportField = "=Format(fields!CreatedOn.Value, \"MM/dd/yyyy\")";
      searchResultField42.ExportColumns = new string[1]
      {
        "CreatedOn"
      };
      searchResultField42.IsTimezoneReq = true;
      SearchResultField searchResultField43 = searchResultField42;
      int num56 = num55;
      int num57 = num56 + 1;
      searchResultField43.Order = num56;
      searchResultField42.Html = new SearchResultFieldHtml()
      {
        field = "CreateDate",
        title = "Create Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertSearchDateToLocalDateOnly(CreateDate) #",
        groupHeaderTemplate = "#= convertSearchDateToLocalDateOnly(value) #"
      };
      SearchResultField searchResultField44 = searchResultField42;
      searchResultFieldList29.Add(searchResultField44);
      List<SearchResultField> searchResultFieldList30 = searchResultFieldList1;
      SearchResultField searchResultField45 = new SearchResultField();
      searchResultField45.Name = "Credit Enhancement Provider";
      searchResultField45.ExportField = "CreditEnhancementProvider";
      int num58 = num57;
      int num59 = num58 + 1;
      searchResultField45.Order = num58;
      searchResultField45.Html = new SearchResultFieldHtml()
      {
        field = "CreditEnhancementProvider",
        title = "Credit Enhancement Provider",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList30.Add(searchResultField45);
      List<SearchResultField> searchResultFieldList31 = searchResultFieldList1;
      SearchResultField searchResultField46 = new SearchResultField();
      searchResultField46.Name = "Credit Enhancement Type";
      searchResultField46.ExportField = "CEType";
      int num60 = num59;
      int num61 = num60 + 1;
      searchResultField46.Order = num60;
      searchResultField46.Html = new SearchResultFieldHtml()
      {
        field = "CEType",
        title = "Credit Enhancement Type",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList31.Add(searchResultField46);
      List<SearchResultField> searchResultFieldList32 = searchResultFieldList1;
      SearchResultField searchResultField47 = new SearchResultField();
      searchResultField47.Name = "Date Approved by MUCC";
      searchResultField47.ExportField = "=Format(fields!DateApprovedByMUCC.Value, \"MM/dd/yyyy\")";
      searchResultField47.ExportColumns = new string[1]
      {
        "DateApprovedByMUCC"
      };
      SearchResultField searchResultField48 = searchResultField47;
      int num62 = num61;
      int num63 = num62 + 1;
      searchResultField48.Order = num62;
      searchResultField47.Html = new SearchResultFieldHtml()
      {
        field = "DateApprovedByMUCC",
        title = "Date Approved by MUCC",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "4cm",
        template = "#= convertDateToString(DateApprovedByMUCC) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField49 = searchResultField47;
      searchResultFieldList32.Add(searchResultField49);
      List<SearchResultField> searchResultFieldList33 = searchResultFieldList1;
      SearchResultField searchResultField50 = new SearchResultField();
      searchResultField50.Name = "Series Dated Date";
      searchResultField50.ExportField = "=Format(fields!SeriesDatedDate.Value, \"MM/dd/yyyy\")";
      searchResultField50.ExportColumns = new string[1]
      {
        "SeriesDatedDate"
      };
      SearchResultField searchResultField51 = searchResultField50;
      int num64 = num63;
      int num65 = num64 + 1;
      searchResultField51.Order = num64;
      searchResultField50.Html = new SearchResultFieldHtml()
      {
        field = "SeriesDatedDate",
        title = "Series Dated Date",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm",
        template = "#= convertDateToString(SeriesDatedDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField52 = searchResultField50;
      searchResultFieldList33.Add(searchResultField52);
      List<SearchResultField> searchResultFieldList34 = searchResultFieldList1;
      SearchResultField searchResultField53 = new SearchResultField();
      searchResultField53.Name = "Dated Date";
      searchResultField53.ExportField = "=Format(fields!DatedDate.Value, \"MM/dd/yyyy\")";
      searchResultField53.ExportColumns = new string[1]
      {
        "DatedDate"
      };
      SearchResultField searchResultField54 = searchResultField53;
      int num66 = num65;
      int num67 = num66 + 1;
      searchResultField54.Order = num66;
      searchResultField53.Html = new SearchResultFieldHtml()
      {
        field = "DatedDate",
        title = "Dated Date",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm",
        template = "#= convertDateToString(DatedDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField55 = searchResultField53;
      searchResultFieldList34.Add(searchResultField55);
      List<SearchResultField> searchResultFieldList35 = searchResultFieldList1;
      SearchResultField searchResultField56 = new SearchResultField();
      searchResultField56.Name = "Day Count";
      searchResultField56.ExportField = "DayCount";
      int num68 = num67;
      int num69 = num68 + 1;
      searchResultField56.Order = num68;
      searchResultField56.Html = new SearchResultFieldHtml()
      {
        field = "DayCount",
        title = "Day Count",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm"
      };
      searchResultFieldList35.Add(searchResultField56);
      List<SearchResultField> searchResultFieldList36 = searchResultFieldList1;
      SearchResultField searchResultField57 = new SearchResultField();
      searchResultField57.Name = "Delivery Date";
      searchResultField57.ExportField = "=Format(fields!SettlementDate.Value, \"MM/dd/yyyy\")";
      searchResultField57.ExportColumns = new string[1]
      {
        "SettlementDate"
      };
      SearchResultField searchResultField58 = searchResultField57;
      int num70 = num69;
      int num71 = num70 + 1;
      searchResultField58.Order = num70;
      searchResultField57.Html = new SearchResultFieldHtml()
      {
        field = "SettlementDate",
        title = "Delivery Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(SettlementDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField59 = searchResultField57;
      searchResultFieldList36.Add(searchResultField59);
      List<SearchResultField> searchResultFieldList37 = searchResultFieldList1;
      SearchResultField searchResultField60 = new SearchResultField();
      searchResultField60.Name = "Disclosure Counsel";
      searchResultField60.ExportField = "DisclosureCounsel";
      int num72 = num71;
      int num73 = num72 + 1;
      searchResultField60.Order = num72;
      searchResultField60.Html = new SearchResultFieldHtml()
      {
        field = "DisclosureCounsel",
        title = "Disclosure Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList37.Add(searchResultField60);
      List<SearchResultField> searchResultFieldList38 = searchResultFieldList1;
      SearchResultField searchResultField61 = new SearchResultField();
      searchResultField61.Name = "Enhanced Ratings (Moody's/S&P/Fitch/Kroll)";
      searchResultField61.ExportField = "EnhancedRating";
      int num74 = num73;
      int num75 = num74 + 1;
      searchResultField61.Order = num74;
      searchResultField61.Html = new SearchResultFieldHtml()
      {
        field = "EnhancedRating",
        title = "Enhanced Ratings (Moody's/S&P/Fitch/Kroll)",
        sortable = true,
        isLeftAligned = true,
        width = "190px",
        excelWidth = "5cm"
      };
      searchResultFieldList38.Add(searchResultField61);
      List<SearchResultField> searchResultFieldList39 = searchResultFieldList1;
      SearchResultField searchResultField62 = new SearchResultField();
      searchResultField62.Name = "Escrow Agent For Refunded Bonds";
      searchResultField62.ExportField = "EscrowAgentForRefundedBonds";
      int num76 = num75;
      int num77 = num76 + 1;
      searchResultField62.Order = num76;
      searchResultField62.Html = new SearchResultFieldHtml()
      {
        field = "EscrowAgentForRefundedBonds",
        title = "Escrow Agent for Refunded Bonds",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList39.Add(searchResultField62);
      List<SearchResultField> searchResultFieldList40 = searchResultFieldList1;
      SearchResultField searchResultField63 = new SearchResultField();
      searchResultField63.Name = "Escrow Securities Provider";
      searchResultField63.ExportField = "EscrowSecuritiesProvider";
      int num78 = num77;
      int num79 = num78 + 1;
      searchResultField63.Order = num78;
      searchResultField63.Html = new SearchResultFieldHtml()
      {
        field = "EscrowSecuritiesProvider",
        title = "Escrow Securities Provider",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList40.Add(searchResultField63);
      List<SearchResultField> searchResultFieldList41 = searchResultFieldList1;
      SearchResultField searchResultField64 = new SearchResultField();
      searchResultField64.Name = "Escrow Verification Agent";
      searchResultField64.ExportField = "EscrowVerificationAgent";
      int num80 = num79;
      int num81 = num80 + 1;
      searchResultField64.Order = num80;
      searchResultField64.Html = new SearchResultFieldHtml()
      {
        field = "EscrowVerificationAgent",
        title = "Escrow Verification Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList41.Add(searchResultField64);
      List<SearchResultField> searchResultFieldList42 = searchResultFieldList1;
      SearchResultField searchResultField65 = new SearchResultField();
      searchResultField65.Name = "Estimated Average Takedown ($/1,000)";
      searchResultField65.ExportField = "Takedown";
      int num82 = num81;
      int num83 = num82 + 1;
      searchResultField65.Order = num82;
      searchResultField65.Html = new SearchResultFieldHtml()
      {
        field = "Takedown",
        title = "Estimated Average Takedown ($/1,000)",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c3}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.000"
      };
      searchResultFieldList42.Add(searchResultField65);
      List<SearchResultField> searchResultFieldList43 = searchResultFieldList1;
      SearchResultField searchResultField66 = new SearchResultField();
      searchResultField66.Name = "Estimated Revenue";
      searchResultField66.ExportField = "EstimatedRevenue";
      int num84 = num83;
      int num85 = num84 + 1;
      searchResultField66.Order = num84;
      searchResultField66.Html = new SearchResultFieldHtml()
      {
        field = "EstimatedRevenue",
        title = "Estimated Revenue",
        sortable = true,
        isLeftAligned = false,
        width = "170px",
        excelWidth = "4.5cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList43.Add(searchResultField66);
      List<SearchResultField> searchResultFieldList44 = searchResultFieldList1;
      SearchResultField searchResultField67 = new SearchResultField();
      searchResultField67.Name = "Expected Award Date";
      searchResultField67.ExportField = "=Format(fields!ExpectedAwardDate.Value, \"MM/dd/yyyy\")";
      searchResultField67.ExportColumns = new string[1]
      {
        "ExpectedAwardDate"
      };
      SearchResultField searchResultField68 = searchResultField67;
      int num86 = num85;
      int num87 = num86 + 1;
      searchResultField68.Order = num86;
      searchResultField67.Html = new SearchResultFieldHtml()
      {
        field = "ExpectedAwardDate",
        title = "Expected Award Date",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm",
        template = "#= convertDateToString(ExpectedAwardDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField69 = searchResultField67;
      searchResultFieldList44.Add(searchResultField69);
      List<SearchResultField> searchResultFieldList45 = searchResultFieldList1;
      SearchResultField searchResultField70 = new SearchResultField();
      searchResultField70.Name = "Fed Tax";
      searchResultField70.ExportField = "FedTaxName";
      int num88 = num87;
      int num89 = num88 + 1;
      searchResultField70.Order = num88;
      searchResultField70.Html = new SearchResultFieldHtml()
      {
        field = "FedTaxName",
        title = "Fed Tax",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm"
      };
      searchResultFieldList45.Add(searchResultField70);
      List<SearchResultField> searchResultFieldList46 = searchResultFieldList1;
      SearchResultField searchResultField71 = new SearchResultField();
      searchResultField71.Name = "Series Pricing Date";
      searchResultField71.ExportField = "=Format(fields!SeriesPricingDate.Value, \"MM/dd/yyyy\")";
      searchResultField71.ExportColumns = new string[1]
      {
        "SeriesPricingDate"
      };
      SearchResultField searchResultField72 = searchResultField71;
      int num90 = num89;
      int num91 = num90 + 1;
      searchResultField72.Order = num90;
      searchResultField71.Html = new SearchResultFieldHtml()
      {
        field = "SeriesPricingDate",
        title = "Series Pricing Date",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm",
        template = "#= convertDateToString(SeriesPricingDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField73 = searchResultField71;
      searchResultFieldList46.Add(searchResultField73);
      List<SearchResultField> searchResultFieldList47 = searchResultFieldList1;
      SearchResultField searchResultField74 = new SearchResultField();
      searchResultField74.Name = "Series Retail Order Period Date";
      searchResultField74.ExportField = "=Format(fields!SeriesROPDate.Value, \"MM/dd/yyyy\")";
      searchResultField74.ExportColumns = new string[1]
      {
        "SeriesROPDate"
      };
      SearchResultField searchResultField75 = searchResultField74;
      int num92 = num91;
      int num93 = num92 + 1;
      searchResultField75.Order = num92;
      searchResultField74.Html = new SearchResultFieldHtml()
      {
        field = "SeriesROPDate",
        title = "Series Retail Order Period Date",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm",
        template = "#= convertDateToString(SeriesROPDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField76 = searchResultField74;
      searchResultFieldList47.Add(searchResultField76);
      List<SearchResultField> searchResultFieldList48 = searchResultFieldList1;
      SearchResultField searchResultField77 = new SearchResultField();
      searchResultField77.Name = "Series Actual Award Date & Time";
      searchResultField77.ExportField = "=Format(fields!SeriesActualAwardDate.Value, \"MM/dd/yyyy hh:mm tt\") & IIF(Len(fields!SeriesActualAwardDateTimeZone.Value)=0, \"\",\" (\") & fields!SeriesActualAwardDateTimeZone.Value & IIF(Len(fields!SeriesActualAwardDateTimeZone.Value)=0, \"\",\")\")";
      searchResultField77.ExportColumns = new string[2]
      {
        "SeriesActualAwardDate",
        "SeriesActualAwardDateTimeZone"
      };
      SearchResultField searchResultField78 = searchResultField77;
      int num94 = num93;
      int num95 = num94 + 1;
      searchResultField78.Order = num94;
      searchResultField77.Html = new SearchResultFieldHtml()
      {
        field = "SeriesActualAwardDate",
        title = "Series Actual Award Date & Time",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        excelFormat = "{M/dd/yyyy}",
        template = "#= convertDateToStringDateTime(SeriesActualAwardDate,SeriesActualAwardDateTimeZone) #",
        groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
      };
      SearchResultField searchResultField79 = searchResultField77;
      searchResultFieldList48.Add(searchResultField79);
      List<SearchResultField> searchResultFieldList49 = searchResultFieldList1;
      SearchResultField searchResultField80 = new SearchResultField();
      searchResultField80.Name = "Series Firm Role";
      searchResultField80.ExportField = "SeriesFirmRoleName";
      int num96 = num95;
      int num97 = num96 + 1;
      searchResultField80.Order = num96;
      searchResultField80.Html = new SearchResultFieldHtml()
      {
        field = "SeriesFirmRoleName",
        title = "Series Firm Role",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm"
      };
      searchResultFieldList49.Add(searchResultField80);
      List<SearchResultField> searchResultFieldList50 = searchResultFieldList1;
      SearchResultField searchResultField81 = new SearchResultField();
      searchResultField81.Name = "Series Firm Liability %";
      searchResultField81.ExportField = "SeriesFirmLiability";
      int num98 = num97;
      int num99 = num98 + 1;
      searchResultField81.Order = num98;
      searchResultField81.Html = new SearchResultFieldHtml()
      {
        field = "SeriesFirmLiability",
        title = "Series Firm Liability %",
        sortable = true,
        isLeftAligned = false,
        width = "100px",
        excelWidth = "3cm",
        format = "{0:n3}",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList50.Add(searchResultField81);
      List<SearchResultField> searchResultFieldList51 = searchResultFieldList1;
      SearchResultField searchResultField82 = new SearchResultField();
      searchResultField82.Name = "Series Firm Mgmt Fee %";
      searchResultField82.ExportField = "SeriesFirmMgtFee";
      int num100 = num99;
      int num101 = num100 + 1;
      searchResultField82.Order = num100;
      searchResultField82.Html = new SearchResultFieldHtml()
      {
        field = "SeriesFirmMgtFee",
        title = "Series Firm Mgmt Fee %",
        sortable = true,
        isLeftAligned = false,
        width = "100px",
        excelWidth = "3cm",
        format = "{0:n3}",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList51.Add(searchResultField82);
      List<SearchResultField> searchResultFieldList52 = searchResultFieldList1;
      SearchResultField searchResultField83 = new SearchResultField();
      searchResultField83.Name = "Series SDC Credit %";
      searchResultField83.ExportField = "SeriesSDCCredit";
      int num102 = num101;
      int num103 = num102 + 1;
      searchResultField83.Order = num102;
      searchResultField83.Html = new SearchResultFieldHtml()
      {
        field = "SeriesSDCCredit",
        title = "Series SDC Credit %",
        sortable = true,
        isLeftAligned = false,
        width = "100px",
        excelWidth = "3cm",
        format = "{0:n3}",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList52.Add(searchResultField83);
      List<SearchResultField> searchResultFieldList53 = searchResultFieldList1;
      SearchResultField searchResultField84 = new SearchResultField();
      searchResultField84.Name = "Financial Advisor";
      searchResultField84.ExportField = "FinancialAdvisor";
      int num104 = num103;
      int num105 = num104 + 1;
      searchResultField84.Order = num104;
      searchResultField84.Html = new SearchResultFieldHtml()
      {
        field = "FinancialAdvisor",
        title = "Financial Advisor",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList53.Add(searchResultField84);
      List<SearchResultField> searchResultFieldList54 = searchResultFieldList1;
      SearchResultField searchResultField85 = new SearchResultField();
      searchResultField85.Name = "Firm Inventory";
      searchResultField85.ExportField = "FirmInventory";
      int num106 = num105;
      int num107 = num106 + 1;
      searchResultField85.Order = num106;
      searchResultField85.Html = new SearchResultFieldHtml()
      {
        field = "FirmInventory",
        title = "Firm Inventory",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList54.Add(searchResultField85);
      List<SearchResultField> searchResultFieldList55 = searchResultFieldList1;
      SearchResultField searchResultField86 = new SearchResultField();
      searchResultField86.Name = "Firm Liability %";
      searchResultField86.ExportField = "LiabilityPercentage";
      int num108 = num107;
      int num109 = num108 + 1;
      searchResultField86.Order = num108;
      searchResultField86.Html = new SearchResultFieldHtml()
      {
        field = "LiabilityPercentage",
        title = "Firm Liability %",
        sortable = true,
        isLeftAligned = false,
        width = "130px",
        excelWidth = "3cm",
        style = "text-align: right !important;",
        format = "{0:n3}",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList55.Add(searchResultField86);
      List<SearchResultField> searchResultFieldList56 = searchResultFieldList1;
      SearchResultField searchResultField87 = new SearchResultField();
      searchResultField87.Name = "Firm Mgmt Fee %";
      searchResultField87.ExportField = "FirmManagementFeePercentage";
      int num110 = num109;
      int num111 = num110 + 1;
      searchResultField87.Order = num110;
      searchResultField87.Html = new SearchResultFieldHtml()
      {
        field = "FirmManagementFeePercentage",
        title = "Firm Mgmt Fee %",
        sortable = true,
        isLeftAligned = false,
        width = "130px",
        excelWidth = "3.5cm",
        style = "text-align: right !important;",
        format = "{0:n3}",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList56.Add(searchResultField87);
      List<SearchResultField> searchResultFieldList57 = searchResultFieldList1;
      SearchResultField searchResultField88 = new SearchResultField();
      searchResultField88.Name = "Firm Role";
      searchResultField88.ExportField = "FirmRole";
      int num112 = num111;
      int num113 = num112 + 1;
      searchResultField88.Order = num112;
      searchResultField88.Html = new SearchResultFieldHtml()
      {
        field = "FirmRole",
        title = "Firm Role",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList57.Add(searchResultField88);
      List<SearchResultField> searchResultFieldList58 = searchResultFieldList1;
      SearchResultField searchResultField89 = new SearchResultField();
      searchResultField89.Name = "First Maturity";
      searchResultField89.ExportField = "=Format(fields!FirstMaturity.Value, \"MM/dd/yyyy\")";
      searchResultField89.ExportColumns = new string[1]
      {
        "FirstMaturity"
      };
      SearchResultField searchResultField90 = searchResultField89;
      int num114 = num113;
      int num115 = num114 + 1;
      searchResultField90.Order = num114;
      searchResultField89.Html = new SearchResultFieldHtml()
      {
        field = "FirstMaturity",
        title = "First Maturity",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(FirstMaturity) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField91 = searchResultField89;
      searchResultFieldList58.Add(searchResultField91);
      List<SearchResultField> searchResultFieldList59 = searchResultFieldList1;
      SearchResultField searchResultField92 = new SearchResultField();
      searchResultField92.Name = "Final Maturity";
      searchResultField92.ExportField = "=Format(fields!FinalMaturity.Value, \"MM/dd/yyyy\")";
      searchResultField92.ExportColumns = new string[1]
      {
        "FinalMaturity"
      };
      SearchResultField searchResultField93 = searchResultField92;
      int num116 = num115;
      int num117 = num116 + 1;
      searchResultField93.Order = num116;
      searchResultField92.Html = new SearchResultFieldHtml()
      {
        field = "FinalMaturity",
        title = "Final Maturity",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "3cm",
        template = "#= convertDateToString(FinalMaturity) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField94 = searchResultField92;
      searchResultFieldList59.Add(searchResultField94);
      List<SearchResultField> searchResultFieldList60 = searchResultFieldList1;
      SearchResultField searchResultField95 = new SearchResultField();
      searchResultField95.Name = "FOS Received Date & Time";
      searchResultField95.ExportField = "=Format(fields!FinalOSReceivedDate.Value, \"MM/dd/yyyy hh:mm tt\") & IIF(Len(fields!FinalOSReceivedDateTimeZone.Value)=0, \"\",\"(\") & fields!FinalOSReceivedDateTimeZone.Value & IIF(Len(fields!FinalOSReceivedDateTimeZone.Value)=0, \"\",\")\")";
      searchResultField95.ExportColumns = new string[2]
      {
        "FinalOSReceivedDate",
        "FinalOSReceivedDateTimeZone"
      };
      SearchResultField searchResultField96 = searchResultField95;
      int num118 = num117;
      int num119 = num118 + 1;
      searchResultField96.Order = num118;
      searchResultField95.Html = new SearchResultFieldHtml()
      {
        field = "FinalOSReceivedDate",
        title = "FOS Received Date & Time",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToStringDateTime(FinalOSReceivedDate,FinalOSReceivedDateTimeZone) #",
        groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
      };
      SearchResultField searchResultField97 = searchResultField95;
      searchResultFieldList60.Add(searchResultField97);
      List<SearchResultField> searchResultFieldList61 = searchResultFieldList1;
      SearchResultField searchResultField98 = new SearchResultField();
      searchResultField98.Name = "G-17 Conflict Letter";
      searchResultField98.ExportField = "G17ConflictLetter";
      int num120 = num119;
      int num121 = num120 + 1;
      searchResultField98.Order = num120;
      searchResultField98.Html = new SearchResultFieldHtml()
      {
        field = "G17ConflictLetter",
        title = "G-17 Conflict Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList61.Add(searchResultField98);
      List<SearchResultField> searchResultFieldList62 = searchResultFieldList1;
      SearchResultField searchResultField99 = new SearchResultField();
      searchResultField99.Name = "G-17 Conflict Letter Ack Date";
      searchResultField99.ExportField = "=Format(fields!G17ConflictLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField99.ExportColumns = new string[1]
      {
        "G17ConflictLetterAckDate"
      };
      SearchResultField searchResultField100 = searchResultField99;
      int num122 = num121;
      int num123 = num122 + 1;
      searchResultField100.Order = num122;
      searchResultField99.Html = new SearchResultFieldHtml()
      {
        field = "G17ConflictLetterAckDate",
        title = "G-17 Conflict Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17ConflictLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField101 = searchResultField99;
      searchResultFieldList62.Add(searchResultField101);
      List<SearchResultField> searchResultFieldList63 = searchResultFieldList1;
      SearchResultField searchResultField102 = new SearchResultField();
      searchResultField102.Name = "G-17 Conflict Letter Sent Date";
      searchResultField102.ExportField = "=Format(fields!G17ConflictLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField102.ExportColumns = new string[1]
      {
        "G17ConflictLetterSentDate"
      };
      SearchResultField searchResultField103 = searchResultField102;
      int num124 = num123;
      int num125 = num124 + 1;
      searchResultField103.Order = num124;
      searchResultField102.Html = new SearchResultFieldHtml()
      {
        field = "G17ConflictLetterSentDate",
        title = "G-17 Conflict Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17ConflictLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField104 = searchResultField102;
      searchResultFieldList63.Add(searchResultField104);
      List<SearchResultField> searchResultFieldList64 = searchResultFieldList1;
      SearchResultField searchResultField105 = new SearchResultField();
      searchResultField105.Name = "G-17 Role & Conflict Letter";
      searchResultField105.ExportField = "G17RoleDisclosureLetter";
      int num126 = num125;
      int num127 = num126 + 1;
      searchResultField105.Order = num126;
      searchResultField105.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleDisclosureLetter",
        title = "G-17 Role & Conflict Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList64.Add(searchResultField105);
      List<SearchResultField> searchResultFieldList65 = searchResultFieldList1;
      SearchResultField searchResultField106 = new SearchResultField();
      searchResultField106.Name = "G-17 Role & Conflict Letter Ack Date";
      searchResultField106.ExportField = "=Format(fields!G17RoleDisclosureLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField106.ExportColumns = new string[1]
      {
        "G17RoleDisclosureLetterAckDate"
      };
      SearchResultField searchResultField107 = searchResultField106;
      int num128 = num127;
      int num129 = num128 + 1;
      searchResultField107.Order = num128;
      searchResultField106.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleDisclosureLetterAckDate",
        title = "G-17 Role & Conflict Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleDisclosureLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField108 = searchResultField106;
      searchResultFieldList65.Add(searchResultField108);
      List<SearchResultField> searchResultFieldList66 = searchResultFieldList1;
      SearchResultField searchResultField109 = new SearchResultField();
      searchResultField109.Name = "G-17 Role & Conflict Letter Sent Date";
      searchResultField109.ExportField = "=Format(fields!G17RoleDisclosureLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField109.ExportColumns = new string[1]
      {
        "G17RoleDisclosureLetterSentDate"
      };
      SearchResultField searchResultField110 = searchResultField109;
      int num130 = num129;
      int num131 = num130 + 1;
      searchResultField110.Order = num130;
      searchResultField109.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleDisclosureLetterSentDate",
        title = "G-17 Role & Conflict Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleDisclosureLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField111 = searchResultField109;
      searchResultFieldList66.Add(searchResultField111);
      List<SearchResultField> searchResultFieldList67 = searchResultFieldList1;
      SearchResultField searchResultField112 = new SearchResultField();
      searchResultField112.Name = "G-17 Role Letter";
      searchResultField112.ExportField = "G17RoleLetter";
      int num132 = num131;
      int num133 = num132 + 1;
      searchResultField112.Order = num132;
      searchResultField112.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleLetter",
        title = "G-17 Role Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList67.Add(searchResultField112);
      List<SearchResultField> searchResultFieldList68 = searchResultFieldList1;
      SearchResultField searchResultField113 = new SearchResultField();
      searchResultField113.Name = "G-17 Role Letter Ack Date";
      searchResultField113.ExportField = "=Format(fields!G17RoleLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField113.ExportColumns = new string[1]
      {
        "G17RoleLetterAckDate"
      };
      SearchResultField searchResultField114 = searchResultField113;
      int num134 = num133;
      int num135 = num134 + 1;
      searchResultField114.Order = num134;
      searchResultField113.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleLetterAckDate",
        title = "G-17 Role Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField115 = searchResultField113;
      searchResultFieldList68.Add(searchResultField115);
      List<SearchResultField> searchResultFieldList69 = searchResultFieldList1;
      SearchResultField searchResultField116 = new SearchResultField();
      searchResultField116.Name = "G-17 Role Letter Sent Date";
      searchResultField116.ExportField = "=Format(fields!G17RoleLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField116.ExportColumns = new string[1]
      {
        "G17RoleLetterSentDate"
      };
      SearchResultField searchResultField117 = searchResultField116;
      int num136 = num135;
      int num137 = num136 + 1;
      searchResultField117.Order = num136;
      searchResultField116.Html = new SearchResultFieldHtml()
      {
        field = "G17RoleLetterSentDate",
        title = "G-17 Role Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17RoleLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField118 = searchResultField116;
      searchResultFieldList69.Add(searchResultField118);
      List<SearchResultField> searchResultFieldList70 = searchResultFieldList1;
      SearchResultField searchResultField119 = new SearchResultField();
      searchResultField119.Name = "G-17 Structure Letter";
      searchResultField119.ExportField = "G17StructureLetter";
      int num138 = num137;
      int num139 = num138 + 1;
      searchResultField119.Order = num138;
      searchResultField119.Html = new SearchResultFieldHtml()
      {
        field = "G17StructureLetter",
        title = "G-17 Structure Letter",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList70.Add(searchResultField119);
      List<SearchResultField> searchResultFieldList71 = searchResultFieldList1;
      SearchResultField searchResultField120 = new SearchResultField();
      searchResultField120.Name = "G-17 Structure Letter Ack Date";
      searchResultField120.ExportField = "=Format(fields!G17StructureLetterAckDate.Value, \"MM/dd/yyyy\")";
      searchResultField120.ExportColumns = new string[1]
      {
        "G17StructureLetterAckDate"
      };
      SearchResultField searchResultField121 = searchResultField120;
      int num140 = num139;
      int num141 = num140 + 1;
      searchResultField121.Order = num140;
      searchResultField120.Html = new SearchResultFieldHtml()
      {
        field = "G17StructureLetterAckDate",
        title = "G-17 Structure Letter Ack Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17StructureLetterAckDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField122 = searchResultField120;
      searchResultFieldList71.Add(searchResultField122);
      List<SearchResultField> searchResultFieldList72 = searchResultFieldList1;
      SearchResultField searchResultField123 = new SearchResultField();
      searchResultField123.Name = "G-17 Structure Letter Sent Date";
      searchResultField123.ExportField = "=Format(fields!G17StructureLetterSentDate.Value, \"MM/dd/yyyy\")";
      searchResultField123.ExportColumns = new string[1]
      {
        "G17StructureLetterSentDate"
      };
      SearchResultField searchResultField124 = searchResultField123;
      int num142 = num141;
      int num143 = num142 + 1;
      searchResultField124.Order = num142;
      searchResultField123.Html = new SearchResultFieldHtml()
      {
        field = "G17StructureLetterSentDate",
        title = "G-17 Structure Letter Sent Date",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "4cm",
        template = "#= convertDateToString(G17StructureLetterSentDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField125 = searchResultField123;
      searchResultFieldList72.Add(searchResultField125);
      List<SearchResultField> searchResultFieldList73 = searchResultFieldList1;
      SearchResultField searchResultField126 = new SearchResultField();
      searchResultField126.Name = "G-32 Submission Date & Time";
      searchResultField126.ExportField = "=Format(fields!G32SubmissionDate.Value, \"MM/dd/yyyy hh:mm tt\") & IIF(Len(fields!G32SubmissionDateTimeZone.Value)=0, \"\",\"(\") & fields!G32SubmissionDateTimeZone.Value & IIF(Len(fields!G32SubmissionDateTimeZone.Value)=0, \"\",\")\")";
      searchResultField126.ExportColumns = new string[2]
      {
        "G32SubmissionDate",
        "G32SubmissionDateTimeZone"
      };
      SearchResultField searchResultField127 = searchResultField126;
      int num144 = num143;
      int num145 = num144 + 1;
      searchResultField127.Order = num144;
      searchResultField126.Html = new SearchResultFieldHtml()
      {
        field = "G32SubmissionDate",
        title = "G-32 Submission Date & Time",
        sortable = true,
        isLeftAligned = true,
        width = "220px",
        excelWidth = "5cm",
        template = "#= convertDateToStringDateTime(G32SubmissionDate,G32SubmissionDateTimeZone) #",
        groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
      };
      SearchResultField searchResultField128 = searchResultField126;
      searchResultFieldList73.Add(searchResultField128);
      List<SearchResultField> searchResultFieldList74 = searchResultFieldList1;
      SearchResultField searchResultField129 = new SearchResultField();
      searchResultField129.Name = "Good Faith Amount";
      searchResultField129.ExportField = "GoodFaithAmount";
      int num146 = num145;
      int num147 = num146 + 1;
      searchResultField129.Order = num146;
      searchResultField129.Html = new SearchResultFieldHtml()
      {
        field = "GoodFaithAmount",
        title = "Good Faith Amount",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList74.Add(searchResultField129);
      List<SearchResultField> searchResultFieldList75 = searchResultFieldList1;
      SearchResultField searchResultField130 = new SearchResultField();
      searchResultField130.Name = "Good Faith Date";
      searchResultField130.ExportField = "=Format(fields!GoodFaithDate.Value, \"MM/dd/yyyy\")";
      searchResultField130.ExportColumns = new string[1]
      {
        "GoodFaithDate"
      };
      SearchResultField searchResultField131 = searchResultField130;
      int num148 = num147;
      int num149 = num148 + 1;
      searchResultField131.Order = num148;
      searchResultField130.Html = new SearchResultFieldHtml()
      {
        field = "GoodFaithDate",
        title = "Good Faith Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(GoodFaithDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField132 = searchResultField130;
      searchResultFieldList75.Add(searchResultField132);
      List<SearchResultField> searchResultFieldList76 = searchResultFieldList1;
      SearchResultField searchResultField133 = new SearchResultField();
      searchResultField133.Name = "Gross Spread($/1,000)";
      searchResultField133.ExportField = "GrossSpread";
      int num150 = num149;
      int num151 = num150 + 1;
      searchResultField133.Order = num150;
      searchResultField133.Html = new SearchResultFieldHtml()
      {
        field = "GrossSpread",
        title = "Gross Spread($/1,000)",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c3}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.000"
      };
      searchResultFieldList76.Add(searchResultField133);
      List<SearchResultField> searchResultFieldList77 = searchResultFieldList1;
      SearchResultField searchResultField134 = new SearchResultField();
      searchResultField134.Name = "Insurance";
      searchResultField134.ExportField = "Insurance";
      int num152 = num151;
      int num153 = num152 + 1;
      searchResultField134.Order = num152;
      searchResultField134.Html = new SearchResultFieldHtml()
      {
        field = "Insurance",
        title = "Insurance",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList77.Add(searchResultField134);
      List<SearchResultField> searchResultFieldList78 = searchResultFieldList1;
      SearchResultField searchResultField135 = new SearchResultField();
      searchResultField135.Name = "Insurance Fee (bps on ds)";
      searchResultField135.ExportField = "InsuranceFee";
      int num154 = num153;
      int num155 = num154 + 1;
      searchResultField135.Order = num154;
      searchResultField135.Html = new SearchResultFieldHtml()
      {
        field = "InsuranceFee",
        title = "Insurance Fee (bps on ds)",
        sortable = true,
        isLeftAligned = false,
        width = "120px",
        excelWidth = "3.9cm",
        format = "{0:N3}",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList78.Add(searchResultField135);
      List<SearchResultField> searchResultFieldList79 = searchResultFieldList1;
      SearchResultField searchResultField136 = new SearchResultField();
      searchResultField136.Name = "Interest Rate Type";
      searchResultField136.ExportField = "RateType";
      int num156 = num155;
      int num157 = num156 + 1;
      searchResultField136.Order = num156;
      searchResultField136.Html = new SearchResultFieldHtml()
      {
        field = "RateType",
        title = "Interest Rate Type",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList79.Add(searchResultField136);
      List<SearchResultField> searchResultFieldList80 = searchResultFieldList1;
      SearchResultField searchResultField137 = new SearchResultField();
      searchResultField137.Name = "IRMA Expiry Date";
      searchResultField137.ExportField = "=Format(fields!IRMAMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField137.ExportColumns = new string[1]
      {
        "IRMAMAExemptionExpirationDate"
      };
      SearchResultField searchResultField138 = searchResultField137;
      int num158 = num157;
      int num159 = num158 + 1;
      searchResultField138.Order = num158;
      searchResultField137.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemptionExpirationDate",
        title = "IRMA Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(IRMAMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField139 = searchResultField137;
      searchResultFieldList80.Add(searchResultField139);
      List<SearchResultField> searchResultFieldList81 = searchResultFieldList1;
      SearchResultField searchResultField140 = new SearchResultField();
      searchResultField140.Name = "IRMA MA Exemption";
      searchResultField140.ExportField = "IRMAMAExemption";
      int num160 = num159;
      int num161 = num160 + 1;
      searchResultField140.Order = num160;
      searchResultField140.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemption",
        title = "IRMA MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList81.Add(searchResultField140);
      List<SearchResultField> searchResultFieldList82 = searchResultFieldList1;
      SearchResultField searchResultField141 = new SearchResultField();
      searchResultField141.Name = "IRMA Start Date";
      searchResultField141.ExportField = "=Format(fields!IRMAMAExemptionStartDate.Value, \"MM/dd/yyyy\")";
      searchResultField141.ExportColumns = new string[1]
      {
        "IRMAMAExemptionStartDate"
      };
      SearchResultField searchResultField142 = searchResultField141;
      int num162 = num161;
      int num163 = num162 + 1;
      searchResultField142.Order = num162;
      searchResultField141.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemptionStartDate",
        title = "IRMA Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(IRMAMAExemptionStartDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField143 = searchResultField141;
      searchResultFieldList82.Add(searchResultField143);
      List<SearchResultField> searchResultFieldList83 = searchResultFieldList1;
      SearchResultField searchResultField144 = new SearchResultField();
      searchResultField144.Name = "Is Advance Refunding?";
      searchResultField144.ExportField = "AdvanceRefunding";
      int num164 = num163;
      int num165 = num164 + 1;
      searchResultField144.Order = num164;
      searchResultField144.Html = new SearchResultFieldHtml()
      {
        field = "AdvanceRefunding",
        title = "Is Advance Refunding?",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "2.6cm"
      };
      searchResultFieldList83.Add(searchResultField144);
      List<SearchResultField> searchResultFieldList84 = searchResultFieldList1;
      SearchResultField searchResultField145 = new SearchResultField();
      searchResultField145.Name = "Issuer's Counsel";
      searchResultField145.ExportField = "IssuerCounsel";
      int num166 = num165;
      int num167 = num166 + 1;
      searchResultField145.Order = num166;
      searchResultField145.Html = new SearchResultFieldHtml()
      {
        field = "IssuerCounsel",
        title = "Issuer's Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList84.Add(searchResultField145);
      List<SearchResultField> searchResultFieldList85 = searchResultFieldList1;
      SearchResultField searchResultField146 = new SearchResultField();
      searchResultField146.Name = "Job Number";
      searchResultField146.ExportField = "JobNumber";
      int num168 = num167;
      int num169 = num168 + 1;
      searchResultField146.Order = num168;
      searchResultField146.Html = new SearchResultFieldHtml()
      {
        field = "JobNumber",
        title = "Job Number",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList85.Add(searchResultField146);
      List<SearchResultField> searchResultFieldList86 = searchResultFieldList1;
      SearchResultField searchResultField147 = new SearchResultField();
      searchResultField147.Name = "Joint Senior Mgr - Book Running";
      searchResultField147.ExportField = "JointSeniorMgrBookRunning";
      int num170 = num169;
      int num171 = num170 + 1;
      searchResultField147.Order = num170;
      searchResultField147.Html = new SearchResultFieldHtml()
      {
        field = "JointSeniorMgrBookRunning",
        title = "Joint Senior Mgr - Book Running",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList86.Add(searchResultField147);
      List<SearchResultField> searchResultFieldList87 = searchResultFieldList1;
      SearchResultField searchResultField148 = new SearchResultField();
      searchResultField148.Name = "Joint Senior Mgr - Non Book Running";
      searchResultField148.ExportField = "JointSeniorMgrNonBookRunning";
      int num172 = num171;
      int num173 = num172 + 1;
      searchResultField148.Order = num172;
      searchResultField148.Html = new SearchResultFieldHtml()
      {
        field = "JointSeniorMgrNonBookRunning",
        title = "Joint Senior Mgr - Non Book Running",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList87.Add(searchResultField148);
      List<SearchResultField> searchResultFieldList88 = searchResultFieldList1;
      SearchResultField searchResultField149 = new SearchResultField();
      searchResultField149.Name = "Lead Banker";
      searchResultField149.ExportField = "LeadBanker";
      int num174 = num173;
      int num175 = num174 + 1;
      searchResultField149.Order = num174;
      searchResultField149.Html = new SearchResultFieldHtml()
      {
        field = "LeadBanker",
        title = "Lead Banker",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList88.Add(searchResultField149);
      List<SearchResultField> searchResultFieldList89 = searchResultFieldList1;
      SearchResultField searchResultField150 = new SearchResultField();
      searchResultField150.Name = "Maturity Period";
      searchResultField150.ExportField = "MaturityPeriod";
      int num176 = num175;
      int num177 = num176 + 1;
      searchResultField150.Order = num176;
      searchResultField150.Html = new SearchResultFieldHtml()
      {
        field = "MaturityPeriod",
        title = "Maturity Period",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "4cm"
      };
      searchResultFieldList89.Add(searchResultField150);
      List<SearchResultField> searchResultFieldList90 = searchResultFieldList1;
      SearchResultField searchResultField151 = new SearchResultField();
      searchResultField151.Name = "Minimum Denomination";
      searchResultField151.ExportField = "Denomination";
      int num178 = num177;
      int num179 = num178 + 1;
      searchResultField151.Order = num178;
      searchResultField151.Html = new SearchResultFieldHtml()
      {
        field = "Denomination",
        title = "Minimum Denomination",
        sortable = true,
        isLeftAligned = false,
        width = "180px",
        excelWidth = "4.2cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList90.Add(searchResultField151);
      List<SearchResultField> searchResultFieldList91 = searchResultFieldList1;
      SearchResultField searchResultField152 = new SearchResultField();
      searchResultField152.Name = "MS Banking Group";
      searchResultField152.ExportField = "GeneralCategory";
      int num180 = num179;
      int num181 = num180 + 1;
      searchResultField152.Order = num180;
      searchResultField152.Html = new SearchResultFieldHtml()
      {
        field = "GeneralCategory",
        title = "MS Banking Group",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList91.Add(searchResultField152);
      List<SearchResultField> searchResultFieldList92 = searchResultFieldList1;
      SearchResultField searchResultField153 = new SearchResultField();
      searchResultField153.Name = "Non Lead Banker";
      searchResultField153.ExportField = "Banker";
      int num182 = num181;
      int num183 = num182 + 1;
      searchResultField153.Order = num182;
      searchResultField153.Html = new SearchResultFieldHtml()
      {
        field = "Banker",
        title = "Non Lead Banker",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList92.Add(searchResultField153);
      List<SearchResultField> searchResultFieldList93 = searchResultFieldList1;
      SearchResultField searchResultField154 = new SearchResultField();
      searchResultField154.Name = "None MA Exemption";
      searchResultField154.ExportField = "NoneMAExemption";
      int num184 = num183;
      int num185 = num184 + 1;
      searchResultField154.Order = num184;
      searchResultField154.Html = new SearchResultFieldHtml()
      {
        field = "NoneMAExemption",
        title = "None MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList93.Add(searchResultField154);
      List<SearchResultField> searchResultFieldList94 = searchResultFieldList1;
      SearchResultField searchResultField155 = new SearchResultField();
      searchResultField155.Name = "None MA Exemption Start Date";
      searchResultField155.ExportField = "=Format(fields!NoneMAExemptionStartDate.Value, \"MM/dd/yyyy\")";
      searchResultField155.ExportColumns = new string[1]
      {
        "NoneMAExemptionStartDate"
      };
      SearchResultField searchResultField156 = searchResultField155;
      int num186 = num185;
      int num187 = num186 + 1;
      searchResultField156.Order = num186;
      searchResultField155.Html = new SearchResultFieldHtml()
      {
        field = "NoneMAExemptionStartDate",
        title = "None MA Exemption Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(NoneMAExemptionStartDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField157 = searchResultField155;
      searchResultFieldList94.Add(searchResultField157);
      List<SearchResultField> searchResultFieldList95 = searchResultFieldList1;
      SearchResultField searchResultField158 = new SearchResultField();
      searchResultField158.Name = "None MA Exemption Expiry Date";
      searchResultField158.ExportField = "=Format(fields!NoneMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField158.ExportColumns = new string[1]
      {
        "NoneMAExemptionExpirationDate"
      };
      SearchResultField searchResultField159 = searchResultField158;
      int num188 = num187;
      int num189 = num188 + 1;
      searchResultField159.Order = num188;
      searchResultField158.Html = new SearchResultFieldHtml()
      {
        field = "NoneMAExemptionExpirationDate",
        title = "None MA Exemption Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(NoneMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField160 = searchResultField158;
      searchResultFieldList95.Add(searchResultField160);
      List<SearchResultField> searchResultFieldList96 = searchResultFieldList1;
      SearchResultField searchResultField161 = new SearchResultField();
      searchResultField161.Name = "Other Advisor Agents";
      searchResultField161.ExportField = "OtherAdvisorAgents";
      int num190 = num189;
      int num191 = num190 + 1;
      searchResultField161.Order = num190;
      searchResultField161.Html = new SearchResultFieldHtml()
      {
        field = "OtherAdvisorAgents",
        title = "Other Advisor Agents",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList96.Add(searchResultField161);
      List<SearchResultField> searchResultFieldList97 = searchResultFieldList1;
      SearchResultField searchResultField162 = new SearchResultField();
      searchResultField162.Name = "Other Counsels";
      searchResultField162.ExportField = "OtherCounsels";
      int num192 = num191;
      int num193 = num192 + 1;
      searchResultField162.Order = num192;
      searchResultField162.Html = new SearchResultFieldHtml()
      {
        field = "OtherCounsels",
        title = "Other Counsels",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList97.Add(searchResultField162);
      List<SearchResultField> searchResultFieldList98 = searchResultFieldList1;
      SearchResultField searchResultField163 = new SearchResultField();
      searchResultField163.Name = "Other Partners";
      searchResultField163.ExportField = "OtherPartners";
      int num194 = num193;
      int num195 = num194 + 1;
      searchResultField163.Order = num194;
      searchResultField163.Html = new SearchResultFieldHtml()
      {
        field = "OtherPartners",
        title = "Other Partners",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList98.Add(searchResultField163);
      List<SearchResultField> searchResultFieldList99 = searchResultFieldList1;
      SearchResultField searchResultField164 = new SearchResultField();
      searchResultField164.Name = "Other Syndicate Members";
      searchResultField164.ExportField = "OtherSyndicateMembers";
      int num196 = num195;
      int num197 = num196 + 1;
      searchResultField164.Order = num196;
      searchResultField164.Html = new SearchResultFieldHtml()
      {
        field = "OtherSyndicateMembers",
        title = "Other Syndicate Members",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList99.Add(searchResultField164);
      List<SearchResultField> searchResultFieldList100 = searchResultFieldList1;
      SearchResultField searchResultField165 = new SearchResultField();
      searchResultField165.Name = "Par Amount";
      searchResultField165.ExportField = "ParAmount";
      int num198 = num197;
      int num199 = num198 + 1;
      searchResultField165.Order = num198;
      searchResultField165.Html = new SearchResultFieldHtml()
      {
        field = "ParAmount",
        title = "Par Amount",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        excelWidth = "5cm",
        format = "{0:c0}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0"
      };
      searchResultFieldList100.Add(searchResultField165);
      List<SearchResultField> searchResultFieldList101 = searchResultFieldList1;
      SearchResultField searchResultField166 = new SearchResultField();
      searchResultField166.Name = "Paying Agent";
      searchResultField166.ExportField = "PayingAgent";
      int num200 = num199;
      int num201 = num200 + 1;
      searchResultField166.Order = num200;
      searchResultField166.Html = new SearchResultFieldHtml()
      {
        field = "PayingAgent",
        title = "Paying Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList101.Add(searchResultField166);
      List<SearchResultField> searchResultFieldList102 = searchResultFieldList1;
      SearchResultField searchResultField167 = new SearchResultField();
      searchResultField167.Name = "Pricing Date";
      searchResultField167.ExportField = "=Format(fields!PricingDate.Value, \"MM/dd/yyyy\")";
      searchResultField167.ExportColumns = new string[1]
      {
        "PricingDate"
      };
      SearchResultField searchResultField168 = searchResultField167;
      int num202 = num201;
      int num203 = num202 + 1;
      searchResultField168.Order = num202;
      searchResultField167.Html = new SearchResultFieldHtml()
      {
        field = "PricingDate",
        title = "Pricing Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(PricingDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField169 = searchResultField167;
      searchResultFieldList102.Add(searchResultField169);
      List<SearchResultField> searchResultFieldList103 = searchResultFieldList1;
      SearchResultField searchResultField170 = new SearchResultField();
      searchResultField170.Name = "Quant";
      searchResultField170.ExportField = "Quant";
      int num204 = num203;
      int num205 = num204 + 1;
      searchResultField170.Order = num204;
      searchResultField170.Html = new SearchResultFieldHtml()
      {
        field = "Quant",
        title = "Quant",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList103.Add(searchResultField170);
      List<SearchResultField> searchResultFieldList104 = searchResultFieldList1;
      SearchResultField searchResultField171 = new SearchResultField();
      searchResultField171.Name = "Remarketing Agent";
      searchResultField171.ExportField = "RemarketingAgent";
      int num206 = num205;
      int num207 = num206 + 1;
      searchResultField171.Order = num206;
      searchResultField171.Html = new SearchResultFieldHtml()
      {
        field = "RemarketingAgent",
        title = "Remarketing Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList104.Add(searchResultField171);
      List<SearchResultField> searchResultFieldList105 = searchResultFieldList1;
      SearchResultField searchResultField172 = new SearchResultField();
      searchResultField172.Name = "RFP MA Exemption";
      searchResultField172.ExportField = "RFPMAExemption";
      int num208 = num207;
      int num209 = num208 + 1;
      searchResultField172.Order = num208;
      searchResultField172.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemption",
        title = "RFP MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "170px",
        excelWidth = "5cm"
      };
      searchResultFieldList105.Add(searchResultField172);
      List<SearchResultField> searchResultFieldList106 = searchResultFieldList1;
      SearchResultField searchResultField173 = new SearchResultField();
      searchResultField173.Name = "RFP MA Exemption Start Date";
      searchResultField173.ExportField = "=Format(fields!RFPMAExemptionStartDate.Value, \"MM/dd/yyyy\")";
      searchResultField173.ExportColumns = new string[1]
      {
        "RFPMAExemptionStartDate"
      };
      SearchResultField searchResultField174 = searchResultField173;
      int num210 = num209;
      int num211 = num210 + 1;
      searchResultField174.Order = num210;
      searchResultField173.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemptionStartDate",
        title = "RFP MA Exemption Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToString(RFPMAExemptionStartDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField175 = searchResultField173;
      searchResultFieldList106.Add(searchResultField175);
      List<SearchResultField> searchResultFieldList107 = searchResultFieldList1;
      SearchResultField searchResultField176 = new SearchResultField();
      searchResultField176.Name = "RFP MA Exemption Expiry Date";
      searchResultField176.ExportField = "=Format(fields!RFPMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField176.ExportColumns = new string[1]
      {
        "RFPMAExemptionExpirationDate"
      };
      SearchResultField searchResultField177 = searchResultField176;
      int num212 = num211;
      int num213 = num212 + 1;
      searchResultField177.Order = num212;
      searchResultField176.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemptionExpirationDate",
        title = "RFP MA Exemption Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToString(RFPMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField178 = searchResultField176;
      searchResultFieldList107.Add(searchResultField178);
      List<SearchResultField> searchResultFieldList108 = searchResultFieldList1;
      SearchResultField searchResultField179 = new SearchResultField();
      searchResultField179.Name = "Security";
      searchResultField179.ExportField = "Security";
      int num214 = num213;
      int num215 = num214 + 1;
      searchResultField179.Order = num214;
      searchResultField179.Html = new SearchResultFieldHtml()
      {
        field = "Security",
        title = "Security",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList108.Add(searchResultField179);
      List<SearchResultField> searchResultFieldList109 = searchResultFieldList1;
      SearchResultField searchResultField180 = new SearchResultField();
      searchResultField180.Name = "Security Type (General)";
      searchResultField180.ExportField = "SecurityType";
      int num216 = num215;
      int num217 = num216 + 1;
      searchResultField180.Order = num216;
      searchResultField180.Html = new SearchResultFieldHtml()
      {
        field = "SecurityType",
        title = "Security Type (General)",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList109.Add(searchResultField180);
      List<SearchResultField> searchResultFieldList110 = searchResultFieldList1;
      SearchResultField searchResultField181 = new SearchResultField();
      searchResultField181.Name = "Selling Group Member";
      searchResultField181.ExportField = "SellingGroupMember";
      int num218 = num217;
      int num219 = num218 + 1;
      searchResultField181.Order = num218;
      searchResultField181.Html = new SearchResultFieldHtml()
      {
        field = "SellingGroupMember",
        title = "Selling Group Member",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList110.Add(searchResultField181);
      List<SearchResultField> searchResultFieldList111 = searchResultFieldList1;
      SearchResultField searchResultField182 = new SearchResultField();
      searchResultField182.Name = "Senior Manager";
      searchResultField182.ExportField = "SeniorManager";
      int num220 = num219;
      int num221 = num220 + 1;
      searchResultField182.Order = num220;
      searchResultField182.Html = new SearchResultFieldHtml()
      {
        field = "SeniorManager",
        title = "Senior Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList111.Add(searchResultField182);
      List<SearchResultField> searchResultFieldList112 = searchResultFieldList1;
      SearchResultField searchResultField183 = new SearchResultField();
      searchResultField183.Name = "Series";
      searchResultField183.ExportField = "SeriesName";
      int num222 = num221;
      int num223 = num222 + 1;
      searchResultField183.Order = num222;
      searchResultField183.Html = new SearchResultFieldHtml()
      {
        field = "SeriesName",
        title = "Series",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList112.Add(searchResultField183);
      List<SearchResultField> searchResultFieldList113 = searchResultFieldList1;
      SearchResultField searchResultField184 = new SearchResultField();
      searchResultField184.Name = "Series Code";
      searchResultField184.ExportField = "SeriesCode";
      int num224 = num223;
      int num225 = num224 + 1;
      searchResultField184.Order = num224;
      searchResultField184.Html = new SearchResultFieldHtml()
      {
        field = "SeriesCode",
        title = "Series Code",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList113.Add(searchResultField184);
      List<SearchResultField> searchResultFieldList114 = searchResultFieldList1;
      SearchResultField searchResultField185 = new SearchResultField();
      searchResultField185.Name = "Series Delivery Date";
      searchResultField185.ExportField = "=Format(fields!SeriesSettlementDate.Value, \"MM/dd/yyyy\")";
      searchResultField185.ExportColumns = new string[1]
      {
        "SeriesSettlementDate"
      };
      SearchResultField searchResultField186 = searchResultField185;
      int num226 = num225;
      int num227 = num226 + 1;
      searchResultField186.Order = num226;
      searchResultField185.Html = new SearchResultFieldHtml()
      {
        field = "SeriesSettlementDate",
        title = "Series Delivery Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(SeriesSettlementDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField187 = searchResultField185;
      searchResultFieldList114.Add(searchResultField187);
      List<SearchResultField> searchResultFieldList115 = searchResultFieldList1;
      SearchResultField searchResultField188 = new SearchResultField();
      searchResultField188.Name = "Sole Manager";
      searchResultField188.ExportField = "SoleManager";
      int num228 = num227;
      int num229 = num228 + 1;
      searchResultField188.Order = num228;
      searchResultField188.Html = new SearchResultFieldHtml()
      {
        field = "SoleManager",
        title = "Sole Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList115.Add(searchResultField188);
      List<SearchResultField> searchResultFieldList116 = searchResultFieldList1;
      SearchResultField searchResultField189 = new SearchResultField();
      searchResultField189.Name = "State Tax";
      searchResultField189.ExportField = "SeriesStateTaxable";
      int num230 = num229;
      int num231 = num230 + 1;
      searchResultField189.Order = num230;
      searchResultField189.Html = new SearchResultFieldHtml()
      {
        field = "SeriesStateTaxable",
        title = "State Tax",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList116.Add(searchResultField189);
      List<SearchResultField> searchResultFieldList117 = searchResultFieldList1;
      SearchResultField searchResultField190 = new SearchResultField();
      searchResultField190.Name = "Supervisory Principal";
      searchResultField190.ExportField = "SupervisoryPrincipal";
      int num232 = num231;
      int num233 = num232 + 1;
      searchResultField190.Order = num232;
      searchResultField190.Html = new SearchResultFieldHtml()
      {
        field = "SupervisoryPrincipal",
        title = "Supervisory Principal",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList117.Add(searchResultField190);
      List<SearchResultField> searchResultFieldList118 = searchResultFieldList1;
      SearchResultField searchResultField191 = new SearchResultField();
      searchResultField191.Name = "Syndicate Structure";
      searchResultField191.ExportField = "PriorityOfOrders";
      int num234 = num233;
      int num235 = num234 + 1;
      searchResultField191.Order = num234;
      searchResultField191.Html = new SearchResultFieldHtml()
      {
        field = "PriorityOfOrders",
        title = "Syndicate Structure",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList118.Add(searchResultField191);
      List<SearchResultField> searchResultFieldList119 = searchResultFieldList1;
      SearchResultField searchResultField192 = new SearchResultField();
      searchResultField192.Name = "Syndicate Team";
      searchResultField192.ExportField = "Underwriter";
      int num236 = num235;
      int num237 = num236 + 1;
      searchResultField192.Order = num236;
      searchResultField192.Html = new SearchResultFieldHtml()
      {
        field = "Underwriter",
        title = "Syndicate Team",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList119.Add(searchResultField192);
      List<SearchResultField> searchResultFieldList120 = searchResultFieldList1;
      SearchResultField searchResultField193 = new SearchResultField();
      searchResultField193.Name = "Transaction Setup By";
      searchResultField193.ExportField = "CreatedBy";
      int num238 = num237;
      int num239 = num238 + 1;
      searchResultField193.Order = num238;
      searchResultField193.Html = new SearchResultFieldHtml()
      {
        field = "CreatedBy",
        title = "Transaction Setup By",
        sortable = true,
        isLeftAligned = true,
        width = "160px",
        excelWidth = "5cm"
      };
      searchResultFieldList120.Add(searchResultField193);
      List<SearchResultField> searchResultFieldList121 = searchResultFieldList1;
      SearchResultField searchResultField194 = new SearchResultField();
      searchResultField194.Name = "Trustee";
      searchResultField194.ExportField = "Trustee";
      int num240 = num239;
      int num241 = num240 + 1;
      searchResultField194.Order = num240;
      searchResultField194.Html = new SearchResultFieldHtml()
      {
        field = "Trustee",
        title = "Trustee",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList121.Add(searchResultField194);
      List<SearchResultField> searchResultFieldList122 = searchResultFieldList1;
      SearchResultField searchResultField195 = new SearchResultField();
      searchResultField195.Name = "Underlying Ratings (Moody's/S&P/Fitch/Kroll)";
      searchResultField195.ExportField = "UnderlyingRating";
      int num242 = num241;
      int num243 = num242 + 1;
      searchResultField195.Order = num242;
      searchResultField195.Html = new SearchResultFieldHtml()
      {
        field = "UnderlyingRating",
        title = "Underlying Ratings (Moody's/S&P/Fitch/Kroll)",
        sortable = true,
        isLeftAligned = true,
        width = "180px",
        excelWidth = "5cm"
      };
      searchResultFieldList122.Add(searchResultField195);
      List<SearchResultField> searchResultFieldList123 = searchResultFieldList1;
      SearchResultField searchResultField196 = new SearchResultField();
      searchResultField196.Name = "Underwriter's Counsel";
      searchResultField196.ExportField = "UnderwriterCounsel";
      int num244 = num243;
      int num245 = num244 + 1;
      searchResultField196.Order = num244;
      searchResultField196.Html = new SearchResultFieldHtml()
      {
        field = "UnderwriterCounsel",
        title = "Underwriter's Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList123.Add(searchResultField196);
      List<SearchResultField> searchResultFieldList124 = searchResultFieldList1;
      SearchResultField searchResultField197 = new SearchResultField();
      searchResultField197.Name = "Use of Proceeds";
      searchResultField197.ExportField = "UseOfProceeds";
      int num246 = num245;
      int num247 = num246 + 1;
      searchResultField197.Order = num246;
      searchResultField197.Html = new SearchResultFieldHtml()
      {
        field = "UseOfProceeds",
        title = "Use of Proceeds",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList124.Add(searchResultField197);
      List<SearchResultField> searchResultFieldList125 = searchResultFieldList1;
      SearchResultField searchResultField198 = new SearchResultField();
      searchResultField198.Name = "UW MA Exemption";
      searchResultField198.ExportField = "UWMAExemption";
      int num248 = num247;
      int num249 = num248 + 1;
      searchResultField198.Order = num248;
      searchResultField198.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemption",
        title = "UW MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList125.Add(searchResultField198);
      List<SearchResultField> searchResultFieldList126 = searchResultFieldList1;
      SearchResultField searchResultField199 = new SearchResultField();
      searchResultField199.Name = "UW MA Exemption Expiry Date";
      searchResultField199.ExportField = "=Format(fields!UWMAExemptionExpirationDate.Value, \"MM/dd/yyyy\")";
      searchResultField199.ExportColumns = new string[1]
      {
        "UWMAExemptionExpirationDate"
      };
      SearchResultField searchResultField200 = searchResultField199;
      int num250 = num249;
      int num251 = num250 + 1;
      searchResultField200.Order = num250;
      searchResultField199.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemptionExpirationDate",
        title = "UW MA Exemption Expiry Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(UWMAExemptionExpirationDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField201 = searchResultField199;
      searchResultFieldList126.Add(searchResultField201);
      List<SearchResultField> searchResultFieldList127 = searchResultFieldList1;
      SearchResultField searchResultField202 = new SearchResultField();
      searchResultField202.Name = "UW MA Exemption Start Date";
      searchResultField202.ExportField = "=Format(fields!UWMAExemptionStartDate.Value, \"MM/dd/yyyy\")";
      searchResultField202.ExportColumns = new string[1]
      {
        "UWMAExemptionStartDate"
      };
      SearchResultField searchResultField203 = searchResultField202;
      int num252 = num251;
      int num253 = num252 + 1;
      searchResultField203.Order = num252;
      searchResultField202.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemptionStartDate",
        title = "UW MA Exemption Start Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(UWMAExemptionStartDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField204 = searchResultField202;
      searchResultFieldList127.Add(searchResultField204);
      List<SearchResultField> searchResultFieldList128 = searchResultFieldList1;
      SearchResultField searchResultField205 = new SearchResultField();
      searchResultField205.Name = "Retail Order Period Date";
      searchResultField205.ExportField = "=Format(fields!ROPDate.Value, \"MM/dd/yyyy\")";
      searchResultField205.ExportColumns = new string[1]
      {
        "ROPDate"
      };
      SearchResultField searchResultField206 = searchResultField205;
      int num254 = num253;
      int num255 = num254 + 1;
      searchResultField206.Order = num254;
      searchResultField205.Html = new SearchResultFieldHtml()
      {
        field = "ROPDate",
        title = "Retail Order Period Date",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm",
        template = "#= convertDateToString(ROPDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField207 = searchResultField205;
      searchResultFieldList128.Add(searchResultField207);
      List<SearchResultField> searchResultFieldList129 = searchResultFieldList1;
      SearchResultField searchResultField208 = new SearchResultField();
      searchResultField208.Name = "Cross Sell";
      searchResultField208.ExportField = "CrossSellIdValue";
      int num256 = num255;
      int num257 = num256 + 1;
      searchResultField208.Order = num256;
      searchResultField208.Html = new SearchResultFieldHtml()
      {
        field = "CrossSellIdValue",
        title = "Cross Sell",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList129.Add(searchResultField208);
      List<SearchResultField> searchResultFieldList130 = searchResultFieldList1;
      SearchResultField searchResultField209 = new SearchResultField();
      searchResultField209.Name = "Deal Type";
      searchResultField209.ExportField = "DealType";
      int num258 = num257;
      int num259 = num258 + 1;
      searchResultField209.Order = num258;
      searchResultField209.Html = new SearchResultFieldHtml()
      {
        field = "DealType",
        title = "Deal Type",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList130.Add(searchResultField209);
      List<SearchResultField> searchResultFieldList131 = searchResultFieldList1;
      SearchResultField searchResultField210 = new SearchResultField();
      searchResultField210.Name = "Formal Due Diligence Date";
      searchResultField210.ExportField = "=Format(fields!FormalDueDiligenceDate.Value, \"MM/dd/yyyy\")";
      searchResultField210.ExportColumns = new string[1]
      {
        "FormalDueDiligenceDate"
      };
      SearchResultField searchResultField211 = searchResultField210;
      int num260 = num259;
      int num261 = num260 + 1;
      searchResultField211.Order = num260;
      searchResultField210.Html = new SearchResultFieldHtml()
      {
        field = "FormalDueDiligenceDate",
        title = "Formal Due Diligence Date",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2.5cm",
        template = "#= convertDateToString(FormalDueDiligenceDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField212 = searchResultField210;
      searchResultFieldList131.Add(searchResultField212);
      List<SearchResultField> searchResultFieldList132 = searchResultFieldList1;
      SearchResultField searchResultField213 = new SearchResultField();
      searchResultField213.Name = "Issue Price Certificate Review Date";
      searchResultField213.ExportField = "=Format(fields!IssuePriceCertReviewDate.Value, \"MM/dd/yyyy\")";
      searchResultField213.ExportColumns = new string[1]
      {
        "IssuePriceCertReviewDate"
      };
      SearchResultField searchResultField214 = searchResultField213;
      int num262 = num261;
      int num263 = num262 + 1;
      searchResultField214.Order = num262;
      searchResultField213.Html = new SearchResultFieldHtml()
      {
        field = "IssuePriceCertReviewDate",
        title = "Issue Price Certificate Review Date",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2.5cm",
        template = "#= convertDateToString(IssuePriceCertReviewDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField215 = searchResultField213;
      searchResultFieldList132.Add(searchResultField215);
      List<SearchResultField> searchResultFieldList133 = searchResultFieldList1;
      SearchResultField searchResultField216 = new SearchResultField();
      searchResultField216.Name = "G-34(c) Submission Date (Liquidity)";
      searchResultField216.ExportField = "=Format(fields!LiquidityAgreementUploadDate.Value, \"MM/dd/yyyy\")";
      searchResultField216.ExportColumns = new string[1]
      {
        "LiquidityAgreementUploadDate"
      };
      SearchResultField searchResultField217 = searchResultField216;
      int num264 = num263;
      int num265 = num264 + 1;
      searchResultField217.Order = num264;
      searchResultField216.Html = new SearchResultFieldHtml()
      {
        field = "LiquidityAgreementUploadDate",
        title = "G-34(c) Submission Date (Liquidity)",
        sortable = true,
        isLeftAligned = true,
        width = "100px",
        excelWidth = "2.5cm",
        template = "#= convertDateToString(LiquidityAgreementUploadDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField218 = searchResultField216;
      searchResultFieldList133.Add(searchResultField218);
      List<SearchResultField> searchResultFieldList134 = searchResultFieldList1;
      SearchResultField searchResultField219 = new SearchResultField();
      searchResultField219.Name = "OS Deemed Final Date";
      searchResultField219.ExportField = "=Format(fields!OSDeemedFinalDate.Value, \"MM/dd/yyyy\")";
      searchResultField219.ExportColumns = new string[1]
      {
        "OSDeemedFinalDate"
      };
      SearchResultField searchResultField220 = searchResultField219;
      int num266 = num265;
      int num267 = num266 + 1;
      searchResultField220.Order = num266;
      searchResultField219.Html = new SearchResultFieldHtml()
      {
        field = "OSDeemedFinalDate",
        title = "OS Deemed Final Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "4cm",
        template = "#= convertDateToString(OSDeemedFinalDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField221 = searchResultField219;
      searchResultFieldList134.Add(searchResultField221);
      List<SearchResultField> searchResultFieldList135 = searchResultFieldList1;
      SearchResultField searchResultField222 = new SearchResultField();
      searchResultField222.Name = "ABA Number";
      searchResultField222.ExportField = "ABANumber";
      int num268 = num267;
      int num269 = num268 + 1;
      searchResultField222.Order = num268;
      searchResultField222.Html = new SearchResultFieldHtml()
      {
        field = "ABANumber",
        title = "ABA Number",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList135.Add(searchResultField222);
      List<SearchResultField> searchResultFieldList136 = searchResultFieldList1;
      SearchResultField searchResultField223 = new SearchResultField();
      searchResultField223.Name = "Account Number";
      searchResultField223.ExportField = "AccountNumber";
      int num270 = num269;
      int num271 = num270 + 1;
      searchResultField223.Order = num270;
      searchResultField223.Html = new SearchResultFieldHtml()
      {
        field = "AccountNumber",
        title = "Account Number",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList136.Add(searchResultField223);
      List<SearchResultField> searchResultFieldList137 = searchResultFieldList1;
      SearchResultField searchResultField224 = new SearchResultField();
      searchResultField224.Name = "Account Name";
      searchResultField224.ExportField = "AccountName";
      int num272 = num271;
      int num273 = num272 + 1;
      searchResultField224.Order = num272;
      searchResultField224.Html = new SearchResultFieldHtml()
      {
        field = "AccountName",
        title = "Account Name",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList137.Add(searchResultField224);
      List<SearchResultField> searchResultFieldList138 = searchResultFieldList1;
      SearchResultField searchResultField225 = new SearchResultField();
      searchResultField225.Name = "Good Faith Notes";
      searchResultField225.ExportField = "GoodFaithNotes";
      int num274 = num273;
      int num275 = num274 + 1;
      searchResultField225.Order = num274;
      searchResultField225.Html = new SearchResultFieldHtml()
      {
        field = "GoodFaithNotes",
        title = "Good Faith Notes",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList138.Add(searchResultField225);
      List<SearchResultField> searchResultFieldList139 = searchResultFieldList1;
      SearchResultField searchResultField226 = new SearchResultField();
      searchResultField226.Name = "Good Faith Instructions";
      searchResultField226.ExportField = "GoodFaithInstructions";
      int num276 = num275;
      int num277 = num276 + 1;
      searchResultField226.Order = num276;
      searchResultField226.Html = new SearchResultFieldHtml()
      {
        field = "GoodFaithInstructions",
        title = "Good Faith Instructions",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "5cm"
      };
      searchResultFieldList139.Add(searchResultField226);
      List<SearchResultField> searchResultFieldList140 = searchResultFieldList1;
      SearchResultField searchResultField227 = new SearchResultField();
      searchResultField227.Name = "Good Faith Type";
      searchResultField227.ExportField = "GoodFaithType";
      int num278 = num277;
      int num279 = num278 + 1;
      searchResultField227.Order = num278;
      searchResultField227.Html = new SearchResultFieldHtml()
      {
        field = "GoodFaithType",
        title = "Good Faith Type",
        sortable = true,
        isLeftAligned = false,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList140.Add(searchResultField227);
      List<SearchResultField> searchResultFieldList141 = searchResultFieldList1;
      SearchResultField searchResultField228 = new SearchResultField();
      searchResultField228.Name = "Why On Hold?";
      searchResultField228.ExportField = "ReasonOfHold";
      int num280 = num279;
      int num281 = num280 + 1;
      searchResultField228.Order = num280;
      searchResultField228.Html = new SearchResultFieldHtml()
      {
        field = "ReasonOfHold",
        title = "Why On Hold?",
        sortable = true,
        isLeftAligned = false,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList141.Add(searchResultField228);
      List<SearchResultField> searchResultFieldList142 = searchResultFieldList1;
      SearchResultField searchResultField229 = new SearchResultField();
      searchResultField229.Name = "SDC Credit %";
      searchResultField229.ExportField = "SDCCreditPerc";
      int num282 = num281;
      int num283 = num282 + 1;
      searchResultField229.Order = num282;
      searchResultField229.Html = new SearchResultFieldHtml()
      {
        field = "SDCCreditPerc",
        title = "SDC Credit %",
        sortable = true,
        isLeftAligned = false,
        width = "100px",
        excelWidth = "2cm",
        format = "{0:n3}",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList142.Add(searchResultField229);
      List<SearchResultField> searchResultFieldList143 = searchResultFieldList1;
      SearchResultField searchResultField230 = new SearchResultField();
      searchResultField230.Name = "Cross Sell Details";
      searchResultField230.ExportField = "CrossSellDetail";
      int num284 = num283;
      int num285 = num284 + 1;
      searchResultField230.Order = num284;
      searchResultField230.Html = new SearchResultFieldHtml()
      {
        field = "CrossSellDetail",
        title = "Cross Sell Details",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList143.Add(searchResultField230);
      List<SearchResultField> searchResultFieldList144 = searchResultFieldList1;
      SearchResultField searchResultField231 = new SearchResultField();
      searchResultField231.Name = "Additional (Please Specify)";
      searchResultField231.ExportField = "FirmOtherRoleAdditionalDetails";
      int num286 = num285;
      int num287 = num286 + 1;
      searchResultField231.Order = num286;
      searchResultField231.Html = new SearchResultFieldHtml()
      {
        field = "FirmOtherRoleAdditionalDetails",
        title = "Additional (Please Specify)",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "5cm"
      };
      searchResultFieldList144.Add(searchResultField231);
      List<SearchResultField> searchResultFieldList145 = searchResultFieldList1;
      SearchResultField searchResultField232 = new SearchResultField();
      searchResultField232.Name = "Transaction Job Number";
      searchResultField232.ExportField = "JobNumbers";
      int num288 = num287;
      int num289 = num288 + 1;
      searchResultField232.Order = num288;
      searchResultField232.Html = new SearchResultFieldHtml()
      {
        field = "JobNumbers",
        title = "Transaction Job Number",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList145.Add(searchResultField232);
      List<SearchResultField> searchResultFieldList146 = searchResultFieldList1;
      SearchResultField searchResultField233 = new SearchResultField();
      searchResultField233.Name = "Quarter (Pricing)";
      searchResultField233.ExportField = "SeriesQuarter";
      int num290 = num289;
      int num291 = num290 + 1;
      searchResultField233.Order = num290;
      searchResultField233.Html = new SearchResultFieldHtml()
      {
        field = "SeriesQuarter",
        title = "Quarter (Pricing)",
        sortable = true,
        isLeftAligned = false,
        width = "100px",
        style = "text-align: right !important;",
        excelWidth = "2cm"
      };
      searchResultFieldList146.Add(searchResultField233);
      List<SearchResultField> searchResultFieldList147 = searchResultFieldList1;
      SearchResultField searchResultField234 = new SearchResultField();
      searchResultField234.Name = "Transaction Quarter";
      searchResultField234.ExportField = "TransactionQuarter";
      int num292 = num291;
      int num293 = num292 + 1;
      searchResultField234.Order = num292;
      searchResultField234.Html = new SearchResultFieldHtml()
      {
        field = "TransactionQuarter",
        title = "Transaction Quarter",
        sortable = true,
        isLeftAligned = false,
        style = "text-align: right !important;",
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList147.Add(searchResultField234);
      List<SearchResultField> searchResultFieldList148 = searchResultFieldList1;
      SearchResultField searchResultField235 = new SearchResultField();
      searchResultField235.Name = "Mandatory Tender/Put Date";
      searchResultField235.ExportField = "=Format(fields!PutDate.Value, \"MM/dd/yyyy\")";
      searchResultField235.ExportColumns = new string[1]
      {
        "PutDate"
      };
      SearchResultField searchResultField236 = searchResultField235;
      int num294 = num293;
      int num295 = num294 + 1;
      searchResultField236.Order = num294;
      searchResultField235.Html = new SearchResultFieldHtml()
      {
        field = "PutDate",
        title = "Mandatory Tender/Put Date",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm",
        template = "#= convertDateToString(PutDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      SearchResultField searchResultField237 = searchResultField235;
      searchResultFieldList148.Add(searchResultField237);
      List<SearchResultField> searchResultFieldList149 = searchResultFieldList1;
      SearchResultField searchResultField238 = new SearchResultField();
      searchResultField238.Name = "Form";
      searchResultField238.ExportField = "PricingForm";
      int num296 = num295;
      int num297 = num296 + 1;
      searchResultField238.Order = num296;
      searchResultField238.Html = new SearchResultFieldHtml()
      {
        field = "PricingForm",
        title = "Form",
        sortable = true,
        isLeftAligned = false,
        width = "100px",
        excelWidth = "2cm"
      };
      searchResultFieldList149.Add(searchResultField238);
      List<SearchResultField> searchResultFieldList150 = searchResultFieldList1;
      SearchResultField searchResultField239 = new SearchResultField();
      searchResultField239.Name = "Record Date";
      searchResultField239.ExportField = "RecordDate";
      int num298 = num297;
      int num299 = num298 + 1;
      searchResultField239.Order = num298;
      searchResultField239.Html = new SearchResultFieldHtml()
      {
        field = "RecordDate",
        title = "Record Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList150.Add(searchResultField239);
      List<SearchResultField> searchResultFieldList151 = searchResultFieldList1;
      SearchResultField searchResultField240 = new SearchResultField();
      searchResultField240.Name = "Transaction Lead Manager";
      searchResultField240.ExportField = "TransactionLeadManager";
      int num300 = num299;
      int num301 = num300 + 1;
      searchResultField240.Order = num300;
      searchResultField240.Html = new SearchResultFieldHtml()
      {
        field = "TransactionLeadManager",
        title = "Transaction Lead Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList151.Add(searchResultField240);
      List<SearchResultField> searchResultFieldList152 = searchResultFieldList1;
      SearchResultField searchResultField241 = new SearchResultField();
      searchResultField241.Name = "Transaction Non-Lead Manager";
      searchResultField241.ExportField = "TransactionNonLeadManager";
      int num302 = num301;
      int num303 = num302 + 1;
      searchResultField241.Order = num302;
      searchResultField241.Html = new SearchResultFieldHtml()
      {
        field = "TransactionNonLeadManager",
        title = "Transaction Non-Lead Manager",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList152.Add(searchResultField241);
      List<SearchResultField> searchResultFieldList153 = searchResultFieldList1;
      SearchResultField searchResultField242 = new SearchResultField();
      searchResultField242.Name = "Revenue Split Agreed";
      searchResultField242.ExportField = "RAAttributionReviewed";
      int num304 = num303;
      int num305 = num304 + 1;
      searchResultField242.Order = num304;
      searchResultField242.Html = new SearchResultFieldHtml()
      {
        field = "RAAttributionReviewed",
        title = "Revenue Split Agreed",
        sortable = true,
        isLeftAligned = true,
        width = "120px",
        excelWidth = "3cm"
      };
      searchResultFieldList153.Add(searchResultField242);
      List<PropertyDescriptor> propertyDescriptorList = new List<PropertyDescriptor>();
      foreach (PropertyDescriptor propertyDescriptor in (IEnumerable<PropertyDescriptor>) this.PropertyDescriptorRepository.FetchPropertyDescriptorsByEntity(-32L).ToList<PropertyDescriptor>())
      {
        string dataType = propertyDescriptor.DataType;
        if (!(dataType == "Decimal"))
        {
          if (!(dataType == "Date"))
          {
            if (dataType == "DateTime")
            {
              IssuePresenter.dateColumnsToAdjust.Add(propertyDescriptor.Key);
              searchResultFieldList1.Add(new SearchResultField()
              {
                Name = "#" + propertyDescriptor.Caption,
                ExportField = "=Format(fields!" + propertyDescriptor.Key + ".Value, \"MM/dd/yyyy hh:mm tt\")",
                ExportColumns = new string[1]
                {
                  propertyDescriptor.Key
                },
                Order = num305++,
                IsMiscellaneous = true,
                Html = new SearchResultFieldHtml()
                {
                  field = propertyDescriptor.Key,
                  title = propertyDescriptor.Caption,
                  sortable = true,
                  isLeftAligned = true,
                  width = "200px",
                  excelWidth = "5cm",
                  excelFormat = "{M/dd/yyyy}",
                  template = "#= convertDateToStringDateTime(" + propertyDescriptor.Key + ", '', '" + true.ToString() + "') #",
                  groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
                }
              });
            }
            else
              searchResultFieldList1.Add(new SearchResultField()
              {
                Name = "#" + propertyDescriptor.Caption,
                ExportField = propertyDescriptor.Key,
                Order = num305++,
                IsMiscellaneous = true,
                Html = new SearchResultFieldHtml()
                {
                  field = propertyDescriptor.Key,
                  title = propertyDescriptor.Caption,
                  sortable = true,
                  isLeftAligned = true,
                  width = "200px",
                  excelWidth = "5cm"
                }
              });
          }
          else
          {
            IssuePresenter.dateColumnsToAdjust.Add(propertyDescriptor.Key);
            searchResultFieldList1.Add(new SearchResultField()
            {
              Name = "#" + propertyDescriptor.Caption,
              ExportField = "=Format(fields!" + propertyDescriptor.Key + ".Value, \"MM/dd/yyyy\")",
              ExportColumns = new string[1]
              {
                propertyDescriptor.Key
              },
              Order = num305++,
              IsMiscellaneous = true,
              Html = new SearchResultFieldHtml()
              {
                field = propertyDescriptor.Key,
                title = propertyDescriptor.Caption,
                sortable = true,
                isLeftAligned = true,
                width = "200px",
                excelWidth = "5cm",
                excelFormat = "{M/dd/yyyy}",
                template = "#= convertDateToString(" + propertyDescriptor.Key + ", '', '" + true.ToString() + "') #",
                groupHeaderTemplate = "#= convertDateToString(value) #"
              }
            });
          }
        }
        else
          searchResultFieldList1.Add(new SearchResultField()
          {
            Name = "#" + propertyDescriptor.Caption,
            ExportField = propertyDescriptor.Key,
            Order = num305++,
            IsMiscellaneous = true,
            Html = new SearchResultFieldHtml()
            {
              field = propertyDescriptor.Key,
              title = propertyDescriptor.Caption,
              sortable = true,
              isLeftAligned = false,
              width = "200px",
              excelWidth = "5cm",
              format = propertyDescriptor.Format == "2 Decimal" ? "{0:n2}" : (propertyDescriptor.Format == "3 Decimal" ? "{0:n3}" : (propertyDescriptor.Format == "4 Decimal" ? "{0:n4}" : "{0:n}")),
              style = "text-align: right !important;",
              excelFormat = propertyDescriptor.Format == "2 Decimal" ? "#,##0.00" : (propertyDescriptor.Format == "3 Decimal" ? "#,##0.000" : (propertyDescriptor.Format == "4 Decimal" ? "#,##0.0000" : "#,##0.00"))
            }
          });
      }
      return searchResultFieldList1;
    }

    private string[] GetSearchLookupItemKeys() => new string[25]
    {
      "Issue Status",
      "State",
      "Firm Role",
      "Additional Firm Role(s)",
      "Type of Offering",
      "Purpose",
      "Fed Tax",
      "State Tax",
      "Moody's Long Term Rating",
      "S&P Long Term Rating",
      "Kroll Long Term Rating",
      "Fitch Long Term Rating",
      "Insurance Provider",
      "MS Banking Group",
      "Syndicate Member Role",
      "Advisory Agent Type",
      "Counsel Type",
      "Other Partner Type",
      "Syndicate Structure",
      "Call Feature",
      "MA Exemption",
      "Deal Type",
      "Use of Proceeds",
      "Interest Rate Type",
      "Cross Sell"
    };

    public List<SearchSettingViewModel> GetAllBookmarks()
    {
      try
      {
        return this.IssueRepository.FetchAllBookmarks().Select<SearchSetting, SearchSettingViewModel>((Func<SearchSetting, SearchSettingViewModel>) (x => new SearchSettingViewModel(x))).ToList<SearchSettingViewModel>().Where<SearchSettingViewModel>((Func<SearchSettingViewModel, bool>) (x => x.SearchSettingID > 0L)).ToList<SearchSettingViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<SearchSettingViewModel>();
      }
    }

    public SaveResult SaveBookMark(SearchSettingViewModel searchSettingModel)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssueRepository.SaveBookMark(new SearchSetting()
          {
            SearchSettingID = searchSettingModel.SearchSettingID,
            Name = searchSettingModel.Name,
            Criteria = searchSettingModel.Criteria,
            GridSetting = searchSettingModel.GridSetting,
            Public = searchSettingModel.Public
          });
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult DeleteBookMark(long bookmarkId)
    {
      try
      {
        this.IssueRepository.DeleteBookMark(bookmarkId);
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private IEnumerable<Dictionary<string, object>> GetSearchResults(
      KendoGridRequest request,
      IssueSearchViewModel issueSearchCriteria,
      out long total,
      ref bool isBlankSearch,
      string timeZoneOffset)
    {
      List<Dictionary<string, object>> finalSearchResults = new List<Dictionary<string, object>>();
      using (IDataReader searchData = this.GetSearchData(request, issueSearchCriteria, out total, ref isBlankSearch, timeZoneOffset))
      {
        List<Dictionary<string, object>> searchResults = new List<Dictionary<string, object>>();
        List<string> stringList = new List<string>();
        if (searchData != null)
        {
          while (searchData.Read())
          {
            Dictionary<string, object> dictionary = searchData.ConvertToDictionary(new Func<string, object, object>(IssuePresenter.FixDate));
            searchResults.Add(dictionary);
            stringList.Add(searchData["AppTransactionID"].ToString());
          }
          if (searchData.NextResult() && searchData.Read())
            total = (long) searchData.GetInt32(0);
        }
        if (stringList.Count > 0)
        {
          string apptransactionIds = string.Join(",", stringList.ToArray());
          List<Dictionary<string, object>> miscSearchResults = new List<Dictionary<string, object>>();
          using (IDataReader dataReader = this.PropertySetValueRepository.FetchTransposedPropertySetValues(apptransactionIds))
          {
            if (dataReader != null)
            {
              while (dataReader.Read())
              {
                Dictionary<string, object> dictionary = dataReader.ConvertToDictionary(new Func<string, object, object>(IssuePresenter.FixDate));
                miscSearchResults.Add(dictionary);
              }
            }
          }
          if (miscSearchResults.Count > 0)
            this.GetFinalSearchResult(finalSearchResults, searchResults, miscSearchResults);
          else
            finalSearchResults = searchResults;
        }
        else
          finalSearchResults = searchResults;
      }
      return (IEnumerable<Dictionary<string, object>>) finalSearchResults;
    }

    private void GetFinalSearchResult(
      List<Dictionary<string, object>> finalSearchResults,
      List<Dictionary<string, object>> searchResults,
      List<Dictionary<string, object>> miscSearchResults)
    {
      int num = 0;
      for (int i = 0; i < searchResults.Count; i++)
      {
        for (int index = num; index < miscSearchResults.Count; ++index)
        {
          if (searchResults[i]["AppTransactionID"].ToString() == miscSearchResults[index]["AppTransactionID"].ToString())
          {
            Dictionary<string, object> dictionary = searchResults[i].Concat<KeyValuePair<string, object>>(miscSearchResults[index].Where<KeyValuePair<string, object>>((Func<KeyValuePair<string, object>, bool>) (x => !searchResults[i].Keys.Contains<string>(x.Key)))).ToDictionary<KeyValuePair<string, object>, string, object>((Func<KeyValuePair<string, object>, string>) (k => k.Key), (Func<KeyValuePair<string, object>, object>) (v => v.Value));
            finalSearchResults.Add(dictionary);
          }
        }
      }
    }

    private IDataReader GetSearchData(
      KendoGridRequest request,
      IssueSearchViewModel issueSearchCriteria,
      out long total,
      ref bool isBlankSearch,
      string timeZoneOffset)
    {
      total = 0L;
      if (issueSearchCriteria.PricingDateTo.HasValue)
        issueSearchCriteria.PricingDateTo = new DateTime?(issueSearchCriteria.PricingDateTo.Value.AddDays(1.0).AddSeconds(-1.0));
      DateTime? nullable1 = issueSearchCriteria.ActualAwardDateTo;
      if (nullable1.HasValue)
      {
        IssueSearchViewModel issueSearchViewModel = issueSearchCriteria;
        nullable1 = issueSearchCriteria.ActualAwardDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        issueSearchViewModel.ActualAwardDateTo = nullable2;
      }
      nullable1 = issueSearchCriteria.SettlementDateTo;
      if (nullable1.HasValue)
      {
        IssueSearchViewModel issueSearchViewModel = issueSearchCriteria;
        nullable1 = issueSearchCriteria.SettlementDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        issueSearchViewModel.SettlementDateTo = nullable2;
      }
      nullable1 = issueSearchCriteria.DatedDateTo;
      if (nullable1.HasValue)
      {
        IssueSearchViewModel issueSearchViewModel = issueSearchCriteria;
        nullable1 = issueSearchCriteria.DatedDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        issueSearchViewModel.DatedDateTo = nullable2;
      }
      nullable1 = issueSearchCriteria.CallDateTo;
      if (nullable1.HasValue)
      {
        IssueSearchViewModel issueSearchViewModel = issueSearchCriteria;
        nullable1 = issueSearchCriteria.CallDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        issueSearchViewModel.CallDateTo = nullable2;
      }
      nullable1 = issueSearchCriteria.DateHiredTo;
      if (nullable1.HasValue)
      {
        IssueSearchViewModel issueSearchViewModel = issueSearchCriteria;
        nullable1 = issueSearchCriteria.DateHiredTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        issueSearchViewModel.DateHiredTo = nullable2;
      }
      nullable1 = issueSearchCriteria.CreateDateFrom;
      if (nullable1.HasValue)
      {
        IssueSearchViewModel issueSearchViewModel = issueSearchCriteria;
        nullable1 = issueSearchCriteria.CreateDateFrom;
        DateTime? nullable2 = new DateTime?(nullable1.Value.ToUniversalTime());
        issueSearchViewModel.CreateDateFrom = nullable2;
      }
      nullable1 = issueSearchCriteria.CreateDateTo;
      if (nullable1.HasValue)
      {
        IssueSearchViewModel issueSearchViewModel1 = issueSearchCriteria;
        nullable1 = issueSearchCriteria.CreateDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.ToUniversalTime());
        issueSearchViewModel1.CreateDateTo = nullable2;
        IssueSearchViewModel issueSearchViewModel2 = issueSearchCriteria;
        nullable1 = issueSearchCriteria.CreateDateTo;
        DateTime? nullable3 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        issueSearchViewModel2.CreateDateTo = nullable3;
      }
      IVisitableCriterion criterion1 = (IVisitableCriterion) EmptyCriterion.Instance;
      foreach (ExternalPartnerSearchModel externalPartner in issueSearchCriteria.ExternalPartners)
        criterion1 = criterion1.Or("PartnerID".Equal(externalPartner.PartnerID).And("MemberType".Equal(externalPartner.Role)));
      IVisitableCriterion instance1 = (IVisitableCriterion) EmptyCriterion.Instance;
      IVisitableCriterion visitableCriterion1;
      if (issueSearchCriteria.IsFirmRoleIn)
        visitableCriterion1 = instance1.Or("FirmRoleID".AnyOf(issueSearchCriteria.SelectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsFirmRoleIn).Or("FirmOtherRoleID".AnyOf(issueSearchCriteria.SelectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsFirmRoleIn)).Or("SeriesFirmRole".AnyOf(issueSearchCriteria.SelectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsFirmRoleIn)));
      else
        visitableCriterion1 = instance1.Or("FirmRoleID".AnyOf(issueSearchCriteria.SelectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsFirmRoleIn).And("FirmOtherRoleID".AnyOf(issueSearchCriteria.SelectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsFirmRoleIn)).And("SeriesFirmRole".AnyOf(issueSearchCriteria.SelectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsFirmRoleIn)));
      IVisitableCriterion instance2 = (IVisitableCriterion) EmptyCriterion.Instance;
      IVisitableCriterion visitableCriterion2;
      if (issueSearchCriteria.IsMAExemptionIn)
        visitableCriterion2 = instance2.And("RFPMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "rfp")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn).Or("UWMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "underwriting")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn)).Or("IRMAMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "irma")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn)).Or("NONEMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "none")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn)));
      else
        visitableCriterion2 = instance2.And("RFPMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "rfp")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn).And("UWMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "underwriting")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn)).And("IRMAMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "irma")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn)).And("NONEMAExemptionType".AnyOf(issueSearchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "none")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsMAExemptionIn)));
      List<SubQueryDefinition> subQueryDefinitionList = new List<SubQueryDefinition>();
      IVisitableCriterion criterion2 = (IVisitableCriterion) EmptyCriterion.Instance;
      bool flag = false;
      if (issueSearchCriteria.SelectedIssueStatuses.Count > 0)
      {
        if (!issueSearchCriteria.IsIssueStatusIn)
        {
          flag = true;
          subQueryDefinitionList.Add(new SubQueryDefinition()
          {
            Field = "IssueStatusID",
            Operator = "Out",
            Value = string.Join(",", issueSearchCriteria.SelectedIssueStatuses.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>())
          });
        }
        else
          criterion2 = criterion2.And("IssueStatusID".AnyOf(issueSearchCriteria.SelectedIssueStatuses.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsIssueStatusIn));
      }
      IVisitableCriterion visitableCriterion3 = Criterion.Contains("IssueNumber", string.IsNullOrEmpty(issueSearchCriteria.IssueNumber) ? issueSearchCriteria.IssueNumber : issueSearchCriteria.IssueNumber.Trim()).And().And(criterion2).And("PnLStatusID".AnyOf(issueSearchCriteria.SelectedPnLStatuses.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsPnLStatusIn)).And(Criterion.Contains("IssueName", string.IsNullOrEmpty(issueSearchCriteria.IssueName) ? issueSearchCriteria.IssueName : issueSearchCriteria.IssueName.Trim())).And(Criterion.Contains("CreatedBy", string.IsNullOrEmpty(issueSearchCriteria.IssueSetupBy) ? issueSearchCriteria.IssueSetupBy : issueSearchCriteria.IssueSetupBy.Trim())).And(Criterion.Contains("Issuer", string.IsNullOrEmpty(issueSearchCriteria.IssuerName) ? issueSearchCriteria.IssuerName : issueSearchCriteria.IssuerName.Trim()).Or(Criterion.Contains("IssuerAliasName", string.IsNullOrEmpty(issueSearchCriteria.IssuerName) ? issueSearchCriteria.IssuerName : issueSearchCriteria.IssuerName.Trim()))).And(Criterion.Contains("Borrower", string.IsNullOrEmpty(issueSearchCriteria.BorrowerName) ? issueSearchCriteria.BorrowerName : issueSearchCriteria.BorrowerName.Trim())).And("IssueStateID".AnyOf(issueSearchCriteria.SelectedIssueStates.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsIssueStateIn)).And("IssuerStateID".AnyOf(issueSearchCriteria.SelectedIssuerStates.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsIssuerStateIn)).And("CEProvider".Equal(string.IsNullOrEmpty(issueSearchCriteria.CEProvider) ? issueSearchCriteria.CEProvider : issueSearchCriteria.CEProvider.Trim())).And("ParAmount".GreaterThanOrEqual<Decimal>(this.ConvertToDecimal(issueSearchCriteria.ParAmountFrom))).And("ParAmount".LessThanOrEqual<Decimal>(this.ConvertToDecimal(issueSearchCriteria.ParAmountTo))).And(visitableCriterion1).And("TypeOfOfferingID".AnyOf(issueSearchCriteria.SelectedTypeOfOffering.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsTypeOfOfferingIn)).And(visitableCriterion2).And("SeriesFedTax".Equal(issueSearchCriteria.FedTax)).And("SeriesStateTaxable".Equal(issueSearchCriteria.StateTaxable)).And("BankQualified".Equal<bool>(issueSearchCriteria.BankQualified)).And("CallFeatureID".Equal(issueSearchCriteria.CallFeature)).And("AttributionReviewed".Equal<bool>(issueSearchCriteria.AttributionReviewed)).And("PriorityOfOrderID".Contains(issueSearchCriteria.SelectedPriorityOfOrder.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Value)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsPriorityOfOrderIn)).And("PricingDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.PricingDateFrom).And("PricingDate".LessThanOrEqual<DateTime>(issueSearchCriteria.PricingDateTo)).Or("SeriesPricingDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.PricingDateFrom).And("SeriesPricingDate".LessThanOrEqual<DateTime>(issueSearchCriteria.PricingDateTo)))).And("ActualAwardDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.ActualAwardDateFrom).And("ActualAwardDate".LessThanOrEqual<DateTime>(issueSearchCriteria.ActualAwardDateTo)).Or("SeriesActualAwardDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.ActualAwardDateFrom).And("SeriesActualAwardDate".LessThanOrEqual<DateTime>(issueSearchCriteria.ActualAwardDateTo)))).And("SettlementDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.SettlementDateFrom).And("SettlementDate".LessThanOrEqual<DateTime>(issueSearchCriteria.SettlementDateTo)).Or("SeriesSettlementDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.SettlementDateFrom).And("SeriesSettlementDate".LessThanOrEqual<DateTime>(issueSearchCriteria.SettlementDateTo)))).And("DatedDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.DatedDateFrom).And("DatedDate".LessThanOrEqual<DateTime>(issueSearchCriteria.DatedDateTo)).Or("SeriesDatedDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.DatedDateFrom).And("SeriesDatedDate".LessThanOrEqual<DateTime>(issueSearchCriteria.DatedDateTo)))).And("SeriesCallDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.CallDateFrom)).And("SeriesCallDate".LessThanOrEqual<DateTime>(issueSearchCriteria.CallDateTo)).And("CreateDate".GreaterThanOrEqual<DateTime>(issueSearchCriteria.CreateDateFrom)).And("CreateDate".LessThanOrEqual<DateTime>(issueSearchCriteria.CreateDateTo)).And("DateHired".GreaterThanOrEqual<DateTime>(issueSearchCriteria.DateHiredFrom)).And("DateHired".LessThanOrEqual<DateTime>(issueSearchCriteria.DateHiredTo)).And("GeneralCategoryID".AnyOf(issueSearchCriteria.SelectedGeneralCategories.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!issueSearchCriteria.IsGeneralCategoryIn)).And("MoodyRatingLT".Equal(issueSearchCriteria.MoodyLongTermRating)).And("SPRatingLT".Equal(issueSearchCriteria.SPLongTermRating)).And("KrollRatingLT".Equal(issueSearchCriteria.KrollLongTermRating)).And("FitchRatingLT".Equal(issueSearchCriteria.FitchLongTermRating)).And("DealTypeID".Equal<long>(issueSearchCriteria.DealTypeID)).And("TransactionTypeID".Equal<long>(issueSearchCriteria.TransactionTypeID)).And("RateTypeID".Equal<long>(issueSearchCriteria.InterestRateTypeID)).And("CrossSellId".Equal<long>(issueSearchCriteria.CrossSellID)).And(Criterion.Contains("JobNumber", issueSearchCriteria.JobNumber)).And("LeadBankerId".AnyOf(issueSearchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "lead banker")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>()).Or("BankerId".AnyOf(issueSearchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "non lead banker")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("QuantId".AnyOf(issueSearchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "quant")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("SupervisoryPrincipalId".AnyOf(issueSearchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "supervisory principal")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("UnderwriterId".AnyOf(issueSearchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "syndicate team")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>()))).And(criterion1);
      if (visitableCriterion3 == EmptyCriterion.Instance && !flag)
      {
        isBlankSearch = true;
        return (IDataReader) null;
      }
      IVisitableCriterion visitableCriterion4 = "Principal".AnyOf(((IEnumerable<int>) this.AppUser.GetEffectivePrincipalIds()).Select<int, string>((Func<int, string>) (x => x.ToString())).ToArray<string>()).And(visitableCriterion3);
      List<string> list = issueSearchCriteria.SelectedFields.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Html.field)).ToList<string>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
        {
          KendoGridRequest.SortObject order = sortObject;
          if (issueSearchCriteria.SelectedFields.Any<SearchResultField>((Func<SearchResultField, bool>) (x => x.Html.field == order.field && !x.IsMiscellaneous)))
            orderingList.Add(new Ordering()
            {
              PropertyName = order.field,
              Direction = order.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
            });
        }
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      return this.IssueRepository.Query(new QueryDefinition()
      {
        Criterion = visitableCriterion4,
        Order = orderingList.ToArray(),
        Projection = (IEnumerable<string>) list,
        SubQueryDefinitions = subQueryDefinitionList
      }, request.take, (int) request.skip);
    }

    private DataTable GetSearchResultsToExport(
      KendoGridRequest request,
      IssueSearchViewModel issueSearchCriteria,
      out long total,
      ref bool isBlankSearch,
      string timeZoneOffset)
    {
      IDataReader searchData = this.GetSearchData(request, issueSearchCriteria, out total, ref isBlankSearch, timeZoneOffset);
      DataTable dtblLeft = new DataTable();
      List<string> stringList = new List<string>();
      if (searchData != null)
      {
        dtblLeft.Load(searchData);
        DataTableReader dataReader = dtblLeft.CreateDataReader();
        while (dataReader.Read())
          stringList.Add(dataReader["AppTransactionID"].ToString());
        if (searchData.Read())
          total = (long) searchData.GetInt32(0);
      }
      string apptransactionIds = string.Join(",", stringList.ToArray());
      DataTable dtblRight = new DataTable();
      using (IDataReader reader = this.PropertySetValueRepository.FetchTransposedPropertySetValues(apptransactionIds))
      {
        Dictionary<string, object> dictionary = new Dictionary<string, object>();
        if (reader != null)
          dtblRight.Load(reader);
      }
      return IssuePresenter.JoinTwoDataTablesOnOneColumn(dtblLeft, dtblRight, "AppTransactionID", IssuePresenter.JoinType.Left);
    }

    public ExportResult Export(
      KendoGridRequest request,
      IssueSearchViewModel searchCriteria,
      string exportType,
      string TimeZoneOffset)
    {
      try
      {
        bool isBlankSearch = false;
        DataTable searchResultsToExport = this.GetSearchResultsToExport(request, searchCriteria, out long _, ref isBlankSearch, TimeZoneOffset);
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Transaction Search", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        if (searchCriteria.SelectedFields == null || searchCriteria.SelectedFields.Count <= 0)
          return (ExportResult) null;
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".25cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        List<SearchResultField> list = searchCriteria.SelectedFields.OrderBy<SearchResultField, int>((Func<SearchResultField, int>) (x => x.Order)).ToList<SearchResultField>();
        string tzAbbreviation = this.GetTzAbbreviation(TimeZone.CurrentTimeZone.StandardName);
        foreach (SearchResultField searchResultField in list)
        {
          if (searchResultField.ExportColumns != null && searchResultField.IsTimezoneReq)
            tabularReportBuilder.AddColumn(searchResultField.Html.title + " (" + tzAbbreviation + ")", searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1, (IEnumerable<string>) searchResultField.ExportColumns);
          else if (searchResultField.ExportColumns != null && !searchResultField.IsTimezoneReq)
            tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1, (IEnumerable<string>) searchResultField.ExportColumns);
          else
            tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1);
        }
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "TransactionSearch", (object) searchResultsToExport);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new ExportResult();
      }
    }

    public string GetTzAbbreviation(string timeZoneName)
    {
      StringBuilder stringBuilder = new StringBuilder();
      string str1 = timeZoneName;
      char[] chArray = new char[1]{ ' ' };
      foreach (string str2 in str1.Split(chArray))
      {
        if (str2[0] != '(')
          stringBuilder.Append(str2[0]);
        else
          stringBuilder.Append(str2);
      }
      return stringBuilder.ToString();
    }

    public string DataTableToJSONWithStringBuilder(DataTable table)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (table.Rows.Count > 0)
      {
        stringBuilder.Append("[");
        for (int index1 = 0; index1 < table.Rows.Count; ++index1)
        {
          stringBuilder.Append("{");
          for (int index2 = 0; index2 < table.Columns.Count; ++index2)
          {
            if (index2 < table.Columns.Count - 1)
              stringBuilder.Append("\"" + table.Columns[index2].ColumnName.ToString() + "\":\"" + table.Rows[index1][index2].ToString() + "\",");
            else if (index2 == table.Columns.Count - 1)
              stringBuilder.Append("\"" + table.Columns[index2].ColumnName.ToString() + "\":\"" + table.Rows[index1][index2].ToString() + "\"");
          }
          if (index1 == table.Rows.Count - 1)
            stringBuilder.Append("}");
          else
            stringBuilder.Append("},");
        }
        stringBuilder.Append("]");
      }
      return stringBuilder.ToString();
    }

    public static DataTable JoinTwoDataTablesOnOneColumn(
      DataTable dtblLeft,
      DataTable dtblRight,
      string colToJoinOn,
      IssuePresenter.JoinType joinType)
    {
      string strTempColName = colToJoinOn + "_2";
      if (dtblRight.Columns.Contains(colToJoinOn))
        dtblRight.Columns[colToJoinOn].ColumnName = strTempColName;
      DataTable dtblResult = dtblLeft.Clone();
      IEnumerable<DataColumn> source = dtblRight.Columns.OfType<DataColumn>().Select<DataColumn, DataColumn>((Func<DataColumn, DataColumn>) (dc => new DataColumn(dc.ColumnName, dc.DataType, dc.Expression, dc.ColumnMapping))).AsEnumerable<DataColumn>().Where<DataColumn>((Func<DataColumn, bool>) (dc => !dtblResult.Columns.Contains(dc.ColumnName)));
      dtblResult.Columns.AddRange(source.ToArray<DataColumn>());
      if (!dtblLeft.Columns.Contains(colToJoinOn) || !dtblRight.Columns.Contains(colToJoinOn) && !dtblRight.Columns.Contains(strTempColName))
      {
        if (!dtblResult.Columns.Contains(colToJoinOn))
          dtblResult.Columns.Add(colToJoinOn);
        return dtblResult;
      }
      if (joinType == IssuePresenter.JoinType.Inner || joinType != IssuePresenter.JoinType.Left)
      {
        foreach (object[] objArray in dtblLeft.AsEnumerable().Join<DataRow, DataRow, object, object[]>((IEnumerable<DataRow>) dtblRight.AsEnumerable(), (Func<DataRow, object>) (rowLeft => rowLeft[colToJoinOn]), (Func<DataRow, object>) (rowRight => rowRight[strTempColName]), (Func<DataRow, DataRow, object[]>) ((rowLeft, rowRight) => ((IEnumerable<object>) rowLeft.ItemArray).Concat<object>((IEnumerable<object>) rowRight.ItemArray).ToArray<object>())))
          dtblResult.Rows.Add(objArray);
      }
      else
      {
        foreach (object[] objArray in dtblLeft.AsEnumerable().GroupJoin((IEnumerable<DataRow>) dtblRight.AsEnumerable(), (Func<DataRow, object>) (rowLeft => rowLeft[colToJoinOn]), (Func<DataRow, object>) (rowRight => rowRight[strTempColName]), (rowLeft, gj) => new
        {
          rowLeft = rowLeft,
          gj = gj
        }).SelectMany(_param1 => _param1.gj.DefaultIfEmpty<DataRow>(), (_param1, subRight) => ((IEnumerable<object>) _param1.rowLeft.ItemArray).Concat<object>(subRight == null ? (IEnumerable<object>) dtblRight.NewRow().ItemArray : (IEnumerable<object>) subRight.ItemArray).ToArray<object>()))
          dtblResult.Rows.Add(objArray);
      }
      dtblRight.Columns[strTempColName].ColumnName = colToJoinOn;
      dtblResult.Columns.Remove(strTempColName);
      return dtblResult;
    }

    private struct IssueEditOnlyStatus
    {
      public bool isIssueDetailsEditable;
      public bool isExternalPartnerEditable;
      public bool isInternalPartnerEditable;
      public bool isIssueRatingEditable;
      public bool isIssuePricingEditable;
      public bool isRestrictedCusipEditable;
      public bool isTransactionReportEditable;
      public bool isMiscEditable;
      public bool isIssueReviewEditable;
    }

    private struct IssueViewOnlyStatus
    {
      public bool isIssueDetailsVisible;
      public bool isExternalPartnerVisible;
      public bool isInternalPartnerVisible;
      public bool isIssueRatingVisible;
      public bool isIssuePricingVisible;
      public bool isRestrictedCusipVisible;
      public bool isTransactionReportVisible;
      public bool isIssueContactsVisible;
      public bool isIssueDocumentsVisible;
      public bool isIssueReviewVisible;
      public bool isAuditTrailVisible;
      public bool isMiscVisible;
    }

    private struct MUCCEditOnlyStatus
    {
      public bool isMUCCDetailsEditable;
    }

    private struct RegulatoryChacklistEditOnlyStatus
    {
      public bool isRegulatoryChacklistEditable;
    }

    public enum JoinType
    {
      Inner,
      Left,
    }
  }
}
