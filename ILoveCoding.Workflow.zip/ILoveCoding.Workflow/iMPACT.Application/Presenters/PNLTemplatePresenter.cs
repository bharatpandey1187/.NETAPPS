﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.PNLTemplatePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (PNLTemplatePresenter))]
  public class PNLTemplatePresenter : PresenterBase
  {
    [Dependency]
    public IPnlRepository PNLTemplateRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [InjectionConstructor]
    public PNLTemplatePresenter()
    {
    }

    public PNLTemplateViewModelContainer FetchAll()
    {
      try
      {
        PNLTemplateViewModelContainer viewModelContainer = new PNLTemplateViewModelContainer();
        List<LookupItemViewModel> lookupItemViewModelList = new List<LookupItemViewModel>();
        List<PNLTemplateViewModel> templateViewModelList1 = new List<PNLTemplateViewModel>();
        List<PNLTemplateViewModel> templateViewModelList2 = new List<PNLTemplateViewModel>();
        List<PNLTemplateViewModel> templateViewModelList3 = new List<PNLTemplateViewModel>();
        using (IDataReader dataReader = this.PNLTemplateRepository.FetchAll())
        {
          IRowMapper<LookupItemViewModel> rowMapper1 = MapBuilder<LookupItemViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<LookupItemViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<long>((Expression<Func<LookupItemViewModel, long>>) (x => x.LookupID)).DoNotMap<int>((Expression<Func<LookupItemViewModel, int>>) (x => x.ItemOrder)).DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsActive)).Build();
          IRowMapper<PNLTemplateViewModel> rowMapper2 = MapBuilder<PNLTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.SectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Key)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.CanOverride)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Formula)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Indenting)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Notes)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Operation)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.CategoryID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Caption)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Format)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.DataType)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsKeyUpdate)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PnLSectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PnLSectionName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Id)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.CategoryName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EvaluationSequence)).Build();
          IRowMapper<PNLTemplateViewModel> rowMapper3 = MapBuilder<PNLTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.SectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Key)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.CanOverride)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Formula)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Indenting)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Notes)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Operation)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.CategoryID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Caption)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Format)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.DataType)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsKeyUpdate)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PNLTemplateID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PNLTemplateName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EntityID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.SelectorFormula)).DoNotMap<DateTime>((Expression<Func<PNLTemplateViewModel, DateTime>>) (x => x.WithEffectFrom)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Id)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.CategoryName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EvaluationSequence)).Build();
          IRowMapper<PNLTemplateViewModel> rowMapper4 = MapBuilder<PNLTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.SectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Key)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.CanOverride)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Formula)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Indenting)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Notes)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Operation)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.CategoryID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Caption)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Format)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.DataType)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsKeyUpdate)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PNLTemplateID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PNLTemplateName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EntityID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.SelectorFormula)).DoNotMap<DateTime>((Expression<Func<PNLTemplateViewModel, DateTime>>) (x => x.WithEffectFrom)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PnLSectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PnLSectionName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EvaluationSequence)).Build();
          while (dataReader.Read())
            lookupItemViewModelList.Add(rowMapper1.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            while (dataReader.Read())
              templateViewModelList1.Add(rowMapper3.MapRow((IDataRecord) dataReader));
          }
          if (dataReader.NextResult())
          {
            while (dataReader.Read())
              templateViewModelList2.Add(rowMapper4.MapRow((IDataRecord) dataReader));
          }
          if (dataReader.NextResult())
          {
            while (dataReader.Read())
              templateViewModelList3.Add(rowMapper2.MapRow((IDataRecord) dataReader));
          }
        }
        viewModelContainer.EntityTypes = lookupItemViewModelList;
        viewModelContainer.Section = templateViewModelList1;
        viewModelContainer.Category = templateViewModelList2;
        viewModelContainer.PNLTemplateItems = templateViewModelList3;
        viewModelContainer.IsViewOnly = !this.HasIndependentPermission("PnL Master", "Edit");
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PNLTemplateViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public PNLTemplateViewModelContainer FetchCategoryNames(
      int sectionID)
    {
      try
      {
        PNLTemplateViewModelContainer viewModelContainer = new PNLTemplateViewModelContainer();
        List<PNLTemplateViewModel> templateViewModelList = new List<PNLTemplateViewModel>();
        using (IDataReader dataReader = this.PNLTemplateRepository.FetchCategoryNames(sectionID))
        {
          IRowMapper<PNLTemplateViewModel> rowMapper = MapBuilder<PNLTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.SectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Key)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.CanOverride)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Formula)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Indenting)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Notes)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Operation)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.CategoryID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Caption)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Format)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.DataType)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsKeyUpdate)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PNLTemplateID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PNLTemplateName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EntityID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.SelectorFormula)).DoNotMap<DateTime>((Expression<Func<PNLTemplateViewModel, DateTime>>) (x => x.WithEffectFrom)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PnLSectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PnLSectionName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EvaluationSequence)).Build();
          while (dataReader.Read())
            templateViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        viewModelContainer.Category = templateViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PNLTemplateViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public PNLTemplateViewModelContainer FetchPNLKeyDetails(
      string key,
      long templateID,
      int sectionID)
    {
      try
      {
        PNLTemplateViewModelContainer viewModelContainer = new PNLTemplateViewModelContainer();
        List<PNLTemplateViewModel> templateViewModelList = new List<PNLTemplateViewModel>();
        using (IDataReader dataReader = this.PNLTemplateRepository.FetchPNLKeyDetails(key, templateID, sectionID))
        {
          IRowMapper<PNLTemplateViewModel> rowMapper = MapBuilder<PNLTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.SectionID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.CategoryID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PNLTemplateID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PNLTemplateName)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Caption)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EntityID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.SelectorFormula)).DoNotMap<DateTime>((Expression<Func<PNLTemplateViewModel, DateTime>>) (x => x.WithEffectFrom)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsKeyUpdate)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PnLSectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PnLSectionName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Id)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.CategoryName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EvaluationSequence)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Indenting)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Operation)).Build();
          while (dataReader.Read())
            templateViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        viewModelContainer.PNLTemplateKeyItems = templateViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PNLTemplateViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult SavePNLTemplate(PNLTemplateViewModel pnlTemplateViewModel)
    {
      try
      {
        this.GetSafeObject<PNLTemplateViewModel>(pnlTemplateViewModel);
        SaveResult saveResult = pnlTemplateViewModel.Validate<PNLTemplateViewModel>();
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.PNLTemplateRepository.SavePNLTemplate(pnlTemplateViewModel.GetPNLTemplateDetails());
            saveResult.Id = num;
            if (saveResult.IsSuccessful)
              transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SaveKeyDetails(PNLTemplateViewModel pnlTemplateViewModel)
    {
      try
      {
        this.GetSafeObject<PNLTemplateViewModel>(pnlTemplateViewModel);
        SaveResult saveResult = pnlTemplateViewModel.Validate<PNLTemplateViewModel>();
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.PNLTemplateRepository.SavePNLTemplateKeys(pnlTemplateViewModel.GetPNLKeyDetails());
            saveResult.Id = num;
            if (saveResult.IsSuccessful)
              transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public PNLTemplateViewModelContainer FetchAllGridData(
      long templateId,
      int sectionId)
    {
      try
      {
        return new PNLTemplateViewModelContainer()
        {
          gridDataAsJSON = this.PNLTemplateRepository.FetchAllGridData(templateId, sectionId)
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        PNLTemplateViewModelContainer viewModelContainer = new PNLTemplateViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public string CopyPNLTemplate(long templateId)
    {
      try
      {
        return this.PNLTemplateRepository.CopyPNLTemplate(templateId);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return ex.ToString();
      }
    }

    public PNLTemplateViewModelContainer UpdatePNLTemplatePublishedStatus(
      long templateId)
    {
      try
      {
        this.PNLTemplateRepository.UpdatePNLTemplatePublishedStatus(templateId);
        return new PNLTemplateViewModelContainer();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PNLTemplateViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public void InsertRowIntoPNLGrid(long templateId, long sectionId, long rowNumber)
    {
      try
      {
        this.PNLTemplateRepository.InsertRowIntoPNLGrid(templateId, sectionId, rowNumber);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public void DeleteRowFromPNLGrid(long templateId, long sectionId, long rowNumber)
    {
      try
      {
        this.PNLTemplateRepository.DeleteRowFromPNLGrid(templateId, sectionId, rowNumber);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    private List<PNLTemplateViewModel> FetchPnlKeysForTemplate(
      long templateId)
    {
      List<PNLTemplateViewModel> templateViewModelList = new List<PNLTemplateViewModel>();
      using (IDataReader dataReader = this.PNLTemplateRepository.FetchAllPnlTemplateKeyDetails(templateId))
      {
        IRowMapper<PNLTemplateViewModel> rowMapper = MapBuilder<PNLTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.SectionID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.CategoryID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PNLTemplateID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PNLTemplateName)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Caption)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EntityID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.SelectorFormula)).DoNotMap<DateTime>((Expression<Func<PNLTemplateViewModel, DateTime>>) (x => x.WithEffectFrom)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsKeyUpdate)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PnLSectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PnLSectionName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Id)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.CategoryName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EvaluationSequence)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Operation)).Build();
        while (dataReader.Read())
          templateViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
      }
      return templateViewModelList;
    }

    public string FetchPNLTemplatePublishState(long templateId)
    {
      try
      {
        return this.PNLTemplateRepository.FetchPNLTemplatePublishState(templateId).ToString();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return ex.ToString();
      }
    }

    public void DeletePNLTemplateKeys(string key)
    {
      try
      {
        this.PNLTemplateRepository.DeletePNLTemplateKeys(key);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public PNLTemplateViewModelContainer FetchPNLTemplateByID(
      int templateID)
    {
      try
      {
        PNLTemplateViewModelContainer viewModelContainer = new PNLTemplateViewModelContainer();
        List<PNLTemplateViewModel> templateViewModelList = new List<PNLTemplateViewModel>();
        using (IDataReader dataReader = this.PNLTemplateRepository.FetchPNLTemplateByID(templateID))
        {
          IRowMapper<PNLTemplateViewModel> rowMapper = MapBuilder<PNLTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PNLTemplateID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.SectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Key)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.CanOverride)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Formula)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Indenting)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Notes)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Operation)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.CategoryID)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.RowNumber)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Caption)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.Format)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.DataType)).DoNotMap<bool>((Expression<Func<PNLTemplateViewModel, bool>>) (x => x.IsKeyUpdate)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.PnLSectionID)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.PnLSectionName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.Id)).DoNotMap<string>((Expression<Func<PNLTemplateViewModel, string>>) (x => x.CategoryName)).DoNotMap<int>((Expression<Func<PNLTemplateViewModel, int>>) (x => x.EvaluationSequence)).Build();
          while (dataReader.Read())
            templateViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        viewModelContainer.PNLTemplateFilteredItems = templateViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PNLTemplateViewModelContainer("An error occurred while fetching the data.");
      }
    }
  }
}
