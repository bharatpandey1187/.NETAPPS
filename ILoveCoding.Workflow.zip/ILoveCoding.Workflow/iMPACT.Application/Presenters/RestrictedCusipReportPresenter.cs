﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.RestrictedCusipReportPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (RestrictedCusipReportPresenter))]
  public class RestrictedCusipReportPresenter : PresenterBase
  {
    [Dependency]
    public IRestrictedCusipReportRepository RestrictedCusipReportRepository { get; set; }

    public List<RestrictedCusipReportViewModel> GetRestrictedCusips()
    {
      try
      {
        List<RestrictedCusipReportViewModel> cusipReportViewModelList = new List<RestrictedCusipReportViewModel>();
        IDataReader dataReader = this.RestrictedCusipReportRepository.FetchRestrictedCUSIPs(-54L, 42L);
        if (dataReader != null)
        {
          IRowMapper<RestrictedCusipReportViewModel> rowMapper = MapBuilder<RestrictedCusipReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            cusipReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return cusipReportViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<RestrictedCusipReportViewModel>();
      }
    }

    public ExportResult Export(KendoGridRequest request, string exportType)
    {
      try
      {
        List<RestrictedCusipReportViewModel> restrictedCusips = this.GetRestrictedCusips();
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        Decimal value;
        Func<RestrictedCusipReportViewModel, \u003C\u003Ef__AnonymousType14<string, string, string, string, Decimal?, string, string>> selector = d => new
        {
          Issuer = d.Issuer,
          DatedDate = d.DatedDate.ToString("MM/dd/yyyy") != "01/01/0001" ? d.DatedDate.ToString("MM/dd/yyyy") : "",
          CUSIP = d.CUSIP,
          Maturity = d.Maturity.ToString("MM/dd/yyyy") != "01/01/0001" ? d.Maturity.ToString("MM/dd/yyyy") : "",
          ParAmout = Decimal.TryParse(d.ParAmout, out value) ? new Decimal?(value) : new Decimal?(),
          Term = d.Term,
          CallDate = d.CallDate.ToString("MM/dd/yyyy") != "01/01/0001" ? d.CallDate.ToString("MM/dd/yyyy") : ""
        };
        IEnumerable<\u003C\u003Ef__AnonymousType14<string, string, string, string, Decimal?, string, string>> datas = restrictedCusips.Select(selector);
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Restricted Cusip Report", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".5cm"));
        columnStyleProvider1.CaptionStyleBuilder.AlignCenter();
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("8cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Dated Date", "DatedDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Cusip", "CUSIP", Unit.Parse("2.5cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Maturity", "Maturity", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Par Amount", "ParAmout", Unit.Parse("3.9cm"), "$#,##0.00", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Term", "Term", Unit.Parse("2cm"), "##", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Call Date", "CallDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "RestrictCusipReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ExportResult();
      }
    }
  }
}
