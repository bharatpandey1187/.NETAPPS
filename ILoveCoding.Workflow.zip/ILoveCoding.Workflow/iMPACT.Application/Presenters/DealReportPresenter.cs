﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.DealReportPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (DealReportPresenter))]
  public class DealReportPresenter : PresenterBase
  {
    [Dependency]
    public IDealReportRepository DealReportRepository { get; set; }

    public Paged<DealReportViewModel> GetDealReport(
      KendoGridRequest request,
      DealReportSearchViewModel model)
    {
      try
      {
        long total = 0;
        return new Paged<DealReportViewModel>((IList<DealReportViewModel>) this.GetSearchData(request, model, out total), total);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new Paged<DealReportViewModel>((IList<DealReportViewModel>) new List<DealReportViewModel>(), 0L);
      }
    }

    private List<DealReportViewModel> GetSearchData(
      KendoGridRequest request,
      DealReportSearchViewModel model,
      out long total)
    {
      total = 0L;
      List<DealReportViewModel> dealReportViewModelList = new List<DealReportViewModel>();
      DateTime dateTime;
      if (model.saleDateTo.HasValue)
      {
        DealReportSearchViewModel reportSearchViewModel = model;
        dateTime = model.saleDateTo.Value.AddDays(1.0);
        DateTime? nullable = new DateTime?(dateTime.AddSeconds(-1.0));
        reportSearchViewModel.saleDateTo = nullable;
      }
      DateTime? settlementDateTo = model.settlementDateTo;
      if (settlementDateTo.HasValue)
      {
        DealReportSearchViewModel reportSearchViewModel = model;
        settlementDateTo = model.settlementDateTo;
        dateTime = settlementDateTo.Value;
        dateTime = dateTime.AddDays(1.0);
        DateTime? nullable = new DateTime?(dateTime.AddSeconds(-1.0));
        reportSearchViewModel.settlementDateTo = nullable;
      }
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      using (IDataReader dataReader = this.DealReportRepository.FetchDealReportData(model.saleDateFrom, model.saleDateTo, model.settlementDateFrom, model.settlementDateTo, orderingList.ToArray(), (int) request.skip, request.take))
      {
        if (dataReader != null)
        {
          IRowMapper<DealReportViewModel> rowMapper = MapBuilder<DealReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            dealReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return dealReportViewModelList;
    }

    private Decimal? ConvertToDecimal(string str) => string.IsNullOrEmpty(str) ? new Decimal?() : new Decimal?(Convert.ToDecimal(str));

    public ExportResult Export(
      KendoGridRequest request,
      DealReportSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<DealReportViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _);
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        Func<DealReportViewModel, \u003C\u003Ef__AnonymousType1<string, string, string, string, string, string, string, string, string, string, string, Decimal?, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, Decimal?, Decimal?, string, Decimal?, Decimal?, Decimal?, Decimal?, Decimal?, Decimal?, Decimal?>> selector = d =>
        {
          string issueNbr = d.IssueNbr;
          string issuer = d.Issuer;
          string borrower = d.Borrower;
          string guarantor = d.Guarantor;
          string jobNumber = d.JobNumber;
          string leadBanker = d.LeadBanker;
          string banker2 = d.Banker2;
          string banker3 = d.Banker3;
          string supervisoryPrincipal = d.SupervisoryPrincipal;
          DateTime? nullable1;
          DateTime finalMaturity1;
          string str1;
          if (!d.SaleDate.HasValue)
          {
            str1 = "";
          }
          else
          {
            nullable1 = d.SaleDate;
            finalMaturity1 = nullable1.Value;
            str1 = finalMaturity1.ToString("MM/dd/yyyy");
          }
          nullable1 = d.SettlementDate;
          string str2;
          if (!nullable1.HasValue)
          {
            str2 = "";
          }
          else
          {
            nullable1 = d.SettlementDate;
            finalMaturity1 = nullable1.Value;
            str2 = finalMaturity1.ToString("MM/dd/yyyy");
          }
          Decimal? nullable2 = this.ConvertToDecimal(d.ParAmount);
          string firmRole = d.FirmRole;
          string firmLiability = d.FirmLiability;
          string rateStructure = d.RateStructure;
          string securityType = d.SecurityType;
          string str3 = d.BankQualified == "1" ? "Yes" : (d.BankQualified == "0" ? "No" : "");
          string fedTax = d.FedTax;
          string stateTaxable = d.StateTaxable;
          string spuRating = d.SPURating;
          string moodyUrating = d.MoodyURating;
          string fitchUrating = d.FitchURating;
          string krollRating = d.KrollRating;
          string bondInsurer = d.BondInsurer;
          string financialAdvisor = d.FinancialAdvisor;
          string bondCounsel = d.BondCounsel;
          string uwCounsel = d.UWCounsel;
          string purpose = d.Purpose;
          string baseCusip = d.BaseCUSIP;
          string leadManager = d.LeadManager;
          string designationPolicy = d.DesignationPolicy;
          Decimal? nullable3 = this.ConvertToDecimal(d.GrossUD);
          Decimal? nullable4 = this.ConvertToDecimal(d.AverageTakedown);
          DateTime finalMaturity2 = d.FinalMaturity;
          finalMaturity1 = d.FinalMaturity;
          string str4;
          if (!(finalMaturity1.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            finalMaturity1 = d.FinalMaturity;
            str4 = finalMaturity1.ToString("MM/dd/yyyy");
          }
          else
            str4 = "";
          Decimal? nullable5 = this.ConvertToDecimal(d.BondUnderwritten);
          Decimal? nullable6 = this.ConvertToDecimal(d.TotalRetailOrder);
          Decimal? nullable7 = this.ConvertToDecimal(d.TotalInstitutionalOrders);
          Decimal? nullable8 = this.ConvertToDecimal(d.TotalInstitutionalAllotments);
          Decimal? nullable9 = this.ConvertToDecimal(d.TotalMemberOrders);
          Decimal? nullable10 = this.ConvertToDecimal(d.TotalMemberAllotments);
          Decimal? nullable11 = this.ConvertToDecimal(d.TotalDesignationDollars);
          return new
          {
            IssueNbr = issueNbr,
            Issuer = issuer,
            Borrower = borrower,
            Guarantor = guarantor,
            JobNumber = jobNumber,
            LeadBanker = leadBanker,
            Banker2 = banker2,
            Banker3 = banker3,
            SupervisoryPrincipal = supervisoryPrincipal,
            SaleDate = str1,
            SettlementDate = str2,
            ParAmount = nullable2,
            FirmRole = firmRole,
            FirmLiability = firmLiability,
            RateStructure = rateStructure,
            SecurityType = securityType,
            BankQualified = str3,
            FedTax = fedTax,
            StateTaxable = stateTaxable,
            SPURating = spuRating,
            MoodyURating = moodyUrating,
            FitchURating = fitchUrating,
            KrollRating = krollRating,
            BondInsurer = bondInsurer,
            FinancialAdvisor = financialAdvisor,
            BondCounsel = bondCounsel,
            UWCounsel = uwCounsel,
            Purpose = purpose,
            BaseCUSIP = baseCusip,
            LeadManager = leadManager,
            DesignationPolicy = designationPolicy,
            GrossUD = nullable3,
            AverageTakedown = nullable4,
            FinalMaturity = str4,
            BondUnderwritten = nullable5,
            TotalRetailOrder = nullable6,
            TotalInstitutionalOrders = nullable7,
            TotalInstitutionalAllotments = nullable8,
            TotalMemberOrders = nullable9,
            TotalMemberAllotments = nullable10,
            TotalDesignationDollars = nullable11
          };
        };
        IEnumerable<\u003C\u003Ef__AnonymousType1<string, string, string, string, string, string, string, string, string, string, string, Decimal?, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, Decimal?, Decimal?, string, Decimal?, Decimal?, Decimal?, Decimal?, Decimal?, Decimal?, Decimal?>> datas = searchData.Select(selector);
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Transaction Report", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Transaction Number", "IssueNbr", Unit.Parse("3.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("7cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Borrower ", "Borrower", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Guarantor ", "Guarantor", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Job Number", "JobNumber", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Lead Banker", "LeadBanker", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Banker 2", "Banker2", Unit.Parse("4.1cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Supervisory Principal", "SupervisoryPrincipal", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Actual Award Date", "SaleDate", Unit.Parse("2.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Delivery Date", "SettlementDate", Unit.Parse("2.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddMeasure("Par Amount", "ParAmount", Unit.Parse("6cm"), "$#,##0", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Firm Role ", "FirmRole", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Firm Liability %", "FirmLiability", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Interest Rate Type", "RateStructure", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Security Type", "SecurityType", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Bank Qualified", "BankQualified", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Fed Tax", "FedTax", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("State Tax", "StateTaxable", Unit.Parse("2.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("S&P U Rating", "SPURating", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Moody's U Rating", "MoodyURating", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Fitch U Rating", "FitchURating", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Kroll U Rating", "KrollRating", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Financial Advisor", "FinancialAdvisor", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Bond Counsel ", "BondCounsel", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("UW Counsel ", "UWCounsel", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Use of Proceeds", "Purpose", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Base CUSIP ", "BaseCUSIP", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Lead Manager ", "LeadManager", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddMeasure("Estimated Average Takedown ($/1,000)", "AverageTakedown", Unit.Parse("6cm"), "$#,##0.000", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Final Maturity", "FinalMaturity", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "TransactionReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }
  }
}
