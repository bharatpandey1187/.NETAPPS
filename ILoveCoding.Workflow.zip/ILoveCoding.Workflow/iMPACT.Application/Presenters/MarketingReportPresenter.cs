﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.MarketingReportPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (MarketingReportPresenter))]
  public class MarketingReportPresenter : PresenterBase
  {
    [Dependency]
    public IMarketingReportRepository MarketingReportRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public MarketingReportSearchViewModel InitializeViewModel() => new MarketingReportSearchViewModel()
    {
      MaterialTypes = this.LookupRepository.FetchByLookupKey("Material Type").Select<LookupItem, KeyValuePair<long, string>>((Func<LookupItem, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>()
    };

    public Paged<MarketingReportViewModel> GetMarketingReport(
      KendoGridRequest request,
      MarketingReportSearchViewModel model)
    {
      try
      {
        long total = 0;
        return new Paged<MarketingReportViewModel>((IList<MarketingReportViewModel>) this.GetSearchData(request, model, out total), total);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new Paged<MarketingReportViewModel>((IList<MarketingReportViewModel>) new List<MarketingReportViewModel>(), 0L);
      }
    }

    private List<MarketingReportViewModel> GetSearchData(
      KendoGridRequest request,
      MarketingReportSearchViewModel model,
      out long total)
    {
      total = 0L;
      List<MarketingReportViewModel> marketingReportViewModelList = new List<MarketingReportViewModel>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      if (string.IsNullOrEmpty(model.LeadBanker))
        model.LeadBankerEmployeeId = 0L;
      if (string.IsNullOrEmpty(model.SupervisoryPrincipal))
        model.SPEmployeeId = 0L;
      MarketingReportSearchViewModel reportSearchViewModel = model;
      DateTime? dateTo;
      DateTime dateTime;
      if (!model.dateTo.HasValue)
      {
        dateTime = DateTime.Today.AddDays(1.0).AddSeconds(-1.0);
      }
      else
      {
        dateTo = model.dateTo;
        dateTime = dateTo.Value.AddDays(1.0).AddSeconds(-1.0);
      }
      DateTime? nullable = new DateTime?(dateTime);
      reportSearchViewModel.dateTo = nullable;
      string[] array1 = model.SelectedMaterialTypes.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Value)).ToArray<string>();
      string str = (string) null;
      if (array1.Length != 0)
        str = string.Join(",", array1);
      IMarketingReportRepository reportRepository = this.MarketingReportRepository;
      DateTime dateFrom = model.dateFrom;
      dateTo = model.dateTo;
      DateTime toDate = dateTo.Value;
      long? leadBankerEmpID = new long?(model.LeadBankerEmployeeId);
      long? supervisoryPrincipalEmpID = new long?(model.SPEmployeeId);
      string MaterialType = str;
      Ordering[] array2 = orderingList.ToArray();
      int skip = (int) request.skip;
      int take = request.take;
      using (IDataReader dataReader = reportRepository.FetchMarketingReportData(dateFrom, toDate, leadBankerEmpID, supervisoryPrincipalEmpID, MaterialType, 1, array2, skip, take))
      {
        if (dataReader != null)
        {
          IRowMapper<MarketingReportViewModel> rowMapper = MapBuilder<MarketingReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            marketingReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return marketingReportViewModelList;
    }

    public ExportResult Export(
      KendoGridRequest request,
      MarketingReportSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<MarketingReportViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _);
        PageLayout pageLayout = new PageLayout(new Unit(18.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType9<string, string, string, string, string, string, string, string, string, string, string, string, string>> datas = searchData.Select(d =>
        {
          string rfpNbr = d.RFPNbr;
          string issuer = d.Issuer;
          string materialType = d.MaterialType;
          string leadBanker = d.LeadBanker;
          DateTime approvedByPrincipal = d.DateApprovedByPrincipal;
          DateTime dateTime;
          string str1;
          if (!(d.DateApprovedByPrincipal.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.DateApprovedByPrincipal;
            str1 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str1 = "";
          DateTime dateSubmitted = d.DateSubmitted;
          dateTime = d.DateSubmitted;
          string str2;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.DateSubmitted;
            str2 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str2 = "";
          string status = d.Status;
          string rfpMaExemption = d.RfpMaExemption;
          DateTime rfpMaExemptionDate = d.RfpMaExemptionDate;
          dateTime = d.RfpMaExemptionDate;
          string str3;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.RfpMaExemptionDate;
            str3 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str3 = "";
          string uwMaExemption = d.UwMaExemption;
          DateTime uwMaExemptionDate = d.UwMaExemptionDate;
          dateTime = d.UwMaExemptionDate;
          string str4;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.UwMaExemptionDate;
            str4 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str4 = "";
          string irmaMaExemption = d.IrmaMaExemption;
          DateTime irmaMaExemptionDate = d.IrmaMaExemptionDate;
          dateTime = d.IrmaMaExemptionDate;
          string str5;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.IrmaMaExemptionDate;
            str5 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str5 = "";
          return new
          {
            RFPNbr = rfpNbr,
            Issuer = issuer,
            MaterialType = materialType,
            LeadBanker = leadBanker,
            DateApprovedByPrincipal = str1,
            DateSubmitted = str2,
            Status = status,
            RfpMaExemption = rfpMaExemption,
            RfpMaExemptionDate = str3,
            UwMaExemption = uwMaExemption,
            UwMaExemptionDate = str4,
            IrmaMaExemption = irmaMaExemption,
            IrmaMaExemptionDate = str5
          };
        });
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("Marketing Report");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Opportunity Number", "RFPNbr", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Material Type ", "MaterialType", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Lead Banker ", "LeadBanker", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Date Approved By Supervisory Principal", "DateApprovedByPrincipal", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Date Submitted ", "DateSubmitted", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Status", "Status", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("RFP MA Exemption", "RfpMaExemption", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("RFP MA Exemption Date", "RfpMaExemptionDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("UW MA Exemption", "UwMaExemption", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("UW MA Exemption Date", "UwMaExemptionDate", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("IRMA MA Exemption", "IrmaMaExemption", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("IRMA MA Exemption Date", "IrmaMaExemptionDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "MarketingReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }
  }
}
