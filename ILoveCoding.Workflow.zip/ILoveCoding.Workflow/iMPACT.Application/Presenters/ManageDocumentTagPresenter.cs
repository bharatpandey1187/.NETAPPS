﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ManageDocumentTagPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (ManageDocumentTagPresenter))]
  public class ManageDocumentTagPresenter : PresenterBase
  {
    [Dependency]
    public IManageDocumentTagRepository ManageDocumentTagRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [InjectionConstructor]
    public ManageDocumentTagPresenter()
    {
    }

    [Dependency]
    public DocumentSearchPresenter DocSearchPresenter { get; set; }

    public ManageDocumentTagViewModelContainer FetchAll()
    {
      try
      {
        ManageDocumentTagViewModelContainer viewModelContainer = new ManageDocumentTagViewModelContainer();
        List<LookupItemViewModel> lookupItemViewModelList = new List<LookupItemViewModel>();
        List<KeyValuePair<long, string>> keyValuePairList = new List<KeyValuePair<long, string>>();
        List<ManageDocumentTagViewModel> documentTagViewModelList = new List<ManageDocumentTagViewModel>();
        using (IDataReader dataReader = this.ManageDocumentTagRepository.FetchAll())
        {
          IRowMapper<LookupItemViewModel> rowMapper1 = MapBuilder<LookupItemViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<LookupItemViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsEditable)).Build();
          while (dataReader.Read())
            lookupItemViewModelList.Add(rowMapper1.MapRow((IDataRecord) dataReader));
          IRowMapper<ManageDocumentTagViewModel> rowMapper2 = MapBuilder<ManageDocumentTagViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<ManageDocumentTagViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<ManageDocumentTagViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<ManageDocumentTagViewModel, string>>) (x => x.ErrorMessage)).Build();
          if (dataReader.NextResult())
          {
            while (dataReader.Read())
              documentTagViewModelList.Add(rowMapper2.MapRow((IDataRecord) dataReader));
          }
        }
        List<KeyValuePair<long, string>> list = this.DocSearchPresenter.FetchAllEntityTypes(0).Select<EntityTypes, KeyValuePair<long, string>>((Func<EntityTypes, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.EntityTypeID, x.TypeName))).ToList<KeyValuePair<long, string>>();
        viewModelContainer.EntityTypes = list;
        viewModelContainer.ManageDocumentTagItems = documentTagViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ManageDocumentTagViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult SaveManageDocumentTagItems(
      List<ManageDocumentTagViewModel> manageDocumentTagItemsViewModel)
    {
      try
      {
        this.GetSafeObject<ManageDocumentTagViewModel>(manageDocumentTagItemsViewModel);
        List<SaveResult> saveResultList = new List<SaveResult>();
        foreach (ManageDocumentTagViewModel documentTagViewModel in manageDocumentTagItemsViewModel)
        {
          SaveResult saveResult = documentTagViewModel.Validate<ManageDocumentTagViewModel>();
          if (!saveResult.IsSuccessful)
          {
            saveResult.Id = documentTagViewModel.EntityTypeDocTagID;
            saveResultList.Add(saveResult);
          }
        }
        if (saveResultList.Count > 0)
          return new SaveResult()
          {
            Errors = {
              {
                "ManageDocumentTagItems",
                (object) saveResultList
              }
            }
          };
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.ManageDocumentTagRepository.SaveManageDocumentTagItems(manageDocumentTagItemsViewModel.Select<ManageDocumentTagViewModel, ManageDocumentTag>((Func<ManageDocumentTagViewModel, ManageDocumentTag>) (x => x.GetManageDocumentTagItem())).ToList<ManageDocumentTag>());
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }
  }
}
