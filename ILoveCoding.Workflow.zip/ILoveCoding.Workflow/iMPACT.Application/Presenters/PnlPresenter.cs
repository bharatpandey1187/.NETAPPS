﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.PnlPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.Core.Logging;
using IrisSoftware.Core.Reflection;
using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (PnlPresenter))]
  public class PnlPresenter : PresenterBase
  {
    [Dependency]
    public IEventBus EventBus { get; set; }

    [Dependency]
    public IPnlRepository PnlRepository { get; set; }

    [Dependency]
    public IPnLWorkflowFactory WorkflowFactory { get; set; }

    [Dependency]
    public IEntityStateRepository EntityStateRepository { get; set; }

    [Dependency]
    public IIssueRepository IssueRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    public ApplicablePnlTemplateViewModel FetchApplicablePnlTemplateById(
      long issueId,
      string jobNumber)
    {
      return new ApplicablePnlTemplateViewModel(this.PnlRepository.FetchApplicablePnlTemplateById(issueId, jobNumber));
    }

    public PnlViewModelContainer Initialize(
      long appTransactionId,
      string jobNumber,
      long templateId)
    {
      try
      {
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (appTransactionId > 0L)
        {
          if (!this.HasUIPermissionForEntity(-34L, appTransactionId, "PnL Form", "View"))
          {
            PnlViewModelContainer viewModelContainer = new PnlViewModelContainer();
            viewModelContainer.ErrorMessage = "401";
            return viewModelContainer;
          }
        }
        else if (!this.HasEntityPermission(-34L, "PnL Form", "View"))
        {
          PnlViewModelContainer viewModelContainer = new PnlViewModelContainer();
          viewModelContainer.ErrorMessage = "401";
          return viewModelContainer;
        }
        return this.GetViewModel(this.PnlRepository.FetchPnlDetailsById(appTransactionId, jobNumber, templateId), appTransactionId);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.PnL, ex.ToString());
        PnlViewModelContainer viewModelContainer = new PnlViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public PnlJobNumberContainer GetJobNumbers(long appTransactionID)
    {
      PnlJobNumberContainer jobNumberContainer1 = (PnlJobNumberContainer) null;
      Pnl pnl = new Pnl();
      try
      {
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (appTransactionID > 0L)
        {
          if (!this.HasUIPermissionForEntity(-34L, appTransactionID, "PnL Form", "View"))
          {
            PnlJobNumberContainer jobNumberContainer2 = new PnlJobNumberContainer();
            jobNumberContainer2.ErrorMessage = "401";
            return jobNumberContainer2;
          }
        }
        else if (!this.HasEntityPermission(-34L, "PnL Form", "View"))
        {
          PnlJobNumberContainer jobNumberContainer2 = new PnlJobNumberContainer();
          jobNumberContainer2.ErrorMessage = "401";
          return jobNumberContainer2;
        }
        if (jobNumberContainer1 == null)
          jobNumberContainer1 = new PnlJobNumberContainer();
        jobNumberContainer1.JobNumbers = this.PnlRepository.FetchJobNumbers(appTransactionID);
        return jobNumberContainer1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.PnL, ex.ToString());
        PnlJobNumberContainer jobNumberContainer2 = new PnlJobNumberContainer();
        jobNumberContainer2.ErrorMessage = "An error occurred while fetching the data.";
        return jobNumberContainer2;
      }
    }

    public SaveResult Save(PnlViewModelContainer pnlContainer, string pnlAction)
    {
      SaveResult saveResult1 = new SaveResult();
      try
      {
        this.GetSafeObject<PnlViewModelContainer>(pnlContainer);
        Logger<Modules> log1 = this.Log;
        DateTime now = DateTime.Now;
        string message1 = string.Format("PERFORMANCE :  Save called at {0} for AppTransactionId {1} ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
        log1.Error(Modules.PnL, message1);
        TransitionResult<PnlEnums.PnLStatus, Pnl> transitionResult = (TransitionResult<PnlEnums.PnLStatus, Pnl>) null;
        List<PnlEnums.PnLStatus> pnLstatusList = new List<PnlEnums.PnLStatus>();
        pnLstatusList.Add(PnlEnums.PnLStatus.Open);
        Pnl oldPnl = new Pnl();
        Logger<Modules> log2 = this.Log;
        now = DateTime.Now;
        string message2 = string.Format("PERFORMANCE : GetSafe executed and list object {0} for AppTransactionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
        log2.Error(Modules.PnL, message2);
        if (pnlContainer.PnlHeaderInfo.AppTransactionId > 0L)
        {
          oldPnl = this.PnlRepository.FetchPnlDetailsById(pnlContainer.PnlHeaderInfo.IssueId, pnlContainer.PnlHeaderInfo.JobNumber, pnlContainer.PnlHeaderInfo.PnlTemplateId, pnlContainer.PnlHeaderInfo.AppTransactionId);
          pnLstatusList.Clear();
          if (oldPnl.PnlCount == 0)
          {
            PnlViewModelContainer viewModelContainer = this.Initialize(pnlContainer.PnlHeaderInfo.IssueId, pnlContainer.PnlHeaderInfo.JobNumber, pnlContainer.PnlHeaderInfo.PnlTemplateId);
            string errorMessage = string.Format("The Transaction and / or PnL information has been modified. Please reopen the PnL form.", (object) viewModelContainer.PnlHeaderInfo.LastModifiedBy, (object) "PnL");
            this.Log.Error(Modules.PnL, "The Transaction and / or PnL information has been modified. Please reopen the PnL form.");
            SaveResult saveResult2 = SaveResult.Failure(pnlContainer.PnlHeaderInfo.AppTransactionId, errorMessage, (object) viewModelContainer);
            saveResult2.ViewModel = (object) viewModelContainer;
            return saveResult2;
          }
          if (!string.IsNullOrEmpty(oldPnl.PnlHeaderInfo.CommaSeperatedStateID))
            oldPnl.PnlHeaderInfo.PnLStatus = ((IEnumerable<string>) oldPnl.PnlHeaderInfo.CommaSeperatedStateID.Split(new string[1]
            {
              ","
            }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>((Func<string, long>) (s => long.Parse(s))).ToList<long>();
          pnLstatusList = oldPnl.PnlHeaderInfo.PnLStatus.ConvertAll<PnlEnums.PnLStatus>((Converter<long, PnlEnums.PnLStatus>) (s => (PnlEnums.PnLStatus) s));
          Logger<Modules> log3 = this.Log;
          now = DateTime.Now;
          string message3 = string.Format("PERFORMANCE : Setting lstOldPnLStatus with Old PnL Status at  {0} for AppTransactionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
          log3.Error(Modules.PnL, message3);
        }
        SaveResult saveResult3 = pnlContainer.Validate<PnlViewModelContainer>();
        if (saveResult3.IsSuccessful && this.ValidateModel(pnlContainer, ref saveResult3))
        {
          Logger<Modules> log3 = this.Log;
          now = DateTime.Now;
          string message3 = string.Format("PERFORMANCE : Model validated  at  {0} for AppTransactionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
          log3.Error(Modules.PnL, message3);
          Pnl pnl = new Pnl();
          if (pnlContainer != null)
            pnl.Version = pnlContainer.Version;
          pnl.PnlHeaderInfo = pnlContainer.PnlHeaderInfo.GetPnlHeaderInfo();
          pnl.PnL = pnlContainer.Pnl;
          pnl.PnlFieldDetails = pnlContainer.PnlFieldDetails;
          pnl.PnLTemplateFields = pnlContainer.PnLTemplateFields;
          pnl.UnderwritingSpread = pnlContainer.GetUnderWritingSpreadInfo();
          pnl.PnlSeries = pnlContainer.GetPnlSeries();
          IWorkflow<PnlEnums.PnLStatus, Pnl> workflow = this.WorkflowFactory.GetWorkflow(PnlPresenter.GetWorkflowType(pnl));
          long num = pnlContainer.PnlHeaderInfo.AppTransactionId;
          Dictionary<PnlEnums.PnLStatus, PnlEnums.PnLStatus> dictionary = (Dictionary<PnlEnums.PnLStatus, PnlEnums.PnLStatus>) null;
          if (num > 0L)
            dictionary = this.PnlRepository.FetchHistoryByAppTransactionID(num);
          if (dictionary != null && dictionary.Count < 1)
            dictionary = (Dictionary<PnlEnums.PnLStatus, PnlEnums.PnLStatus>) null;
          pnl.Issue = this.IssueRepository.FetchByKey(pnl.PnlHeaderInfo.IssueId);
          Logger<Modules> log4 = this.Log;
          now = DateTime.Now;
          string message4 = string.Format("PERFORMANCE : Getting  GetWorkflowType,WorkflowFactory ,FetchHistoryByAppTransactionID  at  {0} for AppTransactionId {1} ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
          log4.Error(Modules.PnL, message4);
          if (!workflow.TryHandle(pnl, (IEnumerable<PnlEnums.PnLStatus>) pnLstatusList, pnlAction, (IDictionary<PnlEnums.PnLStatus, PnlEnums.PnLStatus>) dictionary, out transitionResult))
            return SaveResult.Failure(transitionResult.Errors);
          Dictionary<int, int> history = this.AddHistory(transitionResult);
          List<int> transitionStateTracking = this.GetTransitionStateTracking(pnLstatusList, transitionResult);
          List<PnLFromStateToState> fromToStateList;
          List<PnLFromStateToState> stateAuditTrailList;
          if (num > 0L)
          {
            fromToStateList = EntityStateHelper.GetTransitionFromToState<PnLFromStateToState, PnlEnums.PnLStatus, Pnl>(pnLstatusList, transitionResult);
            stateAuditTrailList = EntityStateHelper.GetAuditFromToState<PnLFromStateToState, PnlEnums.PnLStatus, Pnl>(pnLstatusList, transitionResult);
          }
          else
          {
            fromToStateList = this.SetFromToStateList(transitionResult);
            stateAuditTrailList = new List<PnLFromStateToState>();
          }
          Logger<Modules> log5 = this.Log;
          now = DateTime.Now;
          string message5 = string.Format("PERFORMANCE : TryHandle Called- Set fromToStateList,stateAuditTrailList at  {0} for AppTransactionId {1} ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
          log5.Error(Modules.PnL, message5);
          if (!string.IsNullOrEmpty(pnlAction))
          {
            IrisSoftware.iMPACT.Core.Security.Permission[] array1 = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, -34L, pnlContainer.PnlHeaderInfo.AppTransactionId)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "PnL Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
            List<long> longList = this.SetStatusList(pnlContainer);
            string[] array2 = workflow.GetAllowedActions((IEnumerable<PnlEnums.PnLStatus>) longList.ConvertAll<PnlEnums.PnLStatus>((Converter<long, PnlEnums.PnLStatus>) (s => (PnlEnums.PnLStatus) s))).ToArray<string>();
            pnlContainer.Actions = this.GetMatchingPermission(array1, array2);
            ((IEnumerable<string>) pnlContainer.Actions).FirstOrDefault<string>((Func<string, bool>) (x => x == pnlAction));
            Logger<Modules> log6 = this.Log;
            now = DateTime.Now;
            string message6 = string.Format("PERFORMANCE : Getting Permissions and workflow action based upon selected action at  {0} for AppTransactionId {1} ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
            log6.Error(Modules.PnL, message6);
          }
          using (TransactionScope transactionScope = new TransactionScope())
          {
            pnl.PnlHeaderInfo.PnLStatus = transitionResult.ResultingStates.Select<IState<PnlEnums.PnLStatus, Pnl>, long>((Func<IState<PnlEnums.PnLStatus, Pnl>, long>) (s => (long) s.Key)).ToList<long>();
            Logger<Modules> log6 = this.Log;
            now = DateTime.Now;
            string message6 = string.Format("PERFORMANCE : Checking edit/view permission  at  {0} for AppTransactionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
            log6.Error(Modules.PnL, message6);
            num = this.PnlRepository.Save(pnl, history, fromToStateList, stateAuditTrailList, 0L, string.Empty);
            Logger<Modules> log7 = this.Log;
            now = DateTime.Now;
            string message7 = string.Format("PERFORMANCE : Repository Save called  at  {0} for AppTransactionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
            log7.Error(Modules.PnL, message7);
            pnl.PnlHeaderInfo.AppTransactionId = num;
            Logger<Modules> log8 = this.Log;
            now = DateTime.Now;
            string message8 = string.Format("PERFORMANCE : PerformSharePointDocumentSetOperations called  at  {0} for AppTransactionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
            log8.Error(Modules.PnL, message8);
            transactionScope.Complete();
            Logger<Modules> log9 = this.Log;
            now = DateTime.Now;
            string message9 = string.Format("PERFORMANCE : transaction complete  at  {0} for AppTransactionId {1}  ", (object) now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId);
            log9.Error(Modules.PnL, message9);
          }
          if (num == -1L)
          {
            PnlViewModelContainer viewModelContainer = this.Initialize(pnl.PnlHeaderInfo.IssueId, pnl.PnlHeaderInfo.JobNumber, pnl.PnlHeaderInfo.PnlTemplateId);
            string errorMessage = string.Format("{0} has updated the {1}. Please refresh your screen, re-enter your data and save. Press Yes to refresh the screen.", (object) viewModelContainer.PnlHeaderInfo.LastModifiedBy, (object) "PnL");
            this.Log.Error(Modules.PnL, string.Format("PERFORMANCE : Checking Overriding  at  {0} for AppTransactionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnlContainer.PnlHeaderInfo.AppTransactionId));
            SaveResult saveResult2 = SaveResult.Failure(num, errorMessage, (object) viewModelContainer);
            saveResult2.ViewModel = (object) viewModelContainer;
            return saveResult2;
          }
          if (num == -2L)
          {
            PnlViewModelContainer viewModelContainer = this.Initialize(pnl.PnlHeaderInfo.IssueId, pnl.PnlHeaderInfo.JobNumber, pnl.PnlHeaderInfo.PnlTemplateId);
            string errorMessage = string.Format("The Transaction and / or PnL information has been modified. Please reopen the PnL form.", (object) pnl.PnlHeaderInfo.LastModifiedBy, (object) "PnL");
            this.Log.Error(Modules.PnL, "The Transaction and / or PnL information has been modified. Please reopen the PnL form.");
            SaveResult saveResult2 = SaveResult.Failure(pnlContainer.PnlHeaderInfo.AppTransactionId, errorMessage, (object) viewModelContainer);
            saveResult2.ViewModel = (object) viewModelContainer;
            return saveResult2;
          }
          if (saveResult3.IsSuccessful)
          {
            this.PublishEvents(pnlContainer, pnLstatusList, oldPnl, pnl, num, fromToStateList, transitionStateTracking);
            this.Log.Error(Modules.PnL, string.Format("PERFORMANCE : Set pnlStatusChangedEventList,EventBus  at  {0} for AppTransactionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnl.PnlHeaderInfo.AppTransactionId));
            saveResult3.ViewModel = (object) this.Initialize(pnlContainer.PnlHeaderInfo.IssueId, pnl.PnlHeaderInfo.JobNumber, pnlContainer.PnlHeaderInfo.PnlTemplateId);
            this.Log.Error(Modules.PnL, string.Format("PERFORMANCE : Finally Initialize called   at  {0} for AppTransactionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnl.PnlHeaderInfo.AppTransactionId));
          }
        }
        return saveResult3;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.PnL, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private static string GetWorkflowType(Pnl pnl) => string.Empty;

    private List<WorkflowStateViewModel> GetWorkflowState(
      IEnumerable<Transition<PnlEnums.PnLStatus, Pnl>> stateTransitions,
      Pnl pnl)
    {
      List<WorkflowStateViewModel> source = new List<WorkflowStateViewModel>();
      foreach (Transition<PnlEnums.PnLStatus, Pnl> stateTransition in stateTransitions)
      {
        Transition<PnlEnums.PnLStatus, Pnl> transition = stateTransition;
        long fromStateId = (long) transition.FromState.Key;
        string valueDescription1 = ReflectionUtils.GetEnumValueDescription((System.Enum) transition.FromState.Key);
        foreach (IState<PnlEnums.PnLStatus, Pnl> toState1 in transition.ToStates)
        {
          IState<PnlEnums.PnLStatus, Pnl> toState = toState1;
          long toStateId = (long) toState.Key;
          string valueDescription2 = ReflectionUtils.GetEnumValueDescription((System.Enum) toState.Key);
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == fromStateId)))
          {
            bool flag1 = pnl.PnlHeaderInfo.PnLStatus.Contains((long) transition.FromState.Key);
            bool flag2 = pnl.WorkflowStateTransitions != null && pnl.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long key1 = (long) transition.FromState.Key;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((key1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long key2 = (long) transition.FromState.Key;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return key2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = fromStateId,
              StateName = valueDescription1,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == toStateId)))
          {
            bool flag1 = pnl.PnlHeaderInfo.PnLStatus.Contains((long) toState.Key);
            bool flag2 = pnl.WorkflowStateTransitions != null && pnl.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long key1 = (long) toState.Key;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((key1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long key2 = (long) toState.Key;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return key2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = toStateId,
              StateName = valueDescription2,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
        }
      }
      return source;
    }

    private List<WorkflowStateTransitionViewModel> GetWorkflowStateTransition(
      IEnumerable<Transition<PnlEnums.PnLStatus, Pnl>> stateTransition,
      PnlViewModelContainer pnlViewModel,
      Pnl pnl)
    {
      List<WorkflowStateTransitionViewModel> transitionViewModelList = new List<WorkflowStateTransitionViewModel>();
      foreach (Transition<PnlEnums.PnLStatus, Pnl> transition1 in stateTransition)
      {
        Transition<PnlEnums.PnLStatus, Pnl> transition = transition1;
        foreach (IState<PnlEnums.PnLStatus, Pnl> toState1 in transition.ToStates)
        {
          IState<PnlEnums.PnLStatus, Pnl> toState = toState1;
          transitionViewModelList.Add(new WorkflowStateTransitionViewModel()
          {
            FromState = (long) transition.FromState.Key,
            ToState = (long) toState.Key,
            IsVisited = pnl.WorkflowStateTransitions != null && pnl.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long? nullable = itm.FromStateID;
              long key1 = (long) transition.FromState.Key;
              if ((nullable.GetValueOrDefault() == key1 ? (nullable.HasValue ? 1 : 0) : 0) == 0)
                return false;
              nullable = itm.ToStateID;
              long key2 = (long) toState.Key;
              return nullable.GetValueOrDefault() == key2 && nullable.HasValue;
            }))
          });
        }
      }
      return transitionViewModelList;
    }

    private PnlViewModelContainer GetViewModel(Pnl pnl, long appTransactionId)
    {
      PnlViewModelContainer viewModelContainer = new PnlViewModelContainer()
      {
        JobNumbers = pnl.JobNumbers,
        SelectedJobNumber = pnl.PnlHeaderInfo.JobNumber,
        PnlHeaderInfo = new PnlHeaderInfoViewModel(pnl.PnlHeaderInfo),
        SyndicateMembers = pnl.SyndicateMembers.ToList<PnlSyndicateMember>(),
        PnlSeries = pnl.PnlSeries.Select<PnlSeries, PnlSeriesViewModel>((Func<PnlSeries, PnlSeriesViewModel>) (q => new PnlSeriesViewModel(q))).ToList<PnlSeriesViewModel>(),
        UniqueSection = pnl.UniqueSections,
        UniqueCategories = pnl.UniqueCategories,
        UniqueRowsUnderSection = pnl.UniqueRowsUnderSection,
        UniqueCategoriesUnderSection = pnl.UniqueCategoriesUnderSection,
        Version = pnl.Version,
        PnLTemplateFields = pnl.PnLTemplateFields
      };
      viewModelContainer.PnlHeaderInfo.PnLStatus = pnl.PnlHeaderInfo.PnLStatus;
      viewModelContainer.PnlHeaderInfo.PnLStatusValue = pnl.PnlHeaderInfo.PnLStatusValue;
      viewModelContainer.PnlHeaderInfo.PnLReviewStatus = pnl.PnlHeaderInfo.PnLReviewStatus;
      viewModelContainer.PnlHeaderInfo.PnlNotes = pnl.PnlHeaderInfo.PnlNotes;
      viewModelContainer.PnlHeaderInfo.PnlReviewComments = pnl.PnlHeaderInfo.PnlReviewComments;
      viewModelContainer.PnlHeaderInfo.PricingDeskId = pnl.PnlHeaderInfo.PricingDeskId;
      viewModelContainer.Pnl = pnl.PnL;
      viewModelContainer.Pnl.NoOfSyndicate = viewModelContainer.Pnl.NoOfSyndicate;
      viewModelContainer.Pnl.PnLStatus = pnl.PnlHeaderInfo.PnLStatusValue != null ? pnl.PnlHeaderInfo.PnLStatusValue.Trim() : "";
      viewModelContainer.BindUnderWritingSpreadViewModel(pnl.UnderwritingSpread);
      viewModelContainer.PnlFieldDetails = pnl.PnlFieldDetails;
      AppConfig appConfig = this.AppConfigRepository.FetchByKey(78);
      if (appConfig != null && !string.IsNullOrEmpty(appConfig.Value))
        viewModelContainer.ShowPopupMessageWhenNewPnLTemplate = appConfig.Value.Trim() == "1";
      IWorkflow<PnlEnums.PnLStatus, Pnl> workflow = this.WorkflowFactory.GetWorkflow("");
      viewModelContainer.WorkflowStateTransitions = pnl.WorkflowStateTransitions;
      if (pnl.PnlHeaderInfo.AppTransactionId > 0L)
      {
        List<string> list = workflow.GetAllowedActions((IEnumerable<PnlEnums.PnLStatus>) this.GetPnLStatusListFromStatusIDList(pnl.PnlHeaderInfo.PnLStatus)).ToList<string>();
        IrisSoftware.iMPACT.Core.Security.Permission[] array = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, -34L, appTransactionId)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "PnL Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
        viewModelContainer.Actions = this.GetMatchingPermission(array, list.ToArray());
      }
      pnl.Issue = this.IssueRepository.FetchByKey(pnl.PnlHeaderInfo.IssueId);
      IEnumerable<LookupItemMappings> source = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetSearchLookupItemKeys(), (string[]) null, true);
      viewModelContainer.PricingDesks = source.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Pricing Desk")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
      foreach (UniqueSection uniqueSection in pnl.UniqueSections)
      {
        UniqueSection j = uniqueSection;
        foreach (UniqueCategory uniqueCategory in pnl.UniqueCategories.Where<UniqueCategory>((Func<UniqueCategory, bool>) (x => (long) x.SectionId == j.PnLSectionId)).ToList<UniqueCategory>())
        {
          string str = uniqueCategory.CategoryName == "Out_Of_Pocket" ? uniqueCategory.CategoryName.Replace("_", " ") : (uniqueCategory.CategoryName == "Write_Off" ? uniqueCategory.CategoryName.Replace("_", "").Replace(" ", "") : uniqueCategory.CategoryName);
          string uiName = j.PnLSectionName == "Revenue Summary" ? string.Format("PnlForm.Revenue.{0}", (object) str) : string.Format("PnlForm.Expense.{0}", (object) str);
          uniqueCategory.IsCategoryViewOnly = (uniqueCategory.CategoryName == "Actual" || uniqueCategory.CategoryName == "Difference" || uniqueCategory.CategoryName == "Write_Off") && pnl.PnlHeaderInfo.AppTransactionId <= 0L || this.HasPnLUIViewOnlyPermission(pnl.PnlHeaderInfo.AppTransactionId, uiName, pnl.PnlHeaderInfo.PnLStatus);
        }
      }
      if (string.IsNullOrEmpty(viewModelContainer.Pnl.PricingDesk))
        viewModelContainer.Pnl.PricingDesk = viewModelContainer.PricingDesks[0].Value;
      List<UniqueCategory> list1 = pnl.UniqueCategories.Where<UniqueCategory>((Func<UniqueCategory, bool>) (x => !x.IsCategoryViewOnly)).ToList<UniqueCategory>();
      viewModelContainer.IsSaveDisabled = list1.Count < 1;
      viewModelContainer.UniqueCategories = pnl.UniqueCategories;
      if (pnl.Issue.IssueDetail.IsFreeze || pnl.JobNumbers.Count<string>() == 0)
      {
        viewModelContainer.CannotCalculateFees = true;
        viewModelContainer.IsUnderwritingCategoryProjectedViewOnly = true;
        viewModelContainer.IsUnderwritingCategoryActualViewOnly = true;
        viewModelContainer.IsUnderwritingCategoryDifferenceViewOnly = true;
        viewModelContainer.IsSaveDisabled = true;
      }
      else
      {
        viewModelContainer.CannotCalculateFees = pnl.PnlHeaderInfo.AppTransactionId <= 0L || this.HasPnLUIViewOnlyPermission(pnl.PnlHeaderInfo.AppTransactionId, "PnL Detail", pnl.PnlHeaderInfo.PnLStatus);
        viewModelContainer.IsUnderwritingCategoryProjectedViewOnly = this.HasPnLUIViewOnlyPermission(pnl.PnlHeaderInfo.AppTransactionId, "PnlForm.Underwriting.Projected", pnl.PnlHeaderInfo.PnLStatus);
        viewModelContainer.IsUnderwritingCategoryActualViewOnly = pnl.PnlHeaderInfo.AppTransactionId <= 0L || this.HasPnLUIViewOnlyPermission(pnl.PnlHeaderInfo.AppTransactionId, "PnlForm.Underwriting.Actual", pnl.PnlHeaderInfo.PnLStatus);
        viewModelContainer.IsUnderwritingCategoryDifferenceViewOnly = pnl.PnlHeaderInfo.AppTransactionId <= 0L || this.HasPnLUIViewOnlyPermission(pnl.PnlHeaderInfo.AppTransactionId, "PnlForm.Underwriting.Difference", pnl.PnlHeaderInfo.PnLStatus);
      }
      return viewModelContainer;
    }

    private bool CanViewUI(
      long appTransID,
      string uiName,
      string permission,
      List<long> statusList)
    {
      return appTransID <= 0L ? this.HasEntityPermission(-34L, uiName, permission) : this.HasUIPermissionForEntityStatus(appTransID, uiName, permission, statusList);
    }

    private bool HasPnLUIViewOnlyPermission(
      long appTransactionId,
      string uiName,
      List<long> statusList)
    {
      return appTransactionId <= 0L ? !this.HasEntityPermission(-34L, uiName, "Edit") && this.HasEntityPermission(-34L, uiName, "View") : !this.HasUIPermissionForEntityStatus(appTransactionId, uiName, "Edit", statusList) && this.HasUIPermissionForEntity(-34L, appTransactionId, "PnL Form", "View");
    }

    private List<PnlEnums.PnLStatus> GetPnLStatusListFromStatusIDList(
      List<long> lstPnLStatusID)
    {
      List<PnlEnums.PnLStatus> pnLstatusList = new List<PnlEnums.PnLStatus>();
      foreach (long num in lstPnLStatusID)
        pnLstatusList.Add((PnlEnums.PnLStatus) num);
      return pnLstatusList;
    }

    private List<int> GetTransitionStateTracking(
      List<PnlEnums.PnLStatus> oldStatusList,
      TransitionResult<PnlEnums.PnLStatus, Pnl> transitionResult)
    {
      List<int> intList = new List<int>();
      IEnumerable<IState<PnlEnums.PnLStatus, Pnl>> resultingStates = transitionResult.ResultingStates;
      IEnumerable<IState<PnlEnums.PnLStatus, Pnl>> intermediateStates = transitionResult.IntermediateStates;
      if (intermediateStates != null && intermediateStates.Count<IState<PnlEnums.PnLStatus, Pnl>>() > 0)
      {
        IState<PnlEnums.PnLStatus, Pnl> actionState = transitionResult.ActionState;
        foreach (PnlEnums.PnLStatus oldStatus in oldStatusList)
        {
          if (oldStatus != actionState.Key)
            intList.Add((int) oldStatus);
        }
        foreach (IState<PnlEnums.PnLStatus, Pnl> state in intermediateStates)
          intList.Add((int) state.Key);
      }
      else
      {
        foreach (IState<PnlEnums.PnLStatus, Pnl> state in resultingStates)
          intList.Add((int) state.Key);
      }
      return intList;
    }

    private bool IsUIEditable(long appTransactionID, string uiName, List<long> statusList) => appTransactionID == 0L ? this.HasEntityPermission(-34L, uiName, "Edit") : this.HasUIPermissionForEntityStatus(appTransactionID, uiName, "Edit", statusList);

    private bool ValidateModel(PnlViewModelContainer pnlViewModel, ref SaveResult saveResult) => saveResult.IsSuccessful;

    private string[] GetSearchLookupItemKeys() => new string[1]
    {
      "Pricing Desk"
    };

    private Dictionary<int, int> AddHistory(
      TransitionResult<PnlEnums.PnLStatus, Pnl> transitionResult)
    {
      Dictionary<int, int> dictionary = (Dictionary<int, int>) null;
      if (transitionResult.History.Count > 0)
      {
        dictionary = new Dictionary<int, int>();
        foreach (KeyValuePair<PnlEnums.PnLStatus, IState<PnlEnums.PnLStatus, Pnl>> keyValuePair in (IEnumerable<KeyValuePair<PnlEnums.PnLStatus, IState<PnlEnums.PnLStatus, Pnl>>>) transitionResult.History)
        {
          PnlEnums.PnLStatus key1 = keyValuePair.Key;
          PnlEnums.PnLStatus key2 = keyValuePair.Value.Key;
          dictionary.Add((int) key1, (int) key2);
        }
      }
      return dictionary;
    }

    private List<PnLFromStateToState> SetFromToStateList(
      TransitionResult<PnlEnums.PnLStatus, Pnl> transitionResult)
    {
      List<PnLFromStateToState> lfromStateToStateList = new List<PnLFromStateToState>();
      foreach (IState<PnlEnums.PnLStatus, Pnl> resultingState in transitionResult.ResultingStates)
        lfromStateToStateList.Add(new PnLFromStateToState(new PnlEnums.PnLStatus?(), resultingState.Key));
      return lfromStateToStateList;
    }

    private List<long> SetStatusList(PnlViewModelContainer pnlContainer)
    {
      List<long> longList = new List<long>();
      if (pnlContainer.PnlHeaderInfo.PnLStatus != null && pnlContainer.PnlHeaderInfo.PnLStatus.Count > 0)
        longList = pnlContainer.PnlHeaderInfo.PnLStatus;
      return longList;
    }

    private void PublishEvents(
      PnlViewModelContainer pnlContainer,
      List<PnlEnums.PnLStatus> lstOldPnlStatus,
      Pnl oldPnl,
      Pnl pnl,
      long appTransactionID,
      List<PnLFromStateToState> fromToStateList,
      List<int> stateTracking)
    {
      if (pnlContainer.PnlHeaderInfo.AppTransactionId > 0L)
      {
        if (!EntityStateHelper.IsStatusListEqual(lstOldPnlStatus.ConvertAll<long>((Converter<PnlEnums.PnLStatus, long>) (s => (long) s)), pnl.PnlHeaderInfo.PnLStatus))
        {
          this.EventBus.Publish<PnlStatusChangedEvent>((IEnumerable<Envelope<PnlStatusChangedEvent>>) new List<Envelope<PnlStatusChangedEvent>>()
          {
            (Envelope<PnlStatusChangedEvent>) new PnlStatusChangedEvent(pnl, fromToStateList),
            (Envelope<PnlStatusChangedEvent>) new PnlStatusChangedEvent(stateTracking, appTransactionID)
          });
          this.EventBus.Publish<PnlUpdatedEvent>((Envelope<PnlUpdatedEvent>) new PnlUpdatedEvent(pnl, oldPnl));
          this.Log.Error(Modules.PnL, string.Format("PERFORMANCE : Set pnlStatusChangedEventList,EventBus  at  {0} for AppTransactionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) pnl.PnlHeaderInfo.AppTransactionId));
        }
        else
        {
          this.EventBus.Publish<PnlUpdatedEvent>((Envelope<PnlUpdatedEvent>) new PnlUpdatedEvent(pnl, oldPnl));
          this.Log.Error(Modules.PnL, string.Format("PERFORMANCE : Set EventBus  at  {0} ", (object) DateTime.Now));
        }
      }
      else
        this.EventBus.Publish<PnlCreatedEvent>((IEnumerable<Envelope<PnlCreatedEvent>>) new List<Envelope<PnlCreatedEvent>>()
        {
          (Envelope<PnlCreatedEvent>) new PnlCreatedEvent(pnl),
          (Envelope<PnlCreatedEvent>) new PnlCreatedEvent(stateTracking, appTransactionID)
        });
    }
  }
}
