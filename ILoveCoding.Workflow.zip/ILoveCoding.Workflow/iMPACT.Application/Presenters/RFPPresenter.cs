﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.RFPPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.Core.Mail;
using IrisSoftware.Core.Reflection;
using IrisSoftware.Core.SearchCriteria;
using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Transactions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (RFPPresenter))]
  public class RFPPresenter : PresenterBase
  {
    private string[] partnersEmailAddress = new string[4]
    {
      string.Empty,
      string.Empty,
      string.Empty,
      string.Empty
    };
    private string InfoReceipts = "";

    [Dependency]
    public IPartnerRepository PartnerRepository { get; set; }

    [Dependency]
    public IRFPRepository RFPRepository { get; set; }

    [Dependency]
    public IIssueRepository IssueRepository { get; set; }

    [Dependency]
    public IAuditTrailRepository AuditTrailRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IEmployeeRepository EmployeeRepository { get; set; }

    [Dependency]
    public IEventBus EventBus { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    [Dependency]
    public IEmailTemplateRepository EmailTemplateRepository { get; set; }

    [Dependency]
    public IMailSender MailSender { get; set; }

    [Dependency]
    public IClientRepository ClientRepository { get; set; }

    [Dependency]
    public IRfpWorkflowFactory WorkflowFactory { get; set; }

    [Dependency]
    public IEntityStateRepository EntityStateRepository { get; set; }

    [Dependency]
    public OpportunityPresenter OpportunityPresenter { get; set; }

    [Dependency]
    public IssuePresenter IssuePresenter { get; set; }

    [Dependency]
    public IIssueRatingRepository IssueRatingRepository { get; set; }

    public RFPViewModel Initialize(long appTransactionId)
    {
      try
      {
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (appTransactionId > 0L)
        {
          if (!this.HasUIPermissionForEntity(1L, appTransactionId, "RFP Details", "View"))
          {
            RFPViewModel rfpViewModel = new RFPViewModel();
            rfpViewModel.ErrorMessage = "401";
            return rfpViewModel;
          }
        }
        else if (!this.HasEntityPermission(1L, "RFP Details", "Create"))
        {
          RFPViewModel rfpViewModel = new RFPViewModel();
          rfpViewModel.ErrorMessage = "401";
          return rfpViewModel;
        }
        IrisSoftware.iMPACT.Data.RFP rfp = this.RFPRepository.FetchByID(appTransactionId);
        if (!string.IsNullOrEmpty(rfp.RfpDetail.CommaSeperatedStateID))
          rfp.RfpDetail.RFPStatus = ((IEnumerable<string>) rfp.RfpDetail.CommaSeperatedStateID.Split(new string[1]
          {
            ","
          }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        else
          rfp.RfpDetail.RFPStatus = new List<long>();
        return this.GetViewModel(rfp, appTransactionId);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        RFPViewModel rfpViewModel = new RFPViewModel();
        rfpViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return rfpViewModel;
      }
    }

    private RFPViewModel GetViewModel(IrisSoftware.iMPACT.Data.RFP rfp, long appTransactionId)
    {
      RFPViewModel rfpViewModel1 = new RFPViewModel();
      RFPViewModel rfpViewModel2 = new RFPViewModel(rfp);
      IWorkflow<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> workflow = this.WorkflowFactory.GetWorkflow();
      rfpViewModel2.WorkflowStateTransitions = rfp.WorkflowStateTransitions;
      if (appTransactionId > 0L)
      {
        int num = this.RFPRepository.FetchHistoryByAppTransactionID(appTransactionId).Any<KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>>((Func<KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>, bool>) (h => h.Key == IrisSoftware.iMPACT.Data.RFP.RfpStatus.ReviewProcess)) ? 1 : 0;
        List<string> list = workflow.GetAllowedActions((IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>) this.GetRFPStatusListFromStatusIDList(rfp.RfpDetail.RFPStatus)).ToList<string>();
        if (num == 0)
          list.Remove(RfpAction.ReturnToReviewProcess);
        IrisSoftware.iMPACT.Core.Security.Permission[] array = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, 1L, appTransactionId)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "RFP Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
        rfpViewModel2.Actions = this.GetMatchingPermission(array, list.ToArray<string>());
        if (this.HasUIPermissionForEntity(1L, appTransactionId, "RFP Audit Trail", "View"))
        {
          IEnumerable<AuditTrail> source = this.AuditTrailRepository.FetchByAppTransactionID(appTransactionId);
          rfpViewModel2.AuditTrails = source.Select<AuditTrail, AuditTrailViewModel>((Func<AuditTrail, AuditTrailViewModel>) (x => new AuditTrailViewModel(x))).ToList<AuditTrailViewModel>();
        }
        if (rfp.InternalPartners != null && rfp.InternalPartners.Count > 0)
        {
          rfpViewModel2.Analysts = rfpViewModel2.Analysts.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
          {
            x.IsPrimary = this.GetInternalPartnerIsPrimary(x.IsPrimary);
            return x;
          })).ToList<InternalPartner>();
          rfpViewModel2.SupervisoryPrincipals = rfpViewModel2.SupervisoryPrincipals.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (x =>
          {
            x.IsPrimary = this.GetInternalPartnerIsPrimary(x.IsPrimary);
            return x;
          })).ToList<InternalPartner>();
        }
        rfpViewModel2.BankRMs = rfpViewModel2.BankRMs;
      }
      IEnumerable<LookupItemMappings> source1 = appTransactionId > 0L ? this.FetchLookupItemsByLookupKeys(rfpViewModel2) : this.FetchLookupItemsByLookupKeys();
      rfpViewModel2.RFPTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "RFP Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.MAExemptions = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MA Exemption")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.States = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "State")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.Roles = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Firm Role")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.Purposes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Purpose")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.MaterialTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Material Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.GeneralCategories = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MS Banking Group")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.MoodyRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Moody's Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.SnPRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "S&P Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.FitchRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Fitch Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.KrollRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Kroll Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.AdvisorAgentType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Advisory Agent Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.ApprovedDerivativeMarketers = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Approved Derivative Marketer")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.TransactionTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Transaction Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.SecurityTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Security Type (General)")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.CounselType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Counsel Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpViewModel2.IsViewOnly = this.HasUIViewOnlyPermission(appTransactionId, "RFP Details", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.ViewRfpInternalPartners = this.CanViewUI(appTransactionId, "Internal Partners", "View", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.ViewRfpExternalPartners = this.CanViewUI(appTransactionId, "External Partners", "View", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.ViewRfpDocuments = this.CanViewUI(appTransactionId, "RFP Documents", "View", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.ViewRfpContacts = this.CanViewUI(appTransactionId, "RFP Contacts", "View", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.ViewRfpReview = this.CanViewUI(appTransactionId, "RFP Review", "View", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.ViewRfpAuditTrail = this.CanViewUI(appTransactionId, "RFP Audit Trail", "View", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.CanInitiateIssue = this.CanInitiateIssue(appTransactionId);
      rfpViewModel2.CanUploadRfpDocuments = this.HasPermissionToUploadDoc(appTransactionId);
      rfpViewModel2.DisableInitiateIssue = !this.DisableInitiateIssue(rfp, rfpViewModel2.CanInitiateIssue);
      rfpViewModel2.DisableRfpDetailEmail = this.HasEntityPermission(1L, "EmailRFPDetails", "View");
      rfpViewModel2.IsRfpInternalPartnersViewOnly = this.HasUIViewOnlyPermission(appTransactionId, "Internal Partners", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.IsRfpExternalPartnersViewOnly = this.HasUIViewOnlyPermission(appTransactionId, "External Partners", rfp.RfpDetail.RFPStatus);
      rfpViewModel2.IsRfpDocumentsViewOnly = rfpViewModel2.ViewRfpDocuments && !rfpViewModel2.CanUploadRfpDocuments;
      rfpViewModel2.IsReviewViewOnly = this.HasUIViewOnlyPermission(appTransactionId, "RFP Review", rfp.RfpDetail.RFPStatus);
      if (rfpViewModel2.SubmissionDateTimezone == null)
        rfpViewModel2.SubmissionDateTimezone = "ET";
      if (rfpViewModel2.ResponseDueDateTimezone == null)
        rfpViewModel2.ResponseDueDateTimezone = "ET";
      rfpViewModel2.IsAppTransactionClientContactEditable = this.HasAppTransactionClientContactEditable(rfpViewModel2);
      return rfpViewModel2;
    }

    private bool HasAppTransactionClientContactEditable(RFPViewModel rfpModel) => this.HasIndependentPermission("Client Contact", "Edit") && this.HasIndependentPermission("Client Contact", "Add") && !rfpModel.IsViewOnly;

    private bool HasPermissionToUploadDoc(long appTransactionId) => appTransactionId > 0L && this.HasUIPermissionForEntityStatusMultiple(appTransactionId, IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetRFP, "Upload");

    private bool CanInitiateIssue(long appTransID) => appTransID > 0L && ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, 1L, appTransID)).Any<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "RFP Action" && p.EntityPermission == "Edit" && p.Descr == RfpAction.InitiateIssue && !p.StateID.HasValue));

    private bool DisableInitiateIssue(IrisSoftware.iMPACT.Data.RFP rfp, bool CanInitiateIssue) => ((rfp.RfpDetail.RFPStatus == null || rfp.RfpDetail.RFPStatus.Count <= 0 ? 0 : (rfp.RfpDetail.RFPStatus.Contains(25L) ? 1 : 0)) & (CanInitiateIssue ? 1 : 0)) != 0 && !rfp.RfpDetail.HasIssueInitiated.GetValueOrDefault();

    private bool CanViewUI(
      long appTransID,
      string uiName,
      string permission,
      List<long> statusList)
    {
      return appTransID <= 0L ? this.HasEntityPermission(1L, uiName, permission) : this.HasUIPermissionForEntityStatus(appTransID, uiName, permission, statusList);
    }

    private bool HasUIViewOnlyPermission(
      long appTransactionID,
      string uiName,
      List<long> statusList)
    {
      return appTransactionID <= 0L ? !this.HasEntityPermission(-33L, uiName, "Edit") && this.HasEntityPermission(-33L, uiName, "View") : !this.HasUIPermissionForEntityStatus(appTransactionID, uiName, "Edit", statusList) && this.HasUIPermissionForEntity(1L, appTransactionID, uiName, "View");
    }

    private string GetInternalPartnerIsPrimary(string isPrimary) => !(isPrimary == "0") ? "Yes" : "No";

    private IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys() => this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetRFPLookupKeys());

    private IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys(
      RFPViewModel rfp)
    {
      return this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetRFPLookupKeys(), this.GetRFPLookupItemsID(rfp));
    }

    private string[] GetRFPLookupItemsID(RFPViewModel rfp)
    {
      string[] strArray = new string[5];
      long? nullable;
      long num;
      string str1;
      if (!rfp.State.HasValue)
      {
        str1 = "0";
      }
      else
      {
        nullable = rfp.State;
        num = nullable.Value;
        str1 = num.ToString();
      }
      strArray[0] = str1;
      nullable = rfp.RFPType;
      string str2;
      if (!nullable.HasValue)
      {
        str2 = "0";
      }
      else
      {
        nullable = rfp.RFPType;
        num = nullable.Value;
        str2 = num.ToString();
      }
      strArray[1] = str2;
      nullable = rfp.FirmRole;
      string str3;
      if (!nullable.HasValue)
      {
        str3 = "0";
      }
      else
      {
        nullable = rfp.FirmRole;
        num = nullable.Value;
        str3 = num.ToString();
      }
      strArray[2] = str3;
      nullable = rfp.Purpose;
      string str4;
      if (!nullable.HasValue)
      {
        str4 = "0";
      }
      else
      {
        nullable = rfp.Purpose;
        num = nullable.Value;
        str4 = num.ToString();
      }
      strArray[3] = str4;
      nullable = rfp.GeneralCategory;
      string str5;
      if (!nullable.HasValue)
      {
        str5 = "0";
      }
      else
      {
        nullable = rfp.GeneralCategory;
        num = nullable.Value;
        str5 = num.ToString();
      }
      strArray[4] = str5;
      return ((IEnumerable<string>) strArray).Concat<string>((IEnumerable<string>) this.GetExternalPartnerIDs(rfp.Advisors)).ToArray<string>();
    }

    private string[] GetExternalPartnerIDs(List<ExternalPartner> externalPartner)
    {
      if (externalPartner != null && externalPartner.Count<ExternalPartner>() > 0)
        return externalPartner.Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.MemberType.ToString())).ToArray<string>();
      return new string[1]{ "0" };
    }

    private string[] GetRFPLookupKeys() => new string[17]
    {
      "RFP Type",
      "State",
      "Firm Role",
      "Use of Proceeds",
      "MS Banking Group",
      "Moody's Long Term Rating",
      "S&P Long Term Rating",
      "Fitch Long Term Rating",
      "Advisory Agent Type",
      "Approved Derivative Marketer",
      "Transaction Type",
      "Security Type (General)",
      "MA Exemption",
      "Purpose",
      "Material Type",
      "Counsel Type",
      "Kroll Long Term Rating"
    };

    public List<FinancialAdvisorViewModel> GetFinancialAdvisors(
      string name)
    {
      try
      {
        List<FinancialAdvisorViewModel> advisorViewModelList = new List<FinancialAdvisorViewModel>();
        using (IDataReader dataReader = this.PartnerRepository.FetchFinancialAdvisorsByName(name, "Advisor/Agent"))
        {
          if (dataReader != null)
          {
            IRowMapper<FinancialAdvisorViewModel> rowMapper = MapBuilder<FinancialAdvisorViewModel>.MapAllProperties().Build();
            while (dataReader.Read())
              advisorViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return advisorViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return new List<FinancialAdvisorViewModel>();
      }
    }

    public SaveResult Save(RFPViewModel rfpModel, string rfpAction)
    {
      try
      {
        this.GetSafeObject<RFPViewModel>(rfpModel);
        TransitionResult<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> transitionResult = (TransitionResult<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>) null;
        List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> rfpStatusList = new List<IrisSoftware.iMPACT.Data.RFP.RfpStatus>();
        rfpStatusList.Add(IrisSoftware.iMPACT.Data.RFP.RfpStatus.Open);
        bool flag1 = false;
        IrisSoftware.iMPACT.Data.RFP rfp1 = new IrisSoftware.iMPACT.Data.RFP();
        if (rfpModel.AppTransactionID > 0L)
        {
          rfp1 = this.RFPRepository.FetchByID(rfpModel.AppTransactionID);
          rfpStatusList.Clear();
          if (!string.IsNullOrEmpty(rfp1.RfpDetail.CommaSeperatedStateID))
            rfp1.RfpDetail.RFPStatus = ((IEnumerable<string>) rfp1.RfpDetail.CommaSeperatedStateID.Split(new string[1]
            {
              ","
            }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>((Func<string, long>) (s => long.Parse(s))).ToList<long>();
          rfpStatusList = rfp1.RfpDetail.RFPStatus.ConvertAll<IrisSoftware.iMPACT.Data.RFP.RfpStatus>((Converter<long, IrisSoftware.iMPACT.Data.RFP.RfpStatus>) (s => (IrisSoftware.iMPACT.Data.RFP.RfpStatus) s));
        }
        SaveResult saveResult = rfpModel.Validate<RFPViewModel>();
        if (saveResult.IsSuccessful && this.ValidateModel(rfpModel, ref saveResult))
        {
          IrisSoftware.iMPACT.Data.RFP rfp2 = rfpModel.GetRFP();
          IWorkflow<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> workflow = this.WorkflowFactory.GetWorkflow();
          long num = rfpModel.AppTransactionID;
          rfp2.RfpDetail.SubmittedToMERGDate = rfp1.RfpDetail.SubmittedToMERGDate;
          rfp2.RfpDetail.SupervisoryPrincipalApproverName = rfp1.RfpDetail.SupervisoryPrincipalApproverName;
          Dictionary<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus> dictionary = (Dictionary<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>) null;
          if (rfpModel.AppTransactionID > 0L)
            dictionary = this.RFPRepository.FetchHistoryByAppTransactionID(num);
          if (!workflow.TryHandle(rfp2, (IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>) rfpStatusList, rfpAction, (IDictionary<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>) dictionary, out transitionResult))
            return SaveResult.Failure(transitionResult.Errors);
          RfpState rfpState = new RfpState();
          if (transitionResult.ResultingStates.Any<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>>((Func<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>, bool>) (s => s.Key == IrisSoftware.iMPACT.Data.RFP.RfpStatus.MERGInformed)))
            rfp2.RfpDetail.SubmittedToMERGDate = new DateTime?(DateTime.UtcNow);
          if (transitionResult.ResultingStates.Any<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>>((Func<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>, bool>) (s => s.Key == IrisSoftware.iMPACT.Data.RFP.RfpStatus.SupervisoryPrincipalApproved)))
            rfp2.RfpDetail.SupervisoryPrincipalApproverName = this.AppUser.Name;
          Dictionary<int, int> history = (Dictionary<int, int>) null;
          if (transitionResult.History.Count > 0)
          {
            history = new Dictionary<int, int>();
            foreach (KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>> keyValuePair in (IEnumerable<KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>>>) transitionResult.History)
            {
              IrisSoftware.iMPACT.Data.RFP.RfpStatus key1 = keyValuePair.Key;
              IrisSoftware.iMPACT.Data.RFP.RfpStatus key2 = keyValuePair.Value.Key;
              history.Add((int) key1, (int) key2);
            }
          }
          List<RfpFromStateToState> fromStateToStateList1 = new List<RfpFromStateToState>();
          List<RfpFromStateToState> fromStateToStateList2 = new List<RfpFromStateToState>();
          List<int> transitionStateTracking = this.GetTransitionStateTracking(rfpStatusList, transitionResult);
          List<RfpFromStateToState> fromStateToStateList3;
          List<RfpFromStateToState> stateAuditTrailList;
          if (rfpModel.AppTransactionID > 0L)
          {
            fromStateToStateList3 = EntityStateHelper.GetTransitionFromToState<RfpFromStateToState, IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>(rfpStatusList, transitionResult);
            stateAuditTrailList = EntityStateHelper.GetAuditFromToState<RfpFromStateToState, IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>(rfpStatusList, transitionResult);
          }
          else
          {
            fromStateToStateList3 = new List<RfpFromStateToState>();
            foreach (IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> resultingState in transitionResult.ResultingStates)
              fromStateToStateList3.Add(new RfpFromStateToState(new IrisSoftware.iMPACT.Data.RFP.RfpStatus?(), resultingState.Key));
            stateAuditTrailList = new List<RfpFromStateToState>();
          }
          bool flag2 = false;
          if (!string.IsNullOrEmpty(rfpAction))
          {
            IrisSoftware.iMPACT.Core.Security.Permission[] array1 = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, 1L, rfpModel.AppTransactionID)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "RFP Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
            List<long> longList = new List<long>();
            if (rfpModel.RFPStatus != null && rfpModel.RFPStatus.Count > 0)
              longList = rfpModel.RFPStatus;
            string[] array2 = workflow.GetAllowedActions((IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>) longList.ConvertAll<IrisSoftware.iMPACT.Data.RFP.RfpStatus>((Converter<long, IrisSoftware.iMPACT.Data.RFP.RfpStatus>) (s => (IrisSoftware.iMPACT.Data.RFP.RfpStatus) s))).ToArray<string>();
            rfpModel.Actions = this.GetMatchingPermission(array1, array2);
            flag2 = ((IEnumerable<string>) rfpModel.Actions).FirstOrDefault<string>((Func<string, bool>) (x => x == rfpAction)) != null;
          }
          using (TransactionScope transactionScope = new TransactionScope())
          {
            rfp2.RfpDetail.RFPStatus = transitionResult.ResultingStates.Select<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>, long>((Func<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>, long>) (s => (long) s.Key)).ToList<long>();
            RFPPresenter.RfpEditOnlyStatus rfpEditOnlyStatus = this.SetRfpEditOnlyStatus(rfpStatusList, rfp2.RfpDetail.AppTransactionID);
            if (!rfpEditOnlyStatus.isRfpDetailsEditable && !flag2)
              rfp2.RfpDetail = rfp1.RfpDetail;
            if (!rfpEditOnlyStatus.isInternalPartnerEditable)
            {
              rfp2.InternalPartners = (List<InternalPartner>) null;
              rfp2.InternalPartnerBankRMs = (List<InternalPartnerBankRM>) null;
            }
            if (!rfpEditOnlyStatus.isExternalPartnerEditable)
              rfp2.ExternalPartners = (List<ExternalPartner>) null;
            num = this.RFPRepository.Save(rfp2, history, fromStateToStateList3, stateAuditTrailList);
            if (num == -1L)
            {
              RFPViewModel rfpViewModel = this.Initialize(rfp2.RfpDetail.AppTransactionID);
              string errorMessage = string.Format("{0} has updated the {1}. Please refresh your screen, re-enter your data and save. Press Yes to refresh the screen.", (object) rfpViewModel.LastModifiedBy, (object) "rfp");
              transactionScope.Complete();
              return SaveResult.Failure(num, errorMessage, (object) rfpViewModel);
            }
            rfp2.RfpDetail.AppTransactionID = num;
            this.PerformSharePointDocumentSetOperations(num, rfp1, rfp2);
            saveResult.Id = num;
            if (rfpAction == "InitiateIssue" && rfp2.RfpDetail.RFPStatus != null && (rfp2.RfpDetail.RFPStatus.Count > 0 && rfp2.RfpDetail.RFPStatus.Contains(25L)) && rfpModel.CanInitiateIssue && !rfpModel.HasIssueInitiated.GetValueOrDefault())
            {
              this.Log.Error(Modules.RFP, string.Format("Issue Initiated called from RFP with AppTransactionID: {0} and User Name is : {1} and UserId is : {2} ", (object) num, (object) this.AppUser.Name, (object) this.AppUser.Id));
              SaveResult issueFromRfp = this.CreateIssueFromRFP(rfpModel);
              if (issueFromRfp.IsSuccessful)
              {
                this.AuditTrailRepository.Save(new AuditTrail()
                {
                  AppTransactionID = new long?(rfpModel.AppTransactionID),
                  Entity = "RFP",
                  What = "Issue Initiated"
                });
                flag1 = true;
                this.Log.Error(Modules.Opportunity, string.Format("Issue Initiated called from RFP with AppTransactionID: {0} and User Name is : {1} and UserId is : {2} was successful", (object) num, (object) this.AppUser.Name, (object) this.AppUser.Id));
              }
              else
              {
                this.Log.Error(Modules.Opportunity, string.Format("Issue Initiated called from RFP with AppTransactionID: {0} and User Name is : {1} and UserId is : {2} failed. The error was - {3}", (object) num, (object) this.AppUser.Name, (object) this.AppUser.Id, (object) issueFromRfp.ErrorMessage));
                return issueFromRfp;
              }
            }
            transactionScope.Complete();
            this.FlushUserEntitySecurityPermissions();
          }
          if (saveResult.IsSuccessful)
          {
            if (rfpModel.AppTransactionID > 0L)
            {
              if (!EntityStateHelper.IsStatusListEqual(rfpStatusList.ConvertAll<long>((Converter<IrisSoftware.iMPACT.Data.RFP.RfpStatus, long>) (s => (long) s)), rfp2.RfpDetail.RFPStatus))
              {
                this.EventBus.Publish<RfpStatusChangedEvent>((IEnumerable<Envelope<RfpStatusChangedEvent>>) new List<Envelope<RfpStatusChangedEvent>>()
                {
                  (Envelope<RfpStatusChangedEvent>) new RfpStatusChangedEvent(rfp2, fromStateToStateList3),
                  (Envelope<RfpStatusChangedEvent>) new RfpStatusChangedEvent(transitionStateTracking, num)
                });
                this.EventBus.Publish<RfpUpdatedEvent>((Envelope<RfpUpdatedEvent>) new RfpUpdatedEvent(rfp2, rfp1));
              }
              else
                this.EventBus.Publish<RfpUpdatedEvent>((Envelope<RfpUpdatedEvent>) new RfpUpdatedEvent(rfp2, rfp1));
              if (flag1)
                this.EventBus.Publish<RfpIssueInitiatedEvent>((Envelope<RfpIssueInitiatedEvent>) new RfpIssueInitiatedEvent(rfp2));
            }
            else
              this.EventBus.Publish<RfpCreatedEvent>((IEnumerable<Envelope<RfpCreatedEvent>>) new List<Envelope<RfpCreatedEvent>>()
              {
                (Envelope<RfpCreatedEvent>) new RfpCreatedEvent(rfp2),
                (Envelope<RfpCreatedEvent>) new RfpCreatedEvent(transitionStateTracking, num)
              });
            if (rfpModel.HasDualProposalRequestedOrProposed.GetValueOrDefault())
              this.EventBus.Publish<RFPNotifyDualProposalRequestedProposedEvent>((Envelope<RFPNotifyDualProposalRequestedProposedEvent>) new RFPNotifyDualProposalRequestedProposedEvent(rfp2));
            saveResult.ViewModel = (object) this.Initialize(num);
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult CreateIssue(RFPViewModel rfpModel, string rfpAction)
    {
      try
      {
        return new SaveResult();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public List<RFPPipelineViewModel> GetAll()
    {
      try
      {
        List<RFPPipelineViewModel> pipelineViewModelList = new List<RFPPipelineViewModel>();
        using (IDataReader dataReader = this.RFPRepository.FetchAll())
        {
          if (dataReader != null)
          {
            IRowMapper<RFPPipelineViewModel> rowMapper = MapBuilder<RFPPipelineViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<RFPPipelineViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<RFPPipelineViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<RFPPipelineViewModel, string>>) (x => x.ErrorMessage)).Build();
            while (dataReader.Read())
              pipelineViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return pipelineViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return new List<RFPPipelineViewModel>();
      }
    }

    public RfpSearchViewModel InitializeRfpSearch()
    {
      RfpSearchViewModel rfpSearchViewModel = new RfpSearchViewModel();
      IEnumerable<LookupItemMappings> source1 = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetRFPSearchLookupItemKeys(), (string[]) null, true);
      IEnumerable<EntityState> source2 = this.EntityStateRepository.FetchEntityStateByEntityID(1L);
      rfpSearchViewModel.RfpStatuses = source2.Select<EntityState, KeyValuePair<long, string>>((Func<EntityState, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.StateID, x.StateKey))).ToList<KeyValuePair<long, string>>();
      rfpSearchViewModel.States = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "State")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
      rfpSearchViewModel.RfpTypes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "RFP Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.FirmRoles = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Firm Role")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
      rfpSearchViewModel.MAExemptions = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MA Exemption")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
      rfpSearchViewModel.Purposes = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Purpose")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.GeneralCategories = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MS Banking Group")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
      rfpSearchViewModel.MoodyLongTermRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Moody's Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.Value, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.SPLongTermRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "S&P Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.Value, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.KrollLongTermRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Kroll Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.Value, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.FitchLongTermRatings = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Fitch Long Term Rating")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.Value, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.AdvisorAgentType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Advisory Agent Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.CounselType = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Counsel Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
      rfpSearchViewModel.SelectedFields = this.GetAllSearchResultFields();
      rfpSearchViewModel.CanCreatePublicBookmark = this.HasEntityPermission(1L, "Public Bookmark", "Create");
      SearchSetting searchSetting = this.RFPRepository.FetchAllBookmarks().FirstOrDefault<SearchSetting>((Func<SearchSetting, bool>) (x => x.SearchSettingID == -2L));
      if (searchSetting == null)
      {
        List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
        List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
        List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
        List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
        rfpSearchViewModel.SelectedFields = list1;
        rfpSearchViewModel.AllFields = list2;
        rfpSearchViewModel.SelectedAllFields = list2;
        rfpSearchViewModel.FieldsToSelect = list1;
      }
      else
      {
        IssueSearchViewModel issueSearchViewModel = new JavaScriptSerializer().Deserialize<IssueSearchViewModel>(searchSetting.Criteria);
        if (issueSearchViewModel.SelectedFields != null && issueSearchViewModel.SelectedFields.Count > 0)
        {
          rfpSearchViewModel.SelectedFields = issueSearchViewModel.SelectedFields;
          rfpSearchViewModel.AllFields = issueSearchViewModel.AllFields;
          rfpSearchViewModel.SelectedAllFields = issueSearchViewModel.AllFields;
          rfpSearchViewModel.FieldsToSelect = issueSearchViewModel.FieldsToSelect;
        }
        else
        {
          List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
          List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory || x.Order <= 10)).ToList<SearchResultField>();
          List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
          List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
          rfpSearchViewModel.SelectedFields = list1;
          rfpSearchViewModel.AllFields = list2;
          rfpSearchViewModel.SelectedAllFields = list2;
          rfpSearchViewModel.FieldsToSelect = list1;
        }
      }
      return rfpSearchViewModel;
    }

    private string[] GetRFPSearchLookupItemKeys() => new string[14]
    {
      "RFP Status",
      "State",
      "RFP Type",
      "Firm Role",
      "Purpose",
      "Use of Proceeds",
      "MS Banking Group",
      "Moody's Long Term Rating",
      "S&P Long Term Rating",
      "Kroll Long Term Rating",
      "Fitch Long Term Rating",
      "Advisory Agent Type",
      "Counsel Type",
      "MA Exemption"
    };

    public List<SearchSettingViewModel> GetAllBookmarks()
    {
      try
      {
        return this.RFPRepository.FetchAllBookmarks().Select<SearchSetting, SearchSettingViewModel>((Func<SearchSetting, SearchSettingViewModel>) (x => new SearchSettingViewModel(x))).ToList<SearchSettingViewModel>().Where<SearchSettingViewModel>((Func<SearchSettingViewModel, bool>) (x => x.SearchSettingID > 0L)).ToList<SearchSettingViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return new List<SearchSettingViewModel>();
      }
    }

    public SaveResult SaveBookMark(SearchSettingViewModel searchSettingModel)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.RFPRepository.SaveBookMark(new SearchSetting()
          {
            SearchSettingID = searchSettingModel.SearchSettingID,
            Name = searchSettingModel.Name,
            Criteria = searchSettingModel.Criteria,
            GridSetting = searchSettingModel.GridSetting,
            Public = searchSettingModel.Public
          });
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult DeleteBookMark(long bookmarkId)
    {
      try
      {
        this.RFPRepository.DeleteBookMark(bookmarkId);
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SearchRfp(
      KendoGridRequest request,
      RfpSearchViewModel rfpSearchCriteria,
      string timeZoneOffset)
    {
      try
      {
        long total = 0;
        bool isBlankSearch = false;
        List<RfpSearchResultViewModel> searchData = this.GetSearchData(request, rfpSearchCriteria, out total, ref isBlankSearch, timeZoneOffset);
        SaveResult saveResult1 = new SaveResult();
        SaveResult saveResult2;
        if (isBlankSearch)
        {
          saveResult2 = SaveResult.Failure("Please select one or more filter criteria to continue search.");
        }
        else
        {
          saveResult2 = SaveResult.Success;
          saveResult2.ViewModel = (object) new Paged<RfpSearchResultViewModel>((IList<RfpSearchResultViewModel>) searchData, total);
        }
        return saveResult2;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure(ex.Message);
      }
    }

    public ExportResult Export(
      KendoGridRequest request,
      RfpSearchViewModel searchCriteria,
      string exportType,
      string timezoneOffSet)
    {
      try
      {
        bool isBlankSearch = false;
        List<RfpSearchResultViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _, ref isBlankSearch, timezoneOffSet);
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("RFP Search");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".25cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        foreach (SearchResultField searchResultField in searchCriteria.SelectedFields.OrderBy<SearchResultField, int>((Func<SearchResultField, int>) (x => x.Order)).ToList<SearchResultField>())
          tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "RfpSearch", (object) searchData);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return new ExportResult();
      }
    }

    private List<RfpSearchResultViewModel> GetSearchData(
      KendoGridRequest request,
      RfpSearchViewModel searchCriteria,
      out long total,
      ref bool isBlankSearch,
      string timeZoneOffset)
    {
      total = 0L;
      if (searchCriteria.SupervisoryPrincipalReviewDateTo.HasValue)
        searchCriteria.SupervisoryPrincipalReviewDateTo = new DateTime?(searchCriteria.SupervisoryPrincipalReviewDateTo.Value.AddDays(1.0).AddSeconds(-1.0));
      DateTime? nullable1 = searchCriteria.SubmissionDateTo;
      if (nullable1.HasValue)
      {
        RfpSearchViewModel rfpSearchViewModel = searchCriteria;
        nullable1 = searchCriteria.SubmissionDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        rfpSearchViewModel.SubmissionDateTo = nullable2;
      }
      nullable1 = searchCriteria.ResponseDueDateTo;
      if (nullable1.HasValue)
      {
        RfpSearchViewModel rfpSearchViewModel = searchCriteria;
        nullable1 = searchCriteria.ResponseDueDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        rfpSearchViewModel.ResponseDueDateTo = nullable2;
      }
      nullable1 = searchCriteria.CreateDateFrom;
      if (nullable1.HasValue)
      {
        TimeSpan timeSpan = TimeSpan.FromMinutes((double) -Convert.ToInt32(timeZoneOffset));
        DateTimeOffset dateTimeOffset;
        ref DateTimeOffset local = ref dateTimeOffset;
        nullable1 = searchCriteria.CreateDateFrom;
        DateTime dateTime = nullable1.Value;
        TimeSpan offset = timeSpan;
        local = new DateTimeOffset(dateTime, offset);
        DateTime utcDateTime = dateTimeOffset.UtcDateTime;
        searchCriteria.CreateDateFrom = new DateTime?(utcDateTime);
      }
      nullable1 = searchCriteria.CreateDateTo;
      if (nullable1.HasValue)
      {
        RfpSearchViewModel rfpSearchViewModel = searchCriteria;
        nullable1 = searchCriteria.CreateDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        rfpSearchViewModel.CreateDateTo = nullable2;
        TimeSpan timeSpan = TimeSpan.FromMinutes((double) -Convert.ToInt32(timeZoneOffset));
        DateTimeOffset dateTimeOffset;
        ref DateTimeOffset local = ref dateTimeOffset;
        nullable1 = searchCriteria.CreateDateTo;
        DateTime dateTime = nullable1.Value;
        TimeSpan offset = timeSpan;
        local = new DateTimeOffset(dateTime, offset);
        DateTime utcDateTime = dateTimeOffset.UtcDateTime;
        searchCriteria.CreateDateTo = new DateTime?(utcDateTime);
      }
      IVisitableCriterion criterion1 = (IVisitableCriterion) EmptyCriterion.Instance;
      foreach (ExternalPartnerSearchModel externalPartner in searchCriteria.ExternalPartners)
        criterion1 = criterion1.Or("PartnerID".Equal(externalPartner.PartnerID).And("MemberType".Equal(externalPartner.Role)));
      IVisitableCriterion instance = (IVisitableCriterion) EmptyCriterion.Instance;
      IVisitableCriterion visitableCriterion1;
      if (searchCriteria.IsMAExemptionIn)
        visitableCriterion1 = instance.And("RFPMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "rfp")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn).Or("UWMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "underwriting")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).Or("IRMAMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "irma")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).Or("NoneMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "none")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)));
      else
        visitableCriterion1 = instance.And("RFPMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "rfp")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn).And("UWMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "underwriting")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).And("IRMAMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "irma")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)).And("NoneMAExemptionType".AnyOf(searchCriteria.SelectedMAExemptions.Where<KeyPair>((Func<KeyPair, bool>) (x => x.Value.ToLower() == "none")).Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsMAExemptionIn)));
      List<SubQueryDefinition> subQueryDefinitionList = new List<SubQueryDefinition>();
      IVisitableCriterion criterion2 = (IVisitableCriterion) EmptyCriterion.Instance;
      bool flag = false;
      if (searchCriteria.SelectedRfpStatuses.Count > 0)
      {
        if (!searchCriteria.IsRfpStatusIn)
        {
          flag = true;
          subQueryDefinitionList.Add(new SubQueryDefinition()
          {
            Field = "RFPStatusID",
            Operator = "Out",
            Value = string.Join(",", searchCriteria.SelectedRfpStatuses.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>())
          });
        }
        else
          criterion2 = criterion2.And("RFPStatusID".AnyOf(searchCriteria.SelectedRfpStatuses.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsRfpStatusIn));
      }
      IVisitableCriterion visitableCriterion2 = "RfpNumber".Equal(string.IsNullOrEmpty(searchCriteria.RfpNumber) ? searchCriteria.RfpNumber : searchCriteria.RfpNumber.Trim()).And().And(criterion2).And(Criterion.Contains("RfpName", string.IsNullOrEmpty(searchCriteria.RfpName) ? searchCriteria.RfpName : searchCriteria.RfpName.Trim())).And("RfpStateID".AnyOf(searchCriteria.SelectedRfpStates.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsRfpStateIn)).And(Criterion.Contains("Issuer", string.IsNullOrEmpty(searchCriteria.Issuer) ? searchCriteria.Issuer : searchCriteria.Issuer.Trim()).Or(Criterion.Contains("IssuerAliasName", string.IsNullOrEmpty(searchCriteria.Issuer) ? searchCriteria.Issuer : searchCriteria.Issuer.Trim()))).And("IssuerStateID".AnyOf(searchCriteria.SelectedIssuerStates.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsIssuerStateIn)).And("RfpTypeID".Equal(searchCriteria.RfpType)).And("ExpectedFirmRoleID".AnyOf(searchCriteria.SelectedExpectedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsExpectedFirmRoleIn)).And("AssignedFirmRoleID".AnyOf(searchCriteria.SelectedAssignedFirmRoles.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsAssignedFirmRoleIn)).And(visitableCriterion1).And("PurposeID".Equal(string.IsNullOrEmpty(searchCriteria.Purpose) ? searchCriteria.Purpose : searchCriteria.Purpose.Trim())).And("GeneralCategoryID".AnyOf(searchCriteria.SelectedGeneralCategories.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Key)).ToArray<string>()).ComplementIf(!searchCriteria.IsGeneralCategoryIn)).And("FedTaxable".Equal(searchCriteria.FedTaxable)).And("StateTaxable".Equal(searchCriteria.StateTaxable)).And("AMTTaxable".Equal(searchCriteria.AMTTaxable)).And("IsBankQualified".Equal<bool>(searchCriteria.BankQualified)).And("ParAmount".GreaterThanOrEqual<Decimal>(this.ConvertToDecimal(searchCriteria.ParAmountFrom))).And("ParAmount".LessThanOrEqual<Decimal>(this.ConvertToDecimal(searchCriteria.ParAmountTo))).And("SupervisoryPrincipalReviewDate".GreaterThanOrEqual<DateTime>(searchCriteria.SupervisoryPrincipalReviewDateFrom)).And("SupervisoryPrincipalReviewDate".LessThanOrEqual<DateTime>(searchCriteria.SupervisoryPrincipalReviewDateTo)).And("SubmissionDateTime".GreaterThanOrEqual<DateTime>(searchCriteria.SubmissionDateFrom)).And("SubmissionDateTime".LessThanOrEqual<DateTime>(searchCriteria.SubmissionDateTo)).And("ResponseDueDateTime".GreaterThanOrEqual<DateTime>(searchCriteria.ResponseDueDateFrom)).And("ResponseDueDateTime".LessThanOrEqual<DateTime>(searchCriteria.ResponseDueDateTo)).And("CreatedOn".GreaterThanOrEqual<DateTime>(searchCriteria.CreateDateFrom)).And("CreatedOn".LessThanOrEqual<DateTime>(searchCriteria.CreateDateTo)).And("MoodyRatingLT".Equal(searchCriteria.MoodyLongTermRating)).And("SPRatingLT".Equal(searchCriteria.SPLongTermRating)).And("KrollRatingLT".Equal(searchCriteria.KrollLongTermRating)).And("FitchRatingLT".Equal(searchCriteria.FitchLongTermRating)).And("LeadBankerId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "lead banker")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>()).Or("BankerId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "banker")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("LeadAnalystId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "lead analyst")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("AnalystId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "analyst")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("SupervisoryPrincipalId".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "supervisory principal")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.EmployeeID)).ToArray<string>())).Or("BankRMName".AnyOf(searchCriteria.InternalPartners.Where<InternalPartnerSearchModel>((Func<InternalPartnerSearchModel, bool>) (x => x.Type.ToLower() == "bank rm")).Select<InternalPartnerSearchModel, string>((Func<InternalPartnerSearchModel, string>) (x => x.Name)).ToArray<string>()))).And(criterion1);
      if (visitableCriterion2 == EmptyCriterion.Instance && !flag)
      {
        isBlankSearch = true;
        return new List<RfpSearchResultViewModel>();
      }
      IVisitableCriterion visitableCriterion3 = "Principal".AnyOf(((IEnumerable<int>) this.AppUser.GetEffectivePrincipalIds()).Select<int, string>((Func<int, string>) (x => x.ToString())).ToArray<string>()).And().And(visitableCriterion2);
      List<string> list = searchCriteria.SelectedFields.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Html.field)).ToList<string>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      List<RfpSearchResultViewModel> searchResultViewModelList = new List<RfpSearchResultViewModel>();
      using (IDataReader dataReader = this.RFPRepository.Query(new QueryDefinition()
      {
        Criterion = visitableCriterion3,
        Order = orderingList.ToArray(),
        Projection = (IEnumerable<string>) list,
        SubQueryDefinitions = subQueryDefinitionList
      }, request.take, (int) request.skip))
      {
        if (dataReader != null)
        {
          IRowMapper<RfpSearchResultViewModel> rowMapper = MapBuilder<RfpSearchResultViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            searchResultViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return searchResultViewModelList;
    }

    private string ConvertDateFormat(string value)
    {
      DateTime result;
      return !string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result) ? result.ToString("MM/dd/yyyy") : "";
    }

    private bool ValidateModel(RFPViewModel rfpViewModel, ref SaveResult saveResult)
    {
      long? nullable1 = rfpViewModel.FirmRole;
      long num1 = -12;
      Decimal? nullable2;
      if ((nullable1.GetValueOrDefault() == num1 ? (nullable1.HasValue ? 1 : 0) : 0) != 0)
      {
        nullable2 = rfpViewModel.FirmLiabilityPerc;
        Decimal num2 = (Decimal) 100;
        if ((nullable2.GetValueOrDefault() < num2 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
          saveResult.Errors.Add("RFP", (object) "Expected Firm Liability%  cannot be less than 100%.");
      }
      nullable2 = rfpViewModel.FirmLiabilityPerc;
      Decimal num3 = (Decimal) 100;
      if ((nullable2.GetValueOrDefault() > num3 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("RFP", (object) "Expected Firm Liability% value cannot be greater than 100%.");
      nullable1 = rfpViewModel.AssignedFirmRole;
      long num4 = -12;
      if ((nullable1.GetValueOrDefault() == num4 ? (nullable1.HasValue ? 1 : 0) : 0) != 0)
      {
        nullable2 = rfpViewModel.AssignedFirmLiability;
        Decimal num2 = (Decimal) 100;
        if ((nullable2.GetValueOrDefault() < num2 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
          saveResult.Errors.Add("RFP", (object) "Assigned Firm Liability%  cannot be less than 100%.");
      }
      nullable2 = rfpViewModel.AssignedFirmLiability;
      Decimal num5 = (Decimal) 100;
      if ((nullable2.GetValueOrDefault() > num5 ? (nullable2.HasValue ? 1 : 0) : 0) != 0)
        saveResult.Errors.Add("RFP", (object) "Assigned Firm Liability% value cannot be greater than 100%.");
      if (this.RFPRepository.CheckForDuplicateRFPName(rfpViewModel.AppTransactionID, rfpViewModel.RFPName != null ? rfpViewModel.RFPName.Trim() : rfpViewModel.RFPName))
        saveResult.Errors.Add("RFP Name duplicate", (object) "Duplicate RFP name.");
      return saveResult.IsSuccessful;
    }

    private Decimal? ConvertToDecimal(string str) => string.IsNullOrEmpty(str) ? new Decimal?() : new Decimal?(Convert.ToDecimal(str));

    public List<string> GetRfpNames(string rfpName)
    {
      try
      {
        return this.RFPRepository.FetchRfpNames(rfpName).ToList<string>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<string>();
      }
    }

    private List<WorkflowStateViewModel> GetWorkflowState(
      IEnumerable<Transition<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>> stateTransitions,
      IrisSoftware.iMPACT.Data.RFP rfp)
    {
      List<WorkflowStateViewModel> source = new List<WorkflowStateViewModel>();
      foreach (Transition<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> stateTransition in stateTransitions)
      {
        Transition<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> transition = stateTransition;
        long fromStateId = (long) transition.FromState.Key;
        string valueDescription1 = ReflectionUtils.GetEnumValueDescription((System.Enum) transition.FromState.Key);
        foreach (IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> toState in transition.ToStates)
        {
          long toStateId = (long) toState.Key;
          string valueDescription2 = ReflectionUtils.GetEnumValueDescription((System.Enum) toState.Key);
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == fromStateId)))
          {
            bool flag1 = rfp.RfpDetail.RFPStatus.Contains((long) transition.FromState.Key);
            bool flag2 = rfp.WorkflowStateTransitions != null && rfp.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long key1 = (long) transition.FromState.Key;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((key1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long key2 = (long) transition.FromState.Key;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return key2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = fromStateId,
              StateName = valueDescription1,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
          if (!source.Any<WorkflowStateViewModel>((Func<WorkflowStateViewModel, bool>) (state => state.Id == toStateId)))
          {
            bool flag1 = rfp.RfpDetail.RFPStatus.Contains(toStateId);
            bool flag2 = rfp.WorkflowStateTransitions != null && rfp.WorkflowStateTransitions.Any<AppTransactionStateTransition>((Func<AppTransactionStateTransition, bool>) (itm =>
            {
              long num1 = toStateId;
              long? nullable = itm.FromStateID;
              long valueOrDefault1 = nullable.GetValueOrDefault();
              if ((num1 == valueOrDefault1 ? (nullable.HasValue ? 1 : 0) : 0) != 0)
                return true;
              long num2 = toStateId;
              nullable = itm.ToStateID;
              long valueOrDefault2 = nullable.GetValueOrDefault();
              return num2 == valueOrDefault2 && nullable.HasValue;
            }));
            source.Add(new WorkflowStateViewModel()
            {
              Id = toStateId,
              StateName = valueDescription2,
              IsActive = flag1,
              IsVisited = flag2
            });
          }
        }
      }
      return source;
    }

    public ClientViewModel GetClientDetailsByKey(long clientId) => new ClientViewModel(this.ClientRepository.FetchByKey(clientId));

    private List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> GetRFPStatusListFromStatusIDList(
      List<long> lstRfpStatusID)
    {
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> rfpStatusList = new List<IrisSoftware.iMPACT.Data.RFP.RfpStatus>();
      foreach (long num in lstRfpStatusID)
        rfpStatusList.Add((IrisSoftware.iMPACT.Data.RFP.RfpStatus) num);
      return rfpStatusList;
    }

    private List<RfpFromStateToState> GetTransitionFromToState(
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> oldStatusList,
      TransitionResult<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> transitionResult)
    {
      List<RfpFromStateToState> fromStateToStateList = new List<RfpFromStateToState>();
      IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> actionState = transitionResult.ActionState;
      IEnumerable<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>> intermediateStates = transitionResult.IntermediateStates;
      IEnumerable<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>> resultingStates = transitionResult.ResultingStates;
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> first = new List<IrisSoftware.iMPACT.Data.RFP.RfpStatus>();
      foreach (IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> state in resultingStates)
        first.Add(state.Key);
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> list = oldStatusList.Except<IrisSoftware.iMPACT.Data.RFP.RfpStatus>((IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>) first).ToList<IrisSoftware.iMPACT.Data.RFP.RfpStatus>();
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> filteredToState = first.Except<IrisSoftware.iMPACT.Data.RFP.RfpStatus>((IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>) oldStatusList).ToList<IrisSoftware.iMPACT.Data.RFP.RfpStatus>();
      if (intermediateStates.Count<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>>() > 0)
        list.Remove(actionState.Key);
      foreach (IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> state in intermediateStates)
      {
        fromStateToStateList.Add(new RfpFromStateToState(new IrisSoftware.iMPACT.Data.RFP.RfpStatus?(actionState.Key), state.Key));
        list.Add(state.Key);
      }
      foreach (KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus> keyValuePair in list.SelectMany<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus, KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>>((Func<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>>) (fromStatus => (IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>) filteredToState), (Func<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus, KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>>) ((fromStatus, toStatus) => new KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>(fromStatus, toStatus))))
        fromStateToStateList.Add(new RfpFromStateToState(new IrisSoftware.iMPACT.Data.RFP.RfpStatus?(keyValuePair.Key), keyValuePair.Value));
      return fromStateToStateList;
    }

    private List<RfpFromStateToState> GetAuditFromToState(
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> oldStatusList,
      TransitionResult<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> transitionResult)
    {
      List<RfpFromStateToState> fromStateToStateList = new List<RfpFromStateToState>();
      IEnumerable<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>> resultingStates = transitionResult.ResultingStates;
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> resultingStatusList = new List<IrisSoftware.iMPACT.Data.RFP.RfpStatus>();
      foreach (IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> state in resultingStates)
        resultingStatusList.Add(state.Key);
      foreach (KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus> keyValuePair in oldStatusList.SelectMany<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus, KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>>((Func<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>>) (fromStatus => (IEnumerable<IrisSoftware.iMPACT.Data.RFP.RfpStatus>) resultingStatusList), (Func<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus, KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>>) ((fromStatus, toStatus) => new KeyValuePair<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP.RfpStatus>(fromStatus, toStatus))))
        fromStateToStateList.Add(new RfpFromStateToState(new IrisSoftware.iMPACT.Data.RFP.RfpStatus?(keyValuePair.Key), keyValuePair.Value));
      return fromStateToStateList;
    }

    public ExportResult ExportRFPPipeline(KendoGridRequest request)
    {
      try
      {
        List<RFPPipelineViewModel> all = this.GetAll();
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        Func<RFPPipelineViewModel, \u003C\u003Ef__AnonymousType16<string, string, string, string, string, Decimal?, string, string, string, string, string>> selector = d =>
        {
          string issuerName = d.IssuerName;
          string rfpName = d.RFPName;
          string state = d.State;
          string rfpStatusValue = d.RFPStatusValue;
          string rfpReviewStatus = d.RFPReviewStatus;
          Decimal? nullable1 = this.ConvertToDecimal(d.ParAmount);
          string expectedFirmRole = d.ExpectedFirmRole;
          string leadBanker = d.LeadBanker;
          string financialAdvisorName = d.FinancialAdvisorName;
          DateTime? nullable2;
          string str1;
          if (!d.ResponseDueDateTime.HasValue)
          {
            str1 = "";
          }
          else
          {
            nullable2 = d.ResponseDueDateTime;
            str1 = this.ConvertDateFormat(nullable2.ToString());
          }
          nullable2 = d.SubmissionDateTime;
          string str2;
          if (!nullable2.HasValue)
          {
            str2 = "";
          }
          else
          {
            nullable2 = d.SubmissionDateTime;
            str2 = this.ConvertDateFormat(nullable2.ToString());
          }
          return new
          {
            IssuerName = issuerName,
            RFPName = rfpName,
            State = state,
            RFPStatusValue = rfpStatusValue,
            RFPReviewStatus = rfpReviewStatus,
            ParAmount = nullable1,
            ExpectedFirmRole = expectedFirmRole,
            LeadBanker = leadBanker,
            FinancialAdvisorName = financialAdvisorName,
            ResponseDueDateTime = str1,
            SubmissionDateTime = str2
          };
        };
        IEnumerable<\u003C\u003Ef__AnonymousType16<string, string, string, string, string, Decimal?, string, string, string, string, string>> datas = all.Select(selector);
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("RFP Pipeline");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".25cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        tabularReportBuilder.AddColumn("Issuer", "IssuerName", Unit.Parse("7cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("RFP Name", "RFPName", Unit.Parse("7cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("State", "State", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("RFP Status", "RFPStatusValue", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Review Status", "RFPReviewStatus", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Par Amount", "ParAmount", Unit.Parse("3cm"), "$#,##0.00", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Expected Firm Role", "ExpectedFirmRole", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Lead Banker", "LeadBanker", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Financial Advisor", "FinancialAdvisorName", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("RFP Response Date", "ResponseDueDateTime", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Submission Date", "SubmissionDateTime", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider2);
        return new ReportExporter().Export(tabularReportBuilder.Build(), "excel", "RFPPipeline", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return new ExportResult();
      }
    }

    private List<int> GetTransitionStateTracking(
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> oldStatusList,
      TransitionResult<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> transitionResult)
    {
      List<int> intList = new List<int>();
      IEnumerable<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>> resultingStates = transitionResult.ResultingStates;
      IEnumerable<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>> intermediateStates = transitionResult.IntermediateStates;
      if (intermediateStates != null && intermediateStates.Count<IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP>>() > 0)
      {
        IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> actionState = transitionResult.ActionState;
        foreach (IrisSoftware.iMPACT.Data.RFP.RfpStatus oldStatus in oldStatusList)
        {
          if (oldStatus != actionState.Key)
            intList.Add((int) oldStatus);
        }
        foreach (IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> state in intermediateStates)
          intList.Add((int) state.Key);
      }
      else
      {
        foreach (IState<IrisSoftware.iMPACT.Data.RFP.RfpStatus, IrisSoftware.iMPACT.Data.RFP> state in resultingStates)
          intList.Add((int) state.Key);
      }
      return intList;
    }

    private List<SearchResultField> GetAllSearchResultFields()
    {
      List<SearchResultField> searchResultFieldList = new List<SearchResultField>();
      int num1 = 1;
      SearchResultField searchResultField1 = new SearchResultField();
      searchResultField1.Name = "RFP Number";
      searchResultField1.ExportField = "RFPNumber";
      int num2 = num1;
      int num3 = num2 + 1;
      searchResultField1.Order = num2;
      searchResultField1.Html = new SearchResultFieldHtml()
      {
        field = "RFPNumber",
        title = "RFP Number",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField1);
      SearchResultField searchResultField2 = new SearchResultField();
      searchResultField2.Name = "RFP Name";
      searchResultField2.ExportField = "RFPName";
      int num4 = num3;
      int num5 = num4 + 1;
      searchResultField2.Order = num4;
      searchResultField2.IsMandatory = true;
      searchResultField2.Html = new SearchResultFieldHtml()
      {
        field = "RFPName",
        title = "RFP Name",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "5cm",
        template = "<a href='Rfp.aspx?AppId=#= AppTransactionID #' target='_blank'>#= RFPName #</a>"
      };
      searchResultFieldList.Add(searchResultField2);
      SearchResultField searchResultField3 = new SearchResultField();
      searchResultField3.Name = "RFP Status";
      searchResultField3.ExportField = "RFPStatus";
      int num6 = num5;
      int num7 = num6 + 1;
      searchResultField3.Order = num6;
      searchResultField3.Html = new SearchResultFieldHtml()
      {
        field = "RFPStatus",
        title = "RFP Status",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField3);
      SearchResultField searchResultField4 = new SearchResultField();
      searchResultField4.Name = "Review Status";
      searchResultField4.ExportField = "RFPReviewStatus";
      int num8 = num7;
      int num9 = num8 + 1;
      searchResultField4.Order = num8;
      searchResultField4.Html = new SearchResultFieldHtml()
      {
        field = "RFPReviewStatus",
        title = "Review History",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField4);
      SearchResultField searchResultField5 = new SearchResultField();
      searchResultField5.Name = "Power ID";
      searchResultField5.ExportField = "PowerID";
      int num10 = num9;
      int num11 = num10 + 1;
      searchResultField5.Order = num10;
      searchResultField5.Html = new SearchResultFieldHtml()
      {
        field = "PowerID",
        title = "Power ID",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField5);
      SearchResultField searchResultField6 = new SearchResultField();
      searchResultField6.Name = "Issuer";
      searchResultField6.ExportField = "Issuer";
      int num12 = num11;
      int num13 = num12 + 1;
      searchResultField6.Order = num12;
      searchResultField6.IsMandatory = true;
      searchResultField6.Html = new SearchResultFieldHtml()
      {
        field = "Issuer",
        title = "Issuer",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField6);
      SearchResultField searchResultField7 = new SearchResultField();
      searchResultField7.Name = "Borrower/Obligor";
      searchResultField7.ExportField = "Borrower";
      int num14 = num13;
      int num15 = num14 + 1;
      searchResultField7.Order = num14;
      searchResultField7.Html = new SearchResultFieldHtml()
      {
        field = "Borrower",
        title = "Borrower/Obligor",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField7);
      SearchResultField searchResultField8 = new SearchResultField();
      searchResultField8.Name = "Guarantor";
      searchResultField8.ExportField = "Guarantor";
      int num16 = num15;
      int num17 = num16 + 1;
      searchResultField8.Order = num16;
      searchResultField8.Html = new SearchResultFieldHtml()
      {
        field = "Guarantor",
        title = "Guarantor",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField8);
      SearchResultField searchResultField9 = new SearchResultField();
      searchResultField9.Name = "RFP Type";
      searchResultField9.ExportField = "RFPType";
      int num18 = num17;
      int num19 = num18 + 1;
      searchResultField9.Order = num18;
      searchResultField9.Html = new SearchResultFieldHtml()
      {
        field = "RFPType",
        title = "RFP Type",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField9);
      SearchResultField searchResultField10 = new SearchResultField();
      searchResultField10.Name = "State";
      searchResultField10.ExportField = "State";
      int num20 = num19;
      int num21 = num20 + 1;
      searchResultField10.Order = num20;
      searchResultField10.Html = new SearchResultFieldHtml()
      {
        field = "State",
        title = "State",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField10);
      SearchResultField searchResultField11 = new SearchResultField();
      searchResultField11.Name = "County";
      searchResultField11.ExportField = "County";
      int num22 = num21;
      int num23 = num22 + 1;
      searchResultField11.Order = num22;
      searchResultField11.Html = new SearchResultFieldHtml()
      {
        field = "County",
        title = "County",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField11);
      SearchResultField searchResultField12 = new SearchResultField();
      searchResultField12.Name = "Material Type";
      searchResultField12.ExportField = "MaterialType";
      int num24 = num23;
      int num25 = num24 + 1;
      searchResultField12.Order = num24;
      searchResultField12.Html = new SearchResultFieldHtml()
      {
        field = "MaterialType",
        title = "Material Type",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField12);
      SearchResultField searchResultField13 = new SearchResultField();
      searchResultField13.Name = "Dual Proposal Requested";
      searchResultField13.ExportField = "HybridSolutionIndicator";
      int num26 = num25;
      int num27 = num26 + 1;
      searchResultField13.Order = num26;
      searchResultField13.Html = new SearchResultFieldHtml()
      {
        field = "HybridSolutionIndicator",
        title = "Dual Proposal Requested",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField13);
      SearchResultField searchResultField14 = new SearchResultField();
      searchResultField14.Name = "Dual Proposal Proposed";
      searchResultField14.ExportField = "DualProposalProposed";
      int num28 = num27;
      int num29 = num28 + 1;
      searchResultField14.Order = num28;
      searchResultField14.Html = new SearchResultFieldHtml()
      {
        field = "DualProposalProposed",
        title = "Dual Proposal Proposed",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField14);
      SearchResultField searchResultField15 = new SearchResultField();
      searchResultField15.Name = "Informational MERG Required?";
      searchResultField15.ExportField = "InformationalMERGRequired";
      int num30 = num29;
      int num31 = num30 + 1;
      searchResultField15.Order = num30;
      searchResultField15.Html = new SearchResultFieldHtml()
      {
        field = "InformationalMERGRequired",
        title = "Informational MERG Required?",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField15);
      SearchResultField searchResultField16 = new SearchResultField();
      searchResultField16.Name = "RFP MA Exemption";
      searchResultField16.ExportField = "RFPMAExemption";
      int num32 = num31;
      int num33 = num32 + 1;
      searchResultField16.Order = num32;
      searchResultField16.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemption",
        title = "RFP MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField16);
      SearchResultField searchResultField17 = new SearchResultField();
      searchResultField17.Name = "RFP MA Exemption Date";
      searchResultField17.ExportField = "RFPMAExemptionDateValue";
      int num34 = num33;
      int num35 = num34 + 1;
      searchResultField17.Order = num34;
      searchResultField17.Html = new SearchResultFieldHtml()
      {
        field = "RFPMAExemptionDate",
        title = "RFP MA Exemption Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToString(RFPMAExemptionDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      searchResultFieldList.Add(searchResultField17);
      SearchResultField searchResultField18 = new SearchResultField();
      searchResultField18.Name = "IRMA MA Exemption";
      searchResultField18.ExportField = "IRMAMAExemption";
      int num36 = num35;
      int num37 = num36 + 1;
      searchResultField18.Order = num36;
      searchResultField18.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemption",
        title = "IRMA MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField18);
      SearchResultField searchResultField19 = new SearchResultField();
      searchResultField19.Name = "IRMA MA Exemption Date";
      searchResultField19.ExportField = "IRMAMAExemptionDateValue";
      int num38 = num37;
      int num39 = num38 + 1;
      searchResultField19.Order = num38;
      searchResultField19.Html = new SearchResultFieldHtml()
      {
        field = "IRMAMAExemptionDate",
        title = "IRMA MA Exemption Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToString(IRMAMAExemptionDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      searchResultFieldList.Add(searchResultField19);
      SearchResultField searchResultField20 = new SearchResultField();
      searchResultField20.Name = "UW MA Exemption";
      searchResultField20.ExportField = "UWMAExemption";
      int num40 = num39;
      int num41 = num40 + 1;
      searchResultField20.Order = num40;
      searchResultField20.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemption",
        title = "UW MA Exemption",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField20);
      SearchResultField searchResultField21 = new SearchResultField();
      searchResultField21.Name = "UW MA Exemption Date";
      searchResultField21.ExportField = "UWMAExemptionDateValue";
      int num42 = num41;
      int num43 = num42 + 1;
      searchResultField21.Order = num42;
      searchResultField21.Html = new SearchResultFieldHtml()
      {
        field = "UWMAExemptionDate",
        title = "UW MA Exemption Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToString(UWMAExemptionDate) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      searchResultFieldList.Add(searchResultField21);
      SearchResultField searchResultField22 = new SearchResultField();
      searchResultField22.Name = "Par Amount";
      searchResultField22.ExportField = "ParAmount";
      int num44 = num43;
      int num45 = num44 + 1;
      searchResultField22.Order = num44;
      searchResultField22.Html = new SearchResultFieldHtml()
      {
        field = "ParAmount",
        title = "Par Amount",
        sortable = true,
        isLeftAligned = false,
        width = "120px",
        excelWidth = "3.9cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList.Add(searchResultField22);
      SearchResultField searchResultField23 = new SearchResultField();
      searchResultField23.Name = "Expected Firm Role";
      searchResultField23.ExportField = "ExpectedFirmRole";
      int num46 = num45;
      int num47 = num46 + 1;
      searchResultField23.Order = num46;
      searchResultField23.Html = new SearchResultFieldHtml()
      {
        field = "ExpectedFirmRole",
        title = "Expected Firm Role",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField23);
      SearchResultField searchResultField24 = new SearchResultField();
      searchResultField24.Name = "Expected Firm Liability%";
      searchResultField24.ExportField = "ExpectedFirmLiabilityPercentage";
      int num48 = num47;
      int num49 = num48 + 1;
      searchResultField24.Order = num48;
      searchResultField24.Html = new SearchResultFieldHtml()
      {
        field = "ExpectedFirmLiabilityPercentage",
        title = "Expected Firm Liability%",
        sortable = true,
        isLeftAligned = false,
        width = "160px",
        excelWidth = "2.5cm",
        style = "text-align: right !important;",
        excelFormat = "#,##0.000"
      };
      searchResultFieldList.Add(searchResultField24);
      SearchResultField searchResultField25 = new SearchResultField();
      searchResultField25.Name = "Assigned Firm Role";
      searchResultField25.ExportField = "AssignedFirmRole";
      int num50 = num49;
      int num51 = num50 + 1;
      searchResultField25.Order = num50;
      searchResultField25.Html = new SearchResultFieldHtml()
      {
        field = "AssignedFirmRole",
        title = "Assigned Firm Role",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField25);
      SearchResultField searchResultField26 = new SearchResultField();
      searchResultField26.Name = "Assigned Firm Liability%";
      searchResultField26.ExportField = "AssignedFirmLiabilityPercentage";
      int num52 = num51;
      int num53 = num52 + 1;
      searchResultField26.Order = num52;
      searchResultField26.Html = new SearchResultFieldHtml()
      {
        field = "AssignedFirmLiabilityPercentage",
        title = "Assigned Firm Liability%",
        sortable = true,
        isLeftAligned = false,
        width = "160px",
        excelWidth = "2.5cm",
        style = "text-align: right !important;"
      };
      searchResultFieldList.Add(searchResultField26);
      SearchResultField searchResultField27 = new SearchResultField();
      searchResultField27.Name = "Lead banker";
      searchResultField27.ExportField = "LeadBanker";
      int num54 = num53;
      int num55 = num54 + 1;
      searchResultField27.Order = num54;
      searchResultField27.Html = new SearchResultFieldHtml()
      {
        field = "LeadBanker",
        title = "Lead banker",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField27);
      SearchResultField searchResultField28 = new SearchResultField();
      searchResultField28.Name = "Banker";
      searchResultField28.ExportField = "Banker";
      int num56 = num55;
      int num57 = num56 + 1;
      searchResultField28.Order = num56;
      searchResultField28.Html = new SearchResultFieldHtml()
      {
        field = "Banker",
        title = "Banker",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField28);
      SearchResultField searchResultField29 = new SearchResultField();
      searchResultField29.Name = "Lead Analyst";
      searchResultField29.ExportField = "LeadAnalyst";
      int num58 = num57;
      int num59 = num58 + 1;
      searchResultField29.Order = num58;
      searchResultField29.Html = new SearchResultFieldHtml()
      {
        field = "LeadAnalyst",
        title = "Lead Analyst",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField29);
      SearchResultField searchResultField30 = new SearchResultField();
      searchResultField30.Name = "Analyst";
      searchResultField30.ExportField = "Analyst";
      int num60 = num59;
      int num61 = num60 + 1;
      searchResultField30.Order = num60;
      searchResultField30.Html = new SearchResultFieldHtml()
      {
        field = "Analyst",
        title = "Analyst",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField30);
      SearchResultField searchResultField31 = new SearchResultField();
      searchResultField31.Name = "Supervisory Principal";
      searchResultField31.ExportField = "SupervisoryPrincipal";
      int num62 = num61;
      int num63 = num62 + 1;
      searchResultField31.Order = num62;
      searchResultField31.Html = new SearchResultFieldHtml()
      {
        field = "SupervisoryPrincipal",
        title = "Supervisory Principal",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField31);
      SearchResultField searchResultField32 = new SearchResultField();
      searchResultField32.Name = "Bank RM";
      searchResultField32.ExportField = "BankRM";
      int num64 = num63;
      int num65 = num64 + 1;
      searchResultField32.Order = num64;
      searchResultField32.Html = new SearchResultFieldHtml()
      {
        field = "BankRM",
        title = "Bank RM",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField32);
      SearchResultField searchResultField33 = new SearchResultField();
      searchResultField33.Name = "Financial Advisor";
      searchResultField33.ExportField = "FinancialAdvisor";
      int num66 = num65;
      int num67 = num66 + 1;
      searchResultField33.Order = num66;
      searchResultField33.Html = new SearchResultFieldHtml()
      {
        field = "FinancialAdvisor",
        title = "Financial Advisor",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField33);
      SearchResultField searchResultField34 = new SearchResultField();
      searchResultField34.Name = "Escrow Verification Agent";
      searchResultField34.ExportField = "EscrowVerificationAgent";
      int num68 = num67;
      int num69 = num68 + 1;
      searchResultField34.Order = num68;
      searchResultField34.Html = new SearchResultFieldHtml()
      {
        field = "EscrowVerificationAgent",
        title = "Escrow Verification Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField34);
      SearchResultField searchResultField35 = new SearchResultField();
      searchResultField35.Name = "Escrow Securities Provider";
      searchResultField35.ExportField = "EscrowSecuritiesProvider";
      int num70 = num69;
      int num71 = num70 + 1;
      searchResultField35.Order = num70;
      searchResultField35.Html = new SearchResultFieldHtml()
      {
        field = "EscrowSecuritiesProvider",
        title = "Escrow Securities Provider",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField35);
      SearchResultField searchResultField36 = new SearchResultField();
      searchResultField36.Name = "Escrow Agent For Refunded Bonds";
      searchResultField36.ExportField = "EscrowAgentForRefundedBonds";
      int num72 = num71;
      int num73 = num72 + 1;
      searchResultField36.Order = num72;
      searchResultField36.Html = new SearchResultFieldHtml()
      {
        field = "EscrowAgentForRefundedBonds",
        title = "Escrow Agent for Refunded Bonds",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField36);
      SearchResultField searchResultField37 = new SearchResultField();
      searchResultField37.Name = "Paying Agent";
      searchResultField37.ExportField = "PayingAgent";
      int num74 = num73;
      int num75 = num74 + 1;
      searchResultField37.Order = num74;
      searchResultField37.Html = new SearchResultFieldHtml()
      {
        field = "PayingAgent",
        title = "Paying Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField37);
      SearchResultField searchResultField38 = new SearchResultField();
      searchResultField38.Name = "Remarketing Agent";
      searchResultField38.ExportField = "RemarketingAgent";
      int num76 = num75;
      int num77 = num76 + 1;
      searchResultField38.Order = num76;
      searchResultField38.Html = new SearchResultFieldHtml()
      {
        field = "RemarketingAgent",
        title = "Remarketing Agent",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField38);
      SearchResultField searchResultField39 = new SearchResultField();
      searchResultField39.Name = "Trustee";
      searchResultField39.ExportField = "Trustee";
      int num78 = num77;
      int num79 = num78 + 1;
      searchResultField39.Order = num78;
      searchResultField39.Html = new SearchResultFieldHtml()
      {
        field = "Trustee",
        title = "Trustee",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField39);
      SearchResultField searchResultField40 = new SearchResultField();
      searchResultField40.Name = "Other Advisor Agents";
      searchResultField40.ExportField = "OtherAdvisorAgents";
      int num80 = num79;
      int num81 = num80 + 1;
      searchResultField40.Order = num80;
      searchResultField40.Html = new SearchResultFieldHtml()
      {
        field = "OtherAdvisorAgents",
        title = "Other Advisor Agents",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField40);
      SearchResultField searchResultField41 = new SearchResultField();
      searchResultField41.Name = "Bond Counsel";
      searchResultField41.ExportField = "BondCounsel";
      int num82 = num81;
      int num83 = num82 + 1;
      searchResultField41.Order = num82;
      searchResultField41.Html = new SearchResultFieldHtml()
      {
        field = "BondCounsel",
        title = "Bond Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField41);
      SearchResultField searchResultField42 = new SearchResultField();
      searchResultField42.Name = "Underwriter Counsel";
      searchResultField42.ExportField = "UnderwriterCounsel";
      int num84 = num83;
      int num85 = num84 + 1;
      searchResultField42.Order = num84;
      searchResultField42.Html = new SearchResultFieldHtml()
      {
        field = "UnderwriterCounsel",
        title = "Underwriter Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField42);
      SearchResultField searchResultField43 = new SearchResultField();
      searchResultField43.Name = "Disclosure Counsel";
      searchResultField43.ExportField = "DisclosureCounsel";
      int num86 = num85;
      int num87 = num86 + 1;
      searchResultField43.Order = num86;
      searchResultField43.Html = new SearchResultFieldHtml()
      {
        field = "DisclosureCounsel",
        title = "Disclosure Counsel",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField43);
      SearchResultField searchResultField44 = new SearchResultField();
      searchResultField44.Name = "Other Counsels";
      searchResultField44.ExportField = "OtherCounsels";
      int num88 = num87;
      int num89 = num88 + 1;
      searchResultField44.Order = num88;
      searchResultField44.Html = new SearchResultFieldHtml()
      {
        field = "OtherCounsels",
        title = "Other Counsels",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField44);
      SearchResultField searchResultField45 = new SearchResultField();
      searchResultField45.Name = "Purpose";
      searchResultField45.ExportField = "Purpose";
      int num90 = num89;
      int num91 = num90 + 1;
      searchResultField45.Order = num90;
      searchResultField45.Html = new SearchResultFieldHtml()
      {
        field = "Purpose",
        title = "Purpose",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField45);
      SearchResultField searchResultField46 = new SearchResultField();
      searchResultField46.Name = "Transaction Type";
      searchResultField46.ExportField = "TransactionType";
      int num92 = num91;
      int num93 = num92 + 1;
      searchResultField46.Order = num92;
      searchResultField46.Html = new SearchResultFieldHtml()
      {
        field = "TransactionType",
        title = "Transaction Type",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField46);
      SearchResultField searchResultField47 = new SearchResultField();
      searchResultField47.Name = "Security Type";
      searchResultField47.ExportField = "SecurityType";
      int num94 = num93;
      int num95 = num94 + 1;
      searchResultField47.Order = num94;
      searchResultField47.Html = new SearchResultFieldHtml()
      {
        field = "SecurityType",
        title = "Security Type",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField47);
      SearchResultField searchResultField48 = new SearchResultField();
      searchResultField48.Name = "General Category";
      searchResultField48.ExportField = "GeneralCategory";
      int num96 = num95;
      int num97 = num96 + 1;
      searchResultField48.Order = num96;
      searchResultField48.Html = new SearchResultFieldHtml()
      {
        field = "GeneralCategory",
        title = "General Category",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField48);
      SearchResultField searchResultField49 = new SearchResultField();
      searchResultField49.Name = "Fed Tax";
      searchResultField49.ExportField = "FedTaxable";
      int num98 = num97;
      int num99 = num98 + 1;
      searchResultField49.Order = num98;
      searchResultField49.Html = new SearchResultFieldHtml()
      {
        field = "FedTaxable",
        title = "Fed Tax",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField49);
      SearchResultField searchResultField50 = new SearchResultField();
      searchResultField50.Name = "State Tax";
      searchResultField50.ExportField = "StateTaxable";
      int num100 = num99;
      int num101 = num100 + 1;
      searchResultField50.Order = num100;
      searchResultField50.Html = new SearchResultFieldHtml()
      {
        field = "StateTaxable",
        title = "State Tax",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField50);
      SearchResultField searchResultField51 = new SearchResultField();
      searchResultField51.Name = "AMT";
      searchResultField51.ExportField = "AMTTaxable";
      int num102 = num101;
      int num103 = num102 + 1;
      searchResultField51.Order = num102;
      searchResultField51.Html = new SearchResultFieldHtml()
      {
        field = "AMTTaxable",
        title = "AMT",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField51);
      SearchResultField searchResultField52 = new SearchResultField();
      searchResultField52.Name = "Bank Qualified";
      searchResultField52.ExportField = "BankQualified";
      int num104 = num103;
      int num105 = num104 + 1;
      searchResultField52.Order = num104;
      searchResultField52.Html = new SearchResultFieldHtml()
      {
        field = "BankQualified",
        title = "Bank Qualified",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField52);
      SearchResultField searchResultField53 = new SearchResultField();
      searchResultField53.Name = "Gross Spread ($/1,000)";
      searchResultField53.ExportField = "GrossSpread";
      int num106 = num105;
      int num107 = num106 + 1;
      searchResultField53.Order = num106;
      searchResultField53.Html = new SearchResultFieldHtml()
      {
        field = "GrossSpread",
        title = "Gross Spread ($/1,000)",
        sortable = true,
        isLeftAligned = false,
        width = "120px",
        excelWidth = "3.9cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList.Add(searchResultField53);
      SearchResultField searchResultField54 = new SearchResultField();
      searchResultField54.Name = "Est. Gross Rev";
      searchResultField54.ExportField = "EstGrossRev";
      int num108 = num107;
      int num109 = num108 + 1;
      searchResultField54.Order = num108;
      searchResultField54.Html = new SearchResultFieldHtml()
      {
        field = "EstGrossRev",
        title = "Est Gross Rev",
        sortable = true,
        isLeftAligned = false,
        width = "180px",
        excelWidth = "3.9cm",
        format = "{0:c}",
        style = "text-align: right !important;",
        excelFormat = "$#,##0.00"
      };
      searchResultFieldList.Add(searchResultField54);
      SearchResultField searchResultField55 = new SearchResultField();
      searchResultField55.Name = "Create Date";
      searchResultField55.ExportField = "CreatedOnValue";
      int num110 = num109;
      int num111 = num110 + 1;
      searchResultField55.Order = num110;
      searchResultField55.Html = new SearchResultFieldHtml()
      {
        field = "CreatedOn",
        title = "Create Date",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm",
        template = "#= convertDateToString(CreatedOn) #",
        groupHeaderTemplate = "#= convertDateToString(value) #"
      };
      searchResultFieldList.Add(searchResultField55);
      SearchResultField searchResultField56 = new SearchResultField();
      searchResultField56.Name = "Response Due Date & Time";
      searchResultField56.ExportField = "ResponseDueDateTimeValue";
      int num112 = num111;
      int num113 = num112 + 1;
      searchResultField56.Order = num112;
      searchResultField56.Html = new SearchResultFieldHtml()
      {
        field = "ResponseDueDateTime",
        title = "Response Due Date & Time",
        sortable = true,
        isLeftAligned = true,
        width = "250px",
        excelWidth = "5cm",
        template = "#= convertDateToStringDateTime(ResponseDueDateTime, ResponseDueDateTimeZone) #",
        groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
      };
      searchResultFieldList.Add(searchResultField56);
      SearchResultField searchResultField57 = new SearchResultField();
      searchResultField57.Name = "Submission Date & Time";
      searchResultField57.ExportField = "SubmissionDateTimeValue";
      int num114 = num113;
      int num115 = num114 + 1;
      searchResultField57.Order = num114;
      searchResultField57.Html = new SearchResultFieldHtml()
      {
        field = "SubmissionDateTime",
        title = "Submission Date & Time",
        sortable = true,
        isLeftAligned = true,
        width = "250px",
        excelWidth = "5cm",
        template = "#= convertDateToStringDateTime(SubmissionDateTime, SubmissionDateTimeZone) #",
        groupHeaderTemplate = "#= convertDateToStringDateTime(value,'') #"
      };
      searchResultFieldList.Add(searchResultField57);
      SearchResultField searchResultField58 = new SearchResultField();
      searchResultField58.Name = "Ratings - Moody's";
      searchResultField58.ExportField = "MoodyRatingLT";
      int num116 = num115;
      int num117 = num116 + 1;
      searchResultField58.Order = num116;
      searchResultField58.Html = new SearchResultFieldHtml()
      {
        field = "MoodyRatingLT",
        title = "Ratings - Moody's",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField58);
      SearchResultField searchResultField59 = new SearchResultField();
      searchResultField59.Name = "Ratings - S&P";
      searchResultField59.ExportField = "SPRatingLT";
      int num118 = num117;
      int num119 = num118 + 1;
      searchResultField59.Order = num118;
      searchResultField59.Html = new SearchResultFieldHtml()
      {
        field = "SPRatingLT",
        title = "Ratings - S&P",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField59);
      SearchResultField searchResultField60 = new SearchResultField();
      searchResultField60.Name = "Ratings - Kroll";
      searchResultField60.ExportField = "KrollRatingLT";
      int num120 = num119;
      int num121 = num120 + 1;
      searchResultField60.Order = num120;
      searchResultField60.Html = new SearchResultFieldHtml()
      {
        field = "KrollRatingLT",
        title = "Ratings - Kroll",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField60);
      SearchResultField searchResultField61 = new SearchResultField();
      searchResultField61.Name = "Ratings - Fitch";
      searchResultField61.ExportField = "FitchRatingLT";
      int num122 = num121;
      int num123 = num122 + 1;
      searchResultField61.Order = num122;
      searchResultField61.Html = new SearchResultFieldHtml()
      {
        field = "FitchRatingLT",
        title = "Ratings - Fitch",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "5cm"
      };
      searchResultFieldList.Add(searchResultField61);
      return searchResultFieldList;
    }

    public List<AuditTrailViewModel> GetUpdateAuditTrails(
      long AppTrasanctionID)
    {
      return this.AuditTrailRepository.FetchByAppTransactionID(AppTrasanctionID).Select<AuditTrail, AuditTrailViewModel>((Func<AuditTrail, AuditTrailViewModel>) (x => new AuditTrailViewModel(x))).ToList<AuditTrailViewModel>();
    }

    public EmailTemplateDetailViewModel PrepareInfoEmail(long appTransID)
    {
      try
      {
        IrisSoftware.iMPACT.Data.RFP rfp = this.RFPRepository.FetchByID(appTransID);
        this.GetInternalPartnersEmailAddress(rfp, out this.partnersEmailAddress);
        IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.FetchByKey(50);
        emailTemplate.To = this.SetAppGroupRecipients(emailTemplate.To, appTransID);
        emailTemplate.Cc = this.SetAppGroupRecipients(emailTemplate.Cc, appTransID);
        emailTemplate.Subject = this.ResolvePlaceholders(emailTemplate.Subject, rfp);
        emailTemplate.Body = this.ResolvePlaceholders(emailTemplate.Body, rfp);
        emailTemplate.To = this.SetRecipients(emailTemplate.To);
        emailTemplate.Cc = this.SetRecipients(emailTemplate.Cc);
        return new EmailTemplateDetailViewModel(emailTemplate);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        EmailTemplateDetailViewModel templateDetailViewModel = new EmailTemplateDetailViewModel();
        templateDetailViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return templateDetailViewModel;
      }
    }

    private string SetAppGroupRecipients(string email, long AppTransactionID)
    {
      if (!string.IsNullOrEmpty(email))
      {
        StringBuilder stringBuilder1 = new StringBuilder();
        if (email.Contains("[COMPLIANCE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(3.ToString());
        }
        if (email.Contains("[LEGAL]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(18.ToString());
        }
        if (email.Contains("[MERG]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(19.ToString());
        }
        if (stringBuilder1.Length > 0)
        {
          StringBuilder stringBuilder2 = new StringBuilder();
          foreach (string str in this.EmailTemplateRepository.FetchEmailByRoleID(AppTransactionID, stringBuilder1.ToString()))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append(";");
            stringBuilder2.Append(str);
          }
          StringBuilder stringBuilder3 = new StringBuilder();
          foreach (string str1 in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
          {
            string str2 = str1.ToUpper().Trim();
            if (!(str2 == "[COMPLIANCE]") && !(str2 == "[LEGAL]") && !(str2 == "[MERG]"))
            {
              if (stringBuilder3.Length > 0)
                stringBuilder3.Append(";");
              stringBuilder3.Append(str1);
            }
          }
          stringBuilder3.Append(";" + (object) stringBuilder2);
          return stringBuilder3.ToString();
        }
      }
      return email;
    }

    private string ResolvePlaceholders(string body, IrisSoftware.iMPACT.Data.RFP rfp)
    {
      body = body.Replace("[RFP-NAME]", rfp.RfpDetail.RFPName).Replace("[RFP-NAME-WITH-LINK]", this.GetRFPLink(rfp.RfpDetail.AppTransactionID, rfp.RfpDetail.RFPName)).Replace("[ISSUER-NAME]", rfp.RfpDetail.IssuerName).Replace("[PAR-AMT]", rfp.RfpDetail.ParAmount.HasValue ? string.Format("{0:C}", (object) rfp.RfpDetail.ParAmount.Value) : "").Replace("[ISSUER-NAME-WITH-LINK]", this.GetRFPLink(rfp.RfpDetail.AppTransactionID, rfp.RfpDetail.IssuerName));
      return body;
    }

    private string GetRFPLink(long appTransactionId, string text)
    {
      string[] segments = HttpContext.Current.Request.UrlReferrer.Segments;
      if (segments.Length > 3)
      {
        segments[0] = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + "/";
        segments[segments.Length - 2] = "RFP/";
        segments[segments.Length - 1] = "RFP.aspx";
      }
      return string.Format("<a href='{0}?AppId={1}'>{2}</a>", (object) string.Join(string.Empty, segments), (object) appTransactionId, (object) text);
    }

    private void GetInternalPartnersEmailAddress(IrisSoftware.iMPACT.Data.RFP rfp, out string[] partnersEmailAddress)
    {
      partnersEmailAddress = new string[6]
      {
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty
      };
      if (rfp.InternalPartners == null || rfp.InternalPartners.Count <= 0)
        return;
      foreach (InternalPartner internalPartner in rfp.InternalPartners)
      {
        if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email))
        {
          switch (internalPartner.RoleTypeId.Value)
          {
            case 18:
              if (!string.IsNullOrEmpty(internalPartner.IsPrimary) && internalPartner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
              {
                partnersEmailAddress[0] = string.Format("{0}{1};", (object) partnersEmailAddress[0], (object) internalPartner.Email);
                continue;
              }
              partnersEmailAddress[1] = string.Format("{0}{1};", (object) partnersEmailAddress[1], (object) internalPartner.Email);
              continue;
            case 19:
              if (!string.IsNullOrEmpty(internalPartner.IsPrimary) && internalPartner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
              {
                partnersEmailAddress[2] = string.Format("{0}{1};", (object) partnersEmailAddress[2], (object) internalPartner.Email);
                continue;
              }
              partnersEmailAddress[3] = string.Format("{0}{1};", (object) partnersEmailAddress[3], (object) internalPartner.Email);
              continue;
            case 20:
              partnersEmailAddress[4] = string.Format("{0}{1};", (object) partnersEmailAddress[4], (object) internalPartner.Email);
              continue;
            case 21:
              partnersEmailAddress[5] = string.Format("{0}{1};", (object) partnersEmailAddress[5], (object) internalPartner.Email);
              continue;
            default:
              continue;
          }
        }
      }
    }

    private string SetRecipients(string recipients)
    {
      this.InfoReceipts = "";
      if (!string.IsNullOrEmpty(recipients))
      {
        foreach (string recipient in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
        {
          switch (recipient.Trim().ToUpper())
          {
            case "[INTERNAL-PARTNERS.ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[3]);
              continue;
            case "[INTERNAL-PARTNERS.BANKRM]":
              this.GetRecipients(this.partnersEmailAddress[5]);
              continue;
            case "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[1]);
              continue;
            case "[INTERNAL-PARTNERS.LEAD-ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[2]);
              continue;
            case "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[0]);
              continue;
            case "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]":
              this.GetRecipients(this.partnersEmailAddress[4]);
              continue;
            case "[INTERNAL-PARTNERS.SYNDICATE]":
              continue;
            default:
              this.GetRecipients(recipient);
              continue;
          }
        }
      }
      return this.InfoReceipts;
    }

    public void GetRecipients(string recipient)
    {
      foreach (string str in recipient.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        if (!string.IsNullOrEmpty(str.Trim()) && !this.InfoReceipts.Contains(str))
          this.InfoReceipts = this.InfoReceipts + str + ";";
      }
    }

    private bool IsUIEditable(long appTransactionID, string uiName, List<long> statusList) => appTransactionID == 0L ? this.HasEntityPermission(1L, uiName, "Edit") : this.HasUIPermissionForEntityStatus(appTransactionID, uiName, "Edit", statusList);

    private RFPPresenter.RfpEditOnlyStatus SetRfpEditOnlyStatus(
      List<IrisSoftware.iMPACT.Data.RFP.RfpStatus> rfpStatusList,
      long appTransactionID)
    {
      RFPPresenter.RfpEditOnlyStatus rfpEditOnlyStatus = new RFPPresenter.RfpEditOnlyStatus();
      List<long> statusList = rfpStatusList.ConvertAll<long>((Converter<IrisSoftware.iMPACT.Data.RFP.RfpStatus, long>) (s => (long) s));
      rfpEditOnlyStatus.isRfpDetailsEditable = this.IsUIEditable(appTransactionID, "RFP Details", statusList);
      rfpEditOnlyStatus.isInternalPartnerEditable = this.IsUIEditable(appTransactionID, "Internal Partners", statusList);
      rfpEditOnlyStatus.isExternalPartnerEditable = this.IsUIEditable(appTransactionID, "External Partners", statusList);
      return rfpEditOnlyStatus;
    }

    private SaveResult CreateIssueFromRFP(RFPViewModel rfpViewModel)
    {
      IssueViewModelContainer issueContainer = new IssueViewModelContainer();
      IssueDetailViewModel issueDetailViewModel = new IssueDetailViewModel()
      {
        IssueName = rfpViewModel.RFPName,
        ParentRFPID = new long?(rfpViewModel.AppTransactionID),
        ParentOpportunityID = rfpViewModel.ParentOpportunityID,
        IssuerId = new long?(Convert.ToInt64(rfpViewModel.Issuer.Key)),
        IssuerName = rfpViewModel.Issuer.Value,
        ParAmount = rfpViewModel.ParAmount,
        StateID = rfpViewModel.State,
        County = rfpViewModel.County,
        FirmRoleId = rfpViewModel.AssignedFirmRole,
        FirmLiabilityPerc = rfpViewModel.AssignedFirmLiability,
        CreatedBy = rfpViewModel.CreatedBy,
        BorrowerId = rfpViewModel.Borrower != null ? new long?(Convert.ToInt64(rfpViewModel.Borrower.Key)) : new long?(),
        GuarantorId = rfpViewModel.Guarantor != null ? new long?(Convert.ToInt64(rfpViewModel.Guarantor.Key)) : new long?(),
        OfferingTypeId = 104,
        PowerID = rfpViewModel.PowerID,
        HybridSolutionIndicator = rfpViewModel.HybridSolutionIndicator,
        DualProposalProposed = rfpViewModel.DualProposalProposed,
        TransactionType = rfpViewModel.TransactionType,
        Purpose = rfpViewModel.Purpose,
        GeneralCategoryId = rfpViewModel.GeneralCategory,
        MAExemptionDetails = rfpViewModel.MAExemptionDetails,
        Series = new List<Series>()
        {
          new Series()
          {
            SeriesID = -1L,
            SeriesName = "SERIES",
            SeriesCode = "SERIES"
          }
        }
      };
      IssueInternalPartnerViewModel partnerViewModel1 = new IssueInternalPartnerViewModel()
      {
        IssueInvestmentBankingTeam = this.GetIssueBankers(rfpViewModel.Bankers),
        IssueAnalystProfessionalSupport = this.GetIssueAnalysts(rfpViewModel.Analysts),
        IssueSupervisoryPrincipal = this.GetIssueSupervisoryPrincipals(rfpViewModel.SupervisoryPrincipals),
        IssueBankRM = this.GetIssueBankRMs(rfpViewModel.BankRMs)
      };
      IssueExternalPartnerViewModel partnerViewModel2 = new IssueExternalPartnerViewModel()
      {
        AdvisorAgent = this.GetIssueAdvisors(rfpViewModel.Advisors, rfpViewModel.RfpContact),
        Counsel = this.GetIssueCounsels(rfpViewModel.Counsels, rfpViewModel.RfpContact)
      };
      issueContainer.IssueDetail = issueDetailViewModel;
      issueContainer.TransactionReportDetail.IssueFee.GrossSpread = rfpViewModel.GrossSpread;
      issueContainer.InternalPartnerDetail = partnerViewModel1;
      issueContainer.ExternalPartnerDetail = partnerViewModel2;
      issueContainer.AppTransactionClientContacts = this.GetIssueAppTransactionClientContacts(rfpViewModel.RfpContact);
      issueContainer.TransactionReportDetail.IssueFee.EstimatedRevenue = rfpViewModel.EstGrossRev;
      issueContainer.IssueDetail.IsIssueInitiatedFromParentRFP = new bool?(true);
      SaveResult saveResult1 = this.IssuePresenter.Save(issueContainer, string.Empty, 1);
      if (saveResult1.Id > 0L)
      {
        using (IDataReader dataReader = this.IssueRatingRepository.FetchSeriesDetails(saveResult1.Id))
        {
          if (dataReader != null)
          {
            while (dataReader.Read())
            {
              long int64 = Convert.ToInt64(dataReader["SeriesID"].ToString());
              if (int64 > 0L)
              {
                SaveResult saveResult2 = this.IssuePresenter.SaveIssuePricing(new List<PricingViewModel>()
                {
                  new PricingViewModel()
                  {
                    ParAmount = rfpViewModel.ParAmount.ToString(),
                    SecType = rfpViewModel.SecurityType.ToString(),
                    FedTax = rfpViewModel.FedTax.ToString(),
                    StateTax = rfpViewModel.StateTax.ToString(),
                    AmtTax = rfpViewModel.AMT.ToString(),
                    BankQualified = rfpViewModel.BankQualified.ToString(),
                    SeriesID = int64.ToString()
                  }
                }, saveResult1.Id);
                if (!saveResult2.IsSuccessful)
                  saveResult1 = saveResult2;
              }
            }
          }
        }
      }
      return saveResult1;
    }

    private List<InternalPartner> GetIssueBankers(
      List<InternalPartner> RfpBankers)
    {
      return RfpBankers == null ? new List<InternalPartner>() : RfpBankers.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (Banker => new InternalPartner()
      {
        InternalPartnerID = Banker.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = Banker.EmployeeID,
        PartnerType = Banker.PartnerType,
        RevenueAlloc = Banker.RevenueAlloc,
        IsPrimary = Banker.IsPrimary,
        IsDeleted = false,
        IncludeInDl = Banker.IncludeInDl,
        Type = Banker.Type,
        RoleTypeId = new long?(13L),
        IsDirty = true,
        FullName = Banker.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartner> GetIssueAnalysts(
      List<InternalPartner> RfpAnalysts)
    {
      return RfpAnalysts == null ? new List<InternalPartner>() : RfpAnalysts.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (Analyst => new InternalPartner()
      {
        InternalPartnerID = Analyst.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = Analyst.EmployeeID,
        PartnerType = Analyst.PartnerType,
        RevenueAlloc = Analyst.RevenueAlloc,
        IsPrimary = Analyst.IsPrimary,
        IsDeleted = false,
        IncludeInDl = Analyst.IncludeInDl,
        Type = Analyst.Type,
        RoleTypeId = new long?(14L),
        IsDirty = true,
        FullName = Analyst.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartner> GetIssueSupervisoryPrincipals(
      List<InternalPartner> RfpSupervisoryPrincipals)
    {
      return RfpSupervisoryPrincipals == null ? new List<InternalPartner>() : RfpSupervisoryPrincipals.Select<InternalPartner, InternalPartner>((Func<InternalPartner, InternalPartner>) (SupervisoryPrincipal => new InternalPartner()
      {
        InternalPartnerID = SupervisoryPrincipal.InternalPartnerID * -1L,
        AppTransactionID = 0L,
        EmployeeID = SupervisoryPrincipal.EmployeeID,
        PartnerType = SupervisoryPrincipal.PartnerType,
        RevenueAlloc = SupervisoryPrincipal.RevenueAlloc,
        IsPrimary = SupervisoryPrincipal.IsPrimary,
        IsDeleted = false,
        IncludeInDl = SupervisoryPrincipal.IncludeInDl,
        Type = SupervisoryPrincipal.Type,
        RoleTypeId = new long?(15L),
        IsDirty = true,
        FullName = SupervisoryPrincipal.FullName
      })).ToList<InternalPartner>();
    }

    private List<InternalPartnerBankRM> GetIssueBankRMs(
      List<InternalPartnerBankRM> RfpBankRMs)
    {
      return RfpBankRMs == null ? new List<InternalPartnerBankRM>() : RfpBankRMs.Select<InternalPartnerBankRM, InternalPartnerBankRM>((Func<InternalPartnerBankRM, InternalPartnerBankRM>) (RfpBankRM => new InternalPartnerBankRM()
      {
        ID = RfpBankRM.ID * -1L,
        AppTransactionID = 0L,
        Name = RfpBankRM.Name,
        Title = RfpBankRM.Title,
        Email = RfpBankRM.Email,
        Phone = RfpBankRM.Phone,
        IncludeInDl = RfpBankRM.IncludeInDl,
        IsDeleted = false
      })).ToList<InternalPartnerBankRM>();
    }

    private List<ExternalPartner> GetIssueAdvisors(
      List<ExternalPartner> RfpAdvisors,
      RfpContactDetailViewModel RfpContacts)
    {
      return RfpAdvisors == null ? new List<ExternalPartner>() : RfpAdvisors.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (Advisor => new ExternalPartner()
      {
        ExternalPartnerID = Advisor.ExternalPartnerID * -1L,
        AppTransactionID = 0L,
        PartnerID = Advisor.PartnerID,
        MemberType = Advisor.MemberType,
        Descr = Advisor.Descr,
        LiabilityPerc = Advisor.LiabilityPerc,
        EstMgmtFee = Advisor.EstMgmtFee,
        IsDeleted = false,
        InsertedIssueContact = RfpContacts.AdvisorMemberContact.Where<IssueContact>((Func<IssueContact, bool>) (p => p.CompanyName == Advisor.Name)).Select<IssueContact, string>((Func<IssueContact, string>) (p => p.MainContactID.ToString())).Join<string>(","),
        DeletedIssueContact = string.Empty,
        IsDirty = true,
        Name = Advisor.Name
      })).ToList<ExternalPartner>();
    }

    private List<ExternalPartner> GetIssueCounsels(
      List<ExternalPartner> RfpCounsels,
      RfpContactDetailViewModel RfpContacts)
    {
      return RfpCounsels == null ? new List<ExternalPartner>() : RfpCounsels.Select<ExternalPartner, ExternalPartner>((Func<ExternalPartner, ExternalPartner>) (Counsel => new ExternalPartner()
      {
        ExternalPartnerID = Counsel.ExternalPartnerID * -1L,
        AppTransactionID = 0L,
        PartnerID = Counsel.PartnerID,
        MemberType = Counsel.MemberType,
        Descr = Counsel.Descr,
        LiabilityPerc = Counsel.LiabilityPerc,
        EstMgmtFee = Counsel.EstMgmtFee,
        IsDeleted = false,
        InsertedIssueContact = RfpContacts.CounselMemberContact.Where<IssueContact>((Func<IssueContact, bool>) (p => p.CompanyName == Counsel.Name)).Select<IssueContact, string>((Func<IssueContact, string>) (p => p.MainContactID.ToString())).Join<string>(","),
        DeletedIssueContact = string.Empty,
        IsDirty = true,
        Name = Counsel.Name
      })).ToList<ExternalPartner>();
    }

    private List<AppTransactionClientContact> GetIssueAppTransactionClientContacts(
      RfpContactDetailViewModel RfpContacts)
    {
      List<AppTransactionClientContact> transactionClientContactList = new List<AppTransactionClientContact>();
      foreach (IssueContact issueContact in RfpContacts.IssuerMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      foreach (IssueContact issueContact in RfpContacts.BorrowerMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      foreach (IssueContact issueContact in RfpContacts.GuarantorMemberContact)
      {
        AppTransactionClientContact transactionClientContact = new AppTransactionClientContact()
        {
          AppTransactionID = 0,
          ClientContactID = issueContact.MainContactID,
          ClientType = issueContact.PartnerType,
          ActionType = "Inserted"
        };
        transactionClientContactList.Add(transactionClientContact);
      }
      return transactionClientContactList;
    }

    [Dependency]
    public UploadDocumentPresenter UploadDocPresenter { get; set; }

    [Dependency]
    public IAppTransactionDocSetRepository AppTransactionDocSetRepository { get; set; }

    [Dependency]
    public IEntityDocSetTypeRepository EntityDocSetTypeRepository { get; set; }

    private void PerformSharePointDocumentSetOperations(long appId, IrisSoftware.iMPACT.Data.RFP oldRFP, IrisSoftware.iMPACT.Data.RFP newRFP)
    {
      try
      {
        bool hasAnyPropChanged = false;
        Hashtable properties = this.PopulateDocumentProperties(appId, oldRFP, newRFP, out hasAnyPropChanged);
        List<AppTransactionDocSet> transactionDocSetList = this.AppTransactionDocSetRepository.FetchByAppTransactionID(appId);
        List<EntityDocSetType> entityDocSetTypeList = this.EntityDocSetTypeRepository.FetchEntityDocSetTypeByEntityID(1L);
        string libLocation = this.AppTransactionDocSetRepository.FetchLibraryURLByEntityTypeID(1L);
        List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
        foreach (EntityDocSetType entityDocSetType in entityDocSetTypeList)
        {
          EntityDocSetType docSetType = entityDocSetType;
          RFPPresenter.GetRepositoryLevelProperties_New(properties, docSetType);
          List<DocSetPermission> docSetPermissions = this.GetDocSetPermissions(appId, docSetType.EntityDocSetTypeID);
          int num;
          if (!transactionDocSetList.Exists((Predicate<AppTransactionDocSet>) (x => x.EntityDocSetTypeID.Value == docSetType.EntityDocSetTypeID)))
            this.CreateRfpDocumentSets(appId, properties, libLocation, docSetType, docSetPermissions);
          else if (newRFP.InternalPartners != null && newRFP.InternalPartners.Any<InternalPartner>((Func<InternalPartner, bool>) (x => x.IsDirty)))
          {
            UploadDocumentPresenter uploadDocPresenter = this.UploadDocPresenter;
            num = 1;
            string entityType = num.ToString();
            num = transactionDocSetList.Find((Predicate<AppTransactionDocSet>) (x => x.EntityDocSetTypeID.Value == docSetType.EntityDocSetTypeID)).DocSetID;
            string docSetId = num.ToString();
            List<DocSetPermission> issueDocSetPermissions = docSetPermissions;
            Hashtable sharedFields = properties;
            uploadDocPresenter.ApplyPermission(entityType, docSetId, issueDocSetPermissions, sharedFields);
          }
          else if (hasAnyPropChanged)
          {
            UploadDocumentPresenter uploadDocPresenter = this.UploadDocPresenter;
            num = 1;
            string entityType = num.ToString();
            num = transactionDocSetList.Find((Predicate<AppTransactionDocSet>) (x =>
            {
              long? entityDocSetTypeId1 = x.EntityDocSetTypeID;
              long entityDocSetTypeId2 = docSetType.EntityDocSetTypeID;
              return entityDocSetTypeId1.GetValueOrDefault() == entityDocSetTypeId2 && entityDocSetTypeId1.HasValue;
            })).DocSetID;
            string docSetId = num.ToString();
            Hashtable sharedFields = properties;
            uploadDocPresenter.UpdateSharedFields(entityType, docSetId, sharedFields);
          }
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
      }
    }

    private Hashtable PopulateDocumentProperties(
      long appId,
      IrisSoftware.iMPACT.Data.RFP oldRFP,
      IrisSoftware.iMPACT.Data.RFP newRFP,
      out bool hasAnyPropChanged)
    {
      hasAnyPropChanged = false;
      Hashtable hashtable1 = this.PopulateProperties(appId, oldRFP);
      Hashtable hashtable2 = this.PopulateProperties(appId, newRFP);
      foreach (DictionaryEntry dictionaryEntry in hashtable2)
      {
        if (hashtable1.ContainsKey(dictionaryEntry.Key))
        {
          if (!hashtable1[dictionaryEntry.Key].Equals(dictionaryEntry.Value))
          {
            hasAnyPropChanged = true;
            break;
          }
        }
        else
        {
          hasAnyPropChanged = true;
          break;
        }
      }
      return hashtable2;
    }

    private Hashtable PopulateProperties(long appId, IrisSoftware.iMPACT.Data.RFP rfp) => new Hashtable()
    {
      {
        (object) "iRefID",
        (object) (Convert.ToString(appId) ?? string.Empty)
      }
    };

    private static void GetRepositoryLevelProperties_New(
      Hashtable properties,
      EntityDocSetType docSetType)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) docSetType.DocSetName;
      else
        properties.Add((object) "Title", (object) docSetType.DocSetName);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) docSetType.EntityDocSetTypeID;
      else
        properties.Add((object) "iDocSetType", (object) docSetType.EntityDocSetTypeID);
    }

    private static void GetRepositoryLevelProperties(Hashtable properties, LookupItem repository)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) repository.Value;
      else
        properties.Add((object) "Title", (object) repository.Value);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) repository.LookupItemID;
      else
        properties.Add((object) "iDocSetType", (object) repository.LookupItemID);
    }

    private void CreateRfpDocumentSets(
      long appTransactionId,
      Hashtable properties,
      string libLocation,
      EntityDocSetType docSetType,
      List<DocSetPermission> docSetPermissions)
    {
      DocSetInfo docSet = this.UploadDocPresenter.CreateDocSet(new DocSetInfo()
      {
        AppTransactionId = appTransactionId,
        DocSetName = docSetType.DocSetName,
        EntityType = 1.ToString(),
        URL = libLocation
      }, docSetPermissions, properties);
      this.SaveAppTransactionDetails(new AppTransactionDocSet()
      {
        EntityID = appTransactionId,
        EntityDocSetTypeID = new long?(docSetType.EntityDocSetTypeID),
        DocSetTypeValue = docSetType.DocSetName,
        URL = libLocation,
        DocSetID = Convert.ToInt32(docSet.DocSetId)
      });
    }

    private List<DocSetPermission> GetDocSetPermissions(
      long appId,
      long docSetType)
    {
      string empty = string.Empty;
      List<DocSetPermission> docSetPermissionList1 = new List<DocSetPermission>();
      List<DocSetPermission> docSetPermissionList2 = this.AppTransactionDocSetRepository.FetchRFPRepositoryPermissionsByAppTransID(appId, 1);
      List<DocSetPermission> repositoryUploadPermissionList = docSetPermissionList2.FindAll((Predicate<DocSetPermission>) (p => p.RepositoryID == docSetType && p.Permission.ToLower() == "upload"));
      List<DocSetPermission> all = docSetPermissionList2.FindAll((Predicate<DocSetPermission>) (p => p.RepositoryID == docSetType && p.Permission.ToLower() == "view" && !repositoryUploadPermissionList.Exists((Predicate<DocSetPermission>) (u => u.PrincipalId == p.PrincipalId))));
      foreach (DocSetPermission docSetPermission in repositoryUploadPermissionList)
        docSetPermissionList1.Add(new DocSetPermission()
        {
          Permission = "Upload",
          PrincipalId = docSetPermission.PrincipalId,
          PermissionId = 0
        });
      foreach (DocSetPermission docSetPermission in all)
        docSetPermissionList1.Add(new DocSetPermission()
        {
          Permission = "view",
          PrincipalId = docSetPermission.PrincipalId,
          PermissionId = 0
        });
      return docSetPermissionList1;
    }

    private void SaveAppTransactionDetails(AppTransactionDocSet appTransactionDocSet) => this.AppTransactionDocSetRepository.Save(appTransactionDocSet);

    private struct RfpEditOnlyStatus
    {
      public bool isRfpDetailsEditable;
      public bool isExternalPartnerEditable;
      public bool isInternalPartnerEditable;
    }
  }
}
