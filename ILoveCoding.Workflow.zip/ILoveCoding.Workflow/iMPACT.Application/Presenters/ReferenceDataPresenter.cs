﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ReferenceDataPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (ReferenceDataPresenter))]
  public class ReferenceDataPresenter : PresenterBase
  {
    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [InjectionConstructor]
    public ReferenceDataPresenter()
    {
    }

    public LookupViewModelContainer GetAll()
    {
      try
      {
        return new LookupViewModelContainer()
        {
          IsViewOnly = !this.HasIndependentPermission("Reference Data", "Edit"),
          Lookups = this.LookupRepository.FetchAll().Select<Lookup, LookupViewModel>((Func<Lookup, LookupViewModel>) (x => new LookupViewModel(x))).Where<LookupViewModel>((Func<LookupViewModel, bool>) (x => x.IsActive)).ToList<LookupViewModel>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        LookupViewModelContainer viewModelContainer = new LookupViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public IEnumerable<LookupItemViewModel> GetItemsById(int lookupId)
    {
      try
      {
        return (IEnumerable<LookupItemViewModel>) this.LookupRepository.FetchByLookupId(lookupId, true).Select<LookupItem, LookupItemViewModel>((Func<LookupItem, LookupItemViewModel>) (x => new LookupItemViewModel(x))).ToList<LookupItemViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return (IEnumerable<LookupItemViewModel>) new List<LookupItemViewModel>();
      }
    }

    public IEnumerable<LookupItemViewModel> GetItemsByKey(
      string lookupKey)
    {
      try
      {
        return (IEnumerable<LookupItemViewModel>) this.LookupRepository.FetchByLookupKey(lookupKey).Select<LookupItem, LookupItemViewModel>((Func<LookupItem, LookupItemViewModel>) (x => new LookupItemViewModel(x))).ToList<LookupItemViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return (IEnumerable<LookupItemViewModel>) new List<LookupItemViewModel>();
      }
    }

    public SaveResult SaveLookupItems(List<LookupItemViewModel> lookupItemsViewModel)
    {
      try
      {
        this.GetSafeObject<LookupItemViewModel>(lookupItemsViewModel);
        List<SaveResult> saveResultList = new List<SaveResult>();
        foreach (LookupItemViewModel lookupItemViewModel in lookupItemsViewModel)
        {
          SaveResult saveResult = lookupItemViewModel.Validate<LookupItemViewModel>();
          if (!saveResult.IsSuccessful)
          {
            saveResult.Id = lookupItemViewModel.LookupItemID;
            saveResultList.Add(saveResult);
          }
        }
        if (saveResultList.Count > 0)
          return new SaveResult()
          {
            Errors = {
              {
                "LookupItems",
                (object) saveResultList
              }
            }
          };
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.LookupRepository.SaveLookupItems(lookupItemsViewModel.Select<LookupItemViewModel, LookupItem>((Func<LookupItemViewModel, LookupItem>) (x => x.GetLookupItem())).ToList<LookupItem>());
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }
  }
}
