﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ManageContactPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public class ManageContactPresenter : PresenterBase
  {
    [Dependency]
    public IManageContactRepository ManageContactRepository { get; set; }

    [Dependency]
    public ReferenceDataPresenter Presenter { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IPropertyDescriptorRepository PropertyDescriptorRepository { get; set; }

    [Dependency]
    public IAppTransactionDocSetRepository AppTransactionDocSetRepository { get; set; }

    [Dependency]
    public IEntityDocSetTypeRepository EntityDocSetTypeRepository { get; set; }

    [Dependency]
    public UploadDocumentPresenter UploadDocPresenter { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    public ManageContactViewModelContainer GetAllManageContact()
    {
      try
      {
        ManageContactViewModelContainer viewModelContainer = new ManageContactViewModelContainer();
        viewModelContainer.ManageContacts = this.ManageContactRepository.FetchAll().Select<ManageContact, ManageContactViewModel>((Func<ManageContact, ManageContactViewModel>) (x => new ManageContactViewModel(x))).ToList<ManageContactViewModel>();
        viewModelContainer.States = this.Presenter.GetItemsByKey("State").ToList<LookupItemViewModel>();
        viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Client", "Edit");
        viewModelContainer.IsAddManageContact = false;
        viewModelContainer.IsEditManageContact = false;
        AppConfig appConfig1 = this.AppConfigRepository.FetchByKey(48);
        AppConfig appConfig2 = this.AppConfigRepository.FetchByKey(49);
        viewModelContainer.GoogleAppConfigValue = appConfig1?.Value;
        viewModelContainer.OutlookAppConfigValue = appConfig2?.Value;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        return new ManageContactViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public ManageContactViewModel GetManageContactById(long manageContactID)
    {
      try
      {
        return new ManageContactViewModel(this.ManageContactRepository.FetchByKey(manageContactID))
        {
          IsViewOnly = !this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.ClientEditPermissionSet),
          IsAddManageContact = false,
          IsEditManageContact = false,
          MiscFieldsDetail = this.PropertyDescriptorRepository.FetchPropertyDescriptorsDataByEntity(manageContactID, -83L)
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ManageContactViewModel("An error occurred while fetching the data.");
      }
    }

    public void PerformSharePointDocumentSetOperations(long contactId, ManageContact manageContact)
    {
      try
      {
        Hashtable properties = this.PopulateProperties(contactId, manageContact);
        List<AppTransactionDocSet> transactionDocSetList = this.AppTransactionDocSetRepository.FetchByAppTransactionID(contactId);
        List<EntityDocSetType> entityDocSetTypeList = this.EntityDocSetTypeRepository.FetchEntityDocSetTypeByEntityID(-3L);
        string libLocation = this.AppTransactionDocSetRepository.FetchLibraryURLByEntityTypeID(-3L);
        List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
        foreach (EntityDocSetType entityDocSetType in entityDocSetTypeList)
        {
          EntityDocSetType docSetType = entityDocSetType;
          List<DocSetPermission> docSetPermissions = (List<DocSetPermission>) null;
          ManageContactPresenter.GetRepositoryLevelProperties_New(properties, docSetType);
          if (!transactionDocSetList.Exists((Predicate<AppTransactionDocSet>) (x =>
          {
            long? entityDocSetTypeId1 = x.EntityDocSetTypeID;
            long entityDocSetTypeId2 = docSetType.EntityDocSetTypeID;
            return entityDocSetTypeId1.GetValueOrDefault() == entityDocSetTypeId2 && entityDocSetTypeId1.HasValue;
          })))
            this.CreateIssueDocumentSets(contactId, properties, libLocation, docSetType, docSetPermissions);
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
      }
    }

    private void CreateIssueDocumentSets(
      long contactId,
      Hashtable properties,
      string libLocation,
      EntityDocSetType docSetType,
      List<DocSetPermission> docSetPermissions)
    {
      DocSetInfo docSet = this.UploadDocPresenter.CreateDocSet(new DocSetInfo()
      {
        AppTransactionId = contactId,
        DocSetName = docSetType.DocSetName,
        EntityType = -3.ToString(),
        URL = libLocation
      }, docSetPermissions, properties);
      this.SaveAppTransactionDetails(new AppTransactionDocSet()
      {
        EntityID = contactId,
        EntityDocSetTypeID = new long?(docSetType.EntityDocSetTypeID),
        DocSetTypeValue = docSetType.DocSetName,
        URL = libLocation,
        DocSetID = Convert.ToInt32(docSet.DocSetId)
      });
    }

    private void SaveAppTransactionDetails(AppTransactionDocSet appTransactionDocSet)
    {
      try
      {
        this.AppTransactionDocSetRepository.Save(appTransactionDocSet);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    private static void GetRepositoryLevelProperties_New(
      Hashtable properties,
      EntityDocSetType docSetType)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) docSetType.DocSetName;
      else
        properties.Add((object) "Title", (object) docSetType.DocSetName);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) docSetType.EntityDocSetTypeID;
      else
        properties.Add((object) "iDocSetType", (object) docSetType.EntityDocSetTypeID);
    }

    private Hashtable PopulateProperties(long contactId, ManageContact manageContact) => new Hashtable()
    {
      {
        (object) "iCreateDate",
        (object) (manageContact.CreatedOn == DateTime.MinValue.Date ? DateTime.Now : manageContact.CreatedOn)
      }
    };

    public SaveResult Save(ManageContactViewModel theManageContact)
    {
      try
      {
        SaveResult saveResult = theManageContact.Validate<ManageContactViewModel>();
        this.GetSafeObject<ManageContactViewModel>(theManageContact);
        long contactId = theManageContact.ContactID;
        saveResult.Id = contactId;
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.ManageContactRepository.Save(theManageContact.GetManageContactDetail(theManageContact), theManageContact.MiscFieldsValueDetail);
            saveResult.Id = num;
            if (num == -100L)
              saveResult.Errors.Add("Contact Email", (object) "Contacts cannot have same email address.");
            if (saveResult.IsSuccessful)
              transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult ImportManageContact(List<ManageContactViewModel> theManageContact)
    {
      try
      {
        SaveResult saveResult = new SaveResult();
        this.GetSafeObject<ManageContactViewModel>(theManageContact);
        if (theManageContact.Count<ManageContactViewModel>() > 0)
        {
          if (saveResult.IsSuccessful)
          {
            using (TransactionScope transactionScope = new TransactionScope())
            {
              this.ManageContactRepository.ImportContact(theManageContact.Select<ManageContactViewModel, ManageContact>((Func<ManageContactViewModel, ManageContact>) (x => x.GetManageContactDetail(x))).ToList<ManageContact>());
              transactionScope.Complete();
            }
          }
        }
        else
          saveResult.Errors.Add("Contact CSV File", (object) "No contact avaible in csv file.");
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private List<SaveResult> ValidateContacts(
      List<ManageContactViewModel> theManageContact)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (ManageContactViewModel contactViewModel in theManageContact)
      {
        SaveResult saveResult = contactViewModel.Validate<ManageContactViewModel>();
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = contactViewModel.ContactID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    public List<KeyPair> GetFullLegalNames(string FullName, string Type)
    {
      try
      {
        List<KeyPair> keyPairList = new List<KeyPair>();
        using (IDataReader dataReader = this.ManageContactRepository.FetchFullLegalNames(FullName, Type))
        {
          if (dataReader != null)
          {
            IRowMapper<KeyPair> rowMapper = MapBuilder<KeyPair>.MapAllProperties().Map<string>((Expression<Func<KeyPair, string>>) (x => x.Key)).ToColumn("RefID").Map<string>((Expression<Func<KeyPair, string>>) (x => x.Value)).ToColumn("RefName").Build();
            while (dataReader.Read())
              keyPairList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return keyPairList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<KeyPair>();
      }
    }
  }
}
