﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.MenuDataPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Caching;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (MenuDataPresenter))]
  public class MenuDataPresenter : PresenterBase
  {
    [Dependency]
    public IMenuRepository MenuRepository { get; set; }

    [Dependency]
    public IEmployeeRepository EmployeeRepository { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    public IEnumerable<AppMenuModel> GetMenuItems()
    {
      bool enableInfoLogging = false;
      try
      {
        this.Log.Error(Modules.Administration, string.Format("User: {0}, Email: {1}, EffectivePrincipals: {2}", (object) this.AppUser.Name, (object) this.AppUser.Email, (object) string.Join("; ", ((IEnumerable<int>) this.AppUser.GetEffectivePrincipalIds()).Select<int, string>((Func<int, string>) (x => x.ToString())).ToArray<string>())));
        this.EmployeeRepository.SaveToUserLog(this.AppUser.Name, DateTime.Now, this.AppUser.Email, string.Join("; ", ((IEnumerable<int>) this.AppUser.GetEffectivePrincipalIds()).Select<int, string>((Func<int, string>) (x => x.ToString())).ToArray<string>()));
        if (enableInfoLogging)
          this.Log.Error(Modules.Administration, "GetMenuItems-Begin");
        List<Menu> menuList1 = new List<Menu>();
        List<AppMenuModel> appMenuModelList = new List<AppMenuModel>();
        Cache cache = HttpContext.Current.Cache;
        List<Role> employeeRoles = this.EmployeeRepository.FetchEmployeeRolesByPrincipal(this.AppUser.Id);
        if (employeeRoles == null || employeeRoles.Count == 0)
          return (IEnumerable<AppMenuModel>) appMenuModelList;
        Dictionary<long, List<Menu>> rolesBasedMenus;
        if (cache.Get(Constants.MenuCacheKey) == null)
        {
          rolesBasedMenus = new Dictionary<long, List<Menu>>();
          foreach (Role role in employeeRoles)
          {
            if (enableInfoLogging)
              this.Log.Error(Modules.Administration, "CacheKeyNotFound-GetMenuItems-EmployeeRoleID=" + role.RoleID.ToString());
            List<Menu> menuList2 = this.MenuRepository.FetchAll(role.RoleID);
            rolesBasedMenus.Add(role.RoleID, menuList2);
            menuList1 = menuList1.Union<Menu>((IEnumerable<Menu>) menuList2).ToList<Menu>();
          }
        }
        else
        {
          rolesBasedMenus = cache.Get(Constants.MenuCacheKey) as Dictionary<long, List<Menu>>;
          menuList1 = this.SetMenuItemsforRoles(enableInfoLogging, menuList1, employeeRoles, rolesBasedMenus);
        }
        cache.Insert(Constants.MenuCacheKey, (object) rolesBasedMenus);
        List<Menu> list = menuList1.GroupBy<Menu, int>((Func<Menu, int>) (a => a.MenuID)).Select<IGrouping<int, Menu>, Menu>((Func<IGrouping<int, Menu>, Menu>) (g => g.First<Menu>())).ToList<Menu>();
        foreach (Menu menu in (IEnumerable<Menu>) list.Where<Menu>((Func<Menu, bool>) (x => x.ParentID == 0)).OrderBy<Menu, int>((Func<Menu, int>) (x => x.ItemOrder)))
        {
          Menu parent = menu;
          if (enableInfoLogging)
            this.Log.Error(Modules.Administration, "GetMenuItems-ParentMenuID=" + parent.MenuID.ToString());
          IOrderedEnumerable<Menu> source = list.Where<Menu>((Func<Menu, bool>) (x => x.ParentID > 0 && x.ParentID == parent.MenuID)).OrderBy<Menu, int>((Func<Menu, int>) (x => x.ItemOrder));
          if (source.Count<Menu>() != 0 || !string.IsNullOrEmpty(parent.NavigateURL))
          {
            AppMenuModel menuViewModel = new AppMenuModel();
            menuViewModel.text = parent.Text;
            if (parent.NavigateURL != null && parent.NavigateURL.Count<char>() > 0)
              menuViewModel.url = parent.NavigateURL;
            if (enableInfoLogging)
              this.Log.Error(Modules.Administration, "GetMenuItems-CreateChildMenuItems Begin");
            MenuDataPresenter.CreateChildMenuItems((IEnumerable<Menu>) list, menuViewModel, (IEnumerable<Menu>) source);
            if (enableInfoLogging)
              this.Log.Error(Modules.Administration, "GetMenuItems-CreateChildMenuItems End");
            appMenuModelList.Add(menuViewModel);
          }
        }
        if (enableInfoLogging)
          this.Log.Error(Modules.Administration, "GetMenuItems-End");
        return (IEnumerable<AppMenuModel>) appMenuModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, "GetMenuItems-ErrorException-> " + ex.ToString());
        this.Log.Error(Modules.Administration, ex.ToString());
        return (IEnumerable<AppMenuModel>) new List<AppMenuModel>();
      }
    }

    private List<Menu> SetMenuItemsforRoles(
      bool enableInfoLogging,
      List<Menu> menuItemsForAllRoles,
      List<Role> employeeRoles,
      Dictionary<long, List<Menu>> rolesBasedMenus)
    {
      foreach (Role employeeRole in employeeRoles)
      {
        if (enableInfoLogging)
          this.Log.Error(Modules.Administration, "CacheKeyFound-GetMenuItems-EmployeeRoleID=" + employeeRole.RoleID.ToString());
        List<Menu> menuList1;
        rolesBasedMenus.TryGetValue(employeeRole.RoleID, out menuList1);
        if (menuList1 != null && menuList1.Count > 0)
        {
          menuItemsForAllRoles = menuItemsForAllRoles.Union<Menu>((IEnumerable<Menu>) menuList1).ToList<Menu>();
        }
        else
        {
          List<Menu> menuList2 = this.MenuRepository.FetchAll(employeeRole.RoleID);
          if (enableInfoLogging)
            this.Log.Error(Modules.Administration, "RoleNotFoundInCache-GetMenuItems-EmployeeRoleID=" + employeeRole.RoleID.ToString());
          if (!rolesBasedMenus.ContainsKey(employeeRole.RoleID))
            rolesBasedMenus.Add(employeeRole.RoleID, menuList2);
          menuItemsForAllRoles = menuItemsForAllRoles.Union<Menu>((IEnumerable<Menu>) menuList2).ToList<Menu>();
        }
      }
      return menuItemsForAllRoles;
    }

    public string GetAppConfigValue()
    {
      AppConfig appConfig = this.AppConfigRepository.FetchByKey(57);
      return appConfig != null && !string.IsNullOrEmpty(appConfig.Value) ? appConfig.Value : string.Empty;
    }

    private static void CreateChildMenuItems(
      IEnumerable<Menu> menuItems,
      AppMenuModel menuViewModel,
      IEnumerable<Menu> childMenus)
    {
      if (childMenus == null || childMenus.Count<Menu>() <= 0)
        return;
      menuViewModel.items = new List<AppMenuModel>();
      foreach (Menu childMenu1 in childMenus)
      {
        Menu childMenu = childMenu1;
        AppMenuModel appMenuModel = new AppMenuModel();
        appMenuModel.text = childMenu.Text;
        IEnumerable<Menu> menus = menuItems.Where<Menu>((Func<Menu, bool>) (x => x.ParentID > 0 && x.ParentID == childMenu.MenuID));
        if (menus != null && menus.Count<Menu>() > 0)
          MenuDataPresenter.CreateChildMenuItems(menuItems, menuViewModel, menus);
        if (childMenu.NavigateURL != null && childMenu.NavigateURL.Length > 0)
          appMenuModel.url = childMenu.NavigateURL;
        menuViewModel.items.Add(appMenuModel);
      }
    }
  }
}
