﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ExpenseRevenuePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (ExpenseRevenuePresenter))]
  public class ExpenseRevenuePresenter : PresenterBase
  {
    [Dependency]
    public IExpenseRevenueRepository ExpenseReviewRepository { get; set; }

    public ExpenseRevenueViewModelContainer FetchExpenseRevenueByAppTransactionId(
      long appTransactionId,
      bool IsRefresh)
    {
      ExpenseRevenueViewModelContainer viewModelContainer1 = new ExpenseRevenueViewModelContainer();
      try
      {
        ExpenseRevenue expenseRevenueDetails = this.FetchExpenseRevenueByKey(appTransactionId, IsRefresh);
        if (expenseRevenueDetails.AppTransactionID > 0L)
        {
          viewModelContainer1 = this.GetExpenseRevenueViewModel(expenseRevenueDetails);
        }
        else
        {
          viewModelContainer1.IsViewOnly = true;
          viewModelContainer1.IsProjectedValuesDisable = true;
          viewModelContainer1.IsActualValuesDisable = true;
        }
        return viewModelContainer1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        ExpenseRevenueViewModelContainer viewModelContainer2 = new ExpenseRevenueViewModelContainer();
        viewModelContainer2.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer2;
      }
    }

    public ExpenseRevenueViewModelContainer FetchExpenseRevenueByExpenseRevenueId(
      long expenseRevenueId)
    {
      try
      {
        return this.GetExpenseRevenueViewModelForHistory(this.FetchExpenseRevenueHistoryByKey(expenseRevenueId));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        ExpenseRevenueViewModelContainer viewModelContainer = new ExpenseRevenueViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public SaveResult SaveExpenseRevenue(
      ExpenseRevenueViewModel expenseRevenueViewModel,
      string action)
    {
      bool isMoveAccrualToHistory = false;
      try
      {
        if (action.Trim().ToUpper() == "" && string.IsNullOrEmpty(expenseRevenueViewModel.ERStatus))
          expenseRevenueViewModel.ERStatus = "Open";
        else if (action.Trim().ToUpper() == "FORECAST ACCRUAL")
        {
          expenseRevenueViewModel.ERStatus = "Forecasted";
          expenseRevenueViewModel = this.SetActualValues(expenseRevenueViewModel);
        }
        else if (action.Trim().ToUpper() == "SEND ACCRUAL FOR REVIEW")
        {
          expenseRevenueViewModel.ERStatus = "Accrual Under Review";
          expenseRevenueViewModel = this.SetActualValues(expenseRevenueViewModel);
        }
        else if (action.Trim().ToUpper() == "MORE INFO NEEDED")
          expenseRevenueViewModel.ERStatus = "More Info Needed";
        else if (action.Trim().ToUpper() == "POST ACCRUAL")
        {
          expenseRevenueViewModel.ERStatus = "Accrual Posted";
          isMoveAccrualToHistory = true;
        }
        using (TransactionScope transactionScope = new TransactionScope())
        {
          if (this.ExpenseReviewRepository.SaveExpenseRevenue(expenseRevenueViewModel.GetExpenseRevenue(), isMoveAccrualToHistory) <= 0L)
            return SaveResult.Failure("An error occurred while saving the data.");
          transactionScope.Complete();
          return SaveResult.Success;
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private ExpenseRevenueViewModel SetActualValues(
      ExpenseRevenueViewModel expenseRevenueViewModel)
    {
      expenseRevenueViewModel.ActManagementFee = expenseRevenueViewModel.ProjManagementFee;
      expenseRevenueViewModel.ActManagementFeePerThou = expenseRevenueViewModel.ProjManagementFeePerThou;
      expenseRevenueViewModel.ActTakedown = expenseRevenueViewModel.ProjTakedown;
      expenseRevenueViewModel.ActTakedownPerThou = expenseRevenueViewModel.ProjTakedownPerThou;
      expenseRevenueViewModel.ActExpenses = expenseRevenueViewModel.ProjExpenses;
      expenseRevenueViewModel.ActExpensesPerThou = expenseRevenueViewModel.ProjExpensesPerThou;
      expenseRevenueViewModel.ActStructuringFee = expenseRevenueViewModel.ProjStructuringFee;
      expenseRevenueViewModel.ActStructuringFeePerThou = expenseRevenueViewModel.ProjStructuringFeePerThou;
      expenseRevenueViewModel.ActGrossSpread = expenseRevenueViewModel.ProjGrossSpread;
      expenseRevenueViewModel.ActGrossSpreadPerThou = expenseRevenueViewModel.ProjGrossSpreadPerThou;
      expenseRevenueViewModel.ActFirmUnderwritingRevenue = expenseRevenueViewModel.ProjFirmUnderwritingRevenue;
      expenseRevenueViewModel.ActFinancialAdvisory = expenseRevenueViewModel.ProjFinancialAdvisory;
      expenseRevenueViewModel.ActRemarketingFee = expenseRevenueViewModel.ProjRemarketingFee;
      expenseRevenueViewModel.ActOtherFee = expenseRevenueViewModel.ProjOtherFee;
      expenseRevenueViewModel.ActTotalRevenues = expenseRevenueViewModel.ProjTotalRevenues;
      expenseRevenueViewModel.ActCUSIP = expenseRevenueViewModel.ProjCUSIP;
      expenseRevenueViewModel.ActCalPSA = expenseRevenueViewModel.ProjCalPSA;
      expenseRevenueViewModel.ActMSRB = expenseRevenueViewModel.ProjMSRB;
      expenseRevenueViewModel.ActCDIAC = expenseRevenueViewModel.ProjCDIAC;
      expenseRevenueViewModel.ActSIFMA = expenseRevenueViewModel.ProjSIFMA;
      expenseRevenueViewModel.ActCalMuniStats = expenseRevenueViewModel.ProjCalMuniStats;
      expenseRevenueViewModel.ActBookrunningCharges = expenseRevenueViewModel.ProjBookrunningCharges;
      expenseRevenueViewModel.ActCMBDA = expenseRevenueViewModel.ProjCMBDA;
      expenseRevenueViewModel.ActDayLoan = expenseRevenueViewModel.ProjDayLoan;
      expenseRevenueViewModel.ActMACMI = expenseRevenueViewModel.ProjMACMI;
      expenseRevenueViewModel.ActTicketing = expenseRevenueViewModel.ProjTicketing;
      expenseRevenueViewModel.ActMIPF = expenseRevenueViewModel.ProjMIPF;
      expenseRevenueViewModel.ActTelecommunication = expenseRevenueViewModel.ProjTelecommunication;
      expenseRevenueViewModel.ActMACTX = expenseRevenueViewModel.ProjMACTX;
      expenseRevenueViewModel.ActLegal = expenseRevenueViewModel.ProjLegal;
      expenseRevenueViewModel.ActMACOH = expenseRevenueViewModel.ProjMACOH;
      expenseRevenueViewModel.ActDTCCharges = expenseRevenueViewModel.ProjDTCCharges;
      expenseRevenueViewModel.ActLessExpenseReimbursement = expenseRevenueViewModel.ProjLessExpenseReimbursement;
      expenseRevenueViewModel.ActClearanceExpenses = expenseRevenueViewModel.ProjClearanceExpenses;
      expenseRevenueViewModel.ActOtherExpenses = expenseRevenueViewModel.ProjOtherExpenses;
      expenseRevenueViewModel.ActTotalFinancingExpenses = expenseRevenueViewModel.ProjTotalFinancingExpenses;
      expenseRevenueViewModel.ActTotalRevenueBeforeExpenses = expenseRevenueViewModel.ProjTotalRevenueBeforeExpenses;
      expenseRevenueViewModel.ActLessNetDealExpenses = expenseRevenueViewModel.ProjLessNetDealExpenses;
      expenseRevenueViewModel.ActLessCoManagerDistributions = expenseRevenueViewModel.ProjLessCoManagerDistributions;
      expenseRevenueViewModel.ActNetRevenues = expenseRevenueViewModel.ProjNetRevenues;
      expenseRevenueViewModel.ActTakedownRevenues = expenseRevenueViewModel.ProjTakedownRevenues;
      expenseRevenueViewModel.ActAdjustmentToTakedown = expenseRevenueViewModel.ProjAdjustmentToTakedown;
      expenseRevenueViewModel.ActAdjustedTakedown = expenseRevenueViewModel.ProjAdjustedTakedown;
      expenseRevenueViewModel.ActPublicFinance = expenseRevenueViewModel.ProjPublicFinance;
      expenseRevenueViewModel.ActSalesTradingAndUnderwriting = expenseRevenueViewModel.ProjSalesTradingAndUnderwriting;
      expenseRevenueViewModel.ActTotalRevenuesBreakdown = expenseRevenueViewModel.ProjTotalRevenuesBreakdown;
      return expenseRevenueViewModel;
    }

    private ExpenseRevenue FetchExpenseRevenueByKey(
      long appTransactionId,
      bool isRefresh)
    {
      return this.ExpenseReviewRepository.FetchExpenseRevenueByAppTransactionId(appTransactionId, isRefresh);
    }

    private ExpenseRevenue FetchExpenseRevenueHistoryByKey(long expenseRevenueId) => this.ExpenseReviewRepository.FetchExpenseRevenueHistoryByExpenseRevenueId(expenseRevenueId);

    private ExpenseRevenueViewModelContainer GetExpenseRevenueViewModel(
      ExpenseRevenue expenseRevenueDetails)
    {
      try
      {
        long appTransactionId = expenseRevenueDetails.AppTransactionID;
        ExpenseRevenueViewModelContainer viewModelContainer = new ExpenseRevenueViewModelContainer(expenseRevenueDetails);
        viewModelContainer.UnderwritingFirmRoles = new int[7]
        {
          32,
          33,
          34,
          35,
          36,
          350,
          351
        };
        viewModelContainer.SoleManagerFirmRFole = 32;
        viewModelContainer.IsViewOnly = false;
        viewModelContainer.IsProjectedValuesDisable = false;
        viewModelContainer.IsActualValuesDisable = true;
        if (string.IsNullOrEmpty(viewModelContainer.ExpenseRevenueDetail.ERStatus))
        {
          string[] strArray = (string[]) null;
          viewModelContainer.Actions = strArray;
          viewModelContainer.IsProjectedValuesDisable = false;
          viewModelContainer.IsActualValuesDisable = true;
        }
        else if (!string.IsNullOrEmpty(viewModelContainer.ExpenseRevenueDetail.ERStatus) && Convert.ToString(viewModelContainer.ExpenseRevenueDetail.ERStatus).ToUpper().Trim() == "OPEN")
        {
          string[] strArray = new string[2]
          {
            "Forecast Accrual",
            "Send Accrual for Review"
          };
          viewModelContainer.Actions = strArray;
          viewModelContainer.IsProjectedValuesDisable = false;
          viewModelContainer.IsActualValuesDisable = true;
        }
        else if (!string.IsNullOrEmpty(viewModelContainer.ExpenseRevenueDetail.ERStatus) && Convert.ToString(viewModelContainer.ExpenseRevenueDetail.ERStatus).ToUpper().Trim() == "FORECASTED" || !string.IsNullOrEmpty(viewModelContainer.ExpenseRevenueDetail.ERStatus) && Convert.ToString(viewModelContainer.ExpenseRevenueDetail.ERStatus).ToUpper().Trim() == "MORE INFO NEEDED")
        {
          string[] strArray = new string[1]
          {
            "Send Accrual for Review"
          };
          viewModelContainer.Actions = strArray;
          viewModelContainer.IsProjectedValuesDisable = false;
          viewModelContainer.IsActualValuesDisable = true;
        }
        else if (!string.IsNullOrEmpty(viewModelContainer.ExpenseRevenueDetail.ERStatus) && Convert.ToString(viewModelContainer.ExpenseRevenueDetail.ERStatus).ToUpper().Trim() == "ACCRUAL UNDER REVIEW")
        {
          string[] strArray = new string[2]
          {
            "More Info Needed",
            "Post Accrual"
          };
          viewModelContainer.Actions = strArray;
          viewModelContainer.IsProjectedValuesDisable = true;
          viewModelContainer.IsActualValuesDisable = false;
        }
        else if (!string.IsNullOrEmpty(viewModelContainer.ExpenseRevenueDetail.ERStatus) && Convert.ToString(viewModelContainer.ExpenseRevenueDetail.ERStatus).ToUpper().Trim() == "ACCRUAL POSTED")
        {
          string[] strArray = new string[1]{ "" };
          viewModelContainer.Actions = strArray;
          viewModelContainer.IsProjectedValuesDisable = true;
          viewModelContainer.IsActualValuesDisable = true;
        }
        viewModelContainer.IsProjCAStateDisable = true;
        viewModelContainer.IsProjCOStateDisable = true;
        viewModelContainer.IsProjMIStateDisable = true;
        viewModelContainer.IsProjMNStateDisable = true;
        viewModelContainer.IsProjTXStateDisable = true;
        viewModelContainer.IsProjOHStateDisable = true;
        viewModelContainer.IsActCAStateDisable = true;
        viewModelContainer.IsActCOStateDisable = true;
        viewModelContainer.IsActMIStateDisable = true;
        viewModelContainer.IsActMNStateDisable = true;
        viewModelContainer.IsActTXStateDisable = true;
        viewModelContainer.IsActOHStateDisable = true;
        if (viewModelContainer.ExpenseRevenueDetail.StateName == "CA" && !viewModelContainer.IsProjectedValuesDisable)
          viewModelContainer.IsProjCAStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "CO" && !viewModelContainer.IsProjectedValuesDisable)
          viewModelContainer.IsProjCOStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "MI" && !viewModelContainer.IsProjectedValuesDisable)
          viewModelContainer.IsProjMIStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "MN" && !viewModelContainer.IsProjectedValuesDisable)
          viewModelContainer.IsProjMNStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "TX" && !viewModelContainer.IsProjectedValuesDisable)
          viewModelContainer.IsProjTXStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "OH" && !viewModelContainer.IsProjectedValuesDisable)
          viewModelContainer.IsProjOHStateDisable = false;
        if (viewModelContainer.ExpenseRevenueDetail.StateName == "CA" && !viewModelContainer.IsActualValuesDisable)
          viewModelContainer.IsActCAStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "CO" && !viewModelContainer.IsActualValuesDisable)
          viewModelContainer.IsActCOStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "MI" && !viewModelContainer.IsActualValuesDisable)
          viewModelContainer.IsActMIStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "MN" && !viewModelContainer.IsActualValuesDisable)
          viewModelContainer.IsActMNStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "TX" && !viewModelContainer.IsActualValuesDisable)
          viewModelContainer.IsActTXStateDisable = false;
        else if (viewModelContainer.ExpenseRevenueDetail.StateName == "OH" && !viewModelContainer.IsActualValuesDisable)
          viewModelContainer.IsActOHStateDisable = false;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        ExpenseRevenueViewModelContainer viewModelContainer = new ExpenseRevenueViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    private ExpenseRevenueViewModelContainer GetExpenseRevenueViewModelForHistory(
      ExpenseRevenue expenseRevenueDetails)
    {
      try
      {
        long appTransactionId = expenseRevenueDetails.AppTransactionID;
        return new ExpenseRevenueViewModelContainer(expenseRevenueDetails)
        {
          IsProjCAStateDisable = true,
          IsProjCOStateDisable = true,
          IsProjMIStateDisable = true,
          IsProjMNStateDisable = true,
          IsProjTXStateDisable = true,
          IsProjOHStateDisable = true,
          IsActCAStateDisable = true,
          IsActCOStateDisable = true,
          IsActMIStateDisable = true,
          IsActMNStateDisable = true,
          IsActTXStateDisable = true,
          IsActOHStateDisable = true,
          UnderwritingFirmRoles = new int[7]
          {
            32,
            33,
            34,
            35,
            36,
            350,
            351
          },
          SoleManagerFirmRFole = 32,
          IsProjectedValuesDisable = true,
          IsActualValuesDisable = true,
          IsViewOnly = true
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        ExpenseRevenueViewModelContainer viewModelContainer = new ExpenseRevenueViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }
  }
}
