﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.BidCalendarPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public class BidCalendarPresenter : PresenterBase
  {
    [Dependency]
    public IBidCalendarRepository BidCalendarRepository { get; set; }

    public BidCalendarViewModelContainer GetAllBids()
    {
      try
      {
        BidCalendarViewModelContainer viewModelContainer = new BidCalendarViewModelContainer();
        List<BidCalendarViewModel> calendarViewModelList = new List<BidCalendarViewModel>();
        using (IDataReader dataReader = this.BidCalendarRepository.FetchAll(new bool?(true)))
        {
          IRowMapper<BidCalendarViewModel> rowMapper = MapBuilder<BidCalendarViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<BidCalendarViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<BidCalendarViewModel, bool>>) (x => x.IsDirty)).DoNotMap<string>((Expression<Func<BidCalendarViewModel, string>>) (x => x.ErrorMessage)).Build();
          while (dataReader.Read())
            calendarViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        viewModelContainer.BidCalendars = calendarViewModelList;
        viewModelContainer.IsViewOnly = this.HasIndependentPermission("Bid Calendar", "View");
        viewModelContainer.IsAllowShotlist = this.HasIndependentPermission("Bid Calendar", "Edit");
        if (!viewModelContainer.IsViewOnly)
          viewModelContainer.IsViewOnly = this.HasIndependentPermission("Bid Calendar", "Edit");
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new BidCalendarViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public BidCalendarViewModelContainer ShortlistBid(
      long issueID,
      string ModifiedBy)
    {
      try
      {
        BidCalendarViewModelContainer viewModelContainer = new BidCalendarViewModelContainer();
        this.BidCalendarRepository.ShortListBidByIssueID(issueID, ModifiedBy);
        viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Bid Calendar", "View");
        viewModelContainer.IsAllowShotlist = !this.HasIndependentPermission("Bid Calendar", "Edit");
        if (!viewModelContainer.IsViewOnly)
          viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Bid Calendar", "Edit");
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new BidCalendarViewModelContainer("An error occurred while fetching the data.");
      }
    }
  }
}
