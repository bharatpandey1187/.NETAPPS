﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.G37MasterReportPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (G37MasterReportPresenter))]
  public class G37MasterReportPresenter : PresenterBase
  {
    [Dependency]
    public IG37MasterReportRepository G37MasterReportRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public Paged<G37MasterReportViewModel> GetG37MasterReport(
      KendoGridRequest request,
      G37MasterReportSearchViewModel model)
    {
      try
      {
        long total = 0;
        return new Paged<G37MasterReportViewModel>((IList<G37MasterReportViewModel>) this.GetSearchData(request, model, out total), total);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new Paged<G37MasterReportViewModel>((IList<G37MasterReportViewModel>) new List<G37MasterReportViewModel>(), 0L);
      }
    }

    private List<G37MasterReportViewModel> GetSearchData(
      KendoGridRequest request,
      G37MasterReportSearchViewModel model,
      out long total)
    {
      total = 0L;
      List<G37MasterReportViewModel> masterReportViewModelList = new List<G37MasterReportViewModel>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      using (IDataReader dataReader = this.G37MasterReportRepository.FetchG37MasterReportData(model.DateFrom, model.DateTo, model.typeOfOffering, orderingList.ToArray(), (int) request.skip, request.take))
      {
        if (dataReader != null)
        {
          IRowMapper<G37MasterReportViewModel> rowMapper = MapBuilder<G37MasterReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            masterReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      foreach (G37MasterReportViewModel masterReportViewModel in masterReportViewModelList)
        masterReportViewModel.Series = string.IsNullOrEmpty(masterReportViewModel.Series) ? masterReportViewModel.Series : HttpUtility.HtmlDecode(masterReportViewModel.Series);
      return masterReportViewModelList;
    }

    private string ConvertDateFormat(string value)
    {
      DateTime result;
      return !string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result) ? result.ToString("MM/dd/yyyy") : "";
    }

    public ExportResult Export(
      KendoGridRequest request,
      G37MasterReportSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<G37MasterReportViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _);
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType2<string, string, string, string, string, string, string, Decimal, string, string, string, string>> datas = searchData.Select(d =>
        {
          string issueNbr = d.IssueNbr;
          string series = d.Series;
          string issuer = d.Issuer;
          string cusip = d.CUSIP;
          string state = d.State;
          string typeOfOffering = d.TypeOfOffering;
          string leadManager = d.LeadManager;
          Decimal hseParticipation = d.HSEParticipation;
          DateTime? nullable;
          DateTime dateTime;
          string str1;
          if (!d.SaleDate.HasValue)
          {
            str1 = "";
          }
          else
          {
            nullable = d.SaleDate;
            dateTime = nullable.Value;
            str1 = dateTime.ToString("MM/dd/yyyy");
          }
          nullable = d.G32SubmissionDate;
          string str2;
          if (!nullable.HasValue)
          {
            str2 = "";
          }
          else
          {
            nullable = d.G32SubmissionDate;
            dateTime = nullable.Value;
            str2 = dateTime.ToString("MM/dd/yyyy");
          }
          nullable = d.TransactionSettlementDate;
          string str3;
          if (!nullable.HasValue)
          {
            str3 = "";
          }
          else
          {
            nullable = d.TransactionSettlementDate;
            dateTime = nullable.Value;
            str3 = dateTime.ToString("MM/dd/yyyy");
          }
          string qtrReported = d.QtrReported;
          return new
          {
            IssueNbr = issueNbr,
            Series = series,
            Issuer = issuer,
            CUSIP = cusip,
            State = state,
            TypeOfOffering = typeOfOffering,
            LeadManager = leadManager,
            HSEParticipation = hseParticipation,
            SaleDate = str1,
            G32SubmissionDate = str2,
            TransactionSettlementDate = str3,
            QtrReported = qtrReported
          };
        });
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("G-37 Master Report", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Transaction Number", "IssueNbr", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("8cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Series", "Series", Unit.Parse("6.2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("CUSIP", "CUSIP", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("State", "State", Unit.Parse("1.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Type of Offering", "TypeOfOffering", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Manager", "LeadManager", Unit.Parse("7cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddMeasure("Firm Participation", "HSEParticipation", Unit.Parse("6.0cm"), "$#,##0.000", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Actual Award Date", "SaleDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("G-32 Date", "G32SubmissionDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Delivery Date", "TransactionSettlementDate", Unit.Parse("4.0cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("QTR", "QtrReported", Unit.Parse("2cm"), "##", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "G-37MasterReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }

    public G37MasterReportSearchViewModel InitializeViewModel() => new G37MasterReportSearchViewModel()
    {
      TypeOfOfferings = this.LookupRepository.FetchByLookupKey("Type of Offering").ToList<LookupItem>()
    };
  }
}
