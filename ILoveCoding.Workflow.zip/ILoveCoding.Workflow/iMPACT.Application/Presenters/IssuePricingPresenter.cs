﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.IssuePricingPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (IssuePricingPresenter))]
  public class IssuePricingPresenter : PresenterBase
  {
    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IIssuePricingRepository IssuePricingRepository { get; set; }

    private string[] GetLookupItemKeys() => new string[8]
    {
      "Issue Status",
      "Security Type (General)",
      "Pricing Accrue From",
      "Pricing Form",
      "Coupon Frequency",
      "Day Count",
      "Call Feature",
      "Security Type (Specific)"
    };

    public IssuePricingViewModel GetIssuePricingDetails(long appTransID)
    {
      try
      {
        IssuePricingViewModel pricingViewModel1 = new IssuePricingViewModel(this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetLookupItemKeys()).ToList<LookupItemMappings>());
        using (IDataReader reader = this.IssuePricingRepository.FetchIssuePricings(appTransID))
        {
          if (reader != null)
          {
            IRowMapper<PricingViewModel> rowMapper1 = MapBuilder<PricingViewModel>.MapAllProperties().Map<DateTime?>((Expression<Func<PricingViewModel, DateTime?>>) (x => x.CouponDate)).ToColumn("FirstCouponDate").Map<string>((Expression<Func<PricingViewModel, string>>) (x => x.AmtTax)).ToColumn("AMTTaxable").Map<string>((Expression<Func<PricingViewModel, string>>) (x => x.StateTax)).ToColumn("StateTaxable").Map<string>((Expression<Func<PricingViewModel, string>>) (x => x.AccureForm)).ToColumn("AccrueFrom").DoNotMap<string>((Expression<Func<PricingViewModel, string>>) (x => x.SeriesDataUpdate)).DoNotMap<bool>((Expression<Func<PricingViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<PricingViewModel, bool>>) (x => x.IsDirty)).Build();
            IRowMapper<CusipViewModel> rowMapper2 = MapBuilder<CusipViewModel>.MapAllProperties().Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.SeriesID)).ToColumn("SeriesID").Map<DateTime?>((Expression<Func<CusipViewModel, DateTime?>>) (x => x.MaturityDate)).ToColumn("MaturityDate").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.CUSIP)).ToColumn("CUSIP").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.Term)).ToColumn("Term").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.AverageLife)).ToColumn("AverageLife").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.Amount)).ToColumn("Amount").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.Coupon)).ToColumn("Coupon").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.Yield)).ToColumn("Yield").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.Price)).ToColumn("Price").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.YTM)).ToColumn("YTM").Map<DateTime?>((Expression<Func<CusipViewModel, DateTime?>>) (x => x.CallDate)).ToColumn("CallDate").Map<string>((Expression<Func<CusipViewModel, string>>) (x => x.Takedown)).ToColumn("Takedown").Map<bool>((Expression<Func<CusipViewModel, bool>>) (x => x.Insured)).ToColumn("Insured").DoNotMap<bool>((Expression<Func<CusipViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<CusipViewModel, bool>>) (x => x.IsDirty)).Build();
            while (reader.Read())
              pricingViewModel1.IssuerPricing.Add(rowMapper1.MapRow((IDataRecord) reader));
            List<CusipViewModel> cusipViewModelList = new List<CusipViewModel>();
            if (reader.NextResult())
            {
              while (reader.Read())
                cusipViewModelList.Add(rowMapper2.MapRow((IDataRecord) reader));
            }
            if (reader.NextResult() && reader.Read())
            {
              long pricingStatus = reader.GetInt64(0);
              pricingViewModel1.PricingStatus = pricingViewModel1.PricingStatuses.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.LookupItemID == pricingStatus)).FirstOrDefault<LookupItemMappings>();
            }
            if (reader.NextResult())
              pricingViewModel1.PriorityOfOrderDetails = this.GetPriorityOfOrderDetails(reader);
            foreach (PricingViewModel pricingViewModel2 in pricingViewModel1.IssuerPricing)
            {
              PricingViewModel v = pricingViewModel2;
              v.CUSIP = cusipViewModelList.FindAll((Predicate<CusipViewModel>) (x => x.SeriesID == v.SeriesID));
              if (v.CUSIP.Count == 0)
                v.CUSIP = new List<CusipViewModel>()
                {
                  new CusipViewModel()
                  {
                    Amount = "",
                    AverageLife = "",
                    Coupon = "",
                    CUSIP = "",
                    Price = "",
                    SeriesID = v.SeriesID,
                    Term = "",
                    Yield = "",
                    YTM = ""
                  }
                };
            }
          }
        }
        return pricingViewModel1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        IssuePricingViewModel pricingViewModel = new IssuePricingViewModel();
        pricingViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return pricingViewModel;
      }
    }

    private IEnumerable<PriorityOfOrderDetail> GetPriorityOfOrderDetails(
      IDataReader reader)
    {
      List<PriorityOfOrderDetail> priorityOfOrderDetailList = new List<PriorityOfOrderDetail>();
      IRowMapper<PriorityOfOrderDetail> rowMapper = MapBuilder<PriorityOfOrderDetail>.MapAllProperties().Build();
      while (reader.Read())
        priorityOfOrderDetailList.Add(rowMapper.MapRow((IDataRecord) reader));
      return (IEnumerable<PriorityOfOrderDetail>) priorityOfOrderDetailList;
    }

    public SaveResult SaveIssuePricing(
      List<PricingViewModel> pricing,
      long appTransactionID)
    {
      try
      {
        this.GetSafeObject<PricingViewModel>(pricing);
        DataTable pricingDt;
        DataTable cusipDt;
        this.ReturnIssuePricingDataTable(pricing, out pricingDt, out cusipDt);
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssuePricingRepository.SaveIssuePricings(appTransactionID, pricingDt, cusipDt);
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private void ReturnIssuePricingDataTable(
      List<PricingViewModel> pricing,
      out DataTable pricingDt,
      out DataTable cusipDt)
    {
      pricingDt = new DataTable("PricingViewModel");
      pricingDt.Columns.Add(new DataColumn("SeriesID", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("ParAmount", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("SecType", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("DatedDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("CouponDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("SettlementDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("FedTax", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("StateTax", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("AmtTax", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("BankQualified", typeof (bool)));
      pricingDt.Columns.Add(new DataColumn("AccureForm", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("Form", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("DayCount", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("CallFeature", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("CallDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("CallPrice", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("CouponFreq", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("StructureDateFrom", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("StructureDateTo", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("PutDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("RecordDate", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("PricingDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("RetailOrderPeriodDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("ActualAwardDate", typeof (DateTime)));
      pricingDt.Columns.Add(new DataColumn("ActualAwardDateTimeZone", typeof (string)));
      pricingDt.Columns.Add(new DataColumn("FirmRole", typeof (double)));
      pricingDt.Columns.Add(new DataColumn("FirmLiability", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("FirmMgtFee", typeof (Decimal)));
      pricingDt.Columns.Add(new DataColumn("SDCCredit", typeof (Decimal)));
      cusipDt = new DataTable("CusipViewModel");
      cusipDt.Columns.Add(new DataColumn("SeriesID", typeof (double)));
      cusipDt.Columns.Add(new DataColumn("MaturityDate", typeof (DateTime)));
      cusipDt.Columns.Add(new DataColumn("CUSIP", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("Term", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("AverageLife", typeof (float)));
      cusipDt.Columns.Add(new DataColumn("Amount", typeof (float)));
      cusipDt.Columns.Add(new DataColumn("Coupon", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("Yield", typeof (float)));
      cusipDt.Columns.Add(new DataColumn("Price", typeof (float)));
      cusipDt.Columns.Add(new DataColumn("YTM", typeof (string)));
      cusipDt.Columns.Add(new DataColumn("CallDate", typeof (DateTime)));
      cusipDt.Columns.Add(new DataColumn("Takedown", typeof (float)));
      cusipDt.Columns.Add(new DataColumn("Insured", typeof (bool)));
      foreach (PricingViewModel pricingViewModel in pricing)
      {
        DataRow row1 = pricingDt.NewRow();
        row1["SeriesID"] = (object) pricingViewModel.SeriesID;
        row1["ParAmount"] = string.IsNullOrEmpty(pricingViewModel.ParAmount) ? (object) DBNull.Value : (object) pricingViewModel.ParAmount;
        row1["SecType"] = string.IsNullOrEmpty(pricingViewModel.SecType) ? (object) DBNull.Value : (object) pricingViewModel.SecType;
        DataRow dataRow1 = row1;
        DateTime? nullable = pricingViewModel.DatedDate;
        object obj1 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow1["DatedDate"] = obj1;
        DataRow dataRow2 = row1;
        nullable = pricingViewModel.CouponDate;
        object obj2 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow2["CouponDate"] = obj2;
        DataRow dataRow3 = row1;
        nullable = pricingViewModel.SettlementDate;
        object obj3 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow3["SettlementDate"] = obj3;
        row1["FedTax"] = string.IsNullOrEmpty(pricingViewModel.FedTax) ? (object) DBNull.Value : (object) pricingViewModel.FedTax;
        row1["StateTax"] = string.IsNullOrEmpty(pricingViewModel.StateTax) ? (object) DBNull.Value : (object) pricingViewModel.StateTax;
        row1["AmtTax"] = string.IsNullOrEmpty(pricingViewModel.AmtTax) ? (object) DBNull.Value : (object) pricingViewModel.AmtTax;
        row1["BankQualified"] = string.IsNullOrEmpty(pricingViewModel.BankQualified) ? (object) DBNull.Value : (object) pricingViewModel.BankQualified;
        row1["AccureForm"] = string.IsNullOrEmpty(pricingViewModel.AccureForm) ? (object) DBNull.Value : (object) pricingViewModel.AccureForm;
        row1["Form"] = string.IsNullOrEmpty(pricingViewModel.Form) ? (object) DBNull.Value : (object) pricingViewModel.Form;
        row1["DayCount"] = string.IsNullOrEmpty(pricingViewModel.DayCount) ? (object) DBNull.Value : (object) pricingViewModel.DayCount;
        row1["CallFeature"] = string.IsNullOrEmpty(pricingViewModel.CallFeature) ? (object) DBNull.Value : (object) pricingViewModel.CallFeature;
        DataRow dataRow4 = row1;
        nullable = pricingViewModel.CallDate;
        object obj4 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow4["CallDate"] = obj4;
        row1["CallPrice"] = string.IsNullOrEmpty(pricingViewModel.CallPrice) ? (object) DBNull.Value : (object) pricingViewModel.CallPrice;
        row1["CouponFreq"] = string.IsNullOrEmpty(pricingViewModel.CouponFreq) ? (object) DBNull.Value : (object) pricingViewModel.CouponFreq;
        DataRow dataRow5 = row1;
        nullable = pricingViewModel.StructureDateFrom;
        object obj5 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow5["StructureDateFrom"] = obj5;
        DataRow dataRow6 = row1;
        nullable = pricingViewModel.StructureDateTo;
        object obj6 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow6["StructureDateTo"] = obj6;
        DataRow dataRow7 = row1;
        nullable = pricingViewModel.PutDate;
        object obj7 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow7["PutDate"] = obj7;
        row1["RecordDate"] = string.IsNullOrEmpty(pricingViewModel.RecordDate) ? (object) DBNull.Value : (object) pricingViewModel.RecordDate;
        DataRow dataRow8 = row1;
        nullable = pricingViewModel.PricingDate;
        object obj8 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow8["PricingDate"] = obj8;
        DataRow dataRow9 = row1;
        nullable = pricingViewModel.RetailOrderPeriodDate;
        object obj9 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow9["RetailOrderPeriodDate"] = obj9;
        DataRow dataRow10 = row1;
        nullable = pricingViewModel.ActualAwardDate;
        object obj10 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
        dataRow10["ActualAwardDate"] = obj10;
        DataRow dataRow11 = row1;
        nullable = pricingViewModel.ActualAwardDate;
        object obj11 = !nullable.HasValue ? (object) null : (string.IsNullOrEmpty(pricingViewModel.ActualAwardDateTimeZone) ? (object) DBNull.Value : (object) pricingViewModel.ActualAwardDateTimeZone);
        dataRow11["ActualAwardDateTimeZone"] = obj11;
        row1["FirmRole"] = string.IsNullOrEmpty(pricingViewModel.FirmRole) ? (object) DBNull.Value : (object) pricingViewModel.FirmRole;
        row1["FirmLiability"] = string.IsNullOrEmpty(pricingViewModel.FirmLiability) ? (object) DBNull.Value : (object) pricingViewModel.FirmLiability;
        row1["FirmMgtFee"] = string.IsNullOrEmpty(pricingViewModel.FirmMgtFee) ? (object) DBNull.Value : (object) pricingViewModel.FirmMgtFee;
        row1["SDCCredit"] = string.IsNullOrEmpty(pricingViewModel.SDCCredit) ? (object) DBNull.Value : (object) pricingViewModel.SDCCredit;
        pricingDt.Rows.Add(row1);
        foreach (CusipViewModel cusipViewModel in pricingViewModel.CUSIP)
        {
          if (!cusipViewModel.IsDeleted)
          {
            DataRow row2 = cusipDt.NewRow();
            row2["SeriesID"] = (object) cusipViewModel.SeriesID;
            DataRow dataRow12 = row2;
            nullable = cusipViewModel.MaturityDate;
            object obj12 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
            dataRow12["MaturityDate"] = obj12;
            row2["CUSIP"] = string.IsNullOrEmpty(cusipViewModel.CUSIP) ? (object) DBNull.Value : (object) cusipViewModel.CUSIP;
            row2["Term"] = string.IsNullOrEmpty(cusipViewModel.Term) ? (object) DBNull.Value : (object) cusipViewModel.Term;
            row2["AverageLife"] = string.IsNullOrEmpty(cusipViewModel.AverageLife) ? (object) DBNull.Value : (object) cusipViewModel.AverageLife;
            row2["Amount"] = string.IsNullOrEmpty(cusipViewModel.Amount) ? (object) DBNull.Value : (object) cusipViewModel.Amount;
            row2["Coupon"] = string.IsNullOrEmpty(cusipViewModel.Coupon) ? (object) DBNull.Value : (object) cusipViewModel.Coupon;
            row2["Yield"] = string.IsNullOrEmpty(cusipViewModel.Yield) ? (object) DBNull.Value : (object) cusipViewModel.Yield;
            row2["Price"] = string.IsNullOrEmpty(cusipViewModel.Price) ? (object) DBNull.Value : (object) cusipViewModel.Price;
            row2["YTM"] = string.IsNullOrEmpty(cusipViewModel.YTM) ? (object) DBNull.Value : (object) cusipViewModel.YTM;
            DataRow dataRow13 = row2;
            nullable = cusipViewModel.CallDate;
            object obj13 = nullable.HasValue ? (object) nullable.GetValueOrDefault() : (object) DBNull.Value;
            dataRow13["CallDate"] = obj13;
            row2["Takedown"] = string.IsNullOrEmpty(cusipViewModel.Takedown) ? (object) DBNull.Value : (object) cusipViewModel.Takedown;
            row2["Insured"] = (object) cusipViewModel.Insured;
            cusipDt.Rows.Add(row2);
          }
        }
      }
    }

    public SaveResult SavePricingStatus(long pricingStatus, long appTransactionID)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssuePricingRepository.SavePricingStatus(pricingStatus, appTransactionID);
          transactionScope.Complete();
          return new SaveResult();
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }
  }
}
