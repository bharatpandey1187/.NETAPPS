﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.GoodFaithCompetitiveViewsPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.Mail;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Transactions;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (GoodFaithCompetitiveViewsPresenter))]
  public class GoodFaithCompetitiveViewsPresenter : PresenterBase
  {
    private string[] partnersEmailAddress;
    private StringBuilder InfoReceipts = new StringBuilder();

    [Dependency]
    public IGoodFaithCompetitiveViewsRepository GoodFaithCompetitiveViewsRepository { get; set; }

    [Dependency]
    public ICompetitiveIssueRepository CompIssueRepository { get; set; }

    [Dependency]
    public IEmailTemplateRepository EmailTemplateRepository { get; set; }

    [Dependency]
    public IMailSender Smtpsender { get; set; }

    [Dependency]
    public SendEmailPresenter SendEmailPresenter { get; set; }

    [Dependency]
    public CompetitiveIssuePresenter CompIssuePresenter { get; set; }

    public List<BankerCompetitiveViewModel> FetchBankerViewRecords(
      GoodFaithCompViewsSearchViewModel model,
      string goodFaithView)
    {
      try
      {
        bool flag = this.HasIndependentPermission("Good Faith Report", "Edit");
        List<BankerCompetitiveViewModel> competitiveViewModelList = new List<BankerCompetitiveViewModel>();
        using (IDataReader dataReader = this.GoodFaithCompetitiveViewsRepository.FetchIssuesForBankerView(model.fromDate, model.toDate, model.typeOfOffering == string.Empty ? 0 : Convert.ToInt32(model.typeOfOffering), model.goodFaithStatus, !goodFaithView.Equals("banker")))
        {
          IRowMapper<BankerCompetitiveViewModel> rowMapper = MapBuilder<BankerCompetitiveViewModel>.MapNoProperties().MapByName<long>((Expression<Func<BankerCompetitiveViewModel, long>>) (x => x.AppTransactionID)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (x => x.IssueName)).MapByName<Decimal?>((Expression<Func<BankerCompetitiveViewModel, Decimal?>>) (x => x.GoodFaithAmount)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (x => x.WireInfo)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (x => x.State)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (x => x.TypeOfOffering)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (x => x.GoodFaithInstructions)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (x => x.GoodFaithType)).MapByName<DateTime?>((Expression<Func<BankerCompetitiveViewModel, DateTime?>>) (x => x.GoodFaithIssuedDate)).MapByName<DateTime?>((Expression<Func<BankerCompetitiveViewModel, DateTime?>>) (x => x.GoodFaithReturnedDate)).MapByName<DateTime?>((Expression<Func<BankerCompetitiveViewModel, DateTime?>>) (x => x.GoodFaithDuedate)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (X => X.FedReferenceNumber)).MapByName<string>((Expression<Func<BankerCompetitiveViewModel, string>>) (x => x.StateIDs)).Build();
          if (dataReader != null)
          {
            while (dataReader.Read())
            {
              BankerCompetitiveViewModel competitiveViewModel = rowMapper.MapRow((IDataRecord) dataReader);
              competitiveViewModel.EnableEditPermission = flag;
              competitiveViewModelList.Add(competitiveViewModel);
            }
          }
        }
        return competitiveViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<BankerCompetitiveViewModel>();
      }
    }

    public EmailTemplateDetailViewModel PrepareBankerViewEmailContent(
      List<BankerCompetitiveViewModel> model,
      string state)
    {
      try
      {
        IrisSoftware.iMPACT.Data.EmailTemplate emailModel = !state.Equals("TX") ? this.EmailTemplateRepository.FetchByKey(2) : this.EmailTemplateRepository.FetchByKey(1);
        this.PrepareEmailBody(ref emailModel, model, state);
        return new EmailTemplateDetailViewModel(emailModel);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        EmailTemplateDetailViewModel templateDetailViewModel = new EmailTemplateDetailViewModel();
        templateDetailViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return templateDetailViewModel;
      }
    }

    private void PrepareEmailBody(
      ref IrisSoftware.iMPACT.Data.EmailTemplate emailModel,
      List<BankerCompetitiveViewModel> model,
      string state)
    {
      model = model.OrderBy<BankerCompetitiveViewModel, DateTime?>((Func<BankerCompetitiveViewModel, DateTime?>) (x => x.GoodFaithDate)).ToList<BankerCompetitiveViewModel>();
      DateTime? nullable1 = model.Select<BankerCompetitiveViewModel, DateTime?>((Func<BankerCompetitiveViewModel, DateTime?>) (x => x.GoodFaithDate)).First<DateTime?>();
      DateTime? nullable2 = model.Select<BankerCompetitiveViewModel, DateTime?>((Func<BankerCompetitiveViewModel, DateTime?>) (x => x.GoodFaithDate)).Last<DateTime?>();
      string empty = string.Empty;
      IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = emailModel;
      emailTemplate.Subject = emailTemplate.Subject + " " + string.Format("{0:MM/dd/yyyy}", (object) nullable1) + " To " + string.Format("{0:MM/dd/yyyy}", (object) nullable2);
      IOrderedEnumerable<IGrouping<DateTime?, BankerCompetitiveViewModel>> orderedEnumerable = model.GroupBy<BankerCompetitiveViewModel, DateTime?>((Func<BankerCompetitiveViewModel, DateTime?>) (BankerCompetitiveViewModel => BankerCompetitiveViewModel.GoodFaithDate)).OrderBy<IGrouping<DateTime?, BankerCompetitiveViewModel>, DateTime?>((Func<IGrouping<DateTime?, BankerCompetitiveViewModel>, DateTime?>) (newModel => newModel.Key));
      StringBuilder stringBuilder = new StringBuilder();
      foreach (IGrouping<DateTime?, BankerCompetitiveViewModel> grouping in (IEnumerable<IGrouping<DateTime?, BankerCompetitiveViewModel>>) orderedEnumerable)
      {
        DateTime dateTime = Convert.ToDateTime((object) grouping.Key);
        stringBuilder.Append("<u> " + string.Format("{0:dddd, MMMM d, yyyy}", (object) dateTime) + "</u>");
        stringBuilder.Append("<br />");
        if (state == "NONTX")
        {
          foreach (BankerCompetitiveViewModel competitiveViewModel in (IEnumerable<BankerCompetitiveViewModel>) grouping)
          {
            stringBuilder.Append("<br />");
            stringBuilder.Append(competitiveViewModel.Issuer + ": " + string.Format("{0:C}", (object) competitiveViewModel.GoodFaithAmount) + " by wire transfer to");
            stringBuilder.Append("<br />");
            stringBuilder.Append(competitiveViewModel.GoodFaithInstructions);
            stringBuilder.Append("                                                             ");
            stringBuilder.Append("<br />");
          }
        }
        else
        {
          foreach (BankerCompetitiveViewModel competitiveViewModel in (IEnumerable<BankerCompetitiveViewModel>) grouping)
          {
            stringBuilder.Append("<br />");
            stringBuilder.Append(competitiveViewModel.Issuer + ": " + string.Format("{0:C}", (object) competitiveViewModel.GoodFaithAmount) + " by wire transfer to");
            stringBuilder.Append("                                                             ");
            stringBuilder.Append("<br />");
          }
        }
        stringBuilder.Append("<br />");
      }
      emailModel.Body = stringBuilder.ToString();
    }

    public SaveResult UpdateBankerViewAuditTrail(string issues, string content)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.GoodFaithCompetitiveViewsRepository.SaveBankerViewAuditTrail(issues, content);
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SaveOperationsViewData(List<BankerCompetitiveViewModel> model)
    {
      try
      {
        this.GetSafeObject<BankerCompetitiveViewModel>(model);
        List<SaveResult> saveResultList = new List<SaveResult>();
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.GoodFaithCompetitiveViewsRepository.SaveOperationsViewData(this.ConvertListToDataTable(model));
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private DataTable ConvertListToDataTable(List<BankerCompetitiveViewModel> model)
    {
      DataTable dataTable = new DataTable("BankerCompetitiveViewModel");
      dataTable.Columns.Add(new DataColumn("AppTransactionID", Type.GetType("System.Int64")));
      dataTable.Columns.Add(new DataColumn("WireInfo", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FedReferenceNumber", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("GoodFaithIssuedDate", Type.GetType("System.DateTime")));
      dataTable.Columns.Add(new DataColumn("GoodFaithReturnedDate", Type.GetType("System.DateTime")));
      foreach (BankerCompetitiveViewModel competitiveViewModel in model)
      {
        if (!competitiveViewModel.IsDisabled)
        {
          DataRow row = dataTable.NewRow();
          row["AppTransactionID"] = (object) competitiveViewModel.AppTransactionID;
          DateTime? nullable = competitiveViewModel.GoodFaithIssuedDate;
          row["GoodFaithIssuedDate"] = !nullable.HasValue ? (object) DBNull.Value : (object) competitiveViewModel.GoodFaithIssuedDate;
          nullable = competitiveViewModel.GoodFaithReturnedDate;
          row["GoodFaithReturnedDate"] = !nullable.HasValue ? (object) DBNull.Value : (object) competitiveViewModel.GoodFaithReturnedDate;
          row["WireInfo"] = (object) competitiveViewModel.WireInfo;
          row["FedReferenceNumber"] = (object) competitiveViewModel.FedReferenceNumber;
          dataTable.Rows.Add(row);
        }
      }
      return dataTable;
    }

    public ExportResult Export(
      KendoGridRequest request,
      GoodFaithCompViewsSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<BankerCompetitiveViewModel> source = this.FetchBankerViewRecords(searchCriteria, "banker");
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType19<string, string, string, string, string, Decimal?, string, string, string, string, string>> datas = source.Select(d =>
        {
          string issueName = d.IssueName;
          string state = d.State;
          string typeOfOffering = d.TypeOfOffering;
          string goodFaithType = d.GoodFaithType;
          DateTime? nullable;
          DateTime dateTime;
          string str1;
          if (!d.GoodFaithDuedate.HasValue)
          {
            str1 = "";
          }
          else
          {
            nullable = d.GoodFaithDuedate;
            dateTime = nullable.Value;
            str1 = dateTime.ToString("MM/dd/yyyy");
          }
          Decimal? goodFaithAmount = d.GoodFaithAmount;
          string faithInstructions = d.GoodFaithInstructions;
          nullable = d.GoodFaithIssuedDate;
          string str2;
          if (!nullable.HasValue)
          {
            str2 = "";
          }
          else
          {
            nullable = d.GoodFaithIssuedDate;
            dateTime = nullable.Value;
            str2 = dateTime.ToString("MM/dd/yyyy");
          }
          string wireInfo = d.WireInfo;
          nullable = d.GoodFaithReturnedDate;
          string str3;
          if (!nullable.HasValue)
          {
            str3 = "";
          }
          else
          {
            nullable = d.GoodFaithReturnedDate;
            dateTime = nullable.Value;
            str3 = dateTime.ToString("MM/dd/yyyy");
          }
          string fedReferenceNumber = d.FedReferenceNumber;
          return new
          {
            IssueName = issueName,
            State = state,
            TypeOfOffering = typeOfOffering,
            GoodFaithType = goodFaithType,
            GoodFaithDueDate = str1,
            GoodFaithAmount = goodFaithAmount,
            GoodFaithInstructions = faithInstructions,
            GoodFaithIssuedDate = str2,
            WireInfo = wireInfo,
            GoodFaithReturnedDate = str3,
            FedReferenceNumber = fedReferenceNumber
          };
        });
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Good Faith Report", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Transaction Description", "IssueName", Unit.Parse("7cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("State", "State", Unit.Parse("2.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Type of Offering", "TypeOfOffering", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("GF Type", "GoodFaithType", Unit.Parse("3.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("GF Due Date", "GoodFaithDueDate", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddMeasure("GF Amount", "GoodFaithAmount", Unit.Parse("6cm"), "$#,0.00", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("GF Instructions", "GoodFaithInstructions", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("GF Issued Date", "GoodFaithIssuedDate", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("GF Wire/Check Info", "WireInfo", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("GF Returned Date", "GoodFaithReturnedDate", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Fed Reference Number", "FedReferenceNumber", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "GoodFaithReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ExportResult();
      }
    }

    public ExportResult ExportOps(
      KendoGridRequest request,
      GoodFaithCompViewsSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<BankerCompetitiveViewModel> source = this.FetchBankerViewRecords(searchCriteria, "ops");
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType4<string, string, string, Decimal?, string, string, string>> datas = source.Select(d => new
        {
          IssueNumber = d.IssueNumber,
          IssueName = d.IssueName,
          Issuer = d.Issuer,
          GoodFaithAmount = d.GoodFaithAmount,
          GoodFaithDate = d.GoodFaithDate.HasValue ? d.GoodFaithDate.Value.ToString("MM/dd/yyyy") : "",
          State = d.State,
          WireInfo = d.WireInfo
        });
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("Good Faith Operation View");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CaptionStyleBuilder.BackgroundColor("gray");
        columnStyleProvider1.CaptionStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderColor("black");
        columnStyleProvider1.CaptionStyleBuilder.Color("white");
        columnStyleProvider1.CellTotalStyleBuilder.BackgroundColor("gray");
        columnStyleProvider1.CellTotalStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellTotalStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellTotalStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellTotalStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellTotalStyleBuilder.Color("white");
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CaptionStyleBuilder.BackgroundColor("gray");
        columnStyleProvider2.CaptionStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderColor("black");
        columnStyleProvider2.CaptionStyleBuilder.Color("white");
        columnStyleProvider2.CellTotalStyleBuilder.BackgroundColor("gray");
        columnStyleProvider2.CellTotalStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellTotalStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellTotalStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellTotalStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellTotalStyleBuilder.Padding(Unit.Parse(".4cm"));
        columnStyleProvider2.CellTotalStyleBuilder.Color("white");
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Issue Number", "IssueNumber", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issue Name", "IssueName", Unit.Parse("9cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("8.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("State", "State", Unit.Parse("1.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("WireInfo", "WireInfo", Unit.Parse("21cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "GoodFaithOperationView", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ExportResult();
      }
    }

    public BankerCompetitiveViewModel FetchInitializedViewModel(
      string view)
    {
      try
      {
        return new BankerCompetitiveViewModel()
        {
          IssueNumber = "",
          IssueName = "",
          Issuer = "",
          GoodFaithAmount = new Decimal?(0M),
          GoodFaithDuedate = new DateTime?(),
          GoodFaithDate = new DateTime?(),
          State = "",
          TypeOfOffering = "",
          WireInfo = "",
          FedReferenceNumber = "",
          IsGoodFaithViewReadOnly = !this.ReturnUpdateIssueGoodFaithWireInfo(view)
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        BankerCompetitiveViewModel competitiveViewModel = new BankerCompetitiveViewModel();
        competitiveViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return competitiveViewModel;
      }
    }

    private bool ReturnUpdateIssueGoodFaithWireInfo(string view)
    {
      bool flag = false;
      if (view.Equals("banker"))
        flag = this.HasIndependentPermission("Send Good Faith Email", "SendEmail");
      else if (view.Equals("ops"))
        flag = this.HasIndependentPermission("Good Faith Wire Info", "Edit");
      return flag;
    }

    private string ConvertDateFormat(string value)
    {
      DateTime result;
      return !string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result) ? result.ToString("MM/dd/yyyy") : "";
    }

    public SendEmailModel PrepareEmailContent(long appTransID)
    {
      try
      {
        CompetitiveIssue issue = this.CompIssueRepository.FetchByKey(appTransID);
        this.GetInternalPartnersEmailAddress(issue, out this.partnersEmailAddress);
        IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.FetchByKey(240);
        SendEmailModel sendEmailModel = new SendEmailModel()
        {
          EmailTo = this.SetAppGroupRecipients(emailTemplate.To, appTransID),
          EmailCC = this.SetAppGroupRecipients(emailTemplate.Cc, appTransID),
          EmailSubject = this.CompIssuePresenter.ResolvePlaceholders(emailTemplate.Subject, issue),
          EmailContent = this.CompIssuePresenter.ResolvePlaceholders(emailTemplate.Body, issue)
        };
        sendEmailModel.EmailTo = this.SetRecipients(emailTemplate.To);
        sendEmailModel.EmailCC = this.SetRecipients(emailTemplate.Cc);
        return sendEmailModel;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return (SendEmailModel) null;
      }
    }

    public EmailCallback SendNewEmail(long appTransID)
    {
      try
      {
        return this.SendEmailPresenter.SendEmail(this.PrepareEmailContent(appTransID));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return (EmailCallback) null;
      }
    }

    private void GetInternalPartnersEmailAddress(
      CompetitiveIssue issue,
      out string[] partnersEmailAddress)
    {
      partnersEmailAddress = new string[8]
      {
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty
      };
      if (issue.InternalPartners == null || issue.InternalPartners.Count <= 0)
        return;
      foreach (InternalPartner internalPartner in issue.InternalPartners)
      {
        if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email) && internalPartner.IsActive)
        {
          switch ((IssueEnums.RoleTypes) internalPartner.RoleTypeId.Value)
          {
            case IssueEnums.RoleTypes.InvestmentBankingTeam:
              this.FillInvestmentBankingDetails(partnersEmailAddress, internalPartner);
              continue;
            case IssueEnums.RoleTypes.AnalystProfessionalSupport:
              this.FillAnalystDetails(partnersEmailAddress, internalPartner);
              continue;
            case IssueEnums.RoleTypes.SupervisoryPrincipal:
              partnersEmailAddress[4] = string.Format("{0}{1};", (object) partnersEmailAddress[4], (object) internalPartner.Email);
              continue;
            case IssueEnums.RoleTypes.BankRM:
              partnersEmailAddress[6] = string.Format("{0}{1};", (object) partnersEmailAddress[6], (object) internalPartner.Email);
              continue;
            case IssueEnums.RoleTypes.UnderWritingTeam:
              partnersEmailAddress[5] = string.Format("{0}{1};", (object) partnersEmailAddress[5], (object) internalPartner.Email);
              continue;
            default:
              continue;
          }
        }
      }
    }

    private string SetAppGroupRecipients(string email, long AppTransactionID)
    {
      if (!string.IsNullOrEmpty(email))
      {
        StringBuilder stringBuilder1 = new StringBuilder();
        if (email.Contains("[COMPLIANCE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(3.ToString());
        }
        if (email.Contains("[LEGAL]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(18.ToString());
        }
        if (email.Contains("[MERG]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(19.ToString());
        }
        if (email.Contains("[COMMITMENTCOMMITTEE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(31.ToString());
        }
        if (email.Contains("[MANAGEMENT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(29.ToString());
        }
        if (email.Contains("[JOB-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(37.ToString());
        }
        if (email.Contains("[FIRMCREDIT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(34.ToString());
        }
        if (email.Contains("[OPERATIONS]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(6.ToString());
        }
        if (email.Contains("[PNL-APPROVER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(35.ToString());
        }
        if (email.Contains("[PNL-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(39.ToString());
        }
        if (email.Contains("[FINANCE-CONTROLLER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(36.ToString());
        }
        if (stringBuilder1.Length > 0)
        {
          StringBuilder stringBuilder2 = new StringBuilder();
          foreach (string str in this.EmailTemplateRepository.FetchEmailByRoleID(AppTransactionID, stringBuilder1.ToString()))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append(";");
            stringBuilder2.Append(str);
          }
          StringBuilder emailUpdated = new StringBuilder();
          foreach (string adr in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
          {
            switch (adr.ToUpper().Trim())
            {
              case "[COMMITMENTCOMMITTEE]":
              case "[COMPLIANCE]":
              case "[FINANCE-CONTROLLER]":
              case "[FIRMCREDIT]":
              case "[JOB-ADMINISTRATOR]":
              case "[LEGAL]":
              case "[MANAGEMENT]":
              case "[MERG]":
              case "[OPERATIONS]":
              case "[PNL-ADMINISTRATOR]":
              case "[PNL-APPROVER]":
                continue;
              default:
                this.ApplyDelimiter(emailUpdated, adr);
                continue;
            }
          }
          emailUpdated.Append(";" + (object) stringBuilder2);
          return emailUpdated.ToString();
        }
      }
      return email;
    }

    private void FillAnalystDetails(string[] partnersEmailAddress, InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[2] = string.Format("{0}{1};", (object) partnersEmailAddress[2], (object) partner.Email);
      else
        partnersEmailAddress[3] = string.Format("{0}{1};", (object) partnersEmailAddress[3], (object) partner.Email);
    }

    private void FillInvestmentBankingDetails(
      string[] partnersEmailAddress,
      InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[0] = string.Format("{0}{1};", (object) partnersEmailAddress[0], (object) partner.Email);
      else if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("2", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[7] = string.Format("{0}{1};", (object) partnersEmailAddress[7], (object) partner.Email);
      else
        partnersEmailAddress[1] = string.Format("{0}{1};", (object) partnersEmailAddress[1], (object) partner.Email);
    }

    private void ApplyDelimiter(StringBuilder emailUpdated, string adr)
    {
      if (emailUpdated.Length > 0)
        emailUpdated.Append(";");
      emailUpdated.Append(adr);
    }

    private string SetRecipients(string recipients)
    {
      this.InfoReceipts.Length = 0;
      if (!string.IsNullOrEmpty(recipients))
      {
        foreach (string recipient in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
        {
          switch (recipient.Trim().ToUpper())
          {
            case "[INTERNAL-PARTNERS.ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[3]);
              break;
            case "[INTERNAL-PARTNERS.BANKRM]":
              this.GetRecipients(this.partnersEmailAddress[6]);
              break;
            case "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[1]);
              break;
            case "[INTERNAL-PARTNERS.LEAD-ANALYST]":
              this.GetRecipients(this.partnersEmailAddress[2]);
              break;
            case "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[0]);
              break;
            case "[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]":
              this.GetRecipients(this.partnersEmailAddress[7]);
              break;
            case "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]":
              this.GetRecipients(this.partnersEmailAddress[4]);
              break;
            case "[INTERNAL-PARTNERS.SYNDICATE]":
              this.GetRecipients(this.partnersEmailAddress[5]);
              break;
            default:
              this.GetRecipients(recipient);
              break;
          }
        }
      }
      return this.InfoReceipts.ToString();
    }

    public void GetRecipients(string recipient)
    {
      foreach (string str in recipient.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        if (!string.IsNullOrEmpty(str.Trim()) && !this.InfoReceipts.ToString().Contains(str))
          this.InfoReceipts.Append(str + ";");
      }
    }
  }
}
