﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.GoodFaithViewsPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.Mail;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (GoodFaithViewsPresenter))]
  public class GoodFaithViewsPresenter : PresenterBase
  {
    [Dependency]
    public IGoodFaithViewsRepository GoodFaithViewsRepository { get; set; }

    [Dependency]
    public IEmailTemplateRepository EmailTemplateRepository { get; set; }

    [Dependency]
    public IMailSender Smtpsender { get; set; }

    public List<BankerViewModel> FetchBankerViewRecords(
      GoodFaithViewsSearchViewModel model,
      string goodFaithView)
    {
      try
      {
        List<BankerViewModel> bankerViewModelList = new List<BankerViewModel>();
        using (IDataReader dataReader = this.GoodFaithViewsRepository.FetchIssuesForBankerView(model.fromDate, model.toDate, model.typeOfOffering == string.Empty ? 0 : Convert.ToInt32(model.typeOfOffering), model.state, !goodFaithView.Equals("banker")))
        {
          if (dataReader != null)
          {
            while (dataReader.Read())
            {
              Decimal result1;
              DateTime result2;
              bankerViewModelList.Add(new BankerViewModel()
              {
                AppTransactionID = Convert.ToInt64(dataReader["AppTransactionID"]),
                IssueNumber = dataReader["IssueNumber"].ToString(),
                IssueName = dataReader["IssueName"].ToString(),
                Issuer = dataReader["IssuerName"].ToString(),
                GoodFaithAmount = Decimal.TryParse(dataReader["GoodFaithAmount"].ToString(), out result1) ? new Decimal?(result1) : new Decimal?(),
                GoodFaithDate = DateTime.TryParse(dataReader["GoodFaithDate"].ToString(), out result2) ? new DateTime?(result2) : new DateTime?(),
                WireInfo = dataReader["GoodFaithWireInfo"].ToString(),
                State = dataReader["State"].ToString(),
                TypeOfOffering = dataReader["TypeOfOffering"].ToString(),
                GoodFaithInstructions = dataReader["GoodFaithInstructions"].ToString().Replace("\n\r", "<br />"),
                GoodFaithType = dataReader["GoodFaithType"].ToString(),
                AccountName = dataReader["AccountName"].ToString(),
                AccountNumber = dataReader["AccountNumber"].ToString(),
                ABANumber = dataReader["ABANumber"].ToString(),
                Notes = dataReader["Notes"].ToString(),
                IsGoodFaithViewReadOnly = !this.ReturnUpdateIssueGoodFaithWireInfo(goodFaithView)
              });
            }
          }
        }
        return bankerViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<BankerViewModel>();
      }
    }

    public EmailTemplateDetailViewModel PrepareBankerViewEmailContent(
      List<BankerViewModel> model,
      string state)
    {
      try
      {
        IrisSoftware.iMPACT.Data.EmailTemplate emailModel = !state.Equals("TX") ? this.EmailTemplateRepository.FetchByKey(2) : this.EmailTemplateRepository.FetchByKey(1);
        this.PrepareEmailBody(ref emailModel, model, state);
        return new EmailTemplateDetailViewModel(emailModel);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        EmailTemplateDetailViewModel templateDetailViewModel = new EmailTemplateDetailViewModel();
        templateDetailViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return templateDetailViewModel;
      }
    }

    private void PrepareEmailBody(
      ref IrisSoftware.iMPACT.Data.EmailTemplate emailModel,
      List<BankerViewModel> model,
      string state)
    {
      model = model.OrderBy<BankerViewModel, DateTime?>((Func<BankerViewModel, DateTime?>) (x => x.GoodFaithDate)).ToList<BankerViewModel>();
      DateTime? nullable1 = model.Select<BankerViewModel, DateTime?>((Func<BankerViewModel, DateTime?>) (x => x.GoodFaithDate)).First<DateTime?>();
      DateTime? nullable2 = model.Select<BankerViewModel, DateTime?>((Func<BankerViewModel, DateTime?>) (x => x.GoodFaithDate)).Last<DateTime?>();
      string empty = string.Empty;
      IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = emailModel;
      emailTemplate.Subject = emailTemplate.Subject + " " + string.Format("{0:MM/dd/yyyy}", (object) nullable1) + " To " + string.Format("{0:MM/dd/yyyy}", (object) nullable2);
      IOrderedEnumerable<IGrouping<DateTime?, BankerViewModel>> orderedEnumerable = model.GroupBy<BankerViewModel, DateTime?>((Func<BankerViewModel, DateTime?>) (BankerViewModel => BankerViewModel.GoodFaithDate)).OrderBy<IGrouping<DateTime?, BankerViewModel>, DateTime?>((Func<IGrouping<DateTime?, BankerViewModel>, DateTime?>) (newModel => newModel.Key));
      StringBuilder stringBuilder = new StringBuilder();
      foreach (IGrouping<DateTime?, BankerViewModel> grouping in (IEnumerable<IGrouping<DateTime?, BankerViewModel>>) orderedEnumerable)
      {
        DateTime dateTime = Convert.ToDateTime((object) grouping.Key);
        stringBuilder.Append("<u> " + string.Format("{0:dddd, MMMM d, yyyy}", (object) dateTime) + "</u>");
        stringBuilder.Append("<br />");
        if (state == "NONTX")
        {
          foreach (BankerViewModel bankerViewModel in (IEnumerable<BankerViewModel>) grouping)
          {
            stringBuilder.Append("<br />");
            stringBuilder.Append(bankerViewModel.Issuer + ": " + string.Format("{0:C}", (object) bankerViewModel.GoodFaithAmount) + " by wire transfer to");
            stringBuilder.Append("<br />");
            stringBuilder.Append(bankerViewModel.GoodFaithInstructions);
            stringBuilder.Append("                                                             ");
            stringBuilder.Append("<br />");
          }
        }
        else
        {
          foreach (BankerViewModel bankerViewModel in (IEnumerable<BankerViewModel>) grouping)
          {
            stringBuilder.Append("<br />");
            stringBuilder.Append(bankerViewModel.Issuer + ": " + string.Format("{0:C}", (object) bankerViewModel.GoodFaithAmount) + " by wire transfer to");
            stringBuilder.Append("                                                             ");
            stringBuilder.Append("<br />");
          }
        }
        stringBuilder.Append("<br />");
      }
      emailModel.Body = stringBuilder.ToString();
    }

    public SaveResult UpdateBankerViewAuditTrail(string issues, string content)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.GoodFaithViewsRepository.SaveBankerViewAuditTrail(issues, content);
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SaveOperationsViewData(List<BankerViewModel> model)
    {
      try
      {
        this.GetSafeObject<BankerViewModel>(model);
        List<SaveResult> saveResultList = new List<SaveResult>();
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.GoodFaithViewsRepository.SaveOperationsViewData(this.ConvertListToDataTable(model));
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private DataTable ConvertListToDataTable(List<BankerViewModel> model)
    {
      DataTable dataTable = new DataTable("BankerViewModel");
      dataTable.Columns.Add(new DataColumn("IssueNumber", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("WireInfo", Type.GetType("System.String")));
      foreach (BankerViewModel bankerViewModel in model)
      {
        DataRow row = dataTable.NewRow();
        row["IssueNumber"] = (object) bankerViewModel.IssueNumber;
        row["WireInfo"] = (object) bankerViewModel.WireInfo;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    public ExportResult Export(
      KendoGridRequest request,
      GoodFaithViewsSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<BankerViewModel> source = this.FetchBankerViewRecords(searchCriteria, "banker");
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType3<string, string, string, string, Decimal?, string, string, string, string, string, string, string, string>> datas = source.Select(d => new
        {
          IssueNumber = d.IssueNumber,
          IssueName = d.IssueName,
          Issuer = d.Issuer,
          TypeOfOffering = d.TypeOfOffering,
          GoodFaithAmount = d.GoodFaithAmount,
          GoodFaithDate = d.GoodFaithDate.HasValue ? d.GoodFaithDate.Value.ToString("MM/dd/yyyy") : "",
          State = d.State,
          GoodFaithType = d.GoodFaithType,
          AccountNumber = d.AccountNumber,
          AccountName = d.AccountName,
          ABANumber = d.ABANumber,
          Notes = d.Notes,
          GoodFaithInstructions = d.GoodFaithInstructions
        });
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Good Faith Banker Report", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Transaction Number", "IssueNumber", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Transaction Description", "IssueName", Unit.Parse("9cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("8cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Type of Offering", "TypeOfOffering", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddMeasure("Good Faith Amount", "GoodFaithAmount", Unit.Parse("6cm"), "$#,0.00", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Good Faith Date", "GoodFaithDate", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("State", "State", Unit.Parse("1.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Good Faith Type", "GoodFaithType", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Account Name", "AccountName", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Account Number", "AccountNumber", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("ABA Number", "ABANumber", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Notes", "Notes", Unit.Parse("10.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Good Faith Instructions", "GoodFaithInstructions", Unit.Parse("10.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "GoodFaithBankerReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ExportResult();
      }
    }

    public ExportResult ExportOps(
      KendoGridRequest request,
      GoodFaithViewsSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<BankerViewModel> source = this.FetchBankerViewRecords(searchCriteria, "ops");
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType4<string, string, string, Decimal?, string, string, string>> datas = source.Select(d => new
        {
          IssueNumber = d.IssueNumber,
          IssueName = d.IssueName,
          Issuer = d.Issuer,
          GoodFaithAmount = d.GoodFaithAmount,
          GoodFaithDate = d.GoodFaithDate.HasValue ? d.GoodFaithDate.Value.ToString("MM/dd/yyyy") : "",
          State = d.State,
          WireInfo = d.WireInfo
        });
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("Good Faith Operation View");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CaptionStyleBuilder.BackgroundColor("gray");
        columnStyleProvider1.CaptionStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CaptionStyleBuilder.BorderColor("black");
        columnStyleProvider1.CaptionStyleBuilder.Color("white");
        columnStyleProvider1.CellTotalStyleBuilder.BackgroundColor("gray");
        columnStyleProvider1.CellTotalStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellTotalStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellTotalStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellTotalStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellTotalStyleBuilder.Color("white");
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CaptionStyleBuilder.BackgroundColor("gray");
        columnStyleProvider2.CaptionStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CaptionStyleBuilder.BorderColor("black");
        columnStyleProvider2.CaptionStyleBuilder.Color("white");
        columnStyleProvider2.CellTotalStyleBuilder.BackgroundColor("gray");
        columnStyleProvider2.CellTotalStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellTotalStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellTotalStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellTotalStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellTotalStyleBuilder.Padding(Unit.Parse(".4cm"));
        columnStyleProvider2.CellTotalStyleBuilder.Color("white");
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Issue Number", "IssueNumber", Unit.Parse("4.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issue Name", "IssueName", Unit.Parse("9cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("8.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("State", "State", Unit.Parse("1.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("WireInfo", "WireInfo", Unit.Parse("21cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "GoodFaithOperationView", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ExportResult();
      }
    }

    public BankerViewModel FetchInitializedViewModel(string view)
    {
      try
      {
        return new BankerViewModel()
        {
          IssueNumber = "",
          IssueName = "",
          Issuer = "",
          GoodFaithAmount = new Decimal?(0M),
          GoodFaithDate = new DateTime?(),
          State = "",
          TypeOfOffering = "",
          WireInfo = "",
          IsGoodFaithViewReadOnly = !this.ReturnUpdateIssueGoodFaithWireInfo(view)
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        BankerViewModel bankerViewModel = new BankerViewModel();
        bankerViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return bankerViewModel;
      }
    }

    private bool ReturnUpdateIssueGoodFaithWireInfo(string view)
    {
      bool flag = false;
      if (view.Equals("banker"))
        flag = this.HasIndependentPermission("Send Good Faith Email", "SendEmail");
      else if (view.Equals("ops"))
        flag = this.HasIndependentPermission("Good Faith Wire Info", "Edit");
      return flag;
    }

    private string ConvertDateFormat(string value)
    {
      DateTime result;
      return !string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result) ? result.ToString("MM/dd/yyyy") : "";
    }
  }
}
