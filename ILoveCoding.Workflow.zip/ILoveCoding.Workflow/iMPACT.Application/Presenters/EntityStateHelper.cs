﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.EntityStateHelper
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public class EntityStateHelper
  {
    public static List<TFromToState> GetTransitionFromToState<TFromToState, TStatus, TEntity>(
      List<TStatus> oldStatusList,
      TransitionResult<TStatus, TEntity> transitionResult)
    {
      List<TFromToState> fromToStateList = new List<TFromToState>();
      IState<TStatus, TEntity> actionState = transitionResult.ActionState;
      IEnumerable<IState<TStatus, TEntity>> intermediateStates = transitionResult.IntermediateStates;
      IEnumerable<IState<TStatus, TEntity>> resultingStates = transitionResult.ResultingStates;
      List<TStatus> first = new List<TStatus>();
      foreach (IState<TStatus, TEntity> state in resultingStates)
        first.Add(state.Key);
      List<TStatus> list = oldStatusList.Except<TStatus>((IEnumerable<TStatus>) first).ToList<TStatus>();
      List<TStatus> filteredToState = first.Except<TStatus>((IEnumerable<TStatus>) oldStatusList).ToList<TStatus>();
      if (intermediateStates.Count<IState<TStatus, TEntity>>() > 0 && actionState != null)
        list.Remove(actionState.Key);
      foreach (IState<TStatus, TEntity> state in intermediateStates)
      {
        if (actionState != null)
        {
          TFromToState instance = (TFromToState) Activator.CreateInstance(typeof (TFromToState), (object) actionState.Key, (object) state.Key);
          fromToStateList.Add(instance);
          list.Add(state.Key);
        }
      }
      foreach (KeyValuePair<TStatus, TStatus> keyValuePair in list.SelectMany<TStatus, TStatus, KeyValuePair<TStatus, TStatus>>((Func<TStatus, IEnumerable<TStatus>>) (fromStatus => (IEnumerable<TStatus>) filteredToState), (Func<TStatus, TStatus, KeyValuePair<TStatus, TStatus>>) ((fromStatus, toStatus) => new KeyValuePair<TStatus, TStatus>(fromStatus, toStatus))))
      {
        TFromToState instance = (TFromToState) Activator.CreateInstance(typeof (TFromToState), (object) keyValuePair.Key, (object) keyValuePair.Value);
        fromToStateList.Add(instance);
      }
      return fromToStateList;
    }

    public static List<TFromToState> GetAuditFromToState<TFromToState, TStatus, TEntity>(
      List<TStatus> oldStatusList,
      TransitionResult<TStatus, TEntity> transitionResult)
    {
      List<TFromToState> fromToStateList = new List<TFromToState>();
      IEnumerable<IState<TStatus, TEntity>> resultingStates = transitionResult.ResultingStates;
      List<TStatus> resultingStatusList = new List<TStatus>();
      foreach (IState<TStatus, TEntity> state in resultingStates)
        resultingStatusList.Add(state.Key);
      foreach (KeyValuePair<TStatus, TStatus> keyValuePair in oldStatusList.SelectMany<TStatus, TStatus, KeyValuePair<TStatus, TStatus>>((Func<TStatus, IEnumerable<TStatus>>) (fromStatus => (IEnumerable<TStatus>) resultingStatusList), (Func<TStatus, TStatus, KeyValuePair<TStatus, TStatus>>) ((fromStatus, toStatus) => new KeyValuePair<TStatus, TStatus>(fromStatus, toStatus))))
      {
        TFromToState instance = (TFromToState) Activator.CreateInstance(typeof (TFromToState), (object) keyValuePair.Key, (object) keyValuePair.Value);
        fromToStateList.Add(instance);
      }
      return fromToStateList;
    }

    public static bool IsStatusListEqual(List<long> lstNew, List<long> lstOld) => lstNew.Count == lstOld.Count && lstNew.All<long>((Func<long, bool>) (statusID => lstOld.Contains(statusID))) && lstOld.All<long>((Func<long, bool>) (statusID1 => lstNew.Contains(statusID1)));

    public static bool IsStatusListEqual(
      List<IssueEnums.IssueStatus> oldStatus,
      List<IssueEnums.IssueStatus> newStatus)
    {
      return oldStatus.All<IssueEnums.IssueStatus>((Func<IssueEnums.IssueStatus, bool>) (item => newStatus.Contains(item))) && newStatus.All<IssueEnums.IssueStatus>((Func<IssueEnums.IssueStatus, bool>) (item => oldStatus.Contains(item)));
    }

    public static bool IsStatusListEqual(
      List<CompetitiveIssueEnums.IssueStatus> oldStatus,
      List<CompetitiveIssueEnums.IssueStatus> newStatus)
    {
      return oldStatus.All<CompetitiveIssueEnums.IssueStatus>((Func<CompetitiveIssueEnums.IssueStatus, bool>) (item => newStatus.Contains(item))) && newStatus.All<CompetitiveIssueEnums.IssueStatus>((Func<CompetitiveIssueEnums.IssueStatus, bool>) (item => oldStatus.Contains(item)));
    }

    public static bool IsStatusListEqual(
      List<IssueEnums.IssueG37FormStatus> oldStatus,
      List<IssueEnums.IssueG37FormStatus> newStatus)
    {
      return oldStatus.All<IssueEnums.IssueG37FormStatus>((Func<IssueEnums.IssueG37FormStatus, bool>) (item => newStatus.Contains(item))) && newStatus.All<IssueEnums.IssueG37FormStatus>((Func<IssueEnums.IssueG37FormStatus, bool>) (item => oldStatus.Contains(item)));
    }

    public static bool IsStatusListEqual(
      List<CompetitiveIssueEnums.IssueG37FormStatus> oldStatus,
      List<CompetitiveIssueEnums.IssueG37FormStatus> newStatus)
    {
      return oldStatus.All<CompetitiveIssueEnums.IssueG37FormStatus>((Func<CompetitiveIssueEnums.IssueG37FormStatus, bool>) (item => newStatus.Contains(item))) && newStatus.All<CompetitiveIssueEnums.IssueG37FormStatus>((Func<CompetitiveIssueEnums.IssueG37FormStatus, bool>) (item => oldStatus.Contains(item)));
    }
  }
}
