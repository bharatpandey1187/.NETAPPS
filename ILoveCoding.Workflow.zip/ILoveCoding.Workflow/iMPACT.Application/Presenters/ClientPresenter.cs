﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ClientPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (ClientPresenter))]
  public class ClientPresenter : PresenterBase
  {
    [Dependency]
    public IClientRepository ClientRepository { get; set; }

    [Dependency]
    public ReferenceDataPresenter Presenter { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IAppTransactionDocSetRepository AppTransactionDocSetRepository { get; set; }

    [Dependency]
    public IEntityDocSetTypeRepository EntityDocSetTypeRepository { get; set; }

    [Dependency]
    public UploadDocumentPresenter UploadDocPresenter { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    public ClientViewModelContainer GetAllClient()
    {
      try
      {
        ClientViewModelContainer viewModelContainer = new ClientViewModelContainer();
        viewModelContainer.Clients = this.ClientRepository.FetchAll().Select<Client, ClientViewModel>((Func<Client, ClientViewModel>) (x => new ClientViewModel(x))).ToList<ClientViewModel>();
        viewModelContainer.MeetingTypes = this.Presenter.GetItemsByKey("Meeting Type").ToList<LookupItemViewModel>();
        viewModelContainer.States = this.Presenter.GetItemsByKey("State").ToList<LookupItemViewModel>();
        viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Client", "Edit");
        if (!viewModelContainer.IsViewOnly)
          viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Client", "Add");
        viewModelContainer.IsAddClient = !this.HasIndependentPermission("Client", "Add");
        viewModelContainer.IsEditClient = !this.HasIndependentPermission("Client", "Edit");
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ClientViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public ClientViewModel GetClientById(long clientId)
    {
      try
      {
        AppConfig appConfig = this.AppConfigRepository.FetchByKey(52);
        bool flag = false;
        if (appConfig != null && !string.IsNullOrEmpty(appConfig.Value) && appConfig.Value.Trim() == "0")
          flag = this.CheckClientIdUsedInEntity(clientId);
        ClientViewModel clientViewModel = new ClientViewModel(this.ClientRepository.FetchByKey(clientId));
        clientViewModel.IsViewOnly = clientViewModel.ViewClientCRM = clientViewModel.ViewClientAlias = !this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.ClientEditPermissionSet);
        clientViewModel.IsAddClient = !this.HasIndependentPermission("Client", "Add");
        clientViewModel.IsEditClient = !this.HasIndependentPermission("Client", "Edit");
        clientViewModel.IsAddContact = !this.HasIndependentPermission("Client Contact", "Add");
        clientViewModel.IsEditContact = !this.HasIndependentPermission("Client Contact", "Edit");
        clientViewModel.CanUploadClientDocuments = !this.HasIndependentPermission("Client Documents", "Upload");
        clientViewModel.IsClientIdUsedInEntity = flag;
        clientViewModel.ViewClientDocuments = true;
        clientViewModel.CanEditFidOneDetails = clientViewModel.IsViewOnly;
        if (!clientViewModel.CanEditFidOneDetails)
          clientViewModel.CanEditFidOneDetails = clientViewModel.IsEditClient;
        if (!clientViewModel.CanEditFidOneDetails)
          clientViewModel.CanEditFidOneDetails = !this.HasIndependentPermission("FID1 Client", "View") && !this.HasIndependentPermission("FID1 Client", "Edit");
        IEnumerable<LookupItemMappings> source = this.FetchLookupItemsByLookupKeys();
        clientViewModel.MAExemptions = source.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MA Exemption")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        clientViewModel.SecurityTypes = source.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Security Type (General)")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        clientViewModel.ContactTitle = source.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Contact Title")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        clientViewModel.AdvisoryAgentList = source.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Advisory Agent Type")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        return clientViewModel;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ClientViewModel("An error occurred while fetching the data.");
      }
    }

    public void PerformSharePointDocumentSetOperations(long clientId, Client Client)
    {
      try
      {
        Hashtable properties = this.PopulateProperties(clientId, Client);
        List<AppTransactionDocSet> transactionDocSetList = this.AppTransactionDocSetRepository.FetchByAppTransactionID(clientId);
        List<EntityDocSetType> entityDocSetTypeList = this.EntityDocSetTypeRepository.FetchEntityDocSetTypeByEntityID(-1L);
        string libLocation = this.AppTransactionDocSetRepository.FetchLibraryURLByEntityTypeID(-1L);
        List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
        foreach (EntityDocSetType entityDocSetType in entityDocSetTypeList)
        {
          EntityDocSetType docSetType = entityDocSetType;
          List<DocSetPermission> docSetPermissions = (List<DocSetPermission>) null;
          ClientPresenter.GetRepositoryLevelProperties_New(properties, docSetType);
          if (!transactionDocSetList.Exists((Predicate<AppTransactionDocSet>) (x =>
          {
            long? entityDocSetTypeId1 = x.EntityDocSetTypeID;
            long entityDocSetTypeId2 = docSetType.EntityDocSetTypeID;
            return entityDocSetTypeId1.GetValueOrDefault() == entityDocSetTypeId2 && entityDocSetTypeId1.HasValue;
          })))
            this.CreateIssueDocumentSets(clientId, properties, libLocation, docSetType, docSetPermissions);
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
      }
    }

    private void CreateIssueDocumentSets(
      long clientId,
      Hashtable properties,
      string libLocation,
      EntityDocSetType docSetType,
      List<DocSetPermission> docSetPermissions)
    {
      DocSetInfo docSet = this.UploadDocPresenter.CreateDocSet(new DocSetInfo()
      {
        AppTransactionId = clientId,
        DocSetName = docSetType.DocSetName,
        EntityType = -1.ToString(),
        URL = libLocation
      }, docSetPermissions, properties);
      this.SaveAppTransactionDetails(new AppTransactionDocSet()
      {
        EntityID = clientId,
        EntityDocSetTypeID = new long?(docSetType.EntityDocSetTypeID),
        DocSetTypeValue = docSetType.DocSetName,
        URL = libLocation,
        DocSetID = Convert.ToInt32(docSet.DocSetId)
      });
    }

    private void SaveAppTransactionDetails(AppTransactionDocSet appTransactionDocSet)
    {
      try
      {
        this.AppTransactionDocSetRepository.Save(appTransactionDocSet);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    private static void GetRepositoryLevelProperties_New(
      Hashtable properties,
      EntityDocSetType docSetType)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) docSetType.DocSetName;
      else
        properties.Add((object) "Title", (object) docSetType.DocSetName);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) docSetType.EntityDocSetTypeID;
      else
        properties.Add((object) "iDocSetType", (object) docSetType.EntityDocSetTypeID);
    }

    private Hashtable PopulateProperties(long clientId, Client client) => new Hashtable()
    {
      {
        (object) "iCreateDate",
        (object) (client.CreatedOn == DateTime.MinValue.Date ? DateTime.Now : client.CreatedOn)
      }
    };

    private IEnumerable<LookupItemMappings> FetchLookupItemsByLookupKeys() => this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetClientLookupKeys());

    private string[] GetClientLookupKeys() => new string[4]
    {
      "MA Exemption",
      "State",
      "Security Type (General)",
      "Contact Title"
    };

    public SaveResult Save(ClientViewModel theClient)
    {
      try
      {
        List<ClientCUSIPPrefixViewModel> list = theClient.ClientCUSIPPrefix.Where<ClientCUSIPPrefixViewModel>((Func<ClientCUSIPPrefixViewModel, bool>) (m => m.IsBaseCUSIP)).ToList<ClientCUSIPPrefixViewModel>();
        SaveResult saveResult = theClient.IsClientContactAdded ? new SaveResult() : theClient.Validate<ClientViewModel>();
        if (list.Count<ClientCUSIPPrefixViewModel>() <= 1)
        {
          this.GetSafeObject<ClientViewModel>(theClient);
          long clientId = theClient.ClientID;
          saveResult.Id = clientId;
          if (theClient.ClientContacts != null)
          {
            List<SaveResult> saveResultList = this.ValidateContacts(theClient.ClientContacts);
            if (saveResultList.Count > 0)
              saveResult.Errors.Add("Contacts", (object) saveResultList);
          }
          if (theClient.ClientCUSIPPrefix != null)
          {
            List<SaveResult> saveResultList = this.ValidateClientCUSIPPrefix(theClient.ClientCUSIPPrefix);
            if (saveResultList.Count > 0)
              saveResult.Errors.Add("CUSIPPrefix", (object) saveResultList);
          }
          if (theClient.ClientAlias != null)
          {
            List<SaveResult> saveResultList = this.ValidateClientAlias(theClient.ClientAlias);
            if (saveResultList.Count > 0)
              saveResult.Errors.Add("ContactAlias", (object) saveResultList);
          }
          if (theClient.ClientCRM != null)
          {
            List<SaveResult> saveResultList = this.ValidateClientCRM(theClient.ClientCRM);
            if (saveResultList.Count > 0)
              saveResult.Errors.Add("ClientCRM", (object) saveResultList);
          }
          if (theClient.ClientAddress != null)
          {
            List<SaveResult> saveResultList = this.ValidateClientAddress(theClient.ClientAddress);
            if (saveResultList.Count > 0)
              saveResult.Errors.Add("ClientAddress", (object) saveResultList);
          }
          if (saveResult.IsSuccessful)
          {
            using (TransactionScope transactionScope = new TransactionScope())
            {
              long num = this.ClientRepository.Save(theClient.GetClientDetail(theClient));
              saveResult.Id = num;
              if (num == -100L)
                saveResult.Errors.Add("Client Name", (object) "Client name already exists.");
              if (num == -200L)
                saveResult.Errors.Add("Contact Email", (object) "Contacts cannot have same email address.");
              if (saveResult.IsSuccessful)
                transactionScope.Complete();
            }
          }
        }
        else
          saveResult.Errors.Add("Client CUSIP", (object) "Only one base CUSIP can be added in Client.");
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult UpdateContactDetails(ClientDetailViewModel clientDetailViewModel)
    {
      try
      {
        this.GetSafeObject<ClientDetailViewModel>(clientDetailViewModel);
        long clientContactId = clientDetailViewModel.ClientContactID;
        SaveResult saveResult = clientDetailViewModel.Validate<ClientDetailViewModel>();
        saveResult.Id = clientContactId;
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.ClientRepository.UpdateContactDetails(clientDetailViewModel.GetClientContact());
            saveResult.Id = num;
            if (num == -200L)
              saveResult.Errors.Add("Contact Email", (object) "Contacts cannot have same email address.");
            transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public List<KeyPair> GetFullLegalNames(string fullLegalName, bool showAll)
    {
      try
      {
        List<KeyPair> keyPairList = new List<KeyPair>();
        using (IDataReader dataReader = this.ClientRepository.FetchFullLegalNames(fullLegalName, showAll))
        {
          if (dataReader != null)
          {
            IRowMapper<KeyPair> rowMapper = MapBuilder<KeyPair>.MapAllProperties().Map<string>((Expression<Func<KeyPair, string>>) (x => x.Key)).ToColumn("ClientID").Map<string>((Expression<Func<KeyPair, string>>) (x => x.Value)).ToColumn("FullLegalName").Build();
            while (dataReader.Read())
              keyPairList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return keyPairList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<KeyPair>();
      }
    }

    public List<IssuerState> GetFullLegalWithStateNames(
      string fullLegalName,
      bool showAll)
    {
      try
      {
        List<IssuerState> issuerStateList = new List<IssuerState>();
        using (IDataReader dataReader = this.ClientRepository.FetchFullLegalWithStateNames(fullLegalName, showAll))
        {
          if (dataReader != null)
          {
            IRowMapper<IssuerState> rowMapper = MapBuilder<IssuerState>.MapAllProperties().Map<string>((Expression<Func<IssuerState, string>>) (x => x.Key)).ToColumn("ClientID").Map<string>((Expression<Func<IssuerState, string>>) (x => x.Value)).ToColumn("FullLegalName").Map<string>((Expression<Func<IssuerState, string>>) (x => x.StateID)).ToColumn("StateId").Build();
            while (dataReader.Read())
              issuerStateList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return issuerStateList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<IssuerState>();
      }
    }

    public List<KeyPair> GetClientForAlias(string clientFullName, long clientId)
    {
      try
      {
        List<KeyPair> keyPairList = new List<KeyPair>();
        using (IDataReader clientForAlias = this.ClientRepository.GetClientForAlias(clientFullName, clientId))
        {
          if (clientForAlias != null)
          {
            IRowMapper<KeyPair> rowMapper = MapBuilder<KeyPair>.MapAllProperties().Map<string>((Expression<Func<KeyPair, string>>) (x => x.Key)).ToColumn("ClientID").Map<string>((Expression<Func<KeyPair, string>>) (x => x.Value)).ToColumn("FullLegalName").Build();
            while (clientForAlias.Read())
              keyPairList.Add(rowMapper.MapRow((IDataRecord) clientForAlias));
          }
        }
        return keyPairList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<KeyPair>();
      }
    }

    private List<SaveResult> ValidateContacts(
      List<ClientDetailViewModel> clientDetailViewModel)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (ClientDetailViewModel clientDetailViewModel1 in clientDetailViewModel)
      {
        SaveResult saveResult = clientDetailViewModel1.Validate<ClientDetailViewModel>();
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = clientDetailViewModel1.ClientContactID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    private List<SaveResult> ValidateClientCUSIPPrefix(
      List<ClientCUSIPPrefixViewModel> clienCUSIPPrefixViewModel)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (ClientCUSIPPrefixViewModel cusipPrefixViewModel in clienCUSIPPrefixViewModel)
      {
        SaveResult saveResult = cusipPrefixViewModel.Validate<ClientCUSIPPrefixViewModel>();
        long? securityType = cusipPrefixViewModel.SecurityType;
        long num = 0;
        if ((securityType.GetValueOrDefault() == num ? (securityType.HasValue ? 1 : 0) : 0) != 0)
          saveResult.Errors.Add("CUSIPPrefix", (object) ("Please select Security Type for CUSIP " + cusipPrefixViewModel.CUSIPPrefix + "."));
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = cusipPrefixViewModel.ClientID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    private List<SaveResult> ValidateClientAlias(
      List<ClientAliasViewModel> clienAliasViewModel)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (ClientAliasViewModel clientAliasViewModel in clienAliasViewModel)
      {
        SaveResult saveResult = clientAliasViewModel.Validate<ClientAliasViewModel>();
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = clientAliasViewModel.ClientID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    private List<SaveResult> ValidateClientCRM(
      List<ClientCRMViewModel> clienCRMViewModel)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (ClientCRMViewModel clientCrmViewModel in clienCRMViewModel)
      {
        SaveResult saveResult = clientCrmViewModel.Validate<ClientCRMViewModel>();
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = clientCrmViewModel.ClientID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    private List<SaveResult> ValidateClientAddress(
      List<ClientAddressViewModel> clienAddressViewModel)
    {
      List<SaveResult> saveResultList = new List<SaveResult>();
      foreach (ClientAddressViewModel addressViewModel in clienAddressViewModel)
      {
        SaveResult saveResult = addressViewModel.Validate<ClientAddressViewModel>();
        if (!saveResult.IsSuccessful)
        {
          saveResult.Id = addressViewModel.ClientID;
          saveResultList.Add(saveResult);
        }
      }
      return saveResultList;
    }

    public bool CheckClientIdUsedInEntity(long clientId) => this.ClientRepository.CheckClientIdUsedInEntity(clientId);

    public bool IsClientAddressUsed(long AddressID) => this.ClientRepository.IsClientAddressUsed(AddressID);
  }
}
