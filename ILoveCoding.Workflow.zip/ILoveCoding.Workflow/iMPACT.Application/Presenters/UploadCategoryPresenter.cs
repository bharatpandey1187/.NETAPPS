﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.UploadCategoryPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (UploadCategoryPresenter))]
  public class UploadCategoryPresenter : PresenterBase
  {
    [Dependency]
    public IUploadCategoryRepository UploadCategoryRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public UploadCategoryViewModelContainer GetAllUploadCategories()
    {
      try
      {
        return new UploadCategoryViewModelContainer()
        {
          UploadCategories = this.UploadCategoryRepository.FetchAll().Select<IrisSoftware.iMPACT.Data.UploadCategory, UploadCategoryViewModel>((Func<IrisSoftware.iMPACT.Data.UploadCategory, UploadCategoryViewModel>) (x => new UploadCategoryViewModel(x))).ToList<UploadCategoryViewModel>(),
          IsViewOnly = !this.HasIndependentPermission("Upload Category", "Edit")
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        UploadCategoryViewModelContainer viewModelContainer = new UploadCategoryViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public UploadCategoryViewModelContainer GetUploadCategoriesByEntity(
      long entityID)
    {
      try
      {
        return new UploadCategoryViewModelContainer()
        {
          UploadCategories = this.UploadCategoryRepository.FetchAll().ToList<IrisSoftware.iMPACT.Data.UploadCategory>().Where<IrisSoftware.iMPACT.Data.UploadCategory>((Func<IrisSoftware.iMPACT.Data.UploadCategory, bool>) (x => x.EntityTypeID == entityID)).Select<IrisSoftware.iMPACT.Data.UploadCategory, UploadCategoryViewModel>((Func<IrisSoftware.iMPACT.Data.UploadCategory, UploadCategoryViewModel>) (x => new UploadCategoryViewModel(x))).ToList<UploadCategoryViewModel>(),
          IsViewOnly = !this.HasIndependentPermission("Upload Category", "Edit")
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        UploadCategoryViewModelContainer viewModelContainer = new UploadCategoryViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public List<UploadDocTypeViewModel> GetUploadDocTypesByUploadCategoryID(
      long uploadCategoryId,
      int isAll)
    {
      try
      {
        return this.UploadCategoryRepository.FetchByUploadCategoryID(uploadCategoryId, isAll).ToList<IrisSoftware.iMPACT.Data.UploadDocType>().Select<IrisSoftware.iMPACT.Data.UploadDocType, UploadDocTypeViewModel>((Func<IrisSoftware.iMPACT.Data.UploadDocType, UploadDocTypeViewModel>) (x => new UploadDocTypeViewModel(x))).ToList<UploadDocTypeViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<UploadDocTypeViewModel>();
      }
    }

    public List<UploadDocTypeViewModel> GetAllUploadDocTypesByUploadCategoryID(
      long uploadCategoryId,
      int isAll)
    {
      try
      {
        return this.UploadCategoryRepository.FetchByUploadCategoryID(uploadCategoryId, isAll).ToList<IrisSoftware.iMPACT.Data.UploadDocType>().Select<IrisSoftware.iMPACT.Data.UploadDocType, UploadDocTypeViewModel>((Func<IrisSoftware.iMPACT.Data.UploadDocType, UploadDocTypeViewModel>) (x => new UploadDocTypeViewModel(x))).ToList<UploadDocTypeViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<UploadDocTypeViewModel>();
      }
    }

    public SaveResult SaveUploadDocTypes(
      List<UploadDocTypeViewModel> uploadDocTypesViewModel)
    {
      try
      {
        this.GetSafeObject<UploadDocTypeViewModel>(uploadDocTypesViewModel);
        List<SaveResult> saveResultList = new List<SaveResult>();
        foreach (UploadDocTypeViewModel docTypeViewModel in uploadDocTypesViewModel)
        {
          SaveResult saveResult = docTypeViewModel.Validate<UploadDocTypeViewModel>();
          if (!saveResult.IsSuccessful)
          {
            saveResult.Id = docTypeViewModel.UploadDocTypeID;
            saveResultList.Add(saveResult);
          }
        }
        if (saveResultList.Count > 0)
          return new SaveResult()
          {
            Errors = {
              {
                "uploadDocTypes",
                (object) saveResultList
              }
            }
          };
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.UploadCategoryRepository.SaveUploadDocTypes(uploadDocTypesViewModel.Select<UploadDocTypeViewModel, IrisSoftware.iMPACT.Data.UploadDocType>((Func<UploadDocTypeViewModel, IrisSoftware.iMPACT.Data.UploadDocType>) (x => x.GetUploadDocType())).ToList<IrisSoftware.iMPACT.Data.UploadDocType>());
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public LookupItemViewModelContainer FetchAllEntities()
    {
      try
      {
        return new LookupItemViewModelContainer()
        {
          IsViewOnly = !this.HasIndependentPermission("Reference Data", "Edit"),
          LookupItems = this.LookupRepository.FetchByLookupKey("Entity").Select<LookupItem, LookupItemViewModel>((Func<LookupItem, LookupItemViewModel>) (x => new LookupItemViewModel(x))).ToList<LookupItemViewModel>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        LookupItemViewModelContainer viewModelContainer = new LookupItemViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public SaveResult SaveUploadCategory(UploadCategoryViewModel uploadCategoryViewModel)
    {
      try
      {
        this.GetSafeObject<UploadCategoryViewModel>(uploadCategoryViewModel);
        SaveResult saveResult = uploadCategoryViewModel.Validate<UploadCategoryViewModel>();
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            if (this.UploadCategoryRepository.Save(uploadCategoryViewModel.GetDocumentCategory(uploadCategoryViewModel)) == -100L)
              saveResult.Errors.Add("Category name", (object) "Category Name has already been added.");
            transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }
  }
}
