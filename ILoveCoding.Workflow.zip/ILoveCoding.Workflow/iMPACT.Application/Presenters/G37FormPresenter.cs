﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.G37FormPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (G37FormPresenter))]
  public class G37FormPresenter : PresenterBase
  {
    private const string G37FormEntity = "Issue.G37Form";
    private const string G37FormCreated = "{0} Created";
    private const string G37FormUpdated = "{0} Updated";
    private const string G37FormStatusChanged = "G-37 Form Status changed from {1} to {2}";

    [Dependency]
    public IIssueRepository IssueRepository { get; set; }

    [Dependency]
    public IEventBus EventBus { get; set; }

    [Dependency]
    public IIssueG37FormWorkflowFactory WorkflowFactory { get; set; }

    [Dependency]
    public IAuditTrailRepository AuditTrailRepository { get; set; }

    public G37FormViewModel FetchByIssueKey(long issueId)
    {
      try
      {
        G37FormViewModel g37FormViewModel = new G37FormViewModel();
        using (IDataReader reader = this.IssueRepository.FetchG37FormViewByIssueKey(issueId, "Syndicate Member Role"))
        {
          if (reader.Read())
          {
            g37FormViewModel = MapBuilder<G37FormViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<G37FormViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<G37FormViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<G37FormViewModel, bool>>) (x => x.IsViewOnly)).DoNotMap<bool>((Expression<Func<G37FormViewModel, bool>>) (x => x.CanSaveG37Form)).DoNotMap<bool>((Expression<Func<G37FormViewModel, bool>>) (x => x.CanSubmitG37Form)).DoNotMap<string>((Expression<Func<G37FormViewModel, string>>) (x => x.ErrorMessage)).Build().MapRow((IDataRecord) reader);
            if (reader.NextResult())
              g37FormViewModel.SyndicateMembers = this.GetSyndicateMembers(reader);
            if (reader.NextResult())
              g37FormViewModel.WorkflowStateTransitions = this.GetStateTransitions(reader);
          }
        }
        if (g37FormViewModel.AppTransactionID > 0L)
        {
          if (!this.HasUIPermissionForEntity(0L, g37FormViewModel.AppTransactionID, "Issue G-37 Form", "View"))
            return new G37FormViewModel("You are not authorized to access this resource.");
        }
        else if (!this.HasEntityPermission(-34L, "Issue G-37 Form", "Create"))
          return new G37FormViewModel("You are not authorized to access this resource.");
        if (!string.IsNullOrEmpty(g37FormViewModel.CommaSeperatedStateID))
          g37FormViewModel.G37status = ((IEnumerable<string>) g37FormViewModel.CommaSeperatedStateID.Split(new string[1]
          {
            ","
          }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        else
          g37FormViewModel.G37status = new List<long>();
        if (!string.IsNullOrEmpty(g37FormViewModel.CommaSeperatedIssueStateID))
          g37FormViewModel.Issuestatus = ((IEnumerable<string>) g37FormViewModel.CommaSeperatedIssueStateID.Split(new string[1]
          {
            ","
          }, StringSplitOptions.RemoveEmptyEntries)).Select<string, long>(new Func<string, long>(long.Parse)).ToList<long>();
        else
          g37FormViewModel.Issuestatus = new List<long>();
        G37FormPresenter.SetAttributes(g37FormViewModel);
        this.SetPermissions(g37FormViewModel, issueId);
        return g37FormViewModel;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.G37, ex.ToString());
        return new G37FormViewModel("An error occurred while fetching the data.");
      }
    }

    public SaveResult Save(G37FormViewModel theG37Form, string g37Action)
    {
      try
      {
        this.GetSafeObject<G37FormViewModel>(theG37Form);
        G37FormViewModel oldG37Form = new G37FormViewModel();
        IWorkflow<IssueEnums.IssueG37FormStatus, G37Form> workflow = this.WorkflowFactory.GetWorkflow("");
        g37Action = g37Action.Trim();
        IrisSoftware.iMPACT.Core.Security.Permission[] array1 = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, 0L, theG37Form.AppTransactionID)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "Issue G-37 Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
        string[] array2 = workflow.GetAllowedActions((IEnumerable<IssueEnums.IssueG37FormStatus>) theG37Form.G37status.ConvertAll<IssueEnums.IssueG37FormStatus>((Converter<long, IssueEnums.IssueG37FormStatus>) (s => (IssueEnums.IssueG37FormStatus) s))).ToArray<string>();
        this.GetMatchingPermission(array1, array2);
        string[] matchingPermission = this.GetMatchingPermission(this.AuthorizationService.GetPermissions(this.AppUser, 0L, theG37Form.AppTransactionID), array2);
        if (!string.IsNullOrEmpty(g37Action) && Array.IndexOf<string>(matchingPermission, g37Action) == -1)
          return SaveResult.Failure("You are not authorized to access this resource.");
        TransitionResult<IssueEnums.IssueG37FormStatus, G37Form> transitionResult = (TransitionResult<IssueEnums.IssueG37FormStatus, G37Form>) null;
        List<IssueEnums.IssueG37FormStatus> issueG37FormStatusList = new List<IssueEnums.IssueG37FormStatus>();
        issueG37FormStatusList.Add(IssueEnums.IssueG37FormStatus.Open);
        SaveResult saveResult = theG37Form.Validate<G37FormViewModel>();
        if (theG37Form.AppTransactionID > 0L)
        {
          oldG37Form = this.FetchByIssueKey(theG37Form.ParentAppTransactionID);
          issueG37FormStatusList.Clear();
          issueG37FormStatusList = oldG37Form.G37status.ConvertAll<IssueEnums.IssueG37FormStatus>((Converter<long, IssueEnums.IssueG37FormStatus>) (s => (IssueEnums.IssueG37FormStatus) s));
          if (oldG37Form.FirmRole == -16)
          {
            G37FormViewModel g37FormViewModel1 = theG37Form;
            G37FormViewModel g37FormViewModel2 = theG37Form;
            G37FormViewModel g37FormViewModel3 = theG37Form;
            G37FormViewModel g37FormViewModel4 = theG37Form;
            G37FormViewModel g37FormViewModel5 = theG37Form;
            Decimal? nullable1 = new Decimal?();
            Decimal? nullable2 = nullable1;
            g37FormViewModel5.MacFee = nullable2;
            Decimal? nullable3;
            Decimal? nullable4 = nullable3 = nullable1;
            g37FormViewModel4.IpreoFee = nullable3;
            Decimal? nullable5;
            Decimal? nullable6 = nullable5 = nullable4;
            g37FormViewModel3.InsuranceFee = nullable5;
            Decimal? nullable7;
            Decimal? nullable8 = nullable7 = nullable6;
            g37FormViewModel2.BondCounselFee = nullable7;
            Decimal? nullable9 = nullable8;
            g37FormViewModel1.CusipFee = nullable9;
          }
          else
            theG37Form.EsmtCheck = new Decimal?();
        }
        if (g37Action.Trim() == IssueG37FormAction.ReceivedByCompliance)
        {
          theG37Form.SetUpBy = this.AppUser.Name;
          theG37Form.SetUpDate = new DateTime?(DateTime.Now);
        }
        if (saveResult.IsSuccessful)
        {
          G37Form g37FormDetail = this.GetG37FormDetail(this.IssueRepository, theG37Form);
          g37FormDetail.Issue = this.IssueRepository.FetchByKey(theG37Form.ParentAppTransactionID);
          Dictionary<IssueEnums.IssueG37FormStatus, IssueEnums.IssueG37FormStatus> dictionary = (Dictionary<IssueEnums.IssueG37FormStatus, IssueEnums.IssueG37FormStatus>) null;
          if (theG37Form.AppTransactionID > 0L)
            dictionary = this.IssueRepository.FetchG37HistoryByAppTransactionID(theG37Form.AppTransactionID);
          if (workflow.TryHandle(g37FormDetail, (IEnumerable<IssueEnums.IssueG37FormStatus>) issueG37FormStatusList, g37Action, (IDictionary<IssueEnums.IssueG37FormStatus, IssueEnums.IssueG37FormStatus>) dictionary, out transitionResult))
          {
            Dictionary<int, int> history = (Dictionary<int, int>) null;
            if (transitionResult.History.Count > 0)
            {
              history = new Dictionary<int, int>();
              foreach (KeyValuePair<IssueEnums.IssueG37FormStatus, IState<IssueEnums.IssueG37FormStatus, G37Form>> keyValuePair in (IEnumerable<KeyValuePair<IssueEnums.IssueG37FormStatus, IState<IssueEnums.IssueG37FormStatus, G37Form>>>) transitionResult.History)
              {
                IssueEnums.IssueG37FormStatus key1 = keyValuePair.Key;
                IssueEnums.IssueG37FormStatus key2 = keyValuePair.Value.Key;
                history.Add((int) key1, (int) key2);
              }
            }
            List<IssueG37FormFromStateToState> fromStateToStateList1 = new List<IssueG37FormFromStateToState>();
            List<IssueG37FormFromStateToState> fromStateToStateList2 = new List<IssueG37FormFromStateToState>();
            List<int> transitionStateTracking = this.GetTransitionStateTracking(issueG37FormStatusList, transitionResult);
            List<IssueG37FormFromStateToState> fromToStateList;
            List<IssueG37FormFromStateToState> stateAuditTrailList;
            if (theG37Form.AppTransactionID > 0L)
            {
              fromToStateList = EntityStateHelper.GetTransitionFromToState<IssueG37FormFromStateToState, IssueEnums.IssueG37FormStatus, G37Form>(issueG37FormStatusList, transitionResult);
              stateAuditTrailList = EntityStateHelper.GetAuditFromToState<IssueG37FormFromStateToState, IssueEnums.IssueG37FormStatus, G37Form>(issueG37FormStatusList, transitionResult);
            }
            else
            {
              fromToStateList = new List<IssueG37FormFromStateToState>();
              foreach (IState<IssueEnums.IssueG37FormStatus, G37Form> resultingState in transitionResult.ResultingStates)
                fromToStateList.Add(new IssueG37FormFromStateToState(new IssueEnums.IssueG37FormStatus?(), resultingState.Key));
              stateAuditTrailList = new List<IssueG37FormFromStateToState>();
            }
            using (TransactionScope transactionScope = new TransactionScope())
            {
              g37FormDetail.G37Status = transitionResult.ResultingStates.Select<IState<IssueEnums.IssueG37FormStatus, G37Form>, long>((Func<IState<IssueEnums.IssueG37FormStatus, G37Form>, long>) (s => (long) s.Key)).ToList<long>();
              saveResult.Id = this.IssueRepository.Save(g37FormDetail, history, fromToStateList, stateAuditTrailList);
              transactionScope.Complete();
            }
            if (saveResult.IsSuccessful)
              this.PublishEvents(theG37Form, issueG37FormStatusList, oldG37Form, g37FormDetail, fromToStateList, transitionStateTracking, saveResult.Id);
          }
          else
          {
            foreach (ValidationResult error in (IEnumerable<ValidationResult>) transitionResult.Errors)
              saveResult.Errors.Add(error.Key, (object) error.Message);
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.G37, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private List<G37SyndicateMemberViewModel> GetSyndicateMembers(
      IDataReader reader)
    {
      List<G37SyndicateMemberViewModel> syndicateMemberViewModelList = new List<G37SyndicateMemberViewModel>();
      IRowMapper<G37SyndicateMemberViewModel> rowMapper = MapBuilder<G37SyndicateMemberViewModel>.MapAllProperties().Build();
      while (reader.Read())
        syndicateMemberViewModelList.Add(rowMapper.MapRow((IDataRecord) reader));
      return syndicateMemberViewModelList;
    }

    private List<AppTransactionStateTransition> GetStateTransitions(
      IDataReader reader)
    {
      List<AppTransactionStateTransition> transactionStateTransitionList = new List<AppTransactionStateTransition>();
      IRowMapper<AppTransactionStateTransition> rowMapper = MapBuilder<AppTransactionStateTransition>.MapAllProperties().Build();
      while (reader.Read())
        transactionStateTransitionList.Add(rowMapper.MapRow((IDataRecord) reader));
      return transactionStateTransitionList;
    }

    private G37Form GetG37FormDetail(
      IIssueRepository issueRepository,
      G37FormViewModel g37FormViewModel)
    {
      return new G37Form(issueRepository)
      {
        AppTransactionID = g37FormViewModel.AppTransactionID,
        ParentAppTransactionID = g37FormViewModel.ParentAppTransactionID,
        CompBid = g37FormViewModel.CompBid.ToUpper() == "YES",
        NegoBid = g37FormViewModel.NegoBid.ToUpper() == "YES",
        PrivatePlacementBid = g37FormViewModel.PrivatePlacementBid.ToUpper() == "YES",
        Cusip = g37FormViewModel.Cusip,
        Description = g37FormViewModel.Description,
        ParAmount = g37FormViewModel.ParAmount,
        ActualAwardDateTime = g37FormViewModel.ActualAwardDateTime,
        EsmtCheck = g37FormViewModel.EsmtCheck,
        AcctClosedDate = g37FormViewModel.AcctClosedDate,
        OrdRetail = g37FormViewModel.OrdRetail,
        OrdPreSale = g37FormViewModel.OrdPreSale,
        OrdNetDesig = g37FormViewModel.OrdNetDesig,
        OrdGroupNet = g37FormViewModel.OrdGroupNet,
        OrdMember = g37FormViewModel.OrdMember,
        Deviation = g37FormViewModel.Deviation,
        CusipFee = g37FormViewModel.CusipFee,
        IpreoFee = g37FormViewModel.IpreoFee,
        InsuranceFee = g37FormViewModel.InsuranceFee,
        MacFee = g37FormViewModel.MacFee,
        BondCounselFee = g37FormViewModel.BondCounselFee,
        SetUpBy = g37FormViewModel.SetUpBy,
        SetUpDate = g37FormViewModel.SetUpDate,
        G37Status = g37FormViewModel.G37status,
        Version = g37FormViewModel.Version
      };
    }

    private bool HasEditG37FormwhenOpen(
      IssueEnums.IssueG37FormStatus g37status,
      long appTransactionID)
    {
      return g37status == IssueEnums.IssueG37FormStatus.Open && this.HasUIPermissionForEntity(0L, appTransactionID, "Issue G-37 Form", "Edit");
    }

    private bool HasEditG37FormwhenSubmittedtoCompliance(
      IssueEnums.IssueG37FormStatus g37status,
      long appTransactionID)
    {
      return g37status == IssueEnums.IssueG37FormStatus.SubmittedToCompliance && this.HasUIPermissionForEntityStatus(appTransactionID, "Issue G-37 Form", "Edit");
    }

    private bool HasEditG37FormwhenReceivedByCompliance(
      IssueEnums.IssueG37FormStatus g37status,
      long appTransactionID)
    {
      return g37status == IssueEnums.IssueG37FormStatus.ReceivedByCompliance && this.HasUIPermissionForEntityStatus(appTransactionID, "Issue G-37 Form", "Edit");
    }

    private void SetPermissions(G37FormViewModel g37FormViewModel, long issueId)
    {
      IWorkflow<IssueEnums.IssueG37FormStatus, G37Form> workflow = this.WorkflowFactory.GetWorkflow("");
      IrisSoftware.iMPACT.Core.Security.Permission[] array1 = ((IEnumerable<IrisSoftware.iMPACT.Core.Security.Permission>) this.AuthorizationService.GetPermissions(this.AppUser, 0L, g37FormViewModel.AppTransactionID)).Where<IrisSoftware.iMPACT.Core.Security.Permission>((Func<IrisSoftware.iMPACT.Core.Security.Permission, bool>) (p => p.UIName == "Issue G-37 Action" && p.EntityPermission == "Edit" && !p.StateID.HasValue)).ToArray<IrisSoftware.iMPACT.Core.Security.Permission>();
      List<IssueEnums.IssueG37FormStatus> issueG37FormStatusList = g37FormViewModel.G37status.ConvertAll<IssueEnums.IssueG37FormStatus>((Converter<long, IssueEnums.IssueG37FormStatus>) (s => (IssueEnums.IssueG37FormStatus) s));
      string[] array2 = workflow.GetAllowedActions((IEnumerable<IssueEnums.IssueG37FormStatus>) issueG37FormStatusList).ToArray<string>();
      g37FormViewModel.Actions = this.GetMatchingPermission(array1, array2);
      List<long> statusList1 = g37FormViewModel.G37status.ConvertAll<long>((Converter<long, long>) (s => s));
      List<long> statusList2 = g37FormViewModel.Issuestatus.ConvertAll<long>((Converter<long, long>) (s => s));
      g37FormViewModel.CanSaveG37Form = this.IsUIEditable(issueId, "Issue Detail", statusList2);
      this.FlushEntitySecurityPermissionAppTransIDStatusID();
      g37FormViewModel.CanSaveG37Form = g37FormViewModel.CanSaveG37Form && this.IsUIEditable(g37FormViewModel.AppTransactionID, "Issue G-37 Form", statusList1);
      g37FormViewModel.IsViewOnly = !g37FormViewModel.CanSaveG37Form;
      g37FormViewModel.CanSubmitG37Form = g37FormViewModel.CanSaveG37Form;
    }

    private static void SetAttributes(G37FormViewModel g37FormViewModel)
    {
      if (g37FormViewModel.ParAmount.HasValue)
      {
        Decimal? nullable1;
        Decimal num1;
        if (!g37FormViewModel.FirmLiabilityPerc.HasValue)
        {
          num1 = 100M;
        }
        else
        {
          nullable1 = g37FormViewModel.FirmLiabilityPerc;
          num1 = nullable1.Value;
        }
        Decimal num2 = num1;
        G37FormViewModel g37FormViewModel1 = g37FormViewModel;
        nullable1 = g37FormViewModel.ParAmount;
        Decimal? nullable2 = new Decimal?(nullable1.Value * num2 / 100M);
        g37FormViewModel1.ParAmount = nullable2;
      }
      G37FormViewModel g37FormViewModel2 = g37FormViewModel;
      string compBid = g37FormViewModel.CompBid;
      int num = -55;
      string str1 = num.ToString();
      string str2 = compBid == str1 ? "Yes" : "";
      g37FormViewModel2.CompBid = str2;
      G37FormViewModel g37FormViewModel3 = g37FormViewModel;
      string negoBid = g37FormViewModel.NegoBid;
      num = -54;
      string str3 = num.ToString();
      string str4 = negoBid == str3 ? "Yes" : "";
      g37FormViewModel3.NegoBid = str4;
      G37FormViewModel g37FormViewModel4 = g37FormViewModel;
      string privatePlacementBid1 = g37FormViewModel.PrivatePlacementBid;
      num = -56;
      string str5 = num.ToString();
      string str6;
      if (!(privatePlacementBid1 == str5))
      {
        string privatePlacementBid2 = g37FormViewModel.PrivatePlacementBid;
        num = -57;
        string str7 = num.ToString();
        if (!(privatePlacementBid2 == str7))
        {
          str6 = "";
          goto label_9;
        }
      }
      str6 = "Yes";
label_9:
      g37FormViewModel4.PrivatePlacementBid = str6;
      if (g37FormViewModel.G37status != null && g37FormViewModel.G37status.Count != 0)
        return;
      g37FormViewModel.G37status = new List<long>();
      g37FormViewModel.G37status.Add(1L);
    }

    private List<int> GetTransitionStateTracking(
      List<IssueEnums.IssueG37FormStatus> oldStatusList,
      TransitionResult<IssueEnums.IssueG37FormStatus, G37Form> transitionResult)
    {
      List<int> intList = new List<int>();
      IEnumerable<IState<IssueEnums.IssueG37FormStatus, G37Form>> resultingStates = transitionResult.ResultingStates;
      IEnumerable<IState<IssueEnums.IssueG37FormStatus, G37Form>> intermediateStates = transitionResult.IntermediateStates;
      if (intermediateStates != null && intermediateStates.Count<IState<IssueEnums.IssueG37FormStatus, G37Form>>() > 0)
      {
        IState<IssueEnums.IssueG37FormStatus, G37Form> actionState = transitionResult.ActionState;
        foreach (IssueEnums.IssueG37FormStatus oldStatus in oldStatusList)
        {
          if (oldStatus != actionState.Key)
            intList.Add((int) oldStatus);
        }
        foreach (IState<IssueEnums.IssueG37FormStatus, G37Form> state in intermediateStates)
          intList.Add((int) state.Key);
      }
      else
      {
        foreach (IState<IssueEnums.IssueG37FormStatus, G37Form> state in resultingStates)
          intList.Add((int) state.Key);
      }
      return intList;
    }

    private void PublishEvents(
      G37FormViewModel g37FormModel,
      List<IssueEnums.IssueG37FormStatus> oldG37FormStatus,
      G37FormViewModel oldG37Form,
      G37Form newG37Form,
      List<IssueG37FormFromStateToState> fromToStateList,
      List<int> stateTracking,
      long appTransID)
    {
      bool flag = false;
      int num = g37FormModel.AppTransactionID <= 0L ? 1 : 0;
      List<IssueEnums.IssueG37FormStatus> list = newG37Form.G37Status.ConvertAll<IssueEnums.IssueG37FormStatus>((Converter<long, IssueEnums.IssueG37FormStatus>) (s => (IssueEnums.IssueG37FormStatus) s)).ToList<IssueEnums.IssueG37FormStatus>();
      if (num != 0)
      {
        newG37Form.AppTransactionID = appTransID;
        this.EventBus.Publish<IssueG37FormCreatedEvent>((IEnumerable<Envelope<IssueG37FormCreatedEvent>>) new List<Envelope<IssueG37FormCreatedEvent>>()
        {
          (Envelope<IssueG37FormCreatedEvent>) new IssueG37FormCreatedEvent(newG37Form),
          (Envelope<IssueG37FormCreatedEvent>) new IssueG37FormCreatedEvent(stateTracking, appTransID)
        });
      }
      else
        flag = !EntityStateHelper.IsStatusListEqual(oldG37FormStatus, list);
      if (!flag)
        return;
      this.EventBus.Publish<IssueG37FormStatusChangedEvent>((IEnumerable<Envelope<IssueG37FormStatusChangedEvent>>) new List<Envelope<IssueG37FormStatusChangedEvent>>()
      {
        (Envelope<IssueG37FormStatusChangedEvent>) new IssueG37FormStatusChangedEvent(newG37Form, fromToStateList),
        (Envelope<IssueG37FormStatusChangedEvent>) new IssueG37FormStatusChangedEvent(stateTracking, g37FormModel.AppTransactionID)
      });
    }

    private bool IsUIEditable(long appTransactionID, string uiName, List<long> statusList) => appTransactionID == 0L ? this.HasEntityPermission(-34L, uiName, "Edit") : this.HasUIPermissionForEntityStatus(appTransactionID, uiName, "Edit", statusList);
  }
}
