﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.MuccApprovalReportPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (MuccApprovalReportPresenter))]
  public class MuccApprovalReportPresenter : PresenterBase
  {
    [Dependency]
    public IMuccApprovalReportRepository MuccApprovalReportRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public MuccApprovalReportSearchViewModel InitializeViewModel() => new MuccApprovalReportSearchViewModel()
    {
      MergReviewTypes = this.LookupRepository.FetchByLookupKey("MERG Review Type").Select<LookupItem, KeyValuePair<long, string>>((Func<LookupItem, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>()
    };

    public Paged<MuccApprovalReportViewModel> GetMuccApprovalReport(
      KendoGridRequest request,
      MuccApprovalReportSearchViewModel model)
    {
      try
      {
        long total = 0;
        return new Paged<MuccApprovalReportViewModel>((IList<MuccApprovalReportViewModel>) this.GetSearchData(request, model, out total), total);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new Paged<MuccApprovalReportViewModel>((IList<MuccApprovalReportViewModel>) new List<MuccApprovalReportViewModel>(), 0L);
      }
    }

    private List<MuccApprovalReportViewModel> GetSearchData(
      KendoGridRequest request,
      MuccApprovalReportSearchViewModel model,
      out long total)
    {
      total = 0L;
      List<MuccApprovalReportViewModel> approvalReportViewModelList = new List<MuccApprovalReportViewModel>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      if (string.IsNullOrEmpty(model.LeadBanker))
        model.LeadBankerEmployeeId = 0L;
      if (string.IsNullOrEmpty(model.SupervisoryPrincipal))
        model.SPEmployeeId = 0L;
      MuccApprovalReportSearchViewModel reportSearchViewModel = model;
      DateTime? dateTo;
      DateTime dateTime;
      if (!model.dateTo.HasValue)
      {
        dateTime = DateTime.Today.AddDays(1.0).AddSeconds(-1.0);
      }
      else
      {
        dateTo = model.dateTo;
        dateTime = dateTo.Value.AddDays(1.0).AddSeconds(-1.0);
      }
      DateTime? nullable = new DateTime?(dateTime);
      reportSearchViewModel.dateTo = nullable;
      string[] array1 = model.SelectedMergReviewTypes.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Value)).ToArray<string>();
      string str = (string) null;
      if (array1.Length != 0)
        str = string.Join(",", array1);
      IMuccApprovalReportRepository reportRepository = this.MuccApprovalReportRepository;
      DateTime dateFrom = model.dateFrom;
      dateTo = model.dateTo;
      DateTime toDate = dateTo.Value;
      long? leadBankerEmpID = new long?(model.LeadBankerEmployeeId);
      long? supervisoryPrincipalEmpID = new long?(model.SPEmployeeId);
      string ReviewType = str;
      Ordering[] array2 = orderingList.ToArray();
      int skip = (int) request.skip;
      int take = request.take;
      using (IDataReader dataReader = reportRepository.FetchMuccApprovalReportData(dateFrom, toDate, leadBankerEmpID, supervisoryPrincipalEmpID, ReviewType, 1, array2, skip, take))
      {
        if (dataReader != null)
        {
          IRowMapper<MuccApprovalReportViewModel> rowMapper = MapBuilder<MuccApprovalReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            approvalReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return approvalReportViewModelList;
    }

    public ExportResult Export(
      KendoGridRequest request,
      MuccApprovalReportSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<MuccApprovalReportViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _);
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType12<string, string, string, string, string, string, string, string>> datas = searchData.Select(d =>
        {
          string issueNbr = d.IssueNbr;
          string issuer = d.Issuer;
          string borrower = d.Borrower;
          string leadBanker = d.LeadBanker;
          string banker2 = d.Banker2;
          string supervisoryPrincipal = d.SupervisoryPrincipal;
          string reviewType = d.ReviewType;
          DateTime dateApprovedByMucc = d.DateApprovedByMUCC;
          string str = d.DateApprovedByMUCC.ToString("MM/dd/yyyy") == "01/01/0001" ? "" : d.DateApprovedByMUCC.ToString("MM/dd/yyyy");
          return new
          {
            IssueNbr = issueNbr,
            Issuer = issuer,
            Borrower = borrower,
            LeadBanker = leadBanker,
            Banker2 = banker2,
            SupervisoryPrincipal = supervisoryPrincipal,
            ReviewType = reviewType,
            DateApprovedByMUCC = str
          };
        });
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("MUCC Approved Report");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Transaction Number", "IssueNbr", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Borrower", "Borrower", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Lead Banker ", "LeadBanker", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Banker 2", "Banker2", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Supervisory Principal", "SupervisoryPrincipal", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("MUCC Review Type", "ReviewType", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Date Approved By MUCC", "DateApprovedByMUCC", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "MuccApprovalReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }
  }
}
