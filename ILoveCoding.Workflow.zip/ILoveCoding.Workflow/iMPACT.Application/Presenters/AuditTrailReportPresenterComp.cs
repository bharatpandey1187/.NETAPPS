﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.AuditTrailReportPresenterComp
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (AuditTrailReportPresenterComp))]
  public class AuditTrailReportPresenterComp : PresenterBase
  {
    [Dependency]
    public IAuditTrailReportRepository AuditTrailReportRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IPnlCompetitiveRepository PnlRepository { get; set; }

    [Dependency]
    public IAuditTrailReportRepositoryComp AuditTrailReportRepositoryComp { get; set; }

    public AuditTrailReportViewModelContainer GetAuditTrailsForReport(
      AuditTrailSearchViewModel searchCriteria)
    {
      try
      {
        return new AuditTrailReportViewModelContainer()
        {
          AuditTrailReport = this.GetAuditTrailsdata(searchCriteria)
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new AuditTrailReportViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public ExportResult Export(
      KendoGridRequest request,
      AuditTrailSearchViewModel searchCriteria,
      string exportType,
      string offsetTimeZoneMinutes)
    {
      try
      {
        IEnumerable<\u003C\u003Ef__AnonymousType0<string, string, string, string, string>> datas = this.GetAuditTrailsdata(searchCriteria).Select(d => new
        {
          DealNumber = d.DealNumber,
          IssueName = d.IssueName,
          When = this.GetLocalWhenFromUTCWhen(d.When, offsetTimeZoneMinutes),
          What = d.What,
          WhoEx = d.WhoEx
        });
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Audit Trail Report", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Opportunity/Issue Number", "DealNumber", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Opportunity/Issue", "IssueName", Unit.Parse("12cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Audit Date", "When", Unit.Parse("2.4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Description", "What", Unit.Parse("8.6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Updated By", "WhoEx", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "AuditTrailReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }

    private string GetLocalWhenFromUTCWhen(DateTime When, string OffSetMinutes)
    {
      TimeSpan timeSpan = TimeSpan.FromMinutes((double) -Convert.ToInt32(OffSetMinutes));
      return When.Add(timeSpan).ToString("MM/dd/yyyy hh:mm:ss tt");
    }

    private List<AuditTrailReportViewModel> GetAuditTrailsdata(
      AuditTrailSearchViewModel searchCriteria)
    {
      List<AuditTrailReportViewModel> trailReportViewModelList = new List<AuditTrailReportViewModel>();
      AuditTrailSearchViewModel trailSearchViewModel = searchCriteria;
      DateTime dateTime1;
      if (!(searchCriteria.dateTo == DateTime.MinValue))
      {
        DateTime dateTime2 = searchCriteria.dateTo;
        dateTime2 = dateTime2.AddDays(1.0);
        dateTime1 = dateTime2.AddSeconds(-1.0);
      }
      else
      {
        DateTime dateTime2 = DateTime.Today;
        dateTime2 = dateTime2.AddDays(1.0);
        dateTime1 = dateTime2.AddSeconds(-1.0);
      }
      trailSearchViewModel.dateTo = dateTime1;
      using (IDataReader dataReader = this.AuditTrailReportRepository.FetchAllAuditTrailsForReport(searchCriteria.dateFrom, searchCriteria.dateTo, searchCriteria.entity))
      {
        IRowMapper<AuditTrailReportViewModel> rowMapper = MapBuilder<AuditTrailReportViewModel>.MapAllProperties().Build();
        if (dataReader != null)
        {
          while (dataReader.Read())
            trailReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      return trailReportViewModelList;
    }

    public AuditTrailReportViewModelContainer GetOpportunityAuditTrail(
      long appId,
      int fromVersion,
      int toVersion)
    {
      try
      {
        AuditTrailReportViewModelContainer viewModelContainer1 = new AuditTrailReportViewModelContainer();
        List<OpportunityAuditTrailViewModel> auditTrailViewModelList = new List<OpportunityAuditTrailViewModel>();
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (appId <= 0L)
          return new AuditTrailReportViewModelContainer("401");
        if (!this.HasUIPermissionForEntity(-33L, appId, "Opportunity Details", "View"))
        {
          AuditTrailReportViewModelContainer viewModelContainer2 = new AuditTrailReportViewModelContainer();
          viewModelContainer2.ErrorMessage = "401";
          return viewModelContainer2;
        }
        foreach (OpportunityAuditFields detail in this.AuditTrailReportRepository.GetOpportunityAuditTrail(appId, fromVersion, toVersion))
        {
          detail.VersionNumber = "V#" + detail.VersionNumber;
          auditTrailViewModelList.Add(this.MapAuiditRepositoryFromModel(detail));
        }
        viewModelContainer1.OpportunityAuditTrailViewModel = auditTrailViewModelList;
        return viewModelContainer1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new AuditTrailReportViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public AuditTrailReportViewModelCompContainer GetTransactionAuditTrailComp(
      long appId,
      int fromVersion,
      int toVersion)
    {
      try
      {
        AuditTrailReportViewModelCompContainer modelCompContainer1 = new AuditTrailReportViewModelCompContainer();
        List<TransactionAuditTrailViewModelComp> trailViewModelCompList = new List<TransactionAuditTrailViewModelComp>();
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (appId <= 0L)
          return new AuditTrailReportViewModelCompContainer("401");
        if (!this.HasUIPermissionForEntity(-31L, appId, "Issue Detail", "View"))
        {
          AuditTrailReportViewModelCompContainer modelCompContainer2 = new AuditTrailReportViewModelCompContainer();
          modelCompContainer2.ErrorMessage = "401";
          return modelCompContainer2;
        }
        List<SeriesAudit> seriesData = new List<SeriesAudit>();
        foreach (CompetitiveTransactionAuditFields detail in this.AuditTrailReportRepositoryComp.GetTransactionAuditTrailComp(appId, fromVersion, toVersion, out seriesData))
        {
          detail.VersionNo = "V#" + detail.VersionNo;
          trailViewModelCompList.Add(this.MapTransactionRepositoryFromModel(detail));
        }
        modelCompContainer1.TransactionAuditTrailViewModel = trailViewModelCompList;
        modelCompContainer1.SeriesAuditTrailViewModel = seriesData;
        return modelCompContainer1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new AuditTrailReportViewModelCompContainer("An error occurred while fetching the data.");
      }
    }

    public AuditTrailReportViewModelCompContainer GetPNLAuditTrail(
      long issueId,
      long appId,
      int fromVersion,
      int toVersion)
    {
      try
      {
        AuditTrailReportViewModelCompContainer modelCompContainer = new AuditTrailReportViewModelCompContainer();
        this.FlushEntitySecurityPermissionAppTransIDStatusID();
        if (appId <= 0L)
          return new AuditTrailReportViewModelCompContainer("401");
        if (this.HasUIPermissionForEntity(-35L, issueId, "PnL Audit Trail", "View"))
          ;
        PnlCompetitiveViewModelContainer viewModelContainer = this.FetchPnlHistoryById(appId, fromVersion, toVersion);
        modelCompContainer.PnlAuditViewModel = viewModelContainer;
        return modelCompContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new AuditTrailReportViewModelCompContainer("An error occurred while fetching the data.");
      }
    }

    public PnlCompetitiveViewModelContainer FetchPnlHistoryById(
      long appId,
      int fromVersion,
      int toVersion)
    {
      PnlCompetitiveViewModelContainer viewModelContainer = new PnlCompetitiveViewModelContainer();
      PnlCompetitive pnlCompetitive = this.PnlRepository.FetchPnlHistoryById(appId, fromVersion, toVersion);
      viewModelContainer.PnlAuditData = pnlCompetitive.PnlAuditData;
      viewModelContainer.PnlHeaderInfo = new PnlCompHeaderInfoViewModel(pnlCompetitive.PnlHeaderInfo);
      viewModelContainer.JobNumbers = pnlCompetitive.JobNumbers;
      viewModelContainer.UniqueSection = pnlCompetitive.UniqueSections;
      viewModelContainer.UniqueCategoriesUnderSection = pnlCompetitive.UniqueCategoriesUnderSection;
      viewModelContainer.PnLUserInfo = pnlCompetitive.PnlUserInfo.Select<PnlCompetitiveUserInfo, PnlCompUserInfoViewModel>((Func<PnlCompetitiveUserInfo, PnlCompUserInfoViewModel>) (q => new PnlCompUserInfoViewModel(q))).ToList<PnlCompUserInfoViewModel>();
      viewModelContainer.PnlSummaryUnderWrittingHistory = pnlCompetitive.PnlSummaryUnderWrittingHistory;
      return viewModelContainer;
    }

    private TransactionAuditTrailViewModelComp MapTransactionRepositoryFromModel(
      CompetitiveTransactionAuditFields detail)
    {
      return new TransactionAuditTrailViewModelComp()
      {
        AppTransactionID = detail.AppTransactionID,
        VersionNumber = "V#" + detail.VersionNo,
        VersionInfo = detail.VersionInfo,
        CreateDate = detail.CreateDate,
        UserInfo = detail.UserInfo,
        SettlementDate = detail.SettlementDate,
        G37SettlementDate = detail.G37SettlementDate,
        IPREOStatusValue = detail.IPREOStatusValue,
        IPREOIssuerName = detail.IPREOIssuerName,
        IssueName = detail.IssueName,
        IssueNbr = detail.IssueNbr,
        IssueStatusValue = detail.IssueStatusValue,
        ReviewStatusValue = detail.ReviewStatusValue,
        JobNumber = detail.JobNumber,
        BorrowerName = detail.BorrowerName,
        IssuerName = detail.IssuerName,
        GuarantorName = detail.GuarantorName,
        OfferingType = detail.OfferingType,
        State = detail.State,
        County = detail.County,
        G17SentDate = detail.G17SentDate,
        G17AckDate = detail.G17AckDate,
        RemarksForMUCC = detail.RemarksForMUCC,
        MAExemptions = detail.MAExemptions,
        IRMAIndependent = detail.IRMAIndependent,
        G17Details = detail.G17Details,
        FirmRole = detail.FirmRole,
        FirmLiabilityPerc = detail.FirmLiabilityPerc,
        FirmMgmtFeePerc = detail.FirmMgmtFeePerc,
        FirmOtherRoles = detail.FirmOtherRoles,
        ParAmount = detail.ParAmount,
        SDCCreditPerc = detail.SDCCreditPerc,
        TransactionType = detail.TransactionType,
        GeneralCategory = detail.GeneralCategory,
        GeneralCategorySpecific = detail.GeneralCategorySpecific,
        PricingDate = detail.PricingDate,
        ROPDate = detail.ROPDate,
        ExpectedAwardDate = detail.ExpectedAwardDate,
        ActualAwardDateTime = detail.ActualAwardDateTime,
        ActualAwardDateTimeZone = detail.ActualAwardDateTimeZone,
        EstimatedRevenue = detail.EstimatedRevenue,
        GoodFaithAmount = detail.GoodFaithAmount,
        GoodFaithDate = detail.GoodFaithDate,
        GoodFaithType = detail.GoodFaithType,
        AccountName = detail.AccountName,
        AccountNumber = detail.AccountNumber,
        ABANumber = detail.ABANumber,
        GFRequired = detail.GFRequired,
        GoodFaithApplied = detail.GoodFaithApplied,
        GoodFaithDueDate = detail.GoodFaithDueDate,
        BankName = detail.BankName,
        GoodFaithIssueDate = detail.GoodFaithIssueDate,
        GoodFaithReturnedDate = detail.GoodFaithReturnedDate,
        GoodFaithNotes = detail.GoodFaithNotes,
        GoodFaithInstructions = detail.GoodFaithInstructions,
        DateCounselApprovedByLegal = detail.DateCounselApprovedByLegal,
        CommitmentCommitteeApprovalDate = detail.CommitmentCommitteeApprovalDate,
        DateApprovedByMUCC = detail.DateApprovedByMUCC,
        FinalOSReceivedDateTime = detail.FinalOSReceivedDateTime,
        G32SubmissionDateTime = detail.G32SubmissionDateTime,
        AdvanceRefunding = detail.AdvanceRefunding,
        ARDSubmissionDate = detail.ARDSubmissionDate,
        InvestmentBankingTeam = detail.InvestmentBankingTeam,
        SyndicateMembers = detail.SyndicateMembers,
        SyndicateTeam = detail.SyndicateTeam,
        AdvisoryAgents = detail.AdvisoryAgents,
        Counsels = detail.Counsels,
        SupervisoryPrincipal = detail.SupervisoryPrincipal,
        OtherExternalType = detail.OtherExternalType,
        DateHired = detail.DateHired,
        Series = detail.Series,
        InternalPartners = detail.InternalPartners,
        ExternalPartners = detail.ExternalPartners,
        SyndicateExternalPartners = detail.SyndicateExternalPartners,
        DealType = detail.DealType,
        FormalDueDiligenceDate = detail.FormalDueDiligenceDate,
        IssuePriceCertReviewDate = detail.IssuePriceCertReviewDate,
        LiquidityAgreementUploadDate = detail.LiquidityAgreementUploadDate,
        CrossSellValue = detail.CrossSellValue,
        CrossSellDetail = detail.CrossSellDetail,
        DatedDate = detail.DatedDate,
        OSDeemedFinalDate = detail.OSDeemedFinalDate,
        ReasonOfHold = detail.ReasonOfHold
      };
    }

    private OpportunityAuditTrailViewModel MapAuiditRepositoryFromModel(
      OpportunityAuditFields detail)
    {
      OpportunityAuditTrailViewModel auditTrailViewModel = new OpportunityAuditTrailViewModel()
      {
        VersionNumber = "V#" + detail.VersionNumber,
        VersionInfo = detail.VersionInfo,
        CreateDate = detail.CreateDate,
        UserInfo = detail.UserInfo,
        SDCCreditPerc = detail.SDCCreditPerc,
        DealType = detail.DealType,
        RFPType = detail.RFPType,
        AppTransactionID = detail.AppTransactionID,
        OpportunityNbr = detail.OpportunityNbr,
        OpportunityName = detail.OpportunityName,
        OpportunityStatus = detail.OpportunityStatus,
        ReviewStatus = detail.ReviewStatus,
        PowerID = detail.PowerID,
        State = detail.State,
        County = detail.County,
        Issuer = detail.Issuer,
        Borrower = detail.Borrower,
        Guarantor = detail.Guarantor,
        OpportunityType = detail.OpportunityType,
        ParAmount = detail.ParAmount,
        Purpose = detail.Purpose,
        Market = detail.Market,
        TransactionType = detail.TransactionType,
        SecurityType = detail.SecurityType,
        MaterialType = detail.MaterialType,
        BankQualified = detail.BankQualified,
        AMTTaxable = detail.AMTTaxable,
        FedTaxable = detail.FedTaxable,
        StateTaxable = detail.StateTaxable,
        FAEngaged = detail.FAEngaged,
        CMRelationship = detail.CMRelationship,
        BankRelationship = detail.BankRelationship,
        InsuranceProvider = detail.InsuranceProvider,
        ApprovedDerivativeMarketer = detail.ApprovedDerivativeMarketer,
        MAExemptions = detail.MAExemptions,
        G17Details = detail.G17Details,
        IsNewOpportunity = detail.IsNewOpportunity,
        HybridSolutionIndicator = detail.HybridSolutionIndicator,
        InformationalMERGRequired = detail.InformationalMERGRequired,
        ExpectedFirmRole = detail.ExpectedFirmRole,
        AssignedFirmRole = detail.AssignedFirmRole,
        ExpectedFirmLiabilityPerc = detail.ExpectedFirmLiabilityPerc,
        AssignedFirmLiabilityPerc = detail.ExpectedFirmLiabilityPerc,
        InvestmentBankingTeam = detail.InvestmentBankingTeam,
        SyndicateMembers = detail.SyndicateMembers,
        AdvisoryAgents = detail.AdvisoryAgents,
        Counsels = detail.Counsels,
        SupervisoryPrincipal = detail.SupervisoryPrincipal,
        BankRM = detail.BankRM,
        MoodyRating = detail.MoodyRating,
        SPRating = detail.SPRating,
        KrollRating = detail.KrollRating,
        FitchRating = detail.FitchRating
      };
      auditTrailViewModel.CreateDate = detail.CreateDate;
      auditTrailViewModel.CreateDateValue = detail.CreateDateValue;
      auditTrailViewModel.ResponseDueDateTime = detail.ResponseDueDate;
      auditTrailViewModel.ResponseDueDateTimeZone = detail.ResponseDueDateTimeZone;
      auditTrailViewModel.SentTo3Firms = detail.SentTo3Firms;
      auditTrailViewModel.SaleDate = detail.SaleDate;
      auditTrailViewModel.SaleDateValue = detail.SaleDateValue;
      auditTrailViewModel.CloseDate = detail.CloseDate;
      auditTrailViewModel.CloseDateValue = detail.CloseDateValue;
      auditTrailViewModel.FinancingDate = detail.FinancingDate;
      auditTrailViewModel.FinancingDateValue = detail.FinancingDateValue;
      auditTrailViewModel.SupervisoryPrincipalApprovalDate = detail.SupervisoryPrincipalApprovalDate;
      auditTrailViewModel.SupervisoryPrincipalApprovalDateValue = detail.SupervisoryPrincipalApprovalDateValue;
      auditTrailViewModel.SupervisoryPrincipalReviewDate = detail.SupervisoryPrincipalReviewDate;
      auditTrailViewModel.SupervisoryPrincipalReviewDateValue = detail.SupervisoryPrincipalReviewDateValue;
      auditTrailViewModel.ClientLastContactedDate = detail.ClientLastContactedDate;
      auditTrailViewModel.ClientLastContactedDateValue = detail.ClientLastContactedDateValue;
      auditTrailViewModel.DateHired = detail.DateHired;
      auditTrailViewModel.DateHiredValue = detail.DateHiredValue;
      auditTrailViewModel.GrossSpread = detail.GrossSpread;
      auditTrailViewModel.EstGrossRev = detail.EstGrossRev;
      auditTrailViewModel.RateType = detail.RateType;
      auditTrailViewModel.TakeDownValue = detail.TakeDownValue;
      auditTrailViewModel.RFPType = detail.RFPType;
      auditTrailViewModel.ConflictOfInterest = detail.ConflictOfInterest;
      auditTrailViewModel.DerivativesStrategy = detail.DerivativesStrategy;
      auditTrailViewModel.RFPFees = detail.RFPFees;
      auditTrailViewModel.InvestmentBankingTeam = detail.InvestmentBankingTeam;
      auditTrailViewModel.SyndicateMembers = detail.SyndicateMembers;
      auditTrailViewModel.AdvisoryAgents = detail.AdvisoryAgents;
      auditTrailViewModel.Counsels = detail.Counsels;
      auditTrailViewModel.ResponseDueDate = detail.ResponseDueDate;
      auditTrailViewModel.ResponseDueDateTimezone = detail.ResponseDueDateTimezone;
      auditTrailViewModel.jobnumber = detail.jobnumber;
      auditTrailViewModel.AdditionalInformationForCommitmentCommittee = detail.AdditionalInformationForCommitmentCommittee;
      auditTrailViewModel.AdditionalRFPDetails = detail.AdditionalRFPDetails;
      auditTrailViewModel.WinningSyndicate = detail.WinningSyndicate;
      auditTrailViewModel.InternalPartners = detail.InternalPartners;
      auditTrailViewModel.ExternalPartners = !detail.ExternalPartners.Any<ExternalPartner>((Func<ExternalPartner, bool>) (syn => syn.LookupKey != "Winning Syndicate Members" && syn.LookupKey != "Syndicate Member")) ? (List<ExternalPartner>) null : detail.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (syn => syn.LookupKey != "Winning Syndicate Members" && syn.LookupKey != "Syndicate Member")).ToList<ExternalPartner>();
      auditTrailViewModel.SyndicateExternalPartners = !detail.ExternalPartners.Any<ExternalPartner>((Func<ExternalPartner, bool>) (syn => syn.LookupKey == "Winning Syndicate Members" || syn.LookupKey == "Syndicate Member")) ? (List<ExternalPartner>) null : detail.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (syn => syn.LookupKey == "Winning Syndicate Members" || syn.LookupKey == "Syndicate Member")).ToList<ExternalPartner>();
      auditTrailViewModel.ExpectedPricingDate = detail.ExpectedPricingDate;
      auditTrailViewModel.ExpectedPricingDateValue = detail.ExpectedPricingDateValue;
      auditTrailViewModel.ProposedManagementFee = detail.ProposedManagementFee;
      auditTrailViewModel.ProposedUnderwriterExpenses = detail.ProposedUnderwriterExpenses;
      auditTrailViewModel.FirmMgmtFee = detail.FirmMgmtFee;
      auditTrailViewModel.FedTaxName = detail.FedTaxName;
      auditTrailViewModel.Notes = detail.Notes;
      return auditTrailViewModel;
    }

    private string[] GetAuditTrailLookupItemKeys() => new string[15]
    {
      "Opportunity Status",
      "State",
      "Type of Opportunity",
      "MA Exemption",
      "Firm Role",
      "Purpose",
      "Market",
      "Moody's Long Term Rating",
      "S&P Long Term Rating",
      "Kroll Long Term Rating",
      "Fitch Long Term Rating",
      "Advisory Agent Type",
      "Counsel Type",
      "Material Type",
      "Approved Derivative Marketer"
    };

    public object FetchLastValueForFieldByEntityIdAppTransactionId(
      long appId,
      long entityId,
      string field)
    {
      return this.AuditTrailReportRepository.FetchLastValueForFieldByEntityIdAppTransactionId(appId, entityId, field);
    }
  }
}
