﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.RFPTrackingAndRepositoryPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (RFPTrackingAndRepositoryPresenter))]
  public class RFPTrackingAndRepositoryPresenter : PresenterBase
  {
    [Dependency]
    public IRFPTrackingAndRepository RFPTrackingAndRepository { get; set; }

    public Paged<RFPTrackingAndRepositoryReportViewModel> GetRFPTrackingAndRepositoryReport(
      KendoGridRequest request,
      RFPTrackingAndRepositorySearchViewModel model)
    {
      try
      {
        long total = 0;
        return new Paged<RFPTrackingAndRepositoryReportViewModel>((IList<RFPTrackingAndRepositoryReportViewModel>) this.GetSearchData(request, model, out total), total);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new Paged<RFPTrackingAndRepositoryReportViewModel>((IList<RFPTrackingAndRepositoryReportViewModel>) new List<RFPTrackingAndRepositoryReportViewModel>(), 0L);
      }
    }

    private List<RFPTrackingAndRepositoryReportViewModel> GetSearchData(
      KendoGridRequest request,
      RFPTrackingAndRepositorySearchViewModel model,
      out long total)
    {
      total = 0L;
      List<RFPTrackingAndRepositoryReportViewModel> repositoryReportViewModelList = new List<RFPTrackingAndRepositoryReportViewModel>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      DateTime? dateTo;
      if (model.dateFrom > DateTime.Today)
      {
        RFPTrackingAndRepositorySearchViewModel repositorySearchViewModel = model;
        DateTime dateTime1;
        if (!model.dateTo.HasValue)
        {
          DateTime dateTime2 = model.dateFrom;
          dateTime2 = dateTime2.AddDays(1.0);
          dateTime1 = dateTime2.AddSeconds(-1.0);
        }
        else
        {
          dateTo = model.dateTo;
          dateTime1 = dateTo.Value.AddDays(1.0).AddSeconds(-1.0);
        }
        DateTime? nullable = new DateTime?(dateTime1);
        repositorySearchViewModel.dateTo = nullable;
      }
      else
      {
        RFPTrackingAndRepositorySearchViewModel repositorySearchViewModel = model;
        DateTime dateTime;
        if (!model.dateTo.HasValue)
        {
          dateTime = DateTime.Today.AddDays(1.0).AddSeconds(-1.0);
        }
        else
        {
          dateTo = model.dateTo;
          dateTime = dateTo.Value.AddDays(1.0).AddSeconds(-1.0);
        }
        DateTime? nullable = new DateTime?(dateTime);
        repositorySearchViewModel.dateTo = nullable;
      }
      IRFPTrackingAndRepository trackingAndRepository = this.RFPTrackingAndRepository;
      DateTime dateFrom = model.dateFrom;
      dateTo = model.dateTo;
      DateTime toDate = dateTo.Value;
      Ordering[] array = orderingList.ToArray();
      int skip = (int) request.skip;
      int take = request.take;
      using (IDataReader dataReader = trackingAndRepository.FetchRFPTrackingAndRepositoryReportData(dateFrom, toDate, 1, array, skip, take))
      {
        if (dataReader != null)
        {
          IRowMapper<RFPTrackingAndRepositoryReportViewModel> rowMapper = MapBuilder<RFPTrackingAndRepositoryReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            repositoryReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return repositoryReportViewModelList;
    }

    public ExportResult Export(
      KendoGridRequest request,
      RFPTrackingAndRepositorySearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<RFPTrackingAndRepositoryReportViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _);
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType17<string, string, string, string, string, string, string, string, string, string>> datas = searchData.Select(d =>
        {
          string rfpNbr = d.RFPNbr;
          string issuer = d.Issuer;
          string issuerState = d.IssuerState;
          string generalCategory = d.GeneralCategory;
          string leadBanker = d.LeadBanker;
          string professionalSupport = d.AnalystAndProfessionalSupport;
          string supervisoryPrincipal = d.SupervisoryPrincipal;
          DateTime dateSubmitted = d.DateSubmitted;
          string str = d.DateSubmitted.ToString("MM/dd/yyyy") == "01/01/0001" ? "" : d.DateSubmitted.ToString("MM/dd/yyyy");
          string status = d.Status;
          string firmRole = d.FirmRole;
          return new
          {
            RFPNbr = rfpNbr,
            Issuer = issuer,
            IssuerState = issuerState,
            GeneralCategory = generalCategory,
            LeadBanker = leadBanker,
            AnalystAndProfessionalSupport = professionalSupport,
            SupervisoryPrincipal = supervisoryPrincipal,
            DateSubmitted = str,
            Status = status,
            FirmRole = firmRole
          };
        });
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("RFP Tracking And Repository Report");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Opportunity Number", "RFPNbr", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer State ", "IssuerState", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issue Section / General Category", "GeneralCategory", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Lead Banker ", "LeadBanker", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Analyst And Professional Support", "AnalystAndProfessionalSupport", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Supervisory Principal", "SupervisoryPrincipal", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Date Submitted ", "DateSubmitted", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Status", "Status", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Firm Role", "FirmRole", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "RFPTrackingAndRepositoryReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }
  }
}
