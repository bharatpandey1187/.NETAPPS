﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.Constants
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System.ComponentModel;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public static class Constants
  {
    public static readonly string MenuCacheKey = "CachedMenusByRoles";
    public const int groupDocumentsByCategoryAppConfigId = 50;

    public static class ErrorMessages
    {
      public const string SaveErrorMsg = "An error occurred while saving the data.";
      public const string ViewErrorMsg = "An error occurred while fetching the data.";
      public const string FirmRoleMisMatch = "You are not authorized to view this page.";
      public const string DeleteErrorMsg = "An error occurred while deleting the data.";
      public const string NotAuthorizedMsg = "You are not authorized to view this page.";
      public const string NotAuthorizedToAccessResource = "You are not authorized to access this resource.";
      public const string Unauthorized = "401";
    }

    public static class Messages
    {
    }

    public static class DocumentKeys
    {
      public class StorageKey
      {
        public const string StorageKey_Sharepoint = "SharePoint";
        public const string StorageKey_FileNet_WORM = "FileNet-WORM";
        public const string StorageKey_FileNet_NonWORM = "FileNet-NonWORM";
        public const string TypeValue_Sharepoint = "SharePoint";
        public const string TypeValue_FileNet = "FileNet";
      }
    }

    public static class Validations
    {
      public const string RegExName = "^$|(^[A-Za-z',. ]+$)";
      public const string RegExEmail = "^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$";
      public const string RegExPhone = "^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))";
      public const string RegExFax = "^$|((^[0-9]{10}$)|(^[0-9]{3}[-][0-9]{3}[-][0-9]{4}$))";
      public const string RegExAddress = "^$|(^[A-Za-z0-9.,/() ]+$)";
      public const string RegExZip = "^$|((^[0-9]{5}$)|(^[0-9]{5}-[0-9]{4}$))";
      public const string RegDomainUser = "^$|([a-z][a-z0-9._-]+)\\\\(?! +)([^\\\\[\\]:|<>+=;,?*@]+)$";
      public const string RegAspc = "^$|(^[A-Za-z.,/() ]+$)";
      public const string RegAsp = "^$|(^[A-Za-z0-9 ]+$)";
      public const string RegExAS = "^$|(^[A-Za-z'-. ]+$)";
      public const string RegExNumber = "^$|(^[0-9]+$)";
      public const string RegExDecimal = "^$|(^[0-9]+(.[0-9]{1,2})?$)";
      public const string RegExMoney2D = "^$|(^[$0-9,]+(.[0-9]{1,2})?$)";
      public const string RegExAlphaNumericName = "^$|(^[A-Za-z0-9-\\\\',()@&. /_]+$)";
      public const string RegExAlphaNumericNameWithSemicolon = "^$|(^[A-Za-z0-9-\\\\',;()@&. /_]+$)";
      public const string RegExTin = "^$|(^[A-Za-z0-9-]+$)";
      public const string RegExTitle = "^$|(^[A-Za-z-\\\\,& ./]+$)";
      public const string RegExURL = "^(http|ftp|https)://";
      public const string RegExCUSIP = "^[a-zA-Z0-9#@*]*$";
      public const string RegExClientPhone = "^[0-9-().]*$";
      public const string RegExAlphabets = "^$|(^[A-Za-z]+$)";
      public const string RegExAlphabetsContryInc = "^$|(^[A-Za-z]+$)";
    }

    public static class ValidationMessages
    {
      public const string RegExName = "Only alphabets and spaces ,.' are allowed.";
      public const string RegExEmail = "Email address is not valid.";
      public const string RegExPhone = "Phone number should be in XXX-XXX-XXXX format.";
      public const string RegExMobile = "Mobile number should be in XXX-XXX-XXXX format.";
      public const string RegExFax = "Fax number should be in XXX-XXX-XXXX format.";
      public const string RegExAddress = "Only alphanumeric characters, space and .,/() are allowed.";
      public const string RegExZip = "ZIP Code for USA should be XXXXX or XXXXX-XXXX.";
      public const string RegDomainUser = "Invalid Window ID, it should be in [domain\\username] format.";
      public const string RegAspc = "Only alphabets, space and .,/() are allowed.";
      public const string RegAsp = "Only alphanumeric characters, space are allowed.";
      public const string RegExAS = "Only alphabets, comma, dash, period, apostrophe and space are allowed.";
      public const string RegExNumber = "Only numbers are allowed.";
      public const string RegExDecimal = "Only numbers with two decimal places are allowed .";
      public const string RegExMoney2D = "Only $ sign ,comma, numbers with two decimal places are allowed .";
      public const string RegExAlphaNumericName = "Only alphanumeric characters ,space,Comma,Dot,@,&,(),/,-,_,'  are allowed.";
      public const string RegExTin = "Only alphanumeric characters and - are allowed in Tax ID.";
      public const string RegExTitle = "Only alphabets, comma, slash, dash, &, period and space are allowed.";
      public const string RegExURL = "Invalid URL!!!";
      public const string RegExCUSIP = "Please enter valid basic CUSIP.";
      public const string RegExClientPhone = "Only numeric values , () , . , -  are allowed.";
      public const string RegExAlphabets = "Only alphabets are allowed in Country Code.";
      public const string RegExAlphabetsContryInc = "Only alphabets are allowed in Country Of Incorporation.";
    }

    public static class LookupKeys
    {
      public const string PartnerType = "Partner Type";
      public const string PlatformRole = "Platform Role";
      public const string IssueStates = "Issue Status";
      public const string FirmRole = "Firm Role";
      public const string FirmOtherRole = "Additional Firm Role(s)";
      public const string PriorityOfOrders = "Syndicate Structure";
      public const string TypeOfOffering = "Type of Offering";
      public const string InsuranceProvider = "Insurance Provider";
      public const string State = "State";
      public const string MeetingType = "Meeting Type";
      public const string UseOfProceeds = "Use of Proceeds";
      public const string DSRF = "DSRF";
      public const string Purpose = "Purpose";
      public const string CreditEnhancementProgram = "Credit Enhancement Program";
      public const string GeneralCategory = "MS Banking Group";
      public const string GeneralCategorySpecific = "General Category (Specific)";
      public const string BidPlatform = "Bid Platform";
      public const string BidCalc = "Bid Calc";
      public const string SyndicateMemberRole = "Syndicate Member Role";
      public const string WinningSyndicateMemberRole = "Winning Syndicate Member Role";
      public const string AdvisorAgentType = "Advisory Agent Type";
      public const string CounselType = "Counsel Type";
      public const string OtherPartnerType = "Other Partner Type";
      public const string IssueStatus = "Issue Status";
      public const string MERGReviewType = "MERG Review Type";
      public const string GoodFaithType = "Good Faith Type";
      public const string DocumentRepository = "Document Repository";
      public const string RFPStatus = "RFP Status";
      public const string DealType = "Deal Type";
      public const string G17Type = "G-17 Type";
      public const string IsAdvanceRefunding = "Is Advance Refunding";
      public const string MoodyLongTermRating = "Moody's Long Term Rating";
      public const string MoodyShortTermRating = "Moody's Short Term Rating";
      public const string MoodyRatingOutlook = "Moody's Rating Outlook";
      public const string SPLongTermRating = "S&P Long Term Rating";
      public const string SPShortTermRating = "S&P Short Term Rating";
      public const string SPRatingOutlook = "S&P Rating Outlook";
      public const string KrollLongTermRating = "Kroll Long Term Rating";
      public const string KrollShortTermRating = "Kroll Short Term Rating";
      public const string KrollRatingOutlook = "Kroll Rating Outlook";
      public const string FitchLongTermRating = "Fitch Long Term Rating";
      public const string FitchShortTermRating = "Fitch Short Term Rating";
      public const string FitchRatingOutlook = "Fitch Rating Outlook";
      public const string CreditEnhancementType = "Credit Enhancement Type";
      public const string PricingStatus = "Pricing Status";
      public const string SecurityType = "Security Type (General)";
      public const string SecuritySpecific = "Security Type (Specific)";
      public const string FedTax = "Fed Tax";
      public const string StateTax = "State Tax";
      public const string PricingForm = "Pricing Form";
      public const string PricingAccrueForm = "Pricing Accrue From";
      public const string DayCount = "Day Count";
      public const string CallFeature = "Call Feature";
      public const string CouponFreq = "Coupon Frequency";
      public const string Insurance = "Insurance";
      public const string Entity = "Entity";
      public const string PrincipalFreq = "Principal Freq";
      public const string DataType = "Data Type";
      public const string Banker = "Banker";
      public const string Analyst = "Analyst";
      public const string ProfessionalSupport = "Professional Support";
      public const string Underwriter = "Underwriter";
      public const string Office = "Office";
      public const string AppRoleEntity = "App";
      public const string RfpType = "RFP Type";
      public const string OpportunityStatus = "Opportunity Status";
      public const string OpportunityType = "Type of Opportunity";
      public const string MaterialType = "Material Type";
      public const string MAExemption = "MA Exemption";
      public const string TransactionType = "Transaction Type";
      public const string Market = "Market";
      public const string OpptyRFPType = "Oppty RFP Type";
      public const string RateMode = "Interest Rate Type";
      public const string ApprovedDerivativeMarketer = "Approved Derivative Marketer";
      public const string ContactTitle = "Contact Title";
      public const string CrossSell = "Cross Sell";
      public const string PricingDesk = "Pricing Desk";
      public const string MandatoryStatusFile = "Mandatory Status of File";
      public const string OptionalStatusFile = "Optional Status of File";

      public class LookupKeysRepository
      {
        public const string Issue = "Issue Repository";
        public const string Rfp = "RFP Repository";
        public const string Opportunity = "Opportunity Repository";
      }
    }

    public static class FirmOtherRole
    {
      public const int SellingGroupMember = -2;
    }

    public static class SyndicateMemberRole
    {
      public const int SoleMgr = -3;
      public const int SeniorMgr = -4;
      public const int JointSeniorMgrBookRunning = -10;
      public const int JointSeniorMgrNonBookRunning = -11;
      public const int CoSeniorMgrBookRunning = -5;
      public const int CoManager = -7;
      public const int CoSeniorMgrNonBookRunning = -6;
      public const int Participant = -8;
      public const int SellingGroupMember = -9;
    }

    public static class WinningSyndicateMemberRole
    {
      public const int SoleMgr = -82;
      public const int SeniorMgr = -81;
      public const int CoSeniorMgrBookRunning = -80;
      public const int CoSeniorMgrNonBookRunning = -79;
      public const int CoManager = -78;
      public const int Participant = -77;
      public const int SellingGroupMember = -76;
      public const int JointSeniorMgrBookRunning = -75;
      public const int JointSeniorMgrNonBookRunning = -74;
    }

    public static class PlatformRole
    {
      public const string Banker = "Banker";
      public const string Analyst = "Analyst";
      public const string ProfessionalSupport = "Professional Support";
      public const string Underwriter = "Underwriter";
      public const string BankRM = "Bank RM";
      public const string SupervisoryPrincipal = "Supervisory Principal Review Group";
    }

    public static class FirmRole
    {
      public const int SoleManager = -12;
      public const int SeniorManager = -13;
      public const int CoSeniorManager = -14;
      public const int CoManager = -16;
      public const int SellingGroup = -127;
      public const int PlacementAgent = -22;
      public const int JointSeniorManagerBookRunning = -20;
      public const int JointSeniorManagerNonBookRunning = -21;
      public const int RemarketingTakeover = -23;
      public const int SWAPCounterparty = -24;
      public const int RemarketAgentDealer = -25;
      public const int AdvisorMA = -125;
      public const int Other = -126;
    }

    public static class CrossSell
    {
      public const int Yes = -121;
      public const int No = -122;
    }

    public static class UploadCategory
    {
      public const string IssueEntity = "Issue";
      public const string RFPEntity = "RFP";
      public const string OpportunityEntity = "Opportunity";
    }

    public static class G37FormStatus
    {
      public const int Open = 354;
      public const int SentToCompliance = 355;
      public const int ReceivedByCompliance = 356;
    }

    public static class IssueClosureStatus
    {
      public const int Open = 357;
      public const int Submitted = 358;
      public const int Closed = 359;
    }

    public static class PartnerType
    {
      public const string SyndicateMember = "Syndicate Member";
      public const string AdvisorAgent = "Advisor/Agent";
      public const string Counsel = "Counsel";
      public const string OtherPartner = "Other Partner";
      public const string CreditEnhancementProvider = "Credit Enhancement Provider";
      public const long WinningSyndicateMemberTypeID = 68;
      public const long SyndicateMemberTypeID = 6;
      public const long AdvisoryAgentTypeID = 7;
      public const long CounselTypeID = 8;
      public const long OtherPartnerTypeID = 9;
      public const long SyndicateMemberID = -27;
      public const long AdvisoryAgentID = -28;
      public const long CounselID = -29;
      public const long OtherPartnerID = -30;
      public const long CreditEnhancementProviderID = -31;
      public const string WinningSyndicateAudit = "Winning Syndicate Members";
      public const string WinningSyndicateMember = "Syndicate Member";
    }

    public static class Entity
    {
      public const string RFP = "RFP";
      public const string Issue = "ISSUE";
      public const int RfpEntityID = 1;
      public const int IssueEntityID = -32;
      public const int OpportunityEntityID = -33;
      public const int Administration = -1;
      public const int G37FormEntityID = -34;
      public const int ContactEntityID = -83;
      public const int PnLEntityID = -34;
      public const int PnLCompEntityID = -35;
      public const int IssueCompEntityID = -31;
    }

    public static class EntityType
    {
      public const int ClientEntityID = -1;
      public const int IssueEntityID = -32;
      public const int OpportunityEntityID = -33;
      public const int RfpEntityID = 1;
      public const int HelpEntityID = -2;
      public const int BoilerplateEntityID = -4;
      public const int ContactsEntityID = -3;
      public const int PnLEntityID = -34;
      public const int IssueCompEntityID = -31;
      public const int PnLCompEntityID = -35;
      public const int G37EntityId = 0;
    }

    public static class G17Type
    {
      public const int RoleLetter = -70;
      public const int ConflictLetter = -71;
      public const int RoleAndConflictLetter = -72;
      public const int None = 511;
      public const int StructureLetter = -86;
    }

    public static class GoodFaithType
    {
      public const int NA = 570;
      public const int Check = 571;
      public const int Wire = 572;
    }

    public static class InterestRateType
    {
      public const int Fixed = 432;
      public const int Variable = 433;
      public const int CABs = 510;
      public const int VariableWOLiquidity = -120;
    }

    public static class IssueDocumentTypes
    {
      public const int ExecutedBPA_RA = -7;
      public const int ExecutedCDA = -8;
      public const int FinalOfferingStatement = -9;
      public const int IssuePriceCertificate = -10;
      public const int Transcript = -11;
      public const int UnderwriterCounselOpinion = -12;
      public const int FinalDealChecklist = -13;
      public const int G17LettersAndAcknowledgements = -14;
      public const int WrittenProofOfTransactionAward = -15;
      public const int IssuerCounselOpinion = -16;
      public const int MUCC = -1015;
      public const int SBPA_LOCAgreement = -1024;
      public const int RollLetter = -1040;
      public const int ConflictLetter = -1043;
      public const int RollLetterProofLetterWasSent = -1041;
      public const int RollLetterProofOfAcknowledgment = -1042;
      public const int ConflictLetterProofLetterWasSent = -1044;
      public const int ConflictLetterProofOfAcknowledgment = -1045;
      public const int RollAndConflictLetter = -1046;
      public const int RollAndConflictLetterProofLetterWasSent = -1047;
      public const int RollAndConflictLetterProofOfAcknowledgment = -1048;
      public const int StructureLetter = -1010;
      public const int StructureLetterProofLetterWasSent = -1011;
      public const int StructureLetterProofOfAcknowledgement = -1012;
    }

    public static class EntityTypeDocSet
    {
      public const int BoilerplateTransactionDoctSetID = -1;
      public const int BoilerplateOpptyDoctSetID = -2;
    }

    public static class ClientCategoryForIssueDocuments
    {
      public const int IRMAIssueCategory = -1;
      public const int IRMAClientCategory = -2;
    }

    public static class ClientDocTypesForIssueDocuments
    {
      public const int IRMAIssueDocType = -1;
      public const int ProofOfPerfectionIssueDocType = -2;
      public const int IRMAandProofOfPerfectionIssueDocType = -3;
      public const int IRMAClientDocType = -4;
      public const int ProofOfPerfectionClientDocType = -5;
      public const int IRMAandProofOfPerfectionClientDocType = -6;
    }

    public static class Repository
    {
      public static class Issue
      {
        public const long TransactionDocuments = 20;
        public const long NegotiatedMisc = 11;
        public const long NegotiatedPendingReview = 12;
        public const long ClientIssueCorrespondence = 13;
        public const long MERG = 14;
        public const long Compliance_Legal = 15;
        public const long SupervisoryPrincipal = 16;
        public const long DealFileChecklist = 17;
      }

      public static class CompetitveIssue
      {
        public const long TransactionDocuments = 28;
        public const long NegotiatedMisc = 11;
        public const long NegotiatedPendingReview = 12;
        public const long ClientIssueCorrespondence = 13;
        public const long MERG = 14;
        public const long Compliance_Legal = 15;
        public const long SupervisoryPrincipal = 16;
        public const long DealFileChecklist = 17;
      }

      public static class Rfp
      {
        public const long RFPMisc = 6;
        public const long RFPPendingReview = 7;
        public const long ClientRFPCorrespondence = 8;
        public const long Compliance_Legal = 9;
        public const long SupervisoryPrincipal = 10;
      }

      public static class Opportunity
      {
        public const long OpportunityMisc = 1;
        public const long OpportunityPendingReview = 2;
        public const long ClientOpportunityCorrespondence = 3;
        public const long Compliance_Legal = 4;
        public const long SupervisoryPrincipal = 5;
      }
    }

    public static class Enum
    {
      public enum PnLSectionID
      {
        EstimatedFinancingExpenses = 2,
      }

      public enum PnLCategoryID
      {
        Suspense = -63, // 0xFFFFFFC1
        EstimatedProjected = 4,
        EstimatedOutOfPocket = 5,
        EstimatedNotes = 6,
        EstimatedActual = 7,
        EstimatedDifference = 8,
        EstimatedWriteOff = 9,
      }

      public enum IssueStatus
      {
        Open = 3,
        Active = 4,
        Cancelled = 5,
        Closed = 6,
        Lost = 7,
        PendingClosure = 8,
        Postponed = 9,
        SubmittedToUnderwriter = 10, // 0x0000000A
      }

      public enum IssuePricingStatus
      {
        [Description("Final Pricing")] FinalPricing = -37, // 0xFFFFFFDB
        Repricing = -36, // 0xFFFFFFDC
        [Description("Preliminary Pricing")] PreliminaryPricing = -35, // 0xFFFFFFDD
      }

      public enum EmailTemplate
      {
        OpportunityMAExemption = 20, // 0x00000014
        RFPMAExemption = 49, // 0x00000031
        TransactionJobNumberRequested = 68, // 0x00000044
        IssueMAExemption = 104, // 0x00000068
        PnlApprovedForUnderwriter = 184, // 0x000000B8
        PnLWriteOff = 189, // 0x000000BD
        PnlApprovedForNonUnderwriter = 215, // 0x000000D7
        GoodFaithDetailInfo = 240, // 0x000000F0
      }

      public enum ConfigValue
      {
        RfpDocLibAbsUrl = 2,
        IssueDocLibPrimaryAbsUrl = 3,
        IssueDocLibRetentionUrl = 4,
        OpportunityDocLibPrimaryAbsUrl = 21, // 0x00000015
        OpportunityDocLibRetentionAbsUrl = 22, // 0x00000016
        RfpDocLibRetentionUrl = 23, // 0x00000017
        ClientDocLibPrimaryAbsUrl = 40, // 0x00000028
        BroadcastMessage = 57, // 0x00000039
      }

      public enum UploadCategory
      {
        SystemGenerated = -1, // 0xFFFFFFFF
        Mandatory = 1,
        [Description("Pre-Sales")] PreSales = 1,
        Others = 2,
        Underwriting = 2,
        [Description("IPREO Wires")] IPREOWires = 3,
        Issue = 3,
        Closing = 4,
        Final = 7,
        [Description("Transaction Reports")] TransactionReports = 8,
        RFP = 9,
        Opportunity = 10, // 0x0000000A
        AdditionalRequiredDocument = 13, // 0x0000000D
        Optional = 14, // 0x0000000E
      }

      public enum CompetitiveUploadCategory
      {
        SystemGenerated = -1, // 0xFFFFFFFF
        Mandatory = 1,
        [Description("Pre-Sales")] PreSales = 1,
        Others = 2,
        Underwriting = 2,
        [Description("IPREO Wires")] IPREOWires = 3,
        Issue = 3,
        Closing = 4,
        Final = 7,
        [Description("Transaction Reports")] TransactionReports = 8,
        RFP = 9,
        Opportunity = 10, // 0x0000000A
        Optional = 14, // 0x0000000E
        AdditionalRequiredDocument = 76, // 0x0000004C
        OptionalDocument = 77, // 0x0000004D
      }

      public enum UploadDocType
      {
        [Description("MUCC Presentation")] MUCCPresentation = -1049, // 0xFFFFFBE7
        [Description("MUCC")] MUCC = -1015, // 0xFFFFFC09
        [Description("Repricing")] Repricing = -62, // 0xFFFFFFC2
        [Description("Preliminary Pricing")] PreliminaryPricing = -61, // 0xFFFFFFC3
        [Description("Final Pricing")] FinalPricing = -60, // 0xFFFFFFC4
        [Description("Distribution List")] DistributionList = -59, // 0xFFFFFFC5
        [Description("Regulatory Requirements Checklist")] RegulatoryRequirementsChecklist = -54, // 0xFFFFFFCA
        [Description("Final Deal Checklist")] FinalDealChecklist = -13, // 0xFFFFFFF3
        [Description("Audit Trail")] AuditTrail = -6, // 0xFFFFFFFA
      }

      public enum CompetitiveUploadDocType
      {
        [Description("Regulatory Checklist")] RegulatoryChecklist = -1114, // 0xFFFFFBA6
        [Description("Deal File Checklist")] DealFileChecklist = -1113, // 0xFFFFFBA7
        [Description("MUCC Presentation")] MUCCPresentation = -1049, // 0xFFFFFBE7
        [Description("MUCC")] MUCC = -1015, // 0xFFFFFC09
        [Description("Repricing")] Repricing = -62, // 0xFFFFFFC2
        [Description("Preliminary Pricing")] PreliminaryPricing = -61, // 0xFFFFFFC3
        [Description("Final Pricing")] FinalPricing = -60, // 0xFFFFFFC4
        [Description("Distribution List")] DistributionList = -59, // 0xFFFFFFC5
        [Description("Regulatory Requirements Checklist")] RegulatoryRequirementsChecklist = -54, // 0xFFFFFFCA
        [Description("Final Deal Checklist")] FinalDealChecklist = -13, // 0xFFFFFFF3
        [Description("Audit Trail")] AuditTrail = -6, // 0xFFFFFFFA
      }
    }

    public static class EmailTemplate
    {
      public const int WeeklyMailToFrostBank = 1;
      public const int WeeklyEmailSentToOPS = 2;
      public const int EmailToJJKAndIpreo = 7;
      public const int PricingTemplate = 53;
      public const int IssueInfo = 52;
      public const int OpportunityInfo = 15;
      public const int RFPInfo = 50;
      public const int GoodFaithInfo = 158;

      public class Placeholder
      {
        public const string InternalPartnersPrimaryInvestmentBankingTeam = "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]";
        public const string InternalPartnersQuantInvestmentBankingTeam = "[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]";
        public const string InternalPartnersInvestmentBankingTeam = "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]";
        public const string InternalPartnersLeadAnalyst = "[INTERNAL-PARTNERS.LEAD-ANALYST]";
        public const string InternalPartnersAnalyst = "[INTERNAL-PARTNERS.ANALYST]";
        public const string InternalPartnersSupervisoryPrincipal = "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]";
        public const string InternalPartnersUnderwriter = "[INTERNAL-PARTNERS.SYNDICATE]";
        public const string InternalPartnersBankRM = "[INTERNAL-PARTNERS.BANKRM]";
        public const string Compliance = "[COMPLIANCE]";
        public const string Legal = "[LEGAL]";
        public const string MERG = "[MERG]";
        public const string CommitmentCommittee = "[COMMITMENTCOMMITTEE]";
        public const string Management = "[MANAGEMENT]";
        public const string FirmCredit = "[FIRMCREDIT]";
        public const string Operations = "[OPERATIONS]";
        public const string JobAdministrator = "[JOB-ADMINISTRATOR]";
        public const string PnLApprover = "[PNL-APPROVER]";
        public const string PnLAdministrator = "[PNL-ADMINISTRATOR]";
        public const string FinanceController = "[FINANCE-CONTROLLER]";
      }

      public class Issue
      {
        public const int Created = 31;
        public const int MarkActive = 3;
        public const int MarkPendingClosure = 32;
        public const int SubmittedToUnderwriter = 33;
        public const int MarkLost = 34;
        public const int MarkCancelled = 35;
        public const int MarkPostponed = 36;
        public const int MarkClosed = 26;
        public const int ActualAwardDateAndTimeUpdated = 5;
        public const int FinalOSReceivedDateAndTimeUpdated = 6;
        public const int DualProposalRequestedProposed = 105;

        public class IssueG37
        {
          public const int SubmitToCompliance = 4;
          public const int ReceivedByCompliance = 37;
        }

        public class IssuePlaceholder
        {
          public const string MSBankingGroup = "[MS-BANKING-GROUP]";
          public const string DateHired = "[DATE-HIRED]";
          public const string TypeofOffering = "[TYPE-OF-OFFERING]";
          public const string DealType = "[DEAL-TYPE]";
          public const string CrossSell = "[CROSS-SELL]";
          public const string CrossSellDetails = "[CROSS-SELL-DETAILS]";
          public const string SeriesParSeriesDescFedTax = "[SERIES_PAR-DESC-TAX]";
          public const string IssueName = "[TRANSACTION-DESCRIPTION]";
          public const string ReasonOfOnHold = "[REASON-OF-ON-HOLD]";
          public const string IssueNameWithLink = "[TRANSACTION-DESCRIPTION-WITH-LINK]";
          public const string IssuerName = "[ISSUER-NAME]";
          public const string IssuerAddress = "[ISSUER-ADDRESS]";
          public const string G17ContactPrefix = "[G-17-CONTACT-PREFIX]";
          public const string G17ContactFirstName = "[G-17-CONTACT-FIRST-NAME]";
          public const string G17ContactLastName = "[G-17-CONTACT-LAST-NAME]";
          public const string G17ContactSuffix = "[G17-CONTACT-SUFFIX]";
          public const string G17ContactJobTitle = "[G-17-CONTACT-TITLE]";
          public const string G17ContactAddress = "[G17-CONTACT-ADDRESS]";
          public const string G17ContactEmail = "[G17-CONTACT-EMAIL]";
          public const string TaxStatus = "[TAX-STATUS]";
          public const string IssuerNameWithLink = "[ISSUER-NAME-WITH-LINK]";
          public const string GoodFaithAmount = "[GOOD-FAITH-AMT]";
          public const string ParAmount = "[PAR-AMT]";
          public const string SeriesParAmount = "[SERIES-PAR-AMT]";
          public const string IssueDescription = "[ISSUE-DESCRIPTION]";
          public const string GoodFaithDate = "[GOOD-FAITH-DATE]";
          public const string GoodFaithType = "[GOOD-FAITH-TYPE]";
          public const string AccountName = "[ACCOUNT-NAME]";
          public const string AccountNumber = "[ACCOUNT-NUMBER]";
          public const string ABANumber = "[ABA-NUMBER]";
          public const string GoodFaithNotes = "[NOTES]";
          public const string GoodFaithInstructions = "[GOOD-FAITH-INSTRUCTIONS]";
          public const string ExpectedAwardDate = "[EXPECTED-AWARD-DATE]";
          public const string TicketDate = "[TICKET-DATE]";
          public const string LinkToPlatformDocs = "[LINK-TO-PLATFORM-DOCUMENTS]";
          public const string Series = "[SERIES-INFO]";
          public const string SeriesCode = "[SERIES-CODE]";
          public const string BorrowerObligor = "[BORROWER/OBLIGOR]";
          public const string StateTaxable = "[STATE-TAXABLE]";
          public const string FedTaxable = "[FED-TAXABLE]";
          public const string BankQualified = "[BANK-QUALIFIED]";
          public const string ExpectedBPASigning = "[EXPECTED-BPA-SIGNING]";
          public const string CommitteeApprovalDate = "[COMMITMENTS-COMMITTEE-APPROVAL-DATE]";
          public const string PNCRoleLiability = "[MS-ROLE-AND-LIABILITY]";
          public const string LeadManger = "[LEAD-MANAGER]";
          public const string OtherCoManager = "[OTHER-CO-MANAGERS]";
          public const string UnderlyingRating = "[UNDERLYING-RATING]";
          public const string ShortTermUnderlyingRating = "[SHORT-TERM-UNDERLYING-RATING]";
          public const string IssueUnderlyingRating = "[ISSUE-UNDERLYING-RATING]";
          public const string Insurance = "[INSURANCE]";
          public const string FinalMaturity = "[FINAL-MATURITY]";
          public const string ExpectedCallFeature = "[EXPECTED-CALL-FEATURE]";
          public const string Purpose = "[PURPOSE]";
          public const string Denominations = "[DENOMINATIONS]";
          public const string FinancialAdvisor = "[FINANCIAL-ADVISOR]";
          public const string PayingAgent = "[PAYING-AGENT]";
          public const string InsuredEnhancedRatings = "[INSURED/ENHANCED-RATINGS]";
          public const string UseOfProceeds = "[USE-OF-PROCEEDS]";
          public const string SecurityTypeGeneral = "[SECURITY-TYPE-GENERAL]";
          public const string Security = "[SECURITY]";
          public const string SecurityDetails = "[SECURITY-DETAILS]";
          public const string FirstCoupon = "[FIRST-COUPON]";
          public const string AccrueFrom = "[ACCRUE-FROM]";
          public const string Form = "[FORM]";
          public const string CouponFreq = "[COUPON-FREQ]";
          public const string DayCount = "[DAY-COUNT]";
          public const string RateType = "[RATE-TYPE]";
          public const string CallDate = "[CALL-DATE]";
          public const string CallPrice = "[CALL-PRICE]";
          public const string FirmInventory = "[FIRM-INVENTORY]";
          public const string PnLLink = "[PNL-LINK]";
          public const string JobNumber = "[JOB-NUMBER]";
          public const string LeadBanker = "[LEAD-BANKER]";
          public const string Supportingbanker = "[SUPPORTING-BANKER]";
          public const string SeriesJobNumber = "[SERIES-JOB-NUMBER]";
          public const string PricingSettlementDate = "[SERIES-DELIVERY-DATE]";
          public const string SeriesDatedDate = "[SERIES-DATED-DATE]";
          public const string SeriesPricingDate = "[SERIES-PRICING-DATE]";
          public const string SeriesROPDate = "[SERIES-ROP-DATE]";
          public const string SeriesActualAwardDate = "[SERIES-ACTUAL-AWARD-DATE]";
          public const string SeriesFirmRole = "[SERIES-FIRM-ROLE]";
          public const string SeriesFirmLiability = "[SERIES-FIRM-LIABILITY]";
          public const string SeriesFirmMgtFee = "[SERIES-FIRM-MGT-FEE]";
          public const string SeriesSDCCredit = "[SERIES-SDC-CREDIT]";
          public const string OSDeemedFinalDate = "[OS-DEEMED-FINAL-DATE]";
          public const string ConcatenatedPricingSettlementDate = "[CONC-SERIES-DELIVERY-DATE]";
          public const string ConcatenatedSeriesDatedDate = "[CONC-SERIES-DATED-DATE]";
          public const string ConcatenatedSeriesPricingDate = "[CONC-SERIES-PRICING-DATE]";
          public const string ConcatenatedSeriesROPDate = "[CONC-SERIES-ROP-DATE]";
          public const string ConcatenatedSeriesActualAwardDate = "[CONC-SERIES-ACTUAL-AWARD-DATE]";
          public const string ConcatenatedSeriesFirmRole = "[CONC-SERIES-FIRM-ROLE]";
          public const string ConcatenatedSeriesFirmLiability = "[CONC-SERIES-FIRM-LIABILITY]";
          public const string ConcatenatedSeriesFirmMgtFee = "[CONC-SERIES-FIRM-MGT-FEE]";
          public const string ConcatenatedSeriesSDCCredit = "[CONC-SERIES-SDC-CREDIT]";
          public const string PricingDate = "[PRICING-DATE]";
          public const string RopDate = "[ROP-DATE]";
          public const string SettlementDate = "[DELIVERY-DATE]";
          public const string ActualAwardDate = "[ACTUAL-AWARD-DATE]";
          public const string DatedDate = "[DATED-DATE]";
          public const string MSRole = "[MS-ROLE]";
          public const string FirmLiability = "[FIRM-LIABILITY]";
          public const string FirmMgtFee = "[FIRM-MGT-FEE]";
          public const string SDCCredit = "[SDC-CREDIT]";
          public const string ReviewComments = "[REVIEW-COMMENT]";
          public const string LT_ST_UnderlyingRating = "[LT-ST-Underlying-Rating]";
        }
      }

      public class RFP
      {
        public const int Created = 19;
        public const int Assigned = 20;
        public const int RevertToActive = 21;
        public const int MarkPendingReview = 22;
        public const int MarkApproved = 23;
        public const int MarkSubmitted = 24;
        public const int MarkRejected = 25;
        public const int MarkActive = 27;
        public const int MarkCancelled = 28;
        public const int MarkWon = 29;
        public const int MarkLost = 30;
        public const int IssueInitiated = 48;
        public const int DualProposalRequestedProposed = 51;

        public class RFPPlaceholder
        {
          public const string RfpName = "[RFP-NAME]";
          public const string RfpNameWithLink = "[RFP-NAME-WITH-LINK]";
          public const string IssuerName = "[ISSUER-NAME]";
          public const string IssuerNameWithLink = "[ISSUER-NAME-WITH-LINK]";
          public const string ParAmount = "[PAR-AMT]";
        }
      }

      public class Opportunity
      {
        public const int Created = 38;
        public const int MarkCompleted = 39;
        public const int SentForReview = 40;
        public const int Approved = 41;
        public const int Disapproved = 42;
        public const int MoreInfoNeeded = 43;
        public const int IssueInitiated = 10;
        public const int DualProposalRequestedProposed = 22;

        public class OpportunityPlaceholder
        {
          public const string OpportunityName = "[OPPORTUNITY-DESCRIPTION]";
          public const string OpportunityNameWithLink = "[OPPORTUNITY-DESCRIPTION-WITH-LINK]";
          public const string IssuerName = "[ISSUER-NAME]";
          public const string IssuerNameWithLink = "[ISSUER-NAME-WITH-LINK]";
          public const string ParAmount = "[PAR-AMT]";
          public const string AdditionalRFPDetails = "[ADDITIONAL-RFP-DETAILS]";
          public const string RFPType = "[RFP-TYPE]";
          public const string ResponseDueDate = "[RESPONSE-DUE-DATE]";
          public const string ResponseDueDateTimeZone = "[RESPONSE-DUE-DATE-TIME-ZONE]";
          public const string MSBankingGroup = "[MS-BANKING-GROUP]";
          public const string ProposedAverageTakedown = "[PROPOSED-AVERAGE-TAKEDOWN]";
          public const string ProposedManagementFee = "[PROPOSED-MANAGEMENT-FEE]";
          public const string ProposedUnderwriterExpenses = "[PROPOSED-UNDERWRITER-EXPENSES]";
          public const string ProposedGrossSpread = "[PROPOSE-GROSS-SPREAD]";
          public const string ExpectedFirmLiability = "[EXPECTED-FIRM-LIABILITY]";
          public const string ExpectedFirmMgmtFee = "[EXPECTED-FIRM-MGMT-FEE]";
          public const string EstimatedAverageTakedown = "[ESTIMATED-AVERAGE-TAKEDOWN]";
          public const string EstimatedRevenue = "[ESTIMATED-REVENUE]";
          public const string AdditionalInformationforCommitmentCommittee = "[ADDITIONAL-INFORMATION-FOR-COMMITMENT-COMMITTEE]";
          public const string BorrowerObligor = "[BORROWER/OBLIGOR]";
          public const string DealType = "[DEAL-TYPE]";
          public const string TypeOfOpportunity = "[TYPE-OF-OPPORTUNITY]";
          public const string G17ContactPrefix = "[G-17-CONTACT-PREFIX]";
          public const string G17ContactFirstName = "[G-17-CONTACT-FIRST-NAME]";
          public const string G17ContactLastName = "[G-17-CONTACT-LAST-NAME]";
          public const string G17ContactSuffix = "[G17-CONTACT-SUFFIX]";
          public const string G17ContactJobTitle = "[G-17-CONTACT-TITLE]";
          public const string G17ContactAddress = "[G17-CONTACT-ADDRESS]";
          public const string G17ContactEmail = "[G17-CONTACT-EMAIL]";
          public const string LeadBanker = "[LEAD-BANKER]";
          public const string Ratings = "[RATINGS]";
          public const string ExpectedFirmRole = "[EXPECTED-FIRM-ROLE]";
          public const string ExpectedPricingDate = "[EXPECTED-PRICING-DATE]";
          public const string WinningSyndicateNotes = "[WINNING-SYNDICATE-NOTES]";
          public const string WinningSyndicateMemberName = "[WINNING-SYNDICATE-MEMBER-NAME-ROLE]";
          public const string FirmRole = "[FIRM-ROLE]";
          public const string ReviewComments = "[REVIEW-COMMENT]";
        }
      }

      public class RoleID
      {
        public const int Compliance = 3;
        public const int Legal = 18;
        public const int MERGSecretary = 19;
        public const int JobAdministrator = 37;
        public const int CommitmentCommittee = 31;
        public const int Management = 29;
        public const int FirmCredit = 34;
        public const int Operations = 6;
        public const int PnLApprover = 35;
        public const int PnLAdministrator = 39;
        public const int FinanceController = 36;
      }
    }

    public static class PriorityOfOrders
    {
      public const string Retail = "Retail";
      public const string PreSale = "Pre-Sale";
      public const string NetDesignated = "Net Designated";
      public const string GroupNet = "Group Net";
      public const string Member = "Member";
    }

    public static class SearchScope
    {
      public const string IssueContentType = "iMPACT_CTypeIssueDocSet";
      public const string IssueDocumentMetadata = "iMPACT_CTypeDocumentMetadata";
    }

    public static class ExportType
    {
      public const string Excel = "excel";
      public const string Pdf = "pdf";
    }

    public static class ChecklistItem
    {
      public const int TransactionReport = 28;
    }

    public static class GoodFaithView
    {
      public const string BankerViewAlias = "banker";
      public const string OpsViewAlias = "ops";
    }

    public static class AdvisoryAgentType
    {
      public const int AuctionAgent = -38;
      public const int EscrowBiddingAgent = -39;
      public const int EscrowVerificationAgent = -40;
      public const int EscrowSecuritiesProvider = -41;
      public const int EscrowAgentForRefundedBonds = -42;
      public const int FinancialAdvisor = -43;
      public const int PayingAgent = -44;
      public const int RemarketingAgentOrCPDealer = -45;
      public const int Trustee = -46;
      public const int None = -47;
    }

    public static class AdvisoryRole
    {
      public const long AdvisorMunicipal = 37;
      public const long AdvisorNonMunicipal = 38;
      public const long FinancialAdvisor = 39;
    }

    public static class OpportunityTypes
    {
      public const long IntroMeeting = -48;
      public const long MarketUpdate = -49;
      public const long RefundingUpdate = -50;
      public const long RFP = -51;
      public const long ProposedFinancing = -52;
      public const long Underwriting = -53;
    }

    public static class DefaultBookmark
    {
      public const int Document = -5;
      public const int Client = -4;
      public const int Issue = -3;
      public const int RFP = -2;
      public const int Opportunity = -1;
    }

    public static class DataTypes
    {
      public const string Integer = "Integer";
      public const string Decimal = "Decimal";
      public const string Date = "Date";
      public const string DateTime = "DateTime";
    }

    public static class CSVType
    {
      public const int Google = 48;
      public const int Outlook = 49;
    }

    public static class AppConfigKey
    {
      public const int FirmLegalName = 1;
      public const int AllowMasterDataEditableOnFinalStageDeals = 52;
      public const int ShowPopupMessageWhenNewPnLTemplate = 78;
    }

    public static class DealType
    {
      public const int Corp = -129;
      public const int Muni = -128;
    }
  }
}
