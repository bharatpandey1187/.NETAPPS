﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.AppConfigPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (AppConfigPresenter))]
  public class AppConfigPresenter : PresenterBase
  {
    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    public AppConfigViewModelContainer FetchAllAppConfigReport()
    {
      try
      {
        return new AppConfigViewModelContainer()
        {
          AppConfig = this.AppConfigRepository.FetchAll().Select<AppConfig, AppConfigViewModel>((Func<AppConfig, AppConfigViewModel>) (x => new AppConfigViewModel(x))).ToList<AppConfigViewModel>(),
          IsViewOnly = !this.HasIndependentPermission("Application Configuration", "Edit")
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new AppConfigViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult SaveAppConfigItems(List<AppConfigViewModel> appConfigReportViewModel)
    {
      try
      {
        this.GetSafeObject<AppConfigViewModel>(appConfigReportViewModel);
        List<SaveResult> saveResults = new List<SaveResult>();
        SaveResult saveResult1 = new SaveResult();
        foreach (AppConfigViewModel appConfigItem in appConfigReportViewModel)
        {
          if (!(appConfigItem.Key.ToUpper().Trim() == "BROADCASTMESSAGE"))
          {
            if (string.IsNullOrEmpty(appConfigItem.Value))
            {
              SaveResult saveResult2 = new SaveResult();
              string str = string.Format("{0} cannot be blank.", (object) appConfigItem.Descr);
              saveResult2.Errors.Add(appConfigItem.Key, (object) str);
              saveResult2.Id = appConfigItem.AppConfigID;
              saveResults.Add(saveResult2);
            }
            else
              this.ValidateDataTypeForKey(appConfigItem, ref saveResults);
          }
        }
        SaveResult saveResult3 = new SaveResult();
        if (saveResults.Count <= 0)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            this.AppConfigRepository.SaveConfigValues(appConfigReportViewModel.Select<AppConfigViewModel, AppConfig>((Func<AppConfigViewModel, AppConfig>) (x => x.GetAppConfigItem())).ToList<AppConfig>());
            transactionScope.Complete();
          }
        }
        else
          saveResult3.Errors.Add("AppConfig", (object) saveResults);
        return saveResult3;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private bool IsValidEmail(string source) => true;

    private void ValidateDataType(
      List<AppConfigViewModel> appConfigReportViewModel,
      ref List<SaveResult> saveResults)
    {
      foreach (AppConfigViewModel appConfigViewModel in appConfigReportViewModel)
      {
        if (!(appConfigViewModel.Value == string.Empty))
        {
          if (appConfigViewModel.Type == "email" && !this.IsValidEmail(appConfigViewModel.Value))
            saveResults.Add(new SaveResult()
            {
              Errors = {
                {
                  appConfigViewModel.Key,
                  (object) ("Invalid email for " + appConfigViewModel.Descr)
                }
              }
            });
          if (appConfigViewModel.Type == "url")
          {
            Uri result;
            Uri.TryCreate(appConfigViewModel.Value, UriKind.RelativeOrAbsolute, out result);
            if (result == (Uri) null || !result.IsAbsoluteUri)
              saveResults.Add(new SaveResult()
              {
                Errors = {
                  {
                    appConfigViewModel.Key,
                    (object) ("Invalid URL for " + appConfigViewModel.Descr)
                  }
                }
              });
          }
          if (appConfigViewModel.Type == "int" && !int.TryParse(appConfigViewModel.Value, out int _))
            saveResults.Add(new SaveResult()
            {
              Errors = {
                {
                  appConfigViewModel.Key,
                  (object) ("Invalid value for " + appConfigViewModel.Descr)
                }
              }
            });
          if (appConfigViewModel.Type == "date" && !DateTime.TryParse(appConfigViewModel.Value, out DateTime _))
            saveResults.Add(new SaveResult()
            {
              Errors = {
                {
                  appConfigViewModel.Key,
                  (object) ("Invalid value for " + appConfigViewModel.Descr)
                }
              }
            });
        }
      }
    }

    private void ValidateDataTypeForKey(
      AppConfigViewModel appConfigItem,
      ref List<SaveResult> saveResults)
    {
      if (appConfigItem.Type.ToLower() == "string" && !Regex.IsMatch(appConfigItem.Value, "^$|(^[A-Za-z0-9-\\\\',;()@&. /_]+$)", RegexOptions.IgnoreCase))
        saveResults.Add(new SaveResult()
        {
          Errors = {
            {
              appConfigItem.Key,
              (object) ("Invalid email for " + appConfigItem.Descr)
            }
          }
        });
      if (appConfigItem.Type.ToLower() == "email" && !Regex.IsMatch(appConfigItem.Value, "^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", RegexOptions.IgnoreCase))
        saveResults.Add(new SaveResult()
        {
          Errors = {
            {
              appConfigItem.Key,
              (object) ("Invalid email for " + appConfigItem.Descr)
            }
          }
        });
      if (appConfigItem.Type.ToLower() == "url")
      {
        Uri result;
        Uri.TryCreate(appConfigItem.Value, UriKind.RelativeOrAbsolute, out result);
        if (result == (Uri) null || !result.IsAbsoluteUri)
          saveResults.Add(new SaveResult()
          {
            Errors = {
              {
                appConfigItem.Key,
                (object) ("Invalid URL for " + appConfigItem.Descr)
              }
            }
          });
      }
      if (appConfigItem.Type.ToLower() == "int" && !int.TryParse(appConfigItem.Value, out int _))
        saveResults.Add(new SaveResult()
        {
          Errors = {
            {
              appConfigItem.Key,
              (object) ("Invalid value for " + appConfigItem.Descr)
            }
          }
        });
      if (appConfigItem.Type.ToLower() == "date" && !DateTime.TryParse(appConfigItem.Value, out DateTime _))
        saveResults.Add(new SaveResult()
        {
          Errors = {
            {
              appConfigItem.Key,
              (object) ("Invalid value for " + appConfigItem.Descr)
            }
          }
        });
      if (!(appConfigItem.Type.ToLower() == "alert"))
        return;
      bool IsValidationPassed1 = true;
      int count = Regex.Matches(appConfigItem.Value, ";").Count;
      SaveResult saveResult = new SaveResult();
      bool flag;
      if (count == 1)
      {
        string[] str = appConfigItem.Value.Split(';');
        int index1 = 0;
        if (str.Length == 2)
        {
          bool IsValidationPassed2 = this.ValidateNumericType(IsValidationPassed1, str, index1);
          int index2 = 1;
          flag = this.ValidateNumericType(IsValidationPassed2, str, index2);
        }
        else
          flag = false;
      }
      else
        flag = false;
      if (flag)
        return;
      saveResult.Errors.Add(appConfigItem.Key, (object) ("Invalid value for " + appConfigItem.Descr + ". value must be in X;Y format."));
      saveResults.Add(saveResult);
    }

    private bool ValidateNumericType(bool IsValidationPassed, string[] str, int index)
    {
      if (!string.IsNullOrEmpty(str[index]))
      {
        if (!int.TryParse(str[index], out int _))
          IsValidationPassed = false;
      }
      else
        IsValidationPassed = false;
      return IsValidationPassed;
    }
  }
}
