﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.TemplatePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (TemplatePresenter))]
  public class TemplatePresenter : PresenterBase
  {
    [Dependency]
    public ITemplateRepository TemplateRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public TemplateViewModelContainer GetAllTemplates()
    {
      try
      {
        return new TemplateViewModelContainer()
        {
          Templates = this.TemplateRepository.FetchAll().Select<Template, TemplateViewModel>((Func<Template, TemplateViewModel>) (x => new TemplateViewModel(x))).ToList<TemplateViewModel>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        TemplateViewModelContainer viewModelContainer = new TemplateViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public TemplateViewModelContainer GetTemplatesByEntity(long entityID)
    {
      try
      {
        return new TemplateViewModelContainer()
        {
          Templates = this.TemplateRepository.FetchAll().ToList<Template>().Where<Template>((Func<Template, bool>) (x => x.EntityID == entityID)).Select<Template, TemplateViewModel>((Func<Template, TemplateViewModel>) (x => new TemplateViewModel(x))).ToList<TemplateViewModel>(),
          IsViewOnly = false
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        TemplateViewModelContainer viewModelContainer = new TemplateViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public TemplateFieldViewModelContainer GetTemplateFieldByTemplateID(
      long templateId)
    {
      try
      {
        return new TemplateFieldViewModelContainer()
        {
          TemplateFields = this.TemplateRepository.FetchByTemplateID(templateId).Where<TemplateField>((Func<TemplateField, bool>) (m => m.FieldID > 0L)).ToList<TemplateField>().Select<TemplateField, TemplateFieldViewModel>((Func<TemplateField, TemplateFieldViewModel>) (x => new TemplateFieldViewModel(x))).ToList<TemplateFieldViewModel>(),
          DataTypes = this.LookupRepository.FetchByLookupKey("Data Type").Select<LookupItem, KeyPair>((Func<LookupItem, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>(),
          IsViewOnly = false
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new TemplateFieldViewModelContainer();
      }
    }

    public List<TemplateFieldViewModel> GetAllTemplateFieldByTemplateID(
      long templateId)
    {
      try
      {
        return this.TemplateRepository.FetchByTemplateID(templateId).ToList<TemplateField>().Select<TemplateField, TemplateFieldViewModel>((Func<TemplateField, TemplateFieldViewModel>) (x => new TemplateFieldViewModel(x))).ToList<TemplateFieldViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<TemplateFieldViewModel>();
      }
    }

    public SaveResult SaveTemplate(TemplateViewModel templateViewModel)
    {
      try
      {
        this.GetSafeObject<TemplateViewModel>(templateViewModel);
        SaveResult saveResult = templateViewModel.Validate<TemplateViewModel>();
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.TemplateRepository.Save(templateViewModel.GetTemplate(templateViewModel), templateViewModel.CopyTemplateID);
            if (num == -100L)
              saveResult.Errors.Add("Template Name", (object) "Template Name has already been added.");
            if (num == -101L)
              saveResult.Errors.Add("With Effect From", (object) "With Effect From can't be duplicate.");
            transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SaveTemplateFields(
      List<TemplateFieldViewModel> templateFieldViewModel)
    {
      try
      {
        this.GetSafeObject<TemplateFieldViewModel>(templateFieldViewModel);
        List<SaveResult> saveResultList = new List<SaveResult>();
        foreach (TemplateFieldViewModel templateFieldViewModel1 in templateFieldViewModel)
        {
          SaveResult saveResult = templateFieldViewModel1.Validate<TemplateFieldViewModel>();
          if (!saveResult.IsSuccessful)
          {
            saveResult.Id = templateFieldViewModel1.FieldID;
            saveResultList.Add(saveResult);
          }
        }
        if (saveResultList.Count > 0)
          return new SaveResult()
          {
            Errors = {
              {
                "LookupItems",
                (object) saveResultList
              }
            }
          };
        using (TransactionScope transactionScope = new TransactionScope())
        {
          foreach (TemplateFieldViewModel templateFieldViewModel1 in templateFieldViewModel)
          {
            string name;
            string str = name = this.AppUser.Name;
            templateFieldViewModel1.ModeifiedBy = name;
            templateFieldViewModel1.CreatedBy = str;
          }
          this.TemplateRepository.SaveTemplateFields(templateFieldViewModel.Select<TemplateFieldViewModel, TemplateField>((Func<TemplateFieldViewModel, TemplateField>) (x => x.GetTemplateField())).ToList<TemplateField>());
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public LookupItemViewModelContainer FetchAllEntities()
    {
      try
      {
        return new LookupItemViewModelContainer()
        {
          IsViewOnly = !this.HasIndependentPermission("Reference Data", "Edit"),
          LookupItems = this.LookupRepository.FetchByLookupKey("Entity").Select<LookupItem, LookupItemViewModel>((Func<LookupItem, LookupItemViewModel>) (x => new LookupItemViewModel(x))).ToList<LookupItemViewModel>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        LookupItemViewModelContainer viewModelContainer = new LookupItemViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }
  }
}
