﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.SendEmailPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.Mail;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (SendEmailPresenter))]
  public class SendEmailPresenter : PresenterBase
  {
    [Dependency]
    public ISendEmailRepository SendEmailRepository { get; set; }

    [Dependency]
    public IMailSender Smtpsender { get; set; }

    private void SetRecipients(MailAddressCollection adrCollection, string recipients)
    {
      foreach (string addresses in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        if (!string.IsNullOrEmpty(addresses.Trim()))
          adrCollection.Add(addresses);
      }
    }

    public EmailCallback SendEmail(SendEmailModel model)
    {
      EmailCallback emailCallback = new EmailCallback();
      try
      {
        using (MailMessage message = new MailMessage())
        {
          message.From = new MailAddress(this.AppUser.Email);
          if (!string.IsNullOrEmpty(model.EmailTo))
            this.SetRecipients(message.To, model.EmailTo);
          if (!string.IsNullOrEmpty(model.EmailCC))
            this.SetRecipients(message.CC, model.EmailCC);
          if (!string.IsNullOrEmpty(this.AppUser.Email))
            message.CC.Add(new MailAddress(this.AppUser.Email));
          message.Subject = model.EmailSubject;
          message.Body = model.EmailContent;
          message.IsBodyHtml = true;
          this.Smtpsender.Send(message);
          string empty = string.Empty;
          this.SendEmailRepository.SaveToEmailLog(DateTime.Now, SPContext.get_Current().get_Web().get_CurrentUser().get_Email(), Convert.ToString((object) message.To), Convert.ToString((object) message.CC), Convert.ToString(message.Subject), Convert.ToString(message.Body));
          emailCallback.IsSuccessful = true;
        }
      }
      catch (SmtpFailedRecipientsException ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        StringBuilder stringBuilder = new StringBuilder();
        for (int index = 0; index < ex.InnerExceptions.Length; ++index)
        {
          if (!stringBuilder.ToString().Contains(ex.InnerExceptions[index].FailedRecipient.ToString()))
            stringBuilder.Append(ex.InnerExceptions[index].FailedRecipient.ToString() + ";");
        }
        emailCallback.IsSuccessful = true;
        emailCallback.FailedRecipient = stringBuilder.ToString().Replace("<", "").Replace(">", "");
      }
      catch (SmtpFailedRecipientException ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        emailCallback.IsSuccessful = true;
        emailCallback.FailedRecipient = ex.FailedRecipient.Replace("<", "").Replace(">", "") + ";";
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        emailCallback.IsSuccessful = false;
      }
      return emailCallback;
    }

    public EmailCallback SendEmail(SendEmailModel model, List<Attachment> attachments)
    {
      EmailCallback emailCallback = new EmailCallback();
      try
      {
        using (MailMessage message = new MailMessage())
        {
          message.From = new MailAddress(this.AppUser.Email);
          this.SetRecipients(message.To, model.EmailTo);
          this.SetRecipients(message.CC, model.EmailCC);
          if (!string.IsNullOrEmpty(this.AppUser.Email))
            message.CC.Add(new MailAddress(this.AppUser.Email));
          message.Subject = model.EmailSubject;
          message.Body = model.EmailContent;
          message.IsBodyHtml = true;
          foreach (Attachment attachment in attachments)
            message.Attachments.Add(attachment);
          this.Smtpsender.Send(message);
          string empty = string.Empty;
          this.SendEmailRepository.SaveToEmailLog(DateTime.Now, SPContext.get_Current().get_Web().get_CurrentUser().get_Email(), Convert.ToString((object) message.To), Convert.ToString((object) message.CC), Convert.ToString(message.Subject), Convert.ToString(message.Body));
          emailCallback.IsSuccessful = true;
        }
      }
      catch (SmtpFailedRecipientsException ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        StringBuilder stringBuilder = new StringBuilder();
        for (int index = 0; index < ex.InnerExceptions.Length; ++index)
        {
          if (!stringBuilder.ToString().Contains(ex.InnerExceptions[index].FailedRecipient.ToString()))
            stringBuilder.Append(ex.InnerExceptions[index].FailedRecipient.ToString() + ";");
        }
        emailCallback.IsSuccessful = true;
        emailCallback.FailedRecipient = stringBuilder.ToString().Replace("<", "").Replace(">", "");
      }
      catch (SmtpFailedRecipientException ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        emailCallback.IsSuccessful = true;
        emailCallback.FailedRecipient = ex.FailedRecipient.Replace("<", "").Replace(">", "") + ";";
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        emailCallback.IsSuccessful = false;
      }
      return emailCallback;
    }
  }
}
