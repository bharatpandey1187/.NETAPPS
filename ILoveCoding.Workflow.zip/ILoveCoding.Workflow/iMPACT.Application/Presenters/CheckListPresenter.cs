﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.CheckListPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (CheckListPresenter))]
  public class CheckListPresenter : PresenterBase
  {
    [Dependency]
    public ICheckListRepository CheckListRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public CheckListCategoryViewModelContainer FetchAllCheckListCategoriesByEntityID(
      int entityID)
    {
      try
      {
        return new CheckListCategoryViewModelContainer()
        {
          CheckListCategories = this.CheckListRepository.FetchCheckListCategoryByEntityId((long) entityID).Select<CheckListCategory, CheckListCategoryViewModel>((Func<CheckListCategory, CheckListCategoryViewModel>) (x => new CheckListCategoryViewModel(x))).ToList<CheckListCategoryViewModel>(),
          IsViewOnly = !this.HasIndependentPermission("Checklist Master", "Edit")
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new CheckListCategoryViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public LookupItemViewModelContainer FetchAllEntities()
    {
      try
      {
        return new LookupItemViewModelContainer()
        {
          IsViewOnly = !this.HasIndependentPermission("Reference Data", "Edit"),
          LookupItems = this.LookupRepository.FetchByLookupKey("Entity").Select<LookupItem, LookupItemViewModel>((Func<LookupItem, LookupItemViewModel>) (x => new LookupItemViewModel(x))).ToList<LookupItemViewModel>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        LookupItemViewModelContainer viewModelContainer = new LookupItemViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public CheckListCategoryItemsViewModelContainer FetchCheckListItemsByCategoryID(
      long? checkListCategoryId)
    {
      try
      {
        return new CheckListCategoryItemsViewModelContainer()
        {
          CheckListCategoryItems = this.CheckListRepository.FetchByCheckListItemsByCategoryID(checkListCategoryId).Select<CheckListCategoryItems, CheckListCategoryItemsViewModel>((Func<CheckListCategoryItems, CheckListCategoryItemsViewModel>) (x => new CheckListCategoryItemsViewModel(x))).ToList<CheckListCategoryItemsViewModel>(),
          IsViewOnly = !this.HasIndependentPermission("Checklist Master", "Edit")
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new CheckListCategoryItemsViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult SaveCheckListCategoryItems(
      List<CheckListCategoryItemsViewModel> checkListCategoryItemsViewModel)
    {
      try
      {
        this.GetSafeObject<CheckListCategoryItemsViewModel>(checkListCategoryItemsViewModel);
        List<SaveResult> saveResultList = new List<SaveResult>();
        foreach (CheckListCategoryItemsViewModel categoryItemsViewModel in checkListCategoryItemsViewModel)
        {
          SaveResult saveResult = categoryItemsViewModel.Validate<CheckListCategoryItemsViewModel>();
          if (!saveResult.IsSuccessful)
          {
            saveResult.Id = categoryItemsViewModel.ChecklistItemID.Value;
            saveResultList.Add(saveResult);
          }
        }
        if (saveResultList.Count > 0)
          return new SaveResult()
          {
            Errors = {
              {
                "CheckList Item Description",
                (object) saveResultList
              }
            }
          };
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.CheckListRepository.SaveCheckListCategoryItems(checkListCategoryItemsViewModel.Select<CheckListCategoryItemsViewModel, CheckListCategoryItems>((Func<CheckListCategoryItemsViewModel, CheckListCategoryItems>) (x => x.GetCheckListCategoryItems())).ToList<CheckListCategoryItems>());
          transactionScope.Complete();
          return SaveResult.Success;
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SaveCheckListCategory(
      CheckListCategoryViewModel checkListCategoryViewModel)
    {
      try
      {
        this.GetSafeObject<CheckListCategoryViewModel>(checkListCategoryViewModel);
        SaveResult saveResult = checkListCategoryViewModel.Validate<CheckListCategoryViewModel>();
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            if (this.CheckListRepository.SaveCheckListCategory(checkListCategoryViewModel.GetCheckListCategory(checkListCategoryViewModel)) == -100L)
              saveResult.Errors.Add("Category name", (object) "Selected Category Name has already been added.");
            transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }
  }
}
