﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.EntityContactPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (EntityContactPresenter))]
  public class EntityContactPresenter : PresenterBase
  {
    [Dependency]
    public IEntityContactRepository EntityContactRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public IssueClientContactViewModelContainer FetchIssueClientContactsByKey(
      long currentId,
      long appTransactionID,
      string clientType)
    {
      try
      {
        IssueClientContactViewModelContainer viewModelContainer = new IssueClientContactViewModelContainer();
        IssueClientContactAddress clientContactAddress = this.EntityContactRepository.FetchIssueClientContactsByKey(currentId, appTransactionID, clientType);
        viewModelContainer.IssueClientContacts = clientContactAddress.IssueClientContact.Select<IssueClientContact, IssueClientContactViewModel>((Func<IssueClientContact, IssueClientContactViewModel>) (x => new IssueClientContactViewModel(x))).ToList<IssueClientContactViewModel>();
        viewModelContainer.ClientActiveAddress = clientContactAddress.ClientActiveAddress;
        viewModelContainer.IsAddContact = !this.HasIndependentPermission("Client Contact", "Add");
        viewModelContainer.IsEditContact = !this.HasIndependentPermission("Client Contact", "Edit");
        viewModelContainer.IssuerContactTitle = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetLookupItemKeys()).Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Contact Title")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new IssueClientContactViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult SaveIssueClientContacts(
      IssueClientContactViewModel issueClientContactViewModel)
    {
      try
      {
        this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetLookupItemKeys());
        this.GetSafeObject<IssueClientContactViewModel>(issueClientContactViewModel);
        SaveResult saveResult = issueClientContactViewModel.Validate<IssueClientContactViewModel>();
        if (saveResult.IsSuccessful)
        {
          string clientName = string.Empty;
          using (TransactionScope transactionScope = new TransactionScope())
          {
            long num = this.EntityContactRepository.SaveIssueClientContacts(issueClientContactViewModel.GetIssueClientContactDetail(), out clientName);
            saveResult.Id = num;
            if (num == -200L)
            {
              string str = "Contacts cannot have same email address.";
              if (issueClientContactViewModel.ClientName.Trim().ToUpper() != clientName.Trim().ToUpper())
                str = "The Contact's Email has already been used for client '" + clientName + "'.";
              saveResult.Errors.Add("Contact Email", (object) str);
            }
            if (saveResult.IsSuccessful)
              transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public EntityPartnerContactViewModelContainer FetchPartnerContactsByKey(
      long currentId,
      long appTransactionID,
      long externalPartnerID)
    {
      try
      {
        EntityPartnerContactViewModelContainer viewModelContainer = new EntityPartnerContactViewModelContainer();
        List<IssuePartnerContact> source1 = new List<IssuePartnerContact>();
        List<PartnerActiveAddress> partnerActiveAddressList = new List<PartnerActiveAddress>();
        using (IDataReader dataReader = this.EntityContactRepository.FetchPartnerContactsByKey(currentId, appTransactionID, externalPartnerID))
        {
          if (dataReader != null)
          {
            while (dataReader.Read())
              viewModelContainer.IssuePartner = new Partner()
              {
                PartnerID = currentId,
                Name = dataReader["PartnerName"].ToString()
              };
            if (dataReader.NextResult())
            {
              IRowMapper<IssuePartnerContact> rowMapper = MapBuilder<IssuePartnerContact>.MapAllProperties().Build();
              while (dataReader.Read())
                source1.Add(rowMapper.MapRow((IDataRecord) dataReader));
            }
            if (dataReader.NextResult())
            {
              IRowMapper<PartnerActiveAddress> rowMapper = MapBuilder<PartnerActiveAddress>.MapAllProperties().Build();
              while (dataReader.Read())
                partnerActiveAddressList.Add(rowMapper.MapRow((IDataRecord) dataReader));
            }
          }
        }
        List<EntityPartnerContactViewModel> list = source1.Select<IssuePartnerContact, EntityPartnerContactViewModel>((Func<IssuePartnerContact, EntityPartnerContactViewModel>) (x => new EntityPartnerContactViewModel(x))).ToList<EntityPartnerContactViewModel>();
        viewModelContainer.IssuePartnerContacts = list;
        viewModelContainer.PartnerActiveAddress = partnerActiveAddressList;
        viewModelContainer.IsAddContact = !this.HasIndependentPermission("Partner Contacts", "Add");
        viewModelContainer.IsEditContact = !this.HasIndependentPermission("Partner Contacts", "Edit");
        IEnumerable<LookupItemMappings> source2 = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetLookupItemKeys());
        viewModelContainer.IssuerContactTitle = source2.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Contact Title")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new EntityPartnerContactViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult SavePartnerContacts(
      EntityPartnerContactViewModel issuePartnerContactViewModel)
    {
      try
      {
        this.GetSafeObject<EntityPartnerContactViewModel>(issuePartnerContactViewModel);
        SaveResult saveResult = issuePartnerContactViewModel.Validate<EntityPartnerContactViewModel>();
        if (saveResult.IsSuccessful)
        {
          string partnerName = string.Empty;
          using (TransactionScope transactionScope = new TransactionScope())
          {
            IssuePartnerContact partnerContactDetail = issuePartnerContactViewModel.GetIssuePartnerContactDetail();
            long num = this.EntityContactRepository.SavePartnerContacts(partnerContactDetail, out partnerName);
            saveResult.Id = num;
            if (num == -200L)
            {
              string str = "Contacts cannot have same email address.";
              if (partnerContactDetail.PartnerName.Trim().ToUpper() != partnerName.Trim().ToUpper())
                str = "The Contact's Email has already been used for Partner '" + partnerName + "'.";
              saveResult.Errors.Add("Contact Email", (object) str);
            }
            if (saveResult.IsSuccessful)
              transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private string[] GetLookupItemKeys() => new string[23]
    {
      "Issue Status",
      "MA Exemption",
      "Firm Role",
      "Additional Firm Role(s)",
      "Syndicate Structure",
      "Type of Offering",
      "Insurance Provider",
      "State",
      "DSRF",
      "Purpose",
      "Transaction Type",
      "Credit Enhancement Program",
      "MS Banking Group",
      "Bid Platform",
      "Bid Calc",
      "Syndicate Member Role",
      "Winning Syndicate Member Role",
      "Advisory Agent Type",
      "Counsel Type",
      "Other Partner Type",
      "Issue Status",
      "MERG Review Type",
      "Contact Title"
    };
  }
}
