﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.MergInfoReportPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (MergInfoReportPresenter))]
  public class MergInfoReportPresenter : PresenterBase
  {
    [Dependency]
    public IMergInfoReportRepository MergInfoReportRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public MergInfoReportSearchViewModel InitializeViewModel() => new MergInfoReportSearchViewModel()
    {
      ExemptionTypes = this.LookupRepository.FetchByLookupKey("MA Exemption").Select<LookupItem, KeyValuePair<long, string>>((Func<LookupItem, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>()
    };

    public Paged<MergInfoReportViewModel> GetMergInfoReport(
      KendoGridRequest request,
      MergInfoReportSearchViewModel model)
    {
      try
      {
        long total = 0;
        return new Paged<MergInfoReportViewModel>((IList<MergInfoReportViewModel>) this.GetSearchData(request, model, out total), total);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new Paged<MergInfoReportViewModel>((IList<MergInfoReportViewModel>) new List<MergInfoReportViewModel>(), 0L);
      }
    }

    private List<MergInfoReportViewModel> GetSearchData(
      KendoGridRequest request,
      MergInfoReportSearchViewModel model,
      out long total)
    {
      total = 0L;
      List<MergInfoReportViewModel> infoReportViewModelList = new List<MergInfoReportViewModel>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      if (string.IsNullOrEmpty(model.LeadBanker))
        model.LeadBankerEmployeeId = 0L;
      if (string.IsNullOrEmpty(model.SupervisoryPrincipal))
        model.SPEmployeeId = 0L;
      MergInfoReportSearchViewModel reportSearchViewModel = model;
      DateTime? dateTo;
      DateTime dateTime;
      if (!model.dateTo.HasValue)
      {
        dateTime = DateTime.Today.AddDays(1.0).AddSeconds(-1.0);
      }
      else
      {
        dateTo = model.dateTo;
        dateTime = dateTo.Value.AddDays(1.0).AddSeconds(-1.0);
      }
      DateTime? nullable = new DateTime?(dateTime);
      reportSearchViewModel.dateTo = nullable;
      string[] array1 = model.SelectedExemtionTypes.Select<KeyPair, string>((Func<KeyPair, string>) (x => x.Value)).ToArray<string>();
      string str = (string) null;
      if (array1.Length != 0)
        str = string.Join(",", array1);
      IMergInfoReportRepository reportRepository = this.MergInfoReportRepository;
      DateTime dateFrom = model.dateFrom;
      dateTo = model.dateTo;
      DateTime toDate = dateTo.Value;
      long? leadBankerEmpID = new long?(model.LeadBankerEmployeeId);
      long? supervisoryPrincipalEmpID = new long?(model.SPEmployeeId);
      string ExemtionType = str;
      Ordering[] array2 = orderingList.ToArray();
      int skip = (int) request.skip;
      int take = request.take;
      using (IDataReader dataReader = reportRepository.FetchMergInfoReportData(dateFrom, toDate, leadBankerEmpID, supervisoryPrincipalEmpID, ExemtionType, 1, array2, skip, take))
      {
        if (dataReader != null)
        {
          IRowMapper<MergInfoReportViewModel> rowMapper = MapBuilder<MergInfoReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            infoReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return infoReportViewModelList;
    }

    public ExportResult Export(
      KendoGridRequest request,
      MergInfoReportSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        List<MergInfoReportViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _);
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        IEnumerable<\u003C\u003Ef__AnonymousType11<string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string, string>> datas = searchData.Select(d =>
        {
          string dealNumber = d.DealNumber;
          string issuer = d.Issuer;
          string leadBanker = d.LeadBanker;
          string banker2 = d.Banker2;
          string issuerState = d.IssuerState;
          string generalCategory = d.GeneralCategory;
          string opportunityDescription = d.OpportunityDescription;
          string existingRelationship = d.ExistingRelationship;
          string rfpMaExamption = d.RfpMaExamption;
          DateTime rfpMaExamptionDate = d.RfpMaExamptionDate;
          DateTime dateTime;
          string str1;
          if (!(d.RfpMaExamptionDate.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.RfpMaExamptionDate;
            str1 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str1 = "";
          string uwMaExamption = d.UwMaExamption;
          DateTime uwMaExamptionDate = d.UwMaExamptionDate;
          dateTime = d.UwMaExamptionDate;
          string str2;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.UwMaExamptionDate;
            str2 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str2 = "";
          string irmaMaExamption = d.IrmaMaExamption;
          DateTime irmaMaExamptionDate = d.IrmaMaExamptionDate;
          dateTime = d.IrmaMaExamptionDate;
          string str3;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.IrmaMaExamptionDate;
            str3 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str3 = "";
          string principalApproverName = d.PrincipalApproverName;
          string derivativeMarketer = d.ApprovedDerivativeMarketer;
          DateTime opportunityCreatedDate = d.OpportunityCreatedDate;
          dateTime = d.OpportunityCreatedDate;
          string str4;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.OpportunityCreatedDate;
            str4 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str4 = "";
          DateTime rfpCreatedDate = d.RFPCreatedDate;
          dateTime = d.RFPCreatedDate;
          string str5;
          if (!(dateTime.ToString("MM/dd/yyyy") == "01/01/0001"))
          {
            dateTime = d.RFPCreatedDate;
            str5 = dateTime.ToString("MM/dd/yyyy");
          }
          else
            str5 = "";
          return new
          {
            DealNumber = dealNumber,
            Issuer = issuer,
            LeadBanker = leadBanker,
            Banker2 = banker2,
            IssuerState = issuerState,
            GeneralCategory = generalCategory,
            OpportunityDescription = opportunityDescription,
            ExistingRelationship = existingRelationship,
            RfpMaExamption = rfpMaExamption,
            RfpMaExamptionDate = str1,
            UwMaExamption = uwMaExamption,
            UwMaExamptionDate = str2,
            IrmaMaExamption = irmaMaExamption,
            IrmaMaExamptionDate = str3,
            PrincipalApproverName = principalApproverName,
            ApprovedDerivativeMarketer = derivativeMarketer,
            OpportunityCreatedDate = str4,
            RFPCreatedDate = str5
          };
        });
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetTitle("MERG Info Report");
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Opportunity Number", "DealNumber", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Lead Banker ", "LeadBanker", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Banker 2", "Banker2", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer State", "IssuerState", Unit.Parse("2cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer Sector / General Category", "GeneralCategory", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Opportunity Description", "OpportunityDescription", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Existing Relationship", "ExistingRelationship", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("RFP MA Exemption", "RfpMaExamption", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("RFP MA Exemption Date", "RfpMaExamptionDate", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("UW MA Exemption", "UwMaExamption", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("UW MA Exemption Date", "UwMaExamptionDate", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("IRMA MA Exemption", "IrmaMaExamption", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("IRMA MA Exemption Date", "IrmaMaExamptionDate", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Supervisory Principal Approver Name", "PrincipalApproverName", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Opportunity Create Date", "OpportunityCreatedDate", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "MergInfoReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }
  }
}
