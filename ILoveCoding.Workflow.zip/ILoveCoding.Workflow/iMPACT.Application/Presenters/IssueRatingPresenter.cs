﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.IssueRatingPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;
using System.Reflection;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (IssueRatingPresenter))]
  public class IssueRatingPresenter : PresenterBase
  {
    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IIssueRatingRepository IssueRatingRepository { get; set; }

    private string[] GetLookupItemKeys() => new string[10]
    {
      "Moody's Long Term Rating",
      "Moody's Rating Outlook",
      "Moody's Short Term Rating",
      "S&P Long Term Rating",
      "S&P Rating Outlook",
      "S&P Short Term Rating",
      "Fitch Long Term Rating",
      "Fitch Rating Outlook",
      "Fitch Short Term Rating",
      "Credit Enhancement Type"
    };

    public SaveResult SaveIssueRatings(
      List<UnderlyingRatingsViewModel> underlyingRatings,
      long appTransactionID,
      List<EnhancedRatingsViewModel> enhancedRatings)
    {
      try
      {
        this.GetSafeObject<UnderlyingRatingsViewModel>(underlyingRatings);
        DataTable underlyingRating = this.ReturnUnderlyingRatingsDataTable(underlyingRatings);
        DataTable enhancedRating = this.ReturnEnhancedRatingsDataTable(enhancedRatings);
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.IssueRatingRepository.SaveIssueRatings(underlyingRating, appTransactionID, enhancedRating);
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private DataTable ReturnEnhancedRatingsDataTable(
      List<EnhancedRatingsViewModel> enhancedRatings)
    {
      DataTable dataTable = new DataTable("EnhancedRatingsViewModel");
      dataTable.Columns.Add(new DataColumn("seriesID", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementprovider", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementProviderText", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementType", typeof (double)));
      dataTable.Columns.Add(new DataColumn("CreditEnhancementTypeText", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("Series", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("IsDirty", Type.GetType("System.Boolean")));
      dataTable.Columns.Add(new DataColumn("IsDeleted", Type.GetType("System.Boolean")));
      foreach (EnhancedRatingsViewModel enhancedRating in enhancedRatings)
      {
        DataRow row = dataTable.NewRow();
        row["seriesID"] = (object) enhancedRating.SeriesId;
        row["MoodyRatingLT"] = (object) enhancedRating.MoodyRatingLT;
        row["MoodyRatingLTOutlook"] = (object) enhancedRating.MoodyRatingLTOutlook;
        row["MoodyRatingST"] = (object) enhancedRating.MoodyRatingST;
        row["MoodyRatingSTOutlook"] = (object) enhancedRating.MoodyRatingSTOutlook;
        row["SPRatingLT"] = (object) enhancedRating.SPRatingLT;
        row["SPRatingLTOutlook"] = (object) enhancedRating.SPRatingLTOutlook;
        row["SPRatingST"] = (object) enhancedRating.SPRatingST;
        row["SPRatingSTOutlook"] = (object) enhancedRating.SPRatingSTOutlook;
        row["KrollRatingLT"] = (object) enhancedRating.KrollRatingLT;
        row["KrollRatingLTOutlook"] = (object) enhancedRating.KrollRatingLTOutlook;
        row["KrollRatingST"] = (object) enhancedRating.KrollRatingST;
        row["KrollRatingSTOutlook"] = (object) enhancedRating.KrollRatingSTOutlook;
        row["FitchRatingLT"] = (object) enhancedRating.FitchRatingLT;
        row["FitchRatingLTOutlook"] = (object) enhancedRating.FitchRatingLTOutlook;
        row["FitchRatingST"] = (object) enhancedRating.FitchRatingST;
        row["FitchRatingSTOutlook"] = (object) enhancedRating.FitchRatingSTOutlook;
        row["CreditEnhancementprovider"] = !string.IsNullOrEmpty(enhancedRating.CreditEnhancementProvider.Key) ? (object) enhancedRating.CreditEnhancementProvider.Key : (object) DBNull.Value;
        row["CreditEnhancementProviderText"] = (object) enhancedRating.CreditEnhancementProviderText;
        if (string.IsNullOrEmpty(enhancedRating.CreditEnhancementType))
        {
          row["CreditEnhancementType"] = (object) DBNull.Value;
          row["CreditEnhancementTypeText"] = (object) DBNull.Value;
        }
        else
        {
          row["CreditEnhancementType"] = (object) enhancedRating.CreditEnhancementType;
          row["CreditEnhancementTypeText"] = (object) enhancedRating.CreditEnhancementTypeText;
        }
        row["Series"] = (object) enhancedRating.Series;
        row["IsDirty"] = (object) enhancedRating.IsDirty;
        row["IsDeleted"] = (object) enhancedRating.IsDeleted;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    private DataTable ReturnUnderlyingRatingsDataTable(
      List<UnderlyingRatingsViewModel> underlyingRatings)
    {
      DataTable dataTable = new DataTable("UnderlyingRatingsViewModel");
      dataTable.Columns.Add(new DataColumn("seriesID", Type.GetType("System.Double")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("MoodyRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("SPRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("KrollRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLT", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingLTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingST", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("FitchRatingSTOutlook", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("Series", Type.GetType("System.String")));
      dataTable.Columns.Add(new DataColumn("IsDirty", Type.GetType("System.Boolean")));
      dataTable.Columns.Add(new DataColumn("IsDeleted", Type.GetType("System.Boolean")));
      foreach (UnderlyingRatingsViewModel underlyingRating in underlyingRatings)
      {
        DataRow row = dataTable.NewRow();
        row["seriesID"] = (object) underlyingRating.SeriesId;
        row["MoodyRatingLT"] = (object) underlyingRating.MoodyRatingLT;
        row["MoodyRatingLTOutlook"] = (object) underlyingRating.MoodyRatingLTOutlook;
        row["MoodyRatingST"] = (object) underlyingRating.MoodyRatingST;
        row["MoodyRatingSTOutlook"] = (object) underlyingRating.MoodyRatingSTOutlook;
        row["SPRatingLT"] = (object) underlyingRating.SPRatingLT;
        row["SPRatingLTOutlook"] = (object) underlyingRating.SPRatingLTOutlook;
        row["SPRatingST"] = (object) underlyingRating.SPRatingST;
        row["SPRatingSTOutlook"] = (object) underlyingRating.SPRatingSTOutlook;
        row["KrollRatingLT"] = (object) underlyingRating.KrollRatingLT;
        row["KrollRatingLTOutlook"] = (object) underlyingRating.KrollRatingLTOutlook;
        row["KrollRatingST"] = (object) underlyingRating.KrollRatingST;
        row["KrollRatingSTOutlook"] = (object) underlyingRating.KrollRatingSTOutlook;
        row["FitchRatingLT"] = (object) underlyingRating.FitchRatingLT;
        row["FitchRatingLTOutlook"] = (object) underlyingRating.FitchRatingLTOutlook;
        row["FitchRatingST"] = (object) underlyingRating.FitchRatingST;
        row["FitchRatingSTOutlook"] = (object) underlyingRating.FitchRatingSTOutlook;
        row["Series"] = (object) underlyingRating.Series;
        row["IsDirty"] = (object) underlyingRating.IsDirty;
        row["IsDeleted"] = (object) underlyingRating.IsDeleted;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    private List<Series> GetSeriesDataFromUnderlyingRatings(
      List<UnderlyingRatingsViewModel> underlyingRatings,
      long appTransactionID)
    {
      List<Series> seriesList = new List<Series>();
      foreach (UnderlyingRatingsViewModel underlyingRating in underlyingRatings)
        seriesList.Add(new Series()
        {
          AppTransactionID = appTransactionID,
          KrollRatingLT = underlyingRating.KrollRatingLT,
          KrollRatingLTOutlook = underlyingRating.KrollRatingLTOutlook,
          KrollRatingST = underlyingRating.KrollRatingST,
          KrollRatingSTOutlook = underlyingRating.KrollRatingSTOutlook,
          FitchRatingLT = underlyingRating.FitchRatingLT,
          FitchRatingLTOutlook = underlyingRating.FitchRatingLTOutlook,
          FitchRatingST = underlyingRating.FitchRatingST,
          FitchRatingSTOutlook = underlyingRating.FitchRatingSTOutlook,
          MoodyRatingLT = underlyingRating.MoodyRatingLT,
          MoodyRatingLTOutlook = underlyingRating.MoodyRatingLTOutlook,
          MoodyRatingST = underlyingRating.MoodyRatingST,
          MoodyRatingSTOutlook = underlyingRating.MoodyRatingSTOutlook,
          SeriesName = underlyingRating.Series,
          SPRatingLT = underlyingRating.SPRatingLT,
          SPRatingLTOutlook = underlyingRating.SPRatingLTOutlook,
          SPRatingST = underlyingRating.SPRatingST,
          SPRatingSTOutlook = underlyingRating.SPRatingSTOutlook
        });
      return seriesList;
    }

    private DataTable ConvertListToDataTable<T>(List<T> items)
    {
      DataTable dataTable = new DataTable(typeof (T).Name);
      PropertyInfo[] properties = typeof (T).GetProperties(BindingFlags.Instance | BindingFlags.Public);
      foreach (PropertyInfo propertyInfo in properties)
      {
        Type type = propertyInfo.PropertyType;
        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>))
          type = Nullable.GetUnderlyingType(type);
        dataTable.Columns.Add(propertyInfo.Name, type);
      }
      foreach (T obj in items)
      {
        object[] objArray = new object[properties.Length];
        for (int index = 0; index < properties.Length; ++index)
          objArray[index] = properties[index].GetValue((object) obj, (object[]) null);
        dataTable.Rows.Add(objArray);
      }
      return dataTable;
    }

    public List<KeyPair> GetCEProviders(string providerName)
    {
      try
      {
        List<KeyPair> keyPairList = new List<KeyPair>();
        using (IDataReader dataReader = this.IssueRatingRepository.FetchCEProvidersByName(providerName))
        {
          if (dataReader != null)
          {
            IRowMapper<KeyPair> rowMapper = MapBuilder<KeyPair>.MapAllProperties().Map<string>((Expression<Func<KeyPair, string>>) (x => x.Key)).ToColumn("PartnerID").Map<string>((Expression<Func<KeyPair, string>>) (x => x.Value)).ToColumn("Name").Build();
            while (dataReader.Read())
              keyPairList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          }
        }
        return keyPairList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return new List<KeyPair>();
      }
    }
  }
}
