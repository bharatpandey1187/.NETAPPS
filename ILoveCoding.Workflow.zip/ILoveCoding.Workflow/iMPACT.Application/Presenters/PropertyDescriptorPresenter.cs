﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.PropertyDescriptorPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (PropertyDescriptorPresenter))]
  public class PropertyDescriptorPresenter : PresenterBase
  {
    [Dependency]
    public IPropertyDescriptorRepository PropertyDescriptorRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public PropertyDescriptorViewModelContainer GetPropertyDescriptorByEntity(
      long entityID)
    {
      try
      {
        PropertyDescriptorViewModelContainer viewModelContainer = new PropertyDescriptorViewModelContainer();
        IOrderedEnumerable<PropertyDescriptor> source = this.PropertyDescriptorRepository.FetchPropertyDescriptorsByEntity(entityID).OrderBy<PropertyDescriptor, int>((Func<PropertyDescriptor, int>) (_ => _.Order));
        List<KeyPair> keyPairList = new List<KeyPair>();
        foreach (FieldInfo field in typeof (IrisSoftware.iMPACT.Data.Constants.DataTypes).GetFields())
          keyPairList.Add(new KeyPair(field.GetValue((object) null).ToString(), field.GetValue((object) null).ToString()));
        viewModelContainer.DataTypes = keyPairList;
        viewModelContainer.PropertyDescriptors = source.Select<PropertyDescriptor, PropertyDescriptorViewModel>((Func<PropertyDescriptor, PropertyDescriptorViewModel>) (x => new PropertyDescriptorViewModel(x))).ToList<PropertyDescriptorViewModel>();
        viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Manage Miscellaneous Tab", "Edit");
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        PropertyDescriptorViewModelContainer viewModelContainer = new PropertyDescriptorViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public SaveResult SavePropertyDescriptor(
      List<PropertyDescriptorViewModel> propertyDescriptorViewModel)
    {
      try
      {
        this.GetSafeObject<PropertyDescriptorViewModel>(propertyDescriptorViewModel);
        List<SaveResult> saveResultList = new List<SaveResult>();
        foreach (PropertyDescriptorViewModel descriptorViewModel in propertyDescriptorViewModel)
        {
          SaveResult saveResult = descriptorViewModel.Validate<PropertyDescriptorViewModel>();
          if (!saveResult.IsSuccessful)
          {
            saveResult.Id = descriptorViewModel.PropertyDescriptorID;
            saveResultList.Add(saveResult);
          }
        }
        if (saveResultList.Count > 0)
          return new SaveResult()
          {
            Errors = {
              {
                "LookupItems",
                (object) saveResultList
              }
            }
          };
        using (TransactionScope transactionScope = new TransactionScope())
        {
          foreach (PropertyDescriptorViewModel descriptorViewModel in propertyDescriptorViewModel)
          {
            string name;
            string str = name = this.AppUser.Name;
            descriptorViewModel.ModifiedBy = name;
            descriptorViewModel.CreatedBy = str;
          }
          this.PropertyDescriptorRepository.SavePropertyDescriptorValues(propertyDescriptorViewModel.Select<PropertyDescriptorViewModel, PropertyDescriptor>((Func<PropertyDescriptorViewModel, PropertyDescriptor>) (x => x.GetPropertyDescriptor())).ToList<PropertyDescriptor>());
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public LookupItemViewModelContainer FetchAllEntities()
    {
      try
      {
        return new LookupItemViewModelContainer()
        {
          IsViewOnly = !this.HasIndependentPermission("Reference Data", "Edit"),
          LookupItems = this.LookupRepository.FetchByLookupKey("Entity").Select<LookupItem, LookupItemViewModel>((Func<LookupItem, LookupItemViewModel>) (x => new LookupItemViewModel(x))).ToList<LookupItemViewModel>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        LookupItemViewModelContainer viewModelContainer = new LookupItemViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }
  }
}
