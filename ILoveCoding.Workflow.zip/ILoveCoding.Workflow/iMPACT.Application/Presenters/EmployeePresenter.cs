﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.EmployeePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.Licensing;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (EmployeePresenter))]
  public class EmployeePresenter : PresenterBase
  {
    private const string BankerGroupName = "Banker";
    private const string RoGroupNameSuffix = "ROGroup";
    private const string SupportGroupNameSuffix = "SupportGroup";

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    [Dependency]
    public IMembershipProvider MembershipProvider { get; set; }

    private void PopulateAdditionalSharePointInfo(SaveResult sr, EmployeeViewModel employee)
    {
      AppConfig appConfig = this.AppConfigRepository.FetchByKey(4);
      if (string.IsNullOrEmpty(employee.WindowID))
        return;
      if (appConfig.Value != string.Empty)
      {
        using (IMembershipService membershipService = this.MembershipProvider.GetRetentionMembershipService(appConfig.Value))
        {
          IUser user = this.SetupUserInSP(sr, employee, membershipService);
          employee.Principal = user.Id;
        }
      }
      else
      {
        IMembershipService membershipService = this.MembershipProvider.GetPrimaryMembershipService();
        IUser user = this.SetupUserInSP(sr, employee, membershipService);
        employee.Principal = user.Id;
      }
    }

    private IUser SetupUserInSP(
      SaveResult sr,
      EmployeeViewModel employee,
      IMembershipService membershipService)
    {
      IUser userIfNotExists = membershipService.CreateUserIfNotExists(employee.WindowID);
      if (userIfNotExists != null)
      {
        this.RemoveAssignGroups(sr, membershipService, employee, userIfNotExists);
        foreach (GroupRole selectedGroupRole in employee.SelectedGroupRoles)
        {
          if (selectedGroupRole.IsEveryoneToBeApplied)
            this.AddUserToEveryOne(sr, membershipService, employee, userIfNotExists);
        }
        this.AddUserToSelectedGroups(sr, membershipService, employee, userIfNotExists);
      }
      return userIfNotExists;
    }

    private void RemoveAssignGroups(
      SaveResult sr,
      IMembershipService memberService,
      EmployeeViewModel employee,
      IUser userEmployee)
    {
      try
      {
        IEnumerable<GroupRole> groupRoles = employee.GroupRoles.Where<GroupRole>((Func<GroupRole, bool>) (gRole => !employee.SelectedGroupRoles.Select<GroupRole, long>((Func<GroupRole, long>) (selGroupRole => selGroupRole.GroupID)).Contains<long>(gRole.GroupID)));
        if (!employee.SelectedGroupRoles.Any<GroupRole>((Func<GroupRole, bool>) (x => x.IsEveryoneToBeApplied)))
          memberService.RemoveGroupMember("Everyone", userEmployee.LoginName);
        foreach (GroupRole groupRole in groupRoles)
        {
          if (groupRole.PrincipalID > 0)
            memberService.RemoveGroupMember(groupRole.Name, userEmployee.LoginName);
        }
      }
      catch (Exception ex)
      {
        sr.Errors.Add(nameof (RemoveAssignGroups), (object) "An error occurred while saving the data.");
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    private void AddUserToEveryOne(
      SaveResult sr,
      IMembershipService memberService,
      EmployeeViewModel employee,
      IUser userEmployee)
    {
      try
      {
        IGroup groupIfNotExists = memberService.CreateGroupIfNotExists("Everyone", userEmployee.LoginName);
        memberService.AddGroupMember(groupIfNotExists.Name, userEmployee.LoginName);
      }
      catch (Exception ex)
      {
        sr.Errors.Add(nameof (AddUserToEveryOne), (object) "An error occurred while saving the data.");
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    private void AddUserToSelectedGroups(
      SaveResult sr,
      IMembershipService memberService,
      EmployeeViewModel employee,
      IUser userEmployee)
    {
      try
      {
        foreach (GroupRole selectedGroupRole in employee.SelectedGroupRoles)
        {
          if (selectedGroupRole.PrincipalID >= 1)
          {
            memberService.CreateGroupIfNotExists(selectedGroupRole.Name, userEmployee.LoginName);
            memberService.AddGroupMember(selectedGroupRole.Name, userEmployee.LoginName);
            if (this.HasSupportiveGroup(selectedGroupRole.Name))
            {
              employee.ROGroupPrincipal = memberService.CreateGroupIfNotExists(this.GetUniqueGroupName(userEmployee, "ROGroup"), userEmployee.LoginName).Id;
              employee.SupportGroupPrincipal = memberService.CreateGroupIfNotExists(this.GetUniqueGroupName(userEmployee, "SupportGroup"), userEmployee.LoginName).Id;
            }
          }
        }
      }
      catch (Exception ex)
      {
        sr.Errors.Add(nameof (AddUserToSelectedGroups), (object) "An error occurred while saving the data.");
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    private bool HasSupportiveGroup(string groupName) => string.Compare(groupName, "Banker", true) == 0;

    private string GetUniqueGroupName(IUser oUser, string suffix) => oUser.GetLoginNameWithoutClaimInformation().Replace("\\", "_") + suffix;

    private void SaveEmployeeAssociates(
      int empPrincipalId,
      List<EmployeeAssociatesViewModel> associates)
    {
      AppConfig appConfig = this.AppConfigRepository.FetchByKey(4);
      IMembershipService membershipService1 = this.MembershipProvider.GetPrimaryMembershipService();
      IUser user1 = membershipService1.GetUser(empPrincipalId);
      this.DeleteUsers(user1, associates, membershipService1);
      IGroup groupIfNotExists1 = membershipService1.CreateGroupIfNotExists(this.GetUniqueGroupName(user1, "ROGroup"), user1.LoginName);
      IGroup groupIfNotExists2 = membershipService1.CreateGroupIfNotExists(this.GetUniqueGroupName(user1, "SupportGroup"), user1.LoginName);
      EmployeePresenter.AddAssociates(associates, groupIfNotExists1, groupIfNotExists2, membershipService1);
      if (!string.IsNullOrEmpty(appConfig.Value))
      {
        using (IMembershipService membershipService2 = this.MembershipProvider.GetRetentionMembershipService(appConfig.Value))
        {
          IUser user2 = membershipService2.GetUser(user1.LoginName);
          this.DeleteUsers(user2, associates, membershipService2);
          IGroup groupIfNotExists3 = membershipService2.CreateGroupIfNotExists(this.GetUniqueGroupName(user2, "ROGroup"), user2.LoginName);
          IGroup groupIfNotExists4 = membershipService2.CreateGroupIfNotExists(this.GetUniqueGroupName(user2, "SupportGroup"), user2.LoginName);
          EmployeePresenter.AddAssociates(associates, groupIfNotExists3, groupIfNotExists4, membershipService2);
        }
      }
      this.EmployeeRepository.UpdateGroupPrincipals(empPrincipalId, groupIfNotExists1.Id, groupIfNotExists2.Id);
    }

    private void GetEmployeeAssociates(
      int principalId,
      List<EmployeeAssociatesViewModel> employeeAssociates)
    {
      IMembershipService membershipService = this.MembershipProvider.GetPrimaryMembershipService();
      IUser user = membershipService.GetUser(principalId);
      this.GetEmployeeAssociates(user, true, membershipService, employeeAssociates);
      this.GetEmployeeAssociates(user, false, membershipService, employeeAssociates);
    }

    private void GetEmployeeAssociates(
      string windowId,
      List<EmployeeAssociatesViewModel> employeeAssociates,
      IMembershipService memberService)
    {
      IUser user = memberService.GetUser(windowId);
      this.GetEmployeeAssociates(user, true, memberService, employeeAssociates);
      this.GetEmployeeAssociates(user, false, memberService, employeeAssociates);
    }

    private IGroup GetEmployeeAssociates(
      IUser employee,
      bool empRO,
      IMembershipService memberService,
      List<EmployeeAssociatesViewModel> employesAsssociates)
    {
      string groupName = empRO ? this.GetUniqueGroupName(employee, "ROGroup") : this.GetUniqueGroupName(employee, "SupportGroup");
      IGroup group = (IGroup) null;
      if (memberService.IsGroupExists(groupName, out group))
      {
        List<IUser> allUsersInGroup = memberService.GetAllUsersInGroup(group.Name);
        if (allUsersInGroup != null)
        {
          foreach (IUser user in allUsersInGroup)
          {
            if (user.Id != employee.Id)
              employesAsssociates.Add(new EmployeeAssociatesViewModel()
              {
                PrincipalId = user.Id,
                FullName = user.Name,
                Email = user.Email,
                IsRO = empRO,
                LoginName = user.LoginName
              });
          }
        }
      }
      return group;
    }

    private void DeleteUsers(
      IUser user,
      List<EmployeeAssociatesViewModel> currentAssociates,
      IMembershipService memberService)
    {
      List<EmployeeAssociatesViewModel> associatesViewModelList = new List<EmployeeAssociatesViewModel>();
      this.GetEmployeeAssociates(user.LoginName, associatesViewModelList, memberService);
      IEnumerable<EmployeeAssociatesViewModel> associatesViewModels = associatesViewModelList.Except<EmployeeAssociatesViewModel>((IEnumerable<EmployeeAssociatesViewModel>) currentAssociates);
      if (associatesViewModels == null)
        return;
      foreach (EmployeeAssociatesViewModel associatesViewModel in associatesViewModels)
      {
        string suffix = associatesViewModel.IsRO ? "ROGroup" : "SupportGroup";
        memberService.DeleteGroupMember(this.GetUniqueGroupName(user, suffix), associatesViewModel.LoginName);
      }
    }

    private static void AddAssociates(
      List<EmployeeAssociatesViewModel> associates,
      IGroup roGroup,
      IGroup supportGroup,
      IMembershipService membershipService)
    {
      foreach (EmployeeAssociatesViewModel associate in associates)
      {
        IUser user = (IUser) null;
        try
        {
          user = membershipService.GetUser(associate.LoginName);
        }
        catch (InvalidUserException ex)
        {
        }
        if (user != null)
          membershipService.AddGroupMember(associate.IsRO ? roGroup.Name : supportGroup.Name, user.LoginName);
      }
    }

    [Dependency]
    public IEmployeeRepository EmployeeRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public ILicensingPolicy LicensingPolicy { get; set; }

    [Dependency]
    public LicenseInfo LicenseInfo { get; set; }

    [Dependency]
    public ILookupRepository lookupRepository { get; set; }

    [InjectionConstructor]
    public EmployeePresenter()
    {
    }

    public EmployeeViewModelContainer GetEmployees()
    {
      try
      {
        EmployeeViewModelContainer viewModelContainer = new EmployeeViewModelContainer();
        IEnumerable<LookupItemMappings> source1 = this.LookupRepository.FetchLookupItemsByLookupKeys("Office", "State");
        IEnumerable<AppRoles> source2 = this.EmployeeRepository.FetchAplicationRoles("App");
        IEnumerable<GroupRole> source3 = this.EmployeeRepository.FetchGroupRoles();
        List<KeyPair> list1 = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "State")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        IEnumerable<EmployeeViewModel> list2 = (IEnumerable<EmployeeViewModel>) this.EmployeeRepository.FetchAll().Select<Employee, EmployeeViewModel>((Func<Employee, EmployeeViewModel>) (x => new EmployeeViewModel(x))).ToList<EmployeeViewModel>();
        foreach (EmployeeViewModel employeeViewModel in list2)
        {
          employeeViewModel.States = list1;
          employeeViewModel.AppRoles = source2.ToList<AppRoles>();
          employeeViewModel.GroupRoles = source3.ToList<GroupRole>();
        }
        viewModelContainer.Employees = list2.ToList<EmployeeViewModel>();
        viewModelContainer.IsViewOnly = !this.HasIndependentPermission("Employee", "Edit");
        viewModelContainer.AllowGroupAssignment = true;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new EmployeeViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public EmployeeViewModel GetEmployeeFromUPS(EmployeeViewModel evm) => this.GetEmployeeFromUserProfileService(evm);

    private EmployeeViewModel GetEmployeeFromUserProfileService(
      EmployeeViewModel evm)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      EmployeePresenter.\u003C\u003Ec__DisplayClass47_0 cDisplayClass470 = new EmployeePresenter.\u003C\u003Ec__DisplayClass47_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass470.evm = evm;
      try
      {
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        EmployeePresenter.\u003C\u003Ec__DisplayClass47_1 cDisplayClass471 = new EmployeePresenter.\u003C\u003Ec__DisplayClass47_1();
        // ISSUE: reference to a compiler-generated field
        cDisplayClass471.CS\u0024\u003C\u003E8__locals1 = cDisplayClass470;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.ErrorMessage = (string) null;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!string.IsNullOrEmpty(cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.WindowID))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.WindowID = cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.WindowID.Trim();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.FullName = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Title = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Phone = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Fax = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Email = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.StreetAddress = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.City = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.State = new long?();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Zip = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.KerberosID = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.CostCenter = (string) null;
        }
        // ISSUE: reference to a compiler-generated field
        cDisplayClass471.employeeUPSMapping = this.EmployeeRepository.FetchSPUserProfileMapping();
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!string.IsNullOrEmpty(cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.WindowID))
        {
          // ISSUE: reference to a compiler-generated field
          if (cDisplayClass471.employeeUPSMapping != null)
          {
            // ISSUE: reference to a compiler-generated field
            if (cDisplayClass471.employeeUPSMapping.Count<EmployeeUPSMapping>() > 0)
            {
              // ISSUE: method pointer
              SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass471, __methodptr(\u003CGetEmployeeFromUserProfileService\u003Eb__0)));
            }
            else
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.ErrorMessage = "User Profile Service is not mapped.";
            }
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.ErrorMessage = "User Profile Service is not mapped.";
          }
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!string.IsNullOrEmpty(cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.ErrorMessage))
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.FullName = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Title = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Phone = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Fax = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Email = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.StreetAddress = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.City = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.State = new long?();
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.Zip = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.KerberosID = (string) null;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm.CostCenter = (string) null;
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        return cDisplayClass471.CS\u0024\u003C\u003E8__locals1.evm;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new EmployeeViewModel("An error occurred while fetching the data.");
      }
    }

    public List<InternalPartnerAutoCompleteViewModel> FetchAllEmployeeByRoles(
      string empName,
      long roleTypeId,
      long entityId,
      bool includeInActive)
    {
      try
      {
        if (!string.IsNullOrEmpty(empName))
          empName = empName.Trim();
        return this.EmployeeRepository.FetchAllEmployeeByRoles(empName, roleTypeId, entityId, includeInActive).ToList<Employee>().Select<Employee, InternalPartnerAutoCompleteViewModel>((Func<Employee, InternalPartnerAutoCompleteViewModel>) (x => new InternalPartnerAutoCompleteViewModel(x))).ToList<InternalPartnerAutoCompleteViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<InternalPartnerAutoCompleteViewModel>();
      }
    }

    public List<InternalPartnerAutoCompleteViewModel> FetchAllEmployeeIrrespectiveOfRole(
      string empName,
      bool includeInActive)
    {
      try
      {
        if (!string.IsNullOrEmpty(empName))
          empName = empName.Trim();
        return this.EmployeeRepository.FetchAllEmployeeIrrespectiveOfRole(empName, includeInActive).ToList<Employee>().Select<Employee, InternalPartnerAutoCompleteViewModel>((Func<Employee, InternalPartnerAutoCompleteViewModel>) (x => new InternalPartnerAutoCompleteViewModel(x))).ToList<InternalPartnerAutoCompleteViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<InternalPartnerAutoCompleteViewModel>();
      }
    }

    public List<InternalPartnerAutoCompleteViewModel> FetchFetchEmployeeAutoCompleteByFullName(
      string empName,
      bool IsUserProfile)
    {
      try
      {
        return this.EmployeeRepository.FetchEmployeeAutoCompleteByFullName(empName, IsUserProfile).ToList<Employee>().Select<Employee, InternalPartnerAutoCompleteViewModel>((Func<Employee, InternalPartnerAutoCompleteViewModel>) (x => new InternalPartnerAutoCompleteViewModel(x))).ToList<InternalPartnerAutoCompleteViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<InternalPartnerAutoCompleteViewModel>();
      }
    }

    public EmployeeViewModel GetEmployee(int currentId)
    {
      try
      {
        EmployeeViewModel employeeViewModel = new EmployeeViewModel();
        IEnumerable<LookupItemMappings> source1 = this.LookupRepository.FetchLookupItemsByLookupKeys("Office", "State");
        IEnumerable<AppRoles> source2 = this.EmployeeRepository.FetchAplicationRoles("App");
        IEnumerable<GroupRole> source3 = this.EmployeeRepository.FetchGroupRoles();
        List<KeyPair> list = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "State")).Select<LookupItemMappings, KeyPair>((Func<LookupItemMappings, KeyPair>) (x => new KeyPair(x.LookupItemID, x.Value))).ToList<KeyPair>();
        employeeViewModel.States = list;
        employeeViewModel.AppRoles = source2.ToList<AppRoles>();
        employeeViewModel.GroupRoles = source3.ToList<GroupRole>();
        return employeeViewModel;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new EmployeeViewModel("An error occurred while fetching the data.");
      }
    }

    public SaveResult Save(EmployeeViewModel theEmployee)
    {
      if (theEmployee.EmployeeID == 0L)
      {
        theEmployee = this.GetEmployeeFromUserProfileService(theEmployee);
        if (!string.IsNullOrEmpty(theEmployee.ErrorMessage))
          return new SaveResult()
          {
            Errors = {
              {
                "Failed",
                (object) theEmployee.ErrorMessage
              }
            },
            ViewModel = (object) theEmployee
          };
      }
      EmployeeViewModel employeeViewModel = new EmployeeViewModel();
      SaveResult sr = theEmployee.Validate<EmployeeViewModel>();
      if (!this.AllowUserCreation(theEmployee))
        sr.Errors.Add("Limit Exceeded", (object) "Maximum users allowed by license has exceeded.");
      try
      {
        sr.ViewModel = (object) theEmployee;
        this.GetSafeObject<EmployeeViewModel>(theEmployee);
        if (sr.IsSuccessful)
        {
          this.PopulateAdditionalSharePointInfo(sr, theEmployee);
          if (sr.IsSuccessful)
          {
            if (theEmployee.Principal == 0)
              sr.Errors.Add("Failed", (object) "Failed to add the user in SharePoint.");
            else
              this.SaveAndFetchEmployeeData(theEmployee, employeeViewModel, sr);
          }
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        sr.Errors.Add("Save Exception", (object) ex.Message);
      }
      return sr;
    }

    public SaveResult SaveAssociates(
      int empPrincipalId,
      List<EmployeeAssociatesViewModel> associates)
    {
      try
      {
        this.SaveEmployeeAssociates(empPrincipalId, associates);
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public List<EmployeeAssociatesViewModel> GetEmployeeAssociates(
      int principalId)
    {
      List<EmployeeAssociatesViewModel> employeeAssociates = new List<EmployeeAssociatesViewModel>();
      try
      {
        this.GetEmployeeAssociates(principalId, employeeAssociates);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return employeeAssociates;
      }
      return employeeAssociates;
    }

    private bool AllowUserCreation(EmployeeViewModel theEmployee) => theEmployee.EmployeeID != 0L || this.LicensingPolicy.AllowUserCreation(this.LicenseInfo, this.EmployeeRepository.FetchUsersCount());

    public void Delete(int currentId)
    {
      try
      {
        this.EmployeeRepository.Delete(currentId);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        throw;
      }
    }

    private long SaveAndFetchEmployeeData(
      EmployeeViewModel theEmployee,
      EmployeeViewModel employeeViewModel,
      SaveResult sr)
    {
      long num;
      using (TransactionScope transactionScope = new TransactionScope())
      {
        num = this.EmployeeRepository.Save(employeeViewModel.GetEmployeeDatail(theEmployee));
        if (num == -100L)
          sr.Errors.Add("Employee Number", (object) "Employee Number already exists.");
        if (num == -101L)
          sr.Errors.Add("Window ID", (object) "Window ID/UID already exists.");
        if (num == -102L)
          sr.Errors.Add("Window ID", (object) "Email already exists.");
        if (sr.IsSuccessful)
        {
          transactionScope.Complete();
          employeeViewModel.ErrorMessage = string.Empty;
        }
      }
      return num;
    }
  }
}
