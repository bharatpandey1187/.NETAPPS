﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.EntityGroupRolePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (EntityGroupRolePresenter))]
  public class EntityGroupRolePresenter : PresenterBase
  {
    [Dependency]
    public IEntityGroupRoleRepository EntityGroupRoleRepository { get; set; }

    [Dependency]
    public ReferenceDataPresenter Presenter { get; set; }

    public EntityGroupRoleViewModelContainer Initialize()
    {
      try
      {
        EntityGroupRoleViewModelContainer viewModelContainer = new EntityGroupRoleViewModelContainer();
        List<EntityGroupRoleViewModel> groupRoleViewModelList = new List<EntityGroupRoleViewModel>();
        List<RoleTypesViewModel> roleTypesViewModelList = new List<RoleTypesViewModel>();
        List<RoleViewModel> roleViewModelList = new List<RoleViewModel>();
        using (IDataReader allEntityGroupRole = this.EntityGroupRoleRepository.GetAllEntityGroupRole())
        {
          IRowMapper<EntityGroupRoleViewModel> rowMapper1 = MapBuilder<EntityGroupRoleViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<EntityGroupRoleViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<EntityGroupRoleViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<EntityGroupRoleViewModel, string>>) (x => x.ErrorMessage)).Build();
          while (allEntityGroupRole.Read())
            groupRoleViewModelList.Add(rowMapper1.MapRow((IDataRecord) allEntityGroupRole));
          IRowMapper<RoleTypesViewModel> rowMapper2 = MapBuilder<RoleTypesViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<RoleTypesViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<RoleTypesViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<RoleTypesViewModel, string>>) (x => x.ErrorMessage)).Build();
          if (allEntityGroupRole.NextResult())
          {
            while (allEntityGroupRole.Read())
              roleTypesViewModelList.Add(rowMapper2.MapRow((IDataRecord) allEntityGroupRole));
          }
          IRowMapper<RoleViewModel> rowMapper3 = MapBuilder<RoleViewModel>.MapAllProperties().Build();
          if (allEntityGroupRole.NextResult())
          {
            while (allEntityGroupRole.Read())
              roleViewModelList.Add(rowMapper3.MapRow((IDataRecord) allEntityGroupRole));
          }
        }
        viewModelContainer.EntityGroupRoles = groupRoleViewModelList;
        viewModelContainer.EntityTypes = this.Presenter.GetItemsByKey("Entity").ToList<LookupItemViewModel>();
        viewModelContainer.RoleTypes = roleTypesViewModelList;
        viewModelContainer.Roles = roleViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new EntityGroupRoleViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult Save(
      EntityGroupRoleViewModelContainer theEntityGroupRoleViewModel)
    {
      try
      {
        this.GetSafeObject<EntityGroupRoleViewModelContainer>(theEntityGroupRoleViewModel);
        SaveResult saveResult = theEntityGroupRoleViewModel.Validate<EntityGroupRoleViewModelContainer>();
        if (saveResult.IsSuccessful)
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            EntityGroupRole theEntityGroupRole = new EntityGroupRole();
            long? nullable = theEntityGroupRoleViewModel.GroupId;
            theEntityGroupRole.GroupId = nullable.Value;
            nullable = theEntityGroupRoleViewModel.EntityId;
            theEntityGroupRole.EntityId = nullable.Value;
            nullable = theEntityGroupRoleViewModel.RoleTypesId;
            theEntityGroupRole.RoleTypesId = nullable.Value;
            theEntityGroupRole.SelectedRoles = theEntityGroupRoleViewModel.SelectedRoles;
            this.EntityGroupRoleRepository.Save(theEntityGroupRole);
            transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public EntityGroupRoleViewModelContainer GetEntityGrouptRoleByKeys(
      long GroupId,
      long EntityId,
      long RoleTypesId)
    {
      try
      {
        EntityGroupRoleViewModelContainer viewModelContainer = new EntityGroupRoleViewModelContainer();
        List<RoleViewModel> roleViewModelList = new List<RoleViewModel>();
        using (IDataReader entityGroupRoleByKeys = this.EntityGroupRoleRepository.GetEntityGroupRoleByKeys(GroupId, EntityId, RoleTypesId))
        {
          if (entityGroupRoleByKeys != null)
          {
            IRowMapper<RoleViewModel> rowMapper = MapBuilder<RoleViewModel>.MapAllProperties().Build();
            while (entityGroupRoleByKeys.Read())
              roleViewModelList.Add(rowMapper.MapRow((IDataRecord) entityGroupRoleByKeys));
          }
        }
        viewModelContainer.Roles = roleViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new EntityGroupRoleViewModelContainer("An error occurred while fetching the data.");
      }
    }
  }
}
