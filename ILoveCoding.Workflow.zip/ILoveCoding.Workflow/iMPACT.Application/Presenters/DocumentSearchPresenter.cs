﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.DocumentSearchPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.SearchCriteria;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public class DocumentSearchPresenter : PresenterBase
  {
    private bool enableLogging;

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IManageDocumentTagRepository DocumentTagsRepository { get; set; }

    [Dependency]
    public IUploadCategoryRepository UploadCategoryRepository { get; set; }

    [Dependency]
    public IDocumentQuery DocumentQuery { get; set; }

    [Dependency]
    public IDocumentSearchRepository DocumentSearchRepository { get; set; }

    [Dependency]
    public IEntityDocSetTypeRepository EntityDocSetTypeRepository { get; set; }

    public DocumentSearchViewModel Initialize()
    {
      try
      {
        DocumentSearchViewModel documentSearchViewModel = new DocumentSearchViewModel();
        documentSearchViewModel.EntityTypes = this.FetchAllEntityTypes(1).Select<EntityTypes, KeyValuePair<long, string>>((Func<EntityTypes, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.EntityTypeID, x.TypeName))).ToList<KeyValuePair<long, string>>();
        IEnumerable<LookupItemMappings> source1 = this.LookupRepository.FetchLookupItemsByLookupKeys(this.GetDocSearchLookupItemKeys(), (string[]) null, false);
        IEnumerable<EntityDocSetType> source2 = this.EntityDocSetTypeRepository.FetchEntityDocSetTypeByEntityID(65L).Where<EntityDocSetType>((Func<EntityDocSetType, bool>) (d => d.EntityTypeID != -4L && d.EntityTypeID != -2L));
        documentSearchViewModel.GeneralCategories = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "MS Banking Group")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
        documentSearchViewModel.Entities = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Entity" && x.LookupItemID > 0L)).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
        documentSearchViewModel.States = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "State")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
        documentSearchViewModel.FirmRoles = source1.Where<LookupItemMappings>((Func<LookupItemMappings, bool>) (x => x.Key == "Firm Role")).Select<LookupItemMappings, KeyValuePair<long, string>>((Func<LookupItemMappings, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>();
        if (source2 != null)
        {
          foreach (EntityDocSetType entityDocSetType in source2)
          {
            if (entityDocSetType.EntityTypeID == -32L)
              entityDocSetType.DocSetName = string.Format("{0} (Transaction)", (object) entityDocSetType.DocSetName);
            else if (entityDocSetType.EntityTypeID == -33L)
              entityDocSetType.DocSetName = string.Format("{0} (Oppty)", (object) entityDocSetType.DocSetName);
            else if (entityDocSetType.EntityTypeID == 1L)
              entityDocSetType.DocSetName = string.Format("{0} (RFP)", (object) entityDocSetType.DocSetName);
            else if (entityDocSetType.EntityTypeID == -1L)
              entityDocSetType.DocSetName = string.Format("{0} (Client)", (object) entityDocSetType.DocSetName);
          }
          documentSearchViewModel.DocumentRepositories = source2.ToList<EntityDocSetType>();
        }
        else
          documentSearchViewModel.DocumentRepositories = new List<EntityDocSetType>();
        IEnumerable<IrisSoftware.iMPACT.Data.UploadCategory> source3 = this.UploadCategoryRepository.FetchAll().Where<IrisSoftware.iMPACT.Data.UploadCategory>((Func<IrisSoftware.iMPACT.Data.UploadCategory, bool>) (d => d.EntityTypeID != -4L && d.EntityTypeID != -2L));
        StringBuilder entityCategories = new StringBuilder();
        if (source3 != null)
        {
          foreach (IrisSoftware.iMPACT.Data.UploadCategory uploadCategory in source3)
          {
            entityCategories.Append(uploadCategory.EntityTypeDocTypeCategoryID.ToString() + ",");
            if (uploadCategory.EntityTypeID == -32L)
              uploadCategory.CategoryName = string.Format("{0} (Transaction)", (object) uploadCategory.CategoryName);
            else if (uploadCategory.EntityTypeID == -33L)
              uploadCategory.CategoryName = string.Format("{0} (Oppty)", (object) uploadCategory.CategoryName);
            else if (uploadCategory.EntityTypeID == 1L)
              uploadCategory.CategoryName = string.Format("{0} (RFP)", (object) uploadCategory.CategoryName);
            else if (uploadCategory.EntityTypeID == -1L)
              uploadCategory.CategoryName = string.Format("{0} (Client)", (object) uploadCategory.CategoryName);
          }
          documentSearchViewModel.DocumentCategories = source3.ToList<IrisSoftware.iMPACT.Data.UploadCategory>();
        }
        else
          documentSearchViewModel.DocumentCategories = new List<IrisSoftware.iMPACT.Data.UploadCategory>();
        documentSearchViewModel.DocumentTypes = this.UploadCategoryRepository.FetchAllUploadDocTypes().Where<IrisSoftware.iMPACT.Data.UploadDocType>((Func<IrisSoftware.iMPACT.Data.UploadDocType, bool>) (d => entityCategories.ToString().Contains(d.EntityTypeDocTypeCategoryID.ToString()))).ToList<IrisSoftware.iMPACT.Data.UploadDocType>();
        IEnumerable<ManageDocumentTag> source4 = this.DocumentTagsRepository.FetchTagsList().Where<ManageDocumentTag>((Func<ManageDocumentTag, bool>) (d => d.EntityTypeID != -4L && d.EntityTypeID != -2L));
        if (source4 != null)
        {
          foreach (ManageDocumentTag manageDocumentTag in source4)
          {
            manageDocumentTag.Value = manageDocumentTag.Tag;
            if (manageDocumentTag.EntityTypeID == -32L)
              manageDocumentTag.Tag = string.Format("{0} (Transaction)", (object) manageDocumentTag.Tag);
            else if (manageDocumentTag.EntityTypeID == -33L)
              manageDocumentTag.Tag = string.Format("{0} (Oppty)", (object) manageDocumentTag.Tag);
            else if (manageDocumentTag.EntityTypeID == 1L)
              manageDocumentTag.Tag = string.Format("{0} (RFP)", (object) manageDocumentTag.Tag);
            else if (manageDocumentTag.EntityTypeID == -1L)
              manageDocumentTag.Tag = string.Format("{0} (Client)", (object) manageDocumentTag.Tag);
          }
          documentSearchViewModel.DocumentTags = source4.ToList<ManageDocumentTag>();
        }
        else
          documentSearchViewModel.DocumentTags = new List<ManageDocumentTag>();
        documentSearchViewModel.CanCreatePublicBookmark = this.HasIndependentPermission("Document Public Bookmark", "Create");
        SearchSetting searchSetting = this.DocumentSearchRepository.FetchDocumentBookmarks().FirstOrDefault<SearchSetting>((Func<SearchSetting, bool>) (x => x.SearchSettingID == -5L));
        if (searchSetting == null)
        {
          List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
          List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory)).ToList<SearchResultField>();
          List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
          List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
          documentSearchViewModel.SelectedFields = list1;
          documentSearchViewModel.AllFields = list2;
          documentSearchViewModel.SelectedAllFields = list2;
          documentSearchViewModel.FieldsToSelect = list1;
        }
        else
        {
          IssueSearchViewModel issueSearchViewModel = new JavaScriptSerializer().Deserialize<IssueSearchViewModel>(searchSetting.Criteria);
          if (issueSearchViewModel.SelectedFields != null && issueSearchViewModel.SelectedFields.Count > 0)
          {
            documentSearchViewModel.SelectedFields = issueSearchViewModel.SelectedFields;
            documentSearchViewModel.AllFields = issueSearchViewModel.AllFields;
            documentSearchViewModel.SelectedAllFields = issueSearchViewModel.AllFields;
            documentSearchViewModel.FieldsToSelect = issueSearchViewModel.FieldsToSelect;
          }
          else
          {
            List<SearchResultField> searchResultFields = this.GetAllSearchResultFields();
            List<SearchResultField> list1 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => x.IsMandatory)).ToList<SearchResultField>();
            List<string> fieldsToSelectNames = list1.Select<SearchResultField, string>((Func<SearchResultField, string>) (x => x.Name)).ToList<string>();
            List<SearchResultField> list2 = searchResultFields.Where<SearchResultField>((Func<SearchResultField, bool>) (x => !fieldsToSelectNames.Contains(x.Name))).ToList<SearchResultField>();
            documentSearchViewModel.SelectedFields = list1;
            documentSearchViewModel.AllFields = list2;
            documentSearchViewModel.SelectedAllFields = list2;
            documentSearchViewModel.FieldsToSelect = list1;
          }
        }
        return documentSearchViewModel;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        DocumentSearchViewModel documentSearchViewModel = new DocumentSearchViewModel();
        documentSearchViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return documentSearchViewModel;
      }
    }

    public List<EntityTypes> FetchAllEntityTypes(int showSearchEntityType)
    {
      try
      {
        List<EntityTypes> entityTypesList = new List<EntityTypes>();
        using (IDataReader dataReader = this.DocumentSearchRepository.FetchAllEntityTypes(showSearchEntityType))
        {
          IRowMapper<EntityTypes> rowMapper = MapBuilder<EntityTypes>.MapAllProperties().Build();
          while (dataReader.Read())
            entityTypesList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return entityTypesList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<EntityTypes>();
      }
    }

    public SaveResult SearchDocument(
      KendoGridRequest request,
      DocumentSearchViewModel documentSearchCriteria)
    {
      try
      {
        bool isBlankSearch = false;
        long total = 0;
        List<DocumentSearchResultViewModel> searchData = this.GetSearchData(request, documentSearchCriteria, out total, ref isBlankSearch);
        SaveResult saveResult1 = new SaveResult();
        SaveResult saveResult2;
        if (isBlankSearch)
        {
          saveResult2 = SaveResult.Failure("Please select one or more filter criteria to continue search.");
        }
        else
        {
          saveResult2 = SaveResult.Success;
          saveResult2.ViewModel = (object) new Paged<DocumentSearchResultViewModel>((IList<DocumentSearchResultViewModel>) searchData, total);
        }
        return saveResult2;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure(ex.Message);
      }
    }

    public List<SearchSettingViewModel> GetAllBookmarks()
    {
      try
      {
        return this.DocumentSearchRepository.FetchDocumentBookmarks().Select<SearchSetting, SearchSettingViewModel>((Func<SearchSetting, SearchSettingViewModel>) (x => new SearchSettingViewModel(x))).ToList<SearchSettingViewModel>();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<SearchSettingViewModel>();
      }
    }

    public SaveResult SaveBookMark(SearchSettingViewModel searchSettingModel)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.DocumentSearchRepository.SaveDocumentBookMark(new SearchSetting()
          {
            SearchSettingID = searchSettingModel.SearchSettingID,
            Name = searchSettingModel.Name,
            Criteria = searchSettingModel.Criteria,
            GridSetting = searchSettingModel.GridSetting,
            Public = searchSettingModel.Public
          });
          transactionScope.Complete();
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.DocumentSearch, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult DeleteBookMark(long bookmarkId)
    {
      try
      {
        this.DocumentSearchRepository.DeleteBookMark(bookmarkId);
        return new SaveResult();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while deleting the data.");
      }
    }

    private string GetLocalWhenFromUTCWhen(DateTime When, string OffSetMinutes)
    {
      TimeSpan timeSpan = TimeSpan.FromMinutes((double) -Convert.ToInt32(OffSetMinutes));
      return When.Add(timeSpan).ToString("MM/dd/yyyy hh:mm:ss tt");
    }

    public ExportResult Export(
      KendoGridRequest request,
      DocumentSearchViewModel searchCriteria,
      string exportType,
      string offsetTimeZoneMinutes)
    {
      try
      {
        bool isBlankSearch = false;
        long total = 0;
        IEnumerable<\u003C\u003Ef__AnonymousType5<string, string, string, string, string, string, Decimal?, string, string, string, string, string, string, string, string, string, string, string, string, string>> datas = this.GetSearchData(request, searchCriteria, out total, ref isBlankSearch).Select(d => new
        {
          DealNumber = d.DealNumber,
          DealName = d.DealName,
          DealIssuer = d.DealIssuer,
          DealIssuerName = d.DealIssuerName,
          DealStatus = d.DealStatus,
          DealFirmRole = d.DealFirmRole,
          ParAmount = d.ParAmount,
          DocumentName = d.DocumentName,
          DocumentUrl = d.DocumentUrl,
          DocumentType = d.DocumentType,
          DocumentRepository = d.DocumentRepository,
          Repository = d.Repository,
          UploadDate = this.GetLocalWhenFromUTCWhen(d.UploadDate, offsetTimeZoneMinutes),
          SourceLocation = d.SourceLocation,
          JobNumbers = d.JobNumbers,
          MSBankingGroup = d.MSBankingGroup,
          DealBorrowerName = d.DealBorrowerName,
          CategoryName = d.CategoryName,
          TransactionDescription = d.TransactionDescription,
          OpportunityDescription = d.OpportunityDescription
        });
        PageLayout pageLayout = new PageLayout(new Unit(11.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("Document Search", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.AlignRight();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider1.CellStyleBuilder.LeftRightPadding(Unit.Parse(".25cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.AlignLeft();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        foreach (SearchResultField searchResultField in searchCriteria.SelectedFields.OrderBy<SearchResultField, int>((Func<SearchResultField, int>) (x => x.Order)).ToList<SearchResultField>())
          tabularReportBuilder.AddColumn(searchResultField.Html.title, searchResultField.ExportField, Unit.Parse(searchResultField.Html.excelWidth), searchResultField.Html.excelFormat, searchResultField.Html.isLeftAligned ? (IColumnStyleProvider) columnStyleProvider2 : (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "DocumentSearch", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ExportResult();
      }
    }

    private void SetSearchScope() => this.DocumentQuery.QueryScope = string.Format("ContentType:\"{0}\"", (object) "iMPACT_CTypeDocumentMetadata");

    private DataTable GetPopulatedTable(List<Document> documents)
    {
      DataTable dataTable = new DataTable();
      dataTable.Columns.Add("AppTransactionID");
      dataTable.Columns.Add("DocumentId");
      dataTable.Columns.Add("DocumentName");
      dataTable.Columns.Add("DocumentUrl");
      dataTable.Columns.Add("DocumentType");
      dataTable.Columns.Add("Repository");
      dataTable.Columns.Add("LastModifiedBy");
      dataTable.Columns.Add("LastModifiedOn", Type.GetType("System.DateTime"));
      foreach (Document document in documents)
      {
        if (this.enableLogging)
          this.Log.Error(Modules.DocumentSearch, string.Format("AppTransactionID: {0} DocumentId: {1} Repository: {2} DocumentType: {3} Name: {4} URL: {5}", (object) document.EntityID.ToString(), (object) document.DocumentId, (object) document.DocSetName, (object) document.EntityTypeDocTypeID, (object) document.DocumentName, (object) document.DocumentURL));
        DataRow row = dataTable.NewRow();
        row["AppTransactionID"] = (object) document.EntityID;
        row["DocumentId"] = (object) document.DocumentId;
        row["DocumentName"] = (object) document.DocumentName;
        row["DocumentUrl"] = (object) document.DocumentURL;
        row["DocumentType"] = (object) document.EntityTypeDocTypeID;
        row["Repository"] = (object) document.DocSetName;
        row["LastModifiedBy"] = (object) document.LastModifiedBy;
        row["LastModifiedOn"] = (object) (document.LastModifiedOn == DateTime.MinValue ? DateTime.Now : document.LastModifiedOn);
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    private List<DocumentSearchResultViewModel> GetSearchData(
      KendoGridRequest request,
      DocumentSearchViewModel searchCriteria,
      out long total,
      ref bool isBlankSearch)
    {
      total = 0L;
      if (searchCriteria.UploadDateFrom.HasValue)
        searchCriteria.UploadDateFrom = new DateTime?(searchCriteria.UploadDateFrom.Value.ToUniversalTime());
      DateTime? nullable1 = searchCriteria.UploadDateTo;
      if (nullable1.HasValue)
      {
        DocumentSearchViewModel documentSearchViewModel1 = searchCriteria;
        nullable1 = searchCriteria.UploadDateTo;
        DateTime? nullable2 = new DateTime?(nullable1.Value.ToUniversalTime());
        documentSearchViewModel1.UploadDateTo = nullable2;
        DocumentSearchViewModel documentSearchViewModel2 = searchCriteria;
        nullable1 = searchCriteria.UploadDateTo;
        DateTime? nullable3 = new DateTime?(nullable1.Value.AddDays(1.0).AddSeconds(-1.0));
        documentSearchViewModel2.UploadDateTo = nullable3;
      }
      IVisitableCriterion criterion1 = "DocumentRepository".AnyOf(searchCriteria.SelectedDocumentRepository.Select<EntityDocSetType, string>((Func<EntityDocSetType, string>) (x => x.EntityDocSetTypeID.ToString())).ToArray<string>()).And(Criterion.Contains("DocumentName", searchCriteria.FileName)).And("EntityTypeID".Equal(searchCriteria.SelectedEntityType)).And("DocumentCategory".Equal(searchCriteria.DocumentCategory)).And("DocType".Equal(searchCriteria.DocumentType)).And("DocumentTag".AnyOf(searchCriteria.SelectedDocumentsTags.Select<ManageDocumentTag, string>((Func<ManageDocumentTag, string>) (x => x.Value)).ToArray<string>())).And(Criterion.Contains("DealNumber", string.IsNullOrEmpty(searchCriteria.DealNumber) ? searchCriteria.DealNumber : searchCriteria.DealNumber.Trim())).And(Criterion.Contains("DealName", string.IsNullOrEmpty(searchCriteria.DealName) ? searchCriteria.DealName : searchCriteria.DealName.Trim())).And("DealIssuer".Equal(searchCriteria.DealIssuerID)).And("DealFirmRoleID".Equal(searchCriteria.DealFirmRole)).And("DealStateID".Equal(searchCriteria.DealState)).And("DealBorrower".Equal(searchCriteria.DealBorrowerId)).And("MSBankingGroupID".Equal(searchCriteria.SelectedBankingGroup)).And(Criterion.Contains("JobNumbers", searchCriteria.JobNumber));
      IVisitableCriterion[] visitableCriterionArray1 = new IVisitableCriterion[1];
      nullable1 = searchCriteria.UploadDateFrom;
      DateTime? nullable4;
      if (!nullable1.HasValue)
      {
        nullable4 = searchCriteria.UploadDateFrom;
      }
      else
      {
        nullable1 = searchCriteria.UploadDateFrom;
        nullable4 = new DateTime?(nullable1.Value);
      }
      visitableCriterionArray1[0] = "UploadDate".GreaterThanOrEqual<DateTime>(nullable4);
      IVisitableCriterion criterion2 = criterion1.And(visitableCriterionArray1);
      IVisitableCriterion[] visitableCriterionArray2 = new IVisitableCriterion[1];
      nullable1 = searchCriteria.UploadDateTo;
      DateTime? nullable5;
      if (!nullable1.HasValue)
      {
        nullable5 = searchCriteria.UploadDateTo;
      }
      else
      {
        nullable1 = searchCriteria.UploadDateTo;
        DateTime dateTime = nullable1.Value;
        dateTime = dateTime.AddDays(1.0);
        nullable5 = new DateTime?(dateTime.AddSeconds(-1.0));
      }
      visitableCriterionArray2[0] = "UploadDate".LessThanOrEqual<DateTime>(nullable5);
      IVisitableCriterion visitableCriterion = criterion2.And(visitableCriterionArray2);
      if (visitableCriterion == EmptyCriterion.Instance && string.IsNullOrEmpty(searchCriteria.Phrase))
      {
        isBlankSearch = true;
        return new List<DocumentSearchResultViewModel>();
      }
      List<DocumentSearchResultViewModel> spSearchResult = new List<DocumentSearchResultViewModel>();
      IDataReader dataReader = (IDataReader) null;
      DataTable table = (DataTable) null;
      try
      {
        this.SetSearchScope();
        List<Document> documentList = new List<Document>();
        List<Document> documents = this.DocumentQuery.Execute(searchCriteria.Phrase, visitableCriterion);
        this.Log.Error(Modules.DocumentSearch, "Execute Completed.");
        table = this.GetPopulatedTable(documents);
        this.Log.Error(Modules.DocumentSearch, "kqlResultTable created." + (object) (table != null ? table.Rows.Count : -1));
        dataReader = this.DocumentSearchRepository.SearchDocument(table);
        if (dataReader != null)
        {
          IRowMapper<DocumentSearchResultViewModel> rowMapper = MapBuilder<DocumentSearchResultViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            spSearchResult.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.DocumentSearch, ex.ToString());
      }
      finally
      {
        table?.Dispose();
        dataReader?.Dispose();
      }
      if (string.IsNullOrEmpty(searchCriteria.Phrase))
      {
        List<DocumentSearchResultViewModel> searchDataFromDb = this.GetSearchDataFromDB(visitableCriterion, request, out total);
        return this.MergeSearchResult(spSearchResult, searchDataFromDb);
      }
      total = (long) spSearchResult.Count;
      return spSearchResult;
    }

    private string ConvertDateFormat(string value)
    {
      DateTime result;
      return !string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result) ? result.ToString("MM/dd/yyyy") : "";
    }

    private string[] GetDocSearchLookupItemKeys() => new string[12]
    {
      "Entity",
      "Issue Status",
      "State",
      "Firm Role",
      "Type of Offering",
      "Use of Proceeds",
      "Fed Tax",
      "State Tax",
      "Issue Repository",
      "RFP Repository",
      "Opportunity Repository",
      "MS Banking Group"
    };

    private List<DocumentSearchResultViewModel> MergeSearchResult(
      List<DocumentSearchResultViewModel> spSearchResult,
      List<DocumentSearchResultViewModel> dbSearchResult)
    {
      if ((dbSearchResult == null || dbSearchResult.Count == 0) && (spSearchResult == null || spSearchResult.Count == 0))
        return new List<DocumentSearchResultViewModel>();
      if (spSearchResult != null && spSearchResult.Count > 0 && (dbSearchResult == null || dbSearchResult.Count == 0))
        return spSearchResult;
      if (dbSearchResult != null && dbSearchResult.Count > 0 && (spSearchResult == null || spSearchResult.Count == 0))
        return dbSearchResult;
      foreach (DocumentSearchResultViewModel searchResultViewModel in dbSearchResult)
      {
        DocumentSearchResultViewModel searchResult = searchResultViewModel;
        if (spSearchResult.FirstOrDefault<DocumentSearchResultViewModel>((Func<DocumentSearchResultViewModel, bool>) (x => x.EntityDocSetDocumentID == searchResult.EntityDocSetDocumentID)) == null)
          spSearchResult.Add(searchResult);
      }
      return spSearchResult;
    }

    private List<DocumentSearchResultViewModel> GetSearchDataFromDB(
      IVisitableCriterion criteria,
      KendoGridRequest request,
      out long total)
    {
      total = 0L;
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      List<DocumentSearchResultViewModel> searchResultViewModelList = new List<DocumentSearchResultViewModel>();
      using (IDataReader dataReader = this.DocumentSearchRepository.Query(new QueryDefinition()
      {
        Criterion = criteria,
        Order = orderingList.ToArray()
      }, request.take, (int) request.skip))
      {
        if (dataReader != null)
        {
          IRowMapper<DocumentSearchResultViewModel> rowMapper = MapBuilder<DocumentSearchResultViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
          {
            DocumentSearchResultViewModel searchResultViewModel = rowMapper.MapRow((IDataRecord) dataReader);
            searchResultViewModelList.Add(searchResultViewModel);
          }
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return searchResultViewModelList;
    }

    private List<SearchResultField> GetAllSearchResultFields()
    {
      List<SearchResultField> searchResultFieldList = new List<SearchResultField>();
      int num1 = 1;
      SearchResultField searchResultField1 = new SearchResultField();
      searchResultField1.Name = "Opportunity/Transaction Number";
      searchResultField1.ExportField = "DealNumber";
      int num2 = num1;
      int num3 = num2 + 1;
      searchResultField1.Order = num2;
      searchResultField1.Html = new SearchResultFieldHtml()
      {
        field = "DealNumber",
        title = "Opportunity/Transaction Number",
        sortable = true,
        isLeftAligned = true,
        width = "250px",
        excelWidth = "4.5cm"
      };
      searchResultFieldList.Add(searchResultField1);
      SearchResultField searchResultField2 = new SearchResultField();
      searchResultField2.Name = "Name/Description";
      searchResultField2.ExportField = "DealName";
      int num4 = num3;
      int num5 = num4 + 1;
      searchResultField2.Order = num4;
      searchResultField2.IsMandatory = true;
      searchResultField2.Html = new SearchResultFieldHtml()
      {
        field = "DealName",
        title = "Name/Description",
        sortable = true,
        isLeftAligned = true,
        width = "300px",
        excelWidth = "5.5cm",
        template = "#= dealNameTemplate(AppTransactionID, EntityTypeID, DealName) #"
      };
      searchResultFieldList.Add(searchResultField2);
      SearchResultField searchResultField3 = new SearchResultField();
      searchResultField3.Name = "Issuer";
      searchResultField3.ExportField = "DealIssuerName";
      int num6 = num5;
      int num7 = num6 + 1;
      searchResultField3.Order = num6;
      searchResultField3.Html = new SearchResultFieldHtml()
      {
        field = "DealIssuerName",
        title = "Issuer",
        sortable = true,
        isLeftAligned = true,
        width = "180px",
        excelWidth = "4cm"
      };
      searchResultFieldList.Add(searchResultField3);
      SearchResultField searchResultField4 = new SearchResultField();
      searchResultField4.Name = "Borrower/Obligor";
      searchResultField4.ExportField = "DealBorrowerName";
      int num8 = num7;
      int num9 = num8 + 1;
      searchResultField4.Order = num8;
      searchResultField4.Html = new SearchResultFieldHtml()
      {
        field = "DealBorrowerName",
        title = "Borrower/Obligor",
        sortable = true,
        isLeftAligned = true,
        width = "180px",
        excelWidth = "4cm"
      };
      searchResultFieldList.Add(searchResultField4);
      SearchResultField searchResultField5 = new SearchResultField();
      searchResultField5.Name = "Opportunity/Transaction Status";
      searchResultField5.ExportField = "DealStatus";
      int num10 = num9;
      int num11 = num10 + 1;
      searchResultField5.Order = num10;
      searchResultField5.Html = new SearchResultFieldHtml()
      {
        field = "DealStatus",
        title = "Opportunity/Transaction Status",
        sortable = true,
        isLeftAligned = true,
        width = "250px",
        excelWidth = "3.5cm"
      };
      searchResultFieldList.Add(searchResultField5);
      SearchResultField searchResultField6 = new SearchResultField();
      searchResultField6.Name = "Firm Role";
      searchResultField6.ExportField = "DealFirmRole";
      int num12 = num11;
      int num13 = num12 + 1;
      searchResultField6.Order = num12;
      searchResultField6.Html = new SearchResultFieldHtml()
      {
        field = "DealFirmRole",
        title = "Firm Role",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3.5cm"
      };
      searchResultFieldList.Add(searchResultField6);
      SearchResultField searchResultField7 = new SearchResultField();
      searchResultField7.Name = "Par Amount";
      searchResultField7.ExportField = "ParAmount";
      int num14 = num13;
      int num15 = num14 + 1;
      searchResultField7.Order = num14;
      searchResultField7.Html = new SearchResultFieldHtml()
      {
        field = "ParAmount",
        title = "Par Amount",
        sortable = true,
        isLeftAligned = false,
        width = "200px",
        format = "{0:c0}",
        excelWidth = "6cm",
        style = "text-align: right !important;",
        excelFormat = "$#,##0"
      };
      searchResultFieldList.Add(searchResultField7);
      SearchResultField searchResultField8 = new SearchResultField();
      searchResultField8.Name = "Document File Name";
      searchResultField8.ExportField = "DocumentName";
      int num16 = num15;
      int num17 = num16 + 1;
      searchResultField8.Order = num16;
      searchResultField8.IsMandatory = true;
      searchResultField8.Html = new SearchResultFieldHtml()
      {
        field = "DocumentName",
        title = "Document File Name",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "4.5cm",
        template = "#= documentNameTemplate(DocumentName, DocumentUrl, EntityDocSetDocumentID) #"
      };
      searchResultFieldList.Add(searchResultField8);
      SearchResultField searchResultField9 = new SearchResultField();
      searchResultField9.Name = "Document Type";
      searchResultField9.ExportField = "DocumentType";
      int num18 = num17;
      int num19 = num18 + 1;
      searchResultField9.Order = num18;
      searchResultField9.Html = new SearchResultFieldHtml()
      {
        field = "DocumentType",
        title = "Document Type",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3.5cm"
      };
      searchResultFieldList.Add(searchResultField9);
      SearchResultField searchResultField10 = new SearchResultField();
      searchResultField10.Name = "Repository";
      searchResultField10.ExportField = "Repository";
      int num20 = num19;
      int num21 = num20 + 1;
      searchResultField10.Order = num20;
      searchResultField10.IsMandatory = true;
      searchResultField10.Html = new SearchResultFieldHtml()
      {
        field = "Repository",
        title = "Repository",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3.5cm"
      };
      searchResultFieldList.Add(searchResultField10);
      SearchResultField searchResultField11 = new SearchResultField();
      searchResultField11.Name = "Upload Date";
      searchResultField11.ExportField = "UploadDate";
      int num22 = num21;
      int num23 = num22 + 1;
      searchResultField11.Order = num22;
      searchResultField11.IsDate = true;
      searchResultField11.Html = new SearchResultFieldHtml()
      {
        field = "UploadDate",
        title = "Upload Date",
        sortable = true,
        isLeftAligned = true,
        width = "170px",
        excelWidth = "4.5cm",
        template = "#= convertUTCDateToLocalDate(UploadDateString) #",
        groupHeaderTemplate = "#= convertUTCDateToLocalDate(value,'') #"
      };
      searchResultFieldList.Add(searchResultField11);
      SearchResultField searchResultField12 = new SearchResultField();
      searchResultField12.Name = "Source Location";
      searchResultField12.ExportField = "SourceLocation";
      int num24 = num23;
      int num25 = num24 + 1;
      searchResultField12.Order = num24;
      searchResultField12.IsDate = true;
      searchResultField12.Html = new SearchResultFieldHtml()
      {
        field = "SourceLocation",
        title = "Source Location",
        sortable = true,
        isLeftAligned = true,
        width = "170px",
        excelWidth = "4.5cm"
      };
      searchResultFieldList.Add(searchResultField12);
      SearchResultField searchResultField13 = new SearchResultField();
      searchResultField13.Name = "MS Banking Group";
      searchResultField13.ExportField = "MSBankingGroup";
      int num26 = num25;
      int num27 = num26 + 1;
      searchResultField13.Order = num26;
      searchResultField13.Html = new SearchResultFieldHtml()
      {
        field = "MSBankingGroup",
        title = "MS Banking Group",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList.Add(searchResultField13);
      SearchResultField searchResultField14 = new SearchResultField();
      searchResultField14.Name = "Job Number(s)";
      searchResultField14.ExportField = "JobNumbers";
      int num28 = num27;
      int num29 = num28 + 1;
      searchResultField14.Order = num28;
      searchResultField14.Html = new SearchResultFieldHtml()
      {
        field = "JobNumbers",
        title = "Job Number(s)",
        sortable = true,
        isLeftAligned = true,
        width = "200px",
        excelWidth = "4cm"
      };
      searchResultFieldList.Add(searchResultField14);
      SearchResultField searchResultField15 = new SearchResultField();
      searchResultField15.Name = "Transaction Description";
      searchResultField15.ExportField = "TransactionDescription";
      int num30 = num29;
      int num31 = num30 + 1;
      searchResultField15.Order = num30;
      searchResultField15.Html = new SearchResultFieldHtml()
      {
        field = "TransactionDescription",
        title = "Transaction Description",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList.Add(searchResultField15);
      SearchResultField searchResultField16 = new SearchResultField();
      searchResultField16.Name = "Opportunity Description";
      searchResultField16.ExportField = "OpportunityDescription";
      int num32 = num31;
      int num33 = num32 + 1;
      searchResultField16.Order = num32;
      searchResultField16.Html = new SearchResultFieldHtml()
      {
        field = "OpportunityDescription",
        title = "Opportunity Description",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList.Add(searchResultField16);
      SearchResultField searchResultField17 = new SearchResultField();
      searchResultField17.Name = "Category";
      searchResultField17.ExportField = "CategoryName";
      int num34 = num33;
      int num35 = num34 + 1;
      searchResultField17.Order = num34;
      searchResultField17.Html = new SearchResultFieldHtml()
      {
        field = "CategoryName",
        title = "Category",
        sortable = true,
        isLeftAligned = true,
        width = "150px",
        excelWidth = "3cm"
      };
      searchResultFieldList.Add(searchResultField17);
      return searchResultFieldList;
    }
  }
}
