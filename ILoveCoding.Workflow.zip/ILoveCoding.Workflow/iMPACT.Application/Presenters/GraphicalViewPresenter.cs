﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.GraphicalViewPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (GraphicalViewPresenter))]
  public class GraphicalViewPresenter : PresenterBase
  {
    [Dependency]
    public IGraphicalViewRepository GraphicalViewRepository { get; set; }

    public WorkflowHtmlViewModel GetWorkflowHtml(long entityID)
    {
      try
      {
        WorkflowHtmlViewModel workflowHtmlViewModel = new WorkflowHtmlViewModel();
        return new WorkflowHtmlViewModel(this.GraphicalViewRepository.GetWorkflowHtml(entityID));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Opportunity, ex.ToString());
        WorkflowHtmlViewModel workflowHtmlViewModel = new WorkflowHtmlViewModel();
        workflowHtmlViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return workflowHtmlViewModel;
      }
    }
  }
}
