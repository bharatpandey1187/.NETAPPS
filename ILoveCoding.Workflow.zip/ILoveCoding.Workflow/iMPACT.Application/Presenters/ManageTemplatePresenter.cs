﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ManageTemplatePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;
using System.Web;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (ManageTemplatePresenter))]
  public class ManageTemplatePresenter : PresenterBase
  {
    [Dependency]
    public IManageTemplateRepository ManageTemplateRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    [Dependency]
    public IUser UserRepository { get; set; }

    [InjectionConstructor]
    public ManageTemplatePresenter()
    {
    }

    public ManageTemplateViewModelContainer FetchAll()
    {
      try
      {
        ManageTemplateViewModelContainer viewModelContainer = new ManageTemplateViewModelContainer();
        List<LookupItemViewModel> lookupItemViewModelList = new List<LookupItemViewModel>();
        List<ManageTemplateViewModel> templateViewModelList = new List<ManageTemplateViewModel>();
        using (IDataReader dataReader = this.ManageTemplateRepository.FetchAll())
        {
          IRowMapper<LookupItemViewModel> rowMapper1 = MapBuilder<LookupItemViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<LookupItemViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<LookupItemViewModel, string>>) (x => x.ErrorMessage)).Build();
          while (dataReader.Read())
            lookupItemViewModelList.Add(rowMapper1.MapRow((IDataRecord) dataReader));
          IRowMapper<ManageTemplateViewModel> rowMapper2 = MapBuilder<ManageTemplateViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<ManageTemplateViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<ManageTemplateViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<ManageTemplateViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<bool>((Expression<Func<ManageTemplateViewModel, bool>>) (x => x.IsEditEnable)).Build();
          if (dataReader.NextResult())
          {
            while (dataReader.Read())
              templateViewModelList.Add(rowMapper2.MapRow((IDataRecord) dataReader));
          }
        }
        viewModelContainer.EntityTypes = lookupItemViewModelList;
        foreach (ManageTemplateViewModel templateViewModel in templateViewModelList)
          templateViewModel.IsEditEnable = templateViewModel.EntityTemplateID < 0L;
        viewModelContainer.ManageTemplateItems = templateViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new ManageTemplateViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public SaveResult SaveManageTemplateItems(
      List<ManageTemplateViewModel> manageTemplateItemsViewModel)
    {
      try
      {
        this.GetSafeObject<ManageTemplateViewModel>(manageTemplateItemsViewModel);
        List<SaveResult> saveResultList = new List<SaveResult>();
        foreach (ManageTemplateViewModel templateViewModel in manageTemplateItemsViewModel)
        {
          SaveResult saveResult = templateViewModel.Validate<ManageTemplateViewModel>();
          if (!saveResult.IsSuccessful)
          {
            saveResult.Id = templateViewModel.EntityTemplateID;
            saveResultList.Add(saveResult);
          }
        }
        if (saveResultList.Count > 0)
          return new SaveResult()
          {
            Errors = {
              {
                "ManageTemplateItems",
                (object) saveResultList
              }
            }
          };
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.ManageTemplateRepository.Save(manageTemplateItemsViewModel.Select<ManageTemplateViewModel, ManageTemplate>((Func<ManageTemplateViewModel, ManageTemplate>) (x => x.GetManageTemplateItem())).ToList<ManageTemplate>());
          transactionScope.Complete();
        }
        if (SaveResult.Success.IsSuccessful && manageTemplateItemsViewModel.Any<ManageTemplateViewModel>((Func<ManageTemplateViewModel, bool>) (x => x.EntityID == -1L)))
          HttpContext.Current.Cache.Remove(Constants.MenuCacheKey);
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public ManageTemplateViewModelContainer FetchEntityTemplateByEntityID(
      long entityID,
      long entityTypeDocSetId,
      long appTransactionId)
    {
      try
      {
        return new ManageTemplateViewModelContainer()
        {
          ManageTemplateItems = this.ManageTemplateRepository.FetchEntityTemplateByEntityID(entityID, entityTypeDocSetId, appTransactionId, this.UserRepository.GetEffectivePrincipalIds()).Select<ManageTemplate, ManageTemplateViewModel>((Func<ManageTemplate, ManageTemplateViewModel>) (x => new ManageTemplateViewModel(x))).ToList<ManageTemplateViewModel>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        ManageTemplateViewModelContainer viewModelContainer = new ManageTemplateViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public SaveResult DeleteEntityTemplates(List<long> lstEntityTemplateID)
    {
      try
      {
        this.ManageTemplateRepository.Delete(lstEntityTemplateID);
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult MoveEntityTemplate(
      List<ManageTemplateViewModel> manageTemplateItemsViewModel)
    {
      try
      {
        this.ManageTemplateRepository.Move(manageTemplateItemsViewModel.Select<ManageTemplateViewModel, ManageTemplate>((Func<ManageTemplateViewModel, ManageTemplate>) (x => x.GetManageTemplateItem())).ToList<ManageTemplate>());
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult CopyEntityTemplate(
      List<ManageTemplateViewModel> manageTemplateItemsViewModel)
    {
      try
      {
        this.ManageTemplateRepository.Copy(manageTemplateItemsViewModel.Select<ManageTemplateViewModel, ManageTemplate>((Func<ManageTemplateViewModel, ManageTemplate>) (x => x.GetManageTemplateItem())).ToList<ManageTemplate>());
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }
  }
}
