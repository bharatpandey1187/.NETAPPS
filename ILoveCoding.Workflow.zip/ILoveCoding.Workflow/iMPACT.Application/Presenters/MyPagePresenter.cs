﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.MyPagePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (MyPagePresenter))]
  public class MyPagePresenter : PresenterBase
  {
    [Dependency]
    public IIssueRepository IssueRepository { get; set; }

    public MyPageCalendarContainer GetCalendar()
    {
      try
      {
        MyPageCalendarContainer calendarContainer = new MyPageCalendarContainer();
        List<MyPageSeriesViewModel> source = new List<MyPageSeriesViewModel>();
        using (IDataReader dataReader = this.IssueRepository.FetchCalendar())
        {
          if (dataReader != null)
          {
            IRowMapper<MyPageOpportunityCalendarViewModel> rowMapper1 = MapBuilder<MyPageOpportunityCalendarViewModel>.MapAllProperties().Build();
            while (dataReader.Read())
              calendarContainer.Opportunities.Add(rowMapper1.MapRow((IDataRecord) dataReader));
            if (dataReader.NextResult())
            {
              IRowMapper<MyPageIssueCalendarViewModel> rowMapper2 = MapBuilder<MyPageIssueCalendarViewModel>.MapAllProperties().Build();
              while (dataReader.Read())
                calendarContainer.Issues.Add(rowMapper2.MapRow((IDataRecord) dataReader));
            }
            if (dataReader.NextResult())
            {
              IRowMapper<MyPageSeriesViewModel> rowMapper2 = MapBuilder<MyPageSeriesViewModel>.MapAllProperties().Build();
              while (dataReader.Read())
                source.Add(rowMapper2.MapRow((IDataRecord) dataReader));
            }
          }
        }
        if (calendarContainer.Issues.Count > 0)
        {
          foreach (MyPageIssueCalendarViewModel issue1 in calendarContainer.Issues)
          {
            MyPageIssueCalendarViewModel issue = issue1;
            issue.Series = source.Where<MyPageSeriesViewModel>((Func<MyPageSeriesViewModel, bool>) (x => x.AppTransactionID == issue.AppTransactionID)).ToList<MyPageSeriesViewModel>();
          }
        }
        return calendarContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        MyPageCalendarContainer calendarContainer = new MyPageCalendarContainer();
        calendarContainer.ErrorMessage = "An error occurred while fetching the data.";
        return calendarContainer;
      }
    }
  }
}
