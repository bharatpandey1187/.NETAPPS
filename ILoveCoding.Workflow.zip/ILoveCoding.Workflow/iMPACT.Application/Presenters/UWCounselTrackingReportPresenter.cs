﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.UWCounselTrackingReportPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Data;
using IrisSoftware.Reporting.ReportBuilder;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [IrisSoftware.iMPACT.Core.Unity.Export(typeof (UWCounselTrackingReportPresenter))]
  public class UWCounselTrackingReportPresenter : PresenterBase
  {
    [Dependency]
    public IUWCounselTrackingReportRepository UWConselTrackingReportRepository { get; set; }

    [Dependency]
    public ILookupRepository LookupRepository { get; set; }

    public UWCounselTrackingReportSearchViewModel InitializeViewModel() => new UWCounselTrackingReportSearchViewModel()
    {
      StateTypes = this.LookupRepository.FetchByLookupKey("State").Select<LookupItem, KeyValuePair<long, string>>((Func<LookupItem, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.LookupItemID, x.Value))).ToList<KeyValuePair<long, string>>()
    };

    public Paged<UWCounselTrackingReportViewModel> GetUWConselTrackingReport(
      KendoGridRequest request,
      UWCounselTrackingReportSearchViewModel model)
    {
      try
      {
        long total = 0;
        return new Paged<UWCounselTrackingReportViewModel>((IList<UWCounselTrackingReportViewModel>) this.GetSearchData(request, model, out total), total);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new Paged<UWCounselTrackingReportViewModel>((IList<UWCounselTrackingReportViewModel>) new List<UWCounselTrackingReportViewModel>(), 0L);
      }
    }

    private List<UWCounselTrackingReportViewModel> GetSearchData(
      KendoGridRequest request,
      UWCounselTrackingReportSearchViewModel model,
      out long total)
    {
      total = 0L;
      List<UWCounselTrackingReportViewModel> trackingReportViewModelList = new List<UWCounselTrackingReportViewModel>();
      List<Ordering> orderingList = new List<Ordering>();
      if (request.sort.Length != 0)
      {
        foreach (KendoGridRequest.SortObject sortObject in request.sort)
          orderingList.Add(new Ordering()
          {
            PropertyName = sortObject.field,
            Direction = sortObject.dir == "asc" ? OrderDirection.Asc : OrderDirection.Desc
          });
      }
      else
        orderingList = ((IEnumerable<Ordering>) Ordering.Empty).ToList<Ordering>();
      if (string.IsNullOrEmpty(model.LeadBanker))
        model.LeadBankerEmployeeId = 0L;
      if (string.IsNullOrEmpty(model.UnderWriter))
        model.UnderWriterId = 0L;
      using (IDataReader dataReader = this.UWConselTrackingReportRepository.FetchUWConselTrackingReportData(model.DateFrom, model.DateTo, new long?(model.LeadBankerEmployeeId), new long?(model.UnderWriterId), new long?(model.StateId), 1, orderingList.ToArray(), (int) request.skip, request.take))
      {
        if (dataReader != null)
        {
          IRowMapper<UWCounselTrackingReportViewModel> rowMapper = MapBuilder<UWCounselTrackingReportViewModel>.MapAllProperties().Build();
          while (dataReader.Read())
            trackingReportViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
          if (dataReader.NextResult())
          {
            if (dataReader.Read())
              total = (long) dataReader.GetInt32(0);
          }
        }
      }
      return trackingReportViewModelList;
    }

    private Decimal? ConvertToDecimal(string str) => string.IsNullOrEmpty(str) ? new Decimal?() : new Decimal?(Convert.ToDecimal(str));

    public ExportResult Export(
      KendoGridRequest request,
      UWCounselTrackingReportSearchViewModel searchCriteria,
      string exportType)
    {
      try
      {
        string empty1 = string.Empty;
        string empty2 = string.Empty;
        List<UWCounselTrackingReportViewModel> searchData = this.GetSearchData(request, searchCriteria, out long _);
        PageLayout pageLayout = new PageLayout(new Unit(16.0, UnitType.Inch), new Unit(8.5, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch), new Unit(0.3, UnitType.Inch));
        Func<UWCounselTrackingReportViewModel, \u003C\u003Ef__AnonymousType18<string, string, string, string, Decimal?, string, string, string, string, string, Decimal?>> selector = d =>
        {
          string issueNbr = d.IssueNbr;
          string issuer = d.Issuer;
          string issuerState = d.IssuerState;
          string serTransactionName = d.SerTransactionName;
          Decimal? nullable1 = this.ConvertToDecimal(d.ParAmount);
          DateTime? nullable2;
          DateTime dateTime;
          string str1;
          if (!d.SettlementDate.HasValue)
          {
            str1 = "";
          }
          else
          {
            nullable2 = d.SettlementDate;
            dateTime = nullable2.Value;
            str1 = dateTime.ToString("MM/dd/yyyy");
          }
          string leadBanker = d.LeadBanker;
          string counselFirmName = d.CounselFirmName;
          string counselContact = d.CounselContact;
          nullable2 = d.DateCounselApprovedByLegal;
          string str2;
          if (!nullable2.HasValue)
          {
            str2 = "";
          }
          else
          {
            nullable2 = d.DateCounselApprovedByLegal;
            dateTime = nullable2.Value;
            str2 = dateTime.ToString("MM/dd/yyyy");
          }
          Decimal? nullable3 = this.ConvertToDecimal(d.UnderWriterCounselFeePaid);
          return new
          {
            IssueNbr = issueNbr,
            Issuer = issuer,
            IssuerState = issuerState,
            SerTransactionName = serTransactionName,
            ParAmount = nullable1,
            SettlementDate = str1,
            LeadBanker = leadBanker,
            CounselFirmName = counselFirmName,
            CounselContact = counselContact,
            DateCounselApprovedByLegal = str2,
            UnderWriterCounselFeePaid = nullable3
          };
        };
        IEnumerable<\u003C\u003Ef__AnonymousType18<string, string, string, string, Decimal?, string, string, string, string, string, Decimal?>> datas = searchData.Select(selector);
        PageHeaderFooterBuilder pageHeaderBuilder = new PageHeaderFooterBuilder();
        pageHeaderBuilder.AddText("UW Counsel Tracking Report", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignCenter()).AddText(DateTime.UtcNow.ToString("MM/dd/yyyy hh:mm:ss tt") + " (UTC)", new Rectangle(Unit.Parse("0in"), Unit.Parse("0in"), Unit.Parse("10in"), Unit.Empty), new StyleTypeBuilder().Bold().AlignRight()).AddLine(new Rectangle(Unit.Parse("0in"), Unit.Parse(".5in"), Unit.Parse("0in"), Unit.Empty), new LineStyleTypeBuilder());
        TabularReportBuilder tabularReportBuilder = new TabularReportBuilder();
        tabularReportBuilder.SetPageLayout((IPageLayout) pageLayout).SetPageHeaderBuilder(pageHeaderBuilder);
        foreach (KendoGridRequest.GroupObject groupObject in request.group)
        {
          foreach (KendoGridRequest.ColumnObject column in request.columns)
          {
            if (column.field == groupObject.field)
              tabularReportBuilder.AddGroup(column.title, groupObject.field, Unit.Parse("5cm"));
          }
        }
        DefaultTabularColumnStyleProvider columnStyleProvider1 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider1.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider1.CellStyleBuilder.BorderColor("black");
        columnStyleProvider1.CellStyleBuilder.AlignLeft();
        columnStyleProvider1.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        DefaultTabularColumnStyleProvider columnStyleProvider2 = new DefaultTabularColumnStyleProvider();
        columnStyleProvider2.CellStyleBuilder.BorderBottom(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderTop(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderRight(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderLeft(BorderStyle.Solid);
        columnStyleProvider2.CellStyleBuilder.BorderColor("black");
        columnStyleProvider2.CellStyleBuilder.AlignRight();
        columnStyleProvider2.CellStyleBuilder.Padding(Unit.Parse(".05cm"));
        columnStyleProvider2.CellStyleBuilder.LeftRightPadding(Unit.Parse(".35cm"));
        tabularReportBuilder.AddColumn("Transaction Number", "IssueNbr", Unit.Parse("3cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Issuer", "Issuer", Unit.Parse("6cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("State", "IssuerState", Unit.Parse("1.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Series Description", "SerTransactionName", Unit.Parse("5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddMeasure("Par Amount", "ParAmount", Unit.Parse("6cm"), "$#,##0", (IColumnStyleProvider) columnStyleProvider2);
        tabularReportBuilder.AddColumn("Delivery Date", "SettlementDate", Unit.Parse("2.5cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Lead Banker", "LeadBanker", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Underwriter's Counsel Firm Name", "CounselFirmName", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        tabularReportBuilder.AddColumn("Underwriter's Counsel Primary Contact", "CounselContact", Unit.Parse("4cm"), "", (IColumnStyleProvider) columnStyleProvider1);
        return new ReportExporter().Export(tabularReportBuilder.Build(), exportType, "UWCounselTrackingReport", (object) datas);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
        return new ExportResult();
      }
    }
  }
}
