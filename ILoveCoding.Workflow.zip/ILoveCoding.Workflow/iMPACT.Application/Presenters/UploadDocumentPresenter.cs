﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.UploadDocumentPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (UploadDocumentPresenter))]
  public class UploadDocumentPresenter : PresenterBase
  {
    [Dependency]
    public IAppTransactionDocSetRepository appTransactionDocSetRepository { get; set; }

    [Dependency]
    public UploadCategoryPresenter uploadCategoryPresenter { get; set; }

    [Dependency]
    public IDocumentServiceProvider documentServiceProvider { get; set; }

    [Dependency]
    public IAuditTrailRepository AuditTrailRepository { get; set; }

    [Dependency]
    public UploadDocumentPresenter UploadDocPresenter { get; set; }

    [Dependency]
    public IAppTransactionDocSetDocumentRepository appTransactionDocSetDocumentRepository { get; set; }

    [Dependency]
    public IAppConfigRepository AppConfigRepository { get; set; }

    [Dependency]
    public IEntityDocSetTypeRepository EntityDocSetTypeRepository { get; set; }

    public UploadDocumentViewModelContainer GetUploadDocumentsByTransactions(
      long appTransactionID,
      long entityTypeID)
    {
      IDocumentService service = this.documentServiceProvider.GetService("SharePoint");
      try
      {
        switch (entityTypeID)
        {
          case -33:
          case -32:
          case -31:
            if (!this.HasUIPermissionForEntityStatusMultiple(appTransactionID, IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities, "View"))
            {
              UploadDocumentViewModelContainer viewModelContainer = new UploadDocumentViewModelContainer();
              viewModelContainer.ErrorMessage = "401";
              return viewModelContainer;
            }
            break;
          case -4:
            if (!this.HasIndependentPermission("Boilerplate-Opportunity Documents", "View") && !this.HasIndependentPermission("Boilerplate-Transaction Documents", "View"))
            {
              UploadDocumentViewModelContainer viewModelContainer = new UploadDocumentViewModelContainer();
              viewModelContainer.ErrorMessage = "401";
              return viewModelContainer;
            }
            break;
          case -3:
            if (!this.HasIndependentPermission("Contact Documents", "View"))
            {
              UploadDocumentViewModelContainer viewModelContainer = new UploadDocumentViewModelContainer();
              viewModelContainer.ErrorMessage = "401";
              return viewModelContainer;
            }
            break;
          case -2:
            if (!this.HasIndependentPermission("Help Documents", "View"))
            {
              UploadDocumentViewModelContainer viewModelContainer = new UploadDocumentViewModelContainer();
              viewModelContainer.ErrorMessage = "401";
              return viewModelContainer;
            }
            break;
          case -1:
            if (!this.HasIndependentPermission("Client Documents", "View"))
            {
              UploadDocumentViewModelContainer viewModelContainer = new UploadDocumentViewModelContainer();
              viewModelContainer.ErrorMessage = "401";
              return viewModelContainer;
            }
            break;
        }
        UploadDocumentViewModelContainer viewModelContainer1 = new UploadDocumentViewModelContainer();
        List<UploadDocumentViewModel> documentViewModelList = entityTypeID == -31L || entityTypeID == -32L || entityTypeID == -33L ? this.appTransactionDocSetRepository.FetchByKey(entityTypeID, appTransactionID, (long) this.AppUser.Id).Select<AppTransactionDocSet, UploadDocumentViewModel>((Func<AppTransactionDocSet, UploadDocumentViewModel>) (x => new UploadDocumentViewModel(x))).ToList<UploadDocumentViewModel>() : this.appTransactionDocSetRepository.FetchByEntityTypeID(entityTypeID, appTransactionID, (long) this.AppUser.Id).Select<AppTransactionDocSet, UploadDocumentViewModel>((Func<AppTransactionDocSet, UploadDocumentViewModel>) (x => new UploadDocumentViewModel(x))).ToList<UploadDocumentViewModel>();
        List<UploadCategoryViewModel> uploadCategories = this.uploadCategoryPresenter.GetAllUploadCategories().UploadCategories;
        foreach (UploadDocumentViewModel documentViewModel in documentViewModelList)
        {
          List<DocumentInfo> documentInfoList = new List<DocumentInfo>();
          documentViewModel.MiscDocumentInfos = new List<MiscDocumentInfo>();
          foreach (Document document in this.appTransactionDocSetDocumentRepository.GetDocuments(appTransactionID, documentViewModel.EntityDocSetTypeID.Value))
          {
            MiscDocumentInfo miscDocumentInfo1 = new MiscDocumentInfo();
            long uploadCategoryId = string.IsNullOrEmpty(document.EntityTypeDocTypeCategoryID) ? 0L : Convert.ToInt64(Decimal.Truncate(Convert.ToDecimal(document.EntityTypeDocTypeCategoryID)));
            UploadCategoryViewModel categoryViewModel = uploadCategories.First<UploadCategoryViewModel>((Func<UploadCategoryViewModel, bool>) (x => x.EntityTypeDocTypeCategoryID == uploadCategoryId));
            miscDocumentInfo1.EntityDocSetDocumentID = document.EntityDocSetDocumentID;
            miscDocumentInfo1.Category = categoryViewModel != null ? categoryViewModel.CategoryName : string.Empty;
            miscDocumentInfo1.Name = document.DocumentName;
            miscDocumentInfo1.Tags = document.Tags;
            miscDocumentInfo1.Type = document.EntityTypeDocTypeID;
            miscDocumentInfo1.StorageKey = document.StorageKey;
            if (!string.IsNullOrEmpty(miscDocumentInfo1.Category))
            {
              long uploadDocTypeId = string.IsNullOrEmpty(document.EntityTypeDocTypeID) ? 0L : Convert.ToInt64(Decimal.Truncate(Convert.ToDecimal(document.EntityTypeDocTypeID)));
              UploadDocTypeViewModel docTypeViewModel = this.uploadCategoryPresenter.GetAllUploadDocTypesByUploadCategoryID(uploadCategoryId, 1).FirstOrDefault<UploadDocTypeViewModel>((Func<UploadDocTypeViewModel, bool>) (x => x.UploadDocTypeID == uploadDocTypeId));
              miscDocumentInfo1.Type = docTypeViewModel != null ? docTypeViewModel.Name : string.Empty;
            }
            miscDocumentInfo1.TypeOtherDesc = document.TypeOtherDesc;
            miscDocumentInfo1.WebURL = service.GetVersionHistoryUrl();
            miscDocumentInfo1.FullUrl = document.DocumentURL;
            miscDocumentInfo1.CheckOutType = document.CheckOutType;
            miscDocumentInfo1.TotalVersion = document.TotalVersion;
            miscDocumentInfo1.UIVersionLabel = document.UIVersionLabel;
            miscDocumentInfo1.FileID = document.DocumentId;
            miscDocumentInfo1.CheckedOutBy = document.CheckedOutBy;
            DateTime? nullable;
            if (document.CheckedOutDate.HasValue)
            {
              MiscDocumentInfo miscDocumentInfo2 = miscDocumentInfo1;
              nullable = document.CheckedOutDate;
              DateTime dateTime = nullable.Value;
              miscDocumentInfo2.CheckedOutDate = dateTime;
            }
            nullable = document.CheckedOutExpires;
            if (nullable.HasValue)
            {
              MiscDocumentInfo miscDocumentInfo2 = miscDocumentInfo1;
              nullable = document.CheckedOutExpires;
              DateTime dateTime = nullable.Value;
              miscDocumentInfo2.CheckedOutExpires = dateTime;
            }
            miscDocumentInfo1.LastModifiedBy = document.LastModifiedBy;
            miscDocumentInfo1.LastModifiedOn = document.LastModifiedOn;
            Guid result = new Guid();
            if (!document.DocumentListID.TryParse(out result))
              throw new CustomException(string.Format("Cannot convert string value: {0} to GUID.", (object) document.DocumentListID));
            documentViewModel.ListID = result;
            documentViewModel.MiscDocumentInfos.Add(miscDocumentInfo1);
          }
          documentViewModel.MiscDocumentInfos = documentViewModel.MiscDocumentInfos.OrderBy<MiscDocumentInfo, string>((Func<MiscDocumentInfo, string>) (x => x.Category)).ThenBy<MiscDocumentInfo, string>((Func<MiscDocumentInfo, string>) (x => x.Type)).ThenBy<MiscDocumentInfo, string>((Func<MiscDocumentInfo, string>) (x => x.Name)).ToList<MiscDocumentInfo>();
        }
        viewModelContainer1.uploadDocumentViewModel = documentViewModelList;
        AppConfig appConfig = this.AppConfigRepository.FetchByKey(50);
        viewModelContainer1.GroupDocumentsByCategory = appConfig == null || !(appConfig.Value != "") ? 0L : Convert.ToInt64(appConfig.Value);
        return viewModelContainer1;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        UploadDocumentViewModelContainer viewModelContainer = new UploadDocumentViewModelContainer();
        viewModelContainer.ErrorMessage = "An error occurred while fetching the data.";
        return viewModelContainer;
      }
    }

    public void CheckOut(long appTransactionDocSetDocumentID)
    {
      try
      {
        if (!this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities))
          return;
        Document document = this.appTransactionDocSetDocumentRepository.GetDocument(appTransactionDocSetDocumentID);
        this.appTransactionDocSetDocumentRepository.Update(this.documentServiceProvider.GetService(document.StorageKey).CheckOut(document));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public void CheckIn(long appTransactionDocSetDocumentID, string comments)
    {
      try
      {
        if (!this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities))
          return;
        Document document = this.appTransactionDocSetDocumentRepository.GetDocument(appTransactionDocSetDocumentID);
        this.appTransactionDocSetDocumentRepository.Update(this.documentServiceProvider.GetService(document.StorageKey).CheckIn(document, comments));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public void UndoCheckOut(long appTransactionDocSetDocumentID)
    {
      try
      {
        if (!this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities))
          return;
        Document document = this.appTransactionDocSetDocumentRepository.GetDocument(appTransactionDocSetDocumentID);
        this.appTransactionDocSetDocumentRepository.Update(this.documentServiceProvider.GetService(document.StorageKey).UndoCheckOut(document));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public void DeleteFiles(long[] appTransactionDocSetDocumentIDs)
    {
      try
      {
        if (!this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities))
          return;
        foreach (long docSetDocumentId in appTransactionDocSetDocumentIDs)
        {
          Document document = this.appTransactionDocSetDocumentRepository.GetDocument(docSetDocumentId);
          using (TransactionScope transactionScope = new TransactionScope())
          {
            this.appTransactionDocSetDocumentRepository.Delete(docSetDocumentId);
            this.documentServiceProvider.GetService(document.StorageKey).Delete(document);
            string empty = string.Empty;
            string name = ((SPPrincipal) SPContext.get_Current().get_Web().get_CurrentUser()).get_Name();
            this.appTransactionDocSetDocumentRepository.SaveToDocumentLog((long) Convert.ToInt32(document.EntityType), document.EntityID, document.DocumentName, (long) Convert.ToInt32(document.EntityTypeDocTypeID), DateTime.Now, "Document Deleted", name);
            transactionScope.Complete();
          }
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public void MoveFiles(long[] documentKeys, string destDocLibUrl, int docSetId)
    {
      try
      {
        if (!this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities))
          return;
        DocSetInfo docSetInfo = new DocSetInfo();
        docSetInfo.DocSetId = docSetId.ToString();
        docSetInfo.URL = destDocLibUrl;
        List<Document> docSetDocumentIds = this.appTransactionDocSetDocumentRepository.GetDocumentsByAppTransactionDocSetDocumentIDs(((IEnumerable<long>) documentKeys).ToList<long>());
        this.appTransactionDocSetDocumentRepository.Move(this.documentServiceProvider.GetService("SharePoint").Move(docSetDocumentIds, docSetInfo));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public void CopyFiles(long[] documentKeys, string destDocLibUrl, int docSetId)
    {
      try
      {
        if (!this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities))
          return;
        DocSetInfo docSetInfo = new DocSetInfo();
        docSetInfo.DocSetId = docSetId.ToString();
        docSetInfo.URL = destDocLibUrl;
        List<Document> docSetDocumentIds = this.appTransactionDocSetDocumentRepository.GetDocumentsByAppTransactionDocSetDocumentIDs(((IEnumerable<long>) documentKeys).ToList<long>());
        IDocumentService service = this.documentServiceProvider.GetService("SharePoint");
        foreach (Document doc in docSetDocumentIds)
        {
          byte[] numArray = (byte[]) null;
          using (Stream stream = service.Download(doc))
          {
            numArray = new byte[stream.Length];
            stream.Read(numArray, 0, (int) stream.Length);
            stream.Close();
          }
          doc.DocSetId = docSetInfo.DocSetId;
          doc.DocSetURL = docSetInfo.URL;
          this.Upload(doc, numArray);
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public void Upload(Document doc, byte[] bytes)
    {
      try
      {
        if (!this.HasAnyPermissionOnSet(IrisSoftware.iMPACT.Data.Constants.Permissions.DocumentRepositorySetAllEntities))
          return;
        this.appTransactionDocSetDocumentRepository.Save(this.documentServiceProvider.GetService("SharePoint").Upload(doc, bytes));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
      }
    }

    public MemoryStream Download(string fileID, out Document doc)
    {
      doc = (Document) null;
      try
      {
        long result = 0;
        long.TryParse(fileID, out result);
        doc = this.appTransactionDocSetDocumentRepository.GetDocument(result);
        return (MemoryStream) this.documentServiceProvider.GetService(doc.StorageKey).Download(doc);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new MemoryStream();
      }
    }

    private void RenderContactsEntityIDDropDown(
      DocumentUploadDropdownViewModelContainer DropDownContainer,
      IDataReader reader)
    {
      if (!reader.NextResult())
        return;
      IRowMapper<ShowContactDetails> rowMapper = MapBuilder<ShowContactDetails>.MapAllProperties().Build();
      while (reader.Read())
        DropDownContainer.ShowContactDetails = rowMapper.MapRow((IDataRecord) reader);
    }

    private void RenderClientEntityIDDropDown(
      DocumentUploadDropdownViewModelContainer DropDownContainer,
      IDataReader reader)
    {
      if (!reader.NextResult())
        return;
      IRowMapper<ShowClientDetails> rowMapper = MapBuilder<ShowClientDetails>.MapAllProperties().Build();
      while (reader.Read())
        DropDownContainer.ShowClientDetails = rowMapper.MapRow((IDataRecord) reader);
    }

    public DocumentUploadDropdownViewModelContainer GetDropDownsData(
      long appTransactionID,
      int entityId)
    {
      try
      {
        DocumentUploadDropdownViewModelContainer DropDownContainer = new DocumentUploadDropdownViewModelContainer();
        IDataReader reader = entityId == -31 || entityId == -32 || entityId == -33 ? this.appTransactionDocSetRepository.FetchUploadDropDowns(appTransactionID, entityId) : this.appTransactionDocSetRepository.FetchStateIndependentUploadDropDowns(appTransactionID, entityId);
        if (reader != null)
        {
          IRowMapper<RepositoryViewModel> rowMapper1 = MapBuilder<RepositoryViewModel>.MapAllProperties().Build();
          while (reader.Read())
            DropDownContainer.RepositoryDropDown.Add(rowMapper1.MapRow((IDataRecord) reader));
          if (reader.NextResult())
          {
            IRowMapper<CategoryViewModel> rowMapper2 = MapBuilder<CategoryViewModel>.MapAllProperties().Build();
            while (reader.Read())
              DropDownContainer.CategoryDropDown.Add(rowMapper2.MapRow((IDataRecord) reader));
          }
          if (reader.NextResult())
          {
            IRowMapper<DocTypeViewModel> rowMapper2 = MapBuilder<DocTypeViewModel>.MapAllProperties().Build();
            while (reader.Read())
              DropDownContainer.DocTypeDropDown.Add(rowMapper2.MapRow((IDataRecord) reader));
          }
          if (reader.NextResult())
          {
            IRowMapper<TagViewModel> rowMapper2 = MapBuilder<TagViewModel>.MapAllProperties().Build();
            while (reader.Read())
              DropDownContainer.TagDropDown.Add(rowMapper2.MapRow((IDataRecord) reader));
          }
          switch (entityId)
          {
            case -3:
              this.RenderContactsEntityIDDropDown(DropDownContainer, reader);
              break;
            case -1:
              this.RenderClientEntityIDDropDown(DropDownContainer, reader);
              break;
            default:
              if (reader.NextResult())
              {
                IRowMapper<ShowDealDetails> rowMapper2 = MapBuilder<ShowDealDetails>.MapAllProperties().Build();
                while (reader.Read())
                  DropDownContainer.ShowDealDetail = rowMapper2.MapRow((IDataRecord) reader);
                break;
              }
              break;
          }
        }
        reader?.Dispose();
        return DropDownContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.RFP, ex.ToString());
        return new DocumentUploadDropdownViewModelContainer();
      }
    }

    public DocSetDocumentViewModelContainer FetchDocSetDocuments(
      long AppTransactionID)
    {
      try
      {
        List<DocSetDocument> docSetDocumentList1 = new List<DocSetDocument>();
        List<DocSetDocument> docSetDocumentList2 = this.appTransactionDocSetRepository.FetchDocSetDocumentByAppTransactionID(AppTransactionID);
        DocSetDocumentViewModelContainer viewModelContainer = new DocSetDocumentViewModelContainer();
        List<DocSetDocumentViewModel> documentViewModelList = new List<DocSetDocumentViewModel>();
        foreach (DocSetDocument doc in docSetDocumentList2)
        {
          DocSetDocumentViewModel documentViewModel = new DocSetDocumentViewModel(doc);
          documentViewModelList.Add(documentViewModel);
        }
        viewModelContainer.docSetDocuments = documentViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new DocSetDocumentViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public List<Document> GetDocuments(string entityID, string docSetID) => this.documentServiceProvider.GetService("SharePoint").GetDocuments(entityID, docSetID);

    public void ApplyPermission(
      string entityType,
      string docSetId,
      List<DocSetPermission> issueDocSetPermissions,
      Hashtable sharedFields)
    {
      this.documentServiceProvider.GetService("SharePoint").ApplyPermission(entityType, docSetId, issueDocSetPermissions, sharedFields);
    }

    public void UpdateSharedFields(string entityType, string docSetId, Hashtable sharedFields) => this.documentServiceProvider.GetService("SharePoint").UpdateSharedFields(entityType, docSetId, sharedFields);

    public DocSetInfo CreateDocSet(
      DocSetInfo docSetInfo,
      List<DocSetPermission> documentSetPermissions,
      Hashtable sharedFields)
    {
      return this.documentServiceProvider.GetService("SharePoint").CreateDocSet(docSetInfo, documentSetPermissions, sharedFields);
    }

    public void PerformSharePointDocumentSetOperations(long transactionId, long entityId)
    {
      try
      {
        List<AppTransactionDocSet> transactionDocSetList = this.appTransactionDocSetRepository.FetchByAppTransactionID(transactionId);
        List<EntityDocSetType> entityDocSetTypeList = this.EntityDocSetTypeRepository.FetchEntityDocSetTypeByEntityID(entityId);
        string libLocation = this.appTransactionDocSetRepository.FetchLibraryURLByEntityTypeID(entityId);
        List<DocSetPermission> docSetPermissionList = new List<DocSetPermission>();
        foreach (EntityDocSetType entityDocSetType in entityDocSetTypeList)
        {
          EntityDocSetType docSetType = entityDocSetType;
          List<DocSetPermission> docSetPermissions = (List<DocSetPermission>) null;
          Hashtable properties = new Hashtable();
          UploadDocumentPresenter.GetRepositoryLevelProperties_New(properties, docSetType);
          if (!transactionDocSetList.Exists((Predicate<AppTransactionDocSet>) (x =>
          {
            long? entityDocSetTypeId1 = x.EntityDocSetTypeID;
            long entityDocSetTypeId2 = docSetType.EntityDocSetTypeID;
            return entityDocSetTypeId1.GetValueOrDefault() == entityDocSetTypeId2 && entityDocSetTypeId1.HasValue;
          })))
            this.CreateIssueDocumentSets(transactionId, properties, libLocation, docSetType, docSetPermissions);
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
      }
    }

    private static void GetRepositoryLevelProperties_New(
      Hashtable properties,
      EntityDocSetType docSetType)
    {
      if (properties.ContainsKey((object) "Title"))
        properties[(object) "Title"] = (object) docSetType.DocSetName;
      else
        properties.Add((object) "Title", (object) docSetType.DocSetName);
      if (properties.ContainsKey((object) "iDocSetType"))
        properties[(object) "iDocSetType"] = (object) docSetType.EntityDocSetTypeID;
      else
        properties.Add((object) "iDocSetType", (object) docSetType.EntityDocSetTypeID);
    }

    private Hashtable PopulateProperties(DateTime createdDate) => new Hashtable()
    {
      {
        (object) "iCreateDate",
        (object) (createdDate == DateTime.MinValue.Date ? DateTime.Now : createdDate)
      }
    };

    private void CreateIssueDocumentSets(
      long transactionId,
      Hashtable properties,
      string libLocation,
      EntityDocSetType docSetType,
      List<DocSetPermission> docSetPermissions)
    {
      DocSetInfo docSet = this.UploadDocPresenter.CreateDocSet(new DocSetInfo()
      {
        AppTransactionId = transactionId,
        DocSetName = docSetType.DocSetName,
        EntityType = -4.ToString(),
        URL = libLocation
      }, docSetPermissions, properties);
      this.SaveAppTransactionDetails(new AppTransactionDocSet()
      {
        EntityID = transactionId,
        EntityDocSetTypeID = new long?(docSetType.EntityDocSetTypeID),
        DocSetTypeValue = docSetType.DocSetName,
        URL = libLocation,
        DocSetID = Convert.ToInt32(docSet.DocSetId)
      });
    }

    private void SaveAppTransactionDetails(AppTransactionDocSet appTransactionDocSet)
    {
      try
      {
        this.appTransactionDocSetRepository.Save(appTransactionDocSet);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
      }
    }

    private string GetFilename(string inSTr)
    {
      string empty = string.Empty;
      string[] strArray = inSTr.Split('/');
      if (strArray.Length != 0)
        empty = strArray[strArray.Length - 1];
      return empty;
    }

    public SaveResult SaveIssueAuditTrailList(long appTransactionID)
    {
      try
      {
        bool uploadResult = false;
        string empty = string.Empty;
        ExportResult trailReportStream = this.GetAuditTrailReportStream("~/_layouts/iMPACT/Reports/AuditTrailReport.rdlc", "AuditTrailReport", appTransactionID);
        this.SaveIssueAuditTrailInRepository(appTransactionID, trailReportStream, out uploadResult);
        if (!uploadResult)
          return SaveResult.Failure("There was an error in generating Audit Trail list.");
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.AuditTrailRepository.Save(new AuditTrail()
          {
            AppTransactionID = new long?(appTransactionID),
            Entity = "Issue",
            What = "Issue Audit Trail List published"
          });
          transactionScope.Complete();
          return SaveResult.Success;
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private ExportResult GetAuditTrailReportStream(
      string reportPath,
      string fileName,
      long appTransactionID)
    {
      DataSet dataSet = this.AuditTrailRepository.FetchAuditTrailReportData(appTransactionID);
      dataSet.Tables[0].TableName = "Issuer";
      dataSet.Tables[1].TableName = "AuditTrail";
      dataSet.Tables[2].TableName = "AuditTrailOpp";
      return new ReportExporter().Export(reportPath, "excel", fileName.Replace(" ", ""), (object) dataSet);
    }

    private void SaveIssueAuditTrailInRepository(
      long appTransactionID,
      ExportResult AuditTrailReport,
      out bool uploadResult)
    {
      uploadResult = false;
      List<AppTransactionDocSet> list = this.appTransactionDocSetRepository.FetchByKey(-32L, appTransactionID).ToList<AppTransactionDocSet>();
      if (list == null || list.Count <= 0)
        return;
      DocumentInfo documentInfo = new DocumentInfo();
      AppTransactionDocSet transactionDocSet = list.Find((Predicate<AppTransactionDocSet>) (x =>
      {
        long? entityDocSetTypeId = x.EntityDocSetTypeID;
        long num = 17;
        return entityDocSetTypeId.GetValueOrDefault() == num && entityDocSetTypeId.HasValue;
      }));
      documentInfo.Category = Convert.ToString(3);
      documentInfo.Type = Convert.ToString(-6);
      if (transactionDocSet == null)
        return;
      this.UploadDocPresenter.Upload(new Document()
      {
        DocumentName = "AuditTrailReport.xls",
        DocSetURL = transactionDocSet.URL,
        DocSetId = transactionDocSet.DocSetID.ToString(),
        EntityID = appTransactionID,
        EntityTypeDocTypeID = Convert.ToString(-6),
        Tags = string.Empty,
        EntityTypeDocTypeCategoryID = Convert.ToString(-1),
        EntityType = -32.ToString()
      }, AuditTrailReport.Data);
      uploadResult = true;
    }
  }
}
