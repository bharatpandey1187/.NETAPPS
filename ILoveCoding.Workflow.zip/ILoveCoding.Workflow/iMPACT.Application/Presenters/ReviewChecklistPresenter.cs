﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.ReviewChecklistPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.Core.Mail;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (ReviewChecklistPresenter))]
  public class ReviewChecklistPresenter : PresenterBase
  {
    private const string ReviewChecklist = "Review Checklist";
    private const string ReviewChecklistCreated = "{0} Created";
    private const string ReviewChecklistUpdated = "{0} Updated";
    private const string ReviewChecklistStatusChanged = "Status Changed From {1} to {2}";

    [Dependency]
    public IIssueRepository IssueRepository { get; set; }

    [Dependency]
    public ICheckListRepository CheckListRepository { get; set; }

    [Dependency]
    public IEventBus EventBus { get; set; }

    [Dependency]
    public IAuditTrailRepository AuditTrailRepository { get; set; }

    [Dependency]
    public IssuePresenter Presenter { get; set; }

    [Dependency]
    public IEmailTemplateRepository EmailTemplateRepository { get; set; }

    [Dependency]
    public IMailSender Smtpsender { get; set; }

    public ReviewChecklistViewModel FetchByAppTransactionID(
      long appTransactionID,
      long entityId)
    {
      try
      {
        if (entityId == -32L && !this.HasUIPermissionForEntity(-32L, appTransactionID, "Issue Closure Checklist", "View") || entityId == -33L && !this.HasUIPermissionForEntity(-33L, appTransactionID, "Opportunity Closure Checklist", "View") || entityId == 1L && !this.HasUIPermissionForEntity(1L, appTransactionID, "RFP Closure Checklist", "View"))
          return new ReviewChecklistViewModel("You are not authorized to access this resource.");
        ReviewChecklistViewModel reviewChecklistViewModel = new ReviewChecklistViewModel();
        using (IDataReader reader = this.CheckListRepository.FetchReviewCheckListByAppTransactionID(appTransactionID, entityId))
        {
          IRowMapper<ReviewChecklistViewModel> rowMapper = MapBuilder<ReviewChecklistViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<ReviewChecklistViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<bool>((Expression<Func<ReviewChecklistViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<ReviewChecklistViewModel, bool>>) (x => x.IsViewOnly)).DoNotMap<bool>((Expression<Func<ReviewChecklistViewModel, bool>>) (x => x.IsBankerDisabled)).DoNotMap<bool>((Expression<Func<ReviewChecklistViewModel, bool>>) (x => x.IsUnderWriterDisabled)).DoNotMap<bool>((Expression<Func<ReviewChecklistViewModel, bool>>) (x => x.CanSaveReviewChecklist)).DoNotMap<string>((Expression<Func<ReviewChecklistViewModel, string>>) (x => x.ErrorMessage)).DoNotMap<long>((Expression<Func<ReviewChecklistViewModel, long>>) (x => x.EntityID)).Build();
          if (reader.Read())
          {
            reviewChecklistViewModel = rowMapper.MapRow((IDataRecord) reader);
            reviewChecklistViewModel.ReviewChecklistCategoryViewModel = new List<ReviewChecklistCategoryViewModel>();
            List<ReviewChecklistDetailViewModel> source1 = new List<ReviewChecklistDetailViewModel>();
            if (reader.NextResult())
              source1.AddRange((IEnumerable<ReviewChecklistDetailViewModel>) this.GetReviewChecklistDetails(reader));
            List<ReviewChecklistCategoryViewModel> categoryViewModelList = new List<ReviewChecklistCategoryViewModel>();
            IEnumerable<ReviewChecklistDetailViewModel> source2 = source1.GroupBy<ReviewChecklistDetailViewModel, long>((Func<ReviewChecklistDetailViewModel, long>) (x => x.ChecklistCategoryID)).Select<IGrouping<long, ReviewChecklistDetailViewModel>, ReviewChecklistDetailViewModel>((Func<IGrouping<long, ReviewChecklistDetailViewModel>, ReviewChecklistDetailViewModel>) (y => y.First<ReviewChecklistDetailViewModel>()));
            if (source2.Any<ReviewChecklistDetailViewModel>())
            {
              foreach (ReviewChecklistDetailViewModel checklistDetailViewModel in source2)
                categoryViewModelList.Add(new ReviewChecklistCategoryViewModel()
                {
                  ChecklistCategoryID = new long?(checklistDetailViewModel.ChecklistCategoryID),
                  Category = checklistDetailViewModel.Category
                });
            }
            reviewChecklistViewModel.ReviewChecklistCategoryViewModel = categoryViewModelList;
            foreach (ReviewChecklistCategoryViewModel categoryViewModel in reviewChecklistViewModel.ReviewChecklistCategoryViewModel)
            {
              ReviewChecklistCategoryViewModel item = categoryViewModel;
              item.ReviewChecklistDetailsViewModel = source1.Where<ReviewChecklistDetailViewModel>((Func<ReviewChecklistDetailViewModel, bool>) (x =>
              {
                long checklistCategoryId1 = x.ChecklistCategoryID;
                long? checklistCategoryId2 = item.ChecklistCategoryID;
                long valueOrDefault = checklistCategoryId2.GetValueOrDefault();
                return checklistCategoryId1 == valueOrDefault && checklistCategoryId2.HasValue;
              })).ToList<ReviewChecklistDetailViewModel>();
            }
          }
          this.SetPermissions(reviewChecklistViewModel, entityId);
          return reviewChecklistViewModel;
        }
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.ReviewChecklist, ex.ToString());
        return new ReviewChecklistViewModel("An error occurred while fetching the data.");
      }
    }

    public SaveResult Save(
      ReviewChecklistViewModel theReviewChecklistViewModel)
    {
      try
      {
        if (theReviewChecklistViewModel.EntityID == -33L)
        {
          if (!this.HasUIPermissionForEntity(-33L, theReviewChecklistViewModel.AppTransactionID, "Opportunity Closure Checklist", "Edit"))
            return SaveResult.Failure("You are not authorized to access this resource.");
        }
        else if (theReviewChecklistViewModel.EntityID == 1L)
        {
          if (!this.HasUIPermissionForEntity(1L, theReviewChecklistViewModel.AppTransactionID, "RFP Closure Checklist", "Edit"))
            return SaveResult.Failure("You are not authorized to access this resource.");
        }
        else if (theReviewChecklistViewModel.EntityID == -32L && !this.HasUIPermissionForEntity(-32L, theReviewChecklistViewModel.AppTransactionID, "Issue Closure Checklist", "Edit"))
          return SaveResult.Failure("You are not authorized to access this resource.");
        this.GetSafeObject<ReviewChecklistViewModel>(theReviewChecklistViewModel);
        AuditTrail theAuditTrail = new AuditTrail();
        string empty = string.Empty;
        theAuditTrail.Entity = "Review Checklist";
        if (theReviewChecklistViewModel.ReviewChecklistID > 0L)
          this.FetchByAppTransactionID(theReviewChecklistViewModel.AppTransactionID, theReviewChecklistViewModel.EntityID);
        SaveResult saveResult = theReviewChecklistViewModel.Validate<ReviewChecklistViewModel>();
        if (theReviewChecklistViewModel.ReviewChecklistCategoryViewModel.Count == 0)
          saveResult.Errors.Add("Issue closure checklist category", (object) "Issue closure checklist category does not exist.");
        if (saveResult.IsSuccessful)
        {
          IrisSoftware.iMPACT.Data.ReviewChecklist reviewChecklist = this.GetReviewChecklist(theReviewChecklistViewModel);
          if (theReviewChecklistViewModel.ReviewChecklistID > 0L)
          {
            theAuditTrail.What = string.Format("{0} Updated", (object) "Review Checklist");
          }
          else
          {
            theAuditTrail.What = string.Format("{0} Created", (object) "Review Checklist");
            this.EventBus.Publish<ReviewChecklistCreatedEvent>((Envelope<ReviewChecklistCreatedEvent>) new ReviewChecklistCreatedEvent(reviewChecklist));
          }
          if (saveResult.IsSuccessful)
          {
            using (TransactionScope transactionScope = new TransactionScope())
            {
              theAuditTrail.AppTransactionID = new long?(reviewChecklist.AppTransactionID);
              this.AuditTrailRepository.Save(theAuditTrail);
              this.CheckListRepository.Save(reviewChecklist);
              saveResult.Id = reviewChecklist.ReviewCheckListID;
              transactionScope.Complete();
            }
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.ReviewChecklist, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private List<ReviewChecklistCategoryViewModel> GetReviewChecklistCategory(
      IDataReader reader)
    {
      List<ReviewChecklistCategoryViewModel> categoryViewModelList = new List<ReviewChecklistCategoryViewModel>();
      IRowMapper<ReviewChecklistCategoryViewModel> rowMapper = MapBuilder<ReviewChecklistCategoryViewModel>.MapAllProperties().Build();
      while (reader.Read())
        categoryViewModelList.Add(rowMapper.MapRow((IDataRecord) reader));
      return categoryViewModelList;
    }

    private List<ReviewChecklistDetailViewModel> GetReviewChecklistDetails(
      IDataReader reader)
    {
      List<ReviewChecklistDetailViewModel> checklistDetailViewModelList = new List<ReviewChecklistDetailViewModel>();
      IRowMapper<ReviewChecklistDetailViewModel> rowMapper = MapBuilder<ReviewChecklistDetailViewModel>.MapAllProperties().Build();
      while (reader.Read())
        checklistDetailViewModelList.Add(rowMapper.MapRow((IDataRecord) reader));
      return checklistDetailViewModelList;
    }

    private IrisSoftware.iMPACT.Data.ReviewChecklist GetReviewChecklist(
      ReviewChecklistViewModel reviewChecklistViewModel)
    {
      IrisSoftware.iMPACT.Data.ReviewChecklist reviewChecklist = new IrisSoftware.iMPACT.Data.ReviewChecklist(this.IssueRepository);
      reviewChecklist.ReviewCheckListID = reviewChecklistViewModel.ReviewChecklistID;
      reviewChecklist.AppTransactionID = reviewChecklistViewModel.AppTransactionID;
      foreach (List<ReviewChecklistDetail> reviewChecklistDetailList in reviewChecklistViewModel.ReviewChecklistCategoryViewModel.Select<ReviewChecklistCategoryViewModel, List<ReviewChecklistDetail>>((Func<ReviewChecklistCategoryViewModel, List<ReviewChecklistDetail>>) (x => x.GetReviewChecklistCategory(x))))
        reviewChecklist.ReviewChecklistDetail.AddRange((IEnumerable<ReviewChecklistDetail>) reviewChecklistDetailList);
      reviewChecklist.ReviewCheckListID = reviewChecklistViewModel.ReviewChecklistID;
      return reviewChecklist;
    }

    private void SetPermissions(ReviewChecklistViewModel reviewChecklistViewModel, long entityID)
    {
      reviewChecklistViewModel.IsBankerDisabled = false;
      reviewChecklistViewModel.IsUnderWriterDisabled = false;
      string uiName = string.Empty;
      switch (entityID)
      {
        case -33:
          uiName = "Opportunity Closure Checklist";
          break;
        case -32:
          uiName = "Issue Closure Checklist";
          break;
        case 1:
          uiName = "RFP Closure Checklist";
          break;
      }
      reviewChecklistViewModel.IsViewOnly = !this.HasUIPermissionForEntity(-32L, reviewChecklistViewModel.AppTransactionID, uiName, "Edit");
      if (reviewChecklistViewModel.IsViewOnly)
        return;
      reviewChecklistViewModel.IsViewOnly = reviewChecklistViewModel.IsViewOnly || reviewChecklistViewModel.CanSaveReviewChecklist || reviewChecklistViewModel.IsParentViewOnly;
    }
  }
}
