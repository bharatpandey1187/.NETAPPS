﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.EmailTemplatePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (EmailTemplatePresenter))]
  public class EmailTemplatePresenter : PresenterBase
  {
    [Dependency]
    public IEmailTemplateRepository EmailTemplateRepository { get; set; }

    public EmailTemplateViewModelContainer GetAllEmailTemplate()
    {
      try
      {
        EmailTemplateViewModelContainer viewModelContainer = new EmailTemplateViewModelContainer();
        List<EmailTemplateViewModel> templateViewModelList = new List<EmailTemplateViewModel>();
        using (IDataReader dataReader = this.EmailTemplateRepository.FetchAll())
        {
          IRowMapper<EmailTemplateViewModel> rowMapper = MapBuilder<EmailTemplateViewModel>.MapAllProperties().DoNotMap<string>((Expression<Func<EmailTemplateViewModel, string>>) (email => email.UIName)).Build();
          while (dataReader.Read())
            templateViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        viewModelContainer.EmailTemplates = templateViewModelList;
        return viewModelContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new EmailTemplateViewModelContainer("An error occurred while fetching the data.");
      }
    }

    public EmailTemplateDetailViewModel GetEmailTemplateById(
      int currentId)
    {
      try
      {
        return new EmailTemplateDetailViewModel(this.EmailTemplateRepository.FetchByKey(currentId))
        {
          IsViewOnly = !this.HasIndependentPermission("Email Template", "Edit")
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new EmailTemplateDetailViewModel("An error occurred while fetching the data.");
      }
    }

    public SaveResult Save(EmailTemplateDetailViewModel theEmailTemplate)
    {
      try
      {
        SaveResult saveResult = theEmailTemplate.Validate<EmailTemplateDetailViewModel>();
        if (saveResult.IsSuccessful && this.ValidateModel(theEmailTemplate, ref saveResult))
        {
          using (TransactionScope transactionScope = new TransactionScope())
          {
            IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = theEmailTemplate.GetEmailTemplate(theEmailTemplate);
            emailTemplate.To = this.RemoveEmailWhiteSpace(emailTemplate.To);
            emailTemplate.Cc = this.RemoveEmailWhiteSpace(emailTemplate.Cc);
            this.EmailTemplateRepository.Save(emailTemplate);
            transactionScope.Complete();
          }
        }
        return saveResult;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    private string RemoveEmailWhiteSpace(string email)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (string str in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
        stringBuilder.Append(str.Trim() + ";");
      return stringBuilder.ToString();
    }

    private bool ValidateModel(
      EmailTemplateDetailViewModel theEmailTemplate,
      ref SaveResult saveResult)
    {
      if (!this.ValidateEmail(theEmailTemplate.To))
        saveResult.Errors.Add("Email To", (object) "Invalid To email id.");
      if (!this.ValidateEmail(theEmailTemplate.Cc))
        saveResult.Errors.Add("Email CC", (object) "Invalid Cc email id.");
      return saveResult.IsSuccessful;
    }

    private bool ValidateEmail(string emailIds)
    {
      bool flag = true;
      foreach (string str in emailIds.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        if (flag)
        {
          if (!this.IsInternalPartner(str.Trim()))
            flag = Regex.IsMatch(str.Trim(), "^$|^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9A-Za-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9A-Za-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9A-Za-z][-\\w]*[0-9A-Za-z]*\\.)+[a-zA-Z]{2,4}))$", RegexOptions.IgnoreCase);
        }
        else
          break;
      }
      return flag;
    }

    private bool IsInternalPartner(string str) => str == "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]" || str == "[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]" || (str == "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]" || str == "[INTERNAL-PARTNERS.LEAD-ANALYST]") || (str == "[INTERNAL-PARTNERS.ANALYST]" || str == "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]" || (str == "[INTERNAL-PARTNERS.SYNDICATE]" || str == "[INTERNAL-PARTNERS.BANKRM]")) || (str == "[COMPLIANCE]" || str == "[LEGAL]" || (str == "[COMMITMENTCOMMITTEE]" || str == "[MANAGEMENT]") || (str == "[JOB-ADMINISTRATOR]" || str == "[FIRMCREDIT]" || (str == "[OPERATIONS]" || str == "[PNL-APPROVER]"))) || (str == "[PNL-ADMINISTRATOR]" || str == "[FINANCE-CONTROLLER]");
  }
}
