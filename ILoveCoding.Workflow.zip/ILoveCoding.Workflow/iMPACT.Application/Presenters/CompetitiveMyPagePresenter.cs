﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.CompetitiveMyPagePresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (CompetitiveMyPagePresenter))]
  public class CompetitiveMyPagePresenter : PresenterBase
  {
    [Dependency]
    public ICompetitiveIssueRepository IssueRepository { get; set; }

    public CompetitiveMyPageCalendarContainer GetCalendar()
    {
      try
      {
        CompetitiveMyPageCalendarContainer calendarContainer = new CompetitiveMyPageCalendarContainer();
        List<CompetitiveMyPageSeriesViewModel> source = new List<CompetitiveMyPageSeriesViewModel>();
        using (IDataReader dataReader = this.IssueRepository.FetchCalendar())
        {
          if (dataReader != null)
          {
            IRowMapper<CompetitiveMyPageIssueCalendarViewModel> rowMapper1 = MapBuilder<CompetitiveMyPageIssueCalendarViewModel>.MapAllProperties().Build();
            while (dataReader.Read())
              calendarContainer.Issues.Add(rowMapper1.MapRow((IDataRecord) dataReader));
            if (dataReader.NextResult())
            {
              IRowMapper<CompetitiveMyPageSeriesViewModel> rowMapper2 = MapBuilder<CompetitiveMyPageSeriesViewModel>.MapAllProperties().Build();
              while (dataReader.Read())
                source.Add(rowMapper2.MapRow((IDataRecord) dataReader));
            }
          }
        }
        if (calendarContainer.Issues.Count > 0)
        {
          foreach (CompetitiveMyPageIssueCalendarViewModel issue1 in calendarContainer.Issues)
          {
            CompetitiveMyPageIssueCalendarViewModel issue = issue1;
            issue.Series = source.Where<CompetitiveMyPageSeriesViewModel>((Func<CompetitiveMyPageSeriesViewModel, bool>) (x => x.AppTransactionID == issue.AppTransactionID)).ToList<CompetitiveMyPageSeriesViewModel>();
          }
        }
        return calendarContainer;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Issue, ex.ToString());
        CompetitiveMyPageCalendarContainer calendarContainer = new CompetitiveMyPageCalendarContainer();
        calendarContainer.ErrorMessage = "An error occurred while fetching the data.";
        return calendarContainer;
      }
    }
  }
}
