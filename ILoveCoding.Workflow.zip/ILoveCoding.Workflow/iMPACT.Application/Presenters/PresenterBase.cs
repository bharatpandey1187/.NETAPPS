﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.PresenterBase
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.Logging;
using IrisSoftware.iMPACT.Core.Security;
using Microsoft.Practices.Unity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public class PresenterBase
  {
    [Dependency]
    public IAuthorizationService AuthorizationService { get; set; }

    [Dependency]
    public IUser AppUser { get; set; }

    [Dependency]
    public Logger<Modules> Log { get; set; }

    private string GetPropValue(object src, string propName) => Convert.ToString(src.GetType().GetProperty(propName).GetValue(src, (object[]) null));

    private void ExtractText(object src, string propName)
    {
      string text = Sanitizer.ExtractText(this.GetPropValue(src, propName));
      src.GetType().GetProperty(propName).SetValue(src, (object) text, (object[]) null);
    }

    private void GetSafeHtmlFragment(object src, string propName)
    {
      string safeHtmlFragment = Sanitizer.GetSafeHtmlFragment(this.GetPropValue(src, propName));
      src.GetType().GetProperty(propName).SetValue(src, (object) safeHtmlFragment, (object[]) null);
    }

    public void GetSafeObject<T>(T theObject)
    {
      string[] array1 = ((IEnumerable<PropertyInfo>) theObject.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public)).Where<PropertyInfo>((Func<PropertyInfo, bool>) (pi => pi.PropertyType == typeof (string))).Select<PropertyInfo, string>((Func<PropertyInfo, string>) (pi => pi.Name)).ToArray<string>();
      PropertyInfo[] array2 = ((IEnumerable<PropertyInfo>) theObject.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public)).Where<PropertyInfo>((Func<PropertyInfo, bool>) (pi => pi.PropertyType.Name == "List`1")).ToArray<PropertyInfo>();
      foreach (string str in array1)
      {
        if (((IEnumerable<object>) theObject.GetType().GetProperty(str).GetCustomAttributes(true)).Where<object>((Func<object, bool>) (att => att.ToString() == typeof (AllowHtmlAttribute).ToString())).ToArray<object>().Length != 0)
          this.GetSafeHtmlFragment((object) theObject, str);
      }
      foreach (PropertyInfo propertyInfo in array2)
      {
        if (propertyInfo.GetValue((object) theObject, (object[]) null) is IList list)
        {
          foreach (object theObject1 in (IEnumerable) list)
            this.GetSafeObject<object>(theObject1);
        }
      }
    }

    public void GetSafeObject<T>(List<T> theObject)
    {
      foreach (T theObject1 in theObject)
        this.GetSafeObject<T>(theObject1);
    }

    public string[] GetMatchingPermission(Permission[] permission, string[] actions) => ((IEnumerable<Permission>) permission).Where<Permission>((Func<Permission, bool>) (p => ((IEnumerable<string>) actions).Any<string>((Func<string, bool>) (x => x.Equals(p.Descr.Trim(), StringComparison.CurrentCultureIgnoreCase))))).Select<Permission, string>((Func<Permission, string>) (y => y.Descr)).ToArray<string>();

    public void FlushEntitySecurityPermissionAppTransIDStatusID() => this.AuthorizationService.FlushEntitySecurityPermissionAppTransIDStatusID();

    public bool HasAnyPermissionOnSet(string[] uiNameArry) => this.AuthorizationService.HasAnyPermissionOnSet(this.AppUser, uiNameArry);

    public bool HasAnyPermissionOnSet(List<Tuple<string, string>> uiNamePermissionList) => this.AuthorizationService.HasAnyPermissionOnSet(this.AppUser, uiNamePermissionList);

    public bool HasEntityPermission(long entityTypeID, string uiName, string permission) => this.AuthorizationService.HasSecurityPermission(this.AppUser, entityTypeID, uiName, permission);

    public bool HasUIPermissionForEntity(
      long entityTypeId,
      long entityId,
      string uiName,
      string permission)
    {
      return this.AuthorizationService.HasAccessPermission(this.AppUser, entityTypeId, entityId, uiName, permission);
    }

    public bool HasUIPermissionForEntityStatus(
      long appTransID,
      string uiName,
      string permission,
      List<long> statusList)
    {
      return this.AuthorizationService.HasUIPermissionForEntityStatus(this.AppUser, appTransID, uiName, permission, statusList);
    }

    public bool HasUIPermissionForEntityStatus(long appTransID, string uiName, string permission) => this.AuthorizationService.HasUIPermissionForEntityStatus(this.AppUser, appTransID, uiName, permission);

    public bool HasUIPermissionForEntityStatusMultiple(
      long appTransID,
      string[] uiNameArry,
      string permission)
    {
      return this.AuthorizationService.HasUIPermissionForEntityStatusMultiple(this.AppUser, appTransID, uiNameArry, permission);
    }

    public bool HasIndependentPermission(string uiName, string permission) => this.AuthorizationService.HasIndependentPermission(this.AppUser, uiName, permission);

    public void FlushUserEntitySecurityPermissions() => this.AuthorizationService.FlushUserEntitySecurityPermissions();
  }
}
