﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.RolePermissionPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Core.Unity;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Caching;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  [Export(typeof (RolePermissionPresenter))]
  public class RolePermissionPresenter : PresenterBase
  {
    [Dependency]
    public IRoleRepository RoleRepository { get; set; }

    [Dependency]
    public IMembershipService MembershipService { get; set; }

    [Dependency]
    public IAppGroupRepository AppgroupRepository { get; set; }

    public RolePermissionContainerViewModel Initialize()
    {
      try
      {
        RolePermissionContainerViewModel containerViewModel = new RolePermissionContainerViewModel();
        IEnumerable<Role> source1 = this.RoleRepository.FetchAll();
        IEnumerable<IrisSoftware.iMPACT.Data.Permission> source2 = this.RoleRepository.FetchAllPermissions(true);
        containerViewModel.Entities = source1.Select<Role, string>((Func<Role, string>) (x => x.Entity)).Distinct<string>().ToList<string>();
        containerViewModel.Entities.Sort();
        containerViewModel.AddEntities = source1.Select<Role, string>((Func<Role, string>) (x => x.Entity)).Distinct<string>().ToList<string>();
        containerViewModel.AddEntities.Remove("App");
        containerViewModel.Roles = source1.Select<Role, RoleViewModel>((Func<Role, RoleViewModel>) (x => new RoleViewModel(x))).ToList<RoleViewModel>();
        containerViewModel.Permissions = source2.Select<IrisSoftware.iMPACT.Data.Permission, PermissionViewModel>((Func<IrisSoftware.iMPACT.Data.Permission, PermissionViewModel>) (x => new PermissionViewModel(x))).ToList<PermissionViewModel>();
        containerViewModel.IsViewOnly = !this.HasIndependentPermission("Role Permission", "Edit");
        return containerViewModel;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        RolePermissionContainerViewModel containerViewModel = new RolePermissionContainerViewModel();
        containerViewModel.ErrorMessage = "An error occurred while fetching the data.";
        return containerViewModel;
      }
    }

    public SaveResult SaveRolePermissions(
      List<RolePermissionViewModel> rolePermissionsModel,
      long roleId)
    {
      try
      {
        this.GetSafeObject<RolePermissionViewModel>(rolePermissionsModel);
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.RoleRepository.SaveRolePermissions(rolePermissionsModel.Select<RolePermissionViewModel, RolePermission>((Func<RolePermissionViewModel, RolePermission>) (x => x.GetRolePermission())).ToList<RolePermission>(), roleId);
          transactionScope.Complete();
        }
        Cache cache = HttpContext.Current.Cache;
        if (cache.Get(Constants.MenuCacheKey) != null)
        {
          Dictionary<long, List<Menu>> dictionary = cache.Get(Constants.MenuCacheKey) as Dictionary<long, List<Menu>>;
          if (dictionary.TryGetValue(roleId, out List<Menu> _))
          {
            dictionary.Remove(roleId);
            cache.Insert(Constants.MenuCacheKey, (object) dictionary);
          }
        }
        return SaveResult.Success;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }

    public SaveResult SaveRole(long roleId, string roleName, string entity)
    {
      try
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          string message = this.RoleRepository.Save(new Role()
          {
            RoleID = roleId,
            RoleName = roleName,
            Entity = entity
          });
          if (roleId == 0L && string.IsNullOrEmpty(message))
          {
            IGroup groupIfNotExists = this.MembershipService.CreateGroupIfNotExists(roleName, this.AppUser.Name);
            if (groupIfNotExists != null)
              this.Log.Info(Modules.Administration, string.Format("Group with name {0} created successfully in SharePoint.", (object) groupIfNotExists.Name));
            if (string.IsNullOrEmpty(this.AppgroupRepository.Save(new AppGroup()
            {
              GroupID = 0,
              Name = groupIfNotExists.Name,
              PrincipalID = new int?(groupIfNotExists.Id)
            })))
              this.Log.Info(Modules.Administration, string.Format("Group with name {0} created successfully in Db.", (object) groupIfNotExists.Name));
          }
          transactionScope.Complete();
          if (!string.IsNullOrEmpty(message))
            return SaveResult.Failure(message);
        }
        return new SaveResult();
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return SaveResult.Failure("An error occurred while saving the data.");
      }
    }
  }
}
