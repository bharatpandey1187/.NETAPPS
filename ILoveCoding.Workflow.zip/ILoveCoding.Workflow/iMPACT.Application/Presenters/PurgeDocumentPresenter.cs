﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.Presenters.PurgeDocumentPresenter
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.iMPACT.Application.ViewModels;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;

namespace IrisSoftware.iMPACT.Application.Presenters
{
  public class PurgeDocumentPresenter : PresenterBase
  {
    [Dependency]
    public IPurgeDocumentsRepository PurgeDocumentsRepository { get; set; }

    [Dependency]
    public IAppTransactionDocSetDocumentRepository appTransactionDocSetDocumentRepository { get; set; }

    public PurgeDocumentViewModel Initialize()
    {
      try
      {
        if (!this.HasIndependentPermission("Purge Documents", "Delete"))
        {
          PurgeDocumentViewModel documentViewModel = new PurgeDocumentViewModel();
          documentViewModel.ErrorMessage = "401";
          return documentViewModel;
        }
        return new PurgeDocumentViewModel()
        {
          EntityTypes = this.FetchAllEntityTypes().Select<EntityTypes, KeyValuePair<long, string>>((Func<EntityTypes, KeyValuePair<long, string>>) (x => new KeyValuePair<long, string>(x.EntityTypeID, x.TypeName))).ToList<KeyValuePair<long, string>>()
        };
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new PurgeDocumentViewModel();
      }
    }

    public List<EntityTypes> FetchAllEntityTypes()
    {
      try
      {
        List<EntityTypes> entityTypesList = new List<EntityTypes>();
        using (IDataReader dataReader = this.PurgeDocumentsRepository.FetchAllEntityTypes(1))
        {
          IRowMapper<EntityTypes> rowMapper = MapBuilder<EntityTypes>.MapAllProperties().Build();
          while (dataReader.Read())
            entityTypesList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        return entityTypesList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Administration, ex.ToString());
        return new List<EntityTypes>();
      }
    }

    public PurgeDocumentViewModelContainer GetSearchData(
      PurgeDocumentSearchViewModel documentSearchCriteria)
    {
      PurgeDocumentViewModelContainer viewModelContainer = new PurgeDocumentViewModelContainer();
      List<PurgeDocumentViewModel> documentViewModelList = new List<PurgeDocumentViewModel>();
      IDataReader dataReader = (IDataReader) null;
      try
      {
        dataReader = this.PurgeDocumentsRepository.FetchAllPurgeDocuments(documentSearchCriteria.EntityType, documentSearchCriteria.UploadDateFrom, documentSearchCriteria.UploadDateTo);
        if (dataReader != null)
        {
          IRowMapper<PurgeDocumentViewModel> rowMapper = MapBuilder<PurgeDocumentViewModel>.MapAllProperties().DoNotMap<bool>((Expression<Func<PurgeDocumentViewModel, bool>>) (x => x.IsDirty)).DoNotMap<bool>((Expression<Func<PurgeDocumentViewModel, bool>>) (x => x.IsDeleted)).DoNotMap<string>((Expression<Func<PurgeDocumentViewModel, string>>) (x => x.ErrorMessage)).Build();
          while (dataReader.Read())
            documentViewModelList.Add(rowMapper.MapRow((IDataRecord) dataReader));
        }
        viewModelContainer.PurgeDocuments = documentViewModelList;
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.Report, ex.ToString());
      }
      finally
      {
        dataReader?.Dispose();
      }
      return viewModelContainer;
    }

    private string ConvertDateFormat(string value)
    {
      DateTime result;
      return !string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result) ? result.ToString("MM/dd/yyyy") : "";
    }

    public string DeleteDocument(string[] fileUrls, string[] docIds)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      PurgeDocumentPresenter.\u003C\u003Ec__DisplayClass12_0 cDisplayClass120 = new PurgeDocumentPresenter.\u003C\u003Ec__DisplayClass12_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass120.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass120.fileUrls = fileUrls;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass120.docIds = docIds;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass120.isSuccess = "Failure";
      // ISSUE: reference to a compiler-generated field
      cDisplayClass120.userName = ((SPPrincipal) SPContext.get_Current().get_Web().get_CurrentUser()).get_Name();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass120.docIDs = string.Empty;
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass120, __methodptr(\u003CDeleteDocument\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass120.isSuccess;
    }
  }
}
