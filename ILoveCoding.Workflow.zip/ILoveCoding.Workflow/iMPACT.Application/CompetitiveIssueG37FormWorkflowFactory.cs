﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.CompetitiveIssueG37FormWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class CompetitiveIssueG37FormWorkflowFactory : ICompetitiveIssueG37FormWorkflowFactory
  {
    private readonly Workflow<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form> defaultWorkflow;

    public CompetitiveIssueG37FormWorkflowFactory()
    {
      CompetitiveIssueG37FormState issueG37FormState = new CompetitiveIssueG37FormState();
      this.defaultWorkflow = new Workflow<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>((IEnumerable<Transition<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>>) new Transition<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>[2]
      {
        new Transition<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>((IState<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>) issueG37FormState.Open, CompetitiveIssueG37FormAction.SubmitToCompliance, (IState<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>) issueG37FormState.SubmittedToCompliance),
        new Transition<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>((IState<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>) issueG37FormState.SubmittedToCompliance, CompetitiveIssueG37FormAction.ReceivedByCompliance, (IState<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>) issueG37FormState.ReceivedByCompliance)
      });
    }

    public IWorkflow<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form> GetWorkflow(
      string workflowType)
    {
      return (IWorkflow<CompetitiveIssueEnums.IssueG37FormStatus, CompetitiveG37Form>) this.defaultWorkflow;
    }
  }
}
