﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.EventHandlers.EventHandlersBase
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.Logging;
using IrisSoftware.Core.Mail;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Data;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Transactions;

namespace IrisSoftware.iMPACT.Application.EventHandlers
{
  public class EventHandlersBase
  {
    [Dependency]
    public IMailSender Smtpsender { get; set; }

    protected LazyValue<IAuditTrailRepository> AuditTrailRepository { get; set; }

    protected LazyValue<IEmailTemplateRepository> EmailTemplateRepository { get; set; }

    protected LazyValue<IAppConfigRepository> AppConfigRepository { get; set; }

    protected LazyValue<IOpportunityRepository> OpportunityRepository { get; set; }

    protected LazyValue<IRFPRepository> RFPRepository { get; set; }

    protected LazyValue<IrisSoftware.iMPACT.Application.Presenters.UploadDocumentPresenter> UploadDocumentPresenter { get; set; }

    protected LazyValue<IEntityStateRepository> EntityStateRepository { get; set; }

    protected LazyValue<IIssueRepository> IssueRepository { get; set; }

    protected LazyValue<ICompetitiveIssueRepository> CompetitiveIssueRepository { get; set; }

    protected LazyValue<IAppTransactionDocSetRepository> AppTransactionDocSetRepository { get; set; }

    protected LazyValue<IUser> User { get; set; }

    public LazyValue<Logger<Modules>> Log { get; set; }

    protected LazyValue<IPnlRepository> PnLRepository { get; set; }

    protected LazyValue<IAuditTrailReportRepositoryComp> AuditTrailRepositoryComp { get; set; }

    protected LazyValue<ICompetitiveIssueRepository> CompIssueRepository { get; set; }

    public void SendEmail(MailMessage msg)
    {
      try
      {
        this.Smtpsender.Send(msg);
        string empty = string.Empty;
        this.EmailTemplateRepository.Value.SaveToEmailLog(DateTime.Now, SPContext.get_Current().get_Web().get_CurrentUser().get_Email(), Convert.ToString((object) msg.To), Convert.ToString((object) msg.CC), Convert.ToString(msg.Subject), Convert.ToString(msg.Body));
      }
      catch
      {
        throw;
      }
    }

    public void UpdateAuditTrail(AuditTrail auditTrail)
    {
      try
      {
        if (auditTrail == null)
          return;
        this.AuditTrailRepository.Value.Save(auditTrail);
      }
      catch
      {
        throw;
      }
    }

    public MailMessage GetInitializedMailMessage()
    {
      MailMessage mailMessage = new MailMessage();
      if (!string.IsNullOrEmpty(this.User.Value.Email))
        mailMessage.From = new MailAddress(this.User.Value.Email);
      if (!string.IsNullOrEmpty(this.User.Value.Email))
        mailMessage.CC.Add(new MailAddress(this.User.Value.Email));
      mailMessage.IsBodyHtml = true;
      return mailMessage;
    }

    public virtual void SetRecipients(MailAddressCollection adrCollection, string recipients)
    {
      foreach (string str in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        string adr = str;
        if (!string.IsNullOrEmpty(adr.Trim()) && adrCollection.Count<MailAddress>((Func<MailAddress, bool>) (a => a.Address.Trim() == adr.Trim())) == 0)
          adrCollection.Add(adr);
      }
    }

    public virtual void UpdateDocSetQueue(long appTransactionID)
    {
      List<long> appTransactionIDList = new List<long>();
      appTransactionIDList.Add(appTransactionID);
      if (Transaction.Current != (Transaction) null)
      {
        this.AppTransactionDocSetRepository.Value.SaveDocumentSetQueue(appTransactionIDList);
      }
      else
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.AppTransactionDocSetRepository.Value.SaveDocumentSetQueue(appTransactionIDList);
          transactionScope.Complete();
        }
      }
    }

    public virtual void UpdateIntegrationQueue(long appTransID, List<int> statusList)
    {
      if (Transaction.Current != (Transaction) null)
      {
        this.PnLRepository.Value.SaveIntegrationQueue(appTransID, statusList);
      }
      else
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.PnLRepository.Value.SaveIntegrationQueue(appTransID, statusList);
          transactionScope.Complete();
        }
      }
    }
  }
}
