﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.EventHandlers.LazyValue`1
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using System;

namespace IrisSoftware.iMPACT.Application.EventHandlers
{
  public class LazyValue<T>
  {
    private Func<T> _factory;
    private T _value;
    private bool _resolved;

    public T Value
    {
      get
      {
        if (!this._resolved)
        {
          this._resolved = true;
          this._value = this._factory();
        }
        return this._value;
      }
    }

    public LazyValue(Func<T> factory) => this._factory = factory;
  }
}
