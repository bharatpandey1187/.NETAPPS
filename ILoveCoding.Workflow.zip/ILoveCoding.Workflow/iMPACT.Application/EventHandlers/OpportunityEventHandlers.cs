﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.EventHandlers.OpportunityEventHandlers
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.Core.Logging;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.Presenters;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Transactions;
using System.Web;

namespace IrisSoftware.iMPACT.Application.EventHandlers
{
  public class OpportunityEventHandlers : EventHandlersBase, IEventHandler<OpportunityCreatedEvent>, IEventHandler, IEventHandler<OpportunityStatusChangedEvent>, IEventHandler<OpportunityUpdatedEvent>, IEventHandler<OpportunityIssueInitiatedEvent>, IEventHandler<OpportunityNotifyDualProposalRequestedProposedEvent>, IEventHandler<OpportunityFieldUpdateEvent>
  {
    public OpportunityEventHandlers(
      Func<IUser> user,
      Func<IAuditTrailRepository> auditTrailRepository,
      Func<IEmailTemplateRepository> emailTemplateRepositry,
      Func<IOpportunityRepository> opportunityRepository,
      Func<IRFPRepository> rfpRepository,
      Func<IIssueRepository> issueRepository,
      Func<IAppTransactionDocSetRepository> appTransactionDocSetRepository,
      Func<Logger<Modules>> loggerModule,
      Func<UploadDocumentPresenter> uploadDocumentPresenter,
      Func<IEntityStateRepository> entityStateRepository)
    {
      this.User = new LazyValue<IUser>(user);
      this.AuditTrailRepository = new LazyValue<IAuditTrailRepository>(auditTrailRepository);
      this.EmailTemplateRepository = new LazyValue<IEmailTemplateRepository>(emailTemplateRepositry);
      this.OpportunityRepository = new LazyValue<IOpportunityRepository>(opportunityRepository);
      this.RFPRepository = new LazyValue<IRFPRepository>(rfpRepository);
      this.IssueRepository = new LazyValue<IIssueRepository>(issueRepository);
      this.AppTransactionDocSetRepository = new LazyValue<IAppTransactionDocSetRepository>(appTransactionDocSetRepository);
      this.Log = new LazyValue<Logger<Modules>>(loggerModule);
      this.UploadDocumentPresenter = new LazyValue<UploadDocumentPresenter>(uploadDocumentPresenter);
      this.EntityStateRepository = new LazyValue<IEntityStateRepository>(entityStateRepository);
    }

    public void Handle(Envelope<OpportunityCreatedEvent> envelope)
    {
      this.Log.Value.Error(Modules.Opportunity, string.Format("PERFORMANCE : Opportunity Created Event called  at {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) envelope.Body.AppTransactionID));
      if (envelope.Body.CreatedEventType == 1)
      {
        this.UpdateRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
      }
      else
      {
        IrisSoftware.iMPACT.Data.Opportunity opportunity = envelope.Body.Opportunity;
        foreach (MailMessage msg in this.PrepareMailMessage(new long?(), new long?(opportunity.OpportunityDetail.OpportunityStatus[0]), opportunity))
          this.SendEmail(msg);
      }
      this.Log.Value.Error(Modules.Opportunity, string.Format("PERFORMANCE : Opportunity Created Event completed  at {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) envelope.Body.AppTransactionID));
    }

    public void Handle(Envelope<OpportunityStatusChangedEvent> envelope)
    {
      try
      {
        this.Log.Value.Error(Modules.Opportunity, string.Format("PERFORMANCE : Opportunity Status changed event called  at {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) envelope.Body.AppTransactionID));
        if (envelope.Body.StatusChangedType == 1)
        {
          this.UpdateRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
          this.UpdateDocSetQueue(envelope.Body.AppTransactionID);
        }
        else
        {
          IrisSoftware.iMPACT.Data.Opportunity opportunity = envelope.Body.Opportunity;
          List<IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState> stateToStateList = envelope.Body.FromStateToStateList;
          if (this.User != null)
          {
            if (string.IsNullOrEmpty(this.User.Value.Email))
              this.Log.Value.Error(Modules.Opportunity, string.Format("User Object is not null and Email is null. User Id : {0} , Login Name:{1}", (object) this.User.Value.Id, (object) this.User.Value.LoginName));
            else
              this.Log.Value.Error(Modules.Opportunity, string.Format(" User Id : {0} , Email:{1}", (object) this.User.Value.Id, (object) this.User.Value.Email));
          }
          else
            this.Log.Value.Error(Modules.Opportunity, "User Object is Null");
          foreach (IrisSoftware.iMPACT.Data.Opportunity.OpportunityFromStateToState fromStateToState in stateToStateList)
          {
            IrisSoftware.iMPACT.Data.Opportunity.Status? fromState = fromStateToState.FromState;
            long? FromStateID = fromState.HasValue ? new long?((long) fromState.GetValueOrDefault()) : new long?();
            long? ToStateID = new long?((long) fromStateToState.ToState);
            foreach (MailMessage msg in this.PrepareMailMessage(FromStateID, ToStateID, opportunity))
            {
              this.Log.Value.Error(Modules.Opportunity, string.Format("Sending email for Opportunity: {0} FromState: {1}, ToState: {2}", (object) opportunity.OpportunityDetail.AppTransactionID.ToString(), (object) FromStateID, (object) ToStateID));
              this.SendEmail(msg);
              this.Log.Value.Error(Modules.Opportunity, string.Format("Email Sent for Opportunity: {0} FromState: {1}, ToState: {2} ", (object) opportunity.OpportunityDetail.AppTransactionID.ToString(), (object) FromStateID, (object) ToStateID));
            }
          }
        }
        this.Log.Value.Error(Modules.Opportunity, string.Format("PERFORMANCE : Opportunity Sataus Changed Event completed  at {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) envelope.Body.AppTransactionID));
      }
      catch (Exception ex)
      {
        this.Log.Value.Error(Modules.Opportunity, ex.ToString());
      }
    }

    public void Handle(Envelope<OpportunityUpdatedEvent> envelope)
    {
    }

    public void Handle(Envelope<OpportunityFieldUpdateEvent> envelope)
    {
      if (!envelope.Body.UpdateField)
        return;
      this.OpportunityRepository.Value.UpdateField(envelope.Body.AppTransactionID, envelope.Body.FieldValue, envelope.Body.FieldName);
    }

    public void Handle(Envelope<OpportunityIssueInitiatedEvent> envelope)
    {
      this.Log.Value.Error(Modules.Opportunity, string.Format("PERFORMANCE : Opportunity Issue initiated Event called  at {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) envelope.Body.opportunity.OpportunityDetail.AppTransactionID));
      this.SendEmail(this.PrepareMailMessage(10, envelope.Body.opportunity));
      this.Log.Value.Error(Modules.Opportunity, string.Format("PERFORMANCE : Opportunity Issue initiated Event completd  at {0} for AppTrsanctionId {1}  ", (object) DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"), (object) envelope.Body.opportunity.OpportunityDetail.AppTransactionID));
    }

    public void Handle(
      Envelope<OpportunityNotifyDualProposalRequestedProposedEvent> envelope)
    {
      this.SendEmail(this.PrepareMailMessage(22, envelope.Body.opportunity));
    }

    private List<MailMessage> PrepareMailMessage(
      long? FromStateID,
      long? ToStateID,
      IrisSoftware.iMPACT.Data.Opportunity oppty)
    {
      List<MailMessage> mailMessageList = new List<MailMessage>();
      foreach (IrisSoftware.iMPACT.Data.EmailTemplate template in this.EmailTemplateRepository.Value.FetchByEntityIDStateID(new long?(-33L), FromStateID, ToStateID))
      {
        MailMessage initializedMailMessage = this.GetInitializedMailMessage();
        this.OpportunityMailMessage(template, oppty, initializedMailMessage);
        mailMessageList.Add(initializedMailMessage);
      }
      return mailMessageList;
    }

    private void OpportunityMailMessage(IrisSoftware.iMPACT.Data.EmailTemplate template, IrisSoftware.iMPACT.Data.Opportunity oppty, MailMessage msg)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      string empty5 = string.Empty;
      string newValue1 = string.Empty;
      string newValue2 = string.Empty;
      string empty6 = string.Empty;
      if (oppty.InternalPartners != null && oppty.InternalPartners.Count > 0)
      {
        foreach (InternalPartner internalPartner in oppty.InternalPartners)
        {
          if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email) && internalPartner.IsActive)
          {
            switch (internalPartner.RoleTypeId.Value)
            {
              case 23:
                this.FillInvestmentBankingDetails(ref empty1, ref empty2, ref empty3, internalPartner);
                continue;
              case 24:
                this.FillAnalystDetails(ref empty4, ref empty5, internalPartner);
                continue;
              case 25:
                newValue1 = string.Format("{0}{1};", (object) newValue1, (object) internalPartner.Email);
                continue;
              case 26:
                newValue2 = string.Format("{0}{1};", (object) newValue2, (object) internalPartner.Email);
                continue;
              default:
                continue;
            }
          }
        }
      }
      template.To = this.SetAppGroupRecipients(template.To, oppty.OpportunityDetail.AppTransactionID);
      template.Cc = this.SetAppGroupRecipients(template.Cc, oppty.OpportunityDetail.AppTransactionID);
      if (!string.IsNullOrEmpty(template.To))
      {
        template.To = template.To.ToUpper().Replace("[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]", empty1).Replace("[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]", empty2).Replace("[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]", empty3).Replace("[INTERNAL-PARTNERS.LEAD-ANALYST]", empty4).Replace("[INTERNAL-PARTNERS.ANALYST]", empty5).Replace("[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]", newValue1).Replace("[INTERNAL-PARTNERS.BANKRM]", newValue2).Replace("[INTERNAL-PARTNERS.SYNDICATE]", empty6);
        this.SetRecipients(msg.To, template.To);
      }
      if (!string.IsNullOrEmpty(template.Cc))
      {
        template.Cc = template.Cc.ToUpper().Replace("[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]", empty1).Replace("[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]", empty2).Replace("[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]", empty3).Replace("[INTERNAL-PARTNERS.LEAD-ANALYST]", empty4).Replace("[INTERNAL-PARTNERS.ANALYST]", empty5).Replace("[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]", newValue1).Replace("[INTERNAL-PARTNERS.BANKRM]", newValue2).Replace("[INTERNAL-PARTNERS.SYNDICATE]", empty6);
        this.SetRecipients(msg.CC, template.Cc);
      }
      msg.Subject = this.ResolvePlaceholders(template.Subject, oppty);
      msg.Body = this.ResolvePlaceholders(template.Body, oppty);
    }

    private string GetReviewComment(IrisSoftware.iMPACT.Data.Opportunity Opp)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (Opp.ReviewCommentsCollection != null && Opp.ReviewCommentsCollection.Any<ReviewComments>())
      {
        if (Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewComment != null)
          stringBuilder.Append(Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewComment);
        stringBuilder.Append(" (");
        if (Opp.ReviewCommentsCollection.First<ReviewComments>().UserName != null)
          stringBuilder.Append(Opp.ReviewCommentsCollection.First<ReviewComments>().UserName);
        stringBuilder.Append("; ");
        DateTime? reviewCommentDateTime = Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewCommentDateTime;
        if (reviewCommentDateTime.HasValue)
        {
          reviewCommentDateTime = Opp.ReviewCommentsCollection.First<ReviewComments>().ReviewCommentDateTime;
          DateTime localTime = DateTime.SpecifyKind(reviewCommentDateTime.Value, DateTimeKind.Utc).ToLocalTime();
          stringBuilder.Append(localTime.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/'));
        }
        stringBuilder.Append(")");
      }
      return stringBuilder.ToString();
    }

    private string ResolvePlaceholders(string body, IrisSoftware.iMPACT.Data.Opportunity opportunity)
    {
      string str1 = HttpContext.Current.Request.UrlReferrer.AbsoluteUri;
      if (str1.ToUpper().Contains("?CAPPID"))
        str1 = HttpContext.Current.Request.UrlReferrer.AbsoluteUri.Split('?')[0] + "?AppID=" + (object) opportunity.OpportunityDetail.AppTransactionID;
      else if (!str1.ToUpper().Contains("APPID"))
        str1 = str1 + "?AppID=" + (object) opportunity.OpportunityDetail.AppTransactionID;
      string str2 = body.Replace("[OPPORTUNITY-DESCRIPTION]", opportunity.OpportunityDetail.OpportunityName).Replace("[OPPORTUNITY-DESCRIPTION-WITH-LINK]", "<a href='" + str1 + "'>" + opportunity.OpportunityDetail.OpportunityName + "</a>").Replace("[ISSUER-NAME]", opportunity.OpportunityDetail.IssuerName).Replace("[ISSUER-NAME-WITH-LINK]", "<a href='" + str1 + "'>" + opportunity.OpportunityDetail.IssuerName + "</a>");
      Decimal? nullable1;
      string newValue1;
      if (!opportunity.OpportunityDetail.ParAmount.HasValue)
      {
        newValue1 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.ParAmount;
        newValue1 = string.Format("{0:C0}", (object) nullable1.Value);
      }
      string str3 = str2.Replace("[PAR-AMT]", newValue1).Replace("[ADDITIONAL-RFP-DETAILS]", opportunity.OpportunityDetail.AdditionalRFPDetails);
      DateTime? nullable2 = opportunity.OpportunityDetail.ResponseDueDateTime;
      string newValue2;
      if (!nullable2.HasValue)
      {
        newValue2 = "";
      }
      else
      {
        nullable2 = opportunity.OpportunityDetail.ResponseDueDateTime;
        newValue2 = nullable2.Value.ToString("MM'/'dd'/'yyyy hh:mm tt");
      }
      body = str3.Replace("[RESPONSE-DUE-DATE]", newValue2).Replace("[RESPONSE-DUE-DATE-TIME-ZONE]", Convert.ToString(opportunity.OpportunityDetail.ResponseDueDateTimezone));
      string str4 = body;
      nullable1 = opportunity.OpportunityDetail.RFPFees;
      string newValue3;
      if (!nullable1.HasValue)
      {
        newValue3 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.RFPFees;
        newValue3 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str5 = str4.Replace("[PROPOSED-AVERAGE-TAKEDOWN]", newValue3);
      nullable1 = opportunity.OpportunityDetail.ProposedManagementFee;
      string newValue4;
      if (!nullable1.HasValue)
      {
        newValue4 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.ProposedManagementFee;
        newValue4 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str6 = str5.Replace("[PROPOSED-MANAGEMENT-FEE]", newValue4);
      nullable1 = opportunity.OpportunityDetail.ProposedUnderwriterExpenses;
      string newValue5;
      if (!nullable1.HasValue)
      {
        newValue5 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.ProposedUnderwriterExpenses;
        newValue5 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str7 = str6.Replace("[PROPOSED-UNDERWRITER-EXPENSES]", newValue5);
      nullable1 = opportunity.OpportunityDetail.GrossSpread;
      string newValue6;
      if (!nullable1.HasValue)
      {
        newValue6 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.GrossSpread;
        newValue6 = string.Format("{0:C3}", (object) nullable1.Value);
      }
      string str8 = str7.Replace("[PROPOSE-GROSS-SPREAD]", newValue6);
      nullable1 = opportunity.OpportunityDetail.FirmLiabilityPerc;
      string newValue7;
      if (!nullable1.HasValue)
      {
        newValue7 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.FirmLiabilityPerc;
        newValue7 = string.Format("{0:n3}", (object) nullable1.Value);
      }
      string str9 = str8.Replace("[EXPECTED-FIRM-LIABILITY]", newValue7);
      nullable1 = opportunity.OpportunityDetail.FirmMgmtFee;
      string newValue8;
      if (!nullable1.HasValue)
      {
        newValue8 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.FirmMgmtFee;
        newValue8 = string.Format("{0:n3}", (object) nullable1.Value);
      }
      string str10 = str9.Replace("[EXPECTED-FIRM-MGMT-FEE]", newValue8);
      nullable1 = opportunity.OpportunityDetail.TakeDownValue;
      string newValue9;
      if (!nullable1.HasValue)
      {
        newValue9 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.TakeDownValue;
        newValue9 = string.Format("{0:C2}", (object) nullable1.Value);
      }
      string str11 = str10.Replace("[ESTIMATED-AVERAGE-TAKEDOWN]", newValue9);
      nullable1 = opportunity.OpportunityDetail.EstGrossRev;
      string newValue10;
      if (!nullable1.HasValue)
      {
        newValue10 = "";
      }
      else
      {
        nullable1 = opportunity.OpportunityDetail.EstGrossRev;
        newValue10 = string.Format("{0:C2}", (object) nullable1.Value);
      }
      string str12 = str11.Replace("[ESTIMATED-REVENUE]", newValue10).Replace("[ADDITIONAL-INFORMATION-FOR-COMMITMENT-COMMITTEE]", opportunity.OpportunityDetail.AdditionalInformationForCommitmentCommittee).Replace("[BORROWER/OBLIGOR]", opportunity.OpportunityDetail.BorrowerName).Replace("[DEAL-TYPE]", opportunity.OpportunityDetail.DealTypeName).Replace("[TYPE-OF-OPPORTUNITY]", opportunity.OpportunityDetail.OpportunityTypeName).Replace("[G-17-CONTACT-PREFIX]", opportunity.OpportunityDetail.G17ContactPrefix).Replace("[G-17-CONTACT-FIRST-NAME]", opportunity.OpportunityDetail.G17ContactFirstName).Replace("[G-17-CONTACT-LAST-NAME]", opportunity.OpportunityDetail.G17ContactLastName).Replace("[G17-CONTACT-SUFFIX]", opportunity.OpportunityDetail.G17ContactSuffix).Replace("[G-17-CONTACT-TITLE]", opportunity.OpportunityDetail.G17ContactJobTitle).Replace("[G17-CONTACT-EMAIL]", opportunity.OpportunityDetail.G17ContactEmail).Replace("[LEAD-BANKER]", opportunity.OpportunityDetail.LeadBanker).Replace("[G17-CONTACT-ADDRESS]", opportunity.OpportunityDetail.G17ContactAddress).Replace("[RATINGS]", opportunity.OpportunityDetail.Ratings).Replace("[EXPECTED-FIRM-ROLE]", opportunity.OpportunityDetail.ExpectedFirmRoleValue).Replace("[FIRM-ROLE]", opportunity.OpportunityDetail.FirmRoleValue).Replace("[RFP-TYPE]", opportunity.OpportunityDetail.RFPTypeName);
      nullable2 = opportunity.OpportunityDetail.ExpectedPricingDate;
      string newValue11;
      if (!nullable2.HasValue)
      {
        newValue11 = "";
      }
      else
      {
        nullable2 = opportunity.OpportunityDetail.ExpectedPricingDate;
        newValue11 = nullable2.Value.ToString("MM/dd/yyyy");
      }
      body = str12.Replace("[EXPECTED-PRICING-DATE]", newValue11);
      body = body.Replace("[MS-BANKING-GROUP]", opportunity.OpportunityDetail.MarketTxt);
      body = body.Replace("[WINNING-SYNDICATE-NOTES]", opportunity.OpportunityDetail.Notes);
      body = body.Replace("[REVIEW-COMMENT]", this.GetReviewComment(opportunity));
      if (opportunity.ExternalPartners != null && opportunity.ExternalPartners.Count > 0)
      {
        string source = string.Join("; ", opportunity.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.LookupKey == "Winning Syndicate Member Role" && !m.IsDeleted)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => !string.IsNullOrEmpty(x.Name) ? string.Format("{0} ({1})", (object) x.Name, (object) x.MemberTypeName) : string.Empty)).ToArray<string>());
        body = body.Replace("[WINNING-SYNDICATE-MEMBER-NAME-ROLE]", source.Any<char>() ? source : "");
      }
      else
        body = body.Replace("[WINNING-SYNDICATE-MEMBER-NAME-ROLE]", string.Empty);
      return body;
    }

    private void UpdateRootLeafNode(long appTransID, List<int> statusList)
    {
      if (Transaction.Current != (Transaction) null)
      {
        this.OpportunityRepository.Value.UpdateStatusTracking(appTransID, statusList, -33);
      }
      else
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.OpportunityRepository.Value.UpdateStatusTracking(appTransID, statusList, -33);
          transactionScope.Complete();
        }
      }
    }

    private bool IsMAExemptionUpdated(Envelope<OpportunityUpdatedEvent> envelope)
    {
      List<MAExemptionDetail> exemptionDetails1 = envelope.Body.newOpportunity.OpportunityDetail.MAExemptionDetails;
      List<MAExemptionDetail> exemptionDetails2 = envelope.Body.oldOpportunity.OpportunityDetail.MAExemptionDetails;
      if (exemptionDetails1.Count != exemptionDetails2.Count)
        return true;
      if (exemptionDetails1.Count == 0 && exemptionDetails2.Count == 0)
        return false;
      for (int index = 0; index < exemptionDetails1.Count; ++index)
      {
        if (exemptionDetails1[index].MAExemptionType == exemptionDetails2[index].MAExemptionType)
        {
          DateTime? nullable = exemptionDetails1[index].MAExemptionDate;
          DateTime dateTime = nullable.Value;
          string shortDateString1 = dateTime.ToShortDateString();
          nullable = exemptionDetails2[index].MAExemptionDate;
          dateTime = nullable.Value;
          string shortDateString2 = dateTime.ToShortDateString();
          if (!(shortDateString1 != shortDateString2))
          {
            nullable = exemptionDetails1[index].MAExemptionExpirationDate;
            dateTime = nullable.Value;
            string shortDateString3 = dateTime.ToShortDateString();
            nullable = exemptionDetails2[index].MAExemptionExpirationDate;
            dateTime = nullable.Value;
            string shortDateString4 = dateTime.ToShortDateString();
            if (!(shortDateString3 != shortDateString4))
              continue;
          }
        }
        return true;
      }
      return false;
    }

    private MailMessage PrepareMailMessage(int emailType, IrisSoftware.iMPACT.Data.Opportunity oppty)
    {
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      this.OpportunityMailMessage(this.EmailTemplateRepository.Value.FetchByKey(emailType), oppty, initializedMailMessage);
      return initializedMailMessage;
    }

    private string SetAppGroupRecipients(string email, long AppTransactionID)
    {
      if (!string.IsNullOrEmpty(email))
      {
        StringBuilder stringBuilder1 = new StringBuilder();
        if (email.Contains("[COMPLIANCE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(3.ToString());
        }
        if (email.Contains("[LEGAL]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(18.ToString());
        }
        if (email.Contains("[MERG]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(19.ToString());
        }
        if (email.Contains("[COMMITMENTCOMMITTEE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(31.ToString());
        }
        if (email.Contains("[MANAGEMENT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(29.ToString());
        }
        if (email.Contains("[JOB-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(37.ToString());
        }
        if (email.Contains("[FIRMCREDIT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(34.ToString());
        }
        if (email.Contains("[OPERATIONS]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(6.ToString());
        }
        if (email.Contains("[PNL-APPROVER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(35.ToString());
        }
        if (email.Contains("[PNL-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(39.ToString());
        }
        if (email.Contains("[FINANCE-CONTROLLER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(36.ToString());
        }
        if (stringBuilder1.Length > 0)
        {
          StringBuilder stringBuilder2 = new StringBuilder();
          foreach (string str in this.EmailTemplateRepository.Value.FetchEmailByRoleID(AppTransactionID, stringBuilder1.ToString()))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append(";");
            stringBuilder2.Append(str);
          }
          StringBuilder emailUpdated = new StringBuilder();
          foreach (string adr in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
          {
            switch (adr.ToUpper().Trim())
            {
              case "[COMMITMENTCOMMITTEE]":
              case "[COMPLIANCE]":
              case "[FINANCE-CONTROLLER]":
              case "[FIRMCREDIT]":
              case "[JOB-ADMINISTRATOR]":
              case "[LEGAL]":
              case "[MANAGEMENT]":
              case "[MERG]":
              case "[OPERATIONS]":
              case "[PNL-ADMINISTRATOR]":
              case "[PNL-APPROVER]":
                continue;
              default:
                this.ApplyDelimiter(emailUpdated, adr);
                continue;
            }
          }
          emailUpdated.Append(";" + (object) stringBuilder2);
          return emailUpdated.ToString();
        }
      }
      return email;
    }

    private void FillInvestmentBankingDetails(
      ref string primaryBankerEmail,
      ref string quantBankerEmail,
      ref string bankerEmail,
      InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        primaryBankerEmail = string.Format("{0}{1};", (object) primaryBankerEmail, (object) partner.Email);
      else if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("2", StringComparison.CurrentCultureIgnoreCase))
        quantBankerEmail = string.Format("{0}{1};", (object) quantBankerEmail, (object) partner.Email);
      else
        bankerEmail = string.Format("{0}{1};", (object) bankerEmail, (object) partner.Email);
    }

    private void FillAnalystDetails(
      ref string leadAnalystEmail,
      ref string analystEmail,
      InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        leadAnalystEmail = string.Format("{0}{1};", (object) leadAnalystEmail, (object) partner.Email);
      else
        analystEmail = string.Format("{0}{1};", (object) analystEmail, (object) partner.Email);
    }

    private void ApplyDelimiter(StringBuilder emailUpdated, string adr)
    {
      if (emailUpdated.Length > 0)
        emailUpdated.Append(";");
      emailUpdated.Append(adr);
    }
  }
}
