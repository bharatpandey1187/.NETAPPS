﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.EventHandlers.RFPEventHandlers
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.Presenters;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Transactions;
using System.Web;

namespace IrisSoftware.iMPACT.Application.EventHandlers
{
  public class RFPEventHandlers : EventHandlersBase, IEventHandler<RfpCreatedEvent>, IEventHandler, IEventHandler<RfpUpdatedEvent>, IEventHandler<RfpStatusChangedEvent>, IEventHandler<RfpIssueInitiatedEvent>, IEventHandler<RFPNotifyDualProposalRequestedProposedEvent>
  {
    private string[] partnersEmailAddress = new string[4]
    {
      string.Empty,
      string.Empty,
      string.Empty,
      string.Empty
    };

    public RFPEventHandlers(
      Func<IUser> user,
      Func<IAuditTrailRepository> auditTrailRepository,
      Func<IEmailTemplateRepository> emailTemplateRepositry,
      Func<IRFPRepository> rfpRepository,
      Func<IIssueRepository> issueReposiotry,
      Func<IAppTransactionDocSetRepository> appTransactionDocSetRepository,
      Func<UploadDocumentPresenter> uploadDocumentPresenter,
      Func<IEntityStateRepository> entityStateRepository)
    {
      this.User = new LazyValue<IUser>(user);
      this.AuditTrailRepository = new LazyValue<IAuditTrailRepository>(auditTrailRepository);
      this.EmailTemplateRepository = new LazyValue<IEmailTemplateRepository>(emailTemplateRepositry);
      this.RFPRepository = new LazyValue<IRFPRepository>(rfpRepository);
      this.IssueRepository = new LazyValue<IIssueRepository>(issueReposiotry);
      this.AppTransactionDocSetRepository = new LazyValue<IAppTransactionDocSetRepository>(appTransactionDocSetRepository);
      this.UploadDocumentPresenter = new LazyValue<UploadDocumentPresenter>(uploadDocumentPresenter);
      this.EntityStateRepository = new LazyValue<IEntityStateRepository>(entityStateRepository);
    }

    private string GetEmailAddress(IrisSoftware.iMPACT.Data.RFP rfp)
    {
      string str = string.Empty;
      foreach (InternalPartner internalPartner in rfp.InternalPartners)
      {
        long? nullable = internalPartner.PartnerType;
        if (nullable.HasValue)
        {
          nullable = internalPartner.RoleTypeId;
          if (nullable.Value == Convert.ToInt64((object) IrisSoftware.iMPACT.Data.RFP.RoleTypes.InvestmentBankingTeam) && !string.IsNullOrEmpty(internalPartner.Email) && internalPartner.IsPrimary == "1")
            str = str + internalPartner.Email + ";";
        }
      }
      return str;
    }

    private void GetInternalPartnersEmailAddress(IrisSoftware.iMPACT.Data.RFP rfp, out string[] partnersEmailAddress)
    {
      partnersEmailAddress = new string[6]
      {
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty
      };
      if (rfp.InternalPartners == null || rfp.InternalPartners.Count <= 0)
        return;
      foreach (InternalPartner internalPartner in rfp.InternalPartners)
      {
        if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email) && internalPartner.IsActive)
        {
          switch (internalPartner.RoleTypeId.Value)
          {
            case 18:
              this.FillInvestmentBankingDetails(partnersEmailAddress, internalPartner);
              continue;
            case 19:
              this.FillAnalystDetails(partnersEmailAddress, internalPartner);
              continue;
            case 20:
              partnersEmailAddress[4] = string.Format("{0}{1};", (object) partnersEmailAddress[4], (object) internalPartner.Email);
              continue;
            case 21:
              partnersEmailAddress[5] = string.Format("{0}{1};", (object) partnersEmailAddress[5], (object) internalPartner.Email);
              continue;
            default:
              continue;
          }
        }
      }
    }

    public void Handle(Envelope<RfpCreatedEvent> envelope)
    {
      if (envelope.Body.CreatedEventType == 1)
      {
        this.UpdateRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
      }
      else
      {
        IrisSoftware.iMPACT.Data.RFP rfp = envelope.Body.RFP;
        foreach (MailMessage msg in this.PrepareMailMessage(new long?(), new long?(rfp.RfpDetail.RFPStatus[0]), rfp))
        {
          this.CreateMessage(rfp, msg);
          this.SendEmail(msg);
        }
      }
    }

    public void Handle(Envelope<RfpStatusChangedEvent> envelope)
    {
      if (envelope.Body.StatusChangedType == 1)
      {
        this.UpdateRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
        this.UpdateDocSetQueue(envelope.Body.AppTransactionID);
      }
      else
      {
        IrisSoftware.iMPACT.Data.RFP rfp = envelope.Body.RFP;
        foreach (RfpFromStateToState fromStateToState in envelope.Body.FromStateToStateList)
        {
          IrisSoftware.iMPACT.Data.RFP.RfpStatus? fromState = fromStateToState.FromState;
          foreach (MailMessage msg in this.PrepareMailMessage(fromState.HasValue ? new long?((long) fromState.GetValueOrDefault()) : new long?(), new long?((long) fromStateToState.ToState), rfp))
          {
            string recipients = this.SetAppGroupRecipients(this.GetEmailAddress(rfp), rfp.RfpDetail.AppTransactionID);
            this.SetRecipients(msg.CC, recipients);
            this.SendEmail(msg);
          }
        }
      }
    }

    public void Handle(Envelope<RfpIssueInitiatedEvent> envelope) => this.SendEmail(this.PrepareMailMessage(48, envelope.Body.rfp));

    public void Handle(
      Envelope<RFPNotifyDualProposalRequestedProposedEvent> envelope)
    {
      this.SendEmail(this.PrepareMailMessage(51, envelope.Body.rfp));
    }

    public void Handle(Envelope<RfpUpdatedEvent> envelope) => this.InformMERG(envelope);

    private List<MailMessage> PrepareMailMessage(
      long? FromStateID,
      long? ToStateID,
      IrisSoftware.iMPACT.Data.RFP rfp)
    {
      List<MailMessage> mailMessageList = new List<MailMessage>();
      foreach (IrisSoftware.iMPACT.Data.EmailTemplate template in this.EmailTemplateRepository.Value.FetchByEntityIDStateID(new long?(1L), FromStateID, ToStateID))
      {
        MailMessage initializedMailMessage = this.GetInitializedMailMessage();
        this.GetInternalPartnersEmailAddress(rfp, out this.partnersEmailAddress);
        this.RFPMailMessage(template, rfp, initializedMailMessage);
        mailMessageList.Add(initializedMailMessage);
      }
      return mailMessageList;
    }

    public override void SetRecipients(MailAddressCollection adrCollection, string recipients)
    {
      if (string.IsNullOrEmpty(recipients))
        return;
      foreach (string recipients1 in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        switch (recipients1.ToUpper().Trim())
        {
          case "[INTERNAL-PARTNERS.ANALYST]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[3]);
            continue;
          case "[INTERNAL-PARTNERS.BANKRM]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[5]);
            continue;
          case "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[1]);
            continue;
          case "[INTERNAL-PARTNERS.LEAD-ANALYST]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[2]);
            continue;
          case "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[0]);
            continue;
          case "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[4]);
            continue;
          case "[INTERNAL-PARTNERS.SYNDICATE]":
            continue;
          default:
            base.SetRecipients(adrCollection, recipients1);
            continue;
        }
      }
    }

    private void RFPMailMessage(IrisSoftware.iMPACT.Data.EmailTemplate template, IrisSoftware.iMPACT.Data.RFP Rfp, MailMessage msg)
    {
      template.To = this.SetAppGroupRecipients(template.To, Rfp.RfpDetail.AppTransactionID);
      template.Cc = this.SetAppGroupRecipients(template.Cc, Rfp.RfpDetail.AppTransactionID);
      this.SetRecipients(msg.To, template.To);
      this.SetRecipients(msg.CC, template.Cc);
      msg.Subject = this.ResolvePlaceholders(template.Subject, Rfp);
      msg.Body = this.ResolvePlaceholders(template.Body, Rfp);
    }

    private string GetRFPLink(long appTransactionId, string text)
    {
      string[] segments = HttpContext.Current.Request.UrlReferrer.Segments;
      if (segments.Length > 3)
      {
        segments[0] = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + "/";
        segments[segments.Length - 2] = "RFP/";
        segments[segments.Length - 1] = "RFP.aspx";
      }
      return string.Format("<a href='{0}?AppId={1}'>{2}</a>", (object) string.Join(string.Empty, segments), (object) appTransactionId, (object) text);
    }

    private void UpdateRootLeafNode(long appTransID, List<int> statusList)
    {
      if (Transaction.Current != (Transaction) null)
      {
        this.RFPRepository.Value.UpdateStatusTracking(appTransID, statusList, 1);
      }
      else
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.RFPRepository.Value.UpdateStatusTracking(appTransID, statusList, 1);
          transactionScope.Complete();
        }
      }
    }

    private void InformMERG(Envelope<RfpUpdatedEvent> envelope)
    {
      if (!envelope.Body.oldRFP.RfpDetail.IsMERGInformed || !this.IsMAExemptionUpdated(envelope))
        return;
      this.SendEmail(this.PrepareMERGInformedMailMessage(envelope.Body.newRFP));
    }

    private bool IsMAExemptionUpdated(Envelope<RfpUpdatedEvent> envelope)
    {
      List<MAExemptionDetail> exemptionDetails1 = envelope.Body.newRFP.RfpDetail.MAExemptionDetails;
      List<MAExemptionDetail> exemptionDetails2 = envelope.Body.oldRFP.RfpDetail.MAExemptionDetails;
      if (exemptionDetails1.Count != exemptionDetails2.Count)
        return true;
      if (exemptionDetails1.Count == 0 && exemptionDetails2.Count == 0)
        return false;
      for (int index = 0; index < exemptionDetails1.Count; ++index)
      {
        if (exemptionDetails1[index].MAExemptionType == exemptionDetails2[index].MAExemptionType)
        {
          DateTime? maExemptionDate = exemptionDetails1[index].MAExemptionDate;
          DateTime dateTime = maExemptionDate.Value;
          string shortDateString1 = dateTime.ToShortDateString();
          maExemptionDate = exemptionDetails2[index].MAExemptionDate;
          dateTime = maExemptionDate.Value;
          string shortDateString2 = dateTime.ToShortDateString();
          if (!(shortDateString1 != shortDateString2))
            continue;
        }
        return true;
      }
      return false;
    }

    private MailMessage PrepareMERGInformedMailMessage(IrisSoftware.iMPACT.Data.RFP rfp)
    {
      IrisSoftware.iMPACT.Data.EmailTemplate template = this.EmailTemplateRepository.Value.FetchByKey(49);
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      this.MERGInformedMailMessage(template, rfp, initializedMailMessage);
      return initializedMailMessage;
    }

    private void MERGInformedMailMessage(IrisSoftware.iMPACT.Data.EmailTemplate template, IrisSoftware.iMPACT.Data.RFP rfp, MailMessage msg)
    {
      this.GetInternalPartnersEmailAddress(rfp, out this.partnersEmailAddress);
      template.To = this.SetAppGroupRecipients(template.To, rfp.RfpDetail.AppTransactionID);
      template.Cc = this.SetAppGroupRecipients(template.Cc, rfp.RfpDetail.AppTransactionID);
      this.SetRecipients(msg.To, template.To);
      this.SetRecipients(msg.CC, template.Cc);
      msg.Subject = this.ResolvePlaceholders(template.Subject, rfp);
      msg.Body = this.ResolvePlaceholders(template.Body, rfp);
    }

    private string ResolvePlaceholders(string body, IrisSoftware.iMPACT.Data.RFP rfp)
    {
      body = body.Replace("[RFP-NAME]", rfp.RfpDetail.RFPName).Replace("[RFP-NAME-WITH-LINK]", this.GetRFPLink(rfp.RfpDetail.AppTransactionID, rfp.RfpDetail.RFPName)).Replace("[ISSUER-NAME]", rfp.RfpDetail.IssuerName).Replace("[PAR-AMT]", rfp.RfpDetail.ParAmount.HasValue ? string.Format("{0:C}", (object) rfp.RfpDetail.ParAmount.Value) : "").Replace("[ISSUER-NAME-WITH-LINK]", this.GetRFPLink(rfp.RfpDetail.AppTransactionID, rfp.RfpDetail.IssuerName));
      return body;
    }

    private MailMessage PrepareMailMessage(int emailType, IrisSoftware.iMPACT.Data.RFP rfp)
    {
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      this.GetInternalPartnersEmailAddress(rfp, out this.partnersEmailAddress);
      this.RFPMailMessage(emailType, rfp, initializedMailMessage);
      return initializedMailMessage;
    }

    private void RFPMailMessage(int emailType, IrisSoftware.iMPACT.Data.RFP Rfp, MailMessage msg)
    {
      IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.Value.FetchByKey(emailType);
      emailTemplate.To = this.SetAppGroupRecipients(emailTemplate.To, Rfp.RfpDetail.AppTransactionID);
      emailTemplate.Cc = this.SetAppGroupRecipients(emailTemplate.Cc, Rfp.RfpDetail.AppTransactionID);
      this.SetRecipients(msg.To, emailTemplate.To);
      this.SetRecipients(msg.CC, emailTemplate.Cc);
      msg.Subject = this.ResolvePlaceholders(emailTemplate.Subject, Rfp);
      msg.Body = this.ResolvePlaceholders(emailTemplate.Body, Rfp);
    }

    private string SetAppGroupRecipients(string email, long AppTransactionID)
    {
      if (!string.IsNullOrEmpty(email))
      {
        StringBuilder stringBuilder1 = new StringBuilder();
        if (email.Contains("[COMPLIANCE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(3.ToString());
        }
        if (email.Contains("[LEGAL]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(18.ToString());
        }
        if (email.Contains("[MERG]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(19.ToString());
        }
        if (stringBuilder1.Length > 0)
        {
          StringBuilder stringBuilder2 = new StringBuilder();
          foreach (string str in this.EmailTemplateRepository.Value.FetchEmailByRoleID(AppTransactionID, stringBuilder1.ToString()))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append(";");
            stringBuilder2.Append(str);
          }
          StringBuilder emailUpdated = new StringBuilder();
          foreach (string adr in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
          {
            string str = adr.ToUpper().Trim();
            if (!(str == "[COMPLIANCE]") && !(str == "[LEGAL]") && !(str == "[MERG]"))
              this.ApplyDelimiter(emailUpdated, adr);
          }
          emailUpdated.Append(";" + (object) stringBuilder2);
          return emailUpdated.ToString();
        }
      }
      return email;
    }

    private void FillInvestmentBankingDetails(
      string[] partnersEmailAddress,
      InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[0] = string.Format("{0}{1};", (object) partnersEmailAddress[0], (object) partner.Email);
      else
        partnersEmailAddress[1] = string.Format("{0}{1};", (object) partnersEmailAddress[1], (object) partner.Email);
    }

    private void FillAnalystDetails(string[] partnersEmailAddress, InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[2] = string.Format("{0}{1};", (object) partnersEmailAddress[2], (object) partner.Email);
      else
        partnersEmailAddress[3] = string.Format("{0}{1};", (object) partnersEmailAddress[3], (object) partner.Email);
    }

    private void CreateMessage(IrisSoftware.iMPACT.Data.RFP newRFP, MailMessage msg)
    {
      if (newRFP.InternalPartners == null || newRFP.InternalPartners.Count <= 0)
        return;
      foreach (InternalPartner internalPartner in newRFP.InternalPartners)
      {
        if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email))
        {
          long? roleTypeId = internalPartner.RoleTypeId;
          long int64_1 = Convert.ToInt64((object) IrisSoftware.iMPACT.Data.RFP.RoleTypes.InvestmentBankingTeam);
          if ((roleTypeId.GetValueOrDefault() == int64_1 ? (roleTypeId.HasValue ? 1 : 0) : 0) == 0 || !(internalPartner.IsPrimary.ToUpper() == "1"))
          {
            roleTypeId = internalPartner.RoleTypeId;
            long int64_2 = Convert.ToInt64((object) IrisSoftware.iMPACT.Data.RFP.RoleTypes.AnalystProfessionalSupport);
            if ((roleTypeId.GetValueOrDefault() == int64_2 ? (roleTypeId.HasValue ? 1 : 0) : 0) == 0 || !(internalPartner.IsPrimary.ToUpper() == "1"))
              continue;
          }
          msg.To.Add(internalPartner.Email);
        }
      }
    }

    private void ApplyDelimiter(StringBuilder emailUpdated, string adr)
    {
      if (emailUpdated.Length > 0)
        emailUpdated.Append(";");
      emailUpdated.Append(adr);
    }
  }
}
