﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.EventHandlers.CompetitiveIssueEventHandlers
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.EventBus;
using IrisSoftware.iMPACT.Application.Events;
using IrisSoftware.iMPACT.Application.Presenters;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Web;

namespace IrisSoftware.iMPACT.Application.EventHandlers
{
  public class CompetitiveIssueEventHandlers : EventHandlersBase, IEventHandler<CompetitiveIssueCreatedEvent>, IEventHandler, IEventHandler<CompetitiveIssueUpdatedEvent>, IEventHandler<CompetitiveIssueG37FormCreatedEvent>, IEventHandler<CompetitiveIssueStatusChangedEvent>, IEventHandler<CompetitiveActualAwardDateUpdatedEvent>, IEventHandler<CompetitiveFOSUpdatedEvent>, IEventHandler<CompetitiveIssueG37FormStatusChangedEvent>, IEventHandler<CompetitiveIssueNotifyDualProposalRequestedProposedEvent>
  {
    private string[] partnersEmailAddress;

    public CompetitiveIssueEventHandlers(
      Func<IUser> user,
      Func<IAuditTrailReportRepositoryComp> auditTrailRepository,
      Func<IEmailTemplateRepository> emailTemplateRepository,
      Func<ICompetitiveIssueRepository> issueRepository,
      Func<IAppTransactionDocSetRepository> appTransactionDocSetRepository,
      Func<IEntityStateRepository> entityStateRepository,
      Func<UploadDocumentPresenter> uploadDocumentPresenter,
      Func<IAppConfigRepository> appConfigRepository)
    {
      this.AuditTrailRepositoryComp = new LazyValue<IAuditTrailReportRepositoryComp>(auditTrailRepository);
      this.EmailTemplateRepository = new LazyValue<IEmailTemplateRepository>(emailTemplateRepository);
      this.User = new LazyValue<IUser>(user);
      this.CompetitiveIssueRepository = new LazyValue<ICompetitiveIssueRepository>(issueRepository);
      this.AppTransactionDocSetRepository = new LazyValue<IAppTransactionDocSetRepository>(appTransactionDocSetRepository);
      this.EntityStateRepository = new LazyValue<IEntityStateRepository>(entityStateRepository);
      this.UploadDocumentPresenter = new LazyValue<UploadDocumentPresenter>(uploadDocumentPresenter);
      this.AppConfigRepository = new LazyValue<IAppConfigRepository>(appConfigRepository);
    }

    private AuditTrail CreateAuditTrail(
      long appTransactionID,
      string entity,
      string what)
    {
      return new AuditTrail()
      {
        AppTransactionID = new long?(appTransactionID),
        Entity = entity,
        What = what
      };
    }

    public void Handle(Envelope<CompetitiveIssueCreatedEvent> envelope)
    {
      if (envelope.Body.CreatedEventType == 1)
      {
        this.UpdateRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
      }
      else
      {
        CompetitiveIssue issue = envelope.Body.Issue;
        foreach (MailMessage msg in this.PrepareMailMessage(new long?(), new long?(issue.IssueDetail.IssueStatus[0]), issue, -31))
          this.SendEmail(msg);
      }
    }

    public void Handle(Envelope<CompetitiveIssueUpdatedEvent> envelope)
    {
      CompetitiveGoodFaithDetail goodFaithDetails1 = envelope.Body.oldISSUE.GoodFaithDetails;
      CompetitiveGoodFaithDetail goodFaithDetails2 = envelope.Body.newISSUE.GoodFaithDetails;
      bool? nullable1 = goodFaithDetails2.GFRequired;
      bool flag1 = true;
      if ((nullable1.GetValueOrDefault() == flag1 ? (nullable1.HasValue ? 1 : 0) : 0) != 0)
      {
        nullable1 = goodFaithDetails2.GoodFaithApplied;
        bool? goodFaithApplied = goodFaithDetails1.GoodFaithApplied;
        if ((nullable1.GetValueOrDefault() == goodFaithApplied.GetValueOrDefault() ? (nullable1.HasValue != goodFaithApplied.HasValue ? 1 : 0) : 1) == 0)
        {
          DateTime? nullable2 = goodFaithDetails2.GoodFaithDueDate;
          DateTime? goodFaithDueDate = goodFaithDetails1.GoodFaithDueDate;
          if ((nullable2.HasValue == goodFaithDueDate.HasValue ? (nullable2.HasValue ? (nullable2.GetValueOrDefault() != goodFaithDueDate.GetValueOrDefault() ? 1 : 0) : 0) : 1) == 0)
          {
            DateTime? nullable3 = goodFaithDetails2.GoodFaithIssuedDate;
            nullable2 = goodFaithDetails1.GoodFaithIssuedDate;
            if ((nullable3.HasValue == nullable2.HasValue ? (nullable3.HasValue ? (nullable3.GetValueOrDefault() != nullable2.GetValueOrDefault() ? 1 : 0) : 0) : 1) == 0)
            {
              nullable2 = goodFaithDetails2.GoodFaithReturnedDate;
              nullable3 = goodFaithDetails1.GoodFaithReturnedDate;
              if ((nullable2.HasValue == nullable3.HasValue ? (nullable2.HasValue ? (nullable2.GetValueOrDefault() != nullable3.GetValueOrDefault() ? 1 : 0) : 0) : 1) == 0 && !(goodFaithDetails2.BankName != goodFaithDetails1.BankName))
              {
                Decimal? goodFaithAmount1 = envelope.Body.newISSUE.IssueDetail.GoodFaithAmount;
                Decimal? goodFaithAmount2 = envelope.Body.oldISSUE.IssueDetail.GoodFaithAmount;
                if ((goodFaithAmount1.GetValueOrDefault() == goodFaithAmount2.GetValueOrDefault() ? (goodFaithAmount1.HasValue != goodFaithAmount2.HasValue ? 1 : 0) : 1) == 0 && !(envelope.Body.newISSUE.IssueDetail.GoodFaithInstructions != envelope.Body.oldISSUE.IssueDetail.GoodFaithInstructions) && !(envelope.Body.newISSUE.IssueDetail.GoodFaithNotes != envelope.Body.oldISSUE.IssueDetail.GoodFaithNotes))
                {
                  long? goodFaithType1 = envelope.Body.newISSUE.IssueDetail.GoodFaithType;
                  long? goodFaithType2 = envelope.Body.oldISSUE.IssueDetail.GoodFaithType;
                  if ((goodFaithType1.GetValueOrDefault() == goodFaithType2.GetValueOrDefault() ? (goodFaithType1.HasValue != goodFaithType2.HasValue ? 1 : 0) : 1) == 0 && !(envelope.Body.newISSUE.IssueDetail.GoodFaithWireInfo != envelope.Body.oldISSUE.IssueDetail.GoodFaithWireInfo) && (!(envelope.Body.newISSUE.IssueDetail.ABANumber != envelope.Body.oldISSUE.IssueDetail.ABANumber) && !(envelope.Body.newISSUE.IssueDetail.AccountNumber != envelope.Body.oldISSUE.IssueDetail.AccountNumber)))
                    goto label_8;
                }
              }
            }
          }
        }
        this.SendGoodFaithInfo(envelope.Body.newISSUE);
      }
label_8:
      bool? nullable4 = envelope.Body.newISSUE.IssueDetail.IsIssueInitiatedFromParentOpportunity;
      if (nullable4.HasValue)
      {
        nullable4 = envelope.Body.newISSUE.IssueDetail.IsIssueInitiatedFromParentOpportunity;
        bool flag2 = false;
        if ((nullable4.GetValueOrDefault() == flag2 ? (nullable4.HasValue ? 1 : 0) : 0) == 0)
          return;
      }
      nullable4 = envelope.Body.newISSUE.IssueDetail.IsJobAdminInformed;
      if (nullable4.HasValue)
      {
        nullable4 = envelope.Body.newISSUE.IssueDetail.IsJobAdminInformed;
        bool flag2 = false;
        if ((nullable4.GetValueOrDefault() == flag2 ? (nullable4.HasValue ? 1 : 0) : 0) == 0)
          return;
      }
      this.InformJobAdmin(envelope.Body.newISSUE);
    }

    public void Handle(
      Envelope<CompetitiveIssueStatusChangedEvent> envelope)
    {
      if (envelope.Body.StatusChangedType == 1)
      {
        this.UpdateRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
        this.UpdateDocSetQueue(envelope.Body.AppTransactionID);
      }
      else
      {
        CompetitiveIssue issue = envelope.Body.Issue;
        List<CompetitiveIssueFromStateToState> stateToStateList = envelope.Body.FromStateToStateList;
        bool flag = false;
        foreach (CompetitiveIssueFromStateToState fromStateToState in stateToStateList)
        {
          CompetitiveIssueEnums.IssueStatus? fromState = fromStateToState.FromState;
          long? FromStateID = fromState.HasValue ? new long?((long) fromState.GetValueOrDefault()) : new long?();
          long? ToStateID = new long?((long) fromStateToState.ToState);
          if (!flag)
          {
            List<MailMessage> mailMessageList = this.PrepareMailMessage(FromStateID, ToStateID, issue, -31);
            long? nullable = ToStateID;
            long num = 3;
            if ((nullable.GetValueOrDefault() == num ? (nullable.HasValue ? 1 : 0) : 0) != 0 && stateToStateList.Count > 1)
              flag = true;
            foreach (MailMessage msg in mailMessageList)
              this.SendEmail(msg);
          }
        }
        this.GenerateAuditTrailReport(envelope);
      }
    }

    public void Handle(
      Envelope<CompetitiveActualAwardDateUpdatedEvent> envelope)
    {
      CompetitiveIssue issue = envelope.Body.Issue;
      this.SendEmail(this.PrepareMailMessage(5, issue));
      this.UpdateAuditTrail(this.CreateAuditTrail(issue.IssueDetail.AppTransactionID, "Issue", "Actual Award Date-Time updated"));
    }

    public void Handle(Envelope<CompetitiveFOSUpdatedEvent> envelope)
    {
      CompetitiveIssue issue = envelope.Body.Issue;
      this.SendEmail(this.PrepareMailMessage(6, issue));
      this.UpdateAuditTrail(this.CreateAuditTrail(issue.IssueDetail.AppTransactionID, "Issue", "Final OS Received Date-Time updated"));
    }

    public void Handle(
      Envelope<CompetitiveIssueG37FormCreatedEvent> envelope)
    {
      if (envelope.Body.CreatedEventType != 1)
        return;
      this.UpdateG37FormRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
    }

    public void Handle(
      Envelope<CompetitiveIssueNotifyDualProposalRequestedProposedEvent> envelope)
    {
      this.SendEmail(this.PrepareMailMessage(105, envelope.Body.issue));
    }

    public void Handle(
      Envelope<CompetitiveIssueG37FormStatusChangedEvent> envelope)
    {
      if (envelope.Body.StatusChangedType != 1)
        return;
      this.UpdateG37FormRootLeafNode(envelope.Body.AppTransactionID, envelope.Body.EntityStateTrackingList);
    }

    private void InformJobAdmin(CompetitiveIssue issue)
    {
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      IrisSoftware.iMPACT.Data.EmailTemplate template = this.EmailTemplateRepository.Value.FetchByKey(68);
      if (template != null && template.IsActive)
      {
        this.SetMailMessage(template, issue, initializedMailMessage);
        this.SendEmail(initializedMailMessage);
      }
      this.UpdateIsJobAdminInformedAsTrue(issue.IssueDetail.AppTransactionID);
    }

    private void SendGoodFaithInfo(CompetitiveIssue issue)
    {
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      IrisSoftware.iMPACT.Data.EmailTemplate template = this.EmailTemplateRepository.Value.FetchByKey(240);
      if (template == null || !template.IsActive)
        return;
      this.SetMailMessage(template, issue, initializedMailMessage);
      this.SendEmail(initializedMailMessage);
    }

    private void UpdateIsJobAdminInformedAsTrue(long currentId) => this.CompetitiveIssueRepository.Value.UpdateIsJobAdminInformedAsTrue(currentId);

    private void GenerateAuditTrailReport(
      Envelope<CompetitiveIssueStatusChangedEvent> envelope)
    {
      if (!this.EntityStateRepository.Value.IsEntityStateFreezed(-31L, ((IEnumerable<long?>) envelope.Body.FromStateToStateList.Select<CompetitiveIssueFromStateToState, long?>((Func<CompetitiveIssueFromStateToState, long?>) (m => new long?((long) m.ToState))).ToArray<long?>()).Join<long?>(",")))
        return;
      this.UploadDocumentPresenter.Value.SaveIssueAuditTrailList(envelope.Body.Issue.IssueDetail.AppTransactionID);
    }

    private MailMessage PrepareInformJobAdminMailMessage(CompetitiveIssue issue)
    {
      IrisSoftware.iMPACT.Data.EmailTemplate template = this.EmailTemplateRepository.Value.FetchByKey(68);
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      this.SetMailMessage(template, issue, initializedMailMessage);
      return initializedMailMessage;
    }

    private void SetMailMessage(IrisSoftware.iMPACT.Data.EmailTemplate template, CompetitiveIssue issue, MailMessage msg)
    {
      this.GetInternalPartnersEmailAddress(issue, out this.partnersEmailAddress);
      template.To = this.SetAppGroupRecipients(template.To, issue.IssueDetail.AppTransactionID);
      template.Cc = this.SetAppGroupRecipients(template.Cc, issue.IssueDetail.AppTransactionID);
      this.SetRecipients(msg.To, template.To);
      this.SetRecipients(msg.CC, template.Cc);
      msg.Subject = this.ResolvePlaceholders(template.Subject, issue);
      msg.Body = this.ResolvePlaceholders(template.Body, issue);
    }

    private bool IsMAExemptionUpdated(Envelope<CompetitiveIssueUpdatedEvent> envelope)
    {
      IEnumerable<MAExemptionDetail> maExemptions1 = envelope.Body.newISSUE.IssueDetail.MAExemptions;
      IEnumerable<MAExemptionDetail> maExemptions2 = envelope.Body.oldISSUE.IssueDetail.MAExemptions;
      if (maExemptions1 == null || maExemptions2 == null)
        return false;
      if (maExemptions1.Count<MAExemptionDetail>() != maExemptions2.Count<MAExemptionDetail>())
        return true;
      if (maExemptions1.Count<MAExemptionDetail>() == 0 && maExemptions2.Count<MAExemptionDetail>() == 0)
        return false;
      for (int index = 0; index < maExemptions1.Count<MAExemptionDetail>(); ++index)
      {
        MAExemptionDetail maExemptionDetail1 = maExemptions1.ElementAt<MAExemptionDetail>(index);
        MAExemptionDetail maExemptionDetail2 = maExemptions2.ElementAt<MAExemptionDetail>(index);
        if (maExemptionDetail1.MAExemptionType == maExemptionDetail2.MAExemptionType)
        {
          DateTime? maExemptionDate = maExemptionDetail1.MAExemptionDate;
          string shortDateString1 = maExemptionDate.Value.ToShortDateString();
          maExemptionDate = maExemptionDetail2.MAExemptionDate;
          string shortDateString2 = maExemptionDate.Value.ToShortDateString();
          if (!(shortDateString1 != shortDateString2))
            continue;
        }
        return true;
      }
      return false;
    }

    private string GetIssueLink(long appTransactionId, string text)
    {
      string[] segments = HttpContext.Current.Request.UrlReferrer.Segments;
      if (segments.Length > 3)
      {
        segments[0] = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + "/";
        segments[segments.Length - 2] = "CompetitiveIssue/";
        segments[segments.Length - 1] = "CompetitiveIssue.aspx";
      }
      return string.Format("<a href='{0}?IssueId={1}'>{2}</a>", (object) string.Join(string.Empty, segments), (object) appTransactionId, (object) text);
    }

    private string GetIssueDocumentTabLink(long appTransactionId, string text) => string.Format("<a href='{0}?IssueId={1}&tab=7'>{2}</a>", (object) HttpContext.Current.Request.UrlReferrer.AbsoluteUri, (object) appTransactionId, (object) text);

    private List<MailMessage> PrepareMailMessage(
      long? FromStateID,
      long? ToStateID,
      CompetitiveIssue issue,
      int IssueEntityID)
    {
      List<MailMessage> mailMessageList = new List<MailMessage>();
      foreach (IrisSoftware.iMPACT.Data.EmailTemplate template in this.EmailTemplateRepository.Value.FetchByEntityIDStateID(new long?((long) IssueEntityID), FromStateID, ToStateID))
      {
        MailMessage initializedMailMessage = this.GetInitializedMailMessage();
        this.GetInternalPartnersEmailAddress(issue, out this.partnersEmailAddress);
        this.IssueMailMessage(template, issue, initializedMailMessage);
        mailMessageList.Add(initializedMailMessage);
      }
      return mailMessageList;
    }

    private MailMessage PrepareMailMessage(CompetitiveReviewChecklist reviewChecklist)
    {
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      this.GetInternalPartnersEmailAddress(reviewChecklist.Issue, out this.partnersEmailAddress);
      return initializedMailMessage;
    }

    private string GetSeriesData(CompetitiveIssue issue)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (Series series in issue.IssueDetail.Series)
        stringBuilder.Append(string.Format("{0:C}", (object) series.ParAmount) + " " + series.SeriesName + "</br>");
      return stringBuilder.ToString();
    }

    private void IssueMailMessage(IrisSoftware.iMPACT.Data.EmailTemplate template, CompetitiveIssue issue, MailMessage msg)
    {
      template.To = this.SetAppGroupRecipients(template.To, issue.IssueDetail.AppTransactionID);
      template.Cc = this.SetAppGroupRecipients(template.Cc, issue.IssueDetail.AppTransactionID);
      this.SetRecipients(msg.To, template.To);
      this.SetRecipients(msg.CC, template.Cc);
      msg.Subject = this.ResolvePlaceholders(template.Subject, issue);
      msg.Body = this.ResolvePlaceholders(template.Body, issue);
    }

    private string GetEmailSeriesBodyLabel(string Placeholder)
    {
      if (Placeholder.Contains("[SERIES-DELIVERY-DATE]"))
        return "Series Delivery Date";
      if (Placeholder.Contains("[INSURANCE]"))
        return "Insurance";
      if (Placeholder.Contains("[FINAL-MATURITY]"))
        return "Final Maturity";
      if (Placeholder.Contains("[EXPECTED-CALL-FEATURE]"))
        return "Call Feature";
      if (Placeholder.Contains("[UNDERLYING-RATING]"))
        return "Underlying Rating";
      if (Placeholder.Contains("[SHORT-TERM-UNDERLYING-RATING]"))
        return "Short Term Underlying Rating";
      if (Placeholder.Contains("[DENOMINATIONS]"))
        return "Minimum Denomination";
      if (Placeholder.Contains("[SERIES-INFO]"))
        return "Series";
      if (Placeholder.Contains("[SERIES-CODE]"))
        return "Series Code";
      if (Placeholder.Contains("[SERIES-JOB-NUMBER]"))
        return "Job Number";
      if (Placeholder.Contains("[SERIES-PAR-AMT]"))
        return "Amount";
      if (Placeholder.Contains("[STATE-TAXABLE]"))
        return "State Tax";
      if (Placeholder.Contains("[FED-TAXABLE]"))
        return "Fed Tax";
      if (Placeholder.Contains("[BANK-QUALIFIED]"))
        return "Bank Qualified";
      if (Placeholder.Contains("[SECURITY-TYPE-GENERAL]"))
        return "Security Type (General)";
      if (Placeholder.Contains("[SECURITY]"))
        return "Security";
      if (Placeholder.Contains("[SECURITY-DETAILS]"))
        return "Security Details";
      if (Placeholder.Contains("[FIRST-COUPON]"))
        return "1st Coupon";
      if (Placeholder.Contains("[ACCRUE-FROM]"))
        return "Accrue From";
      if (Placeholder.Contains("[FORM]"))
        return "Form";
      if (Placeholder.Contains("[COUPON-FREQ]"))
        return "Coupon Frequency";
      if (Placeholder.Contains("[DAY-COUNT]"))
        return "Day Count";
      if (Placeholder.Contains("[RATE-TYPE]"))
        return "Interest Rate Type";
      if (Placeholder.Contains("[CALL-DATE]"))
        return "Call Date";
      if (Placeholder.Contains("[CALL-PRICE]"))
        return "Call Price";
      if (Placeholder.Contains("[FIRM-INVENTORY]"))
        return "Firm Inventory";
      if (Placeholder.Contains("[SERIES-DATED-DATE]"))
        return "Series Dated Date";
      if (Placeholder.Contains("[SERIES-PRICING-DATE]"))
        return "Series Pricing Date";
      if (Placeholder.Contains("[SERIES-ROP-DATE]"))
        return "Series Retail Order Period Date";
      if (Placeholder.Contains("[SERIES-ACTUAL-AWARD-DATE]"))
        return "Series Actual Award Date & Time";
      if (Placeholder.Contains("[SERIES-FIRM-ROLE]"))
        return "Series Firm Role";
      if (Placeholder.Contains("[SERIES-FIRM-LIABILITY]"))
        return "Series Firm Liability %";
      if (Placeholder.Contains("[SERIES-FIRM-MGT-FEE]"))
        return "Series Firm Management Fee %";
      return Placeholder.Contains("[SERIES-SDC-CREDIT]") ? "Series SDC Credit %" : "&nbsp;";
    }

    private string GenerateEmailSeriesBody(string placeholderStr, CompetitiveIssue issue)
    {
      if (string.IsNullOrEmpty(placeholderStr))
        return placeholderStr;
      placeholderStr = placeholderStr.Replace("&nbsp;", string.Empty).Trim();
      placeholderStr = placeholderStr.Replace("&NBSP;", string.Empty).Trim();
      string[] strArray = placeholderStr.Split(';');
      StringBuilder GridHTML = new StringBuilder();
      StringBuilder GridHTMLRow = new StringBuilder();
      StringBuilder stringBuilder = new StringBuilder();
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      string empty5 = string.Empty;
      string empty6 = string.Empty;
      string empty7 = string.Empty;
      string empty8 = string.Empty;
      string empty9 = string.Empty;
      int countHeader = 0;
      int CellWidth = 0;
      int TableWidth = 50;
      string DateFormat = "MM'/'dd'/'yyyy";
      if (issue.IssueDetail.Series != null && issue.IssueDetail.Series.Count<Series>() > 0)
      {
        CellWidth = 100 / (issue.IssueDetail.Series.Count<Series>() + 1);
        if (issue.IssueDetail.Series.Count<Series>() >= 3)
          TableWidth = 100;
      }
      foreach (string str in strArray)
      {
        if (!string.IsNullOrEmpty(str) && !string.IsNullOrEmpty(str.Trim()))
        {
          int count = 0;
          GridHTMLRow.Length = 0;
          if (issue.IssueDetail.Series == null || issue.IssueDetail.Series.Count<Series>() <= 0)
          {
            this.AppendHTML(GridHTML, str);
          }
          else
          {
            foreach (Series sr in issue.IssueDetail.Series)
            {
              this.ReplacePlaceholdersForSeries(ref empty1, ref empty2, ref empty3, ref empty4, ref empty5, ref empty6, ref empty7, ref empty8, ref empty9, DateFormat, str, sr);
              this.CreateHTMLRow(GridHTMLRow, empty1, count, countHeader, CellWidth, TableWidth, str);
              ++count;
              ++countHeader;
            }
            if (GridHTMLRow.Length > 0)
              GridHTML.Append((object) GridHTMLRow.Append("</tr>"));
          }
        }
      }
      if (GridHTML.Length > 0 && issue.IssueDetail.Series != null && issue.IssueDetail.Series.Count<Series>() > 0)
        GridHTML.Append("</table>");
      return GridHTML.ToString();
    }

    private string UpdateEmailSeriesData(string _body, CompetitiveIssue issue)
    {
      StringBuilder stringBuilder1 = new StringBuilder(_body);
      string format = "MM'/'dd'/'yyyy";
      if (stringBuilder1.ToString().Contains("[STATE-TAXABLE]") || stringBuilder1.ToString().Contains("[FED-TAXABLE]") || (stringBuilder1.ToString().Contains("[BANK-QUALIFIED]") || stringBuilder1.ToString().Contains("[SERIES-INFO]")) || (stringBuilder1.ToString().Contains("[SERIES-CODE]") || stringBuilder1.ToString().Contains("[SERIES-JOB-NUMBER]") || (stringBuilder1.ToString().Contains("[UNDERLYING-RATING]") || stringBuilder1.ToString().Contains("[SHORT-TERM-UNDERLYING-RATING]"))) || (stringBuilder1.ToString().Contains("[DENOMINATIONS]") || stringBuilder1.ToString().Contains("[SERIES-PAR-AMT]") || (stringBuilder1.ToString().Contains("[INSURANCE]") || stringBuilder1.ToString().Contains("[FINAL-MATURITY]")) || (stringBuilder1.ToString().Contains("[EXPECTED-CALL-FEATURE]") || stringBuilder1.ToString().Contains("[SECURITY-TYPE-GENERAL]") || (stringBuilder1.ToString().Contains("[SECURITY]") || stringBuilder1.ToString().Contains("[SECURITY-DETAILS]")))) || (stringBuilder1.ToString().Contains("[FIRST-COUPON]") || stringBuilder1.ToString().Contains("[ACCRUE-FROM]") || (stringBuilder1.ToString().Contains("[FORM]") || stringBuilder1.ToString().Contains("[COUPON-FREQ]")) || (stringBuilder1.ToString().Contains("[DAY-COUNT]") || stringBuilder1.ToString().Contains("[RATE-TYPE]") || (stringBuilder1.ToString().Contains("[CALL-DATE]") || stringBuilder1.ToString().Contains("[CALL-PRICE]"))) || (stringBuilder1.ToString().Contains("[FIRM-INVENTORY]") || stringBuilder1.ToString().Contains("[SERIES-PRICING-DATE]") || (stringBuilder1.ToString().Contains("[SERIES-ROP-DATE]") || stringBuilder1.ToString().Contains("[SERIES-ACTUAL-AWARD-DATE]")) || (stringBuilder1.ToString().Contains("[SERIES-FIRM-ROLE]") || stringBuilder1.ToString().Contains("[SERIES-FIRM-LIABILITY]") || (stringBuilder1.ToString().Contains("[SERIES-FIRM-MGT-FEE]") || stringBuilder1.ToString().Contains("[SERIES-SDC-CREDIT]"))))) || (stringBuilder1.ToString().Contains("[SERIES-DATED-DATE]") || stringBuilder1.ToString().Contains("[SERIES-DELIVERY-DATE]")))
      {
        string pattern = "\\[GRID\\](.*?)\\[\\/GRID\\]";
        MatchCollection matchCollection = Regex.Matches(_body, pattern);
        if (matchCollection.Count > 0)
        {
          foreach (Match match in matchCollection)
          {
            if (match.Groups != null && match.Groups.Count > 0)
              stringBuilder1 = stringBuilder1.Replace(match.Groups[0].ToString(), this.GenerateEmailSeriesBody(match.Groups[1].ToString(), issue));
          }
        }
        if (stringBuilder1.ToString().Contains("[STATE-TAXABLE]") || stringBuilder1.ToString().Contains("[FED-TAXABLE]") || (stringBuilder1.ToString().Contains("[BANK-QUALIFIED]") || stringBuilder1.ToString().Contains("[SERIES-INFO]")) || (stringBuilder1.ToString().Contains("[SERIES-CODE]") || stringBuilder1.ToString().Contains("[SERIES-JOB-NUMBER]") || (stringBuilder1.ToString().Contains("[UNDERLYING-RATING]") || stringBuilder1.ToString().Contains("[SHORT-TERM-UNDERLYING-RATING]"))) || (stringBuilder1.ToString().Contains("[DENOMINATIONS]") || stringBuilder1.ToString().Contains("[SERIES-PAR-AMT]") || (stringBuilder1.ToString().Contains("[INSURANCE]") || stringBuilder1.ToString().Contains("[FINAL-MATURITY]")) || (stringBuilder1.ToString().Contains("[EXPECTED-CALL-FEATURE]") || stringBuilder1.ToString().Contains("[SECURITY-TYPE-GENERAL]") || (stringBuilder1.ToString().Contains("[SECURITY]") || stringBuilder1.ToString().Contains("[SECURITY-DETAILS]")))) || (stringBuilder1.ToString().Contains("[FIRST-COUPON]") || stringBuilder1.ToString().Contains("[ACCRUE-FROM]") || (stringBuilder1.ToString().Contains("[FORM]") || stringBuilder1.ToString().Contains("[COUPON-FREQ]")) || (stringBuilder1.ToString().Contains("[DAY-COUNT]") || stringBuilder1.ToString().Contains("[RATE-TYPE]") || (stringBuilder1.ToString().Contains("[CALL-DATE]") || stringBuilder1.ToString().Contains("[CALL-PRICE]"))) || (stringBuilder1.ToString().Contains("[FIRM-INVENTORY]") || stringBuilder1.ToString().Contains("[SERIES-PRICING-DATE]") || (stringBuilder1.ToString().Contains("[SERIES-ROP-DATE]") || stringBuilder1.ToString().Contains("[SERIES-ACTUAL-AWARD-DATE]")) || (stringBuilder1.ToString().Contains("[SERIES-FIRM-ROLE]") || stringBuilder1.ToString().Contains("[SERIES-FIRM-LIABILITY]") || (stringBuilder1.ToString().Contains("[SERIES-FIRM-MGT-FEE]") || stringBuilder1.ToString().Contains("[SERIES-SDC-CREDIT]"))))) || (stringBuilder1.ToString().Contains("[SERIES-DATED-DATE]") || stringBuilder1.ToString().Contains("[SERIES-DELIVERY-DATE]")))
        {
          using (IEnumerator<Series> enumerator = issue.IssueDetail.Series.GetEnumerator())
          {
            if (enumerator.MoveNext())
            {
              Series current = enumerator.Current;
              string str1 = string.Empty;
              string str2 = string.Empty;
              string str3 = string.Empty;
              string str4 = string.Empty;
              if (!string.IsNullOrEmpty(current.MoodyRatingLT) || !string.IsNullOrEmpty(current.SPRatingLT) || (!string.IsNullOrEmpty(current.FitchRatingLT) || !string.IsNullOrEmpty(current.KrollRatingLT)))
              {
                str1 = string.IsNullOrEmpty(current.MoodyRatingLT) ? "-/" : current.MoodyRatingLT + "/";
                str2 = string.IsNullOrEmpty(current.SPRatingLT) ? "-/" : current.SPRatingLT + "/";
                str3 = string.IsNullOrEmpty(current.FitchRatingLT) ? "-/" : current.FitchRatingLT + "/";
                str4 = string.IsNullOrEmpty(current.KrollRatingLT) ? "-" : current.KrollRatingLT;
              }
              else if (!string.IsNullOrEmpty(current.MoodyRatingST) || !string.IsNullOrEmpty(current.SPRatingST) || (!string.IsNullOrEmpty(current.FitchRatingST) || !string.IsNullOrEmpty(current.KrollRatingST)))
              {
                str1 = string.IsNullOrEmpty(current.MoodyRatingST) ? "-/" : current.MoodyRatingST + "/";
                str2 = string.IsNullOrEmpty(current.SPRatingST) ? "-/" : current.SPRatingST + "/";
                str3 = string.IsNullOrEmpty(current.FitchRatingST) ? "-/" : current.FitchRatingST + "/";
                str4 = string.IsNullOrEmpty(current.KrollRatingST) ? "-" : current.KrollRatingST;
              }
              string str5 = string.Format("{0}{1}{2}{3}", (object) str1, (object) str2, (object) str3, (object) str4);
              string MoodyRatingST = string.Empty;
              string SPRatingST = string.Empty;
              string FitchRatingST = string.Empty;
              string KrollRatingST = string.Empty;
              if (!string.IsNullOrEmpty(current.MoodyRatingST) || !string.IsNullOrEmpty(current.SPRatingST) || (!string.IsNullOrEmpty(current.FitchRatingST) || !string.IsNullOrEmpty(current.KrollRatingST)))
              {
                MoodyRatingST = string.IsNullOrEmpty(current.MoodyRatingST) ? "-/" : current.MoodyRatingST + "/";
                SPRatingST = string.IsNullOrEmpty(current.SPRatingST) ? "-/" : current.SPRatingST + "/";
                FitchRatingST = string.IsNullOrEmpty(current.FitchRatingST) ? "-/" : current.FitchRatingST + "/";
                KrollRatingST = string.IsNullOrEmpty(current.KrollRatingST) ? "-" : current.KrollRatingST;
              }
              string str6 = this.AppendEnhancedRatings(MoodyRatingST, SPRatingST, FitchRatingST, KrollRatingST, current);
              stringBuilder1 = stringBuilder1.Replace("[INSURANCE]", current.InsuranceName);
              StringBuilder stringBuilder2 = stringBuilder1;
              DateTime? nullable1 = current.StructureDateTo;
              string empty1;
              if (nullable1.HasValue)
              {
                nullable1 = current.StructureDateTo;
                empty1 = nullable1.Value.ToString(format);
              }
              else
                empty1 = string.Empty;
              stringBuilder1 = stringBuilder2.Replace("[FINAL-MATURITY]", empty1);
              stringBuilder1 = stringBuilder1.Replace("[EXPECTED-CALL-FEATURE]", current.CallFeature);
              stringBuilder1 = stringBuilder1.Replace("[UNDERLYING-RATING]", str5.ToString());
              stringBuilder1 = stringBuilder1.Replace("[SHORT-TERM-UNDERLYING-RATING]", str6.ToString());
              StringBuilder stringBuilder3 = stringBuilder1;
              Decimal? nullable2 = current.Denomination;
              string newValue1 = !nullable2.HasValue ? string.Empty : string.Format("{0:C0}", (object) current.Denomination);
              stringBuilder1 = stringBuilder3.Replace("[DENOMINATIONS]", newValue1);
              nullable2 = current.ParAmount;
              string newValue2 = string.IsNullOrEmpty(nullable2.ToString()) ? "$0" : string.Format("{0:C0}", (object) current.ParAmount);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-INFO]", current.SeriesName);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-CODE]", current.SeriesCode);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-JOB-NUMBER]", current.JobNumber);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-PAR-AMT]", newValue2);
              stringBuilder1 = stringBuilder1.Replace("[STATE-TAXABLE]", string.IsNullOrEmpty(current.StateTaxable) ? string.Empty : current.StateTaxable.Trim());
              stringBuilder1 = stringBuilder1.Replace("[FED-TAXABLE]", string.IsNullOrEmpty(current.FedTaxName) ? string.Empty : current.FedTaxName.Trim());
              StringBuilder stringBuilder4 = stringBuilder1;
              string newValue3;
              if (current.BankQualified.HasValue)
              {
                bool? bankQualified = current.BankQualified;
                bool flag = true;
                newValue3 = (bankQualified.GetValueOrDefault() == flag ? (bankQualified.HasValue ? 1 : 0) : 0) != 0 ? "Yes" : "No";
              }
              else
                newValue3 = string.Empty;
              stringBuilder1 = stringBuilder4.Replace("[BANK-QUALIFIED]", newValue3);
              stringBuilder1 = stringBuilder1.Replace("[SECURITY-TYPE-GENERAL]", string.IsNullOrEmpty(current.SecTypeName) ? string.Empty : current.SecTypeName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[SECURITY]", string.IsNullOrEmpty(current.Security) ? string.Empty : current.Security.Trim());
              stringBuilder1 = stringBuilder1.Replace("[SECURITY-DETAILS]", string.IsNullOrEmpty(current.SecurityDetails) ? string.Empty : current.SecurityDetails.Trim());
              StringBuilder stringBuilder5 = stringBuilder1;
              nullable1 = current.FirstCouponDate;
              string empty2;
              if (nullable1.HasValue)
              {
                nullable1 = current.FirstCouponDate;
                empty2 = nullable1.Value.ToString(format);
              }
              else
                empty2 = string.Empty;
              stringBuilder1 = stringBuilder5.Replace("[FIRST-COUPON]", empty2);
              stringBuilder1 = stringBuilder1.Replace("[ACCRUE-FROM]", string.IsNullOrEmpty(current.AccrueFromName) ? string.Empty : current.AccrueFromName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[FORM]", string.IsNullOrEmpty(current.PricingFromName) ? string.Empty : current.PricingFromName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[COUPON-FREQ]", string.IsNullOrEmpty(current.CouponFreqName) ? string.Empty : current.CouponFreqName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[DAY-COUNT]", string.IsNullOrEmpty(current.DayCountName) ? string.Empty : current.DayCountName.Trim());
              stringBuilder1 = stringBuilder1.Replace("[RATE-TYPE]", string.IsNullOrEmpty(current.RateTypeName) ? string.Empty : current.RateTypeName.Trim());
              StringBuilder stringBuilder6 = stringBuilder1;
              nullable1 = current.CallDate;
              string empty3;
              if (nullable1.HasValue)
              {
                nullable1 = current.CallDate;
                empty3 = nullable1.Value.ToString(format);
              }
              else
                empty3 = string.Empty;
              stringBuilder1 = stringBuilder6.Replace("[CALL-DATE]", empty3);
              StringBuilder stringBuilder7 = stringBuilder1;
              nullable2 = current.CallPrice;
              Decimal num;
              string empty4;
              if (!nullable2.HasValue)
              {
                empty4 = string.Empty;
              }
              else
              {
                nullable2 = current.CallPrice;
                num = nullable2.Value;
                empty4 = num.ToString("N3");
              }
              stringBuilder1 = stringBuilder7.Replace("[CALL-PRICE]", empty4);
              StringBuilder stringBuilder8 = stringBuilder1;
              nullable2 = current.FirmInventory;
              string newValue4 = !nullable2.HasValue ? string.Empty : string.Format("{0:C0}", (object) current.FirmInventory);
              stringBuilder1 = stringBuilder8.Replace("[FIRM-INVENTORY]", newValue4);
              nullable1 = current.ActualAwardDate;
              DateTime dateTime;
              string empty5;
              if (!nullable1.HasValue)
              {
                empty5 = string.Empty;
              }
              else
              {
                nullable1 = current.ActualAwardDate;
                dateTime = nullable1.Value;
                empty5 = dateTime.ToString("MM'/'dd'/'yyyy hh:mm tt");
              }
              string str7 = string.IsNullOrEmpty(current.ActualAwardDateTimeZone) ? "ET" : " " + current.ActualAwardDateTimeZone;
              string newValue5 = empty5 + str7;
              StringBuilder stringBuilder9 = stringBuilder1;
              nullable1 = current.DatedDate;
              string empty6;
              if (nullable1.HasValue)
              {
                nullable1 = current.DatedDate;
                dateTime = nullable1.Value;
                empty6 = dateTime.ToString(format);
              }
              else
                empty6 = string.Empty;
              stringBuilder1 = stringBuilder9.Replace("[SERIES-DATED-DATE]", empty6);
              StringBuilder stringBuilder10 = stringBuilder1;
              nullable1 = current.PricingDate;
              string empty7;
              if (nullable1.HasValue)
              {
                nullable1 = current.PricingDate;
                dateTime = nullable1.Value;
                empty7 = dateTime.ToString(format);
              }
              else
                empty7 = string.Empty;
              stringBuilder1 = stringBuilder10.Replace("[SERIES-PRICING-DATE]", empty7);
              StringBuilder stringBuilder11 = stringBuilder1;
              nullable1 = current.RetailOrderPeriodDate;
              string empty8;
              if (nullable1.HasValue)
              {
                nullable1 = current.RetailOrderPeriodDate;
                dateTime = nullable1.Value;
                empty8 = dateTime.ToString(format);
              }
              else
                empty8 = string.Empty;
              stringBuilder1 = stringBuilder11.Replace("[SERIES-ROP-DATE]", empty8);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-ACTUAL-AWARD-DATE]", newValue5);
              stringBuilder1 = stringBuilder1.Replace("[SERIES-FIRM-ROLE]", string.IsNullOrEmpty(current.FirmRoleName) ? string.Empty : current.FirmRoleName);
              StringBuilder stringBuilder12 = stringBuilder1;
              nullable2 = current.FirmLiability;
              string empty9;
              if (!nullable2.HasValue)
              {
                empty9 = string.Empty;
              }
              else
              {
                nullable2 = current.FirmLiability;
                num = nullable2.Value;
                empty9 = num.ToString();
              }
              stringBuilder1 = stringBuilder12.Replace("[SERIES-FIRM-LIABILITY]", empty9);
              StringBuilder stringBuilder13 = stringBuilder1;
              nullable2 = current.FirmMgtFee;
              string empty10;
              if (!nullable2.HasValue)
              {
                empty10 = string.Empty;
              }
              else
              {
                nullable2 = current.FirmMgtFee;
                num = nullable2.Value;
                empty10 = num.ToString();
              }
              stringBuilder1 = stringBuilder13.Replace("[SERIES-FIRM-MGT-FEE]", empty10);
              StringBuilder stringBuilder14 = stringBuilder1;
              nullable2 = current.SdcCredit;
              string empty11;
              if (!nullable2.HasValue)
              {
                empty11 = string.Empty;
              }
              else
              {
                nullable2 = current.SdcCredit;
                num = nullable2.Value;
                empty11 = num.ToString();
              }
              stringBuilder1 = stringBuilder14.Replace("[SERIES-SDC-CREDIT]", empty11);
              StringBuilder stringBuilder15 = stringBuilder1;
              nullable1 = current.SettlementDate;
              string empty12;
              if (nullable1.HasValue)
              {
                nullable1 = current.SettlementDate;
                dateTime = nullable1.Value;
                empty12 = dateTime.ToString(format);
              }
              else
                empty12 = string.Empty;
              stringBuilder1 = stringBuilder15.Replace("[SERIES-DELIVERY-DATE]", empty12);
            }
          }
          stringBuilder1 = stringBuilder1.Replace("[INSURANCE]", string.Empty).Replace("[FINAL-MATURITY]", string.Empty).Replace("[EXPECTED-CALL-FEATURE]", string.Empty).Replace("[UNDERLYING-RATING]", string.Empty).Replace("[SHORT-TERM-UNDERLYING-RATING]", string.Empty).Replace("[DENOMINATIONS]", string.Empty).Replace("[SERIES-INFO]", string.Empty).Replace("[SERIES-CODE]", string.Empty).Replace("[SERIES-JOB-NUMBER]", string.Empty).Replace("[SERIES-PAR-AMT]", string.Empty).Replace("[STATE-TAXABLE]", string.Empty).Replace("[FED-TAXABLE]", string.Empty).Replace("[BANK-QUALIFIED]", string.Empty).Replace("[SECURITY-TYPE-GENERAL]", string.Empty).Replace("[SECURITY]", string.Empty).Replace("[SECURITY-DETAILS]", string.Empty).Replace("[FIRST-COUPON]", string.Empty).Replace("[ACCRUE-FROM]", string.Empty).Replace("[FORM]", string.Empty).Replace("[COUPON-FREQ]", string.Empty).Replace("[DAY-COUNT]", string.Empty).Replace("[RATE-TYPE]", string.Empty).Replace("[CALL-DATE]", string.Empty).Replace("[CALL-PRICE]", string.Empty).Replace("[FIRM-INVENTORY]", string.Empty).Replace("[SERIES-PRICING-DATE]", string.Empty).Replace("[SERIES-ROP-DATE]", string.Empty).Replace("[SERIES-ACTUAL-AWARD-DATE]", string.Empty).Replace("[SERIES-FIRM-ROLE]", string.Empty).Replace("[SERIES-FIRM-LIABILITY]", string.Empty).Replace("[SERIES-FIRM-MGT-FEE]", string.Empty).Replace("[SERIES-SDC-CREDIT]", string.Empty).Replace("[SERIES-DELIVERY-DATE]", string.Empty).Replace("[SERIES-DATED-DATE]", string.Empty);
        }
      }
      return stringBuilder1.ToString();
    }

    private string GetConcatenatedSeriesValue(CompetitiveIssue issue, string PlcHlderValue)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (!string.IsNullOrEmpty(PlcHlderValue) && issue.IssueDetail.Series != null)
      {
        foreach (Series series in issue.IssueDetail.Series)
        {
          if (stringBuilder.Length > 0)
            stringBuilder.Append("<br />");
          stringBuilder.Append(PlcHlderValue);
          string newValue = string.IsNullOrEmpty(series.ParAmount.ToString()) ? "$0" : string.Format("{0:C0}", (object) series.ParAmount);
          stringBuilder = stringBuilder.Replace("[SERIES-INFO]", series.SeriesName);
          stringBuilder = stringBuilder.Replace("[SERIES-PAR-AMT]", newValue);
          stringBuilder = stringBuilder.Replace("[FED-TAXABLE]", "(" + (string.IsNullOrEmpty(series.FedTaxName) ? string.Empty : series.FedTaxName.Trim()) + ")");
        }
      }
      return stringBuilder.ToString();
    }

    private string GetSeriesPlaceholderfromConcatenatedValue(
      CompetitiveIssue issue,
      string PlcHlder)
    {
      string PlcHlderValue = string.Empty;
      if (PlcHlder == "[SERIES_PAR-DESC-TAX]")
        PlcHlderValue = "[SERIES-PAR-AMT] [SERIES-INFO] [FED-TAXABLE]";
      return this.GetConcatenatedSeriesValue(issue, PlcHlderValue);
    }

    private string GetConcatenatedSeriesValueDiff(CompetitiveIssue issue, string PlcHlder)
    {
      string empty = string.Empty;
      StringBuilder SeriesValue = new StringBuilder();
      int count = 0;
      string DateFormat = "MM'/'dd'/'yyyy";
      string DateTimeFormat = "MM'/'dd'/'yyyy hh:mm tt";
      string defaultTimeZone = "ET";
      if (!string.IsNullOrEmpty(PlcHlder) && issue.IssueDetail != null && (issue.IssueDetail.Series != null && issue.IssueDetail.Series.Any<Series>()))
        this.GetDetailValue(issue, PlcHlder, ref empty, SeriesValue, ref count, DateFormat, DateTimeFormat, defaultTimeZone);
      return empty;
    }

    private string GetReviewComment(CompetitiveIssue issue)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (issue.IssueReviews != null && issue.IssueReviews.Any<ReviewComments>())
      {
        if (issue.IssueReviews.First<ReviewComments>().ReviewComment != null)
          stringBuilder.Append(issue.IssueReviews.First<ReviewComments>().ReviewComment);
        stringBuilder.Append(" (");
        if (issue.IssueReviews.First<ReviewComments>().UserName != null)
          stringBuilder.Append(issue.IssueReviews.First<ReviewComments>().UserName);
        stringBuilder.Append("; ");
        DateTime? reviewCommentDateTime = issue.IssueReviews.First<ReviewComments>().ReviewCommentDateTime;
        if (reviewCommentDateTime.HasValue)
        {
          reviewCommentDateTime = issue.IssueReviews.First<ReviewComments>().ReviewCommentDateTime;
          DateTime localTime = DateTime.SpecifyKind(reviewCommentDateTime.Value, DateTimeKind.Utc).ToLocalTime();
          stringBuilder.Append(localTime.ToString("MM/dd/yyyy hh:mm:ss tt").Replace('-', '/'));
        }
        stringBuilder.Append(")");
      }
      return stringBuilder.ToString();
    }

    private string GetLT_ST_CombinedRatings(CompetitiveIssue issue)
    {
      StringBuilder stringBuilder = new StringBuilder();
      string str1 = string.Empty;
      string str2 = string.Empty;
      bool flag1 = true;
      bool flag2 = true;
      if (issue != null && issue.IssueDetail.Series != null)
      {
        List<Series> list = issue.IssueDetail.Series.ToList<Series>();
        for (int index = 0; index < issue.IssueDetail.Series.Count<Series>(); ++index)
        {
          if (index == 0)
          {
            str1 = (string.IsNullOrEmpty(list[index].MoodyRatingLT) ? "-/" : list[index].MoodyRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingLT) ? "-/" : list[index].SPRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingLT) ? "-/" : list[index].FitchRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingLT) ? "-" : list[index].KrollRatingLT.Trim());
            str2 = (string.IsNullOrEmpty(list[index].MoodyRatingST) ? "-/" : list[index].MoodyRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingST) ? "-/" : list[index].SPRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingST) ? "-/" : list[index].FitchRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingST) ? "-" : list[index].KrollRatingST.Trim());
          }
          if (index > 0)
          {
            if (str1 != (string.IsNullOrEmpty(list[index].MoodyRatingLT) ? "-/" : list[index].MoodyRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingLT) ? "-/" : list[index].SPRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingLT) ? "-/" : list[index].FitchRatingLT.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingLT) ? "-" : list[index].KrollRatingLT.Trim()))
            {
              flag1 = false;
              break;
            }
            if (str2 != (string.IsNullOrEmpty(list[index].MoodyRatingST) ? "-/" : list[index].MoodyRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].SPRatingST) ? "-/" : list[index].SPRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].FitchRatingST) ? "-/" : list[index].FitchRatingST.Trim() + "/") + (string.IsNullOrEmpty(list[index].KrollRatingST) ? "-" : list[index].KrollRatingST.Trim()))
            {
              flag2 = false;
              break;
            }
          }
        }
        if (flag1 & flag2)
        {
          if (!string.IsNullOrEmpty(str1) && str1 != "-/-/-/-")
          {
            stringBuilder.Append("(L/T): ");
            stringBuilder.Append(str1);
          }
          if (!string.IsNullOrEmpty(str2) && str2 != "-/-/-/-")
          {
            if (stringBuilder.Length > 0)
            {
              stringBuilder.Append(";");
              stringBuilder.Append("<br />");
            }
            stringBuilder.Append("(S/T): ");
            stringBuilder.Append(str2);
          }
        }
        else
        {
          foreach (Series series in issue.IssueDetail.Series)
          {
            string str3 = (string.IsNullOrEmpty(series.MoodyRatingLT) ? "-/" : series.MoodyRatingLT.Trim() + "/") + (string.IsNullOrEmpty(series.SPRatingLT) ? "-/" : series.SPRatingLT.Trim() + "/") + (string.IsNullOrEmpty(series.FitchRatingLT) ? "-/" : series.FitchRatingLT.Trim() + "/") + (string.IsNullOrEmpty(series.KrollRatingLT) ? "-" : series.KrollRatingLT.Trim());
            if (str3 != "-/-/-/-")
            {
              if (stringBuilder.Length > 0)
              {
                stringBuilder.Append(";");
                stringBuilder.Append("<br />");
              }
              stringBuilder.Append(series.SeriesCode + " (L/T): " + str3);
            }
            string str4 = (string.IsNullOrEmpty(series.MoodyRatingST) ? "-/" : series.MoodyRatingST.Trim() + "/") + (string.IsNullOrEmpty(series.SPRatingST) ? "-/" : series.SPRatingST.Trim() + "/") + (string.IsNullOrEmpty(series.FitchRatingST) ? "-/" : series.FitchRatingST.Trim() + "/") + (string.IsNullOrEmpty(series.KrollRatingST) ? "-" : series.KrollRatingST.Trim());
            if (str4 != "-/-/-/-")
            {
              if (stringBuilder.Length > 0)
              {
                stringBuilder.Append(";");
                stringBuilder.Append("<br />");
              }
              stringBuilder.Append(series.SeriesCode + " (S/T): " + str4);
            }
          }
        }
      }
      return stringBuilder.ToString();
    }

    private string ResolvePlaceholders(string _body, CompetitiveIssue issue)
    {
      if (issue == null)
        return string.Empty;
      string str1 = HttpContext.Current.Request.UrlReferrer.AbsoluteUri;
      string newValue1 = string.Empty;
      string format = "MM'/'dd'/'yyyy";
      if (issue != null && !HttpContext.Current.Request.UrlReferrer.Query.ToUpper().Contains("ISSUEID"))
        str1 = str1 + "?IssueID=" + (object) issue.IssueDetail.AppTransactionID;
      if (!HttpContext.Current.Request.UrlReferrer.Query.ToLower().Contains("tab"))
        newValue1 = str1 + "&tab=7";
      string newValue2 = string.Empty;
      if (issue.IssueDetail.ExpectedAwardDate.HasValue)
      {
        newValue2 = issue.IssueDetail.ExpectedAwardDate.Value.ToString(format);
        if (issue.IssueDetail.ExpectedAwardTxtDate.Trim().ToUpper() != "AS OF")
          newValue2 = newValue2 + " " + issue.IssueDetail.ExpectedAwardTxtDate;
      }
      _body = this.UpdateEmailSeriesData(_body, issue);
      StringBuilder stringBuilder1 = new StringBuilder(_body);
      string newValue3 = string.IsNullOrEmpty(issue.IssueDetail.FirmRoleValue) ? string.Empty : issue.IssueDetail.FirmRoleValue;
      string str2 = string.IsNullOrEmpty(issue.IssueDetail.FirmRoleValue) ? string.Empty : issue.IssueDetail.FirmRoleValue;
      Decimal num1;
      string str3;
      if (!issue.IssueDetail.FirmLiabilityPerc.HasValue)
      {
        str3 = string.Empty;
      }
      else
      {
        num1 = issue.IssueDetail.FirmLiabilityPerc.Value;
        str3 = " (" + num1.ToString() + "%)";
      }
      string newValue4 = str2 + str3;
      string newValue5 = (issue.IssueDetail.ActualAwardDateTime.HasValue ? issue.IssueDetail.ActualAwardDateTime.Value.ToString("MM'/'dd'/'yyyy hh:mm tt") : string.Empty) + (string.IsNullOrEmpty(issue.IssueDetail.ActualAwardDateTimeZone) ? "ET" : " " + issue.IssueDetail.ActualAwardDateTimeZone);
      StringBuilder stringBuilder2 = stringBuilder1.Replace("[TRANSACTION-DESCRIPTION]", issue.IssueDetail.IssueName).Replace("[TRANSACTION-DESCRIPTION-WITH-LINK]", this.GetIssueLink(issue.IssueDetail.AppTransactionID, issue.IssueDetail.IssueName)).Replace("[ISSUER-NAME]", issue.IssueDetail.IssuerName).Replace("[ISSUER-NAME-WITH-LINK]", this.GetIssueLink(issue.IssueDetail.AppTransactionID, issue.IssueDetail.IssuerName));
      Decimal? nullable1 = issue.IssueDetail.ParAmount;
      string newValue6;
      if (!nullable1.HasValue)
      {
        newValue6 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.ParAmount;
        newValue6 = string.Format("{0:C0}", (object) nullable1.Value);
      }
      StringBuilder stringBuilder3 = stringBuilder2.Replace("[PAR-AMT]", newValue6);
      nullable1 = issue.IssueDetail.GoodFaithAmount;
      string newValue7;
      if (!nullable1.HasValue)
      {
        newValue7 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.GoodFaithAmount;
        newValue7 = string.Format("{0:C}", (object) nullable1.Value);
      }
      StringBuilder stringBuilder4 = stringBuilder3.Replace("[GOOD-FAITH-AMT]", newValue7).Replace("[EXPECTED-AWARD-DATE]", newValue2).Replace("[ACTUAL-AWARD-DATE]", newValue5);
      DateTime? nullable2 = issue.IssueDetail.TicketExecDateTime;
      string newValue8;
      if (!nullable2.HasValue)
      {
        newValue8 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.TicketExecDateTime;
        newValue8 = nullable2.Value.ToString("MM'/'dd'/'yyyy hh:mm tt");
      }
      StringBuilder stringBuilder5 = stringBuilder4.Replace("[TICKET-DATE]", newValue8).Replace("[LINK-TO-PLATFORM-DOCUMENTS]", newValue1);
      nullable2 = issue.IssueDetail.GoodFaithDate;
      string newValue9;
      if (!nullable2.HasValue)
      {
        newValue9 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.GoodFaithDate;
        newValue9 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder6 = stringBuilder5.Replace("[GOOD-FAITH-DATE]", newValue9).Replace("[GOOD-FAITH-TYPE]", issue.IssueDetail.GoodFaithTypeValue).Replace("[ACCOUNT-NAME]", issue.IssueDetail.AccountName).Replace("[ACCOUNT-NUMBER]", issue.IssueDetail.AccountNumber).Replace("[ABA-NUMBER]", issue.IssueDetail.ABANumber).Replace("[NOTES]", issue.IssueDetail.GoodFaithNotes).Replace("[GOOD-FAITH-INSTRUCTIONS]", issue.IssueDetail.GoodFaithInstructions).Replace("[G-17-CONTACT-PREFIX]", issue.IssueDetail.G17ContactPrefix).Replace("[G-17-CONTACT-FIRST-NAME]", issue.IssueDetail.G17ContactFirstName).Replace("[G-17-CONTACT-LAST-NAME]", issue.IssueDetail.G17ContactLastName).Replace("[G17-CONTACT-SUFFIX]", issue.IssueDetail.G17ContactSuffix).Replace("[G-17-CONTACT-TITLE]", issue.IssueDetail.G17ContactJobTitle).Replace("[G17-CONTACT-EMAIL]", issue.IssueDetail.G17ContactEmail).Replace("[G17-CONTACT-ADDRESS]", issue.IssueDetail.G17ContactAddress).Replace("[ISSUE-UNDERLYING-RATING]", issue.IssueDetail.IssueUnderlyingRating).Replace("[MS-ROLE]", newValue3).Replace("[ISSUER-ADDRESS]", issue.IssueDetail.IssuerAddress);
      nullable2 = issue.IssueDetail.ROPDate;
      string newValue10;
      if (!nullable2.HasValue)
      {
        newValue10 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.ROPDate;
        newValue10 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder7 = stringBuilder6.Replace("[ROP-DATE]", newValue10).Replace("[TAX-STATUS]", issue.IssueDetail.TaxStatus);
      nullable2 = issue.IssueDetail.DatedDate;
      string newValue11;
      if (!nullable2.HasValue)
      {
        newValue11 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.DatedDate;
        newValue11 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder8 = stringBuilder7.Replace("[DATED-DATE]", newValue11);
      nullable1 = issue.IssueDetail.FirmLiabilityPerc;
      string newValue12;
      if (!nullable1.HasValue)
      {
        newValue12 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.FirmLiabilityPerc;
        num1 = nullable1.Value;
        newValue12 = num1.ToString();
      }
      StringBuilder stringBuilder9 = stringBuilder8.Replace("[FIRM-LIABILITY]", newValue12);
      nullable1 = issue.IssueDetail.FirmMgmtFeePerc;
      string newValue13;
      if (!nullable1.HasValue)
      {
        newValue13 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.FirmMgmtFeePerc;
        num1 = nullable1.Value;
        newValue13 = num1.ToString();
      }
      StringBuilder stringBuilder10 = stringBuilder9.Replace("[FIRM-MGT-FEE]", newValue13);
      nullable1 = issue.IssueDetail.SDCCreditPerc;
      string newValue14;
      if (!nullable1.HasValue)
      {
        newValue14 = "";
      }
      else
      {
        nullable1 = issue.IssueDetail.SDCCreditPerc;
        num1 = nullable1.Value;
        newValue14 = num1.ToString();
      }
      StringBuilder stringBuilder11 = stringBuilder10.Replace("[SDC-CREDIT]", newValue14).Replace("[SERIES_PAR-DESC-TAX]", this.GetSeriesPlaceholderfromConcatenatedValue(issue, "[SERIES_PAR-DESC-TAX]")).Replace("[CONC-SERIES-DELIVERY-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-DELIVERY-DATE]")).Replace("[CONC-SERIES-DATED-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-DATED-DATE]")).Replace("[CONC-SERIES-PRICING-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-PRICING-DATE]")).Replace("[CONC-SERIES-ROP-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-ROP-DATE]")).Replace("[CONC-SERIES-ACTUAL-AWARD-DATE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-ACTUAL-AWARD-DATE]")).Replace("[CONC-SERIES-FIRM-ROLE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-FIRM-ROLE]")).Replace("[CONC-SERIES-FIRM-LIABILITY]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-FIRM-LIABILITY]")).Replace("[CONC-SERIES-FIRM-MGT-FEE]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-FIRM-MGT-FEE]")).Replace("[CONC-SERIES-SDC-CREDIT]", this.GetConcatenatedSeriesValueDiff(issue, "[CONC-SERIES-SDC-CREDIT]")).Replace("[ISSUER-NAME]", issue.IssueDetail.IssuerName).Replace("[BORROWER/OBLIGOR]", issue.IssueDetail.BorrowerName);
      nullable2 = issue.IssueDetail.PricingDate;
      string newValue15;
      if (!nullable2.HasValue)
      {
        newValue15 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.PricingDate;
        newValue15 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder12 = stringBuilder11.Replace("[PRICING-DATE]", newValue15);
      nullable2 = issue.IssueDetail.BPASigningDate;
      string newValue16;
      if (!nullable2.HasValue)
      {
        newValue16 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.BPASigningDate;
        newValue16 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder13 = stringBuilder12.Replace("[EXPECTED-BPA-SIGNING]", newValue16).Replace("[MS-ROLE-AND-LIABILITY]", newValue4);
      nullable2 = issue.IssueDetail.SettlementDate;
      string newValue17;
      if (!nullable2.HasValue)
      {
        newValue17 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.SettlementDate;
        newValue17 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder14 = stringBuilder13.Replace("[DELIVERY-DATE]", newValue17).Replace("[PURPOSE]", issue.IssueDetail.PurposeTxt).Replace("[REASON-OF-ON-HOLD]", issue.IssueDetail.ReasonOfHold).Replace("[MS-BANKING-GROUP]", issue.IssueDetail.GeneralCategoryTxt);
      nullable2 = issue.IssueDetail.DateHired;
      string newValue18;
      if (!nullable2.HasValue)
      {
        newValue18 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.DateHired;
        newValue18 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder15 = stringBuilder14.Replace("[DATE-HIRED]", newValue18).Replace("[TYPE-OF-OFFERING]", issue.IssueDetail.OfferingTypeTxt).Replace("[DEAL-TYPE]", issue.IssueDetail.DealTypeTxt).Replace("[CROSS-SELL]", issue.IssueDetail.CrossSellIdTxt).Replace("[CROSS-SELL-DETAILS]", issue.IssueDetail.CrossSellDetail);
      nullable2 = issue.IssueDetail.OSDeemedFinalDate;
      string newValue19;
      if (!nullable2.HasValue)
      {
        newValue19 = "";
      }
      else
      {
        nullable2 = issue.IssueDetail.OSDeemedFinalDate;
        newValue19 = nullable2.Value.ToString(format);
      }
      StringBuilder stringBuilder16 = stringBuilder15.Replace("[OS-DEEMED-FINAL-DATE]", newValue19).Replace("[REVIEW-COMMENT]", this.GetReviewComment(issue)).Replace("[LT-ST-Underlying-Rating]", this.GetLT_ST_CombinedRatings(issue));
      StringBuilder stringBuilder17;
      if (issue.ExternalPartners != null)
      {
        string str4 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -3L || m.MemberType == -4L || m.MemberType == -10L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x =>
        {
          string str4 = string.IsNullOrEmpty(x.Name) ? string.Empty : x.Name;
          Decimal? liabilityPerc = x.LiabilityPerc;
          string str5;
          if (liabilityPerc.HasValue)
          {
            liabilityPerc = x.LiabilityPerc;
            str5 = " (" + liabilityPerc.Value.ToString() + "%)";
          }
          else
            str5 = string.Empty;
          return str4 + str5;
        })).ToArray<string>());
        string str7 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -11L || m.MemberType == -5L || m.MemberType == -7L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x =>
        {
          string str4 = string.IsNullOrEmpty(x.Name) ? string.Empty : x.Name;
          Decimal? liabilityPerc = x.LiabilityPerc;
          string str5;
          if (liabilityPerc.HasValue)
          {
            liabilityPerc = x.LiabilityPerc;
            str5 = " (" + liabilityPerc.Value.ToString() + "%)";
          }
          else
            str5 = string.Empty;
          return str4 + str5;
        })).ToArray<string>());
        long? firmRole1 = issue.IssueDetail.FirmRole;
        long num2 = -12;
        if ((firmRole1.GetValueOrDefault() == num2 ? (firmRole1.HasValue ? 1 : 0) : 0) == 0)
        {
          long? firmRole2 = issue.IssueDetail.FirmRole;
          long num3 = -13;
          if ((firmRole2.GetValueOrDefault() == num3 ? (firmRole2.HasValue ? 1 : 0) : 0) == 0)
          {
            long? firmRole3 = issue.IssueDetail.FirmRole;
            long num4 = -20;
            if ((firmRole3.GetValueOrDefault() == num4 ? (firmRole3.HasValue ? 1 : 0) : 0) == 0)
            {
              long? firmRole4 = issue.IssueDetail.FirmRole;
              long num5 = -21;
              if ((firmRole4.GetValueOrDefault() == num5 ? (firmRole4.HasValue ? 1 : 0) : 0) == 0)
              {
                long? firmRole5 = issue.IssueDetail.FirmRole;
                long num6 = -14;
                if ((firmRole5.GetValueOrDefault() == num6 ? (firmRole5.HasValue ? 1 : 0) : 0) == 0)
                {
                  long? firmRole6 = issue.IssueDetail.FirmRole;
                  long num7 = -16;
                  if ((firmRole6.GetValueOrDefault() == num7 ? (firmRole6.HasValue ? 1 : 0) : 0) == 0)
                    goto label_73;
                }
              }
              if (!string.IsNullOrEmpty(str7))
                str7 += "; ";
              AppConfig appConfig = this.AppConfigRepository.Value.FetchByKey(1);
              string str5 = str7;
              string str6 = appConfig == null || appConfig.Value == null ? string.Empty : appConfig.Value;
              nullable1 = issue.IssueDetail.FirmLiabilityPerc;
              string str8;
              if (nullable1.HasValue)
              {
                nullable1 = issue.IssueDetail.FirmLiabilityPerc;
                str8 = " (" + nullable1.ToString() + "%)";
              }
              else
                str8 = string.Empty;
              str7 = str5 + str6 + str8;
              goto label_73;
            }
          }
        }
        if (!string.IsNullOrEmpty(str4))
          str4 += "; ";
        AppConfig appConfig1 = this.AppConfigRepository.Value.FetchByKey(1);
        string str9 = str4;
        string str10 = appConfig1 == null || appConfig1.Value == null ? string.Empty : appConfig1.Value;
        nullable1 = issue.IssueDetail.FirmLiabilityPerc;
        string str11;
        if (nullable1.HasValue)
        {
          nullable1 = issue.IssueDetail.FirmLiabilityPerc;
          str11 = " (" + nullable1.ToString() + "%)";
        }
        else
          str11 = string.Empty;
        str4 = str9 + str10 + str11;
label_73:
        StringBuilder stringBuilder18 = stringBuilder16.Replace("[LEAD-MANAGER]", str4 ?? "").Replace("[OTHER-CO-MANAGERS]", str7 ?? "");
        string newValue20 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -43L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToArray<string>());
        string newValue21 = string.Join("; ", issue.ExternalPartners.Where<ExternalPartner>((Func<ExternalPartner, bool>) (m => m.MemberType == -44L)).Select<ExternalPartner, string>((Func<ExternalPartner, string>) (x => x.Name)).ToArray<string>());
        stringBuilder17 = stringBuilder18.Replace("[FINANCIAL-ADVISOR]", newValue20).Replace("[PAYING-AGENT]", newValue21);
      }
      else
        stringBuilder17 = stringBuilder16.Replace("[LEAD-MANAGER]", string.Empty).Replace("[OTHER-CO-MANAGERS]", string.Empty).Replace("[FINANCIAL-ADVISOR]", string.Empty).Replace("[PAYING-AGENT]", string.Empty);
      string newValue22 = string.Empty;
      if (issue.IssueDetail.Series != null && issue.IssueDetail.Series.Count<Series>() > 0)
        newValue22 = string.Join("; ", issue.IssueDetail.Series.Where<Series>((Func<Series, bool>) (m => m.JobNumber != "")).Select<Series, string>((Func<Series, string>) (x => !string.IsNullOrEmpty(x.JobNumber) ? x.JobNumber : string.Empty)).ToArray<string>());
      StringBuilder stringBuilder19 = stringBuilder17.Replace("[JOB-NUMBER]", newValue22);
      StringBuilder stringBuilder20;
      if (issue.InternalPartners != null)
      {
        string str4 = string.Join("; ", issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (m => m.IsPrimary == "1" && m.Type == "IBT")).Select<InternalPartner, string>((Func<InternalPartner, string>) (x => !string.IsNullOrEmpty(x.FullName) ? x.FullName : string.Empty)).ToArray<string>());
        string str5 = string.Join("; ", issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (m => m.IsPrimary != "1" && m.Type == "IBT")).Select<InternalPartner, string>((Func<InternalPartner, string>) (x => !string.IsNullOrEmpty(x.FullName) ? x.FullName : string.Empty)).ToArray<string>());
        string str6 = string.Join("; ", issue.InternalPartners.Where<InternalPartner>((Func<InternalPartner, bool>) (m => m.Type == "IBT")).Select<InternalPartner, string>((Func<InternalPartner, string>) (x => !string.IsNullOrEmpty(x.FullName) ? x.FullName : string.Empty)).Distinct<string>().ToArray<string>());
        stringBuilder20 = stringBuilder19.Replace("[LEAD-BANKER]", str4 ?? "").Replace("[SUPPORTING-BANKER]", str5 ?? "").Replace("[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]", str6 ?? "");
      }
      else
        stringBuilder20 = stringBuilder19.Replace("[LEAD-BANKER]", string.Empty).Replace("[SUPPORTING-BANKER]", string.Empty);
      return stringBuilder20.ToString();
    }

    private void GetInternalPartnersEmailAddress(
      CompetitiveIssue issue,
      out string[] partnersEmailAddress)
    {
      partnersEmailAddress = new string[8]
      {
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty,
        string.Empty
      };
      if (issue.InternalPartners == null || issue.InternalPartners.Count <= 0)
        return;
      foreach (InternalPartner internalPartner in issue.InternalPartners)
      {
        if (!internalPartner.IsDeleted && !string.IsNullOrEmpty(internalPartner.Email) && internalPartner.IsActive)
        {
          switch (internalPartner.RoleTypeId.Value)
          {
            case 30:
              this.FillInvestmentBankingDetails(partnersEmailAddress, internalPartner);
              continue;
            case 31:
              this.FillAnalystDetails(partnersEmailAddress, internalPartner);
              continue;
            case 32:
              partnersEmailAddress[4] = string.Format("{0}{1};", (object) partnersEmailAddress[4], (object) internalPartner.Email);
              continue;
            case 33:
              partnersEmailAddress[6] = string.Format("{0}{1};", (object) partnersEmailAddress[6], (object) internalPartner.Email);
              continue;
            case 34:
              partnersEmailAddress[5] = string.Format("{0}{1};", (object) partnersEmailAddress[5], (object) internalPartner.Email);
              continue;
            default:
              continue;
          }
        }
      }
    }

    public override void SetRecipients(MailAddressCollection adrCollection, string recipients)
    {
      if (string.IsNullOrEmpty(recipients))
        return;
      foreach (string recipients1 in recipients.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
      {
        switch (recipients1.ToUpper().Trim())
        {
          case "[INTERNAL-PARTNERS.ANALYST]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[3]);
            break;
          case "[INTERNAL-PARTNERS.BANKRM]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[6]);
            break;
          case "[INTERNAL-PARTNERS.INVESTMENTBANKINGTEAM]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[1]);
            break;
          case "[INTERNAL-PARTNERS.LEAD-ANALYST]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[2]);
            break;
          case "[INTERNAL-PARTNERS.PRIMARY-INVESTMENTBANKINGTEAM]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[0]);
            break;
          case "[INTERNAL-PARTNERS.QUANT-INVESTMENTBANKINGTEAM]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[7]);
            break;
          case "[INTERNAL-PARTNERS.SUPERVISORYPRINCIPAL]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[4]);
            break;
          case "[INTERNAL-PARTNERS.SYNDICATE]":
            base.SetRecipients(adrCollection, this.partnersEmailAddress[5]);
            break;
          default:
            base.SetRecipients(adrCollection, recipients1);
            break;
        }
      }
    }

    private MailMessage PrepareMailMessage(int emailType, CompetitiveIssue issue)
    {
      MailMessage initializedMailMessage = this.GetInitializedMailMessage();
      this.GetInternalPartnersEmailAddress(issue, out this.partnersEmailAddress);
      this.IssueMailMessage(emailType, issue, initializedMailMessage);
      return initializedMailMessage;
    }

    private void IssueMailMessage(int emailType, CompetitiveIssue issue, MailMessage msg)
    {
      IrisSoftware.iMPACT.Data.EmailTemplate emailTemplate = this.EmailTemplateRepository.Value.FetchByKey(emailType);
      emailTemplate.To = this.SetAppGroupRecipients(emailTemplate.To, issue.IssueDetail.AppTransactionID);
      emailTemplate.Cc = this.SetAppGroupRecipients(emailTemplate.Cc, issue.IssueDetail.AppTransactionID);
      this.SetRecipients(msg.To, emailTemplate.To);
      this.SetRecipients(msg.CC, emailTemplate.Cc);
      msg.Subject = this.ResolvePlaceholders(emailTemplate.Subject, issue);
      msg.Body = this.ResolvePlaceholders(emailTemplate.Body, issue);
    }

    private void UpdateRootLeafNode(long appTransID, List<int> statusList)
    {
      if (Transaction.Current != (Transaction) null)
      {
        this.CompetitiveIssueRepository.Value.UpdateStatusTracking(appTransID, statusList, -31);
      }
      else
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.CompetitiveIssueRepository.Value.UpdateStatusTracking(appTransID, statusList, -31);
          transactionScope.Complete();
        }
      }
    }

    private void UpdateG37FormRootLeafNode(long appTransID, List<int> statusList)
    {
      if (Transaction.Current != (Transaction) null)
      {
        this.CompetitiveIssueRepository.Value.UpdateStatusTracking(appTransID, statusList, -34);
      }
      else
      {
        using (TransactionScope transactionScope = new TransactionScope())
        {
          this.CompetitiveIssueRepository.Value.UpdateStatusTracking(appTransID, statusList, -34);
          transactionScope.Complete();
        }
      }
    }

    private string SetAppGroupRecipients(string email, long AppTransactionID)
    {
      if (!string.IsNullOrEmpty(email))
      {
        StringBuilder stringBuilder1 = new StringBuilder();
        if (email.Contains("[COMPLIANCE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(3.ToString());
        }
        if (email.Contains("[LEGAL]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(18.ToString());
        }
        if (email.Contains("[MERG]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(19.ToString());
        }
        if (email.Contains("[COMMITMENTCOMMITTEE]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(31.ToString());
        }
        if (email.Contains("[MANAGEMENT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(29.ToString());
        }
        if (email.Contains("[JOB-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(37.ToString());
        }
        if (email.Contains("[FIRMCREDIT]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(34.ToString());
        }
        if (email.Contains("[OPERATIONS]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(6.ToString());
        }
        if (email.Contains("[PNL-APPROVER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(35.ToString());
        }
        if (email.Contains("[PNL-ADMINISTRATOR]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(39.ToString());
        }
        if (email.Contains("[FINANCE-CONTROLLER]"))
        {
          if (stringBuilder1.Length > 0)
            stringBuilder1.Append(",");
          stringBuilder1.Append(36.ToString());
        }
        if (stringBuilder1.Length > 0)
        {
          StringBuilder stringBuilder2 = new StringBuilder();
          foreach (string str in this.EmailTemplateRepository.Value.FetchEmailByRoleID(AppTransactionID, stringBuilder1.ToString()))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append(";");
            stringBuilder2.Append(str);
          }
          StringBuilder emailUpdated = new StringBuilder();
          foreach (string adr in email.Split(";".ToCharArray(), StringSplitOptions.RemoveEmptyEntries))
          {
            switch (adr.ToUpper().Trim())
            {
              case "[COMMITMENTCOMMITTEE]":
              case "[COMPLIANCE]":
              case "[FINANCE-CONTROLLER]":
              case "[FIRMCREDIT]":
              case "[JOB-ADMINISTRATOR]":
              case "[LEGAL]":
              case "[MANAGEMENT]":
              case "[MERG]":
              case "[OPERATIONS]":
              case "[PNL-ADMINISTRATOR]":
              case "[PNL-APPROVER]":
                continue;
              default:
                this.ApplyDelimiter(emailUpdated, adr);
                continue;
            }
          }
          emailUpdated.Append(";" + (object) stringBuilder2);
          return emailUpdated.ToString();
        }
      }
      return email;
    }

    private void AppendHTML(StringBuilder GridHTML, string item)
    {
      if (GridHTML.Length > 0)
        GridHTML.Append(" " + item);
      else
        GridHTML.Append(item);
    }

    private void ReplacePlaceholdersForSeries(
      ref string ResolvedItem,
      ref string MoodyRating,
      ref string SPRating,
      ref string FitchRating,
      ref string KrollRating,
      ref string MoodyRatingST,
      ref string SPRatingST,
      ref string FitchRatingST,
      ref string KrollRatingST,
      string DateFormat,
      string item,
      Series sr)
    {
      ResolvedItem = item;
      MoodyRating = string.Empty;
      SPRating = string.Empty;
      FitchRating = string.Empty;
      KrollRating = string.Empty;
      if (!string.IsNullOrEmpty(sr.MoodyRatingLT) || !string.IsNullOrEmpty(sr.SPRatingLT) || (!string.IsNullOrEmpty(sr.FitchRatingLT) || !string.IsNullOrEmpty(sr.KrollRatingLT)))
      {
        MoodyRating = string.IsNullOrEmpty(sr.MoodyRatingLT) ? "-/" : sr.MoodyRatingLT + "/";
        SPRating = string.IsNullOrEmpty(sr.SPRatingLT) ? "-/" : sr.SPRatingLT + "/";
        FitchRating = string.IsNullOrEmpty(sr.FitchRatingLT) ? "-/" : sr.FitchRatingLT + "/";
        KrollRating = string.IsNullOrEmpty(sr.KrollRatingLT) ? "-" : sr.KrollRatingLT;
      }
      else if (!string.IsNullOrEmpty(sr.MoodyRatingST) || !string.IsNullOrEmpty(sr.SPRatingST) || (!string.IsNullOrEmpty(sr.FitchRatingST) || !string.IsNullOrEmpty(sr.KrollRatingST)))
      {
        MoodyRating = string.IsNullOrEmpty(sr.MoodyRatingST) ? "-/" : sr.MoodyRatingST + "/";
        SPRating = string.IsNullOrEmpty(sr.SPRatingST) ? "-/" : sr.SPRatingST + "/";
        FitchRating = string.IsNullOrEmpty(sr.FitchRatingST) ? "-/" : sr.FitchRatingST + "/";
        KrollRating = string.IsNullOrEmpty(sr.KrollRatingST) ? "-" : sr.KrollRatingST;
      }
      string str1 = string.Format("{0}{1}{2}{3}", (object) MoodyRating, (object) SPRating, (object) FitchRating, (object) KrollRating);
      MoodyRatingST = string.Empty;
      SPRatingST = string.Empty;
      FitchRatingST = string.Empty;
      KrollRatingST = string.Empty;
      if (!string.IsNullOrEmpty(sr.MoodyRatingST) || !string.IsNullOrEmpty(sr.SPRatingST) || (!string.IsNullOrEmpty(sr.FitchRatingST) || !string.IsNullOrEmpty(sr.KrollRatingST)))
      {
        MoodyRatingST = string.IsNullOrEmpty(sr.MoodyRatingST) ? "-/" : sr.MoodyRatingST + "/";
        SPRatingST = string.IsNullOrEmpty(sr.SPRatingST) ? "-/" : sr.SPRatingST + "/";
        FitchRatingST = string.IsNullOrEmpty(sr.FitchRatingST) ? "-/" : sr.FitchRatingST + "/";
        KrollRatingST = string.IsNullOrEmpty(sr.KrollRatingST) ? "-" : sr.KrollRatingST;
      }
      string str2 = string.Format("{0}{1}{2}{3}", (object) MoodyRatingST, (object) SPRatingST, (object) FitchRatingST, (object) KrollRatingST);
      StringBuilder stringBuilder1 = new StringBuilder();
      StringBuilder stringBuilder2 = new StringBuilder();
      StringBuilder stringBuilder3 = new StringBuilder();
      if (sr.EnhancementRatingBySeries != null)
      {
        foreach (EnhancementRatingBySeries enhancementRatingBySeries in sr.EnhancementRatingBySeries)
        {
          if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementProvider))
          {
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append("; ");
            stringBuilder1.Append(enhancementRatingBySeries.CreditEnhancementProvider);
          }
          if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementType))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append("; ");
            stringBuilder2.Append(enhancementRatingBySeries.CreditEnhancementType);
          }
          if (!string.IsNullOrEmpty(enhancementRatingBySeries.EnhancedRating))
          {
            if (stringBuilder3.Length > 0)
              stringBuilder3.Append("; ");
            stringBuilder3.Append(enhancementRatingBySeries.EnhancedRating);
          }
        }
      }
      ResolvedItem = ResolvedItem.Replace("[SERIES-DELIVERY-DATE]", !sr.SettlementDate.HasValue ? string.Empty : sr.SettlementDate.Value.ToString(DateFormat));
      ResolvedItem = ResolvedItem.Replace("[INSURANCE]", sr.InsuranceName);
      ResolvedItem = ResolvedItem.Replace("[FINAL-MATURITY]", !sr.StructureDateTo.HasValue ? string.Empty : sr.StructureDateTo.Value.ToString(DateFormat));
      ResolvedItem = ResolvedItem.Replace("[EXPECTED-CALL-FEATURE]", sr.CallFeature);
      ResolvedItem = ResolvedItem.Replace("[UNDERLYING-RATING]", str1.ToString());
      ResolvedItem = ResolvedItem.Replace("[SHORT-TERM-UNDERLYING-RATING]", str2.ToString());
      ResolvedItem = ResolvedItem.Replace("[DENOMINATIONS]", !sr.Denomination.HasValue ? string.Empty : string.Format("{0:C0}", (object) sr.Denomination));
      Decimal? nullable1 = sr.ParAmount;
      string newValue1 = string.IsNullOrEmpty(nullable1.ToString()) ? "$0" : string.Format("{0:C0}", (object) sr.ParAmount);
      ResolvedItem = ResolvedItem.Replace("[SERIES-INFO]", sr.SeriesName);
      ResolvedItem = ResolvedItem.Replace("[SERIES-CODE]", sr.SeriesCode);
      ResolvedItem = ResolvedItem.Replace("[SERIES-JOB-NUMBER]", sr.JobNumber);
      ResolvedItem = ResolvedItem.Replace("[SERIES-PAR-AMT]", newValue1);
      ResolvedItem = ResolvedItem.Replace("[STATE-TAXABLE]", string.IsNullOrEmpty(sr.StateTaxable) ? string.Empty : sr.StateTaxable.Trim());
      ResolvedItem = ResolvedItem.Replace("[FED-TAXABLE]", string.IsNullOrEmpty(sr.FedTaxName) ? string.Empty : sr.FedTaxName.Trim());
      ref string local1 = ref ResolvedItem;
      string str3 = ResolvedItem;
      string newValue2;
      if (sr.BankQualified.HasValue)
      {
        bool? bankQualified = sr.BankQualified;
        bool flag = true;
        newValue2 = (bankQualified.GetValueOrDefault() == flag ? (bankQualified.HasValue ? 1 : 0) : 0) != 0 ? "Yes" : "No";
      }
      else
        newValue2 = string.Empty;
      string str4 = str3.Replace("[BANK-QUALIFIED]", newValue2);
      local1 = str4;
      ResolvedItem = ResolvedItem.Replace("[SECURITY-TYPE-GENERAL]", string.IsNullOrEmpty(sr.SecTypeName) ? string.Empty : sr.SecTypeName.Trim());
      ResolvedItem = ResolvedItem.Replace("[SECURITY]", string.IsNullOrEmpty(sr.Security) ? string.Empty : sr.Security.Trim());
      ResolvedItem = ResolvedItem.Replace("[SECURITY-DETAILS]", string.IsNullOrEmpty(sr.SecurityDetails) ? string.Empty : sr.SecurityDetails.Trim());
      ResolvedItem = ResolvedItem.Replace("[FIRST-COUPON]", !sr.FirstCouponDate.HasValue ? string.Empty : sr.FirstCouponDate.Value.ToString(DateFormat));
      ResolvedItem = ResolvedItem.Replace("[ACCRUE-FROM]", string.IsNullOrEmpty(sr.AccrueFromName) ? string.Empty : sr.AccrueFromName.Trim());
      ResolvedItem = ResolvedItem.Replace("[FORM]", string.IsNullOrEmpty(sr.PricingFromName) ? string.Empty : sr.PricingFromName.Trim());
      ResolvedItem = ResolvedItem.Replace("[COUPON-FREQ]", string.IsNullOrEmpty(sr.CouponFreqName) ? string.Empty : sr.CouponFreqName.Trim());
      ResolvedItem = ResolvedItem.Replace("[DAY-COUNT]", string.IsNullOrEmpty(sr.DayCountName) ? string.Empty : sr.DayCountName.Trim());
      ResolvedItem = ResolvedItem.Replace("[RATE-TYPE]", string.IsNullOrEmpty(sr.RateTypeName) ? string.Empty : sr.RateTypeName.Trim());
      ResolvedItem = ResolvedItem.Replace("[CALL-DATE]", !sr.CallDate.HasValue ? string.Empty : sr.CallDate.Value.ToString(DateFormat));
      ref string local2 = ref ResolvedItem;
      string str5 = ResolvedItem;
      nullable1 = sr.CallPrice;
      string empty1;
      if (!nullable1.HasValue)
      {
        empty1 = string.Empty;
      }
      else
      {
        nullable1 = sr.CallPrice;
        empty1 = nullable1.Value.ToString("N3");
      }
      string str6 = str5.Replace("[CALL-PRICE]", empty1);
      local2 = str6;
      ref string local3 = ref ResolvedItem;
      string str7 = ResolvedItem;
      nullable1 = sr.FirmInventory;
      string newValue3 = !nullable1.HasValue ? string.Empty : string.Format("{0:C0}", (object) sr.FirmInventory);
      string str8 = str7.Replace("[FIRM-INVENTORY]", newValue3);
      local3 = str8;
      DateTime? nullable2 = sr.ActualAwardDate;
      string empty2;
      if (!nullable2.HasValue)
      {
        empty2 = string.Empty;
      }
      else
      {
        nullable2 = sr.ActualAwardDate;
        empty2 = nullable2.Value.ToString("MM'/'dd'/'yyyy hh:mm tt");
      }
      string str9 = string.IsNullOrEmpty(sr.ActualAwardDateTimeZone) ? "ET" : " " + sr.ActualAwardDateTimeZone;
      string newValue4 = empty2 + str9;
      ref string local4 = ref ResolvedItem;
      string str10 = ResolvedItem;
      nullable2 = sr.DatedDate;
      string empty3;
      if (nullable2.HasValue)
      {
        nullable2 = sr.DatedDate;
        empty3 = nullable2.Value.ToString(DateFormat);
      }
      else
        empty3 = string.Empty;
      string str11 = str10.Replace("[SERIES-DATED-DATE]", empty3);
      local4 = str11;
      ref string local5 = ref ResolvedItem;
      string str12 = ResolvedItem;
      nullable2 = sr.PricingDate;
      string empty4;
      if (nullable2.HasValue)
      {
        nullable2 = sr.PricingDate;
        empty4 = nullable2.Value.ToString(DateFormat);
      }
      else
        empty4 = string.Empty;
      string str13 = str12.Replace("[SERIES-PRICING-DATE]", empty4);
      local5 = str13;
      ref string local6 = ref ResolvedItem;
      string str14 = ResolvedItem;
      nullable2 = sr.RetailOrderPeriodDate;
      string empty5;
      if (nullable2.HasValue)
      {
        nullable2 = sr.RetailOrderPeriodDate;
        empty5 = nullable2.Value.ToString(DateFormat);
      }
      else
        empty5 = string.Empty;
      string str15 = str14.Replace("[SERIES-ROP-DATE]", empty5);
      local6 = str15;
      ResolvedItem = ResolvedItem.Replace("[SERIES-ACTUAL-AWARD-DATE]", newValue4);
      ResolvedItem = ResolvedItem.Replace("[SERIES-FIRM-ROLE]", string.IsNullOrEmpty(sr.FirmRoleName) ? string.Empty : sr.FirmRoleName);
      ref string local7 = ref ResolvedItem;
      string str16 = ResolvedItem;
      nullable1 = sr.FirmLiability;
      Decimal num;
      string empty6;
      if (!nullable1.HasValue)
      {
        empty6 = string.Empty;
      }
      else
      {
        nullable1 = sr.FirmLiability;
        num = nullable1.Value;
        empty6 = num.ToString();
      }
      string str17 = str16.Replace("[SERIES-FIRM-LIABILITY]", empty6);
      local7 = str17;
      ref string local8 = ref ResolvedItem;
      string str18 = ResolvedItem;
      nullable1 = sr.FirmMgtFee;
      string empty7;
      if (!nullable1.HasValue)
      {
        empty7 = string.Empty;
      }
      else
      {
        nullable1 = sr.FirmMgtFee;
        num = nullable1.Value;
        empty7 = num.ToString();
      }
      string str19 = str18.Replace("[SERIES-FIRM-MGT-FEE]", empty7);
      local8 = str19;
      ref string local9 = ref ResolvedItem;
      string str20 = ResolvedItem;
      nullable1 = sr.SdcCredit;
      string empty8;
      if (!nullable1.HasValue)
      {
        empty8 = string.Empty;
      }
      else
      {
        nullable1 = sr.SdcCredit;
        num = nullable1.Value;
        empty8 = num.ToString();
      }
      string str21 = str20.Replace("[SERIES-SDC-CREDIT]", empty8);
      local9 = str21;
    }

    private void CreateHTMLRow(
      StringBuilder GridHTMLRow,
      string ResolvedItem,
      int count,
      int countHeader,
      int CellWidth,
      int TableWidth,
      string item)
    {
      if (countHeader == 0)
        GridHTMLRow.Append("<style>.tableStyle td{padding:2px; border:1px solid #000;}</style> <table class='tableStyle' style='border-collapse:collapse;width:" + TableWidth.ToString() + "%;margin-bottom:0;' border='1' cellspacing='0' cellpadding='0'>");
      if (count == 0)
        GridHTMLRow.Append("<tr><td  style='padding:2px 2px;width:" + CellWidth.ToString() + "%;'><b>" + this.GetEmailSeriesBodyLabel(item) + "</b></td>");
      GridHTMLRow.Append("<td  style='padding:2px 2px;width:" + CellWidth.ToString() + "%;'>" + ResolvedItem + "</td>");
    }

    private string AppendEnhancedRatings(
      string MoodyRatingST,
      string SPRatingST,
      string FitchRatingST,
      string KrollRatingST,
      Series sr)
    {
      string str = string.Format("{0}{1}{2}{3}", (object) MoodyRatingST, (object) SPRatingST, (object) FitchRatingST, (object) KrollRatingST);
      StringBuilder stringBuilder1 = new StringBuilder();
      StringBuilder stringBuilder2 = new StringBuilder();
      StringBuilder stringBuilder3 = new StringBuilder();
      if (sr.EnhancementRatingBySeries != null)
      {
        foreach (EnhancementRatingBySeries enhancementRatingBySeries in sr.EnhancementRatingBySeries)
        {
          if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementProvider))
          {
            if (stringBuilder1.Length > 0)
              stringBuilder1.Append("; ");
            stringBuilder1.Append(enhancementRatingBySeries.CreditEnhancementProvider);
          }
          if (!string.IsNullOrEmpty(enhancementRatingBySeries.CreditEnhancementType))
          {
            if (stringBuilder2.Length > 0)
              stringBuilder2.Append("; ");
            stringBuilder2.Append(enhancementRatingBySeries.CreditEnhancementType);
          }
          if (!string.IsNullOrEmpty(enhancementRatingBySeries.EnhancedRating))
          {
            if (stringBuilder3.Length > 0)
              stringBuilder3.Append("; ");
            stringBuilder3.Append(enhancementRatingBySeries.EnhancedRating);
          }
        }
      }
      return str;
    }

    private void GetDetailValue(
      CompetitiveIssue issue,
      string PlcHlder,
      ref string DetailValue,
      StringBuilder SeriesValue,
      ref int count,
      string DateFormat,
      string DateTimeFormat,
      string defaultTimeZone)
    {
      // ISSUE: reference to a compiler-generated method
      switch (\u003CPrivateImplementationDetails\u003E.ComputeStringHash(PlcHlder))
      {
        case 471950495:
          if (!(PlcHlder == "[CONC-SERIES-SDC-CREDIT]"))
            break;
          ref string local1 = ref DetailValue;
          Decimal? nullable1 = issue.IssueDetail.SDCCreditPerc;
          string empty1;
          if (!nullable1.HasValue)
          {
            empty1 = string.Empty;
          }
          else
          {
            nullable1 = issue.IssueDetail.SDCCreditPerc;
            empty1 = nullable1.Value.ToString();
          }
          local1 = empty1;
          foreach (Series series in issue.IssueDetail.Series)
          {
            nullable1 = issue.IssueDetail.SDCCreditPerc;
            if (nullable1.HasValue)
            {
              nullable1 = series.SdcCredit;
              if (nullable1.HasValue)
              {
                nullable1 = issue.IssueDetail.SDCCreditPerc;
                Decimal num1 = nullable1.Value;
                nullable1 = series.SdcCredit;
                Decimal num2 = nullable1.Value;
                if (!(num1 != num2))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            Decimal num;
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable1 = series.SdcCredit;
              string empty2;
              if (!nullable1.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable1 = series.SdcCredit;
                num = nullable1.Value;
                empty2 = num.ToString();
              }
              string str2 = "; " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable1 = series.SdcCredit;
              string empty2;
              if (!nullable1.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable1 = series.SdcCredit;
                num = nullable1.Value;
                empty2 = num.ToString();
              }
              string str2 = " " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 1233063450:
          if (!(PlcHlder == "[CONC-SERIES-PRICING-DATE]"))
            break;
          ref string local2 = ref DetailValue;
          DateTime? pricingDate = issue.IssueDetail.PricingDate;
          string str3;
          if (!pricingDate.HasValue)
          {
            str3 = "";
          }
          else
          {
            pricingDate = issue.IssueDetail.PricingDate;
            str3 = pricingDate.Value.ToString(DateFormat);
          }
          local2 = str3;
          foreach (Series series in issue.IssueDetail.Series)
          {
            pricingDate = issue.IssueDetail.PricingDate;
            DateTime dateTime;
            if (pricingDate.HasValue)
            {
              pricingDate = series.PricingDate;
              if (pricingDate.HasValue)
              {
                pricingDate = issue.IssueDetail.PricingDate;
                dateTime = pricingDate.Value;
                DateTime date1 = dateTime.Date;
                pricingDate = series.PricingDate;
                dateTime = pricingDate.Value;
                DateTime date2 = dateTime.Date;
                if (!(date1 != date2))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              pricingDate = series.PricingDate;
              string empty2;
              if (!pricingDate.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                pricingDate = series.PricingDate;
                dateTime = pricingDate.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = "; " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              pricingDate = series.PricingDate;
              string empty2;
              if (!pricingDate.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                pricingDate = series.PricingDate;
                dateTime = pricingDate.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = " " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 1365360433:
          if (!(PlcHlder == "[CONC-SERIES-ROP-DATE]"))
            break;
          ref string local3 = ref DetailValue;
          DateTime? nullable2 = issue.IssueDetail.ROPDate;
          string str4;
          if (!nullable2.HasValue)
          {
            str4 = "";
          }
          else
          {
            nullable2 = issue.IssueDetail.ROPDate;
            str4 = nullable2.Value.ToString(DateFormat);
          }
          local3 = str4;
          foreach (Series series in issue.IssueDetail.Series)
          {
            nullable2 = issue.IssueDetail.ROPDate;
            DateTime dateTime;
            if (nullable2.HasValue)
            {
              nullable2 = series.RetailOrderPeriodDate;
              if (nullable2.HasValue)
              {
                nullable2 = issue.IssueDetail.ROPDate;
                dateTime = nullable2.Value;
                DateTime date1 = dateTime.Date;
                nullable2 = series.RetailOrderPeriodDate;
                dateTime = nullable2.Value;
                DateTime date2 = dateTime.Date;
                if (!(date1 != date2))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable2 = series.RetailOrderPeriodDate;
              string empty2;
              if (!nullable2.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable2 = series.RetailOrderPeriodDate;
                dateTime = nullable2.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = "; " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable2 = series.RetailOrderPeriodDate;
              string empty2;
              if (!nullable2.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable2 = series.RetailOrderPeriodDate;
                dateTime = nullable2.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = " " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 1577796845:
          if (!(PlcHlder == "[CONC-SERIES-FIRM-MGT-FEE]"))
            break;
          ref string local4 = ref DetailValue;
          Decimal? nullable3 = issue.IssueDetail.FirmMgmtFeePerc;
          string str5;
          if (!nullable3.HasValue)
          {
            str5 = "";
          }
          else
          {
            nullable3 = issue.IssueDetail.FirmMgmtFeePerc;
            str5 = nullable3.Value.ToString();
          }
          local4 = str5;
          foreach (Series series in issue.IssueDetail.Series)
          {
            nullable3 = issue.IssueDetail.FirmMgmtFeePerc;
            if (nullable3.HasValue)
            {
              nullable3 = series.FirmMgtFee;
              if (nullable3.HasValue)
              {
                nullable3 = issue.IssueDetail.FirmMgmtFeePerc;
                Decimal num1 = nullable3.Value;
                nullable3 = series.FirmMgtFee;
                Decimal num2 = nullable3.Value;
                if (!(num1 != num2))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            Decimal num;
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable3 = series.FirmMgtFee;
              string empty2;
              if (!nullable3.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable3 = series.FirmMgtFee;
                num = nullable3.Value;
                empty2 = num.ToString();
              }
              string str2 = "; " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable3 = series.FirmMgtFee;
              string empty2;
              if (!nullable3.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable3 = series.FirmMgtFee;
                num = nullable3.Value;
                empty2 = num.ToString();
              }
              string str2 = " " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 1620828019:
          if (!(PlcHlder == "[CONC-SERIES-FIRM-LIABILITY]"))
            break;
          ref string local5 = ref DetailValue;
          Decimal? nullable4 = issue.IssueDetail.FirmLiabilityPerc;
          string str6;
          if (!nullable4.HasValue)
          {
            str6 = "";
          }
          else
          {
            nullable4 = issue.IssueDetail.FirmLiabilityPerc;
            str6 = nullable4.Value.ToString();
          }
          local5 = str6;
          foreach (Series series in issue.IssueDetail.Series)
          {
            nullable4 = issue.IssueDetail.FirmLiabilityPerc;
            if (nullable4.HasValue)
            {
              nullable4 = series.FirmLiability;
              if (nullable4.HasValue)
              {
                nullable4 = issue.IssueDetail.FirmLiabilityPerc;
                Decimal num1 = nullable4.Value;
                nullable4 = series.FirmLiability;
                Decimal num2 = nullable4.Value;
                if (!(num1 != num2))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            Decimal num;
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable4 = series.FirmLiability;
              string empty2;
              if (!nullable4.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable4 = series.FirmLiability;
                num = nullable4.Value;
                empty2 = num.ToString();
              }
              string str2 = "; " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              nullable4 = series.FirmLiability;
              string empty2;
              if (!nullable4.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable4 = series.FirmLiability;
                num = nullable4.Value;
                empty2 = num.ToString();
              }
              string str2 = " " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 2048272596:
          if (!(PlcHlder == "[CONC-SERIES-FIRM-ROLE]"))
            break;
          DetailValue = string.IsNullOrEmpty(issue.IssueDetail.FirmRoleValue) ? string.Empty : issue.IssueDetail.FirmRoleValue.ToString();
          foreach (Series series in issue.IssueDetail.Series)
          {
            if (issue.IssueDetail.FirmRoleValue == null || string.IsNullOrEmpty(series.FirmRoleName) || issue.IssueDetail.FirmRoleValue != series.FirmRoleName)
            {
              if (SeriesValue.Length <= 0)
                SeriesValue.Append(" (Except");
              if (count > 0)
                SeriesValue.Append("; " + (string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode) + ": " + (string.IsNullOrEmpty(series.FirmRoleName) ? string.Empty : series.FirmRoleName));
              else
                SeriesValue.Append(" " + (string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode) + ": " + (string.IsNullOrEmpty(series.FirmRoleName) ? string.Empty : series.FirmRoleName));
              ++count;
            }
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 2569023092:
          if (!(PlcHlder == "[CONC-SERIES-DATED-DATE]"))
            break;
          ref string local6 = ref DetailValue;
          DateTime? datedDate = issue.IssueDetail.DatedDate;
          string str7;
          if (!datedDate.HasValue)
          {
            str7 = "";
          }
          else
          {
            datedDate = issue.IssueDetail.DatedDate;
            str7 = datedDate.Value.ToString(DateFormat);
          }
          local6 = str7;
          foreach (Series series in issue.IssueDetail.Series)
          {
            datedDate = issue.IssueDetail.DatedDate;
            DateTime dateTime;
            if (datedDate.HasValue)
            {
              datedDate = series.DatedDate;
              if (datedDate.HasValue)
              {
                datedDate = issue.IssueDetail.DatedDate;
                dateTime = datedDate.Value;
                DateTime date1 = dateTime.Date;
                datedDate = series.DatedDate;
                dateTime = datedDate.Value;
                DateTime date2 = dateTime.Date;
                if (!(date1 != date2))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              datedDate = series.DatedDate;
              string empty2;
              if (!datedDate.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                datedDate = series.DatedDate;
                dateTime = datedDate.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = "; " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              datedDate = series.DatedDate;
              string empty2;
              if (!datedDate.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                datedDate = series.DatedDate;
                dateTime = datedDate.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = " " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 3516992630:
          if (!(PlcHlder == "[CONC-SERIES-ACTUAL-AWARD-DATE]"))
            break;
          ref string local7 = ref DetailValue;
          DateTime? nullable5 = issue.IssueDetail.ActualAwardDateTime;
          string empty3;
          if (!nullable5.HasValue)
          {
            empty3 = string.Empty;
          }
          else
          {
            nullable5 = issue.IssueDetail.ActualAwardDateTime;
            empty3 = nullable5.Value.ToString(DateTimeFormat);
          }
          string str8 = string.IsNullOrEmpty(issue.IssueDetail.ActualAwardDateTimeZone) ? defaultTimeZone : " " + issue.IssueDetail.ActualAwardDateTimeZone;
          string str9 = empty3 + str8;
          local7 = str9;
          foreach (Series series in issue.IssueDetail.Series)
          {
            nullable5 = issue.IssueDetail.ActualAwardDateTime;
            if (nullable5.HasValue)
            {
              nullable5 = series.ActualAwardDate;
              if (nullable5.HasValue)
              {
                nullable5 = issue.IssueDetail.ActualAwardDateTime;
                string str1 = nullable5.Value.ToString(DateTimeFormat);
                nullable5 = series.ActualAwardDate;
                string str2 = nullable5.Value.ToString(DateTimeFormat);
                if (!(str1 != str2) && !((string.IsNullOrEmpty(issue.IssueDetail.ActualAwardDateTimeZone) ? defaultTimeZone : issue.IssueDetail.ActualAwardDateTimeZone.ToUpper()) != (string.IsNullOrEmpty(series.ActualAwardDateTimeZone) ? defaultTimeZone : series.ActualAwardDateTimeZone.ToUpper())))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string[] strArray = new string[5]
              {
                "; ",
                string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode,
                ": ",
                null,
                null
              };
              nullable5 = series.ActualAwardDate;
              string empty2;
              if (!nullable5.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable5 = series.ActualAwardDate;
                empty2 = nullable5.Value.ToString(DateTimeFormat);
              }
              strArray[3] = empty2;
              strArray[4] = string.IsNullOrEmpty(series.ActualAwardDateTimeZone) ? defaultTimeZone : " " + series.ActualAwardDateTimeZone;
              string str1 = string.Concat(strArray);
              stringBuilder.Append(str1);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string[] strArray = new string[5]
              {
                " ",
                string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode,
                ": ",
                null,
                null
              };
              nullable5 = series.ActualAwardDate;
              string empty2;
              if (!nullable5.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                nullable5 = series.ActualAwardDate;
                empty2 = nullable5.Value.ToString(DateTimeFormat);
              }
              strArray[3] = empty2;
              strArray[4] = string.IsNullOrEmpty(series.ActualAwardDateTimeZone) ? defaultTimeZone : " " + series.ActualAwardDateTimeZone;
              string str1 = string.Concat(strArray);
              stringBuilder.Append(str1);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
        case 3598869056:
          if (!(PlcHlder == "[CONC-SERIES-DELIVERY-DATE]"))
            break;
          ref string local8 = ref DetailValue;
          DateTime? settlementDate = issue.IssueDetail.SettlementDate;
          string str10;
          if (!settlementDate.HasValue)
          {
            str10 = "";
          }
          else
          {
            settlementDate = issue.IssueDetail.SettlementDate;
            str10 = settlementDate.Value.ToString(DateFormat);
          }
          local8 = str10;
          foreach (Series series in issue.IssueDetail.Series)
          {
            settlementDate = issue.IssueDetail.SettlementDate;
            DateTime dateTime;
            if (settlementDate.HasValue)
            {
              settlementDate = series.SettlementDate;
              if (settlementDate.HasValue)
              {
                settlementDate = issue.IssueDetail.SettlementDate;
                dateTime = settlementDate.Value;
                DateTime date1 = dateTime.Date;
                settlementDate = series.SettlementDate;
                dateTime = settlementDate.Value;
                DateTime date2 = dateTime.Date;
                if (!(date1 != date2))
                  continue;
              }
            }
            if (SeriesValue.Length <= 0)
              SeriesValue.Append(" (Except");
            if (count > 0)
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              settlementDate = series.SettlementDate;
              string empty2;
              if (!settlementDate.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                settlementDate = series.SettlementDate;
                dateTime = settlementDate.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = "; " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            else
            {
              StringBuilder stringBuilder = SeriesValue;
              string str1 = string.IsNullOrEmpty(series.SeriesCode) ? string.Empty : series.SeriesCode;
              settlementDate = series.SettlementDate;
              string empty2;
              if (!settlementDate.HasValue)
              {
                empty2 = string.Empty;
              }
              else
              {
                settlementDate = series.SettlementDate;
                dateTime = settlementDate.Value;
                empty2 = dateTime.ToString(DateFormat);
              }
              string str2 = " " + str1 + ": " + empty2;
              stringBuilder.Append(str2);
            }
            ++count;
          }
          if (SeriesValue.Length > 0)
            SeriesValue.Append(")");
          DetailValue = (string.IsNullOrEmpty(DetailValue) ? string.Empty : DetailValue) + (string.IsNullOrEmpty(SeriesValue.ToString()) ? string.Empty : SeriesValue.ToString());
          break;
      }
    }

    private void FillInvestmentBankingDetails(
      string[] partnersEmailAddress,
      InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[0] = string.Format("{0}{1};", (object) partnersEmailAddress[0], (object) partner.Email);
      else if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("2", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[7] = string.Format("{0}{1};", (object) partnersEmailAddress[7], (object) partner.Email);
      else
        partnersEmailAddress[1] = string.Format("{0}{1};", (object) partnersEmailAddress[1], (object) partner.Email);
    }

    private void FillAnalystDetails(string[] partnersEmailAddress, InternalPartner partner)
    {
      if (!string.IsNullOrEmpty(partner.IsPrimary) && partner.IsPrimary.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        partnersEmailAddress[2] = string.Format("{0}{1};", (object) partnersEmailAddress[2], (object) partner.Email);
      else
        partnersEmailAddress[3] = string.Format("{0}{1};", (object) partnersEmailAddress[3], (object) partner.Email);
    }

    private void ApplyDelimiter(StringBuilder emailUpdated, string adr)
    {
      if (emailUpdated.Length > 0)
        emailUpdated.Append(";");
      emailUpdated.Append(adr);
    }
  }
}
