﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.IssueWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class IssueWorkflowFactory : IIssueWorkflowFactory
  {
    private readonly Workflow<IssueEnums.IssueStatus, Issue> defaultWorkflow;

    public IssueWorkflowFactory()
    {
      IssueState issueState1 = new IssueState();
      IssueState issueState2 = new IssueState();
      IssueState issueState3 = new IssueState();
      this.defaultWorkflow = new Workflow<IssueEnums.IssueStatus, Issue>((IEnumerable<Transition<IssueEnums.IssueStatus, Issue>>) new Transition<IssueEnums.IssueStatus, Issue>[60]
      {
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.open, IssueAction.SendForActivation, (IState<IssueEnums.IssueStatus, Issue>) issueState1.active),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.active, IssueAction.SendForLeadBankerReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.active, IssueAction.MarkCancelled, (IState<IssueEnums.IssueStatus, Issue>) issueState1.cancelled),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerUnderReview, IssueAction.MarkLeadBankerMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerUnderReview, IssueAction.MarkLeadBankerApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerMoreInfoNeeded, IssueAction.SendForLeadBankerReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerApproved, IssueAction.SendForMUCCReview, (IEnumerable<IState<IssueEnums.IssueStatus, Issue>>) new AtomicState<IssueEnums.IssueStatus, Issue>[4]
        {
          issueState1.complianceLegalUnderReview,
          issueState1.supervisoryPrincipalUnderReview,
          issueState1.managementUnderReview,
          issueState1.firmCreditUnderReview
        }),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.leadBankerApproved, IssueAction.SendForPrePricing, (IState<IssueEnums.IssueStatus, Issue>) issueState1.prePricing),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.compoundLeadBankerReview, IssueAction.MarkCancelled, (IState<IssueEnums.IssueStatus, Issue>) issueState1.cancelled),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.complianceLegalUnderReview, IssueAction.MarkComplianceLegalMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.complianceLegalMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.complianceLegalUnderReview, IssueAction.MarkComplianceLegalApproved, (IEnumerable<IState<IssueEnums.IssueStatus, Issue>>) new AtomicState<IssueEnums.IssueStatus, Issue>[1]
        {
          issueState1.complianceLegalApproved
        }),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.complianceLegalMoreInfoNeeded, IssueAction.SendForComplianceLegalReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.complianceLegalUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.supervisoryPrincipalUnderReview, IssueAction.MarkSupervisoryPrincipalMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.supervisoryPrincipalMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.supervisoryPrincipalUnderReview, IssueAction.MarkSupervisoryPrincipalApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.supervisoryPrincipalApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.supervisoryPrincipalMoreInfoNeeded, IssueAction.SendForSupervisoryPrincipalReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.supervisoryPrincipalUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.managementUnderReview, IssueAction.MarkManagementMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.managementMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.managementUnderReview, IssueAction.MarkManagementApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.managementApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.managementMoreInfoNeeded, IssueAction.SendForManagementReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.managementUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.firmCreditUnderReview, IssueAction.MarkFirmCreditMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.firmCreditMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.firmCreditUnderReview, IssueAction.MarkFirmCreditApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.firmCreditApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.firmCreditMoreInfoNeeded, IssueAction.SendForFirmCreditReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.firmCreditUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.parallelMUCCReview, IssueAction.MarkCancelled, (IState<IssueEnums.IssueStatus, Issue>) issueState1.cancelled),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.MUCCApproved, IssueAction.SendForPrePricing, (IState<IssueEnums.IssueStatus, Issue>) issueState1.prePricing),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.MUCCApproved, IssueAction.MarkCancelled, (IState<IssueEnums.IssueStatus, Issue>) issueState1.cancelled),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.prePricing, IssueAction.MarkTransactionPriced, (IState<IssueEnums.IssueStatus, Issue>) issueState1.transactionPriced),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.prePricing, IssueAction.SendForQuantitativeReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeUnderReview, IssueAction.MarkQuantitativeMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeUnderReview, IssueAction.MarkQuantitativeReviewed, (IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeReviewed),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeMoreInfoNeeded, IssueAction.SendForQuantitativeReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.quantitativeReviewed, IssueAction.MarkTransactionPriced, (IState<IssueEnums.IssueStatus, Issue>) issueState1.transactionPriced),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.compoundQuantitativeReview, IssueAction.MarkCancelled, (IState<IssueEnums.IssueStatus, Issue>) issueState1.cancelled),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.prePricing, IssueAction.MarkCancelled, (IState<IssueEnums.IssueStatus, Issue>) issueState1.cancelled),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.transactionPriced, IssueAction.SendForRegulatoryChecklistReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.transactionPriced, IssueAction.MarkCancelled, (IState<IssueEnums.IssueStatus, Issue>) issueState1.cancelled),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceUnderReview, IssueAction.MarkRegulatoryChecklistComplianceMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceUnderReview, IssueAction.MarkRegulatoryChecklistComplianceApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceMoreInfoNeeded, IssueAction.SendForRegulatoryChecklistComplianceReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistComplianceApproved, IssueAction.SendForPendingExpenseReconcile, (IState<IssueEnums.IssueStatus, Issue>) issueState1.pendingExpenseReconcile),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.pendingExpenseReconcile, IssueAction.SendForRegulatoryChecklistLeadBankerReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerUnderReview, IssueAction.MarkRegulatoryChecklistLeadBankerMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerUnderReview, IssueAction.MarkRegulatoryChecklistLeadBankerApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerMoreInfoNeeded, IssueAction.SendForRegulatoryChecklistLeadBankerReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistLeadBankerApproved, IssueAction.SendForRegulatoryChecklistSupervisoryPrincipalReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalUnderReview, IssueAction.MarkRegulatoryChecklistSupervisoryPrincipalMoreInfoNeeded, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalMoreInfoNeeded),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalUnderReview, IssueAction.MarkRegulatoryChecklistSupervisoryPrincipalApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalMoreInfoNeeded, IssueAction.SendForRegulatoryChecklistSupervisoryPrincipalReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalUnderReview),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.regulatoryChecklistSupervisoryPrincipalApproved, IssueAction.SendForOperationsReconcile, (IState<IssueEnums.IssueStatus, Issue>) issueState1.operationsReconcile),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.operationsReconcile, IssueAction.MarkTransactionComplete, (IState<IssueEnums.IssueStatus, Issue>) issueState1.complete),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.active, IssueAction.MarkOnHold, (IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.compoundLeadBankerReview, IssueAction.MarkOnHold, (IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, true),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.parallelMUCCReview, IssueAction.MarkOnHold, (IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, true),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.MUCCApproved, IssueAction.MarkOnHold, (IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, true),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.prePricing, IssueAction.MarkOnHold, (IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.compoundQuantitativeReview, IssueAction.MarkOnHold, (IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, true),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, IssueAction.MarkReActive, (IState<IssueEnums.IssueStatus, Issue>) issueState1.active),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, IssueAction.ReturnToLeadBankerReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.compoundLeadBankerReview, true),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, IssueAction.ReturnToMUCCReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.parallelMUCCReview, true),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, IssueAction.ReturnToMUCCApproved, (IState<IssueEnums.IssueStatus, Issue>) issueState1.MUCCApproved),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, IssueAction.ReturnToPrePricing, (IState<IssueEnums.IssueStatus, Issue>) issueState1.prePricing),
        new Transition<IssueEnums.IssueStatus, Issue>((IState<IssueEnums.IssueStatus, Issue>) issueState1.onHold, IssueAction.ReturnToQuantativeReview, (IState<IssueEnums.IssueStatus, Issue>) issueState1.compoundQuantitativeReview, true)
      });
    }

    public IWorkflow<IssueEnums.IssueStatus, Issue> GetWorkflow(
      string workflowType)
    {
      return (IWorkflow<IssueEnums.IssueStatus, Issue>) this.defaultWorkflow;
    }
  }
}
