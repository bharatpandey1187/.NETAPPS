﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Application.CompetitiveIssueWorkflowFactory
// Assembly: iMPACT.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 391F369C-7EC2-4D00-B28E-0AE281567FC4
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Application.dll

using IrisSoftware.Core.StateBasedWorkflow;
using IrisSoftware.iMPACT.Data;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Application
{
  public class CompetitiveIssueWorkflowFactory : ICompetitiveIssueWorkflowFactory
  {
    private readonly Workflow<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue> defaultWorkflow;

    public CompetitiveIssueWorkflowFactory()
    {
      CompetitiveIssueState competitiveIssueState = new CompetitiveIssueState();
      this.defaultWorkflow = new Workflow<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IEnumerable<Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>>) new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>[33]
      {
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.shortlisted, CompetitiveIssueAction.MarkOnHold, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold, CompetitiveIssueAction.ReturnToShortlisted, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.shortlisted),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.shortlisted, CompetitiveIssueAction.MarkCancelled, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.cancelled),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.shortlisted, CompetitiveIssueAction.MarkOpen, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.open),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.shortlisted, CompetitiveIssueAction.MarkCoManagerDeal, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.coManagerDeal),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.open, CompetitiveIssueAction.MarkOnHold, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold, CompetitiveIssueAction.ReturnToOpen, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.open),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.open, CompetitiveIssueAction.MarkTransactionPriced, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.transactionPriced),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.open, CompetitiveIssueAction.MarkCancelled, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.cancelled),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.transactionPriced, CompetitiveIssueAction.MarkOnHold, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold, CompetitiveIssueAction.ReturnToTransactionPriced, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.transactionPriced),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.transactionPriced, CompetitiveIssueAction.MarkSubmitted, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.submitted),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.transactionPriced, CompetitiveIssueAction.MarkCancelled, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.cancelled),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.submitted, CompetitiveIssueAction.MarkOnHold, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold, CompetitiveIssueAction.ReturnToSubmitted, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.submitted),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.submitted, CompetitiveIssueAction.MarkCancelled, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.cancelled),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.submitted, CompetitiveIssueAction.MarkWon, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.won),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.submitted, CompetitiveIssueAction.MarkLost, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.lost),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.won, CompetitiveIssueAction.MarkOnHold, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold, CompetitiveIssueAction.ReturnToWon, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.won),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.won, CompetitiveIssueAction.MarkActive, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.active),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.active, CompetitiveIssueAction.MarkOnHold, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.onHold, CompetitiveIssueAction.MarkReActive, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.active),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.active, CompetitiveIssueAction.MarkCancelled, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.cancelled),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.active, CompetitiveIssueAction.SendForRegulatoryAndDealChecklistReview, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorUnderReview),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorUnderReview, CompetitiveIssueAction.MarkTraderSupervisorMoreInfoNeeded, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorMoreInfoNeeded),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorUnderReview, CompetitiveIssueAction.MarkTraderSupervisorApproved, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorApproved),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorMoreInfoNeeded, CompetitiveIssueAction.SendForTraderSupervisorReview, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorUnderReview),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.traderSupervisorApproved, CompetitiveIssueAction.SendForSPReview, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spUnderReview),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spUnderReview, CompetitiveIssueAction.MarkSPMoreInfoNeeded, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spMoreInfoNeeded),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spUnderReview, CompetitiveIssueAction.MarkSPApproved, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spApproved),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spMoreInfoNeeded, CompetitiveIssueAction.SendForSPReview, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spUnderReview),
        new Transition<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>((IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.spApproved, CompetitiveIssueAction.MarkTransactionComplete, (IState<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) competitiveIssueState.complete)
      });
    }

    public IWorkflow<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue> GetWorkflow(
      string workflowType)
    {
      return (IWorkflow<CompetitiveIssueEnums.IssueStatus, CompetitiveIssue>) this.defaultWorkflow;
    }
  }
}
