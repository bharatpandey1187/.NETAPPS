﻿using System.Collections.Generic;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class Transition<TKey, TEntity>
    {
        public IState<TKey, TEntity> FromState { get; private set; }

        public string Action { get; private set; }

        public IEnumerable<IState<TKey, TEntity>> ToStates { get; private set; }

        public bool WithHistory { get; private set; }

        public Transition(
          IState<TKey, TEntity> fromState,
          string action,
          IState<TKey, TEntity> toState,
          bool withHistory)
          : this(fromState, action, (IEnumerable<IState<TKey, TEntity>>)new IState<TKey, TEntity>[1]
          {
        toState
          }, (withHistory ? 1 : 0) != 0)
        {
        }

        public Transition(
          IState<TKey, TEntity> fromState,
          string action,
          IState<TKey, TEntity> toState)
          : this(fromState, action, toState, false)
        {
        }

        public Transition(
          IState<TKey, TEntity> fromState,
          string action,
          IEnumerable<IState<TKey, TEntity>> toStates)
          : this(fromState, action, toStates, false)
        {
        }

        public Transition(
          IState<TKey, TEntity> fromState,
          string action,
          IEnumerable<IState<TKey, TEntity>> toStates,
          bool withHistory)
        {
            this.FromState = fromState;
            this.Action = action;
            this.ToStates = toStates;
            this.WithHistory = withHistory;
        }
    }
}
