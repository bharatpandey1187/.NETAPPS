﻿using System;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public static class EventHandlerExtension
    {
        public static void Raise<T>(this EventHandler<T> evt, object sender, T args) where T : EventArgs
        {
            if (evt == null)
                return;
            evt(sender, args);
        }
    }
}
