﻿using System.Collections.Generic;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class TransitionContext<TKey, TEntity>
    {
        public TransitionContext() => this.IntermediateStates = new HashSet<IState<TKey, TEntity>>();

        public Transition<TKey, TEntity> CurrentTransition { get; set; }

        public IEnumerable<TransitionResult<TKey, TEntity>> Results { get; set; }

        public IDictionary<TKey, IState<TKey, TEntity>> History { get; set; }

        public HashSet<IState<TKey, TEntity>> IntermediateStates { get; private set; }
    }
}
