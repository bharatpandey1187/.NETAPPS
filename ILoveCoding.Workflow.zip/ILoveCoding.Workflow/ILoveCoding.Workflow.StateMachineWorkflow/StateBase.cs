﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Practices.EnterpriseLibrary.Validation;
namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public abstract class StateBase<TKey, TEntity> : IState<TKey, TEntity>
    {
        public static readonly IGuard<TEntity> NoGuard = (IGuard<TEntity>)new MethodGuardAdapter<TEntity>((GuardMethod<TEntity>)((TEntity entity, out ValidationResults result) =>
        {
            result = (ValidationResults)null;
            return true;
        }));
        private readonly Dictionary<string, Transition<TKey, TEntity>> _transitions = new Dictionary<string, Transition<TKey, TEntity>>((IEqualityComparer<string>)StringComparer.OrdinalIgnoreCase);

        public IState<TKey, TEntity> Parent { get; set; }

        public TKey Key { get; private set; }

        public IGuard<TEntity> Guard { get; private set; }

        public event EventHandler<StateEnteredEventArgs<TKey, TEntity>> Entered;

        public event EventHandler<TransitioningEventArgs<TKey, TEntity>> Exiting;

        protected StateBase(TKey key)
          : this(key, StateBase<TKey, TEntity>.NoGuard)
        {
        }

        protected StateBase(TKey key, IGuard<TEntity> guard)
        {
            this.Key = key;
            this.Guard = guard ?? StateBase<TKey, TEntity>.NoGuard;
        }

        public virtual TransitionResult<TKey, TEntity> TryHandle(
          TEntity entity,
          string actionKey,
          TransitionContext<TKey, TEntity> context)
        {
            if (this.HandlesAction(actionKey))
                return this.Handle(entity, actionKey, context, (IState<TKey, TEntity>)this);
            if (this.Parent != null)
            {
                TransitionResult<TKey, TEntity> result = this.Parent.TryHandle(entity, actionKey, context);
                if (!result.IsSelfTransition())
                {
                    result.FromState = (IState<TKey, TEntity>)this;
                    if (result.Success)
                        this.OnExiting(result, context);
                    return result;
                }
            }
            return this.TransitionToSelf(entity);
        }

        public bool HandlesAction(string actionKey) => this._transitions.ContainsKey(actionKey);

        private TransitionResult<TKey, TEntity> TransitionToSelf(TEntity entity)
        {
            ValidationResults errors;
            if (!this.Guard.TrySatisfy(entity, out errors))
                return TransitionResult<TKey, TEntity>.CreateFailure((IState<TKey, TEntity>)this, errors);
            return new TransitionResult<TKey, TEntity>()
            {
                FromState = (IState<TKey, TEntity>)this,
                ResultingStates = (IEnumerable<IState<TKey, TEntity>>)new IState<TKey, TEntity>[1]
              {
          (IState<TKey, TEntity>) this
              },
                Status = ResultStatus.Completed,
                Success = true
            };
        }

        private TransitionResult<TKey, TEntity> Handle(
          TEntity entity,
          string actionKey,
          TransitionContext<TKey, TEntity> context,
          IState<TKey, TEntity> initialState)
        {
            Transition<TKey, TEntity> transition = this._transitions[actionKey];
            context.CurrentTransition = transition;
            IEnumerable<IState<TKey, TEntity>> list = (IEnumerable<IState<TKey, TEntity>>)transition.ToStates.SelectMany<IState<TKey, TEntity>, IState<TKey, TEntity>>((Func<IState<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(s => s.GetResultingStates(context))).ToList<IState<TKey, TEntity>>();
            HashSet<IState<TKey, TEntity>> stateSet = new HashSet<IState<TKey, TEntity>>();
            context.IntermediateStates.AddRange<IState<TKey, TEntity>>(list);
            foreach (IState<TKey, TEntity> state in list)
            {
                StateEnteredEventArgs<TKey, TEntity> args = new StateEnteredEventArgs<TKey, TEntity>()
                {
                    Context = context,
                    FromState = (IState<TKey, TEntity>)this,
                    TargetStates = list,
                    ResultingStates = new HashSet<IState<TKey, TEntity>>()
          {
            state
          }
                };
                state.Enter(args);
                stateSet.AddRange<IState<TKey, TEntity>>((IEnumerable<IState<TKey, TEntity>>)args.ResultingStates);
            }
            foreach (IState<TKey, TEntity> state in stateSet)
            {
                ValidationResults errors;
                if (!state.CanEnter(entity, out errors))
                    return TransitionResult<TKey, TEntity>.CreateFailure(initialState, errors);
            }
            TransitionResult<TKey, TEntity> result = new TransitionResult<TKey, TEntity>()
            {
                FromState = initialState,
                ResultingStates = (IEnumerable<IState<TKey, TEntity>>)stateSet.ToList<IState<TKey, TEntity>>(),
                Success = true,
                ActionState = (IState<TKey, TEntity>)this
            };
            this.OnExiting(result, context);
            context.IntermediateStates.RemoveRange<IState<TKey, TEntity>>(result.ResultingStates);
            if (result.Status == ResultStatus.Pending)
                result.Status = ResultStatus.Completed;
            return result;
        }

        protected void OnExiting(
          TransitionResult<TKey, TEntity> result,
          TransitionContext<TKey, TEntity> context)
        {
            this.OnExiting(new TransitioningEventArgs<TKey, TEntity>()
            {
                Transition = result,
                Context = context
            });
        }

        protected void OnExiting(TransitioningEventArgs<TKey, TEntity> args) => this.Exiting.Raise<TransitioningEventArgs<TKey, TEntity>>((object)this, args);

        public virtual void Enter(StateEnteredEventArgs<TKey, TEntity> args) => this.Entered.Raise<StateEnteredEventArgs<TKey, TEntity>>((object)this, args);

        public void AddTransition(Transition<TKey, TEntity> transition) => this._transitions.Add(transition.Action, transition);

        public virtual IEnumerable<string> GetAllowedActions() => this.Parent != null ? this._transitions.Keys.Union<string>(this.Parent.GetAllowedActions()) : (IEnumerable<string>)this._transitions.Keys;

        public virtual IEnumerable<IState<TKey, TEntity>> Ancestors()
        {
            if (this.Parent != null)
            {
                foreach (IState<TKey, TEntity> ancestor in this.Parent.Ancestors())
                    yield return ancestor;
            }
            yield return (IState<TKey, TEntity>)this;
        }

        public virtual bool CanEnter(TEntity entity, out ValidationResults errors) => this.Guard.TrySatisfy(entity, out errors);

        public abstract IEnumerable<IState<TKey, TEntity>> GetResultingStates(
          TransitionContext<TKey, TEntity> context);

        public abstract bool HasChild(IState<TKey, TEntity> state);

        public abstract IEnumerable<IState<TKey, TEntity>> Descendants();
    }
}
