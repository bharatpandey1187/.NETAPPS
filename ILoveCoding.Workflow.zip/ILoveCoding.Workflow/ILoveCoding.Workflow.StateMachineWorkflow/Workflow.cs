﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class Workflow<TKey, TEntity> : IWorkflow<TKey, TEntity>
    {
        private readonly Dictionary<TKey, IState<TKey, TEntity>> _knownStates = new Dictionary<TKey, IState<TKey, TEntity>>();

        public Workflow(IEnumerable<Transition<TKey, TEntity>> transitions)
        {
            this.Transitions = transitions;
            foreach (Transition<TKey, TEntity> transition in transitions)
            {
                IState<TKey, TEntity> fromState = transition.FromState;
                foreach (IState<TKey, TEntity> state in fromState.Ancestors().Union<IState<TKey, TEntity>>(transition.ToStates.SelectMany<IState<TKey, TEntity>, IState<TKey, TEntity>>((Func<IState<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(s => s.Ancestors()))).Union<IState<TKey, TEntity>>(fromState.Descendants()).Union<IState<TKey, TEntity>>(transition.ToStates.SelectMany<IState<TKey, TEntity>, IState<TKey, TEntity>>((Func<IState<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(s => s.Descendants()))))
                {
                    if (!this._knownStates.ContainsKey(state.Key))
                        this._knownStates.Add(state.Key, state);
                }
                fromState.AddTransition(transition);
            }
        }

        public bool TryHandle(
          TEntity entity,
          IEnumerable<TKey> stateKeys,
          string actionKey,
          IDictionary<TKey, TKey> history,
          out TransitionResult<TKey, TEntity> result)
        {
            TransitionContext<TKey, TEntity> context = new TransitionContext<TKey, TEntity>()
            {
                Results = (IEnumerable<TransitionResult<TKey, TEntity>>)stateKeys.Select<TKey, TransitionResult<TKey, TEntity>>((Func<TKey, TransitionResult<TKey, TEntity>>)(k =>
                {
                    IState<TKey, TEntity> knownState = this._knownStates[k];
                    return new TransitionResult<TKey, TEntity>()
                    {
                        FromState = knownState,
                        ResultingStates = (IEnumerable<IState<TKey, TEntity>>)new IState<TKey, TEntity>[1]
                      {
              knownState
                      },
                        Status = ResultStatus.Pending
                    };
                })).ToList<TransitionResult<TKey, TEntity>>(),
                History = (IDictionary<TKey, IState<TKey, TEntity>>)(history ?? (IDictionary<TKey, TKey>)new Dictionary<TKey, TKey>()).Select<KeyValuePair<TKey, TKey>, KeyValuePair<TKey, IState<TKey, TEntity>>>((Func<KeyValuePair<TKey, TKey>, KeyValuePair<TKey, IState<TKey, TEntity>>>)(kv => new KeyValuePair<TKey, IState<TKey, TEntity>>(kv.Key, this._knownStates[kv.Value]))).ToDictionary<KeyValuePair<TKey, IState<TKey, TEntity>>, TKey, IState<TKey, TEntity>>((Func<KeyValuePair<TKey, IState<TKey, TEntity>>, TKey>)(kv => kv.Key), (Func<KeyValuePair<TKey, IState<TKey, TEntity>>, IState<TKey, TEntity>>)(kv => kv.Value))
            };
            foreach (TransitionResult<TKey, TEntity> result1 in context.Results)
            {
                if (result1.Status == ResultStatus.Pending)
                {
                    TransitionResult<TKey, TEntity> transitionResult = result1.FromState.TryHandle(entity, actionKey, context);
                    if (transitionResult.Success)
                    {
                        result1.FromState = transitionResult.FromState;
                        result1.ResultingStates = transitionResult.ResultingStates;
                        result1.Errors = transitionResult.Errors;
                        result1.Status = transitionResult.Status;
                        result1.ActionState = transitionResult.ActionState;
                    }
                    else
                    {
                        result = transitionResult;
                        return false;
                    }
                }
            }
            IState<TKey, TEntity>[] array = context.Results.Where<TransitionResult<TKey, TEntity>>((Func<TransitionResult<TKey, TEntity>, bool>)(r => r.Status == ResultStatus.Completed)).SelectMany<TransitionResult<TKey, TEntity>, IState<TKey, TEntity>>((Func<TransitionResult<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(r => r.ResultingStates)).Distinct<IState<TKey, TEntity>>().ToArray<IState<TKey, TEntity>>();
            result = TransitionResult<TKey, TEntity>.CreateSuccess((IEnumerable<IState<TKey, TEntity>>)array, context.History, (IEnumerable<IState<TKey, TEntity>>)context.IntermediateStates);
            TransitionResult<TKey, TEntity> transitionResult1 = context.Results.Where<TransitionResult<TKey, TEntity>>((Func<TransitionResult<TKey, TEntity>, bool>)(r => r.Status == ResultStatus.Completed)).First<TransitionResult<TKey, TEntity>>();
            result.ActionState = transitionResult1.ActionState;
            result.FromState = transitionResult1.FromState;
            return true;
        }

        public IEnumerable<string> GetAllowedActions(IEnumerable<TKey> stateKey) => stateKey.SelectMany<TKey, string>((Func<TKey, IEnumerable<string>>)(k => this._knownStates[k].GetAllowedActions())).Distinct<string>();

        public IEnumerable<Transition<TKey, TEntity>> Transitions { get; set; }
    }
}
