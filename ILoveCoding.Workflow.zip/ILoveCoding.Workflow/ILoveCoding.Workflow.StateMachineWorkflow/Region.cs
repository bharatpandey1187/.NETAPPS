﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class Region<TKey, TEntity>
    {
        private readonly IState<TKey, TEntity>[] _states;
        private readonly IState<TKey, TEntity> _initial;
        private readonly HashSet<IState<TKey, TEntity>> _finalStates;

        public TKey Key { get; private set; }

        public bool TracksHistory { get; set; }

        public event EventHandler<StateEnteredEventArgs<TKey, TEntity>> Entered;

        public event EventHandler<TransitioningEventArgs<TKey, TEntity>> Finished;

        public event EventHandler<TransitioningEventArgs<TKey, TEntity>> Exiting;

        public Region(
          TKey key,
          IState<TKey, TEntity>[] states,
          IState<TKey, TEntity> initial,
          IEnumerable<IState<TKey, TEntity>> finalStates)
        {
            this.Key = key;
            this._states = states;
            foreach (IState<TKey, TEntity> state in states)
            {
                state.Entered += new EventHandler<StateEnteredEventArgs<TKey, TEntity>>(this.State_Entered);
                state.Exiting += new EventHandler<TransitioningEventArgs<TKey, TEntity>>(this.State_Exiting);
            }
            this._initial = initial;
            this._finalStates = new HashSet<IState<TKey, TEntity>>(finalStates);
        }

        private void State_Entered(object sender, StateEnteredEventArgs<TKey, TEntity> e)
        {
            if (this.HasChild(e.FromState))
                return;
            this.OnEntered(e);
        }

        private void OnEntered(StateEnteredEventArgs<TKey, TEntity> e) => this.Entered.Raise<StateEnteredEventArgs<TKey, TEntity>>((object)this, e);

        private void State_Exiting(object sender, TransitioningEventArgs<TKey, TEntity> e)
        {
            IState<TKey, TEntity> state = e.Transition.ResultingStates.First<IState<TKey, TEntity>>();
            if (this._finalStates.Contains(state))
            {
                if (this.TracksHistory)
                    e.Context.History.Remove(this.Key);
                this.Finished.Raise<TransitioningEventArgs<TKey, TEntity>>((object)this, e);
            }
            else
            {
                if (this.HasChild(state))
                    return;
                if (this.TracksHistory)
                    e.Context.History[this.Key] = sender as IState<TKey, TEntity>;
                this.Exiting.Raise<TransitioningEventArgs<TKey, TEntity>>((object)this, e);
            }
        }

        public bool HasChild(IState<TKey, TEntity> state) => ((IEnumerable<IState<TKey, TEntity>>)this._states).Any<IState<TKey, TEntity>>((Func<IState<TKey, TEntity>, bool>)(s => s.HasChild(state)));

        public IEnumerable<IState<TKey, TEntity>> Children => (IEnumerable<IState<TKey, TEntity>>)this._states;

        public IEnumerable<IState<TKey, TEntity>> GetResultingStates(
          TransitionContext<TKey, TEntity> context)
        {
            IState<TKey, TEntity> state1 = context.CurrentTransition.ToStates.Intersect<IState<TKey, TEntity>>(this.Children).FirstOrDefault<IState<TKey, TEntity>>();
            if (state1 != null)
                return state1.GetResultingStates(context);
            if (this.TracksHistory && context.History.ContainsKey(this.Key))
            {
                IState<TKey, TEntity> state2 = context.History[this.Key];
                context.History.Remove(this.Key);
                if (context.CurrentTransition.WithHistory)
                    return state2.GetResultingStates(context);
            }
            return this._initial.GetResultingStates(context);
        }

        public bool IsFinished(TransitionContext<TKey, TEntity> context)
        {
            foreach (TransitionResult<TKey, TEntity> result in context.Results)
            {
                if (this._finalStates.Contains(result.ResultingStates.FirstOrDefault<IState<TKey, TEntity>>()))
                    return true;
            }
            return false;
        }
    }
}
