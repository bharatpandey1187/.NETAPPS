﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Validation;
namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class MethodGuardAdapter<TEntity> : IGuard<TEntity>
    {
        private readonly GuardMethod<TEntity> _guard;

        public MethodGuardAdapter(GuardMethod<TEntity> guard) => this._guard = guard;

        public bool TrySatisfy(TEntity entity, out ValidationResults errors) => this._guard(entity, out errors);
    }
}
