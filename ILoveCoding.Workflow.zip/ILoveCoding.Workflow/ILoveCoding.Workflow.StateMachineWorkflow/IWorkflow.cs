﻿using System.Collections.Generic;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public interface IWorkflow<TKey, TEntity>
    {
        bool TryHandle(
          TEntity entity,
          IEnumerable<TKey> stateKeys,
          string actionKey,
          IDictionary<TKey, TKey> history,
          out TransitionResult<TKey, TEntity> transitionResult);

        IEnumerable<string> GetAllowedActions(IEnumerable<TKey> stateKey);

        IEnumerable<Transition<TKey, TEntity>> Transitions { get; set; }
    }
}
