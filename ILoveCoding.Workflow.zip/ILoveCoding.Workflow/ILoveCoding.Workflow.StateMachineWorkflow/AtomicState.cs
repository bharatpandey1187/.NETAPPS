﻿using System.Collections.Generic;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class AtomicState<TKey, TEntity> : StateBase<TKey, TEntity>
    {
        private static readonly IComparer<TKey> _comparer = (IComparer<TKey>)Comparer<TKey>.Default;

        public AtomicState(TKey key)
          : base(key)
        {
        }

        public AtomicState(TKey key, IGuard<TEntity> guard)
          : base(key, guard)
        {
        }

        public override IEnumerable<IState<TKey, TEntity>> GetResultingStates(
          TransitionContext<TKey, TEntity> context)
        {
            yield return (IState<TKey, TEntity>)this;
        }

        public override bool HasChild(IState<TKey, TEntity> state) => AtomicState<TKey, TEntity>._comparer.Compare(state.Key, this.Key) == 0;

        public override IEnumerable<IState<TKey, TEntity>> Descendants()
        {
            yield return (IState<TKey, TEntity>)this;
        }
    }
}
