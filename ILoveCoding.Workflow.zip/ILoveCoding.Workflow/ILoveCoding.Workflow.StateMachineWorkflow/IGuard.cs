﻿namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    using Microsoft.Practices.EnterpriseLibrary.Validation;
    public interface IGuard<TEntity>
    {
        bool TrySatisfy(TEntity entity, out ValidationResults errors);
    }
}
