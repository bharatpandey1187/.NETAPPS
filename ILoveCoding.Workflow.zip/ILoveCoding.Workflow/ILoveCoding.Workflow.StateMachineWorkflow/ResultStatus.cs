﻿namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public enum ResultStatus
    {
        Pending,
        Skipped,
        Completed,
    }

    public enum UnknownActionStrategy
    {
        TransitionToSelf,
        ThrowInvalidOperationException,
    }
}
