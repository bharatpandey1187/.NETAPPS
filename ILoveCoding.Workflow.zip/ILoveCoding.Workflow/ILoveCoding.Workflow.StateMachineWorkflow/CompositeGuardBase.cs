﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Validation;
namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public abstract class CompositeGuardBase<T> : IGuard<T>
    {
        private IEnumerable<IGuard<T>> Guards;

        protected CompositeGuardBase(IEnumerable<IGuard<T>> guards) => this.Guards = guards;

        public bool TrySatisfy(T entity, out ValidationResults errors)
        {
            if (this.InvokeComposedGuards(entity, out errors))
                errors = new ValidationResults();
            ValidationResults errors1;
            if (!this.TrySatisfyCurrent(entity, out errors1))
                errors.AddAllResults((IEnumerable<ValidationResult>)errors1);
            return errors.IsValid;
        }

        private bool InvokeComposedGuards(T entity, out ValidationResults errors)
        {
            errors = new ValidationResults();
            foreach (IGuard<T> guard in this.Guards)
            {
                ValidationResults errors1;
                if (!guard.TrySatisfy(entity, out errors1))
                    errors.AddAllResults((IEnumerable<ValidationResult>)errors1);
            }
            return errors.IsValid;
        }

        protected abstract bool TrySatisfyCurrent(T entity, out ValidationResults errors);
    }
}
