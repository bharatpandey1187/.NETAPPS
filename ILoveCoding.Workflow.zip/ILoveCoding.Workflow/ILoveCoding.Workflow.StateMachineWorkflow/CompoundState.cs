﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class CompoundState<TKey, TEntity> : StateBase<TKey, TEntity>
    {
        private readonly IEnumerable<IState<TKey, TEntity>> _states;
        private readonly IState<TKey, TEntity> _initial;

        public bool TracksHistory { get; set; }

        public CompoundState(
          TKey key,
          IEnumerable<IState<TKey, TEntity>> states,
          IState<TKey, TEntity> initial)
          : base(key, StateBase<TKey, TEntity>.NoGuard)
        {
            this._states = states;
            this._initial = initial;
            foreach (IState<TKey, TEntity> state in states)
            {
                state.Parent = (IState<TKey, TEntity>)this;
                state.Exiting += new EventHandler<TransitioningEventArgs<TKey, TEntity>>(this.State_Exiting);
                state.Entered += new EventHandler<StateEnteredEventArgs<TKey, TEntity>>(this.State_Entered);
            }
        }

        private void State_Entered(object sender, StateEnteredEventArgs<TKey, TEntity> e) => this.Enter(e);

        private void State_Exiting(object sender, TransitioningEventArgs<TKey, TEntity> e)
        {
            foreach (IState<TKey, TEntity> resultingState in e.Transition.ResultingStates)
            {
                if (!this.HasChild(resultingState))
                {
                    if (this.TracksHistory)
                        e.Context.History[this.Key] = sender as IState<TKey, TEntity>;
                    this.OnExiting(e);
                    break;
                }
            }
        }

        public override TransitionResult<TKey, TEntity> TryHandle(
          TEntity entity,
          string actionKey,
          TransitionContext<TKey, TEntity> context)
        {
            TransitionResult<TKey, TEntity> result = base.TryHandle(entity, actionKey, context);
            if (result.Success && this.HasChild(result.FromState) && !result.ResultingStates.All<IState<TKey, TEntity>>(new Func<IState<TKey, TEntity>, bool>(((StateBase<TKey, TEntity>)this).HasChild)))
                this.OnExiting(result, context);
            return result;
        }

        public override IEnumerable<IState<TKey, TEntity>> GetResultingStates(
          TransitionContext<TKey, TEntity> context)
        {
            if (this._initial == null)
                return Enumerable.Empty<IState<TKey, TEntity>>();
            IState<TKey, TEntity> state1 = context.CurrentTransition.ToStates.Intersect<IState<TKey, TEntity>>(this._states).FirstOrDefault<IState<TKey, TEntity>>();
            if (state1 != null)
                return state1.GetResultingStates(context);
            if (this.TracksHistory && context.History.ContainsKey(this.Key))
            {
                IState<TKey, TEntity> state2 = context.History[this.Key];
                context.History.Remove(this.Key);
                if (context.CurrentTransition.WithHistory)
                    return state2.GetResultingStates(context);
            }
            return this._initial.GetResultingStates(context);
        }

        public override bool HasChild(IState<TKey, TEntity> state) => this._states.Any<IState<TKey, TEntity>>((Func<IState<TKey, TEntity>, bool>)(s => s.HasChild(state)));

        public override IEnumerable<IState<TKey, TEntity>> Descendants() => this._states.SelectMany<IState<TKey, TEntity>, IState<TKey, TEntity>>((Func<IState<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(s => s.Descendants()));
    }
}
