﻿using System;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class TransitioningEventArgs<TKey, TEntity> : EventArgs
    {
        public TransitionResult<TKey, TEntity> Transition { get; set; }

        public TransitionContext<TKey, TEntity> Context { get; set; }
    }
}
