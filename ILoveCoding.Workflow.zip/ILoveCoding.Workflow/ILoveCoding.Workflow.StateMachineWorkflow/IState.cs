﻿using System;
using System.Collections.Generic;
using Microsoft.Practices.EnterpriseLibrary.Validation;
namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public interface IState<TKey, TEntity>
    {
        TKey Key { get; }

        IGuard<TEntity> Guard { get; }

        IState<TKey, TEntity> Parent { get; set; }

        TransitionResult<TKey, TEntity> TryHandle(
          TEntity entity,
          string actionKey,
          TransitionContext<TKey, TEntity> context);

        void AddTransition(Transition<TKey, TEntity> transition);

        IEnumerable<string> GetAllowedActions();

        IEnumerable<IState<TKey, TEntity>> GetResultingStates(
          TransitionContext<TKey, TEntity> context);

        void Enter(StateEnteredEventArgs<TKey, TEntity> args);

        bool HasChild(IState<TKey, TEntity> state);

        bool HandlesAction(string actionKey);

        IEnumerable<IState<TKey, TEntity>> Ancestors();

        IEnumerable<IState<TKey, TEntity>> Descendants();

        event EventHandler<StateEnteredEventArgs<TKey, TEntity>> Entered;

        event EventHandler<TransitioningEventArgs<TKey, TEntity>> Exiting;

        bool CanEnter(TEntity entity, out ValidationResults errors);
    }
}
