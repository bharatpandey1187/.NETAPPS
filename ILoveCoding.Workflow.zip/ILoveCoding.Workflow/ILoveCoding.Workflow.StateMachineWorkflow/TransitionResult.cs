﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Practices.EnterpriseLibrary.Validation;
namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class TransitionResult<TKey, TEntity>
    {
        public IState<TKey, TEntity> FromState { get; set; }

        public ResultStatus Status { get; set; }

        public IEnumerable<IState<TKey, TEntity>> ResultingStates { get; set; }

        public ValidationResults Errors { get; set; }

        public bool Success { get; set; }

        public IDictionary<TKey, IState<TKey, TEntity>> History { get; set; }

        public IEnumerable<IState<TKey, TEntity>> IntermediateStates { get; set; }

        public IState<TKey, TEntity> ActionState { get; set; }

        public static TransitionResult<TKey, TEntity> CreateSuccess(
          IEnumerable<IState<TKey, TEntity>> state)
        {
            return new TransitionResult<TKey, TEntity>()
            {
                ResultingStates = state,
                Status = ResultStatus.Completed,
                Success = true
            };
        }

        public static TransitionResult<TKey, TEntity> CreateFailure(
          IState<TKey, TEntity> state,
          ValidationResults errors)
        {
            return new TransitionResult<TKey, TEntity>()
            {
                ResultingStates = (IEnumerable<IState<TKey, TEntity>>)((IEnumerable<IState<TKey, TEntity>>)new IState<TKey, TEntity>[1]
              {
          state
              }).ToList<IState<TKey, TEntity>>(),
                Errors = errors,
                Success = false,
                Status = ResultStatus.Completed
            };
        }

        public bool IsSelfTransition() => this.ResultingStates != null && this.ResultingStates.Count<IState<TKey, TEntity>>() == 1 && this.FromState == this.ResultingStates.First<IState<TKey, TEntity>>();

        public static TransitionResult<TKey, TEntity> CreateSuccess(
          IEnumerable<IState<TKey, TEntity>> states,
          IDictionary<TKey, IState<TKey, TEntity>> history,
          IEnumerable<IState<TKey, TEntity>> intermediateStates)
        {
            TransitionResult<TKey, TEntity> success = TransitionResult<TKey, TEntity>.CreateSuccess(states);
            success.History = history;
            success.IntermediateStates = intermediateStates;
            return success;
        }
    }
}
