﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class ParallelState<TKey, TEntity> : StateBase<TKey, TEntity>
    {
        private readonly IEnumerable<Region<TKey, TEntity>> _regions;
        private readonly IState<TKey, TEntity> _targetState;

        public ParallelState(
          TKey key,
          IEnumerable<Region<TKey, TEntity>> regions,
          IState<TKey, TEntity> targetState)
          : base(key, StateBase<TKey, TEntity>.NoGuard)
        {
            this._regions = regions;
            this._targetState = targetState;
            foreach (Region<TKey, TEntity> region in regions)
            {
                foreach (IState<TKey, TEntity> child in region.Children)
                    child.Parent = (IState<TKey, TEntity>)this;
                region.Entered += new EventHandler<StateEnteredEventArgs<TKey, TEntity>>(this.Region_Entered);
                region.Finished += new EventHandler<TransitioningEventArgs<TKey, TEntity>>(this.Region_Finished);
                region.Exiting += new EventHandler<TransitioningEventArgs<TKey, TEntity>>(this.Region_Exiting);
            }
        }

        private void Region_Entered(object sender, StateEnteredEventArgs<TKey, TEntity> e)
        {
            Region<TKey, TEntity> region1 = (Region<TKey, TEntity>)sender;
            foreach (Region<TKey, TEntity> region2 in this._regions)
            {
                if (region2 != region1 && !e.TargetStates.Any<IState<TKey, TEntity>>(new Func<IState<TKey, TEntity>, bool>(region2.HasChild)))
                    e.ResultingStates.AddRange<IState<TKey, TEntity>>(region2.GetResultingStates(e.Context));
            }
            this.Enter(e);
        }

        private void Region_Exiting(object sender, TransitioningEventArgs<TKey, TEntity> e)
        {
            this.MarkRangeTransitionsSkipped((Region<TKey, TEntity>)sender, e.Context);
            this.OnExiting(e);
        }

        private void MarkRangeTransitionsSkipped(
          Region<TKey, TEntity> skipRegion,
          TransitionContext<TKey, TEntity> context)
        {
            foreach (Region<TKey, TEntity> region in this._regions.Where<Region<TKey, TEntity>>((Func<Region<TKey, TEntity>, bool>)(r => r != skipRegion)))
            {
                foreach (TransitionResult<TKey, TEntity> result in context.Results)
                {
                    if (region.HasChild(result.FromState))
                    {
                        if (region.TracksHistory)
                            context.History[region.Key] = result.FromState;
                        result.Status = ResultStatus.Skipped;
                    }
                }
            }
        }

        private void Region_Finished(object sender, TransitioningEventArgs<TKey, TEntity> e)
        {
            Region<TKey, TEntity> finishedRegion = (Region<TKey, TEntity>)sender;
            if (!this._regions.Where<Region<TKey, TEntity>>((Func<Region<TKey, TEntity>, bool>)(r => r != finishedRegion)).Any<Region<TKey, TEntity>>((Func<Region<TKey, TEntity>, bool>)(r => !r.IsFinished(e.Context))))
            {
                e.Transition.ResultingStates = (IEnumerable<IState<TKey, TEntity>>)this._targetState.GetResultingStates(e.Context).ToList<IState<TKey, TEntity>>();
                this.MarkRangeTransitionsSkipped(finishedRegion, e.Context);
            }
            this.OnExiting(e);
        }

        public override IEnumerable<IState<TKey, TEntity>> GetResultingStates(
          TransitionContext<TKey, TEntity> context)
        {
            return this._regions.SelectMany<Region<TKey, TEntity>, IState<TKey, TEntity>>((Func<Region<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(r => r.GetResultingStates(context)));
        }

        public override bool HasChild(IState<TKey, TEntity> state) => this._regions.Any<Region<TKey, TEntity>>((Func<Region<TKey, TEntity>, bool>)(r => r.HasChild(state)));

        public override IEnumerable<IState<TKey, TEntity>> Descendants() => this._regions.SelectMany<Region<TKey, TEntity>, IState<TKey, TEntity>>((Func<Region<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(r => r.Children.SelectMany<IState<TKey, TEntity>, IState<TKey, TEntity>>((Func<IState<TKey, TEntity>, IEnumerable<IState<TKey, TEntity>>>)(s => s.Descendants()))));
    }
}
