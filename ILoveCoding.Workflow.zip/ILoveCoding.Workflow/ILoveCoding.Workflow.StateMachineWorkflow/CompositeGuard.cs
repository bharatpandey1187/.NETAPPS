﻿using System.Collections.Generic;
using Microsoft.Practices.EnterpriseLibrary.Validation;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class CompositeGuard<T> : CompositeGuardBase<T>
    {
        public CompositeGuard(IEnumerable<IGuard<T>> guards)
          : base(guards)
        {
        }

        protected override bool TrySatisfyCurrent(T entity, out ValidationResults errors)
        {
            errors = (ValidationResults)null;
            return true;
        }
    }
}
