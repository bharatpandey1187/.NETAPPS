﻿using System;
using System.Collections.Generic;

namespace ILoveCoding.Workflow.StateMachineWorkflow
{
    public class StateEnteredEventArgs<TKey, TEntity> : EventArgs
    {
        public IState<TKey, TEntity> FromState { get; set; }

        public TransitionContext<TKey, TEntity> Context { get; set; }

        public HashSet<IState<TKey, TEntity>> ResultingStates { get; set; }

        public IEnumerable<IState<TKey, TEntity>> TargetStates { get; set; }
    }
}
