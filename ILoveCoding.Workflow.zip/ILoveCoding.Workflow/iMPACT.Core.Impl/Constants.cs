﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Constants
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using System.Runtime.InteropServices;

namespace IrisSoftware.iMPACT.Core.Impl
{
  public class Constants
  {
    public const string StorageKey_Sharepoint = "SharePoint";
    public const string StorageKey_FileNet_WORM = "FileNet-WORM";
    public const string StorageKey_FileNet_NonWORM = "FileNet-NonWORM";
    public const string TypeValue_Sharepoint = "SharePoint";
    public const string TypeValue_FileNet = "FileNet";
    public const string Column_StorageKey = "StorageKey";
    public const string Column_SettingKey = "SettingKey";
    public const string Column_SettingValue = "SettingValue";
    public const string TypeSettingKey = "Type";

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct SharepointSettingKeys
    {
      public const string Type = "Type";
      public const string OpportunityDocLibPrimaryAbsURL = "OpportunityDocLibPrimaryAbsURL";
      public const string RfpDocLibPrimaryAbsURL = "RfpDocLibPrimaryAbsURL";
      public const string IssueDocLibPrimaryAbsURL = "IssueDocLibPrimaryAbsURL";
      public const string VersionHistoryUrl = "VersionHistoryUrl";
    }
  }
}
