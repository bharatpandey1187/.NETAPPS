﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.AssemblyInitializer
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.iMPACT.Core.Impl.Security;
using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.Unity;
using System.Reflection;

namespace IrisSoftware.iMPACT.Core.Impl
{
  public class AssemblyInitializer : IAssemblyInitializer
  {
    public void Initialize(IUnityContainer container) => new ExportAttributeBasedContainerConfigurator().ConfigureContainer(container, Assembly.GetExecutingAssembly());

    public void InitializePerRequest(IUnityContainer container)
    {
      container.RegisterType<IUser, User>((LifetimeManager) new ContainerControlledLifetimeManager());
      container.RegisterType<IMembershipProvider, SharePointADMembershipProvider>((LifetimeManager) new ContainerControlledLifetimeManager());
    }
  }
}
