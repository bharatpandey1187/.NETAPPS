﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Logging.SPDiagnosticsServiceLogger
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.Core.Logging;
using Microsoft.SharePoint.Administration;
using System.Collections.Generic;
using System.Diagnostics;

namespace IrisSoftware.iMPACT.Core.Impl.Logging
{
  public class SPDiagnosticsServiceLogger : SPDiagnosticsServiceBase, ILogWriter
  {
    private const string DiagnosticAreaName = "iMPACT";
    private IEnumerable<string> diagnosticsCategories;

    public TraceEventType LogLevel { get; set; }

    public SPDiagnosticsServiceLogger(IEnumerable<string> diagnosticsCategories)
    {
      this.\u002Ector("iMPACT", SPFarm.get_Local());
      this.diagnosticsCategories = diagnosticsCategories;
    }

    public void Write(LogEntry entry)
    {
      if ((this.LogLevel & entry.EntryType) != this.LogLevel)
        return;
      this.WriteTrace(0U, this.get_Areas().get_Item("iMPACT").get_Categories().get_Item(entry.Category), entry.EntryType.ToTraceSeverity(), entry.Message, new object[0]);
    }

    protected virtual IEnumerable<SPDiagnosticsArea> ProvideAreas() => (IEnumerable<SPDiagnosticsArea>) new SPDiagnosticsServiceLogger.\u003CProvideAreas\u003Ed__8(-2)
    {
      \u003C\u003E4__this = this
    };

    private IEnumerable<SPDiagnosticsCategory> GetDiagnosticsCategories() => (IEnumerable<SPDiagnosticsCategory>) new SPDiagnosticsServiceLogger.\u003CGetDiagnosticsCategories\u003Ed__9(-2)
    {
      \u003C\u003E4__this = this
    };
  }
}
