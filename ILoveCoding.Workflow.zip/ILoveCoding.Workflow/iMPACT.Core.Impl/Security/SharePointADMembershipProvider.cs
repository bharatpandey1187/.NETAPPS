﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Security.SharePointADMembershipProvider
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.iMPACT.Core.Security;
using Microsoft.SharePoint;
using System;

namespace IrisSoftware.iMPACT.Core.Impl.Security
{
  public class SharePointADMembershipProvider : IMembershipProvider
  {
    private IMembershipService primaryMembershipService;
    private IMembershipService retentionMembershipService;
    private bool disposed;

    public IMembershipService GetPrimaryMembershipService()
    {
      if (this.disposed)
        throw new ObjectDisposedException(nameof (SharePointADMembershipProvider));
      if (this.primaryMembershipService == null)
        this.primaryMembershipService = (IMembershipService) new SharePointADMembershipService();
      return this.primaryMembershipService;
    }

    public IMembershipService GetRetentionMembershipService(string url)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointADMembershipProvider.\u003C\u003Ec__DisplayClass4_0 cDisplayClass40 = new SharePointADMembershipProvider.\u003C\u003Ec__DisplayClass4_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass40.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass40.url = url;
      if (this.disposed)
        throw new ObjectDisposedException(nameof (SharePointADMembershipProvider));
      if (this.retentionMembershipService == null)
      {
        // ISSUE: method pointer
        SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass40, __methodptr(\u003CGetRetentionMembershipService\u003Eb__0)));
      }
      return this.retentionMembershipService;
    }
  }
}
