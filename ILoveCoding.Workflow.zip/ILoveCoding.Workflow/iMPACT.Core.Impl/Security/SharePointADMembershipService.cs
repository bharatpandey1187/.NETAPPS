﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Security.SharePointADMembershipService
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.Text;

namespace IrisSoftware.iMPACT.Core.Impl.Security
{
  [Export(typeof (IMembershipService))]
  public class SharePointADMembershipService : IMembershipService, IDisposable
  {
    private SPWeb web;
    private bool disposable;

    private SPSite Site { get; set; }

    [InjectionConstructor]
    public SharePointADMembershipService()
      : this(SPContext.get_Current().get_Site(), SPContext.get_Current().get_Web())
    {
    }

    public SharePointADMembershipService(SPSite site, SPWeb web)
    {
      this.Site = site;
      this.web = web;
      this.disposable = true;
    }

    public IUser CreateUserIfNotExists(string loginName)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointADMembershipService.\u003C\u003Ec__DisplayClass8_0 cDisplayClass80 = new SharePointADMembershipService.\u003C\u003Ec__DisplayClass8_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass80.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass80.loginName = loginName;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass80.user = (IUser) null;
      try
      {
        // ISSUE: method pointer
        SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass80, __methodptr(\u003CCreateUserIfNotExists\u003Eb__0)));
        // ISSUE: reference to a compiler-generated field
        return cDisplayClass80.user;
      }
      catch (SPException ex)
      {
        throw new InvalidUserException(((Exception) ex).Message, (Exception) ex);
      }
    }

    public IGroup CreateGroupIfNotExists(string groupName, string loginName)
    {
      SPUser spUser = this.GetSPUser(this.Site.OpenWeb(), loginName);
      SPMember spMember = spUser != null ? (SPMember) spUser : throw new Exception(string.Format("Invalid login name: {0}", (object) loginName));
      return this.CreateGroup(groupName, spMember, spUser, this.GetDescription(groupName, spUser));
    }

    public void DeleteGroup(string groupName)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointADMembershipService.\u003C\u003Ec__DisplayClass10_0 cDisplayClass100 = new SharePointADMembershipService.\u003C\u003Ec__DisplayClass10_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass100.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass100.groupName = groupName;
      try
      {
        // ISSUE: method pointer
        SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass100, __methodptr(\u003CDeleteGroup\u003Eb__0)));
      }
      catch (SPException ex)
      {
        throw new InvalidGroupException(((Exception) ex).Message, (Exception) ex);
      }
    }

    public List<IUser> GetAllUsers()
    {
      List<IUser> userList = new List<IUser>();
      using (SPWeb spWeb = this.Site.OpenWeb())
        return this.PopulateUsers(spWeb.get_SiteUsers());
    }

    public string GetEmailIds(int[] principalIds)
    {
      StringBuilder stringBuilder = new StringBuilder();
      using (SPWeb spWeb = this.Site.OpenWeb())
      {
        foreach (int principalId in principalIds)
        {
          SPUser spUser = (SPUser) null;
          SPGroup spGroup = (SPGroup) null;
          try
          {
            spUser = spWeb.get_SiteUsers().GetByID(principalId);
          }
          catch
          {
          }
          if (spUser != null)
          {
            stringBuilder.AppendFormat("{0};", (object) spUser.get_Email());
          }
          else
          {
            try
            {
              spGroup = spWeb.get_SiteGroups().GetByID(principalId);
            }
            catch
            {
            }
            if (spGroup != null)
            {
              foreach (User user in this.GetAllUsersInGroup(((SPPrincipal) spGroup).get_Name()))
                stringBuilder.AppendFormat("{0};", (object) user.Email);
            }
          }
        }
      }
      return stringBuilder.ToString();
    }

    public List<IUser> GetAllUsersInGroup(string groupName)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointADMembershipService.\u003C\u003Ec__DisplayClass13_0 cDisplayClass130 = new SharePointADMembershipService.\u003C\u003Ec__DisplayClass13_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass130.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass130.groupName = groupName;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass130.users = new List<IUser>();
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass130, __methodptr(\u003CGetAllUsersInGroup\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass130.users;
    }

    public List<Group> GetAllGroups()
    {
      List<Group> groupList = new List<Group>();
      using (SPWeb spWeb = this.Site.OpenWeb())
      {
        IEnumerator enumerator = ((SPBaseCollection) spWeb.get_SiteGroups()).GetEnumerator();
        try
        {
          while (enumerator.MoveNext())
          {
            SPGroup current = (SPGroup) enumerator.Current;
            groupList.Add(new Group()
            {
              Id = ((SPMember) current).get_ID(),
              Name = ((SPPrincipal) current).get_Name(),
              Description = current.get_Description()
            });
          }
        }
        finally
        {
          if (enumerator is IDisposable disposable)
            disposable.Dispose();
        }
      }
      return groupList;
    }

    private List<IUser> PopulateUsers(SPUserCollection spUserCollection)
    {
      List<IUser> userList = new List<IUser>();
      IEnumerator enumerator = ((SPBaseCollection) spUserCollection).GetEnumerator();
      try
      {
        while (enumerator.MoveNext())
        {
          IUser user = (IUser) new User((SPUser) enumerator.Current);
          userList.Add(user);
        }
      }
      finally
      {
        if (enumerator is IDisposable disposable)
          disposable.Dispose();
      }
      return userList;
    }

    public void AddGroupMember(string groupName, string loginName)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointADMembershipService.\u003C\u003Ec__DisplayClass16_0 cDisplayClass160 = new SharePointADMembershipService.\u003C\u003Ec__DisplayClass16_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass160.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass160.loginName = loginName;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass160.groupName = groupName;
      IGroup group = (IGroup) null;
      // ISSUE: reference to a compiler-generated field
      if (!this.IsGroupExists(cDisplayClass160.groupName, out group))
      {
        // ISSUE: reference to a compiler-generated field
        throw new Exception(string.Format("Group Name: {0} does not exists", (object) cDisplayClass160.groupName));
      }
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass160, __methodptr(\u003CAddGroupMember\u003Eb__0)));
    }

    public bool DoesUserExistInAD(string userName)
    {
      using (PrincipalContext context = new PrincipalContext(ContextType.Domain, userName.Split(new string[1]
      {
        "\\"
      }, StringSplitOptions.None)[0]))
      {
        using (UserPrincipal byIdentity = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, userName))
          return byIdentity != null;
      }
    }

    public void RemoveGroupMember(string groupName, string loginName)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointADMembershipService.\u003C\u003Ec__DisplayClass18_0 cDisplayClass180 = new SharePointADMembershipService.\u003C\u003Ec__DisplayClass18_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass180.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass180.loginName = loginName;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass180.groupName = groupName;
      IGroup group = (IGroup) null;
      // ISSUE: reference to a compiler-generated field
      if (!this.IsGroupExists(cDisplayClass180.groupName, out group))
      {
        // ISSUE: reference to a compiler-generated field
        throw new Exception(string.Format("Group Name: {0} does not exists", (object) cDisplayClass180.groupName));
      }
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass180, __methodptr(\u003CRemoveGroupMember\u003Eb__0)));
    }

    public void DeleteGroupMember(string groupName, string loginName) => SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) new SharePointADMembershipService.\u003C\u003Ec__DisplayClass19_0()
    {
      \u003C\u003E4__this = this,
      loginName = loginName,
      groupName = groupName,
      allowUnsafeUpdate = false
    }, __methodptr(\u003CDeleteGroupMember\u003Eb__0)));

    public bool IsGroupExists(string groupName, out IGroup group)
    {
      bool flag = false;
      group = (IGroup) new Group();
      try
      {
        using (SPWeb spWeb = this.Site.OpenWeb())
        {
          SPGroup spGroup = spWeb.get_SiteGroups().get_Item(groupName);
          flag = true;
          group.Name = ((SPPrincipal) spGroup).get_Name();
          group.Id = ((SPMember) spGroup).get_ID();
          group.Description = spGroup.get_Description();
        }
      }
      catch
      {
      }
      return flag;
    }

    public bool IsUserExists(string loginName)
    {
      bool flag = false;
      try
      {
        using (SPWeb spWeb = this.Site.OpenWeb())
        {
          spWeb.get_SiteUsers().get_Item(loginName);
          flag = true;
        }
      }
      catch
      {
      }
      return flag;
    }

    public IUser GetUser(string loginName)
    {
      IUser user = (IUser) null;
      bool flag = false;
      try
      {
        using (SPWeb spWeb = this.Site.OpenWeb())
        {
          flag = spWeb.get_AllowUnsafeUpdates();
          spWeb.set_AllowUnsafeUpdates(true);
          user = (IUser) new User(spWeb.EnsureUser(loginName));
        }
      }
      catch (SPException ex)
      {
        if (ex.get_ErrorCode() != -2146232832)
          throw new InvalidUserException(((Exception) ex).Message, (Exception) ex);
      }
      finally
      {
        this.web.set_AllowUnsafeUpdates(flag);
      }
      return user;
    }

    public IUser GetUser(int principalID)
    {
      try
      {
        using (SPWeb spWeb = this.Site.OpenWeb())
          return (IUser) new User(spWeb.get_AllUsers().GetByID(principalID));
      }
      catch (SPException ex)
      {
        throw new InvalidUserException(((Exception) ex).Message, (Exception) ex);
      }
    }

    private string GetDescription(string groupName, SPUser oUser)
    {
      int num = ((SPPrincipal) oUser).get_LoginName().LastIndexOf('\\');
      return string.Format("Group [{0}] created for [{1}]", (object) groupName, (object) ((SPPrincipal) oUser).get_LoginName().Substring(num + 1));
    }

    private IGroup CreateGroup(
      string groupName,
      SPMember spMember,
      SPUser spUser,
      string descriptionOfGroup)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointADMembershipService.\u003C\u003Ec__DisplayClass25_0 cDisplayClass250 = new SharePointADMembershipService.\u003C\u003Ec__DisplayClass25_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass250.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass250.groupName = groupName;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass250.spMember = spMember;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass250.spUser = spUser;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass250.descriptionOfGroup = descriptionOfGroup;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass250.group = (IGroup) null;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!this.IsGroupExists(cDisplayClass250.groupName, out cDisplayClass250.group))
      {
        // ISSUE: method pointer
        SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass250, __methodptr(\u003CCreateGroup\u003Eb__0)));
      }
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass250.group;
    }

    private static Group PopulateGroup(string groupName, SPWeb web)
    {
      SPGroup spGroup = web.get_SiteGroups().get_Item(groupName);
      return new Group()
      {
        Name = groupName,
        Description = spGroup.get_Description(),
        Id = ((SPMember) spGroup).get_ID()
      };
    }

    private SPUser GetSPUser(SPWeb web, string loginName)
    {
      SPUser spUser = (SPUser) null;
      bool flag = false;
      try
      {
        flag = web.get_AllowUnsafeUpdates();
        web.set_AllowUnsafeUpdates(true);
        spUser = web.EnsureUser(loginName);
      }
      catch (SPException ex)
      {
        if (ex.get_ErrorCode() != -2146232832)
          throw new InvalidUserException(((Exception) ex).Message, (Exception) ex);
      }
      finally
      {
        web.set_AllowUnsafeUpdates(flag);
      }
      return spUser;
    }

    private bool IsSPGroupExists(SPWeb web, string groupName)
    {
      bool flag = false;
      try
      {
        web.get_SiteGroups().get_Item(groupName);
        flag = true;
      }
      catch
      {
      }
      return flag;
    }

    public void Dispose()
    {
      if (!this.disposable)
        return;
      this.Dispose(true);
    }

    private void Dispose(bool disposing)
    {
      if (!disposing)
        return;
      if (this.web != null)
        this.web.Dispose();
      if (this.Site != null)
        this.Site.Dispose();
      GC.SuppressFinalize((object) this);
    }
  }
}
