﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Security.AuthorizationService
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.iMPACT.Core.Security;
using IrisSoftware.iMPACT.Core.Unity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Core.Impl.Security
{
  [Export(typeof (IAuthorizationService))]
  public class AuthorizationService : IAuthorizationService
  {
    private Permission[] userPermissions;
    private Permission[] userEntityPermissions;
    private Permission[] userEntitySecurityPermissions;
    private Permission[] userEntitySecurityPermissionsAppTransIDStatusID;
    private Permission[] userIndependentPermissions;
    private Dictionary<long, Permission[]> dicUserEntitySecurityPermissions = new Dictionary<long, Permission[]>();
    private List<Tuple<long, long, Permission[]>> tupleUserEntityPermissions = new List<Tuple<long, long, Permission[]>>();
    private readonly IPermissionRepository repository;

    public AuthorizationService(IPermissionRepository repository) => this.repository = repository;

    public bool HasPermission(IUser user, int permission)
    {
      this.GetUserPermissions(user);
      return ((IEnumerable<Permission>) this.userPermissions).Any<Permission>((Func<Permission, bool>) (p => p.PermissionID == permission));
    }

    public bool HasPermission(IUser user, long entityTypeId, long entityId, int permission)
    {
      this.GetEntityPermissions(user, entityTypeId, entityId);
      return ((IEnumerable<Permission>) this.userEntityPermissions).Any<Permission>((Func<Permission, bool>) (p => (long) p.EntityTypeID == entityTypeId && p.PermissionID == permission));
    }

    public bool HasAnyPermission(IUser user, int[] permissions)
    {
      this.GetUserPermissions(user);
      return ((IEnumerable<Permission>) this.userPermissions).Any<Permission>((Func<Permission, bool>) (p => ((IEnumerable<int>) permissions).Any<int>((Func<int, bool>) (x => x == p.PermissionID))));
    }

    public bool HasAnyPermission(IUser user, long entityTypeId, long entityId, int[] permissions)
    {
      this.GetEntityPermissions(user, entityTypeId, entityId);
      return ((IEnumerable<Permission>) this.userEntityPermissions).Any<Permission>((Func<Permission, bool>) (p => (long) p.EntityTypeID == entityTypeId && ((IEnumerable<int>) permissions).Any<int>((Func<int, bool>) (x => x == p.PermissionID))));
    }

    public Permission[] GetPermissions(IUser user)
    {
      this.GetUserPermissions(user);
      return this.userPermissions;
    }

    public Permission[] GetPermissions(IUser user, long entityTypeId, long entityId)
    {
      this.GetEntityPermissions(user, entityTypeId, entityId);
      return this.userEntityPermissions;
    }

    private void GetUserPermissions(IUser user)
    {
      if (this.userPermissions != null)
        return;
      this.userPermissions = this.repository.GetPermission(user.GetEffectivePrincipalIds());
    }

    private void GetEntityPermissions(IUser user, long entityTypeId, long entityId)
    {
      if (this.tupleUserEntityPermissions.Count == 0 || !this.tupleUserEntityPermissions.Any<Tuple<long, long, Permission[]>>((Func<Tuple<long, long, Permission[]>, bool>) (t => t.Item1 == entityTypeId && t.Item2 == entityId)))
      {
        int[] effectivePrincipalIds = user.GetEffectivePrincipalIds();
        this.tupleUserEntityPermissions.Add(Tuple.Create<long, long, Permission[]>(entityTypeId, entityId, this.repository.GetPermission(entityTypeId, entityId, effectivePrincipalIds)));
      }
      this.userEntityPermissions = this.tupleUserEntityPermissions.Where<Tuple<long, long, Permission[]>>((Func<Tuple<long, long, Permission[]>, bool>) (t => t.Item1 == entityTypeId && t.Item2 == entityId)).FirstOrDefault<Tuple<long, long, Permission[]>>().Item3;
    }

    public bool HasExecutePermission(
      IUser user,
      long? entityTypeID,
      string[] uiName,
      string permission)
    {
      int[] effectivePrincipalIds = user.GetEffectivePrincipalIds();
      return this.repository.CheckPermission(entityTypeID, uiName, permission, effectivePrincipalIds);
    }

    public bool HasExecutePermission(
      IUser user,
      long? entityTypeId,
      List<Tuple<string, string>> uiNamePermissionList)
    {
      int[] effectivePrincipalIds = user.GetEffectivePrincipalIds();
      return this.repository.CheckPermission(entityTypeId, uiNamePermissionList, effectivePrincipalIds);
    }

    public bool HasAnyPermissionOnSet(IUser user, string[] uiNameArry)
    {
      this.GetUserPermissions(user);
      return ((IEnumerable<Permission>) this.userPermissions).Any<Permission>((Func<Permission, bool>) (p => ((IEnumerable<string>) uiNameArry).Any<string>((Func<string, bool>) (x => x == p.UIName))));
    }

    public bool HasAnyPermissionOnSet(IUser user, List<Tuple<string, string>> uiNamePermissionList)
    {
      this.GetUserPermissions(user);
      return ((IEnumerable<Permission>) this.userPermissions).Any<Permission>((Func<Permission, bool>) (p => uiNamePermissionList.Any<Tuple<string, string>>((Func<Tuple<string, string>, bool>) (uip => uip.Item1 == p.UIName && uip.Item2 == p.EntityPermission))));
    }

    public bool HasSecurityPermission(
      IUser user,
      long entityTypeID,
      string uiName,
      string permission)
    {
      this.GetEntitySecurityPermission(user, entityTypeID);
      return ((IEnumerable<Permission>) this.userEntitySecurityPermissions).Any<Permission>((Func<Permission, bool>) (p => (long) p.EntityTypeID == entityTypeID && p.UIName == uiName && p.EntityPermission == permission));
    }

    public bool HasAccessPermission(
      IUser user,
      long entityTypeId,
      long entityId,
      string uiName,
      string permission)
    {
      this.GetEntityPermissions(user, entityTypeId, entityId);
      return ((IEnumerable<Permission>) this.userEntityPermissions).Any<Permission>((Func<Permission, bool>) (p => (long) p.EntityTypeID == entityTypeId && p.UIName == uiName && p.EntityPermission == permission));
    }

    public bool HasUIPermissionForEntityStatus(
      IUser user,
      long appTransID,
      string uiName,
      string permission,
      List<long> statusList)
    {
      this.GetEntitySecurityPermissionAppTransIDStatusID(user, appTransID);
      return permission.Trim().ToLower() == "view" ? ((IEnumerable<Permission>) this.userEntitySecurityPermissionsAppTransIDStatusID).Any<Permission>((Func<Permission, bool>) (p => p.UIName == uiName && p.EntityPermission == permission && !p.StateID.HasValue)) : ((IEnumerable<Permission>) this.userEntitySecurityPermissionsAppTransIDStatusID).Any<Permission>((Func<Permission, bool>) (p => p.UIName == uiName && p.EntityPermission == permission && statusList.Contains((long) p.StateID.GetValueOrDefault())));
    }

    public bool HasUIPermissionForEntityStatus(
      IUser user,
      long appTransID,
      string uiName,
      string permission)
    {
      this.GetEntitySecurityPermissionAppTransIDStatusID(user, appTransID);
      return ((IEnumerable<Permission>) this.userEntitySecurityPermissionsAppTransIDStatusID).Any<Permission>((Func<Permission, bool>) (p => p.UIName == uiName && p.EntityPermission == permission));
    }

    public bool HasUIPermissionForEntityStatusMultiple(
      IUser user,
      long appTransID,
      string[] uiName,
      string permission)
    {
      this.GetEntitySecurityPermissionAppTransIDStatusID(user, appTransID);
      return ((IEnumerable<Permission>) this.userEntitySecurityPermissionsAppTransIDStatusID).Any<Permission>((Func<Permission, bool>) (p => ((IEnumerable<string>) uiName).Any<string>((Func<string, bool>) (u => u == p.UIName)) && p.EntityPermission == permission));
    }

    public bool HasIndependentPermission(IUser user, string uiName, string permission)
    {
      this.GetIndepedentPermission(user);
      return ((IEnumerable<Permission>) this.userIndependentPermissions).Any<Permission>((Func<Permission, bool>) (p => p.UIName == uiName && p.EntityPermission == permission));
    }

    public void FlushEntitySecurityPermissionAppTransIDStatusID() => this.userEntitySecurityPermissionsAppTransIDStatusID = (Permission[]) null;

    private void GetEntitySecurityPermission(IUser user, long entityTypeId)
    {
      if (this.dicUserEntitySecurityPermissions.Count == 0 || !this.dicUserEntitySecurityPermissions.ContainsKey(entityTypeId))
      {
        int[] effectivePrincipalIds = user.GetEffectivePrincipalIds();
        this.dicUserEntitySecurityPermissions.Add(entityTypeId, this.repository.GetPermissionByEntityTypeID(effectivePrincipalIds, entityTypeId));
      }
      this.userEntitySecurityPermissions = this.dicUserEntitySecurityPermissions[entityTypeId];
    }

    private void GetEntitySecurityPermissionAppTransIDStatusID(IUser user, long entityId)
    {
      if (this.userEntitySecurityPermissionsAppTransIDStatusID != null)
        return;
      this.userEntitySecurityPermissionsAppTransIDStatusID = this.repository.GetPermissionByAppTransIDStatusID(user.GetEffectivePrincipalIds(), entityId);
    }

    private void GetIndepedentPermission(IUser user)
    {
      if (this.userIndependentPermissions != null)
        return;
      this.userIndependentPermissions = this.repository.GetIndependentPermission(user.GetEffectivePrincipalIds());
    }

    public void FlushUserEntitySecurityPermissions() => this.userEntitySecurityPermissions = (Permission[]) null;
  }
}
