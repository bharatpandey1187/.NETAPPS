﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Security.User
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.iMPACT.Core.Security;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Administration.Claims;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace IrisSoftware.iMPACT.Core.Impl.Security
{
  public class User : IUser
  {
    private SPUser user;

    public int Id => ((SPMember) this.user).get_ID();

    public string Name => ((SPPrincipal) this.user).get_Name();

    public string LoginName => ((SPPrincipal) this.user).get_LoginName();

    public string Email => this.user.get_Email();

    [InjectionConstructor]
    public User() => this.user = SPContext.get_Current().get_Web().get_CurrentUser();

    public User(SPUser spUser) => this.user = spUser;

    public int[] GetGroupPrincipalIds() => ((IEnumerable) this.user.get_Groups()).Cast<SPGroup>().Select<SPGroup, int>((Func<SPGroup, int>) (g => ((SPMember) g).get_ID())).ToArray<int>();

    public int[] GetEffectivePrincipalIds() => ((IEnumerable<int>) new int[1]
    {
      ((SPMember) this.user).get_ID()
    }).Union<int>(((IEnumerable) this.user.get_Groups()).Cast<SPGroup>().Select<SPGroup, int>((Func<SPGroup, int>) (g => ((SPMember) g).get_ID()))).ToArray<int>();

    public string GetLoginNameWithoutClaimInformation()
    {
      try
      {
        SPClaimProviderManager local = SPClaimProviderManager.get_Local();
        return SPPersistedObject.op_Inequality((SPPersistedObject) local, (SPPersistedObject) null) && SPClaimProviderManager.IsEncodedClaim(((SPPrincipal) this.user).get_LoginName()) ? local.ConvertClaimToIdentifier(((SPPrincipal) this.user).get_LoginName()) : ((SPPrincipal) this.user).get_LoginName();
      }
      catch
      {
        return ((SPPrincipal) this.user).get_LoginName();
      }
    }
  }
}
