﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.DocumentService.ContentType
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using System.IO;

namespace IrisSoftware.iMPACT.Core.Impl.DocumentService
{
  public class ContentType
  {
    public static string FromFileExtention(string fileName)
    {
      string empty = string.Empty;
      string str;
      switch (Path.GetExtension(fileName))
      {
        case ".avi":
          str = "video/avi";
          break;
        case ".bmp":
          str = "image/bmp";
          break;
        case ".csv":
        case ".xls":
        case ".xlt":
          str = "application/vnd.msexcel";
          break;
        case ".doc":
        case ".dot":
          str = "application/msword";
          break;
        case ".gif":
          str = "image/gif";
          break;
        case ".htm":
        case ".html":
          str = "text/html";
          break;
        case ".jpeg":
        case ".jpg":
          str = "image/jpeg";
          break;
        case ".mpeg":
        case ".mpg":
          str = "video/mpeg";
          break;
        case ".pdf":
          str = "application/pdf";
          break;
        case ".rtf":
          str = "text/richtext";
          break;
        case ".txt":
          str = "text/plain";
          break;
        case ".xml":
          str = "application/vnd.xml";
          break;
        default:
          str = "application/octet-stream";
          break;
      }
      return str;
    }
  }
}
