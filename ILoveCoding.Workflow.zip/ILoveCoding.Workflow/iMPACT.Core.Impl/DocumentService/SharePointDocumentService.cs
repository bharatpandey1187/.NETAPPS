﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.DocumentService.SharePointDocumentService
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.iMPACT.Core.DocumentService;
using Microsoft.Office.DocumentManagement.DocumentSets;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace IrisSoftware.iMPACT.Core.Impl.DocumentService
{
  public class SharePointDocumentService : IDocumentService
  {
    private SPWeb _oWeb;
    private string OpportunityDocLibPrimaryAbsUrl;
    private string RfpDocLibPrimaryAbsUrl;
    private string IssueDocLibPrimaryAbsUrl;
    private string VersionHistoryUrl;

    [InjectionConstructor]
    public SharePointDocumentService(Dictionary<string, string> settings)
      : this(SPContext.get_Current().get_Web(), settings)
      => this.InitializeSettings(settings);

    public SharePointDocumentService(SPWeb oWeb, Dictionary<string, string> settings)
    {
      this._oWeb = oWeb;
      this.InitializeSettings(settings);
    }

    private void InitializeSettings(Dictionary<string, string> settings)
    {
      settings.TryGetValue("OpportunityDocLibPrimaryAbsURL", out this.OpportunityDocLibPrimaryAbsUrl);
      settings.TryGetValue("RfpDocLibPrimaryAbsURL", out this.RfpDocLibPrimaryAbsUrl);
      settings.TryGetValue("IssueDocLibPrimaryAbsURL", out this.IssueDocLibPrimaryAbsUrl);
      settings.TryGetValue("VersionHistoryUrl", out this.VersionHistoryUrl);
    }

    public Document CheckIn(Document document, string comments)
    {
      Document doc = this.DocumentDeepClone(document);
      string documentUrl = doc.DocumentURL;
      SharePointDocumentService.AppSPWeb appSpWeb = new SharePointDocumentService.AppSPWeb(documentUrl, this._oWeb);
      bool allowUnsafeUpdates = appSpWeb.SPWeb.get_AllowUnsafeUpdates();
      try
      {
        SPListItem listItem = appSpWeb.SPWeb.GetListItem(documentUrl);
        if (listItem == null)
          throw new Exception("File url " + documentUrl + " not found.");
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(true);
        listItem.get_File().CheckIn(comments);
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(allowUnsafeUpdates);
        this.PopulateDocumentFromFile(listItem.get_File(), doc);
        return doc;
      }
      catch (SPFileCheckOutException ex)
      {
        throw new DocumentCheckOutException(((Exception) ex).Message, (Exception) ex);
      }
    }

    public Document CheckOut(Document document)
    {
      Document doc = this.DocumentDeepClone(document);
      string documentUrl = doc.DocumentURL;
      SharePointDocumentService.AppSPWeb appSpWeb = new SharePointDocumentService.AppSPWeb(documentUrl, this._oWeb);
      bool allowUnsafeUpdates = appSpWeb.SPWeb.get_AllowUnsafeUpdates();
      try
      {
        SPListItem listItem = appSpWeb.SPWeb.GetListItem(documentUrl);
        if (listItem == null)
          throw new Exception("File url " + documentUrl + " not found.");
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(true);
        listItem.get_File().CheckOut();
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(allowUnsafeUpdates);
        this.PopulateDocumentFromFile(listItem.get_File(), doc);
        return doc;
      }
      catch (SPFileCheckOutException ex)
      {
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(allowUnsafeUpdates);
        throw new DocumentCheckOutException(((Exception) ex).Message, (Exception) ex);
      }
    }

    public Document UndoCheckOut(Document document)
    {
      Document doc = this.DocumentDeepClone(document);
      string documentUrl = doc.DocumentURL;
      SharePointDocumentService.AppSPWeb appSpWeb = new SharePointDocumentService.AppSPWeb(documentUrl, this._oWeb);
      bool allowUnsafeUpdates = appSpWeb.SPWeb.get_AllowUnsafeUpdates();
      try
      {
        SPListItem listItem = appSpWeb.SPWeb.GetListItem(documentUrl);
        if (listItem == null)
          throw new Exception("File url " + documentUrl + " not found.");
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(true);
        listItem.get_File().UndoCheckOut();
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(allowUnsafeUpdates);
        this.PopulateDocumentFromFile(listItem.get_File(), doc);
        return doc;
      }
      catch (SPFileCheckOutException ex)
      {
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(allowUnsafeUpdates);
        throw new DocumentCheckOutException(((Exception) ex).Message, (Exception) ex);
      }
    }

    public DocSetInfo CreateDocSet(
      DocSetInfo docSetInfo,
      List<DocSetPermission> documentSetPermissions,
      Hashtable sharedFields)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointDocumentService.\u003C\u003Ec__DisplayClass11_0 cDisplayClass110 = new SharePointDocumentService.\u003C\u003Ec__DisplayClass11_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass110.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass110.docSetInfo = docSetInfo;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass110.sharedFields = sharedFields;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass110.documentSetInfo = new DocSetInfo();
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass110, __methodptr(\u003CCreateDocSet\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass110.documentSetInfo;
    }

    public Document Upload(Document document, byte[] bytes)
    {
      Document doc = (Document) null;
      string docSetUrl = document.DocSetURL;
      int result;
      if (!int.TryParse(document.DocSetId, out result))
        throw new Exception(string.Format("Could not convert string: {0} to int", (object) document.DocSetId));
      using (SPSite spSite = new SPSite(docSetUrl))
      {
        using (SPWeb web = spSite.OpenWeb())
        {
          bool allowUnsafeUpdates = web.get_AllowUnsafeUpdates();
          web.set_AllowUnsafeUpdates(true);
          SPFile file = ((SPList) this.GetLibraryFromUrl(docSetUrl, web)).GetItemById(result).get_Folder().get_Files().Add(document.DocumentName, bytes, true);
          ((SPItem) file.get_Item()).set_Item("Name", (object) document.DocumentName);
          ((SPItem) file.get_Item()).set_Item("Title", (object) document.DocumentName);
          ((SPItem) file.get_Item()).set_Item("iDocCategory", (object) document.EntityTypeDocTypeCategoryID);
          ((SPItem) file.get_Item()).set_Item("iDocType", (object) document.EntityTypeDocTypeID);
          if (document.Tags == null)
            document.Tags = string.Empty;
          string[] strArray = document.Tags.Split(new char[1]
          {
            '~'
          }, StringSplitOptions.RemoveEmptyEntries);
          SPFieldMultiChoiceValue multiChoiceValue = new SPFieldMultiChoiceValue();
          foreach (string str in strArray)
            multiChoiceValue.Add(str);
          ((SPItem) file.get_Item()).set_Item("iDocMultiTag", (object) multiChoiceValue);
          ((SPItem) file.get_Item()).set_Item("iDocTypeOtherDesc", (object) document.TypeOtherDesc);
          ((SPItem) file.get_Item()).set_Item("ContentType", (object) "iMPACT_CTypeDocumentMetadata");
          file.get_Item().UpdateOverwriteVersion();
          if (file.get_CheckOutType() != 2)
            file.CheckIn(string.Empty);
          web.set_AllowUnsafeUpdates(allowUnsafeUpdates);
          doc = this.DocumentDeepClone(document);
          this.PopulateDocumentFromFile(file, doc);
        }
      }
      return doc;
    }

    public Document Upload(
      Document document,
      byte[] bytes,
      Dictionary<string, string> sharedFields)
    {
      return new Document();
    }

    public void UpdateSharedFields(string entityType, string strDocSetId, Hashtable sharedFields)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointDocumentService.\u003C\u003Ec__DisplayClass14_0 cDisplayClass140 = new SharePointDocumentService.\u003C\u003Ec__DisplayClass14_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass140.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass140.sharedFields = sharedFields;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass140.absoluteDocLibUrl = this.GetDocLibPrimaryUrl(entityType);
      // ISSUE: reference to a compiler-generated field
      if (!int.TryParse(strDocSetId, out cDisplayClass140.docSetId))
        throw new Exception(string.Format("Could not convert string: {} to int", (object) strDocSetId));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (cDisplayClass140.sharedFields == null || cDisplayClass140.sharedFields.Count <= 0)
        return;
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass140, __methodptr(\u003CUpdateSharedFields\u003Eb__0)));
    }

    public Document UpdateSharedFields(
      Document document,
      Dictionary<string, string> sharedFields)
    {
      throw new NotImplementedException();
    }

    public void ApplyPermission(
      string entityType,
      string strDocSetId,
      List<DocSetPermission> issueDocSetPermissions)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointDocumentService.\u003C\u003Ec__DisplayClass16_1 cDisplayClass161 = new SharePointDocumentService.\u003C\u003Ec__DisplayClass16_1();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass161.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass161.issueDocSetPermissions = issueDocSetPermissions;
      // ISSUE: reference to a compiler-generated field
      if (!int.TryParse(strDocSetId, out cDisplayClass161.docSetId))
        throw new Exception(string.Format("Could not convert string: {} to int", (object) strDocSetId));
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) new SharePointDocumentService.\u003C\u003Ec__DisplayClass16_0()
      {
        CS\u0024\u003C\u003E8__locals1 = cDisplayClass161,
        absoluteDocLibUrl = this.GetDocLibPrimaryUrl(entityType)
      }, __methodptr(\u003CApplyPermission\u003Eb__0)));
    }

    public void ApplyPermission(
      string entityType,
      string strDocSetId,
      List<DocSetPermission> issueDocSetPermissions,
      Hashtable sharedFields)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointDocumentService.\u003C\u003Ec__DisplayClass17_0 cDisplayClass170 = new SharePointDocumentService.\u003C\u003Ec__DisplayClass17_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass170.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass170.entityType = entityType;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass170.sharedFields = sharedFields;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass170.issueDocSetPermissions = issueDocSetPermissions;
      // ISSUE: reference to a compiler-generated field
      if (!int.TryParse(strDocSetId, out cDisplayClass170.docSetId))
        throw new Exception(string.Format("Could not convert string: {} to int", (object) strDocSetId));
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass170, __methodptr(\u003CApplyPermission\u003Eb__0)));
    }

    public void Delete(Document doc)
    {
      string documentUrl = doc.DocumentURL;
      using (SharePointDocumentService.AppSPWeb appSpWeb = new SharePointDocumentService.AppSPWeb(documentUrl, this._oWeb))
      {
        bool allowUnsafeUpdates = appSpWeb.SPWeb.get_AllowUnsafeUpdates();
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(true);
        ((SPItem) (appSpWeb.SPWeb.GetListItem(documentUrl) ?? throw new Exception("File url " + documentUrl + " not found."))).Delete();
        appSpWeb.SPWeb.set_AllowUnsafeUpdates(allowUnsafeUpdates);
      }
    }

    public List<Document> Move(
      List<Document> documentsToMoveList,
      DocSetInfo docSetInfo)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointDocumentService.\u003C\u003Ec__DisplayClass19_0 cDisplayClass190 = new SharePointDocumentService.\u003C\u003Ec__DisplayClass19_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass190.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass190.docSetInfo = docSetInfo;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass190.documentsToMoveList = documentsToMoveList;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass190.movedDocList = new List<Document>();
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!int.TryParse(cDisplayClass190.docSetInfo.DocSetId, out cDisplayClass190.docSetId))
      {
        // ISSUE: reference to a compiler-generated field
        throw new Exception(string.Format("Could not convert DocSetID string: {} to int", (object) cDisplayClass190.docSetInfo.DocSetId));
      }
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass190, __methodptr(\u003CMove\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass190.movedDocList;
    }

    public List<Document> Move(string[] srcFileUrls, DocSetInfo docSetInfo)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointDocumentService.\u003C\u003Ec__DisplayClass20_0 cDisplayClass200 = new SharePointDocumentService.\u003C\u003Ec__DisplayClass20_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass200.\u003C\u003E4__this = this;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass200.docSetInfo = docSetInfo;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass200.srcFileUrls = srcFileUrls;
      // ISSUE: reference to a compiler-generated field
      cDisplayClass200.docList = new List<Document>();
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!int.TryParse(cDisplayClass200.docSetInfo.DocSetId, out cDisplayClass200.docSetId))
      {
        // ISSUE: reference to a compiler-generated field
        throw new Exception(string.Format("Could not convert DocSetID string: {} to int", (object) cDisplayClass200.docSetInfo.DocSetId));
      }
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass200, __methodptr(\u003CMove\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return cDisplayClass200.docList;
    }

    public Stream Download(Document doc)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      SharePointDocumentService.\u003C\u003Ec__DisplayClass21_0 cDisplayClass210 = new SharePointDocumentService.\u003C\u003Ec__DisplayClass21_0()
      {
        doc = doc,
        memoryStream = new MemoryStream(),
        cType = string.Empty
      };
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      cDisplayClass210.absoluteDocLibUrl = cDisplayClass210.doc.DocSetURL;
      // ISSUE: method pointer
      SPSecurity.RunWithElevatedPrivileges(new SPSecurity.CodeToRunElevated((object) cDisplayClass210, __methodptr(\u003CDownload\u003Eb__0)));
      // ISSUE: reference to a compiler-generated field
      return (Stream) cDisplayClass210.memoryStream;
    }

    public List<Document> GetDocuments(string entityType, string docSetId)
    {
      string docLibPrimaryUrl = this.GetDocLibPrimaryUrl(entityType);
      List<Document> documentList = new List<Document>();
      SharePointDocumentService.AppSPWeb appSpWeb = new SharePointDocumentService.AppSPWeb(docLibPrimaryUrl, this._oWeb);
      SPDocumentLibrary libraryFromUrl = this.GetLibraryFromUrl(docLibPrimaryUrl, appSpWeb.SPWeb);
      SPQuery spQuery1 = new SPQuery();
      spQuery1.set_Query(string.Format("<Where><Eq><FieldRef Name='ID' /><Value Type='Counter'>{0}</Value></Eq></Where>", (object) docSetId));
      SPQuery spQuery2 = spQuery1;
      SPListItemCollection items = ((SPList) libraryFromUrl).GetItems(spQuery2);
      if (items != null && ((SPBaseCollection) items).get_Count() > 0)
      {
        IEnumerator enumerator1 = ((SPBaseCollection) items).GetEnumerator();
        try
        {
          while (enumerator1.MoveNext())
          {
            SPListItem current1 = (SPListItem) enumerator1.Current;
            SPFileCollection files = current1.get_Folder().get_Files();
            if (files != null)
            {
              IEnumerator enumerator2 = ((SPBaseCollection) files).GetEnumerator();
              try
              {
                while (enumerator2.MoveNext())
                {
                  SPFile current2 = (SPFile) enumerator2.Current;
                  documentList.Add(this.PopulateDocumentProperties(current1, current2));
                }
              }
              finally
              {
                if (enumerator2 is IDisposable disposable)
                  disposable.Dispose();
              }
            }
          }
        }
        finally
        {
          if (enumerator1 is IDisposable disposable)
            disposable.Dispose();
        }
      }
      return documentList;
    }

    public bool IsFileExists(Document doc)
    {
      bool flag = false;
      using (SharePointDocumentService.AppSPWeb appSpWeb = new SharePointDocumentService.AppSPWeb(doc.DocumentURL, this._oWeb))
      {
        try
        {
          if (appSpWeb.SPWeb.GetListItem(doc.DocumentURL) != null)
            flag = true;
        }
        catch
        {
        }
      }
      return flag;
    }

    public string GetVersionHistoryUrl() => this.VersionHistoryUrl;

    private void UpdateSharedFields(SPDocumentLibrary docLib, int docSetId, Hashtable sharedFields)
    {
      SPListItem itemById = ((SPList) docLib).GetItemById(docSetId);
      foreach (string key in (IEnumerable) sharedFields.Keys)
        ((SPItem) itemById).set_Item(key, (object) Convert.ToString(sharedFields[(object) key]).Trim());
      ((SPItem) itemById).Update();
    }

    private void ApplyPermission(
      List<DocSetPermission> issueDocSetPermissions,
      SPWeb web,
      SPDocumentLibrary docLib,
      int docSetId)
    {
      bool allowUnsafeUpdates = web.get_AllowUnsafeUpdates();
      web.set_AllowUnsafeUpdates(true);
      SPListItem itemById = ((SPList) docLib).GetItemById(docSetId);
      List<SPRoleAssignment> roleAssignments = new List<SPRoleAssignment>();
      this.GetRoleAssignmentForUser(issueDocSetPermissions, ref roleAssignments);
      this.GetRoleAssignmentForGroup(issueDocSetPermissions, ref roleAssignments);
      if (roleAssignments.Count > 0)
      {
        this.BreakInheritedPermission(ref itemById);
        this.AddRoleAssignment(itemById, roleAssignments);
        ((SPItem) itemById).Update();
      }
      web.set_AllowUnsafeUpdates(allowUnsafeUpdates);
    }

    private SPDocumentLibrary GetLibraryFromUrl(
      string absoluteDocLibUrl,
      SPWeb web)
    {
      try
      {
        if (!(web.GetList(absoluteDocLibUrl) is SPDocumentLibrary list))
          throw new UnknownDocumentLibraryException(absoluteDocLibUrl);
        return list;
      }
      catch (SPException ex)
      {
        throw new UnknownDocumentLibraryException(absoluteDocLibUrl, (Exception) ex);
      }
    }

    private DocumentSet CreateDocumentSet(
      SPDocumentLibrary docLib,
      Hashtable sharedFields)
    {
      SPContentTypeId spContentTypeId = ((SPList) docLib).get_RootFolder().get_UniqueContentTypeOrder() == null ? (((SPList) docLib).get_ContentTypes().get_Item("iMPACT_CTypeDocumentMetadata") == null ? ((SPList) docLib).get_ContentTypes().get_Item(0).get_Id() : ((SPList) docLib).get_ContentTypes().get_Item("iMPACT_CTypeDocumentMetadata").get_Id()) : ((SPList) docLib).get_RootFolder().get_UniqueContentTypeOrder()[0].get_Id();
      return DocumentSet.Create(((SPList) docLib).get_RootFolder(), Guid.NewGuid().ToString(), spContentTypeId, sharedFields);
    }

    private void AddRoleAssignment(SPListItem listItem, List<SPRoleAssignment> roleAssignments)
    {
      using (List<SPRoleAssignment>.Enumerator enumerator = roleAssignments.GetEnumerator())
      {
        while (enumerator.MoveNext())
        {
          SPRoleAssignment current = enumerator.Current;
          ((SPSecurableObject) listItem).get_RoleAssignments().Add(current);
        }
      }
    }

    private void BreakInheritedPermission(ref SPListItem item)
    {
      if (!((SPSecurableObject) item).get_HasUniqueRoleAssignments())
        ((SPSecurableObject) item).BreakRoleInheritance(false);
      List<SPPrincipal> spPrincipalList = new List<SPPrincipal>();
      IEnumerator enumerator1 = ((SPBaseCollection) ((SPSecurableObject) item).get_RoleAssignments()).GetEnumerator();
      try
      {
        while (enumerator1.MoveNext())
        {
          SPRoleAssignment current = (SPRoleAssignment) enumerator1.Current;
          spPrincipalList.Add(current.get_Member());
        }
      }
      finally
      {
        if (enumerator1 is IDisposable disposable)
          disposable.Dispose();
      }
      using (List<SPPrincipal>.Enumerator enumerator2 = spPrincipalList.GetEnumerator())
      {
        while (enumerator2.MoveNext())
        {
          SPPrincipal current = enumerator2.Current;
          ((SPSecurableObject) item).get_RoleAssignments().Remove(current);
        }
      }
      item.SystemUpdate(false);
    }

    private void GetRoleAssignmentForGroup(
      List<DocSetPermission> issueDocSetPermissions,
      ref List<SPRoleAssignment> roleAssignments)
    {
      SPGroupCollection siteGroups = this._oWeb.get_SiteGroups();
      foreach (DocSetPermission docSetPermission in issueDocSetPermissions)
      {
        try
        {
          SPRoleAssignment spRoleAssignment = new SPRoleAssignment((SPPrincipal) siteGroups.GetByID(docSetPermission.PrincipalId));
          SPRoleDefinition spRoleDefinition = this._oWeb.get_RoleDefinitions().get_Item(this.GetTranslatedSPPermission(docSetPermission.Permission));
          spRoleAssignment.get_RoleDefinitionBindings().Add(spRoleDefinition);
          roleAssignments.Add(spRoleAssignment);
        }
        catch (SPException ex)
        {
          if (ex.get_ErrorCode() != -2146232832)
            throw;
        }
      }
    }

    private void GetRoleAssignmentForUser(
      List<DocSetPermission> issueDocSetPermissions,
      ref List<SPRoleAssignment> roleAssignments)
    {
      SPUserCollection siteUsers = this._oWeb.get_SiteUsers();
      foreach (DocSetPermission docSetPermission in issueDocSetPermissions)
      {
        try
        {
          SPRoleAssignment spRoleAssignment = new SPRoleAssignment((SPPrincipal) siteUsers.GetByID(docSetPermission.PrincipalId));
          SPRoleDefinition spRoleDefinition = this._oWeb.get_RoleDefinitions().get_Item(this.GetTranslatedSPPermission(docSetPermission.Permission));
          spRoleAssignment.get_RoleDefinitionBindings().Add(spRoleDefinition);
          roleAssignments.Add(spRoleAssignment);
        }
        catch (SPException ex)
        {
          if (ex.get_ErrorCode() != -2146232832)
            throw;
        }
      }
    }

    private Document PopulateDocumentProperties(SPListItem currentItem, SPFile currentFile)
    {
      DocumentInfo documentInfo = new DocumentInfo();
      Document document = new Document();
      document.DocSetName = currentItem.get_ContentType().get_Name();
      document.CheckedOutBy = currentFile.get_CheckedOutByUser() != null ? ((SPPrincipal) currentFile.get_CheckedOutByUser()).get_LoginName() : string.Empty;
      document.CheckedOutDate = new DateTime?(currentFile.get_CheckedOutByUser() != null ? currentFile.get_CheckedOutDate() : DateTime.MinValue);
      document.CheckedOutExpires = new DateTime?(currentFile.get_LockedByUser() != null ? currentFile.get_LockExpires() : DateTime.MinValue);
      document.LastModifiedBy = currentFile.get_ModifiedBy() != null ? ((SPPrincipal) currentFile.get_ModifiedBy()).get_LoginName() : string.Empty;
      document.LastModifiedOn = currentFile.get_TimeLastModified();
      document.DocumentURL = currentFile.get_Item().get_Item((Guid) SPBuiltInFieldId.EncodedAbsUrl) as string;
      document.DocumentId = ((SPItem) currentFile.get_Item()).get_ID().ToString();
      document.CheckOutType = currentFile.get_CheckOutType().ToString();
      document.UIVersionLabel = currentFile.get_UIVersionLabel();
      document.TotalVersion = ((SPBaseCollection) currentFile.get_Versions()).get_Count() + 1;
      documentInfo.Name = currentFile.get_Name();
      documentInfo.Category = Convert.ToString(currentFile.GetProperty((object) "iDocCategory"));
      string str = Convert.ToString(currentFile.GetProperty((object) "iDocMultiTag")).Replace("#", "");
      if (str.StartsWith(";"))
        str = str.Substring(1);
      documentInfo.Tags = str;
      documentInfo.Type = Convert.ToString(currentFile.GetProperty((object) "iDocType"));
      documentInfo.TypeOtherDesc = Convert.ToString(currentFile.GetProperty((object) "iDocTypeOtherDesc"));
      return document;
    }

    private void PopulateDocumentFromFile(SPFile file, Document doc)
    {
      doc.DocumentId = ((SPItem) file.get_Item()).get_ID().ToString();
      doc.DocumentName = file.get_Name();
      doc.DocumentListID = file.get_Item().get_ParentList().get_ID().ToString();
      doc.DocumentURL = file.get_Item().get_Item((Guid) SPBuiltInFieldId.EncodedAbsUrl) as string;
      doc.CheckOutType = file.get_CheckOutType().ToString();
      doc.UIVersionLabel = file.get_UIVersionLabel();
      doc.TotalVersion = ((SPBaseCollection) file.get_Versions()).get_Count() + 1;
      doc.CheckedOutBy = file.get_CheckedOutByUser() != null ? ((SPPrincipal) file.get_CheckedOutByUser()).get_LoginName() : string.Empty;
      doc.CheckedOutDate = file.get_CheckedOutByUser() == null ? new DateTime?() : new DateTime?(file.get_CheckedOutDate());
      doc.CheckedOutExpires = file.get_LockedByUser() == null ? new DateTime?() : new DateTime?(file.get_LockExpires());
      doc.LastModifiedBy = file.get_ModifiedBy() != null ? ((SPPrincipal) file.get_ModifiedBy()).get_LoginName() : string.Empty;
      doc.LastModifiedOn = file.get_TimeLastModified();
      doc.EntityTypeDocTypeCategoryID = Convert.ToString(((SPItem) file.get_Item()).get_Item("iDocCategory"));
      string[] strArray = Convert.ToString(((SPItem) file.get_Item()).get_Item("iDocMultiTag")).Split(new string[1]
      {
        ";#"
      }, StringSplitOptions.RemoveEmptyEntries);
      doc.Tags = string.Join(";", strArray);
      doc.EntityTypeDocTypeID = Convert.ToString(((SPItem) file.get_Item()).get_Item("iDocType"));
      doc.TypeOtherDesc = Convert.ToString(((SPItem) file.get_Item()).get_Item("iDocTypeOtherDesc"));
      doc.StorageKey = "SharePoint";
    }

    private string GetTranslatedSPPermission(string permission)
    {
      string str = string.Empty;
      if (string.Compare(permission, "Upload", true) == 0)
        str = "Contribute";
      else if (string.Compare(permission, "view", true) == 0)
        str = "Read";
      return str;
    }

    private Document DocumentDeepClone(Document doc)
    {
      using (MemoryStream memoryStream = new MemoryStream())
      {
        BinaryFormatter binaryFormatter = new BinaryFormatter();
        binaryFormatter.Serialize((Stream) memoryStream, (object) doc);
        memoryStream.Position = 0L;
        return (Document) binaryFormatter.Deserialize((Stream) memoryStream);
      }
    }

    private string GetDocLibPrimaryUrl(string entityID)
    {
      string str = string.Empty;
      if (!(entityID == "-32"))
      {
        if (entityID == "-33")
          str = this.OpportunityDocLibPrimaryAbsUrl;
      }
      else
        str = this.IssueDocLibPrimaryAbsUrl;
      return str;
    }

    private bool IsFileExists(SPListItem DocSet, Document doc)
    {
      IEnumerator enumerator = ((SPBaseCollection) DocSet.get_Folder().get_Files()).GetEnumerator();
      try
      {
        while (enumerator.MoveNext())
        {
          if (((SPFile) enumerator.Current).get_Name() == doc.DocumentName)
            return true;
        }
      }
      finally
      {
        if (enumerator is IDisposable disposable)
          disposable.Dispose();
      }
      return false;
    }

    private sealed class AppSPWeb : IDisposable
    {
      private SPSite site;
      private SPWeb web;
      private bool isSPContextWeb;

      public SPWeb SPWeb => this.web;

      public AppSPWeb(string url, SPWeb bweb)
      {
        if (url.StartsWith(bweb.get_Url(), StringComparison.CurrentCultureIgnoreCase))
        {
          this.web = bweb;
          this.isSPContextWeb = true;
        }
        else
        {
          using (SPSite spSite = new SPSite(url))
          {
            using (SPWeb spWeb = spSite.OpenWeb())
            {
              this.web = spWeb;
              this.isSPContextWeb = false;
            }
          }
        }
      }

      public void Dispose()
      {
        if (this.isSPContextWeb)
          return;
        this.Dispose(true);
        GC.SuppressFinalize((object) this);
      }

      private void Dispose(bool disposing)
      {
        if (!disposing || this.isSPContextWeb)
          return;
        if (this.web != null)
        {
          this.web.Dispose();
          this.web = (SPWeb) null;
        }
        if (this.site == null)
          return;
        this.site.Dispose();
        this.site = (SPSite) null;
      }
    }
  }
}
