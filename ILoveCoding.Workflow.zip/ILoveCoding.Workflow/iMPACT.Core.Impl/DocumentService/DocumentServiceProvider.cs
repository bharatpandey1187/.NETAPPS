﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.DocumentService.DocumentServiceProvider
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.Unity;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace IrisSoftware.iMPACT.Core.Impl.DocumentService
{
  [Export(typeof (IDocumentServiceProvider))]
  public class DocumentServiceProvider : IDocumentServiceProvider
  {
    [Dependency]
    public SqlDatabase db { get; set; }

    public IDocumentService GetService(string storageKey)
    {
      Dictionary<string, string> settingConfigValues = this.GetStorageSettingConfigValues(storageKey);
      string empty = string.Empty;
      return settingConfigValues.TryGetValue("Type", out empty) && empty == "SharePoint" ? (IDocumentService) new SharePointDocumentService(settingConfigValues) : (IDocumentService) null;
    }

    private Dictionary<string, string> GetStorageSettingConfigValues(string storageKey)
    {
      Dictionary<string, string> dictionary = new Dictionary<string, string>();
      using (DbCommand storedProcCommand = this.db.GetStoredProcCommand("usp_FetchSettingValuesByStorageKey"))
      {
        this.db.AddInParameter(storedProcCommand, "@StorageKey", DbType.String, (object) storageKey);
        using (IDataReader dataReader = this.db.ExecuteReader(storedProcCommand))
        {
          int ordinal1 = dataReader.GetOrdinal("SettingKey");
          int ordinal2 = dataReader.GetOrdinal("SettingValue");
          while (dataReader.Read())
          {
            string key = dataReader.GetString(ordinal1);
            string str = dataReader.GetString(ordinal2);
            dictionary.Add(key, str);
          }
        }
      }
      return dictionary;
    }
  }
}
