﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Query.QueryFieldMapping
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

namespace IrisSoftware.iMPACT.Core.Impl.Query
{
  public class QueryFieldMapping
  {
    public string PropertyName { get; set; }

    public string SqlName { get; set; }

    public string SharePointName { get; set; }

    public SharePointPropertyType SharePointType { get; set; }

    public QueryFieldMapping()
    {
    }

    public QueryFieldMapping(
      string propertyName,
      string sqlName,
      string sharePointName,
      SharePointPropertyType sharePointType)
    {
      this.PropertyName = propertyName;
      this.SqlName = sqlName;
      this.SharePointName = sharePointName;
      this.SharePointType = sharePointType;
    }
  }
}
