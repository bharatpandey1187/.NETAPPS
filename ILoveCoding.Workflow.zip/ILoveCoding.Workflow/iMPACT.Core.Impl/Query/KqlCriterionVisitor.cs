﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Query.KqlCriterionVisitor
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.Core.SearchCriteria;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace IrisSoftware.iMPACT.Core.Impl.Query
{
  public class KqlCriterionVisitor : ICriterionVisitor
  {
    protected internal StringBuilder whereClause = new StringBuilder();
    private IDictionary<string, QueryFieldMapping> knownMappings;

    public KqlCriterionVisitor(
      IDictionary<string, QueryFieldMapping> knownMappings)
    {
      this.knownMappings = knownMappings;
    }

    public virtual void VisitAndCriterion<TVisitor>(AndCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor => this.VisitJunctionCriterion(criterion.Criteria, " AND ");

    private void VisitJunctionCriterion(IVisitableCriterion[] criteria, string juncture)
    {
      for (int index = 0; index < criteria.Length; ++index)
      {
        criteria[index].Accept<KqlCriterionVisitor>(this);
        if (index < criteria.Length - 1)
          this.whereClause.Append(juncture);
      }
    }

    public virtual void VisitOrCriterion<TVisitor>(OrCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor => this.VisitJunctionCriterion(criterion.Criteria, " OR ");

    public virtual void VisitContainsCriterion<TVisitor>(
      ContainsCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      string str = this.RemapPropertyName(criterion.PropertyName);
      this.whereClause.Append("(");
      for (int index = 0; index < criterion.Values.Length; ++index)
      {
        this.whereClause.AppendFormat("{0}:{1}", (object) str, (object) criterion.Values[index]);
        if (index < criterion.Values.Length - 1)
          this.whereClause.Append(" OR ");
      }
      this.whereClause.Append(")");
    }

    public virtual void VisitAnyOfCriterion<TVisitor>(AnyOfCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor
    {
      string str = this.RemapPropertyName(criterion.PropertyName);
      this.whereClause.Append("(");
      for (int index = 0; index < criterion.Values.Length; ++index)
      {
        this.whereClause.Append(str).Append("=");
        if (index < criterion.Values.Length)
        {
          this.whereClause.Append(criterion.Values[index]);
          if (index != criterion.Values.Length - 1)
            this.whereClause.Append(" OR ");
        }
      }
      this.whereClause.Append(")");
    }

    public virtual void VisitNotCriterion<TVisitor>(NotCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor
    {
      this.whereClause.Append("( NOT ");
      criterion.Criterion.Accept<KqlCriterionVisitor>(this);
      this.whereClause.Append(")");
    }

    public virtual void VisitEqualCriterion<TVisitor>(EqualCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor
    {
      if (this.IsEmbeddedMultiChoiceType(criterion.PropertyName))
        this.VisitLogicalExpression(criterion.PropertyName, ":", (object) ("\"" + criterion.Value + "\""));
      else
        this.VisitLogicalExpression(criterion.PropertyName, "=", (object) ("\"" + criterion.Value + "\""));
    }

    private bool IsEmbeddedMultiChoiceType(string propertyName)
    {
      bool flag = false;
      if (this.knownMappings.ContainsKey(propertyName) && string.Compare(this.knownMappings[propertyName].SharePointType.ToString(), "EmbeddedMultiChoice", true) == 0)
        flag = true;
      return flag;
    }

    public virtual void VisitGreaterThanCriterion<TVisitor>(
      GreaterThanCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      this.VisitLogicalExpression(criterion.PropertyName, ">", criterion.Value);
    }

    public virtual void VisitGreaterThanOrEqualCriterion<TVisitor>(
      GreaterThanOrEqualCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      string empty = string.Empty;
      if (this.IsDateTimeType(criterion.PropertyName))
      {
        string fromSystemDateTime = SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(criterion.Value));
        this.VisitLogicalExpression(criterion.PropertyName, ">=", (object) fromSystemDateTime);
      }
      else
        this.VisitLogicalExpression(criterion.PropertyName, ">=", criterion.Value);
    }

    private bool IsDateTimeType(string propertyName)
    {
      bool flag = false;
      if (this.knownMappings.ContainsKey(propertyName) && string.Compare(this.knownMappings[propertyName].SharePointType.ToString(), "DateTime", true) == 0)
        flag = true;
      return flag;
    }

    public virtual void VisitLessThanCriterion<TVisitor>(
      LessThanCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      this.VisitLogicalExpression(criterion.PropertyName, "<", criterion.Value);
    }

    public virtual void VisitLessThanOrEqualCriterion<TVisitor>(
      LessThanOrEqualCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      string empty = string.Empty;
      if (criterion.PropertyName == "UploadDate")
      {
        string fromSystemDateTime = SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(criterion.Value));
        this.VisitLogicalExpression(criterion.PropertyName, "<=", (object) fromSystemDateTime);
      }
      else
        this.VisitLogicalExpression(criterion.PropertyName, "<=", criterion.Value);
    }

    public virtual void VisitEmptyCriterion<TVisitor>(EmptyCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor => this.whereClause.Append("(1 = 1)");

    public virtual void VisitStartsWithCriterion<TVisitor>(
      StartsWithCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      string str = this.RemapPropertyName(criterion.PropertyName);
      this.whereClause.Append("(");
      for (int index = 0; index < criterion.Values.Length; ++index)
      {
        this.whereClause.AppendFormat("{0}:{1}*", (object) str, (object) criterion.Values[index]);
        if (index < criterion.Values.Length - 1)
          this.whereClause.Append(" OR ");
      }
      this.whereClause.Append(")");
    }

    protected void VisitLogicalExpression(string propertyName, string op, object value) => this.whereClause.AppendFormat("({0}{1}{2})", (object) this.RemapPropertyName(propertyName), (object) op, value);

    private string RemapPropertyName(string propertyName) => this.knownMappings.ContainsKey(propertyName) ? this.knownMappings[propertyName].SharePointName : propertyName;

    internal string Build(IVisitableCriterion criterion)
    {
      criterion.Accept<KqlCriterionVisitor>(this);
      return this.whereClause.ToString();
    }

    private string EncodeFilterValue(string parameterValue)
    {
      string[] strArray1 = new string[9]
      {
        "(",
        ")",
        "&",
        "[",
        "]",
        "|",
        "'",
        ",",
        "\""
      };
      string[] strArray2 = new string[9]
      {
        "(",
        ")",
        "&",
        "[",
        "]",
        "|",
        "'",
        ",",
        "\\\""
      };
      string str = string.Empty;
      for (int index = 0; index < strArray1.Length; ++index)
        str = parameterValue.Replace(strArray1[index], strArray2[index]);
      return str;
    }
  }
}
