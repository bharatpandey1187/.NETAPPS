﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Query.SharePointPropertyType
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

namespace IrisSoftware.iMPACT.Core.Impl.Query
{
  public enum SharePointPropertyType
  {
    Text,
    Number,
    DateTime,
    EmbeddedMultiChoice,
  }
}
