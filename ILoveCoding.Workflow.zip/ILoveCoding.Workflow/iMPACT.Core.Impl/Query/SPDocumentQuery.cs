﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Impl.Query.SPDocumentQuery
// Assembly: iMPACT.Core.Impl, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: ACF8BDC6-AA99-4546-A52B-22458C8D2A30
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.Impl.dll

using IrisSoftware.Core.Logging;
using IrisSoftware.Core.SearchCriteria;
using IrisSoftware.iMPACT.Core.DocumentService;
using IrisSoftware.iMPACT.Core.Query;
using IrisSoftware.iMPACT.Core.Unity;
using Microsoft.Office.Server.Search.Query;
using Microsoft.Practices.Unity;
using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Data;

namespace IrisSoftware.iMPACT.Core.Impl.Query
{
  [Export(typeof (IDocumentQuery))]
  public class SPDocumentQuery : IDocumentQuery
  {
    private bool enableLogging = true;

    public int RowLimit { get; set; }

    public string QueryScope { get; set; }

    protected SPSite QuerySite { get; set; }

    [InjectionConstructor]
    public SPDocumentQuery()
      : this(SPContext.get_Current().get_Site(), "\"iMPACTContentSource\"")
      => this.RowLimit = 500;

    [Dependency]
    public Logger<Modules> Log { get; set; }

    public SPDocumentQuery(SPSite site, string scope)
    {
      this.QuerySite = site;
      this.QueryScope = scope;
    }

    public List<Document> Execute(string docSearchTerms, IVisitableCriterion criterion)
    {
      try
      {
        this.Log.Error(Modules.DocumentSearch, "Execute Query");
        IDictionary<string, QueryFieldMapping> knownMappings = this.GetKnownMappings();
        return this.ExecuteDocumentSearch(docSearchTerms, criterion, knownMappings);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.DocumentSearch, ex.ToString());
        throw;
      }
    }

    private List<Document> ExecuteDocumentSearch(
      string docSearchTerms,
      IVisitableCriterion criterion,
      IDictionary<string, QueryFieldMapping> knownMappings)
    {
      try
      {
        this.Log.Error(Modules.DocumentSearch, "Execute Document Search");
        string str = this.BuildKqlQuery(this.QueryScope, docSearchTerms, criterion, knownMappings);
        this.Log.Error(Modules.DocumentSearch, str);
        return this.ExecuteQuery(str);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.DocumentSearch, ex.ToString());
        throw;
      }
    }

    private List<Document> ExecuteQuery(string kqlQuery)
    {
      try
      {
        this.Log.Error(Modules.DocumentSearch, "Execute Query 2");
        KeywordQuery query = this.BuildKeywordQuery(kqlQuery);
        this.AssignSearchProperties(query);
        return this.ExecuteQuery(query);
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.DocumentSearch, ex.ToString());
        throw;
      }
    }

    private void AssignSearchProperties(KeywordQuery query)
    {
      query.get_SelectProperties().Add("iMPACTRefID");
      query.get_SelectProperties().Add("iMPACTDocCategory");
      query.get_SelectProperties().Add("iMPACTDocSetType");
      query.get_SelectProperties().Add("iMPACTDocType");
      query.get_SelectProperties().Add("iMPACTDocMultiTags");
      query.get_SelectProperties().Add("iMPACTFirmRole");
      query.get_SelectProperties().Add("iMPACTDocTypeOtherDesc");
      query.get_SelectProperties().Add("iMPACTCreateDate");
      query.get_SelectProperties().Add("Title");
      query.get_SelectProperties().Add("Path");
    }

    private List<Document> ExecuteQuery(KeywordQuery query)
    {
      try
      {
        this.Log.Error(Modules.DocumentSearch, "Execute Query Final");
        List<Document> documents = new List<Document>();
        ResultTableCollection resultTableCollection = ((Microsoft.Office.Server.Search.Query.Query) query).Execute();
        this.Log.Error(Modules.DocumentSearch, "Query Results Count " + (object) (resultTableCollection != null ? resultTableCollection.get_Count() : 0));
        using (ResultTable resultTable = resultTableCollection.get_Item(((Microsoft.Office.Server.Search.Query.Query) query).get_ResultTypes()))
        {
          DataTable dataTable = new DataTable();
          dataTable.Load((IDataReader) resultTable, LoadOption.OverwriteChanges);
          this.Log.Error(Modules.DocumentSearch, string.Format("Search Result Count = {0}", (object) dataTable.Rows.Count));
          foreach (DataRow row in (InternalDataCollectionBase) dataTable.Rows)
            this.PopulateDocument(documents, row);
        }
        return documents;
      }
      catch (Exception ex)
      {
        throw;
      }
    }

    private void PopulateDocument(List<Document> documents, DataRow currentRow)
    {
      this.Log.Error(Modules.DocumentSearch, "Populate Document Start");
      Document document = new Document();
      Decimal result1 = 0M;
      DateTime minValue = DateTime.MinValue;
      Decimal result2;
      Decimal.TryParse(Convert.ToString(currentRow["iMPACTRefID"]), out result2);
      document.EntityID = (long) (int) result2;
      document.DocumentURL = Convert.ToString(currentRow["Path"]);
      Decimal result3;
      Decimal.TryParse(Convert.ToString(currentRow["iMPACTDocSetType"]), out result3);
      document.DocSetName = Convert.ToString(Math.Round(result3, 0));
      Decimal result4;
      Decimal.TryParse(Convert.ToString(currentRow["iMPACTDocCategory"]), out result4);
      document.EntityTypeDocTypeCategoryID = Convert.ToString(Math.Round(result4, 0));
      document.DocumentId = "0";
      Decimal.TryParse(Convert.ToString(currentRow["iMPACTDocType"]), out result1);
      document.EntityTypeDocTypeID = Convert.ToString(Math.Round(result1, 0));
      document.DocumentName = Convert.ToString(currentRow["Title"]);
      document.Tags = Convert.ToString(currentRow["iMPACTDocMultiTags"]);
      document.TypeOtherDesc = Convert.ToString(currentRow["iMPACTDocTypeOtherDesc"]);
      documents.Add(document);
      this.Log.Error(Modules.DocumentSearch, "EntityID : " + (object) document.EntityID + "\r\n" + "DocumentURL : " + document.DocumentURL + "\r\n" + "DocumentName : " + document.DocumentName + "\r\n" + "DocSetName : " + document.DocSetName + "\r\n" + "Category : " + document.EntityTypeDocTypeCategoryID + "\r\n" + "DocType : " + document.EntityTypeDocTypeID + "\r\n");
      this.Log.Error(Modules.DocumentSearch, "Populate Document End");
    }

    private KeywordQuery BuildKeywordQuery(string kqlQuery)
    {
      KeywordQuery keywordQuery = new KeywordQuery(this.QuerySite);
      ((Microsoft.Office.Server.Search.Query.Query) keywordQuery).set_ResultTypes((ResultType) 1);
      ((Microsoft.Office.Server.Search.Query.Query) keywordQuery).set_KeywordInclusion((KeywordInclusion) 1);
      ((Microsoft.Office.Server.Search.Query.Query) keywordQuery).set_TrimDuplicates(false);
      ((Microsoft.Office.Server.Search.Query.Query) keywordQuery).set_EnableStemming(true);
      ((Microsoft.Office.Server.Search.Query.Query) keywordQuery).set_RowLimit(this.RowLimit);
      ((Microsoft.Office.Server.Search.Query.Query) keywordQuery).set_QueryText(kqlQuery);
      return keywordQuery;
    }

    private string BuildKqlQuery(
      string scope,
      string docSearchTerms,
      IVisitableCriterion criterion,
      IDictionary<string, QueryFieldMapping> knownMappings)
    {
      this.Log.Error(Modules.DocumentSearch, "Building Kql Query");
      KqlCriterionVisitor criterionVisitor = new KqlCriterionVisitor(knownMappings);
      return string.IsNullOrEmpty(docSearchTerms) ? string.Format("({0}) AND {1}", (object) scope, (object) criterionVisitor.Build(criterion)) : string.Format("({0}) AND ({1}) AND {2}", (object) scope, (object) docSearchTerms, (object) criterionVisitor.Build(criterion));
    }

    private IDictionary<string, QueryFieldMapping> GetKnownMappings()
    {
      Dictionary<string, QueryFieldMapping> dictionary = new Dictionary<string, QueryFieldMapping>();
      try
      {
        dictionary.Add("DocumentRepository", new QueryFieldMapping("DocumentRepository", "DocSetTypeValue", "iMPACTDocSetType", SharePointPropertyType.Text));
        dictionary.Add("DocType", new QueryFieldMapping("DocType", "DocSetTypeValue", "iMPACTDocType", SharePointPropertyType.Text));
        dictionary.Add("DocumentTag", new QueryFieldMapping("DocumentTag", "", "iMPACTDocMultiTags", SharePointPropertyType.Text));
        dictionary.Add("DealNumber", new QueryFieldMapping("DealNumber", "IssueNbr", "iMPACTDealNbr", SharePointPropertyType.Text));
        dictionary.Add("DealName", new QueryFieldMapping("DealName", "IssueName", "iMPACTEntityName", SharePointPropertyType.Text));
        dictionary.Add("DealIssuer", new QueryFieldMapping("DealIssuer", "Issuer", "iMPACTIssuerID", SharePointPropertyType.Text));
        dictionary.Add("DealFirmRoleID", new QueryFieldMapping("DealFirmRoleID", "FirmRole", "iMPACTFirmRole", SharePointPropertyType.Text));
        dictionary.Add("DocumentCategory", new QueryFieldMapping("DocumentCategory", "DocumentCategory", "iMPACTDocCategory", SharePointPropertyType.Text));
        dictionary.Add("DealStateID", new QueryFieldMapping("DealStateID", "State", "iMPACTState", SharePointPropertyType.Text));
        dictionary.Add("UploadDate", new QueryFieldMapping("UploadDate", "BidPricingDateTime", "iMPACTCreateDate", SharePointPropertyType.DateTime));
      }
      catch (Exception ex)
      {
        this.Log.Error(Modules.DocumentSearch, ex.ToString());
        throw;
      }
      return (IDictionary<string, QueryFieldMapping>) dictionary;
    }
  }
}
