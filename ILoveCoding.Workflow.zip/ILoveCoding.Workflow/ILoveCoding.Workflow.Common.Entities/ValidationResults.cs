﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILoveCoding.Workflow.Common.Entities
{
    [Serializable]
    public class ValidationResults : IEnumerable<ValidationResult>, IEnumerable
    {
        private List<ValidationResult> validationResults;

        public ValidationResults() => this.validationResults = new List<ValidationResult>();

        public void AddResult(ValidationResult validationResult) => this.validationResults.Add(validationResult);

        public void AddAllResults(
          IEnumerable<ValidationResult> sourceValidationResults)
        {
            this.validationResults.AddRange(sourceValidationResults);
        }

        public ValidationResults FindAll(TagFilter tagFilter, params string[] tags)
        {
            if (tags == null)
                tags = new string[1];
            ValidationResults validationResults = new ValidationResults();
            foreach (ValidationResult validationResult in (IEnumerable<ValidationResult>)this)
            {
                bool flag = false;
                foreach (string tag in tags)
                {
                    if (tag == null && validationResult.Tag == null || tag != null && tag.Equals(validationResult.Tag))
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag ^ tagFilter == TagFilter.Ignore)
                    validationResults.AddResult(validationResult);
            }
            return validationResults;
        }

        public bool IsValid => this.validationResults.Count == 0;

        public int Count => this.validationResults.Count;

        IEnumerator<ValidationResult> IEnumerable<ValidationResult>.GetEnumerator() => (IEnumerator<ValidationResult>)this.validationResults.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => (IEnumerator)this.validationResults.GetEnumerator();
    }
}
