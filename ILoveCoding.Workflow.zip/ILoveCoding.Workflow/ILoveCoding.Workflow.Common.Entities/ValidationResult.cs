﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILoveCoding.Workflow.Common.Entities
{
    [Serializable]
    public class ValidationResult
    {
        private string message;
        private string key;
        private string tag;
        [NonSerialized]
        private object target;
        [NonSerialized]
        private Validator validator;
        private IEnumerable<ValidationResult> nestedValidationResults;
        private static readonly IEnumerable<ValidationResult> NoNestedValidationResults = (IEnumerable<ValidationResult>)new ValidationResult[0];

        public ValidationResult(
          string message,
          object target,
          string key,
          string tag,
          Validator validator)
          : this(message, target, key, tag, validator, ValidationResult.NoNestedValidationResults)
        {
        }

        public ValidationResult(
          string message,
          object target,
          string key,
          string tag,
          Validator validator,
          IEnumerable<ValidationResult> nestedValidationResults)
        {
            this.message = message;
            this.key = key;
            this.target = target;
            this.tag = tag;
            this.validator = validator;
            this.nestedValidationResults = nestedValidationResults;
        }

        public string Key => this.key;

        public string Message => this.message;

        public string Tag => this.tag;

        public object Target => this.target;

        public Validator Validator => this.validator;

        public IEnumerable<ValidationResult> NestedValidationResults => this.nestedValidationResults;
    }
}
