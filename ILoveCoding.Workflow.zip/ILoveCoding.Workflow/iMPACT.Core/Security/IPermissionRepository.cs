﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Security.IPermissionRepository
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Core.Security
{
  public interface IPermissionRepository
  {
    bool HasPermission(int[] principals, int permission);

    bool HasPermission(int[] principals, long entityId, int permission);

    bool HasAnyPermission(int[] principals, int[] permissions);

    Permission[] GetPermission(int[] principals);

    Permission[] GetPermission(long entityTypeId, long entityId, int[] principals);

    bool CheckPermission(long? entityTypeId, string[] uiName, string permission, int[] principals);

    bool CheckPermission(
      long? entityTypeId,
      List<Tuple<string, string>> uiNamePermissionList,
      int[] principals);

    Permission[] GetPermissionByEntityTypeID(int[] principals, long entityTypeId);

    Permission[] GetPermissionByAppTransIDStatusID(int[] principals, long entityId);

    Permission[] GetIndependentPermission(int[] principals);
  }
}
