﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Security.IAuthorizationService
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using System;
using System.Collections.Generic;

namespace IrisSoftware.iMPACT.Core.Security
{
  public interface IAuthorizationService
  {
    bool HasPermission(IUser user, int permission);

    bool HasPermission(IUser user, long entityTypeId, long entityId, int permission);

    bool HasAnyPermission(IUser user, int[] permissions);

    bool HasAnyPermission(IUser user, long entityTypeId, long entityId, int[] permissions);

    Permission[] GetPermissions(IUser user);

    Permission[] GetPermissions(IUser user, long entityTypeId, long entityId);

    bool HasExecutePermission(IUser user, long? entityTypeId, string[] uiName, string permission);

    bool HasExecutePermission(
      IUser user,
      long? entityTypeId,
      List<Tuple<string, string>> uiNamePermissionList);

    bool HasAnyPermissionOnSet(IUser user, string[] uiNameArry);

    bool HasAnyPermissionOnSet(IUser user, List<Tuple<string, string>> uiNamePermissionList);

    bool HasSecurityPermission(IUser user, long entityTypeId, string uiName, string permission);

    bool HasAccessPermission(
      IUser user,
      long entityTypeId,
      long entityId,
      string uiName,
      string permission);

    bool HasUIPermissionForEntityStatus(
      IUser user,
      long entityId,
      string uiName,
      string permission);

    bool HasUIPermissionForEntityStatus(
      IUser user,
      long entityId,
      string uiName,
      string permission,
      List<long> statusList);

    bool HasUIPermissionForEntityStatusMultiple(
      IUser user,
      long entityId,
      string[] uiName,
      string permission);

    bool HasIndependentPermission(IUser user, string uiName, string permission);

    void FlushEntitySecurityPermissionAppTransIDStatusID();

    void FlushUserEntitySecurityPermissions();
  }
}
