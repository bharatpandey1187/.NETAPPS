﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Security.Sanitizer
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace IrisSoftware.iMPACT.Core.Security
{
  public static class Sanitizer
  {
    private static readonly Dictionary<string, string[]> elementWhiteList = new Dictionary<string, string[]>()
    {
      {
        "p",
        new string[3]{ "style", "class", "align" }
      },
      {
        "div",
        new string[3]{ "style", "class", "align" }
      },
      {
        "span",
        new string[2]{ "style", "class" }
      },
      {
        "br",
        new string[2]{ "style", "class" }
      },
      {
        "hr",
        new string[2]{ "style", "class" }
      },
      {
        "label",
        new string[2]{ "style", "class" }
      },
      {
        "h1",
        new string[2]{ "style", "class" }
      },
      {
        "h2",
        new string[2]{ "style", "class" }
      },
      {
        "h3",
        new string[2]{ "style", "class" }
      },
      {
        "h4",
        new string[2]{ "style", "class" }
      },
      {
        "h5",
        new string[2]{ "style", "class" }
      },
      {
        "h6",
        new string[2]{ "style", "class" }
      },
      {
        "font",
        new string[5]{ "style", "class", "color", "face", "size" }
      },
      {
        "strong",
        new string[2]{ "style", "class" }
      },
      {
        "b",
        new string[2]{ "style", "class" }
      },
      {
        "em",
        new string[2]{ "style", "class" }
      },
      {
        "i",
        new string[2]{ "style", "class" }
      },
      {
        "u",
        new string[2]{ "style", "class" }
      },
      {
        "strike",
        new string[2]{ "style", "class" }
      },
      {
        "ol",
        new string[2]{ "style", "class" }
      },
      {
        "ul",
        new string[2]{ "style", "class" }
      },
      {
        "li",
        new string[2]{ "style", "class" }
      },
      {
        "blockquote",
        new string[2]{ "style", "class" }
      },
      {
        "code",
        new string[2]{ "style", "class" }
      },
      {
        "a",
        new string[4]{ "style", "class", "href", "title" }
      },
      {
        "img",
        new string[10]
        {
          "style",
          "class",
          "src",
          "height",
          "width",
          "alt",
          "title",
          "hspace",
          "vspace",
          "border"
        }
      },
      {
        "table",
        new string[2]{ "style", "class" }
      },
      {
        "thead",
        new string[2]{ "style", "class" }
      },
      {
        "tbody",
        new string[2]{ "style", "class" }
      },
      {
        "tfoot",
        new string[2]{ "style", "class" }
      },
      {
        "th",
        new string[3]{ "style", "class", "scope" }
      },
      {
        "tr",
        new string[2]{ "style", "class" }
      },
      {
        "td",
        new string[3]{ "style", "class", "colspan" }
      },
      {
        "q",
        new string[3]{ "style", "class", "cite" }
      },
      {
        "cite",
        new string[2]{ "style", "class" }
      },
      {
        "abbr",
        new string[2]{ "style", "class" }
      },
      {
        "acronym",
        new string[2]{ "style", "class" }
      },
      {
        "del",
        new string[2]{ "style", "class" }
      },
      {
        "ins",
        new string[2]{ "style", "class" }
      }
    };
    private static readonly string[] encodedCharacters = new string[256];

    static Sanitizer()
    {
      for (int index = 0; index < (int) byte.MaxValue; ++index)
        Sanitizer.encodedCharacters[index] = index >= 48 && index <= 57 || index >= 65 && index <= 90 || index >= 97 && index <= 122 ? (string) null : index.ToString("X2");
    }

    public static string GetSafeHtmlFragment(string html) => Sanitizer.GetSafeHtmlFragment(html, Sanitizer.elementWhiteList);

    public static string ExtractText(string html)
    {
      HtmlDocument htmlDocument = new HtmlDocument();
      htmlDocument.LoadHtml(html);
      foreach (HtmlNode htmlNode in htmlDocument.DocumentNode.Descendants("script").ToArray<HtmlNode>())
        htmlNode.Remove();
      foreach (HtmlNode htmlNode in htmlDocument.DocumentNode.Descendants("style").ToArray<HtmlNode>())
        htmlNode.Remove();
      return htmlDocument.DocumentNode.InnerText;
    }

    public static string GetSafeHtmlFragment(
      string htmlFragment,
      Dictionary<string, string[]> elementWhiteList)
    {
      return Sanitizer.SanitizeHtml(htmlFragment, elementWhiteList);
    }

    private static string SanitizeHtml(
      string htmlText,
      Dictionary<string, string[]> elementWhiteList)
    {
      HtmlDocument htmlDocument = new HtmlDocument();
      htmlDocument.OptionFixNestedTags = true;
      htmlDocument.OptionAutoCloseOnEnd = true;
      htmlDocument.OptionDefaultStreamEncoding = Encoding.UTF8;
      htmlDocument.LoadHtml(htmlText);
      HtmlNode documentNode = htmlDocument.DocumentNode;
      Dictionary<string, string[]> dictionary = elementWhiteList;
      string[] array = dictionary.Keys.ToArray<string>();
      Sanitizer.CleanNodes(documentNode, array);
      foreach (KeyValuePair<string, string[]> keyValuePair in dictionary)
      {
        KeyValuePair<string, string[]> tag = keyValuePair;
        IEnumerable<HtmlNode> htmlNodes = documentNode.DescendantsAndSelf().Where<HtmlNode>((Func<HtmlNode, bool>) (n => n.Name == tag.Key));
        if (htmlNodes != null)
        {
          foreach (HtmlNode htmlNode in htmlNodes)
          {
            if (htmlNode.HasAttributes)
            {
              foreach (HtmlAttribute attribute in htmlNode.Attributes.ToArray<HtmlAttribute>())
              {
                if (!((IEnumerable<string>) tag.Value).Contains<string>(attribute.Name))
                  attribute.Remove();
                else if (Sanitizer.CleanAttributeValues(attribute))
                  attribute.Remove();
              }
            }
          }
        }
      }
      return documentNode.InnerHtml;
    }

    private static void CleanNodes(HtmlNode node, string[] tagWhiteList)
    {
      if (node.NodeType == HtmlNodeType.Element && !((IEnumerable<string>) tagWhiteList).Contains<string>(node.Name))
      {
        node.ParentNode.RemoveChild(node);
      }
      else
      {
        if (node.HasChildNodes)
          Sanitizer.CleanChildren(node, tagWhiteList);
        if (node.NodeType != HtmlNodeType.Text)
          return;
        ((HtmlTextNode) node).Text = HttpUtility.HtmlEncode(HttpUtility.HtmlDecode(node.InnerText));
      }
    }

    private static void CleanChildren(HtmlNode parent, string[] tagWhiteList)
    {
      for (int index = parent.ChildNodes.Count - 1; index >= 0; --index)
        Sanitizer.CleanNodes(parent.ChildNodes[index], tagWhiteList);
    }

    private static bool CleanAttributeValues(HtmlAttribute attribute)
    {
      bool flag = true;
      while (flag)
      {
        flag = false;
        if (Regex.IsMatch(attribute.Value, "/\\*([a]*|[^a]*)\\*/", RegexOptions.IgnoreCase))
          flag = true;
        attribute.Value = Regex.Replace(attribute.Value, "/\\*([a]*|[^a]*)\\*/", "", RegexOptions.IgnoreCase);
        if (Regex.IsMatch(attribute.Value, "\\s*j\\s*a\\s*v\\s*a\\s*s\\s*c\\s*r\\s*i\\s*p\\s*t\\s*", RegexOptions.IgnoreCase) || Regex.IsMatch(attribute.Value, "\\s*v\\s*b\\s*s\\s*c\\s*r\\s*i\\s*p\\s*t\\s*", RegexOptions.IgnoreCase) || Regex.IsMatch(attribute.Value, "\\s*s\\s*c\\s*r\\s*i\\s*p\\s*t\\s*", RegexOptions.IgnoreCase))
          return true;
        if (attribute.Name.ToLower() == "style")
        {
          if (Regex.IsMatch(attribute.Value, "\\s*e\\s*x\\s*p\\s*r\\s*e\\s*s\\s*s\\s*i\\s*o\\s*n\\s*", RegexOptions.IgnoreCase) || Regex.IsMatch(attribute.Value, "\\s*b\\s*e\\s*h\\s*a\\s*v\\s*i\\s*o\\s*r\\s*", RegexOptions.IgnoreCase))
            return true;
          if (Regex.IsMatch(attribute.Value, "-[a-zA-Z\\s]+-", RegexOptions.IgnoreCase))
            flag = true;
          attribute.Value = Regex.Replace(attribute.Value, "-[a-zA-Z\\s]+-", "", RegexOptions.IgnoreCase);
        }
        if (attribute.Name.ToLower() == "media")
        {
          if (Regex.IsMatch(attribute.Value, "-[a-zA-Z\\s]+-", RegexOptions.IgnoreCase))
            flag = true;
          attribute.Value = Regex.Replace(attribute.Value, "-[a-zA-Z\\s]+-", "", RegexOptions.IgnoreCase);
        }
        if (attribute.Name.ToLower() == "href" || attribute.Name.ToLower() == "src")
        {
          if (Regex.IsMatch(attribute.Value, "\\s*m\\s*o\\s*c\\s*h\\s*a\\s*", RegexOptions.IgnoreCase))
            flag = true;
          attribute.Value = Regex.Replace(attribute.Value, "\\s*m\\s*o\\s*c\\s*h\\s*a\\s*", "", RegexOptions.IgnoreCase);
        }
      }
      attribute.Value = HttpUtility.HtmlEncode(attribute.Value);
      StringBuilder stringBuilder = new StringBuilder();
      foreach (char c in attribute.Value.ToCharArray())
        stringBuilder.Append(Sanitizer.EncodeCharacterToHtmlEntityEscape(c));
      attribute.Value = stringBuilder.ToString();
      return false;
    }

    private static string EncodeCharacterToHtmlEntityEscape(char c)
    {
      string str;
      if (c < 'ÿ')
      {
        str = Sanitizer.encodedCharacters[(int) c];
        if (str == null)
          return c.ToString() ?? "";
      }
      else
        str = ((int) c).ToString("X2");
      if (c <= '\x001F' && c != '\t' && (c != '\n' && c != '\r') || c >= '\x007F' && c <= '\x009F')
        str = "fffd";
      return "&#x" + str + ";";
    }
  }
}
