﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Security.EnsureExecutePermissionAttribute
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using System;

namespace IrisSoftware.iMPACT.Core.Security
{
  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
  public class EnsureExecutePermissionAttribute : Attribute
  {
    public int? EntityID { get; set; }

    public string UIName { get; set; }

    public string Permission { get; set; }

    public EnsureExecutePermissionAttribute(string uiName, string permission)
    {
      this.EntityID = new int?();
      this.UIName = uiName;
      this.Permission = permission;
    }

    public EnsureExecutePermissionAttribute(string[] uiName, string permission)
    {
      this.EntityID = new int?();
      this.UIName = string.Join(",", uiName);
      this.Permission = permission;
    }

    public EnsureExecutePermissionAttribute(int entityTypeID, string uiName, string permission)
    {
      this.EntityID = new int?(entityTypeID);
      this.UIName = uiName;
      this.Permission = permission;
    }

    public EnsureExecutePermissionAttribute(int entityTypeID, string[] uiName, string permission)
    {
      this.EntityID = new int?(entityTypeID);
      this.UIName = string.Join(",", uiName);
      this.Permission = permission;
    }
  }
}
