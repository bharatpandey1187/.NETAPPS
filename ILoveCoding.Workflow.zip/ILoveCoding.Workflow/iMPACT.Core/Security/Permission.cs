﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Security.Permission
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

namespace IrisSoftware.iMPACT.Core.Security
{
  public class Permission
  {
    public int PermissionID { get; private set; }

    public string Descr { get; private set; }

    public string GroupName { get; private set; }

    public int ItemOrder { get; private set; }

    public string UIName { get; private set; }

    public int EntityTypeID { get; private set; }

    public int? StateID { get; private set; }

    public string EntityPermission { get; private set; }
  }
}
