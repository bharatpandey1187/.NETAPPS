﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Query.SqlCriterionVisitor
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using IrisSoftware.Core.SearchCriteria;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace IrisSoftware.iMPACT.Core.Query
{
  public class SqlCriterionVisitor : ICriterionVisitor
  {
    protected internal StringBuilder whereClause = new StringBuilder();
    private int parameterCount;
    protected List<SqlParameter> paramList = new List<SqlParameter>();
    private IDictionary<string, string> knownMappings = (IDictionary<string, string>) new Dictionary<string, string>();

    public SqlCriterionVisitor(IDictionary<string, string> knownMappings) => this.knownMappings = knownMappings;

    public virtual void VisitAndCriterion<TVisitor>(AndCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor => this.VisitJunctionCriterion(criterion.Criteria, " and ");

    private void VisitJunctionCriterion(IVisitableCriterion[] criteria, string juncture)
    {
      this.whereClause.Append("(");
      for (int index = 0; index < criteria.Length; ++index)
      {
        criteria[index].Accept<SqlCriterionVisitor>(this);
        if (index < criteria.Length - 1)
          this.whereClause.Append(juncture);
      }
      this.whereClause.Append(")");
    }

    public virtual void VisitOrCriterion<TVisitor>(OrCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor => this.VisitJunctionCriterion(criterion.Criteria, " or ");

    public virtual void VisitContainsCriterion<TVisitor>(
      ContainsCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      string name = this.RemapPropertyName(criterion.PropertyName);
      this.whereClause.Append("(");
      for (int index = 0; index < criterion.Values.Length; ++index)
      {
        SqlParameter sqlParameter = this.AddParameter(name, (object) ("%" + SqlCriterionVisitor.EscapeForLike(criterion.Values[index]) + "%"));
        this.whereClause.AppendFormat("{0} like {1}", (object) name, (object) sqlParameter.ParameterName);
        if (index < criterion.Values.Length - 1)
          this.whereClause.Append(" or ");
      }
      this.whereClause.Append(")");
    }

    public virtual void VisitStartsWithCriterion<TVisitor>(
      StartsWithCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      string name = this.RemapPropertyName(criterion.PropertyName);
      this.whereClause.Append("(");
      for (int index = 0; index < criterion.Values.Length; ++index)
      {
        SqlParameter sqlParameter = this.AddParameter(name, (object) (SqlCriterionVisitor.EscapeForLike(criterion.Values[index]) + "%"));
        this.whereClause.AppendFormat("{0} like {1}", (object) name, (object) sqlParameter.ParameterName);
        if (index < criterion.Values.Length - 1)
          this.whereClause.Append(" or ");
      }
      this.whereClause.Append(")");
    }

    private static string EscapeForLike(string value) => value.Replace("[", "[[]").Replace("_", "[_]").Replace("%", "[%]");

    public virtual void VisitAnyOfCriterion<TVisitor>(AnyOfCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor
    {
      string name = this.RemapPropertyName(criterion.PropertyName);
      this.whereClause.Append("(").Append(name).Append(" in (");
      for (int index = 0; index < criterion.Values.Length; ++index)
      {
        this.whereClause.Append(this.AddParameter(name, criterion.Values[index]).ParameterName);
        if (index < criterion.Values.Length - 1)
          this.whereClause.Append(", ");
      }
      this.whereClause.Append("))");
    }

    public virtual void VisitNotCriterion<TVisitor>(NotCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor
    {
      this.whereClause.Append("(not");
      criterion.Criterion.Accept<SqlCriterionVisitor>(this);
      this.whereClause.Append(")");
    }

    public virtual void VisitEqualCriterion<TVisitor>(EqualCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor => this.VisitLogicalExpression(criterion.PropertyName, "=", criterion.Value);

    public virtual void VisitGreaterThanCriterion<TVisitor>(
      GreaterThanCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      this.VisitLogicalExpression(criterion.PropertyName, ">", criterion.Value);
    }

    public virtual void VisitGreaterThanOrEqualCriterion<TVisitor>(
      GreaterThanOrEqualCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      this.VisitLogicalExpression(criterion.PropertyName, ">=", criterion.Value);
    }

    public virtual void VisitLessThanCriterion<TVisitor>(
      LessThanCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      this.VisitLogicalExpression(criterion.PropertyName, "<", criterion.Value);
    }

    public virtual void VisitLessThanOrEqualCriterion<TVisitor>(
      LessThanOrEqualCriterion criterion,
      TVisitor visitor)
      where TVisitor : ICriterionVisitor
    {
      this.VisitLogicalExpression(criterion.PropertyName, "<=", criterion.Value);
    }

    public virtual void VisitEmptyCriterion<TVisitor>(EmptyCriterion criterion, TVisitor visitor) where TVisitor : ICriterionVisitor => this.whereClause.Append("(1 = 1)");

    protected void VisitLogicalExpression(string propertyName, string op, object value)
    {
      string str = this.RemapPropertyName(propertyName);
      SqlParameter sqlParameter = this.AddParameter(propertyName, value);
      this.whereClause.AppendFormat("({0} {1} {2})", (object) str, (object) op, (object) sqlParameter.ParameterName);
    }

    private string RemapPropertyName(string propertyName) => this.knownMappings.ContainsKey(propertyName) ? this.knownMappings[propertyName] : propertyName;

    protected virtual SqlParameter AddParameter(string name, object value)
    {
      SqlParameter sqlParameter = new SqlParameter(this.BuildParameterName(), value);
      this.paramList.Add(sqlParameter);
      return sqlParameter;
    }

    protected virtual string BuildParameterName()
    {
      ++this.parameterCount;
      return "@p" + (object) this.parameterCount;
    }

    public SqlCriterionVisitResult Build(IVisitableCriterion criterion)
    {
      criterion.Accept<SqlCriterionVisitor>(this);
      return new SqlCriterionVisitResult()
      {
        WhereClause = this.whereClause.ToString(),
        Parameters = this.paramList.ToArray()
      };
    }
  }
}
