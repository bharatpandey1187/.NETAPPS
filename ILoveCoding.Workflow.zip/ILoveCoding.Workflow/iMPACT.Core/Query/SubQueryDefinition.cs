﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Query.SubQueryDefinition
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

namespace IrisSoftware.iMPACT.Core.Query
{
  public class SubQueryDefinition
  {
    public string Field { get; set; }

    public string Operator { get; set; }

    public string Value { get; set; }
  }
}
