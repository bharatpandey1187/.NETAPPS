﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Query.SqlCriterionVisitResult
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using System.Data.SqlClient;

namespace IrisSoftware.iMPACT.Core.Query
{
  public class SqlCriterionVisitResult
  {
    public string WhereClause { get; set; }

    public SqlParameter[] Parameters { get; set; }
  }
}
