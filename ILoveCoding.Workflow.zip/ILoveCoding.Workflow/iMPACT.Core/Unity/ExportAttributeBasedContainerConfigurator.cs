﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.Unity.ExportAttributeBasedContainerConfigurator
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace IrisSoftware.iMPACT.Core.Unity
{
  public class ExportAttributeBasedContainerConfigurator
  {
    private Type exportAttribute = typeof (ExportAttribute);

    public void ConfigureContainer(IUnityContainer container, Assembly assembly)
    {
      foreach (Type t in ((IEnumerable<Type>) assembly.GetExportedTypes()).Where<Type>((Func<Type, bool>) (t => !t.IsAbstract && !t.IsInterface && ((IEnumerable<object>) t.GetCustomAttributes(this.exportAttribute, false)).Any<object>())))
        this.RegisterType(container, t);
    }

    private void RegisterType(IUnityContainer container, Type t)
    {
      ExportAttribute exportAttribute = (ExportAttribute) ((IEnumerable<object>) t.GetCustomAttributes(this.exportAttribute, false)).FirstOrDefault<object>();
      LifetimeManager lifeTimeManager = this.GetLifeTimeManager(exportAttribute.LifeTime);
      container.RegisterType(exportAttribute.ExportedType, t, exportAttribute.Name, lifeTimeManager);
    }

    private LifetimeManager GetLifeTimeManager(LifeTime lifeTime)
    {
      switch (lifeTime)
      {
        case LifeTime.Transient:
          return (LifetimeManager) new PerResolveLifetimeManager();
        case LifeTime.SingleInstance:
          return (LifetimeManager) new ContainerControlledLifetimeManager();
        case LifeTime.SingleInstancePerRequest:
          return (LifetimeManager) new HierarchicalLifetimeManager();
        default:
          return (LifetimeManager) new TransientLifetimeManager();
      }
    }
  }
}
