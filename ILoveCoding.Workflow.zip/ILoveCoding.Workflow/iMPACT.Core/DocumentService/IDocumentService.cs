﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.DocumentService.IDocumentService
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace IrisSoftware.iMPACT.Core.DocumentService
{
  public interface IDocumentService
  {
    Document CheckIn(Document document, string comments);

    Document CheckOut(Document document);

    Document UndoCheckOut(Document document);

    DocSetInfo CreateDocSet(
      DocSetInfo docSetInfo,
      List<DocSetPermission> documentSetPermissions,
      Hashtable sharedFields);

    Document Upload(Document document, byte[] bytes);

    Document Upload(
      Document document,
      byte[] bytes,
      Dictionary<string, string> sharedFields);

    void UpdateSharedFields(string entityType, string docSetId, Hashtable sharedFields);

    Document UpdateSharedFields(Document document, Dictionary<string, string> sharedFields);

    void ApplyPermission(
      string entityType,
      string docSetId,
      List<DocSetPermission> issueDocSetPermissions);

    void ApplyPermission(
      string entityType,
      string docSetId,
      List<DocSetPermission> issueDocSetPermissions,
      Hashtable sharedFields);

    void Delete(Document doc);

    List<Document> Move(string[] srcFileUrls, DocSetInfo docSetInfo);

    List<Document> Move(List<Document> documentsToMoveList, DocSetInfo docSetInfo);

    Stream Download(Document doc);

    List<Document> GetDocuments(string entityType, string docSetId);

    bool IsFileExists(Document doc);

    string GetVersionHistoryUrl();
  }
}
