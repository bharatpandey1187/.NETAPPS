﻿// Decompiled with JetBrains decompiler
// Type: IrisSoftware.iMPACT.Core.DocumentService.Document
// Assembly: iMPACT.Core, Version=1.0.0.0, Culture=neutral, PublicKeyToken=4fa02899a5d95bc5
// MVID: 3D281991-A499-4B40-83FD-C5237A473B7A
// Assembly location: E:\IRIS Data\Bharat\Books & Others\iMPACT.MS\iMPACT.Core.dll

using System;

namespace IrisSoftware.iMPACT.Core.DocumentService
{
  [Serializable]
  public class Document
  {
    public long EntityDocSetDocumentID { get; set; }

    public long EntityDocSetID { get; set; }

    public long EntityID { get; set; }

    public string DocSetId { get; set; }

    public string DocSetName { get; set; }

    public string DocSetURL { get; set; }

    public string DocumentId { get; set; }

    public string DocumentName { get; set; }

    public string DocumentURL { get; set; }

    public string DocumentListID { get; set; }

    public string CheckOutDocumentId { get; set; }

    public string UIVersionLabel { get; set; }

    public int TotalVersion { get; set; }

    public string CheckOutType { get; set; }

    public string LastModifiedBy { get; set; }

    public DateTime LastModifiedOn { get; set; }

    public string CheckedOutBy { get; set; }

    public DateTime? CheckedOutDate { get; set; }

    public DateTime? CheckedOutExpires { get; set; }

    public string StorageKey { get; set; }

    public string EntityType { get; set; }

    public string EntityTypeDocTypeCategoryID { get; set; }

    public string EntityTypeDocTypeID { get; set; }

    public string TypeOtherDesc { get; set; }

    public string Tags { get; set; }

    public bool ExistsInSameDocSet { get; set; }
  }
}
