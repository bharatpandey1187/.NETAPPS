USE [XJTCrew]
GO

/****** Object:  UserDefinedFunction [dbo].[rs_s_MyAircraftQuals]    Script Date: 8/27/2020 10:06:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[rs_s_MyAircraftQuals](@EmpNo VARCHAR(7), @Position VARCHAR(2))
RETURNS VARCHAR(50)
AS
BEGIN

    DECLARE @MyAC VARCHAR(50)
    SET @MyAC = ''

    IF @Position = 'FF'
        SET @Position = 'FA'

    --Get the distinct aircraft list, along with a correct sort column
    ;WITH xyz AS
    (SELECT DISTINCT Aircraft, CASE WHEN Aircraft = 'CRJ' THEN 1 ELSE 2 END AS Sort1
     FROM CTQualification q
     WHERE q.EmpNo = @EmpNo
     AND (q.PositionCode = @Position OR (@Position = 'FA' AND q.PositionCode = 'FF'))
     AND q.DequalDate >= CONVERT(DATE, GETDATE())
     )

    --Concatenate using FOR XML PATH.  Use STUFF to suppress the first comma.
    --The TYPE parameter forces it to return an xml data type.
    --The .value method performs an XQuery call and converts to VARCHAR(MAX)
    SELECT @MyAC = STUFF((SELECT ',' + x.Aircraft
                          FROM xyz x
                          ORDER BY x.Sort1
                          FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)')
                   , 1,1,'')

    RETURN @MyAC
END
GO


