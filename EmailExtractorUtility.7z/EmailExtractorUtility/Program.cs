﻿

namespace EmailExtractorUtility
{
    using OpenPop.Mime;
    using OpenPop.Mime.Header;
    using OpenPop.Pop3;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.IO;
    using System.Net.Mail;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Web;
    class Program
    {
        private static string MailServer;
        private static int MailServerPort;
        private static string MailServer2 = "";
        private static int MailServer2Port;
        private static string MailUser;
        private static string MailPassword;
        private static string SqlServer;
        private static string SqlDB;
        private static string AttachmentPath;
        private static string LogFilePath;
        private static string StoredProcName;
        private static string RecipientFilter;
        private static string AppTitle;
        private static string CrewDbConnectionString;
        public static bool IsSSL;

        private static string CleanAddress(string email)
        {
            int index = email.IndexOf('<');
            string str = email;
            if ((index >= 0) && (index < email.Length))
            {
                str = email.Substring(index + 1, (email.Length - index) - 1);
                index = str.IndexOf('>');
                if (index >= 0)
                {
                    str = str.Substring(0, index);
                }
            }
            return str;
        }

        private static string DownloadEmail()
        {
            SqlConnection connection = new SqlConnection(CrewDbConnectionString);
            SqlCommand command = new SqlCommand("", connection);
            Pop3Client client = new Pop3Client();
            List<int> list2 = new List<int>();
            string str5 = "";
            bool flag = false;
            try
            {
                try
                {
                    Console.WriteLine("MailServer=" + MailServer);
                    Console.WriteLine(client.ToString());
                    client.Connect(MailServer, MailServerPort, IsSSL);
                    client.Authenticate(MailUser, MailPassword,AuthenticationMethod.UsernameAndPassword);
                }
                catch (Exception exception)
                {
                    if (MailServer2 == "")
                    {
                        throw exception;
                    }
                    flag = true;
                    try
                    {
                        client.Disconnect();
                    }
                    catch
                    {
                    }
                }
                if (flag)
                {
                    Console.WriteLine("MailServer=" + MailServer2);
                    Console.WriteLine(client.ToString());
                    client.Connect(MailServer2, MailServer2Port, IsSSL);
                    client.Authenticate(MailUser, MailPassword, AuthenticationMethod.UsernameAndPassword);
                }
                int messageCount = client.GetMessageCount();
                try
                {
                    if (messageCount > 0)
                    {
                        connection.Open();
                        try
                        {
                            Console.WriteLine("Total Messages: " + messageCount);
                            int item = 1;
                            string deleteEmail = ConfigurationManager.AppSettings["DeleteEmails"].ToUpper().Trim();
                            while (true)
                            {
                                if (item > messageCount)
                                {
                                    if (deleteEmail == "TRUE")
                                    {
                                        foreach (int num7 in list2)
                                        {
                                            client.DeleteMessage(num7);
                                        }
                                    }
                                    break;
                                }
                                Message message = client.GetMessage(item);
                                try
                                {
                                    DateTime now;
                                    DateTime minValue;
                                    string str8 = (message.Headers.Subject != null) ? message.Headers.Subject.Trim() : "(no subject)";
                                    if (str8.ToUpper().Trim().StartsWith("[EXTERNAL] -"))
                                    {
                                        str8 = str8.Substring(12).Trim();
                                    }
                                    string str9 = (message.Headers.From != null) ? message.Headers.From.Address : "";
                                    Console.WriteLine(str8);
                                    string s = "";
                                    MessagePart part = message.FindFirstHtmlVersion();
                                    if (part == null)
                                    {
                                        part = message.FindFirstPlainTextVersion();
                                    }
                                    s = (part == null) ? "error decoding email" : part.GetBodyAsText();
                                    if ((s.IndexOf("<br", StringComparison.CurrentCultureIgnoreCase) < 0) && ((s.IndexOf("<p", StringComparison.CurrentCultureIgnoreCase) < 0) && (s.IndexOf("<div", StringComparison.CurrentCultureIgnoreCase) < 0)))
                                    {
                                        s = s.Replace("\r\n", "<br />").Replace("\n", "<br />");
                                    }
                                    s = s.Replace("\x00ef\x00bb\x00bf", "");
                                    StringBuilder builder = new StringBuilder();
                                    StringBuilder builder2 = new StringBuilder();
                                    foreach (RfcMailAddress address in message.Headers.To)
                                    {
                                        if (address.HasValidMailAddress && (address.Address.Trim() != ""))
                                        {
                                            builder.Append(CleanAddress(address.Address) + ";");
                                        }
                                    }
                                    foreach (RfcMailAddress address2 in message.Headers.Cc)
                                    {
                                        if (address2.HasValidMailAddress && (address2.Address.Trim() != ""))
                                        {
                                            builder2.Append(CleanAddress(address2.Address) + ";");
                                        }
                                    }
                                    if (((builder.Length == 0) && (builder2.Length == 0)) && (message.Headers.UnknownHeaders["Delivered-To"] != null))
                                    {
                                        string str7 = CleanAddress(message.Headers.UnknownHeaders["Delivered-To"].Trim());
                                        if (str7.Contains(";"))
                                        {
                                            str7 = str7.Substring(0, str7.IndexOf(';')).Trim();
                                        }
                                        if (str7.Contains("@") && str7.Contains("."))
                                        {
                                            builder.Append(str7);
                                        }
                                    }
                                    try
                                    {
                                        minValue = DateTime.MinValue;
                                        foreach (Received received in message.Headers.Received)
                                        {
                                            if (received.Date > minValue)
                                            {
                                                minValue = received.Date;
                                            }
                                        }
                                        if (minValue == DateTime.MinValue)
                                        {
                                            minValue = DateTime.Now.ToUniversalTime();
                                        }
                                        now = minValue.ToLocalTime();
                                    }
                                    catch
                                    {
                                        now = DateTime.Now;
                                        minValue = DateTime.UtcNow;
                                    }
                                    List<MessagePart> list = message.FindAllAttachments();
                                    int num4 = 0;
                                    int num5 = 0;
                                    while (true)
                                    {
                                        string str4;
                                        if (num5 >= list.Count)
                                        {
                                            string str2 = StripHTML(s);
                                            if ((RecipientFilter == "") || (builder.ToString().ToLower().Contains(RecipientFilter) || builder2.ToString().ToLower().Contains(RecipientFilter)))
                                            {
                                                object[] objArray1 = new object[0x16];
                                                objArray1[0] = StoredProcName;
                                                objArray1[1] = " '";
                                                objArray1[2] = str9.Replace("'", "''");
                                                objArray1[3] = "', '";
                                                objArray1[4] = builder.ToString().Replace("'", "''");
                                                objArray1[5] = "', '";
                                                objArray1[6] = builder2.ToString().Replace("'", "''");
                                                objArray1[7] = "', '";
                                                objArray1[8] = str8.Replace("'", "''");
                                                objArray1[9] = "', '";
                                                objArray1[10] = str2.Replace("'", "''");
                                                objArray1[11] = "', '";
                                                objArray1[12] = s.Replace("'", "''");
                                                objArray1[13] = "', '";
                                                objArray1[14] = now.ToString("yyyy-MM-dd HH:mm:ss");
                                                objArray1[15] = "', '";
                                                objArray1[0x10] = minValue.ToString("yyyy-MM-dd HH:mm:ss");
                                                objArray1[0x11] = "', '";
                                                objArray1[0x12] = num4;
                                                objArray1[0x13] = "', '";
                                                objArray1[20] = Encoding.GetEncoding(0x4e4).GetString(message.RawMessage).Replace("'", "''");
                                                objArray1[0x15] = "' ";
                                                command.CommandText = string.Concat(objArray1);
                                                string str3 = command.ExecuteScalar().ToString();
                                                if (num4 > 0)
                                                {
                                                    if (!Directory.Exists(AttachmentPath + str3))
                                                    {
                                                        Directory.CreateDirectory(AttachmentPath + str3);
                                                    }
                                                    for (int i = 0; i < list.Count; i++)
                                                    {
                                                        str4 = list[i].FileName;
                                                        if ((str4 != "") && (str4.ToLower() != "body.htm"))
                                                        {
                                                            int num3 = 0;
                                                            string path = AttachmentPath + str3 + @"\" + str4;
                                                            while (true)
                                                            {
                                                                if (!File.Exists(path))
                                                                {
                                                                    list[i].Save(new FileInfo(path));
                                                                    break;
                                                                }
                                                                num3++;
                                                                object[] objArray2 = new object[] { AttachmentPath, str3, @"\", num3, "_", str4 };
                                                                path = string.Concat(objArray2);
                                                            }
                                                        }
                                                    }
                                                }
                                                list2.Add(item);
                                            }
                                            break;
                                        }
                                        str4 = list[num5].FileName;
                                        if ((str4 != "") && (str4.ToLower() != "body.htm"))
                                        {
                                            num4++;
                                        }
                                        num5++;
                                    }
                                }
                                catch (Exception exception2)
                                {
                                    object[] objArray3 = new object[] { str5, "____________________\r\n\r\n", exception2.ToString(), "\r\n- - - - - - - -\r\nRAW MESSAGE:", message, "\r\n\r\n" };
                                    str5 = string.Concat(objArray3);
                                }
                                item++;
                            }
                        }
                        finally
                        {
                            connection?.Close();
                        }
                    }
                }
                finally
                {
                    try
                    {
                        client?.Dispose();
                    }
                    catch
                    {
                    }
                }
            }
            catch (Exception exception3)
            {
                str5 = "Error connecting to POP3 server: " + exception3.ToString();
            }
            return str5;
        }

        public static void LogError(string errmsg)
        {
            if (!Directory.Exists(Path.GetDirectoryName(LogFilePath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(LogFilePath));
            }
            int num = 0;
            while (true)
            {
                if (num < 3)
                {
                    try
                    {
                        using (StreamWriter writer = new StreamWriter(LogFilePath, true))
                        {
                            writer.WriteLine("______________________________\r\n" + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt") + "\r\n" + errmsg);
                        }
                    }
                    catch
                    {
                        Thread.Sleep(0xbb8);
                        num++;
                        continue;
                    }
                }
                break;
            }
            Console.WriteLine(errmsg);
        }

        private static int Main(string[] args)
        {
            Console.WriteLine("Start Cycle");
            string errmsg = "";
            int num = 0;
            try
            {
                AppTitle = ConfigurationManager.AppSettings["AppTitle"];
                if (AppTitle == null)
                {
                    AppTitle = "Email Extractor";
                }
            }
            catch
            {
                AppTitle = "Email Extractor";
            }
            MailServer = ConfigurationManager.AppSettings["MailServer"];
            if (ConfigurationManager.AppSettings["MailServer2"] != null)
            {
                MailServer2 = ConfigurationManager.AppSettings["MailServer2"];
            }
            MailUser = ConfigurationManager.AppSettings["MailUser"];
            MailPassword = ConfigurationManager.AppSettings["MailPassword"];
            SqlServer = ConfigurationManager.AppSettings["SQLServer"];
            SqlDB = ConfigurationManager.AppSettings["SQLDB"];
            AttachmentPath = ConfigurationManager.AppSettings["AttachmentPath"];
            StoredProcName = ConfigurationManager.AppSettings["StoredProcName"];
            RecipientFilter = ConfigurationManager.AppSettings["RecipientFilter"];
            RecipientFilter = (RecipientFilter != null) ? RecipientFilter.ToLower().Trim() : "";
            CrewDbConnectionString = ConfigurationManager.AppSettings["CrewDbConnectionString"];
            MailServerPort = int.Parse(ConfigurationManager.AppSettings["MailServerPort"]);
            MailServer2Port = int.Parse(ConfigurationManager.AppSettings["MailServer2Port"]);
            IsSSL = bool.Parse(ConfigurationManager.AppSettings["IsSSL"]);
            string currentLocationPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            if (!AttachmentPath.EndsWith(@"\"))
            {
                AttachmentPath = AttachmentPath + @"\";
            }
            string[] textArray1 = new string[] { Path.GetDirectoryName(currentLocationPath), @"\Log\", Path.ChangeExtension(Path.GetFileName(currentLocationPath), null), DateTime.Today.ToString("_yyyyMMdd"), ".log" };
            LogFilePath = string.Concat(textArray1);
            try
            {
                errmsg = errmsg + DownloadEmail();
            }
            catch (Exception exception)
            {
                errmsg = errmsg + "____________________\r\nUNKNOWN ERROR:\r\n" + exception.ToString() + "\r\n\r\n";
                Console.WriteLine("Error Found");
            }
            if (errmsg != "")
            {
                string[] textArray2 = new string[] { @"<html><body><a href='\\", Environment.MachineName, @"\", LogFilePath.Replace(":", "$"), "'>View Log</a><br>\r\n", errmsg.Replace("\r\n", "<br>\r\n"), "</body></html>" };
                SendEmail(ConfigurationManager.AppSettings["AdminEmail"], "Load Error", string.Concat(textArray2), true);
                LogError(errmsg);
                num = 13;
            }
            return num;
        }

        private static string RemoveHTMLBlock(string tagname, string s)
        {
            int index = s.IndexOf("<" + tagname, StringComparison.CurrentCultureIgnoreCase);
            int num2 = s.IndexOf("</" + tagname + ">", StringComparison.CurrentCultureIgnoreCase);
            if (num2 >= 0)
            {
                num2 += tagname.Length + 2;
            }
            if ((index >= 0) && (num2 > index))
            {
                s = s.Remove(index, (num2 - index) + 1);
            }
            return s;
        }

        private static void SendEmail(string recipient, string subject, string body, bool html)
        {
            try
            {
                MailMessage message = new MailMessage(AppTitle + " (" + Environment.MachineName + ")<donotreply@skywest.com>", recipient, subject, body)
                {
                    IsBodyHtml = html
                };
                new SmtpClient(ConfigurationManager.AppSettings["SMTPServer"]).Send(message);
                Console.WriteLine("Sending Error Email to:" + recipient);
            }
            catch (Exception exception)
            {
                LogError("____________________\r\nSEND MAIL ERROR\r\n____________________\r\n" + exception.ToString() + "\r\n____________________\r\n");
            }
        }

        private static string StripHTML(string s)
        {
            try
            {
                s = RemoveHTMLBlock("head", s);
                s = RemoveHTMLBlock("style", s);
                s = RemoveHTMLBlock("script", s);
                if (s.ToUpper().Contains("<BR") || (s.ToUpper().Contains("<DIV") || s.ToUpper().Contains("<P>")))
                {
                    s = s.Replace("\r\n", " ");
                }
                return HttpUtility.HtmlDecode(Regex.Replace(s.Replace("\r\n", "\x00ff").Replace("<br>", "\x00ff").Replace("<br />", "\x00ff").Replace("<BR>", "\x00ff").Replace("<BR />", "\x00ff").Replace("<p", "\x00ff<p").Replace("<P", "\x00ff<p").Replace("<div", "\x00ff<div").Replace("<DIV", "\x00ff<div").Replace("&nbsp;", " "), "<[^>]+?>", "")).Replace("\x00ff", "\r\n");
            }
            catch
            {
                return s;
            }
        }
    }
}
