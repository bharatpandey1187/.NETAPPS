$( document ).ready( function( ) {

$( "#tabs-Main" ).tabs();
             bindTreeView('Manuals',"tabs-Manuals");  
			 
			// updateURL('Manuals');
    $( '.tree li' ).each( function() {
        if( $( this ).children( 'ul' ).length > 0 ) {
            $( this ).addClass( 'parent' );     
        }
    });
 
    $( '.tree li.parent > a' ).click( function( ) {
        $( this ).parent().toggleClass( 'active' );
        $( this ).parent().children( 'ul' ).slideToggle( 'fast' );
    });
 
    $( '#all' ).click( function() {
 
        $( '.tree li' ).each( function() {
            $( this ).toggleClass( 'active' );
            $( this ).children( 'ul' ).slideToggle( 'fast' );
        });
    });
	
 
// sortList();
 
});
        var sMenuString = "";
        var rootFolders;
var getInternalDocName = "MX"; 
        
function updateURL(value) {
      if (history.pushState) {
                  getInternalDocName = window.location.pathname.substring(window.location.pathname.lastIndexOf("/") + 1);
                  getInternalDocName = getInternalDocName.substr(0, getInternalDocName.indexOf('.'));
        var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?'+getInternalDocName+'='+value;

                
 window.history.pushState({path:newurl},'',newurl);
             
 }
    }

        function bindTreeView(search,selectedtab) {
            try {
                var div = document.getElementById(selectedtab);
                // getInternalDocName = window.location.pathname.substring(window.location.pathname.lastIndexOf("/") + 1);
                 // getInternalDocName = getInternalDocName.substr(0, getInternalDocName.indexOf('.'));                
//alert(_spPageContextInfo.webAbsoluteUrl);
                sMenuString = "";
                $.ajax({
                    url: _spPageContextInfo.webAbsoluteUrl + "/_api/lists/getbytitle('"+getInternalDocName+"')/items?$expand=Folder&$select=ID,Title,EncodedAbsUrl,FileRef,FSObjType,FileLeafRef,Folder/ServerRelativeUrl&$top=5000&$orderby=ID%20asc", //assuming web part is added on same site :)  
                    type: "GET",
                    headers: { "accept": "application/json;odata=verbose" },
                    async: false,
                    success: function (docsData) {
                        if (docsData.d.results.length > 0) {
                            var getValues = docsData.d.results; 
                       getValues=     getValues.sort(function(a, b) {
  var nameA = a.FileLeafRef.toUpperCase(); // ignore upper and lowercase
  var nameB = b.FileLeafRef.toUpperCase(); // ignore upper and lowercase
  if (nameA < nameB) {
    return -1;
  }
  if (nameA > nameB) {
    return 1;
  }

  // names must be equal
  return 0;
});
                            rootFolders = $.grep(getValues, function (e) {
                                if (e.EncodedAbsUrl.split(getInternalDocName + "/")[1] != null) {
                                    return e.EncodedAbsUrl.split(getInternalDocName + "/")[1].split('/').length == 1;
                                }
                            }); 
                           sMenuString += "<ul id='rootlist'>";
                            $.each(rootFolders, function (i, rootFolder) {
							
                               sMenuString += "<li class='parent image'><a style='display:table;'>" + rootFolder.FileLeafRef + "</a>";

                                if (rootFolder.FSObjType == 1) {
                                    sMenuString += "<ul>";
                                    SubFoldersFiles(getValues, rootFolder.FileLeafRef.replace(/ /g, '%20'), rootFolder.EncodedAbsUrl);
                                    sMenuString += "</ul>";
                               
                                sMenuString += "</li>";
								}
                            });
                               

                            sMenuString += "</ul>";
                            div.innerHTML = sMenuString;

                        }
                    }
                });
            } catch (e) {
              alert(e.message);
            }
            return false;
        }

        function SubFoldersFiles(listItems, currentItem, fullUrl) {
            var items = [];
            var subItems = $.grep(listItems, function (e) {
                if (e.EncodedAbsUrl.split(fullUrl + "/").length > 1) {
                    var fileUrl = e.EncodedAbsUrl.split(fullUrl + "/")[1];
                    if (fileUrl.split("/").length == 1) {
                        return true;
                    }
                }
            });

            if (subItems.length > 0) {
                $.each(subItems, function (i, subItem) {

                    if (subItem.FSObjType == 1) {
                        sMenuString += "<li class='parent image'><a>" + subItem.FileLeafRef + "</a>";
                        sMenuString += "<ul>";
                       
                        SubFoldersFiles(listItems, subItem.FileLeafRef.replace(/ /g, '%20'), subItem.EncodedAbsUrl);
                        sMenuString += "</ul>";
                    }
                    else {
                       if((subItem.Title==null))
                        {
sMenuString += "<li class='image1' style='padding-left: 20px;'><a target='_blank' href='" + encodeURI(subItem.FileRef).replace("\'",'%27') +"?web=1"+ "'>" + subItem.FileLeafRef.substring(0,subItem.FileLeafRef.lastIndexOf('.')) + "</a></li>";
                        }
                        else{
sMenuString += "<li class='image1' style='padding-left: 20px;'><a target='_blank' href='" + encodeURI(subItem.FileRef).replace("\'",'%27')  +"?web=1"+ "'>" + subItem.Title + "</a></li>";

                        }
                    }
                });
            }
        }
        
        