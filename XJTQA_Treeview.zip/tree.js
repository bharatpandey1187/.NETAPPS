var sMenuString = "";
var rootFolders;
//var getInternalDocName = "Company";
var getInternalDocName;
getInternalDocName = window.location.pathname.substring(window.location.pathname.lastIndexOf("/") + 1);
getInternalDocName = getInternalDocName.substr(0, getInternalDocName.indexOf('.'));
var expandFolderjson={};
var IsExists=false;

$( document ).ready( function( ) {
$( "#tabs-Main" ).tabs();
$( "#tabs-Main" ).css("display", "block");
 getFolderExpand();
             bindTreeView('Manuals',"tabs-Manuals"); 
			 bindTreeView('Bulletins',"tabs-Bulletins");
			 bindTreeView('Form',"tabs-Form");
			 bindTreeView('eForms',"tabs-eForms");
			// bindTreeView('Manuals',"tabs-Manuals"); 
			 
			 // Would write the value of the QueryString-variable called name to the console 
console.log(getQueryStringValue(getInternalDocName));
			
			 if(typeof getQueryStringValue(getInternalDocName)==="undefined" || getQueryStringValue(getInternalDocName)=='' || getQueryStringValue(getInternalDocName)==null){
			 updateURL('Manuals');
			 }else{
 activaTab('tabs-'+getQueryStringValue(getInternalDocName));

             }
    $( '.tree li' ).each( function() {
        if( $( this ).children( 'ul' ).length > 0 ) {
            $( this ).addClass( 'parent' );     
        }
    });
 
    $( '.tree li.parent > a' ).click( function( ) {
        $( this ).parent().toggleClass( 'active' );
        $( this ).parent().children( 'ul' ).slideToggle( 'fast' );
    });
 
    $( '#all' ).click( function() {
 
        $( '.tree li' ).each( function() {
            $( this ).toggleClass( 'active' );
            $( this ).children( 'ul' ).slideToggle( 'fast' );
        });
    });
	  
    $(document).on('click', 'a[name=a-tabs-Bulletins]', function(e) {
        updateURL('Bulletins')
    });
	$(document).on('click', 'a[name=a-tabs-Form]', function(e) {
        updateURL('Form')
    });
	$(document).on('click', 'a[name=a-tabs-eForms]', function(e) {
        updateURL('eForms')
    });
	$(document).on('click', 'a[name=a-tabs-Manuals]', function(e) {
        updateURL('Manuals')
    });
 
 
});
 
function activaTab(tab){ 
    $('.nav-tabs').children().removeClass('ui-tabs-active ui-state-active');
    $('.nav-tabs a[href="#' + tab + '"]').parent().addClass('ui-tabs-active ui-state-active');
    $( '#'+tab ).css("display", "block"); 
     $( '#'+tab ).siblings().not(".nav-tabs").css("display", "none"); 
};
function getQueryStringValue (key) {  
  return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));  
} 
function updateURL(value) {
    activaTab('tabs-'+value);
      if (history.pushState) {
          var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?'+getInternalDocName+'='+value;
          window.history.pushState({path:newurl},'',newurl);
      }
    }

function bindTreeView(search,selectedtab) {
            try {
                var div = document.getElementById(selectedtab);

                sMenuString = "";
                $.ajax({
                    url: _spPageContextInfo.webAbsoluteUrl + "/_api/lists/getbytitle('"+getInternalDocName+"')/items?$expand=Folder&$select=ID,Title,EncodedAbsUrl,FileRef,FSObjType,FileLeafRef,Folder/ServerRelativeUrl&$top=5000&$orderby=ID%20asc", //assuming web part is added on same site :)  
                    type: "GET",
                    headers: { "accept": "application/json;odata=verbose" },
                    async: false,
                    success: function (docsData) {
                        if (docsData.d.results.length > 0) {
                            var getValues = docsData.d.results;
                       getValues=     getValues.sort(function(a, b) {
  var nameA = a.FileLeafRef.toUpperCase(); // ignore upper and lowercase
  var nameB = b.FileLeafRef.toUpperCase(); // ignore upper and lowercase
  if (nameA < nameB) {
    return -1;
  }
  if (nameA > nameB) {
    return 1;
  }

  // names must be equal
  return 0;
});
                            rootFolders = $.grep(getValues, function (e) {
                                if (e.EncodedAbsUrl.split(getInternalDocName + "/")[1] != null) {
                                    return e.EncodedAbsUrl.split(getInternalDocName + "/")[1].split('/').length == 1;
                                }
                            }); 
                           sMenuString += "<ul>";
                            $.each(rootFolders, function (i, rootFolder) {
							if(rootFolder.FileLeafRef.toLowerCase()=== search.toLowerCase()){
                             //   sMenuString += "<li class='parent'><a>" + rootFolder.FileLeafRef + "</a>";
 sMenuString += rootFolderName(rootFolder.FileLeafRef,getInternalDocName);
                                if (rootFolder.FSObjType == 1) {
                                    sMenuString += "<ul style='display:block'>";
                                    SubFoldersFiles(getValues, rootFolder.FileLeafRef.replace(/ /g, '%20'), rootFolder.EncodedAbsUrl);
                                    sMenuString += "</ul>";
                                }
                                sMenuString += "</li>";
								}
                            });
                           sMenuString += "</ul>";
                            div.innerHTML = sMenuString;
                        }
                    }
                });
            } catch (e) {
                alert(e.message);
            }
            return false;
        }

        
function rootFolderName(value,library){
     value= value.toLowerCase()==="form"?"Forms":value
    switch(library.toLowerCase()) {
    case"company":  
   return "<li class='parent imageComputer active'><a style='display:table;'>Company "+ value+"</a>"; 
    break;

    case"acs": 
    return "<li class='parent imageComputer active'><a style='display:table;'>CS " + value + "</a>";
    break;

    case"flightoperations": 
    return "<li class='parent imageComputer active'><a style='display:table;'>Flight Ops " + value + "</a>";
    break;

    case"inflight": 
    return "<li class='parent imageComputer active'><a style='display:table;'>IF " + value + "</a>";
    break; 

    default:
    return "<li class='parent imageComputer active'><a style='display:table;'>" + value + "</a>";
    break;
     
}
}
function getFolderExpand(){

 $.ajax({ url: _spPageContextInfo.webAbsoluteUrl + "/_api/lists/getbytitle('FolderExpand')/items?$select=Title,FolderUrl&$top=500&$orderby=ID%20asc", //assuming web part is added on same site :)
                    type: "GET",
                    headers: { "accept": "application/json;odata=verbose" },
                    async: false,
                    cache:true,
                    success: function (docsData) {
                        if (docsData.d.results.length > 0) {
                            expandFolderjson= docsData.d.results;
                        }}
                    });

 }
 
function SubFoldersFiles(listItems, currentItem, fullUrl) {
            var items = [];
            var subItems = $.grep(listItems, function (e) {
                if (e.EncodedAbsUrl.split(fullUrl + "/").length > 1) {
                    var fileUrl = e.EncodedAbsUrl.split(fullUrl + "/")[1];
                    if (fileUrl.split("/").length == 1) {
                        return true;
                    }
                }
            });

            if (subItems.length > 0) {
                $.each(subItems, function (i, subItem) {
 
                    if (subItem.FSObjType == 1) {
                        chkExists(expandFolderjson,subItem.Folder.ServerRelativeUrl);
                           if(IsExists) {
    sMenuString += "<li class='parent image active'><a>" + subItem.FileLeafRef + "</a>"; 
sMenuString += "<ul style='display: block ;'>";  
     }
     else{
          sMenuString += "<li class='parent image'><a>" + subItem.FileLeafRef + "</a>";
                        sMenuString += "<ul>";
     }    
                        SubFoldersFiles(listItems, subItem.FileLeafRef.replace(/ /g, '%20'), subItem.EncodedAbsUrl);
                        sMenuString += "</ul>";
                    }
                    else {
                        if((subItem.Title==null))
                        {
sMenuString += "<li class='image1' style='padding-left: 20px;'><a target='_blank' href='" + encodeURI(subItem.FileRef).replace("\'",'%27') +"?web=1"+ "'>" + subItem.FileLeafRef.substring(0,subItem.FileLeafRef.lastIndexOf('.')) + "</a></li>";
                        }
                        else{
sMenuString += "<li class='image1' style='padding-left: 20px;'><a target='_blank' href='" + encodeURI(subItem.FileRef).replace("\'",'%27')  +"?web=1"+ "'>" + subItem.Title + "</a></li>";

                        }
                        
                    }
                });
            }
        }

function chkExists(expandFolderjson,subItem){
$.each(expandFolderjson, function( key, obj ) { 
       
if(subItem.replace(/\//g, "\\").endsWith(obj.FolderUrl) ) { 
    IsExists=true;
    console.log('Exists: ' +obj.FolderUrl);
    return false; 
     }
      IsExists=false;
     
}); 
  }	
