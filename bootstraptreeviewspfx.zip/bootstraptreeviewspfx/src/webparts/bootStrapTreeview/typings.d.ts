interface JQuery<TElement = HTMLElement>
{
   treeview(options?:any);
   treeview(methodname:string,options?:any);
}