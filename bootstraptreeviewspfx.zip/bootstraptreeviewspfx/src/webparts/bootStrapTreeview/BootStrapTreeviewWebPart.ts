import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './BootStrapTreeviewWebPart.module.scss';
import * as strings from 'BootStrapTreeviewWebPartStrings';
import { SPComponentLoader } from '@microsoft/sp-loader';
import * as  $ from 'jquery';
require('bootstrap');
require('treeview');
export interface IBootStrapTreeviewWebPartProps {
  description: string;
}

export default class BootStrapTreeviewWebPart extends BaseClientSideWebPart <IBootStrapTreeviewWebPartProps> {

  public SearchTreeview()
  {  
      var pattern = $('#input-search').val();
      var options = {
        ignoreCase: true,
        exactMatch: false,
        revealResults:true
      };

      let result=  $('#treeview').treeview('search', [ pattern, options ]);
      console.log(JSON.stringify(result));
      // $('#treeview').treeview({
      //   data:result
      // }
      // );
  }
  public render(): void {   

    var defaultData = [
      {
        text: 'Parent 1',
        href: 'http://google.com',
        tags: ['4'],
        nodes: [
          {
            text: 'Child 1',
            href: 'https://jonmiles.github.io',
            tags: ['2'],
            nodes: [
              {
                text: 'Grandchild 1',
                href: '#grandchild1',
                tags: ['0']
              },
              {
                text: 'Grandchild 2',
                href: '#grandchild2',
                tags: ['0']
              }
            ]
          },
          {
            text: 'Child 2',
            href: '#child2',
            tags: ['0']
          }
        ]
      },
      {
        text: 'Parent 2',
        href: '#parent2',
        tags: ['0']
      },
      {
        text: 'Parent 3',
        href: '#parent3',
         tags: ['0']
      },
      {
        text: 'Parent 4',
        href: '#parent4',
        tags: ['0']
      },
      {
        text: 'Parent 5',
        href: '#parent5'  ,
        tags: ['0']
      }
    ];

    let cssURL = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css";
   SPComponentLoader.loadCss(cssURL);

    this.domElement.innerHTML = `
      <input type="text" id="input-search" maxlength='100' placeholder='Type to Search...'/>
      <div id='treeview'></div>`;

      $('#treeview').treeview({
        color: "#428bca",
            enableLinks: true,
            data: defaultData
      });
      $('#input-search').on('keyup', this.SearchTreeview);          
  }

  protected get dataVersion(): Version {
  return Version.parse('1.0');
}

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
  return {
    pages: [
      {
        header: {
          description: strings.PropertyPaneDescription
        },
        groups: [
          {
            groupName: strings.BasicGroupName,
            groupFields: [
              PropertyPaneTextField('description', {
                label: strings.DescriptionFieldLabel
              })
            ]
          }
        ]
      }
    ]
  };
}
}
