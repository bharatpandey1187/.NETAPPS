/* tslint:disable */
require("./BootStrapTreeviewWebPart.module.css");
const styles = {
  bootStrapTreeview: 'bootStrapTreeview_e42d2640',
  container: 'container_e42d2640',
  row: 'row_e42d2640',
  column: 'column_e42d2640',
  'ms-Grid': 'ms-Grid_e42d2640',
  title: 'title_e42d2640',
  subTitle: 'subTitle_e42d2640',
  description: 'description_e42d2640',
  button: 'button_e42d2640',
  label: 'label_e42d2640'
};

export default styles;
/* tslint:enable */