declare interface IBootStrapTreeviewWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BootStrapTreeviewWebPartStrings' {
  const strings: IBootStrapTreeviewWebPartStrings;
  export = strings;
}
