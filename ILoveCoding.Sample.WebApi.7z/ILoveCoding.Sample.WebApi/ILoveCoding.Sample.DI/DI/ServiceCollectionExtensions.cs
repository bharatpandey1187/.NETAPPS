﻿using ILoveCoding.Sample.DI;
using System;
using System.Linq;
using System.Reflection;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Export Configurator 
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Registers the exported types.
        /// </summary>
        /// <param name="serviceCollection">The service collection.</param>
        /// <param name="assemblies">The assemblies.</param>
        /// <returns></returns>
        public static IServiceCollection RegisterTypes(this IServiceCollection serviceCollection, params Assembly[] assemblies)
        {
            if (assemblies != default && assemblies.Any())
            {
                foreach (var assembly in assemblies)
                {
                    var exportTypes = assembly.GetExportedTypes().Where(x => !x.IsAbstract && !x.IsInterface && (x.GetCustomAttributes(typeof(ExportAttribute), false).Any()));
                    if (exportTypes.Any())
                    {
                        foreach (var exportType in exportTypes)
                        {
                            RegisterType(serviceCollection, exportType);
                        }
                    }
                }
            }

            return serviceCollection;
        }

        /// <summary>
        /// Registers the type.
        /// </summary>
        /// <param name="container">The container.</param>
        /// <param name="type">The type.</param>
        private static void RegisterType(IServiceCollection container, Type type)
        {
            ExportAttribute exportAttribute = (ExportAttribute)type.GetCustomAttributes(typeof(ExportAttribute), false).FirstOrDefault();
            var serviceType = exportAttribute.ExportType;
            var implementationType = exportAttribute.IsGenericType ? type.GetGenericTypeDefinition() : type;
            switch (exportAttribute.LifeTime)
            {
                case ServiceLifetime.Scoped:
                    container.AddScoped(serviceType, implementationType);
                    break;
                case ServiceLifetime.Singleton:
                    container.AddSingleton(serviceType, implementationType);
                    break;
                case ServiceLifetime.Transient:
                    container.AddTransient(serviceType, implementationType);
                    break;
            }
        }
    }
}
