﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;

namespace ILoveCoding.Sample.DI
{
    /// <summary>
    /// Export Attribute To Configure DI Container.
    /// </summary>
    /// <seealso cref="System.Attribute" />
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = false)]
    public sealed class ExportAttribute : Attribute
    {
        #region Public Properties
        
        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; private set; }

        /// <summary>
        /// Gets the type of the export.
        /// </summary>
        /// <value>
        /// The type of the export.
        /// </value>
        public Type ExportType { get; private set; }

        /// <summary>
        /// Gets the life time.
        /// </summary>
        /// <value>
        /// The life time.
        /// </value>
        public ServiceLifetime LifeTime { get; private set; }

        /// <summary>
        /// Gets a value indicating whether this instance is generic type.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is generic type; otherwise, <c>false</c>.
        /// </value>
        public bool IsGenericType { get; private set; } 

        #endregion

        #region Constructor(s)

        /// <summary>
        /// Initializes a new instance of the <see cref="ExportAttribute"/> class.
        /// </summary>
        /// <param name="exportType">Type of the export.</param>
        public ExportAttribute(Type exportType) : this(exportType, ServiceLifetime.Scoped, exportType.Name, false)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExportAttribute"/> class.
        /// </summary>
        /// <param name="exportType">Type of the export.</param>
        /// <param name="lifeTime">The life time.</param>
        /// <param name="name">The name.</param>
        /// <param name="isGenericType">if set to <c>true</c> [is generic type].</param>
        public ExportAttribute(Type exportType, ServiceLifetime lifeTime, string name = default, bool isGenericType = false)
        {
            ExportType = exportType;
            LifeTime = lifeTime;
            Name = name;
            IsGenericType = isGenericType;
        } 

        #endregion
    }

}
