﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILoveCoding.Sample.ApiApp.Interface
{
    public interface IServiceBusFactory
    {
        IServiceBus GetByType(ServiceBusType type);
    }
}
