﻿namespace ILoveCoding.Sample.ApiApp.Interface
{
    public interface ICustomLogger<T>
    {
    }
}
