﻿using ILoveCoding.Sample.ApiApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILoveCoding.Sample.ApiApp.Interface
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetAllAsync();
        Task<Product> GetByIDAsync(Guid productID);
        Task<bool> AddAsync(Product product);
        Task<bool> PutAsync(Product product);
        Task<bool> DeleteAsync(Guid productID);
        Task<IEnumerable<Product>> FindByNameAsync(string name);
    }
}
