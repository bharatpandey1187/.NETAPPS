﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ILoveCoding.Sample.ApiApp.Implementation;
using ILoveCoding.Sample.ApiApp.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ILoveCoding.Sample.ApiApp.Controllers
{
    [Route("api/sbfactory")]
    [ApiController]
    public class ServiceBusFactoryController : ControllerBase
    {
        private readonly IServiceBusFactory factory;

        public ServiceBusFactoryController(IServiceBusFactory factory)
        {
            this.factory = factory;
        }

        [HttpGet]
        [Route("GetAll")]
        public IActionResult GetAll()
        {
            var fileServiceBus = factory.GetByType(ServiceBusType.File);
            var jobServiceBus = factory.GetByType(ServiceBusType.Job);
            var localeServiceBus = factory.GetByType(ServiceBusType.Locale);
            string result = $"FILE SERVICE BUS:{fileServiceBus.GetString()},{Environment.NewLine}JOB SERVICE BUS:{jobServiceBus.GetString()},{Environment.NewLine}LOCALE SERVICE BUS:{localeServiceBus.GetString()}";
            return Ok(result);
        }
    }
}
