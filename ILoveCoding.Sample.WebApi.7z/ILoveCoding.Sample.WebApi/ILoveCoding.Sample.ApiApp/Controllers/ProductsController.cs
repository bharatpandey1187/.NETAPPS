﻿using ILoveCoding.Sample.ApiApp.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILoveCoding.Sample.ApiApp.Controllers
{
    [Route("api/Products")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService productService;
        private readonly ILogger<ProductsController> logger;
        private readonly ICustomLogger<ProductsController> customLogger;
        public ProductsController(IProductService productService, ILogger<ProductsController> logger, ICustomLogger<ProductsController> customLogger)
        {
            this.productService = productService;
            this.logger = logger;
            this.customLogger = customLogger;
        }

        [HttpGet]
        [Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await this.productService.GetAllAsync());
        }

        [HttpGet]
        [Route("Get/{productID}")]
        public async Task<IActionResult> Get(Guid productID)
        {
            return Ok(await this.productService.GetByIDAsync(productID));
        }
    }
}
