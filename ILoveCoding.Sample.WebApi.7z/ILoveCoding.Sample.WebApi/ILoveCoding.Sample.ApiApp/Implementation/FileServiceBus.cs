﻿using ILoveCoding.Sample.ApiApp.Interface;
using ILoveCoding.Sample.DI;

namespace ILoveCoding.Sample.ApiApp.Implementation
{
    [Export(typeof(FileServiceBus), Microsoft.Extensions.DependencyInjection.ServiceLifetime.Singleton)]
    public class FileServiceBus : IServiceBus
    {
        public FileServiceBus()
        {
        }

        public string GetString()
        {
            return $"Hello From {nameof(FileServiceBus)}";
        }
    }
}
