﻿using ILoveCoding.Sample.ApiApp.Interface;
using ILoveCoding.Sample.DI;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace ILoveCoding.Sample.ApiApp.Implementation
{
    /// <summary>
    /// Service Bus Factory Implementation Class.
    /// </summary>
    /// <seealso cref="ILoveCoding.Sample.ApiApp.Interface.IServiceBusFactory" />
    [Export(typeof(IServiceBusFactory), ServiceLifetime.Transient)]
    public class ServiceBusFactory : IServiceBusFactory
    {
        private readonly IServiceProvider serviceProvider;

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBusFactory"/> class.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        public ServiceBusFactory(IServiceProvider serviceProvider)
        {
            this.serviceProvider = serviceProvider;
        }

        /// <summary>
        /// Gets the type of the by.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        public IServiceBus GetByType(ServiceBusType type)
        {
            return type switch
            {
                ServiceBusType.File => serviceProvider.GetRequiredService<FileServiceBus>(),
                ServiceBusType.Job => serviceProvider.GetRequiredService<JobServiceBus>(),
                ServiceBusType.Locale => serviceProvider.GetRequiredService<LocaleServiceBus>(),
                _ => throw new ArgumentException("Invalid arguments."),
            };
        }
    }
}
