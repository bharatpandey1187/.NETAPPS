﻿using ILoveCoding.Sample.ApiApp.Interface;
using ILoveCoding.Sample.DI;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILoveCoding.Sample.ApiApp.Implementation
{
    [Export(typeof(ICustomLogger<>), ServiceLifetime.Singleton, nameof(CustomLogger<T>), true)]
    public class CustomLogger<T> : ICustomLogger<T>
    {
    }
}
