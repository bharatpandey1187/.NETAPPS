﻿using ILoveCoding.Sample.ApiApp.Interface;
using ILoveCoding.Sample.DI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILoveCoding.Sample.ApiApp.Implementation
{
    [Export(typeof(JobServiceBus), Microsoft.Extensions.DependencyInjection.ServiceLifetime.Singleton)]
    public class JobServiceBus : IServiceBus
    {
        public string GetString()
        {
            return $"Hello From {nameof(JobServiceBus)}";
        }
    }
}
