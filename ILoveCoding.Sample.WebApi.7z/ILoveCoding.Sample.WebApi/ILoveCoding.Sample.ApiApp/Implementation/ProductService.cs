﻿using ILoveCoding.Sample.ApiApp.Interface;
using ILoveCoding.Sample.ApiApp.Models;
using ILoveCoding.Sample.DI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILoveCoding.Sample.ApiApp.Implementation
{
    [Export(typeof(IProductService))]
    public class ProductService : IProductService
    {
        public ProductService()
        {
        }

        private static List<Product> products = new List<Product>
        {
            new Product
            {
                ID=new Guid("{D3132E40-5E85-4793-BF95-621A7CED623B}"),
                Description="Laptop",
                Name="Dell Inspiron 3000 15.3",
                Price=50000,
                SKU="8BHHG233FFDDA"
            },
            new Product
            {
                ID=new Guid("{988A2CDE-CF01-471E-A948-A7E7D8FD96C0}"),
                Description="Laptop",
                Name="Dell Inspiron 3000 13.3",
                Price=60000,
                SKU="0009BHHG233FFDDA"
            },
            new Product
            {
                ID=new Guid("{8B3DF5F4-9A4B-4631-9B71-14DA2D15A06E}"),
                Description="Desktop",
                Name="Dell Vivante 32GB 13.3",
                Price=100000,
                SKU="1000BHHG233FFDDA"
            }
        };
        public async Task<bool> AddAsync(Product product)
        {
            await Task.Run(() => products.Add(product));
            return true;
        }

        public async Task<bool> DeleteAsync(Guid productID)
        {
            var product = await GetByIDAsync(productID);
            if (product != default)
            {
                products.Remove(product);
            }

            return true;
        }

        public async Task<IEnumerable<Product>> FindByNameAsync(string name)
        {
            return await Task.Run(() => products.Where(x => x.Name.Contains(name)));
        }

        public async Task<IEnumerable<Product>> GetAllAsync()
        {
            return await Task.Run(() => products);
        }

        public async Task<Product> GetByIDAsync(Guid productID)
        {
            return await Task.Run(() => products.SingleOrDefault(x => x.ID == productID));
        }

        public async Task<bool> PutAsync(Product product)
        {
            var productToUpdate = await GetByIDAsync(product.ID);
            if (productToUpdate != default)
            {
                productToUpdate = product;
            }

            return true;
        }
    }
}
