﻿using ILoveCoding.Sample.ApiApp.Implementation;
using ILoveCoding.Sample.ApiApp.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace ILoveCoding.Sample.ApiApp
{
    public static class Factories
    {
        public static IServiceBus FileStorageService(IServiceProvider serviceProvider, string type)
        {
            if (type.ToLower() == "file")
            {
                return (FileServiceBus)serviceProvider.GetService(typeof(FileServiceBus));
            }
            else if (type.ToLower() == "job")
            {
                return new JobServiceBus();
            }
            else if (type.ToLower() == "locales")
            {
                return new LocaleServiceBus();
            }

            throw new ArgumentException("Invalid Argument");
        }
    }
}
