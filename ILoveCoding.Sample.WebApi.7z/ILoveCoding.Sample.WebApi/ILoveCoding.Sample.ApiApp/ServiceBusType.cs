﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILoveCoding.Sample.ApiApp
{
    public enum ServiceBusType
    {
        File,
        Job,
        Locale
    }
}
