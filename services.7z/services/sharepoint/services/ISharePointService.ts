import {
  SPRest,
  List,
  Item,
  Items,
  ItemAddResult,
  ItemUpdateResult,
  FolderAddResult,
  FileAddResult
} from "@pnp/sp";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { TypedHash } from "@pnp/common";
import { CurrentUser } from "@pnp/sp/src/siteusers";
export default interface ISharePointService {
  getListByTitle(title: string): List;
  getListByUrl(listRelativeUrl: string): List;
  getItemById(listTitle: string, itemID: number): Promise<any>;
  getListItems(
    listTitle: string,
    queryXml: string,
    rowLimit: number
  ): Promise<any>;
  AddItem(listTitle: string, data: TypedHash<any>): Promise<ItemAddResult>;
  UpdateItem_List(listTitle: string,
    itemID: number,
    data: TypedHash<any>
  ): Promise<ItemUpdateResult>;
  UpdateItem(
    listTitle: string,
    itemID: number,
    data: TypedHash<any>
  ): Promise<ItemUpdateResult>;
  DeleteItem(listTitle: string, itemID: number): Promise<void>;
  getChoices(listTitle: string, columnName: string): Promise<any>;
  getAllFolders(listName: string): Promise<any>;
  createFolder(listName: string, folderName: String): Promise<FolderAddResult>;
  addFile(
    listName: string,
    folderName: string,
    file: any,
    fileName: string
  ): Promise<FileAddResult>;
  addPropertyFile(
    file: FileAddResult,
    data: TypedHash<any>
  ): Promise<ItemUpdateResult>;
  AddFileRoot(
    listName: string,
    // folderName: string,
    file: any,
    fileName: string
  ): Promise<FileAddResult>;
  getGroups(userEmail: string): Promise<any>;
  getCurrentUser(): Promise<CurrentUser>;
}
