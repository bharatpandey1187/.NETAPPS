import ISharePointService from "./ISharePointService";
import {
  sp,
  SPRest,
  Item,
  List,
  CamlQuery,
  Items,
  ItemAddResult,
  ItemUpdateResult,
  Web,
  SharePointQueryableShareableWeb,
  Folder,
  FolderAddResult,
  FileAddResult
} from "@pnp/sp";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { TypedHash } from "@pnp/common";
import { CurrentUser } from "@pnp/sp/src/siteusers";
export default class SPPnPService implements ISharePointService {
  //#region Constructor(s)

  private web: Web;

  /**
   * Constructor For SharePoint Service Class
   */
  constructor(baseUrl: string) {
    this.Initialize(baseUrl);
  }
  //#endregion

  //#region Public Method(s)

  public getCurrentUser(): Promise<CurrentUser> {
    return this.web.currentUser.get();
  }
  public getChoices(listTitle: string, columnName: string): Promise<any> {
    let getItemPromise: Promise<any>;
    let list: List = this.GetList(listTitle);
    if (list) {
      getItemPromise = this.getColumnChoices(list, columnName);
    }

    return getItemPromise;
  }

  public getItemById(listTitle: string, itemID: number): Promise<any> {
    let getItemPromise: Promise<any>;
    let list: List = this.GetList(listTitle);
    if (list) {
      getItemPromise = this.GetListItemByID(list, itemID);
    }

    return getItemPromise;
  }

  public getListByTitle(listTitle: string): List {
    return this.GetList(listTitle);
  }

  public getListByUrl(serverRelativeUrl: string): List {
    return this.GetListByUrl(serverRelativeUrl);
  }

  public getListItems(listTitle: string, queryXml: string): Promise<any> {
    let getItemsPromise: Promise<any>;

    let list: List = this.GetList(listTitle);
    if (list) {
      if (queryXml == "") {
        queryXml = "<View><Query><Where></Where></Query></View>";
      }
      let camlQuery: CamlQuery = {
        ViewXml: queryXml
      };

      getItemsPromise = list.getItemsByCAMLQuery(camlQuery);
    }

    return getItemsPromise;
  }

  public AddItem(listTitle: string, data: TypedHash<any>): Promise<ItemAddResult> {
    var addItemPromise: Promise<ItemAddResult>;
    let list: List = this.GetList(listTitle);
    let listItem: any;
    if (list) {
      addItemPromise = list.items.add(data);
    }

    return addItemPromise;
  }

  public UpdateItem_List(
    listTitle: string,
    itemID: number,
    data: TypedHash<any>
  ): Promise<ItemUpdateResult> {
    let updateItemPromise: Promise<ItemUpdateResult>;
    let UpdateResult: ItemUpdateResult;
    let list: List = this.GetList(listTitle);
    updateItemPromise = list.items.getById(itemID).update(data);
    return updateItemPromise;
  }


  public UpdateItem(
    listTitle: string,
    itemID: number,
    data: TypedHash<any>
  ): Promise<ItemUpdateResult> {
    let updateItemPromise: Promise<ItemUpdateResult>;
    let list: List = this.GetList(listTitle);

    let listItemPromise: Promise<any> = this.GetListItemByID(list, itemID);
    if (listItemPromise) {
      listItemPromise.then((item: Item) => {
        updateItemPromise = item[0].update(data);
      });
    }

    return updateItemPromise;
  }

  public DeleteItem(listTitle: string, itemID: number): Promise<void> {
    var itemDeletePromise: Promise<void>;
    let list: List = this.GetList(listTitle);
    let listItemPromise: Promise<any> = this.GetListItemByID(list, itemID);
    let listitems: Items = list.items;
    if (list) {
      itemDeletePromise = listitems.getById(itemID).delete();     
    }
    return itemDeletePromise;
  }
  public getAllFolders(listName: string): Promise<any> {
    let list: List = this.GetList(listName);
    if (list) {
      return this.GetAllFolders(list);
    }
  }
  public createFolder(
    listName: string,
    folderName: string
  ): Promise<FolderAddResult> {
    let list: List = this.GetList(listName);
    if (list) {
      return this.CreateFolder(list, folderName);
    }
  }
  public addFile(
    listName: string,
    folderName: string,
    file: any,
    fileName: string
  ): Promise<FileAddResult> {
    let list: List = this.GetList(listName);
    if (list) {
      return this.AddFile(list, folderName, file, fileName);
    }
  }
  public addPropertyFile(
    file: FileAddResult,
    data: TypedHash<any>
  ): Promise<ItemUpdateResult> {
    return this.AddPropertyFile(file, data);
  }

  public getGroups(userEmail): Promise<any> {
    return this.web.siteUsers.getByEmail(userEmail).groups.get();
  }

  //#endregion

  //#region Private Method(s)

  private Initialize(baseUrl: string): void {
    this.web = new Web(baseUrl);
    
  }
  private getColumnChoices(list: List, columnName: string) {
    return list.fields.getByInternalNameOrTitle(columnName).get();
  }

  private GetList(listTitle: string): List {
    return this.web.lists.getByTitle(listTitle);
  }

  private GetListByUrl(listTitle: string) {
    return this.web.lists.getByTitle(listTitle);
  }

  private GetListItemByID(list: List, itemID: number): Promise<any> {
    let query: string = `<View>
                            <Query>
                                <Where>
                                    <Eq>
                                        <FieldRef Name='ID'/>
                                        <Value Type='Number'>${itemID}</Value>
                                    </Eq>
                                </Where>
                            </Query>
                        <RowLimit>1</RowLimit>
                        </View>`;

    let camlQuery: CamlQuery = {
      ViewXml: query
    };
    return list.getItemsByCAMLQuery(camlQuery);
  }
  private GetAllFolders(listName: List): Promise<any> {
    return listName.rootFolder.folders.get();
  }
  private CreateFolder(
    listName: List,
    folderName: string
  ): Promise<FolderAddResult> {
    return listName.rootFolder.folders.add(folderName);
  }
  private AddFile(
    listName: List,
    folderName: string,
    file: any,
    fileName: string
  ): Promise<FileAddResult> {
    return listName.rootFolder.folders
      .getByName(folderName)
      .files.add(fileName, file, true);
  }
  private AddFileRoot1(
    listName: List,
    // folderName: string,
    file: any,
    fileName: string
  ): Promise<FileAddResult> {
    return listName.rootFolder
      .files.add(fileName, file, true);
  }
  public AddFileRoot(
    listName: string,
    // folderName: string,
    file: any,
    fileName: string
  ): Promise<FileAddResult> {
    let list: List = this.GetList(listName);
    if (list) {
      return this.AddFileRoot1(list, file, fileName);
    }
  }
  private AddPropertyFile(
    file: FileAddResult,
    data: TypedHash<any>
  ): Promise<ItemUpdateResult> {
    return file.file.getItem().then(item => item.update(data));
  }

  //#endregion

  public async BatchDeleteListItems(listTitle: string, filterExpression: string): Promise<boolean> {
    var batch = sp.createBatch();
    var result: boolean = false;

    var list = this.web.lists.getByTitle(listTitle);

    await list.items.filter(filterExpression).get().then(async (items) => {

      items.forEach(item => {
         list.items.getById(item["ID"]).inBatch(batch).delete();
      });

     await batch.execute().then(() => result = true);
    });
    return Promise.resolve(result);
  }

  public async BatchInsertListItems(listTitle: string, items: TypedHash<any>[]): Promise<boolean> {
    var batch = sp.createBatch();
    var result: boolean = false;
    var list = this.web.lists.getByTitle(listTitle);
    await list.getListItemEntityTypeFullName().then(async (typeName) => {
      items.forEach(async (item) => {
        list.items.inBatch(batch).add(item, typeName);
        await batch.execute().then(_ => {
          result = true;
        }).catch((e) => {
          result = false;
          console.log("Batch Insert Error:" + e);
        });
      });

    }).catch((e) => {
      result = false;
      console.log("Batch Insert Error:" + e);
    });

    return Promise.resolve(result);
  }

  /**
   * Currents sppn pservice
   * @returns  
   */
  public Current():Web
  {
    return this.web;
  }
}