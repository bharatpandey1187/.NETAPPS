import XJTApiService from "./XJTApiService";
import { QuickLinkItem } from "../models/QuickLinkItem";
import { QuickLinksServiceProxy } from "../common/serviceProxy";

export class QuickLinksService
{
    private apiService:XJTApiService;
    public constructor(private serviceBaseUrl: string) {
        this.apiService= new XJTApiService();
    }

    public getQuickLinks(linkID:string,userID:string):Promise<QuickLinkItem[]>
    {
        var apiUrl=QuickLinksServiceProxy.getQuickLinksForUser(this.serviceBaseUrl,linkID,userID);
        var quickLinksPromise:Promise<QuickLinkItem[]>= this.apiService.fetch(apiUrl,{
            "Accept":"application/json;charset=utf-8"
        },null,false,false);

        return quickLinksPromise;
    }
}