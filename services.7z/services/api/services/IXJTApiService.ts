interface IAJAXApiService {
    fetch(url: string, headers: any, data: any, cache: boolean, async: boolean,authorize?:boolean): Promise<any>;
    post(url: string, headers: any, data: any, cache: boolean, async: boolean, authorize?: boolean): Promise<any>;
}

export { IAJAXApiService };