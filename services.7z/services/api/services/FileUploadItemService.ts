import XJTApiService from "./XJTApiService";
import { FileUploadPostproxy } from "../common/serviceProxy";

export default class FileUploadItemService {
  private serviceBaseUrl: string;
  private apiService: XJTApiService;

  public constructor(serviceBaseUrl: string) {
    this.serviceBaseUrl = serviceBaseUrl;
    this.apiService = new XJTApiService();
  }

  public postFileUploaDetails(body: string) {
    let apiMethodUrl: string = FileUploadPostproxy.postFiledetails(
      this.serviceBaseUrl
    );
    this.apiService.post(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      body,
      null,
      false
    );
  }
}
