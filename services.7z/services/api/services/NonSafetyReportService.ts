import XJTApiService from "./XJTApiService";
import { NonSafetyReportProxy } from "../common/NonSafetyReportProxy"; 

export default class NonSafteyReport {
  private serviceBaseUrl: string;
  private apiService: XJTApiService;
  private userID: string;
  public constructor(serviceBaseUrl: string,userID:string) {
    this.serviceBaseUrl = serviceBaseUrl;
    this.userID=userID;
    this.apiService = new XJTApiService();
  }

  public getNonSafetyReportItem(): Promise<any> {
    let apiMethodUrl: string = NonSafetyReportProxy.getNonSafetyReportItem( 
      this.serviceBaseUrl,  
      this.userID
    );
    let NonSafetyReportItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return NonSafetyReportItems;
  }

  public getNonSafetyViewItem(eventID:number): Promise<any> {
    let apiMethodUrl: string = NonSafetyReportProxy.geViewItem( 
      this.serviceBaseUrl,  
      eventID
    );
    let NonSafetyReportItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return NonSafetyReportItems;
  }

  public flightRelatedEvent(eventDate:string): Promise<any> {
    let apiMethodUrl: string = NonSafetyReportProxy.flightRelatedEventItem( 
      this.serviceBaseUrl,  
      eventDate
    );
    let NonSafetyReportItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return NonSafetyReportItems;
  }
  public saveFlightRelatedEvent(body: string): Promise<number> {
    let apiMethodUrl: string = NonSafetyReportProxy.saveFlightEvent(
      this.serviceBaseUrl,
      this.userID
    );
    let saveItemPromise: Promise<number> = this.apiService.post(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      body,
      null,
      false
    );
    return saveItemPromise;
  }

  public saveFlightDraftEvent(body: string): Promise<number> {
    let apiMethodUrl: string = NonSafetyReportProxy.saveDraftFlightEvent(
      this.serviceBaseUrl,
      this.userID
    );
    let saveItemPromise: Promise<number> = this.apiService.post(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      body,
      null,
      false
    );
    return saveItemPromise;
  }
  public deletEvent(eventID: number): Promise<number> {
    let apiMethodUrl: string = NonSafetyReportProxy.deletFlightEvent(
      this.serviceBaseUrl,
      eventID
    );
    let saveItemPromise: Promise<number> = this.apiService.Delete(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return saveItemPromise;
  }
  
}
