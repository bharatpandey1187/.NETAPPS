import XJTApiService from "./XJTApiService";
import SecurityModel from "../models/SecurityModel";
import { AuthorizationServiceProxy } from "../common/serviceProxy";
import SessionStorageService from "../common/SessionStorageService";
import { StorageConfigKeys } from "../constants/Constants";

export default class AuthorizationService {
    private apiService: XJTApiService;
    // Constructor
    public constructor(private serviceBaseUrl: string) {
        this.apiService = new XJTApiService();
    }

    public async DoesUserHavePermission(principal: string, allowedSecurityGroups: string): Promise<boolean> {
        let hasAccess = false;
        if (allowedSecurityGroups && allowedSecurityGroups.trim() != "") {
            let securityModels: SecurityModel[] = await this.GetSecurityGroupsByPrincipal(principal);
            if (securityModels && securityModels.length > 0) {
                let allowedSecurityGroupsArray: string[] = allowedSecurityGroups.split(",");
                if (allowedSecurityGroupsArray && allowedSecurityGroupsArray.length > 0) {
                    hasAccess = securityModels.some(r => allowedSecurityGroupsArray.indexOf(r.id) >= 0);
                }
            }
        }

        return Promise.resolve(hasAccess);
    }

    private GetSecurityGroupsByPrincipal(principal: string): Promise<SecurityModel[]> {
        var securityModels: SecurityModel[] = SessionStorageService.getItem(StorageConfigKeys.UserSecurityGroups);
        if (securityModels && securityModels.length > 0) {
            return Promise.resolve(securityModels);
        }

        let apiMethodUrl: string = AuthorizationServiceProxy.getSecurityGroupsByPrincipal(this.serviceBaseUrl, principal);
        let securityModelPromise: Promise<SecurityModel[]> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false, false) as Promise<SecurityModel[]>;

        return securityModelPromise;
    }
}