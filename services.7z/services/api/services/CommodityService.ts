import XJTApiService from "./XJTApiService";
import { CommodityModel } from "../models/CommodityModel";
import { CommodityModelServiceProxy } from "../common/serviceProxy";

export default class CommodityService
{
    private serviceBaseUrl: string;
    private apiService: XJTApiService;
    public constructor(serviceBaseUrl: string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.apiService = new XJTApiService();
    }

    public getCommodityDetail(): Promise<CommodityModel> {
         let apiMethodUrl: string = CommodityModelServiceProxy.getCommodityDetail(this.serviceBaseUrl);
         let commodityDetailModelPromise: Promise<CommodityModel> = this.apiService.fetch(apiMethodUrl, {
             "Accept": "application/json",
             "Content-Type": "application/json;charset=utf-8"
         }, null,true, false);
 
         return commodityDetailModelPromise;
     }
}