import { IAJAXApiService } from "./IXJTApiService";
import * as $ from "jquery";
import TokenService from "./TokenService";
import SessionStorageService from "../common/SessionStorageService";
import { StorageConfigKeys } from "../constants/Constants";
export default class XJTApiService implements IAJAXApiService {
  constructor() { }
  // THE AJAX REQUEST : GET
  public fetch(
    url: string,
    headers: any,
    data: any,
    cache: boolean,
    async: boolean,
    authorize?: boolean
  ): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.callJson(
        url,
        "GET",
        headers,
        data,
        cache,
        async,
        (resultObject: any) => {
          if (resultObject) {
            if (resultObject.result) {
              resolve(resultObject.result);
            } else {
              resolve(resultObject);
            }
          }
        },
        (jqXR: XMLHttpRequest, errorStatus: any, errorThrown: string) => {
          reject(errorThrown);
        }
        , authorize
        , true
      );
    });
  }

  //THE AJAX REQUEST :POST
  public post(
    url: string,
    headers: any,
    data: any,
    cache: boolean,
    async: boolean,
    authorize?: boolean
  ): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.callJson(
        url,
        "POST",
        headers,
        data,
        cache,
        async,
        (resultObject: any) => {
          if (resultObject) {
            if (resultObject.result) {
              resolve(resultObject.result);
            } else {
              resolve(resultObject);
            }
          }
        },
        (jqXR: XMLHttpRequest, errorStatus: any, errorThrown: string) => {
          reject(errorThrown);
        }
        , authorize
        , true // TO MAKE USE OF API TOKEN
      );
    });
  }
  public Delete(
    url: string,
    headers: any,
    data: any,
    cache: boolean,
    async: boolean
  ): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.callJson(
        url,
        "DELETE",
        headers,
        data,
        cache,
        async,
        (resultObject: any) => {
          if (resultObject) {
            resolve(resultObject.result);
          }
        },
        (jqXR: XMLHttpRequest, errorStatus: any, errorThrown: string) => {
          reject(errorThrown);
        }
        , false
        , true
      );
    });
  }

  // Calls the AJAX JSON
  private async callJson(
    url: string,
    type: string,
    headers: any,
    data: any,
    cache: boolean,
    async: boolean,
    successCallback: any,
    failureCallBack: any,
    authorize?: boolean,
    crossDomain?: boolean
  ) {
    let token: string;
    if (authorize) {
      token = SessionStorageService.getItem(StorageConfigKeys.BearerToken);
    }
    headers = headers || {};
    cache = cache || false;
    async = async || true;
    data = data || null;
    var serviceHandler = this;
    var ajaxCall = $.ajax({
      url: url,
      type: type,
      data: data,
      cache: cache,
      async: async,
      contentType:"application/json; charset=utf-8",
      beforeSend: jqXR => {
        if (authorize) {
          jqXR.setRequestHeader("Authorization", "Bearer " + token);
        }
        if (crossDomain) {
          jqXR.setRequestHeader("Access-Control-Allow-Origin", "https://xjt.sharepoint.com/");
        }
      },
      success: successCallback,
      error: failureCallBack
    });

    return ajaxCall;
  }
}
