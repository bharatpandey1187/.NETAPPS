import XJTApiService from "./XJTApiService";
import { RelocationRequestServiceProxy } from "../common/serviceProxy";
import { InflightModelContainer } from "../models/InflightModelContainer";


export default class RelocationRequestService {
    private serviceBaseUrl: string;
    private apiService: XJTApiService;

    public constructor(serviceBaseUrl: string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.apiService = new XJTApiService();
    }
    public getServiceBasedCollection(employeeNo: string): Promise<void> {
       //let modelContainer: TopStoryItemModelContainer = null;
        let apiMethodUrl: string = RelocationRequestServiceProxy.getUserInformationData(this.serviceBaseUrl, employeeNo);
        let relocationRequestItemsPromise: Promise<void> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false);

        return relocationRequestItemsPromise;
    }



    
}