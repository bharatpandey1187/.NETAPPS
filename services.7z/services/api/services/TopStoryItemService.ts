import XJTApiService from "./XJTApiService";
import { TopStoryItem, TopStoryItemModelContainer } from "../models/TopStoryItemModelContainer";
import { TopStoryServiceProxy } from "../common/serviceProxy";

export default class TopStoryItemService {
    private serviceBaseUrl: string;
    private apiService: XJTApiService;

    public constructor(serviceBaseUrl: string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.apiService = new XJTApiService();
    }

    public getTopStoriesItemsByCategory(categoryID: number, maxRows: number): Promise<TopStoryItemModelContainer> {
        let modelContainer: TopStoryItemModelContainer = null;
        let apiMethodUrl: string = TopStoryServiceProxy.getItemByCategory(this.serviceBaseUrl, categoryID, maxRows);
        let topStoriesItemsPromise: Promise<TopStoryItemModelContainer> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false);

        return topStoriesItemsPromise;
    }
}

