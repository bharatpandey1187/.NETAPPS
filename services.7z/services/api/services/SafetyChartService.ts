import XJTApiService from "./XJTApiService";
import { SafetyChartServiceProxy } from "../common/serviceProxy";
import { SafetyChartModelContainer } from "../models/SafetyChartModelContainer";

export default class SafetyChartService {
  private serviceBaseUrl: string;
  private apiService: XJTApiService;

  public constructor(serviceBaseUrl: string) {
    this.serviceBaseUrl = serviceBaseUrl;
    this.apiService = new XJTApiService();
  }

  public getItem(): Promise<SafetyChartModelContainer> {
    let modelContainer: SafetyChartModelContainer = null;
    let apiMethodUrl: string = SafetyChartServiceProxy.getitem(
      this.serviceBaseUrl
    );
    let safetyChartItems: Promise<SafetyChartModelContainer> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return safetyChartItems;
  }
}
