import {Log} from "@microsoft/sp-core-library";
import { ServiceScope } from '@microsoft/sp-core-library';

export default class LoggingService {
    constructor() {
  }

    public Verbose(source: string, message: string,scope:ServiceScope|undefined): void {
        Log.verbose(source, message, scope);
  }

  public Information(source: string, message: string,scope:ServiceScope|undefined): void {
    Log.info(source, message, scope);
    
  }

  public Warning(source: string, message: string,scope:ServiceScope|undefined): void {
    Log.warn(source, message, scope);   
  }

    public Error(source: string, error: Error,scope:ServiceScope|undefined): void {
        Log.error(source, error, scope);  
  }

}