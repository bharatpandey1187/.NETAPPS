import XJTApiService from "./XJTApiService";
import { AnniversaryServiceProxy } from "../common/serviceProxy";

export default class AnniversaryService {
  private serviceBaseUrl: string;
  private apiService: XJTApiService;

  public constructor(serviceBaseUrl: string) {
    this.serviceBaseUrl = serviceBaseUrl;
    this.apiService = new XJTApiService();
  }

  public getItem(): Promise<any> {
    let apiMethodUrl: string = AnniversaryServiceProxy.getitem(
      this.serviceBaseUrl
    );
    let AnniversaryItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return AnniversaryItems;
  }
}
