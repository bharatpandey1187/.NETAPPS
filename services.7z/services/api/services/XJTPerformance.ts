import XJTApiService from "./XJTApiService";
import { XJTPerformanceProxy } from "../common/serviceProxy";

export default class XJTPerformance {
  private serviceBaseUrl: string;
  private apiService: XJTApiService;

  public constructor(serviceBaseUrl: string) {
    this.serviceBaseUrl = serviceBaseUrl;
    this.apiService = new XJTApiService();
  }

  public getItem(date: string,location:string): Promise<any> {
    let apiMethodUrl: string = XJTPerformanceProxy.GetDashboardData(
      this.serviceBaseUrl,
      date,
      location
    );
    let DashboardDataItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return DashboardDataItems;
  }

  public GetRTPByStation(date: string, station: string): Promise<any> {
    let apiMethodUrl: string = XJTPerformanceProxy.GetRTPByStation(
      this.serviceBaseUrl,
      date,
      station
    );
    let RTPByStationDataItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return RTPByStationDataItems;
  }
  public GetSWAPWeatherData(LocationID: string): Promise<any> {
    let apiMethodUrl: string = XJTPerformanceProxy.GetSWAPWeatherData(
      this.serviceBaseUrl,
      LocationID
    );
    let RTPByStationDataItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return RTPByStationDataItems;
  }

  public GetDashboardDataFiltered(month: string, year: string): Promise<any> {
    let apiMethodUrl: string = XJTPerformanceProxy.GetDashboardDataFiltered(
      this.serviceBaseUrl,
      month,
      year
    );
    let DashboardDataFilteredDataItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return DashboardDataFilteredDataItems;
  }
  public FilterFlightsByStatus(serviceBaseUrl: string, date: string,stationCode:string,carrierCode:string,requestType:string): Promise<any> {
    let apiMethodUrl: string = XJTPerformanceProxy.FilterFlightsByStatus(
      this.serviceBaseUrl, date,stationCode,carrierCode,requestType
    );
    let FlightsItems: Promise<any> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );
    return FlightsItems;
  }
}
