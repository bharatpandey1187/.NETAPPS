import ISharePointService from "../../sharepoint/services/ISharePointService";
import SecuredMenu from "../models/Secured";
import { CommonConstants, ListTitles } from "../constants/Constants";
import SPPnPService from "../../sharepoint/services/SPPnPService";


export default class MenuService {
    private sharePointService: ISharePointService;
    constructor(private webUrl: string) {
        this.sharePointService = new SPPnPService(this.webUrl);
    }
    public async GetMenuItems(): Promise<SecuredMenu[]> {
        var result = await this.sharePointService.getListItems(ListTitles.Menu, "<View><Query><Eq><FieldRef Name='Enabled'/><Value Type='Boolean'>1</Value></Eq></Query><ViewFields><FieldRef Name='ID'></FieldRef><FieldRef Name='Title'></FieldRef><FieldRef Name='ParentId'></FieldRef><FieldRef Name='TargetURL'></FieldRef><FieldRef Name='TargetWindow'></FieldRef><FieldRef Name='Enabled'></FieldRef><FieldRef Name='Sequence'></FieldRef><FieldRef Name='UniqueName'></FieldRef></ViewFields></View>", 5000);
        let items: SecuredMenu[] = [];
        if (result) {
            result.forEach((listItem) => {
                if (listItem.ParentId === 0) {
                    let securedMenuItem: SecuredMenu = {
                        id: listItem.ID,
                        parentId: listItem.ParentId,
                        menuText: listItem.Title,
                        uniqueName: listItem.UniqueName,
                        targetUrl: this.GetURL(listItem.TargetURL),
                        targetWindow: !listItem.TargetWindow || listItem.TargetWindow == "NULL" ? "" : listItem.TargetWindow,
                        sequence: listItem.Sequence,
                        securedSubMenu: [] as SecuredMenu[],
                        enabled: listItem.Enabled,
                    };
                    items.push(securedMenuItem);
                }
            });

            //Populate Children
            result.forEach((childItem) => {
                // ONLY ADD THE ITEMS IN THE CHILD LIST IF THE ITEM IS NOT ALREADY THERE
                if (!this.FindMenuItem(items, childItem.id)) {
                    if (childItem.ParentId !== 0) {
                        let securedMenuItem: SecuredMenu = {
                            id: childItem.ID,
                            parentId: childItem.ParentId,
                            menuText: childItem.Title,
                            uniqueName: childItem.UniqueName,
                            targetUrl: this.GetURL(childItem.TargetURL),
                            targetWindow: !childItem.TargetWindow || childItem.TargetWindow === "NULL" ? "" : childItem.TargetWindow,
                            sequence: childItem.Sequence,
                            securedSubMenu: [] as SecuredMenu[],
                            enabled: childItem.Enabled,
                        };

                        let parentItem: SecuredMenu = this.FindParentItem(items, securedMenuItem.parentId);

                        if (parentItem) {
                            parentItem.securedSubMenu.push(securedMenuItem);
                        }
                    }
                }
            });
        }
        if (items) {
            items.sort((first, second) => {
                return (first.sequence - second.sequence);
            });
        }
        return Promise.resolve(items);
    }

    private GetURL(linkUrl: string): string {
        linkUrl = linkUrl && linkUrl !== 'NULL' ? linkUrl : '';
        if (linkUrl) {
            if (linkUrl.lastIndexOf("xjt.com") > 0) {
                return linkUrl;
            }
            else {
                return this.webUrl.concat(linkUrl);
            }
        }
        

        return linkUrl;
    }



    private FindMenuItem(items: SecuredMenu[], menuID: number): SecuredMenu {
        var item = null;
        for (let i = 0; i < items.length; i++) {
            if (items[i].id == menuID) {
                item = items[i];
                break;
            }

            if (items[i].securedSubMenu.length > 0) {
                item = this.FindMenuItem(items[i].securedSubMenu, menuID);
                if (item) {
                    return item;
                }
            }
        }

        return item;
    }

    private FindParentItem(items: SecuredMenu[], menuID: number) {
        for (let itemIndex = 0; itemIndex < items.length; itemIndex++) {
            if (items[itemIndex].id === menuID) {
                return items[itemIndex];
            }

            if (items[itemIndex].securedSubMenu.length > 0) {
                let found = this.FindParentItem(items[itemIndex].securedSubMenu, menuID);
                if (found) {
                    return found;
                }
            }
        }

        return null;
    }
}