import XJTApiService from "./XJTApiService";
import { MyFavouritesItem} from "../models/MyItemFavourites";
import { MyItemServiceProxy } from "../common/MyItemServiceProxy";
import MyItemModel from "../models/MyItemModel";
import CommonMyItemModel from "../models/CommonMyItemModel";
import SPPnPService from "../../sharepoint/services/SPPnPService";

export default class MyItemService 
{
    private serviceBaseUrl: string;
    private userEmail:string;
    private apiService: XJTApiService;
    private sharePointService:SPPnPService;

    public constructor(serviceBaseUrl: string,baseUrl:string, userEmail:string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.userEmail=userEmail;
        this.apiService = new XJTApiService();
        this.sharePointService= new SPPnPService(baseUrl);
    }

    public getMyItemsByID(): Promise<MyFavouritesItem[]> {
       
        let apiMethodUrl: string = MyItemServiceProxy.getItemByID(this.serviceBaseUrl,this.userEmail);
        let MyItemsPromise: Promise<MyFavouritesItem[]> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false);

        return MyItemsPromise;
    }

    public async getMyCommonItems(listTitle:string):Promise<CommonMyItemModel[]>
    {
        var commonItems: CommonMyItemModel[] = commonItems || [];
                let queryXML: string = `<View><Query><Where><Eq><FieldRef Name='IsActive'/><Value Type='Boolean'>1</Value></Eq></Where><OrderBy><FieldRef Name='ItemOrder' Ascending='True'/></OrderBy></Query></View>`;
        var items = await this.sharePointService.getListItems(listTitle, queryXML);
        if (items && items.length) {
            items.map((item: any) => {
                let commonItem:CommonMyItemModel=new CommonMyItemModel();
                commonItem.LinkTitle=item.Title;
                commonItem.Description=item.Description;
                commonItem.IsActive=item.IsActive;
                commonItem.LinkUrl=item.ItemURL.Url;
                commonItem.LinkAlternateText=item.ItemURL.Description;
                commonItem.LogoUrl=item.LogoURL.Url;
                commonItem.LogoAlternateText=item.LogoURL.Description;
                commonItem.TargetWindow=item.TargetWindow||"_self";
                commonItems.push(commonItem);
            });
        }

        return Promise.resolve(commonItems);
    }
   
}