import XJTApiService from "./XJTApiService";
import { TravelRequestServiceProxy } from "../common/serviceProxy";

export default class CrewTrainingTravelService {
  private serviceBaseUrl: string;
  private apiService: XJTApiService;

  public constructor(serviceBaseUrl: string) {
    this.serviceBaseUrl = serviceBaseUrl;
    this.apiService = new XJTApiService();
  }
  public getServiceBasedCollection(employeeNo: string): Promise<void> {
    //let modelContainer: TopStoryItemModelContainer = null;
    let apiMethodUrl: string = TravelRequestServiceProxy.getCrewInformation(
      this.serviceBaseUrl,
      employeeNo
    );
    let travelRequestItemsPromise: Promise<void> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8",
      },
      null,
      null,
      false
    );

    return travelRequestItemsPromise;
  }
}
