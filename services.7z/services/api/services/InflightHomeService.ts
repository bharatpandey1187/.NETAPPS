import XJTApiService from "./XJTApiService";
import { InFlightHomeServiceProxy } from "../common/serviceProxy";
import { InflightModelContainer } from "../models/InflightModelContainer";


export default class InflightHomeService {
    private serviceBaseUrl: string;
    private apiService: XJTApiService;

    public constructor(serviceBaseUrl: string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.apiService = new XJTApiService();
    }
    public getServiceBasedCollection(): Promise<InflightModelContainer> {
       //let modelContainer: TopStoryItemModelContainer = null;
        let apiMethodUrl: string = InFlightHomeServiceProxy.getInflightDashBoardData(this.serviceBaseUrl);
        let inFlightHomesItemsPromise: Promise<InflightModelContainer> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false);

        return inFlightHomesItemsPromise;
    }
}