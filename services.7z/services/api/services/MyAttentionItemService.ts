import XJTApiService from "./XJTApiService";
import { PromotedState } from "@pnp/sp";
import MyItemViewModel from "../models/MyItemViewModel";
import { MyAttentionItemsServiceProxy } from "../common/serviceProxy";
import SPPnPService from "../../sharepoint/services/SPPnPService";
import { CommonConstants, ListTitles } from "../constants/Constants";
import { Helper } from "../common/Helper";
import MyItemModel from "../models/MyItemModel";
import { CurrentUser } from "@pnp/sp/src/siteusers";
import MyItemViewModelContainer from "../models/MyItemViewModelContainer";

export default class MyAttentionItemService {
    private serviceBaseUrl: string;
    private userID: string;
    private apiService: XJTApiService;
    private sharePointService: SPPnPService;

    public constructor(serviceBaseUrl: string, siteUrl: string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.apiService = new XJTApiService();
        this.sharePointService = new SPPnPService(siteUrl);
    }

    public getAttentionItemsByEmpNo(empNo: string): Promise<MyItemViewModel[]> {
        let apiUrl: string = MyAttentionItemsServiceProxy.getItemsByEmpNo(this.serviceBaseUrl, empNo);
        var promise: Promise<MyItemViewModel[]> = this.apiService.fetch(apiUrl,
            {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            , null
            , false
            , true
            , false
        ) as Promise<MyItemViewModel[]>;
        return promise;
    }

    public getMyAttentionItemsByEmpNo(empNo:string):Promise<MyItemViewModelContainer>
    {
        let apiUrl: string = MyAttentionItemsServiceProxy.getMyItemsModelContainer(this.serviceBaseUrl, empNo);
        var promise: Promise<MyItemViewModelContainer> = this.apiService.fetch(apiUrl,
            {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            , null
            , false
            , true
            , false
        ) as Promise<MyItemViewModelContainer>;
        return promise;
    }

    public async DeleteAttentionItem(id:number):Promise<boolean>
    {
        let apiUrl:string=MyAttentionItemsServiceProxy.DeleteAttentionItem(this.serviceBaseUrl,id);
        var promise: any= await this.apiService.Delete(apiUrl,
            {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            , null
            , false
            , true            
        ) ;

        return Promise.resolve(promise.result);
    }

    public async getSharePointAttentionItems(): Promise<MyItemViewModel[]> {
        var attentionItems: MyItemViewModel[] = attentionItems || [];
        let currentUser: any = await this.sharePointService.getCurrentUser();
        let queryXML: string = `<View><Query><Where><Eq><FieldRef Name='flag'/><Value Type='Boolean'>0</Value></Eq></Where></Query></View>`;
        var items = await this.sharePointService.getListItems(ListTitles.AttentionItem, queryXML);
        if (items && items.length) {
            items.map((item: any) => {
                if (item.UsersId&&item.UsersId.indexOf(currentUser.Id) > -1) {
                    let attentionItem: MyItemViewModel = attentionItems.find(x => x.category === item.Category);
                    if (attentionItem) {
                        var model = new MyItemModel();
                        model.application = item.Application;
                        model.category = item.Category;
                        model.id = item.ID;
                        model.message = item.Title;
                        model.url = item.Link.Url;
                        model.empNo = this.userID;
                        model.targetWindow = "_blank";
                        model.dateCreated = item.Created;
                        model.itemType="SPListItem";
                        attentionItem.items = attentionItem.items || [];
                        attentionItem.items.push(model);
                    }
                    else {
                        attentionItem = new MyItemViewModel();
                        attentionItem.category = item.Category;
                        var model = new MyItemModel();
                        model.application = item.Application;
                        model.category = item.Category;
                        model.id = item.ID;
                        model.message = item.Title;
                        model.url = item.Link.Url;
                        model.empNo = this.userID;
                        model.targetWindow = "_blank";
                        model.dateCreated = item.Created;
                        model.itemType="SPListItem";
                        attentionItem.items = attentionItem.items || [];
                        attentionItem.items.push(model);

                        attentionItems.push(attentionItem);
                    }
                }
            });
        }
        return Promise.resolve(attentionItems);
    }
}