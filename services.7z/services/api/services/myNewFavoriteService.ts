import XJTApiService from "./XJTApiService";

import { MyFavoriteViewModel, MyFavouritesItemModelContainer } from "../../../services/api/models/NewmyFavViewModel";
import MenuService from "./NewMenuService";
export default class MenuItemService {

  private userID: string;
  public MenuService: MenuService;
  public constructor(SiteUrl: string, userID: string) {
    this.userID = userID;
    this.MenuService = new MenuService(SiteUrl);
  }

  public async getMyFavoriteItems(): Promise<MyFavouritesItemModelContainer> {
    const MenuItems = await this.MenuService.GetMenuItems();
    const MyFavConnexItems = await this.MenuService.GetMyFavConnexItems(Number(this.userID));
    let MyItemsPromise = await this.getdata(MenuItems, MyFavConnexItems);

    return MyItemsPromise;

  }
  private async getdata(MenuItems: any, MyFavConnexItems: any): Promise<any> {

    let viewModelContainer = new MyFavouritesItemModelContainer(MenuItems);
    let myfavcon1: MyFavoriteViewModel[] = [];
    if (MenuItems != null) {
      for (let myfavitem = 0; myfavitem < MyFavConnexItems.length; myfavitem++) {
        for (let MenuItem = 0; MenuItem < MenuItems.length; MenuItem++) {
          myfavcon1.push(await this.findObjectByLabel(MenuItems[MenuItem], MyFavConnexItems[myfavitem], myfavitem));
        }
        this.getObject(MenuItems, MyFavConnexItems[myfavitem].Menu_Id);
      }
      viewModelContainer.myFavourites = myfavcon1.filter((e) => { return e; });
      viewModelContainer.allItems = MenuItems.filter((e) => { return e; });
    }

    return viewModelContainer;
  }


  private getObject(theObject, id) {
    var result = null;
    if (theObject instanceof Array) {
      for (var i = 0; i < theObject.length; i++) {
        result = this.getObject(theObject[i], id);
        if (result) {
          break;
        }
      }
    }
    else {
      for (var prop in theObject) {
        if (prop == 'id') {
          if (theObject[prop] == id) {
            theObject.isSelected = true;
          }
        }
        if (theObject[prop] instanceof Object || theObject[prop] instanceof Array) {
          result = this.getObject(theObject[prop], id);
          if (result) {
            break;
          }
        }
      }
    }
  }
  private findObjectByLabel(obj, label, level): MyFavoriteViewModel {
    if (obj.id === label.Menu_Id) {
      obj.favoriteName = label.Title;
      obj.path = label.Title;
      obj.menuItemSequence = label.Seq;
      // obj.order = label.ID;
      //obj.level=level;
      //obj.isSelected = true;
      return (obj);

    }
    else if (obj.securedSubMenu.length > 0)
      for (var i in obj.securedSubMenu) {
        let dat = this.findObjectByLabel(obj.securedSubMenu[i], label, level);
        if (typeof dat !== "undefined") {
          return dat;
        }
      }

  }
}

