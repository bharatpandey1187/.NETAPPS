import XJTApiService from "./XJTApiService";
import { MyFavoriteViewModel, MyFavouritesItemModelContainer } from "../../../services/api/models/EditMyFavouritesItem";
import { EditMyFavouritesItemServiceProxy } from "../common/EditMyFavouritesItemServiceProxy";
export default class MyItemService {
    private serviceBaseUrl: string;
    private userEmail: string;
    private apiService: XJTApiService;

    public constructor(serviceBaseUrl: string, userEmail: string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.userEmail = userEmail;
        this.apiService = new XJTApiService();
    }

    public getMyItemsByID(): Promise<MyFavoriteViewModel[]> {

        let apiMethodUrl: string = EditMyFavouritesItemServiceProxy.getItemByID(this.serviceBaseUrl, this.userEmail);
        let MyItemsPromise: Promise<MyFavoriteViewModel[]> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false);

        return MyItemsPromise;
    }

    public getAllMenuItems(): Promise<MyFavouritesItemModelContainer> {

        let apiMethodUrl: string = EditMyFavouritesItemServiceProxy.getAllMenuItem(this.serviceBaseUrl, this.userEmail);
        let MyItemsPromise: Promise<MyFavouritesItemModelContainer> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false);

        return MyItemsPromise;
    }


    public setMyFavouritesItems(body: string): Promise<number> {
        let apiMethodUrl: string = EditMyFavouritesItemServiceProxy.saveMyFavouritesItems(
            this.serviceBaseUrl, ""
        );
        let saveItemPromise: Promise<number> = this.apiService.post(
            apiMethodUrl,
            {
                Accept: "application/json",
                "Content-Type": "application/json;charset=utf-8"
            },
            body,
            null,
            false
        );
        return saveItemPromise;
    }




}