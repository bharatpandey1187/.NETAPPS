import ISharePointService from "../../sharepoint/services/ISharePointService";
import SPPnPService from "../../sharepoint/services/SPPnPService";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { Items, App } from "@pnp/sp";
import { Helper } from "../common/Helper";
import SessionStorageService from "../common/SessionStorageService";
import * as $ from "jquery";
import AppConfig from "../models/AppConfig";
import { StorageConfigKeys, ListTitles } from "../constants/Constants";

export default class AppConfigService {
  private ConfigList: AppConfig<string, any>[];
  private sharepointService: ISharePointService;

  constructor(private webUrl: string) {
    this.sharepointService = new SPPnPService(this.webUrl);
  }

  private get GetConfigList(): AppConfig<string, any>[] {
    var currentConfigs: any[] = [];
    this.ConfigList = SessionStorageService.getItem<AppConfig<string, any>[]>(
      StorageConfigKeys.AppSettingKeyConfigList
    );
    if (!this.ConfigList) {
      let queryXML: string = "";
      let getItemsPromise: Promise<any> = this.sharepointService.getListItems(
        ListTitles.AppConfig,
        queryXML,
        500
      );
      if (getItemsPromise) {
        getItemsPromise.then((items: any) => {
          $.each(items, (index: number, item) => {
            currentConfigs.push(
              new AppConfig<string, any>(item.Title, item.ConfigValue)
            );
          });

          this.ConfigList = currentConfigs;
          SessionStorageService.AddItem(
            StorageConfigKeys.AppSettingKeyConfigList,
            JSON.stringify(this.ConfigList)
          );
        });
      }
    }
    return this.ConfigList;
  }

  public async GetConfigItemByKey(key: string): Promise<string> {
    let configValue: string;
    var currentConfigs: any[] = [];
    this.ConfigList = SessionStorageService.getItem<AppConfig<string, any>[]>(
      StorageConfigKeys.AppSettingKeyConfigList
    );
    if (!this.ConfigList) {
      let queryXML: string = "";
      let items: any[] = await this.sharepointService.getListItems(
        ListTitles.AppConfig,
        queryXML,
        500
      );
      if (items) {
        $.each(items, (index: number, item) => {
          currentConfigs.push(
            new AppConfig<string, any>(item.Title, item.ConfigValue)
          );
        });
        this.ConfigList = currentConfigs;
        SessionStorageService.AddItem(
          StorageConfigKeys.AppSettingKeyConfigList,
          JSON.stringify(this.ConfigList)
        );
      }
    }

    this.ConfigList.forEach(element => {
      if (element.configKey == key) {
        configValue = element.configValue;
        return;
      }
    });
    return await Promise.resolve(configValue);
  }
}
