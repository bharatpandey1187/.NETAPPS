import XJTApiService from "./XJTApiService";
import {
  MyFavoriteViewModel,
  MyFavouritesItemModelContainer
} from "../models/EditMyFavouritesItem";
import { MenuFavoritesServiceProxy } from "../common/serviceProxy";
export default class MenuFavoritesService {
  private serviceBaseUrl: string;
  private userID: string;
  private apiService: XJTApiService;

  public constructor(serviceBaseUrl: string, userID: string) {
    this.serviceBaseUrl = serviceBaseUrl;
    this.userID = userID;
    this.apiService = new XJTApiService();
  }

  public async getMyItemsByID(): Promise<MyFavoriteViewModel[]> {
    let apiMethodUrl: string = MenuFavoritesServiceProxy.getItemByID(
      this.serviceBaseUrl,
      this.userID
    );
    let MyItemsPromise: Promise<MyFavoriteViewModel[]> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      false
    );

    return MyItemsPromise;
  }

  public getMenuFavoritesViewModelContainer(): Promise<
    MyFavouritesItemModelContainer
  > {
    let apiMethodUrl: string = MenuFavoritesServiceProxy.getMenuFavoritesViewModelContainer(
      this.serviceBaseUrl,
      this.userID
    );
    let MyItemsPromise: Promise<MyFavouritesItemModelContainer> = this.apiService.fetch(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      null,
      null,
      true
    );

    return MyItemsPromise;
  }

  public setMyFavouritesItems(body: string): Promise<number> {
    let apiMethodUrl: string = MenuFavoritesServiceProxy.saveMyFavouritesItems(
      this.serviceBaseUrl,
      this.userID
    );
    let saveItemPromise: Promise<number> = this.apiService.post(
      apiMethodUrl,
      {
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8"
      },
      body,
      null,
      false
    );
    return saveItemPromise;
  }
}
