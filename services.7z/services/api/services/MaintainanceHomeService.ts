import XJTApiService from "./XJTApiService";
import { InFlightHomeServiceProxy, MaintainanceHomeServiceProxy } from "../common/serviceProxy";


export default class MaintainanceHomeService {
    private serviceBaseUrl: string;
    private apiService: XJTApiService;

    public constructor(serviceBaseUrl: string) {
        this.serviceBaseUrl = serviceBaseUrl;
        this.apiService = new XJTApiService();
    }
    public getServiceBasedCollection(safetyType:string, month: number, year: number): Promise<void> {
       //let modelContainer: TopStoryItemModelContainer = null;
        let apiMethodUrl: string = MaintainanceHomeServiceProxy.getPerformanceStats(this.serviceBaseUrl,safetyType,month,year);
        let inFlightHomesItemsPromise: Promise<void> = this.apiService.fetch(apiMethodUrl, {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=utf-8"
        }, null, null, false);

        return inFlightHomesItemsPromise;
    }
}