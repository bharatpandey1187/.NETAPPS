import ISharePointService from "../../sharepoint/services/ISharePointService";
import {
  MyFavoriteViewModel,
  MyFavouritesItemModelContainer
} from "../models/NewmyFavViewModel";
import { CommonConstants, ListTitles } from "../constants/Constants";
import SPPnPService from "../../sharepoint/services/SPPnPService";


export default class MenuService {
  private sharePointService: ISharePointService;
  constructor(private webUrl: string) {
    this.sharePointService = new SPPnPService(this.webUrl);
  }


  public async GetMyFavConnexItems(EmpNo: number) {
    let camlQuery: string = "<View><Query><Where><Eq><FieldRef Name='EmpNo' /><Value Type='Number'>" + EmpNo + "</Value></Eq></Where></Query></View>";
    var result = await this.sharePointService.getListItems(ListTitles.MenuFavorites, camlQuery, 5000);
    return result;
  }
  //Gets the URL of the Item
  private GetURL(linkUrl: string): string {
    linkUrl = linkUrl && linkUrl !== 'NULL' ? linkUrl : '';
    if (linkUrl) {
      if (linkUrl.indexOf("http://") == 0 || linkUrl.indexOf("https://") == 0) {
        return linkUrl;
      }

    }
    else {
      return "javascript:void(0)";
    }
    return linkUrl;
  }

  public async GetMenuItems(): Promise<MyFavoriteViewModel[]> {
    let camlQuery: string = "<View><Query><Where><Eq><FieldRef Name='Enabled'/><Value Type='Boolean'>1</Value></Eq></Where></Query><ViewFields><FieldRef Name='ID'></FieldRef><FieldRef Name='Title'></FieldRef><FieldRef Name='ParentId'></FieldRef><FieldRef Name='TargetURL'></FieldRef><FieldRef Name='TargetWindow'></FieldRef><FieldRef Name='Enabled'></FieldRef><FieldRef Name='Sequence'></FieldRef><FieldRef Name='UniqueName'></FieldRef><FieldRef Name='IsXJTAppUrl'></FieldRef></ViewFields></View>"
    var result = await this.sharePointService.getListItems(ListTitles.Menu, camlQuery, 5000);
    let items: MyFavoriteViewModel[] = [];
    if (result) {
      result.forEach((listItem) => {
        if (listItem.ParentId === 0) {
          let securedMenuItem: MyFavoriteViewModel = {
            id: Number(listItem.ID),
            parentId: Number(listItem.ParentId),
            menuText: String(listItem.Title),
            uniqueName: String(listItem.UniqueName),
            targetUrl: this.GetURL(listItem.TargetURL),
            targetWindow: !listItem.TargetWindow || listItem.TargetWindow == "NULL" ? "" : listItem.TargetWindow,
            menuItemSequence: Number(listItem.Sequence),
            securedSubMenu: [] as MyFavoriteViewModel[],
            isSelected: false,
            path: listItem.Title,
            IsXjtAppUrl: listItem.IsXJTAppUrl
            //enabled: listItem.Enabled,
          };
          items.push(securedMenuItem);
        }
      });

      //Populate securedSubMenu
      result.forEach((childItem) => {
        // ONLY ADD THE ITEMS IN THE CHILD LIST IF THE ITEM IS NOT ALREADY THERE
        if (!this.FindMenuItem(items, childItem.id)) {
          if (childItem.ParentId !== 0) {
            let securedMenuItem: MyFavoriteViewModel = {
              id: childItem.ID,
              parentId: childItem.ParentId,
              menuText: childItem.Title,
              uniqueName: childItem.UniqueName,
              targetUrl: this.GetURL(childItem.TargetURL),
              targetWindow: !childItem.TargetWindow || childItem.TargetWindow === "NULL" ? "" : childItem.TargetWindow,
              menuItemSequence: childItem.Sequence,
              securedSubMenu: [] as MyFavoriteViewModel[],
              isSelected: false,
              path: childItem.Title,
              IsXjtAppUrl: childItem.IsXJTAppUrl
              //  path:String(items.menuText+"/"+childItem.UniqueName)
              //enabled: childItem.Enabled,
            };
            if ((typeof securedMenuItem !== "undefined") && (securedMenuItem.parentId !== null) && (securedMenuItem.parentId !== NaN)) {
              let parentItem: MyFavoriteViewModel = this.FindParentItem(items, securedMenuItem.parentId);
              if (parentItem) {
                securedMenuItem.path = parentItem.path + "/" + securedMenuItem.menuText;
                parentItem.securedSubMenu.push(securedMenuItem);
              }
            }
          }
        }
      });
    }
    if (items) {
      items.sort((first, second) => {
        return (first.menuItemSequence - second.menuItemSequence);
      });
      items.sort(this.sortSecureMenuItem);
      items.forEach((item: MyFavoriteViewModel) => {
        this.sortSubMenu(item);
      })
    }
    return Promise.resolve(items);
  }
  private sortSubMenu(item: MyFavoriteViewModel) {
    if (item.securedSubMenu.length == 0)
      return;
    item.securedSubMenu.sort(this.sortSecureMenuItem);
    item.securedSubMenu.forEach(subMenuItem => {
      this.sortSubMenu(subMenuItem);
    });
  }
  private sortSecureMenuItem(first: MyFavoriteViewModel, second: MyFavoriteViewModel): number {
    return (first.menuItemSequence - second.menuItemSequence);
  }
  private FindMenuItem(items: MyFavoriteViewModel[], menuID: number): MyFavoriteViewModel {
    var item = null;
    for (let i = 0; i < items.length; i++) {
      if (items[i].id == menuID) {
        item = items[i];
        break;
      }

      if (items[i].securedSubMenu.length > 0) {
        item = this.FindMenuItem(items[i].securedSubMenu, menuID);
        if (item) {
          return item;
        }
      }
    }

    return item;
  }

  private FindParentItem(items: MyFavoriteViewModel[], menuID: number) {
    for (let itemIndex = 0; itemIndex < items.length; itemIndex++) {
      if (items[itemIndex].id === menuID) {
        return items[itemIndex];
      }

      if (items[itemIndex].securedSubMenu.length > 0) {
        let found = this.FindParentItem(items[itemIndex].securedSubMenu, menuID);
        if (found) {
          return found;
        }
      }
    }

    return null;
  }
}