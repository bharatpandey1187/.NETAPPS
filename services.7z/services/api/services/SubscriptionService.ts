import SPPnPService from "../../sharepoint/services/SPPnPService";
import AppConfigService from "./AppConfigService";
import { NewsItemFrequencyModel } from "../models/SubscribeNewItemFrequeryModel";
import UserSubscriptionModel from "../models/UserSubscriptionModel";
import NewsCategoryItemModel from "../models/SubscribeItemModel";
import { ListTitles, CommonConstants } from "../../../services/api/constants/Constants";
import { Helper } from "../common/Helper";
import {

    Web,

} from "@pnp/sp";

export default class SubscriptionService {
    private SharePontService: SPPnPService;
    constructor(private serviceBaseUrl: string, private siteUrl: string) {
        this.SharePontService = new SPPnPService(this.siteUrl);
    }
    /**
     * Gets new item frequency types
     * @returns new item frequency types 
     */
    public GetNewItemFrequencyTypes(): NewsItemFrequencyModel[] {
        let newsItemFrequncyModels: NewsItemFrequencyModel[] = [];
        let frequencyItemType = new NewsItemFrequencyModel();
        frequencyItemType.ID = 1;
        frequencyItemType.Selected = true;
        frequencyItemType.FrequencyType = "Daily";
        newsItemFrequncyModels.push(frequencyItemType);

        frequencyItemType = new NewsItemFrequencyModel();
        frequencyItemType.ID = 2;
        frequencyItemType.Selected = false;
        frequencyItemType.FrequencyType = "Weekly";
        newsItemFrequncyModels.push(frequencyItemType);

        return newsItemFrequncyModels;
    }

    /**
     * Gets user subscriptions by Email
     * @param userEmail 
     * @returns user subscriptions 
     */
    public async GetUserSubscriptions(userEmail: string): Promise<UserSubscriptionModel[]> {

        let userSubscriptions: UserSubscriptionModel[] = [];
        let camlQuery: string = "<View><Query><Where><Eq><FieldRef Name='Enabled'/><Value Type='Boolean'>1</Value></Eq></Where></Query><ViewFields><FieldRef Name='Title'/><FieldRef Name='Enabled'/><FieldRef Name='ID'/></ViewFields><RowLimit>5000</RowLimit></View>";
        var newCategories: NewsCategoryItemModel[] = await this.SharePontService.getListItems(ListTitles.NewsCategories, camlQuery) as NewsCategoryItemModel[];

        if (newCategories && newCategories.length > 0) {
            let camlQuery: string = "<View><Query><Where><Eq><FieldRef Name='UserEmail'/><Value Type='Text'>" + userEmail + "</Value></Eq></Where></Query><ViewFields><FieldRef Name='Title'/><FieldRef Name='ID'/><FieldRef Name='Subscribe'/><FieldRef Name='Frequency'/><FieldRef Name='UserEmail'/></ViewFields><RowLimit>5000</RowLimit></View>";

            let userNewsSubscriptionItems: any[] = await this.SharePontService.getListItems(ListTitles.NewsSubscriptions, camlQuery);

            newCategories.map((newsCategoryItem: NewsCategoryItemModel) => {
                let subscription: UserSubscriptionModel = new UserSubscriptionModel();
                subscription.ID = newsCategoryItem.ID;
                subscription.Name = newsCategoryItem.Title;

                let newsSubscription;
                if (userSubscriptions) {
                    newsSubscription = userNewsSubscriptionItems.find((sub => sub.Title == newsCategoryItem.Title));
                }

                if (newsSubscription) {
                    subscription.DisableSelected = true;
                    subscription.CheckboxChecked = true;
                    subscription.Frequency = newsSubscription.Frequency == "Daily" ? "2" : "1";
                }
                else {
                    subscription.DisableSelected = false;
                    subscription.CheckboxChecked = false;
                    subscription.Frequency = "1";
                }

                userSubscriptions.push(subscription);
            });
            return Promise.resolve(userSubscriptions);
        }
    }

    public async UpdateAndDeleteNewsSubscriptions(userEmail: string, userSubscriptions: UserSubscriptionModel[]): Promise<boolean> {
        let result: boolean = false;
        let spObject: Web = this.SharePontService.Current();

        if (spObject) {
            var list = spObject.lists.getByTitle(ListTitles.NewsSubscriptions);
            var batch = spObject.createBatch();
            var listItems: any[] = await list.items.filter(Helper.format("UserEmail eq '{0}'", userEmail)).get();

            if (listItems && listItems.length > 0) {
                //DELETE ITEMS WHICH ARE IN THE LIST BUT NOT SELECTED IN THE USER SUBSCRIPTION
                userSubscriptions.filter(x => x.CheckboxChecked == false).forEach(async (subscription: UserSubscriptionModel) => {
                    var targetListItem = listItems.find(x => x.Title == subscription.Name);
                    if (targetListItem) {
                        await list.items.getById(targetListItem.Id).inBatch(batch).delete();
                    }
                });
            }

            const entityTypeFullName = await list.getListItemEntityTypeFullName();
            //UPDATE  OR INSERT ITEMS WHICH ARE IN THE LIST BUT NOT SELECTED IN THE USER SUBSCRIPTION
            userSubscriptions.filter(x => x.CheckboxChecked == true).forEach(async (subscription: UserSubscriptionModel) => {

                var targetListItem = listItems && listItems.find(x => x.Title == subscription.Name);
                if (targetListItem) {
                    await list.items.getById(targetListItem.ID).inBatch(batch).update({
                        Frequency: subscription.Frequency == "2" ? "Daily" : "Weekly",
                    }, "*", entityTypeFullName);
                }
                else {
                    await list.items.inBatch(batch).add({
                        Frequency: subscription.Frequency == "2" ? "Daily" : "Weekly",
                        Title: subscription.Name,
                        Subscribe: "true",
                        UserEmail: userEmail
                    }, entityTypeFullName);
                }
            });
            await batch.execute();
            result = true;
        }

        return Promise.resolve(result);
    }    
}