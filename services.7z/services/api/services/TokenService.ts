import XJTApiService from "./XJTApiService";
import IUser from "../models/User";
import { TokenServiceProxy } from "../common/serviceProxy";
import SessionStorageService from "../common/SessionStorageService";
import { StorageConfigKeys, CommonConstants } from "../constants/Constants";

export default class TokenService {
    private apiService: XJTApiService;
    constructor(private serviceBaseUrl: string) {
        this.apiService = new XJTApiService();
    }

    public async GetToken(): Promise<string> {
        let token: string = SessionStorageService.getItem(StorageConfigKeys.BearerToken);
        if (!token || token === "") {
            let apiUrl: string = TokenServiceProxy.getToken(this.serviceBaseUrl);
            let headers: any = {
                "Accept": "application/json",
                "Content-Type": "application/json;charset=utf-8;"
            };

            token = await this.apiService.fetch(apiUrl, headers, null, false, false);
            if (token && token != CommonConstants.EMPTY_STRING) {
                SessionStorageService.AddItem(StorageConfigKeys.BearerToken, token);
            }
        }

        return Promise.resolve(token);
    }
}