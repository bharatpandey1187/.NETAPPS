import { Helper } from "./Helper";

class TopStoryServiceProxy {
  public static getItemByCategory(
    serviceBaseUrl: string,
    categoryID: number,
    maxRows: number
  ): string {
    return Helper.format(
      "{0}/v1/CmsContent/GetByCategory?categoryID={1}&maxRows={2}",
      serviceBaseUrl,
      categoryID,
      maxRows
    );
  }
}
class FileUploadPostproxy {
  public static postFiledetails(serviceBaseUrl: string): string {
    return Helper.format("{0}/v1/photosubmission/Create", serviceBaseUrl);
  }
}
class SafetyChartServiceProxy {
  public static getitem(serviceBaseUrl: string): string {
    return Helper.format(
      "{0}/v1/PerformanceStats/SafetyHomeChartStats",
      serviceBaseUrl
    );
  }
}
class AnniversaryServiceProxy {
  public static getitem(serviceBaseUrl: string): string {
    return Helper.format("{0}/v1/asauser/getAnniversary", serviceBaseUrl);
  }
}
class XJTPerformanceProxy {
  public static GetDashboardData(
    serviceBaseUrl: string,
    date: string,
    location: string
  ): string {
    return Helper.format(
      "{0}/v1/PerfDashboard/GetDashboardData?dateTime={1}&location={2}",
      serviceBaseUrl,
      date,
      location
    );
  }
  public static GetDashboardDataFiltered(
    serviceBaseUrl: string,
    month: string,
    year: string
  ): string {
    return Helper.format(
      "{0}/v1/PerfDashboard/GetDashboardDataFiltered?month={1}&year={2}",
      serviceBaseUrl,
      month,
      year
    );
  }
  public static GetRTPByStation(
    serviceBaseUrl: string,
    date: string,
    station: string
  ): string {
    return Helper.format(
      "{0}/v1/PerfDashboard/GetDashboardData?dateTime={1}&stationName={2}",
      serviceBaseUrl,
      date,
      station
    );
  }
  public static GetSWAPWeatherData(
    serviceBaseUrl: string,
    LocationID: string
  ): string {
    return Helper.format(
      "{0}/v1/PerfDashboard/GetSWAPWeatherData?location={1}",
      serviceBaseUrl,
      LocationID
    );
  }
  public static FilterFlightsByStatus(
    serviceBaseUrl: string,
    date: string,
    stationCode: string,
    carrierCode: string,
    requestType: string
  ): string {
    return Helper.format(
      "{0}/v1/flight/FilterFlightsByStatus?dateTime={1}&stationCode={2}&carrierCode={3}&requestType={4}",
      serviceBaseUrl,
      date,
      stationCode,
      carrierCode,
      requestType
    );
  }
}
class QuickLinksServiceProxy {
  public static getQuickLinksForUser(
    serviceBaseUrl: string,
    linkID: string,
    userID: string
  ): string {
    return Helper.format(
      "{0}/v1/QuickLinks/GetByUser?linkID={1}&email={2}",
      serviceBaseUrl,
      linkID,
      userID
    );
  }
}

class InFlightHomeServiceProxy {
  public static getInflightDashBoardData(serviceBaseUrl: string): string {
    return Helper.format("{0}/v1/InFlight/GetDashboardData", serviceBaseUrl);
  }
}

class MaintainanceHomeServiceProxy {
  public static getPerformanceStats(
    serviceBaseUrl: string,
    safetyType: string,
    month: number,
    year: number
  ): string {
    return Helper.format(
      "{0}/v1/PerformanceStats/GetBySafetyType?safetyType={1}&month={2}&year={3}",
      serviceBaseUrl,
      safetyType,
      month,
      year
    );
  }
}

class MenuFavoritesServiceProxy {
  public static getItemByID(serviceBaseUrl: string, userEmail: string): string {
    return Helper.format(
      "{0}/v1/MyFavorites/GetById?empNo={1}",
      serviceBaseUrl,
      userEmail
    );
  }
  public static getMenuFavoritesViewModelContainer(
    serviceBaseUrl: string,
    empNo: string
  ): string {
    return Helper.format(
      "{0}/v1/MyFavorites/GetAllInclFavorites?empNo={1}",
      serviceBaseUrl,
      empNo
    );
  }

  public static saveMyFavouritesItems(
    serviceBaseUrl: string,
    userEmail: string
  ): string {
    return Helper.format(
      "{0}/v1/MyFavorites/SaveMyFavorites?empNo={1}",
      serviceBaseUrl,
      userEmail
    );
  }
}

class TokenServiceProxy {
  private constructor() {}

  public static getToken(serviceBaseUrl: string): string {
    return Helper.format("{0}/v1/Token", serviceBaseUrl);
  }
}

class AuthorizationServiceProxy {
  private constructor() {}
  public static getSecurityGroupsByPrincipal(
    serviceBaseUrl: string,
    principal: string
  ): string {
    return Helper.format(
      "{0}/v1/security/GetByPrincipal?principal={1}",
      serviceBaseUrl,
      principal
    );
  }
}

class RelocationRequestServiceProxy {
  public static getUserInformationData(
    serviceBaseUrl: string,
    empNo: string
  ): string {
    return Helper.format(
      "{0}/v1/asauser/getMgrInfo?empNo={1}",
      serviceBaseUrl,
      empNo
    );
  }
}

class CrewTrainingTravelServiceProxy {
  public static getCrewInformation(
    serviceBaseUrl: string,
    empNo: string
  ): string {
    return Helper.format(
      "{0}/v1/asauser/getMgrInfo?empNo={1}",
      serviceBaseUrl,
      empNo
    );
  }
}

class CommodityModelServiceProxy {
  public static getCommodityDetail(serviceBaseUrl: string): string {
    return Helper.format("{0}/v1/commodities/GetDetail", serviceBaseUrl);
  }
}

class MyAttentionItemsServiceProxy {
  public static getItemsByEmpNo(serviceBaseUrl: string, empNo: string): string {
    return Helper.format(
      "{0}/v1/MyItems/GetByEmpNo?empNo={1}",
      serviceBaseUrl,
      empNo
    );
  }

  public static DeleteAttentionItem(
    serviceBaseUrl: string,
    id: number
  ): string {
    return Helper.format("{0}/v1/MyItems/Delete/{1}", serviceBaseUrl, id);
  }

  public static getMyItemsModelContainer(
    serviceBaseUrl: string,
    empNo: string
  ): string {
    return Helper.format(
      "{0}/v1/MyItems/GetMyItems/{1}",
      serviceBaseUrl,
      empNo
    );
  }
}

class ChemicalRequestServiceProxy {
  public static getStations(serviceBaseUrl: string): string {
    return Helper.format("{0}/v1/StationProfile/GetStation", serviceBaseUrl);
  }
}

class TravelRequestServiceProxy {
  public static getCrewInformation(
    serviceBaseUrl: string,
    empNo: string
  ): string {
    return Helper.format(
      "{0}/v1/asauser/getMgrInfo?empNo={1}",
      serviceBaseUrl,
      empNo
    );
  }
}

export {
  TopStoryServiceProxy,
  InFlightHomeServiceProxy,
  MaintainanceHomeServiceProxy,
  SafetyChartServiceProxy,
  AnniversaryServiceProxy,
  FileUploadPostproxy,
  QuickLinksServiceProxy,
  XJTPerformanceProxy,
  MenuFavoritesServiceProxy,
  TokenServiceProxy,
  AuthorizationServiceProxy,
  RelocationRequestServiceProxy,
  CrewTrainingTravelServiceProxy,
  CommodityModelServiceProxy,
  MyAttentionItemsServiceProxy,
  ChemicalRequestServiceProxy,
  TravelRequestServiceProxy,
};
