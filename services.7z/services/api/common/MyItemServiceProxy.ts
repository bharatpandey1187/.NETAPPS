import { Helper } from './Helper';
class MyItemServiceProxy {
    public static getItemByID(serviceBaseUrl: string,userEmail:string): string {
        return Helper.format("{0}/v1/MyFavorites/GetById?empNo=75003", serviceBaseUrl);
    }
}

export { MyItemServiceProxy };