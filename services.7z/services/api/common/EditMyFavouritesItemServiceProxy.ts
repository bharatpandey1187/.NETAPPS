import { Helper } from './Helper';
class EditMyFavouritesItemServiceProxy {
    public static getItemByID(serviceBaseUrl: string,userEmail:string): string {
        return Helper.format("{0}/v1/MyFavorites/GetById?empNo=7020431", serviceBaseUrl);
    }
    public static getAllMenuItem(serviceBaseUrl: string,userEmail:string): string {
        return Helper.format("{0}/v1/MyFavorites/GetAllInclFavorites?empNo=7020431", serviceBaseUrl);
    }
    
    public static saveMyFavouritesItems(serviceBaseUrl: string,userEmail:string): string {
        return Helper.format("{0}/v1/MyFavorites/SaveMyFavorites?empNo=7020431", serviceBaseUrl,userEmail);
    }
    
}

export { EditMyFavouritesItemServiceProxy };