export default class SessionStorageService {

    //SET STORAGE SETTING ITEM BY KEY
    public static AddItem(key: string, value: string): boolean {
        let item: string = sessionStorage.getItem(key);
        if (item == null || item == "null") {
            sessionStorage.setItem(key, value);
            return true;
        }
        
        return false;
    }

    //GET STORAGE SETTING ITEM BY KEY
    public static getItem<T>(key: string): T {
        let item: string = sessionStorage.getItem(key);
        let result: any;
        if (item === "null") {
            result = null;
        }
        else {
            result = this.IsJson(item) ? JSON.parse(item) as T : item;
        }

        return result;
    }

    private static IsJson(inputData):boolean {
        try {
            JSON.parse(inputData);
        } catch (e) {
            return false;
        }
        return true;
    }
}