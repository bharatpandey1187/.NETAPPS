import * as moment from "moment-timezone";
class Helper {
  public static toFixed(value: number, precison: number): string {
    if (value) return value.toFixed(precison);
    else return "";
  }

  public static getParameterByName(name: string, url: string): string {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  }

  public static format(inputString: string, ...values: any[]) {
    if (values) {
      for (let index = 0; index < values.length; index++) {
        inputString = inputString.replace(`{${index}}`, values[index]);
      }
    }

    return inputString;
  }
  public static handleNumbers(value: number) {
    if (this.isInt(value)) {
      return value;
    } else {
      return this.round(value, 1);
    }
  }

  public static isInt(value): boolean {
    return !isNaN(value) &&
      parseInt(value) === value &&
      !isNaN(parseInt(value, 10));
  }
  public static round(value: number, decimals: number) {
    return Number(Math.round(+(value + "e" + decimals)) + "e-" + decimals);
  }
  public static convertTimezone(date)
  {
    var abbrs = {
      EST : 'Eastern',
      EDT : 'Eastern',
      CST : 'Central',
      CDT : 'Central',
      MST : 'Mountain',
      MDT : 'Mountain',
      PST : 'Pacific',
      PDT : 'Pacific',
  };
  
    var tZone=moment.tz(date,moment.tz.guess()).format('z');
    moment.fn.zoneName = function (){this.zoneAbbr(); return abbrs[tZone] || tZone};
    var timeZone=moment.tz(date,moment.tz.guess()).format('zz');
 
    var createdTIme = moment
      .tz(date, moment.tz.guess())
      .format("MM/DD/YYYY hh:mm A");
      return (createdTIme+" "+timeZone);
  }
}


export { Helper };
