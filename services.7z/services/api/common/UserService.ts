import * as pnp from "@pnp/sp";
import { CommonConstants } from "../constants/Constants";
import SessionStorageService from "./SessionStorageService";
import AppConfig from "../models/AppConfig";
import { StorageConfigKeys } from "../constants/Constants";

export default class UserService {
  constructor() { }

  public async GetCurrentUserEmployeeNumber(): Promise<string> {
    let empNo: string;
    empNo = SessionStorageService.getItem<string>(StorageConfigKeys.EMPID);
    if (!empNo) {
      await pnp.sp.profiles.myProperties.get().then(function (result) {
        var userProperties = result.UserProfileProperties;
        userProperties.forEach(function (property) {
          if (property.Key.toLowerCase() === CommonConstants.USERPROFILEPROPERTYEMPNO.toLowerCase()) {
            empNo = property.Value;
            SessionStorageService.AddItem(StorageConfigKeys.EMPID, empNo);
            return;
          }
        });
      });
    } else {
      return Promise.resolve(empNo);
    }
    return Promise.resolve(empNo);
  }
}
