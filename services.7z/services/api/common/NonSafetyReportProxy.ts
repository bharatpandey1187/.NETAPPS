import { Helper } from './Helper';
class NonSafetyReportProxy {
  public static getNonSafetyReportItem(serviceBaseUrl: string, userID: string): string {
    return Helper.format("{0}/v1/NSR/GetNonSafetyReportData?empNo={1}", serviceBaseUrl, userID);
  }
  public static flightRelatedEventItem(serviceBaseUrl: string, eventDate: string): string {
    return Helper.format("{0}/v1/flight/FilterFlightsByDate?dateTime={1}", serviceBaseUrl,eventDate);
  }
  public static geViewItem(serviceBaseUrl: string, eventID: number): string {
    return Helper.format("{0}/v1/NSR/GetByEventID?eventID={1}", serviceBaseUrl, eventID);
  }
  public static saveFlightEvent(serviceBaseUrl: string, userID: string): string {
    return Helper.format(
      "{0}/v1/NSR/SubmitEvents?empNo={1}", serviceBaseUrl, userID);
  }
  public static saveDraftFlightEvent(serviceBaseUrl: string, userID: string): string {
    return Helper.format(
      "{0}/v1/NSR/SaveDraft", serviceBaseUrl);
  }

  public static deletFlightEvent(serviceBaseUrl: string, eventID: number): string {
    return Helper.format(
      "{0}/v1/NSR/Delete?eventID={1}", serviceBaseUrl, eventID);
  }
}





export { NonSafetyReportProxy };