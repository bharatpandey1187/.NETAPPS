export class ListTitles {
  private constructor() { }
  public static readonly AppConfig: string = "AppConfig";
  public static readonly EvContact: string = "EvContact";
  public static readonly EvContactCats: string = "EvContactCats";
  public static readonly XjtContactDropdown: string = "XjtContactDropdown";
  public static readonly SubmitPhoto: string = "SubmitPhoto";
  public static readonly NewsSubscriptions: string = "NewsSubscriptions";
  public static readonly NewsCategories: string = "NewsCategories";
  public static readonly NonSafetyReport: string = "NonSafetyReport";
  public static readonly Menu: string = "TopNavigation";
  public static readonly ControllableControl: string = "ControllableControl";
  public static readonly AttentionItem: string = "Attention";
  public static readonly MenuFavorites: string = "MenuFavorites";
}

export class CommonConstants {
  public static readonly EMPTY_STRING: string = "";
  public static readonly USERPROFILEPROPERTYEMPNO = "employeeID";
  public static readonly DATEFORMAT = "MM/DD/YYYY";
  public static readonly LastControlGroup = "LastControlGroup";
}

export class StorageConfigKeys {
  private constructor() { }
  public static readonly EMPID = "EMPID";
  public static readonly AppSettingKeyConfigList = "APPCONFIG";
  public static readonly BearerToken = "AuthToken";
  public static readonly UserSecurityGroups = "UserSecurityGroups";
}

export class AppConfigKeys {
  private constructor() { }
  public static readonly XjtApiURL = "XJTApiURL";
  public static readonly XJTAppUrl = "XJTAppUrl";
  public static readonly TypeCategory = "TypeCats";
  public static readonly DivisionType = "DivisionType";
  public static readonly Title = "Title";
  public static readonly EventNotificationPageUrl: string = "MyItemEventNotificationLinkUrl";
}

export class Format {
  private constructor() { }
  public static readonly DateFormat = "YYYYMMDDhhmmss";
}
export class LOGSOURCE {
  public static readonly EVTopStories = "EVTOPSTORIES";
  public static readonly QuickLinks = "QUICKLINKS";
  public static readonly CommoditiesDetail = "COMMODITIES";
  public static readonly RelocationRequest = "RELOCATIONREQUEST";
  public static readonly Badge = "BADGE";
  public static readonly EvContact = "EVCONTACT";
  public static readonly Anniversary = "ANNIVERSARY";
  public static readonly InFlight = "INFLIGHT";
  public static readonly MaintainancePeStats = "MAINTAINANCEPSTAS";
  public static readonly MyFavourite = "MYFAVOURITE";
  public static readonly MyItem = "MYITEM";
  public static readonly Nef = "NEF";
  public static readonly NonSafetyReport = "NONSAFETYREPORT";
  public static readonly SubmitPhoto = "SUBMITPHOTO";
  public static readonly Subscribe = "SUBSCRIBE";
  public static readonly TravelTabs = "TRAVELTABS";
  public static readonly TravelRequest = "TRAVELREQUEST";
  public static readonly XJTChart = "XJTCHART";
  public static readonly XJTContactDropDown = "XJTCONTACTDROPDOWN";
  public static readonly XJTPerformance = "XJTPERFORMANCE";
  public static readonly ChemicalRequest = "CHEMICALREQUEST";
}
