class TopStoryItem {
    constructor(private topStoriesItem: TopStoryItem) {
        this.contentID = topStoriesItem.contentID;
        this.isExternalLink = topStoriesItem.isExternalLink;
        this.alternateLink = topStoriesItem.alternateLink;
        this.alternateLinkTarget = topStoriesItem.alternateLinkTarget;
        this.article = topStoriesItem.article;
        this.postDate = topStoriesItem.postDate;
        this.summary = topStoriesItem.summary;
        this.title = topStoriesItem.title;
    }

    public contentID: number;
    public title: string;
    public summary: string;
    public article: string;
    public alternateLink: string;
    public alternateLinkTarget: string;
    public postDate?: Date;
    public isExternalLink: boolean;
}


class TopStoryItemModelContainer {
    constructor(private container: TopStoryItemModelContainer) {     
    }
    public count: number;
    public items: TopStoryItem[];
}

export { TopStoryItem, TopStoryItemModelContainer };