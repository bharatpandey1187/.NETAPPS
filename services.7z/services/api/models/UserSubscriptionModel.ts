export default class UserSubscriptionModel
{
    public ID:number;
    public Name:string;
    public Frequency:string;
    public DisableSelected:boolean;
    public  CheckboxChecked:boolean;    
}
