class AllMenuItems {
    constructor(private AllMenuItems: AllMenuItems) {
    
       
        this.menuId= AllMenuItems.menuId,
        this.parentId= AllMenuItems.parentId,
        this.menuText= AllMenuItems.menuText,
        this.favoriteName= AllMenuItems.favoriteName,
        this.path= AllMenuItems.path,
        this.menuItemSequence= AllMenuItems.menuItemSequence,
        this.order= AllMenuItems.order,
        this.level= AllMenuItems.level,
        this.isSelected= AllMenuItems.isSelected,
        this.targetURL= AllMenuItems.targetURL,
        this.targetWindow= AllMenuItems.targetWindow,
        this.children= AllMenuItems.children
    }

   
    public menuId: number;
    public parentId: number;
    public menuText: string;
    public favoriteName: string;
    public path: string;
    public menuItemSequence: number;
    public order: number;
    public level: number;
    public isSelected: boolean;
    public targetURL: string;
    public targetWindow:string;
    public children:any;
    
   
}



export { AllMenuItems};