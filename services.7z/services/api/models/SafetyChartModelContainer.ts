class SafetyChartModelContainer {
  constructor(private container: SafetyChartModelContainer) {}
  private ojiInjuriesStats: any;
  private ojiInjuriesGoals: any;
  private aircraftDamages: any;
  private aircraftDamagesGoals: any;
}

export { SafetyChartModelContainer };
