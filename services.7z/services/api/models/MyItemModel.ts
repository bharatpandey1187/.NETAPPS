export default class MyItemModel {
    public id: number;
    public empNo: string;
    public application: string;
    public category: string;
    public message: string;
    public url: string;
    public targetWindow: string;
    public dateCreated: Date;
    public itemType:string;
}