class MyFavoriteViewModel {
    constructor(private EditMyFavouritesItem: MyFavoriteViewModel) {
    
       
        this.menuId= EditMyFavouritesItem.menuId,
        this.parentId= EditMyFavouritesItem.parentId,
        this.menuText= EditMyFavouritesItem.menuText,
        this.favoriteName= EditMyFavouritesItem.favoriteName,
        this.path= EditMyFavouritesItem.path,
        this.menuItemSequence= EditMyFavouritesItem.menuItemSequence,
        this.order= EditMyFavouritesItem.order,
        this.level= EditMyFavouritesItem.level,
        this.isSelected= EditMyFavouritesItem.isSelected,
        this.targetURL= EditMyFavouritesItem.targetURL,
        this.targetWindow= EditMyFavouritesItem.targetWindow,
        this.isXJTAppUrl=EditMyFavouritesItem.isXJTAppUrl,
        this.children= EditMyFavouritesItem.children
    }

   
    public menuId: number;
    public parentId: number;
    public menuText: string;
    public favoriteName: string;
    public path: string;
    public menuItemSequence: number;
    public order: number;
    public level: number;
    public isSelected: boolean;
    public targetURL: string;
    public targetWindow:string;
    public isXJTAppUrl:boolean;
    public children:MyFavoriteViewModel[];    
   
}
class MyFavouritesItemModelContainer {
    constructor(private container: MyFavouritesItemModelContainer) {     
    }
    public count: number;
    public allItems: MyFavoriteViewModel[];
    public myFavourites:MyFavoriteViewModel[];
}


export { MyFavoriteViewModel,MyFavouritesItemModelContainer};