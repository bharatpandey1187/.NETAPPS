export default class NewsCategoryItemModel
{
    public ID:number;
    public Title:string;
    public Enabled:boolean;
}