class MyFavoriteViewModel {
    public id: number;
    public parentId: number;
    public menuText?: string;
    public uniqueName?: string;
    public favoriteName?: string;
    public path?: string;
    public menuItemSequence?: number;
    public order?: number;
    public level?: number;
    public isSelected: boolean = false;
    public targetUrl?: string;
    public targetWindow?: string;
    public securedSubMenu?: MyFavoriteViewModel[];
    public IsXjtAppUrl: boolean;

}
class MyFavouritesItemModelContainer {
    constructor(private container: MyFavouritesItemModelContainer) {
        this.myFavourites = container.myFavourites;
        this.allItems = container.allItems;
    }
    public count: number;
    public allItems: MyFavoriteViewModel[];
    public myFavourites: MyFavoriteViewModel[];
}


export { MyFavoriteViewModel, MyFavouritesItemModelContainer };