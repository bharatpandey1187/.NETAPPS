export default class CommonMyItemModel
{
     public LinkTitle:string;
     public Description:string;
     public LogoUrl:string;
     public LogoAlternateText:string;
     public LinkUrl:string;
     public LinkAlternateText:string;
     public IsActive:boolean;
     TargetWindow:string;
}