export default class SecurityModel
{
    public id?:string;
    public empNo?:string;
    public description?:string;
}