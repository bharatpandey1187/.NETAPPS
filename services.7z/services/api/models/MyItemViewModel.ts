import MyItemModel from "./MyItemModel";

export default class MyItemViewModel
{
    public category:string;
    public items: MyItemModel[];
}