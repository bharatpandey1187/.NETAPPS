export default class IUser {
    private displayName: string;
    private Id: number;
    private loginName: string;
    private email: string;

    public constructor(Id: number, displayName: string, loginName: string, email: string) {
        this.Id = Id;
        this.displayName = displayName;
        this.loginName = loginName;
        this.email = email;
    }

    get DisplayName(): string { return this.displayName; }
    set DisplayName(displayName: string) { this.displayName = displayName; }

    get GetId(): number { return this.Id; }
    set SetId(Id: number) { this.Id = Id; }

    get GetLoginName(): string { return this.loginName; }
    set SetLoginName(loginName: string) { this.loginName = loginName; }

    get GetEmail(): string { return this.email; }
    set SetEmail(email: string) { this.email = email; }
}