export default class AppConfig<T, U> {
    public configKey: T;
    public configValue: U;
   
    constructor(configKey: T, configValue: U) {
        this.configKey = configKey;
        this.configValue = configValue;
    }   
}