export class NewsItemFrequencyModel {
    public ID: number;
    public FrequencyType: string;
    public Selected: boolean;
  }