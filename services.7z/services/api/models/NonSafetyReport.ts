class NonSaftetReportUserModel {
    constructor(private NonSaftetReportItem: NonSaftetReportUserModel) {
    
       
        this.empNo= NonSaftetReportItem.empNo,
        this.preferredName= NonSaftetReportItem.preferredName,
        this.firstName= NonSaftetReportItem.firstName,
        this.lastName= NonSaftetReportItem.lastName,
        this.middleName= NonSaftetReportItem.middleName,
        this.email= NonSaftetReportItem.email,
        this.managerEmpNo= NonSaftetReportItem.managerEmpNo,
        this.managerPreferredName= NonSaftetReportItem.managerPreferredName,
        this.managerFirstName= NonSaftetReportItem.managerFirstName,
        this.managerLastName= NonSaftetReportItem.managerLastName,
        this.managerMiddleName= NonSaftetReportItem.managerMiddleName,
        this.managerEmail= NonSaftetReportItem.managerEmail,
        this.gender= NonSaftetReportItem.gender,
        this.dateOfBirth= NonSaftetReportItem.dateOfBirth,
        this.position= NonSaftetReportItem.position,
        this.position= NonSaftetReportItem.position,
        this.seniority= NonSaftetReportItem.seniority,
        this.equipment= NonSaftetReportItem.equipment,
        this.workPhone= NonSaftetReportItem.workPhone,
        this.domicile= NonSaftetReportItem.domicile,
        this.managerName= NonSaftetReportItem.managerName,
        this.employeeName= NonSaftetReportItem.employeeName
    }

   
    
  public empNo: string;
  public preferredName: string;
  public firstName: string;
  public lastName: string;
  public middleName: string;
  public email: string;
  public managerEmpNo:string;
  public managerPreferredName: string;
  public managerFirstName: string;
  public managerLastName: string;
  public managerMiddleName:string;
  public managerEmail: string;
  public gender: string;
  public dateOfBirth: string;
  public location: string;
  public position: string;
  public seniority: string;
  public equipment: string;
  public workPhone: string;
  public domicile:string;
  public managerName: string;
  public employeeName: string;
 
}

class SelectModel
{
    public name:string;
    public value:string;
}

class NonSafetySubCategories
{
    public category:string;
    public subCategories:SelectModel;
}

class NonSafetyFlight
{
      public flightCode: string;
      public airline: string;
      public description:string;
      public flight: string;
      public origin: string;
      public destination:string;
      public scheduledTime: string;
      public outTime: string;
      public minutes: string;
      public aircraftType: string;
      public codeShare: string;
      public tail: string;
      public flightDate: string;
      public scheduledOrigin: string;
      public scheduledDestination: string;
      public title: string;
}

class nonSafetyReport
{
        public eventId: number;
        public datePosted: string;
        public empNo:string;
        public eventDate: string;
        public category: string;
        public subCategory: string;
        public fleetType:string;
        public partner: string;
        public flight: string;
        public occurrenceCity: string;
        public attachment: string;
        public narrative:string;
        public resolved: false;
        public draft: true;
        public isFlightRelatedEvent: true;
        public selectedValue:string;
}

class NonSafetyReportViewModelContainer
   {
    constructor(private container: NonSafetyReportViewModelContainer) {     
    }

    public user: NonSaftetReportUserModel[];
    public nonSafetyReportCategories:SelectModel[];
    public nonSafetyReportSubCategories:NonSafetySubCategories[];    
    public nonSafetyReportingEvents :nonSafetyReport[];
   
}

class FlightViewModel
   {
    constructor(private container: NonSafetyReportViewModelContainer) {     
    }

    public result: NonSafetyFlight[];
  
   
}


export {FlightViewModel,nonSafetyReport, NonSafetyReportViewModelContainer};