class MyFavouritesItem {
    constructor(private MyItem: MyFavouritesItem) {
    
        this.menuId = MyItem.menuId;
        this.menuText=MyItem.menuText;
        this.favoriteName=MyItem.favoriteName;
        this.path=MyItem.path;
        this.menuItemSequence=MyItem.menuItemSequence;
        this.order=MyItem.order;
        this.level=MyItem.level;
        this.isSelected=MyItem.isSelected;
        this.targetURL=MyItem.targetURL;
        this.targetWindow=MyItem.targetWindow;
    }

   
    public menuId: number;
    public menuText: string;
    public favoriteName: string;
    public path: string;
    public menuItemSequence: string;
    public order: string;
    public level: string;
    public isSelected: string;
    public targetURL: string;
    public targetWindow: string;
   
}



export { MyFavouritesItem};