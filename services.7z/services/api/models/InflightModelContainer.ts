class InflightItems {
    constructor(private inflightItem: InflightItems) {
        this.monthName = inflightItem.monthName;
        this.lossTimeEventTickers = inflightItem.lossTimeEventTickers;
        this.performanceStats = inflightItem.performanceStats;
        this.ytdInjuries = inflightItem.ytdInjuries;
        this.ytdInjuryDrivers = inflightItem.ytdInjuryDrivers;
       
    }

    public monthName: string;
    public ytdInjuries: any;
    public ytdInjuryDrivers: any;
    public lossTimeEventTickers: any;
    public performanceStats: any;
 
}


class InflightModelContainer {
    constructor(private container: InflightModelContainer) {     
    }
    public items: InflightItems[];
}

export { InflightItems, InflightModelContainer };