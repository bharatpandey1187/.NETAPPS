export class FlightCancellationData
{
    public ytdRecord:string;
    public lastCancellation:string;   
}

export class LightCrudeOilModel
{
    public ticker:string;
    public description:string;
    public lastTradedPrice:string;
    public priceChange:string;
    public openingPrice:string;
    public daysHigh:string;
    public daysLow:string;
    public volume:string;
    public lastTradedDate:string;
    public lastTradedTime:string;
}
export class CommodityModel
{
    public flightCancellation:FlightCancellationData;
    public crudeOilModel:LightCrudeOilModel;
    constructor()
    {
        this.flightCancellation=new FlightCancellationData();
        this.crudeOilModel= new LightCrudeOilModel();
    }  
}

