import MyItemViewModel from "./MyItemViewModel";

export default class MyItemViewModelContainer
{
    constructor()
    {

    }

    public myItems:MyItemViewModel[];
    public showEventNotificationSection:boolean;
}