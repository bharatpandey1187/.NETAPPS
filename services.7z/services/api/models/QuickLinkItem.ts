export class QuickLinkItem
{
    public linkID: string;
    public  linkText: string;
    public  linkURL: string;
    public order: number;
    public menuKey: string;
    public target: string;
    public groupTitle: string;
    public isExternalLink: string;
}