export default class SecuredMenu
{
    public id:number;
    public parentId:number;
    public sequence:number;
    public uniqueName:string;
    public menuText:string;
    public targetUrl:string;
    public targetWindow:string;
    public enabled:boolean;
    public securedSubMenu:SecuredMenu[];
}