﻿using Coforge.iShare.Services.Core;
using Coforge.iShare.Services.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace Coforge.iShare.Services.WebApi.Controllers
{

    [RoutePrefix("api/PPTX")]
    public class PowerPointServicesController : ApiController
    {
        private IDocumentService documentService;
        private ISharePointOnlineService sharePointOnlineService;
        public PowerPointServicesController(IDocumentService documentService, ISharePointOnlineService sharePointOnlineService)
        {
            this.documentService = documentService;
            this.sharePointOnlineService = sharePointOnlineService;
        }

        [HttpPost]
        [Route("MergeAndGet")]
        public async Task<IHttpActionResult> GetFileAsync([FromBody]PowerPointRequestModel requestModel)
        {
            //converting Pdf file into bytes array  
            var dataBytes = await documentService.GetMergedFile(requestModel);
            //adding bytes to memory stream   
            var dataStream = new MemoryStream(dataBytes);
            return await Task.FromResult(new FileResult(dataStream, Request, requestModel.TargetFileName));
        }

        [HttpGet]
        [Route("GetData")]
        public async Task<IHttpActionResult> Get()
        {
            List<string> result = new List<string>
          {
              "Ram","Bharat","Ramesh","Sachin"
          };

            return await Task.FromResult(Ok(result));
        }

        [HttpGet]
        [Route("GetFile")]
        public async Task<IHttpActionResult> GetFileAsync(string siteUrl, string fileRelativeUrl)
        {
            //converting Pdf file into bytes array  
            var dataBytes = await sharePointOnlineService.GetFileDataAsBytes(siteUrl, fileRelativeUrl);
            //adding bytes to memory stream   
            var dataStream = new MemoryStream(dataBytes);
            return await Task.FromResult(new FileResult(dataStream, Request, Path.GetFileName(fileRelativeUrl)));
        }
    }
}
