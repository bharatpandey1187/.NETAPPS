﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Coforge.iShare.Services.Model
{
    public class PowerPointRequestModel
    {

        public string WebUrl { get; set; } = string.Empty;

        public List<RequestFileModel> Files { get; set; } = new List<RequestFileModel>();

        public string TargetFileName { get; set; } = string.Empty;
    }

    public class RequestFileModel
    {
        public string Name { get; set; }

        public string Order { get; set; }
        public string ServerRelativeUrl { get; set; }
    }
}
