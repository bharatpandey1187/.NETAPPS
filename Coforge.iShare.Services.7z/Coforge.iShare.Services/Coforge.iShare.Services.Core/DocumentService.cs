﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Coforge.iShare.Services.Core.DI;
using Coforge.iShare.Services.Model;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Presentation;
using DocumentFormat.OpenXml.Validation;

namespace Coforge.iShare.Services.Core
{
    [Export(typeof(IDocumentService))]
    public class DocumentService : IDocumentService
    {

        private ISharePointOnlineService sharePointOnlineService;
        public DocumentService(ISharePointOnlineService sharePointOnlineService)
        {
            this.sharePointOnlineService = sharePointOnlineService;
        }

        uint uniqueId;
        public async Task<byte[]> GetMergedFile(PowerPointRequestModel powerPointRequestModel)
        {
            var result = default(byte[]);
            string targetFileName = $"{Path.GetTempPath()}{powerPointRequestModel.TargetFileName}";
            string templateFileName = System.Web.Hosting.HostingEnvironment.MapPath("~/Template/Sample_Template_Office2016.pptx");

            // Make a copy of the template presentation. This will throw an
            // exception if the template presentation does not exist.
            File.Copy(templateFileName, targetFileName, true);
            int id = 0;
            foreach (RequestFileModel fileModel in powerPointRequestModel.Files.OrderBy(x => x.Order))
            {
                byte[] data = await sharePointOnlineService.GetFileDataAsBytes(powerPointRequestModel.WebUrl, fileModel.ServerRelativeUrl);

                using (MemoryStream stream = new MemoryStream(data, false))
                {
                    MergeSlides(stream, targetFileName, fileModel, ref id);
                }
            }
            var errors = default(IEnumerable<ValidationErrorInfo>);

            OpenXmlValidator validator = new OpenXmlValidator();
            using (PresentationDocument mergedPresentation = PresentationDocument.Open(targetFileName, false))
            {
                errors = validator.Validate(mergedPresentation);
            }

            if (!errors.Any())
            {
                result = File.ReadAllBytes(targetFileName);
                if (File.Exists(targetFileName))
                {
                    File.Delete(targetFileName);
                }
            }

            return result;
        }

        private void MergeSlides(Stream sourceStream, string targetFileName, RequestFileModel fileModel, ref int id)
        {
            // Open the destination presentation.
            using (PresentationDocument myDestDeck = PresentationDocument.Open(targetFileName, true))
            {
                PresentationPart destPresPart = myDestDeck.PresentationPart;
                destPresPart.Presentation.SlideIdList = destPresPart.Presentation.SlideIdList ?? new SlideIdList();
                // If the merged presentation does not have a SlideIdList 
                // element yet, add it.
                using (PresentationDocument mySourceDeck = PresentationDocument.Open(sourceStream, false))
                {
                    PresentationPart sourcePresPart = mySourceDeck.PresentationPart;

                    // Get unique ids for the slide master and slide lists
                    // for use later.
                    uniqueId = this.GetMaxSlideMasterId(destPresPart.Presentation.SlideMasterIdList);

                    uint maxSlideId = GetMaxSlideId(destPresPart.Presentation.SlideIdList);

                    // Copy each slide in the source presentation, in order, to 
                    // the destination presentation.
                    foreach (SlideId slideId in sourcePresPart.Presentation.SlideIdList)
                    {
                        SlidePart sp;
                        SlidePart destSp;
                        SlideMasterPart destMasterPart;
                        string relId;
                        SlideMasterId newSlideMasterId;
                        SlideId newSlideId;

                        // Create a unique relationship id.
                        id++;
                        sp = (SlidePart)sourcePresPart.GetPartById(slideId.RelationshipId);
                        //   mySourceDeck.
                        relId = "mrId" + id;

                        // Add the slide part to the destination presentation.
                        destSp = destPresPart.AddPart<SlidePart>(sp, relId);

                        // The slide master part was added. Make sure the
                        // relationship between the main presentation part and
                        // the slide master part is in place.
                        destMasterPart = destSp.SlideLayoutPart.SlideMasterPart;
                        destPresPart.AddPart(destMasterPart);

                        // Add the slide master id to the slide master id list.
                        uniqueId++;
                        newSlideMasterId = new SlideMasterId();
                        newSlideMasterId.RelationshipId = destPresPart.GetIdOfPart(destMasterPart);
                        newSlideMasterId.Id = uniqueId;

                        destPresPart.Presentation.SlideMasterIdList.Append(newSlideMasterId);

                        // Add the slide id to the slide id list.
                        maxSlideId++;
                        newSlideId = new SlideId();
                        newSlideId.RelationshipId = relId;
                        newSlideId.Id = maxSlideId;

                        destPresPart.Presentation.SlideIdList.Append(newSlideId);
                    }

                    // Make sure that all slide layout ids are unique.
                    FixSlideLayoutIds(destPresPart);
                }

                // Save the changes to the destination deck.
                destPresPart.Presentation.Save();
            }
        }
        private void FixSlideLayoutIds(PresentationPart presPart)
        {
            // Make sure that all slide layouts have unique ids.
            foreach (SlideMasterPart slideMasterPart in presPart.SlideMasterParts)
            {
                foreach (SlideLayoutId slideLayoutId in
                  slideMasterPart.SlideMaster.SlideLayoutIdList)
                {
                    uniqueId++;
                    slideLayoutId.Id = (uint)uniqueId;
                }

                slideMasterPart.SlideMaster.Save();
            }
        }

        private uint GetMaxSlideId(SlideIdList slideIdList)
        {
            // Slide identifiers have a minimum value of greater than or
            // equal to 256 and a maximum value of less than 2147483648. 
            uint max = 256;

            if (slideIdList != null)
                // Get the maximum id value from the current set of children.
                foreach (SlideId child in slideIdList.Elements<SlideId>())
                {
                    uint id = child.Id;

                    if (id > max)
                        max = id;
                }

            return max;
        }

        private uint GetMaxSlideMasterId(SlideMasterIdList slideMasterIdList)
        {
            // Slide master identifiers have a minimum value of greater than
            // or equal to 2147483648. 
            uint max = 2147483648;

            if (slideMasterIdList != null)
                // Get the maximum id value from the current set of children.
                foreach (SlideMasterId child in slideMasterIdList.Elements<SlideMasterId>())
                {
                    uint id = child.Id;

                    if (id > max)
                        max = id;
                }

            return max;
        }

    }
}
