﻿using Coforge.iShare.Services.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coforge.iShare.Services.Core
{
    public interface IDocumentService
    {
        Task<byte[]> GetMergedFile(PowerPointRequestModel powerPointRequestModel);
    }
}
