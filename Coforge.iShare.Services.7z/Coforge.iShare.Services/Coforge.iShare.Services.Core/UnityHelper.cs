﻿using Coforge.iShare.Services.Core.DI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace Coforge.iShare.Services.Core
{
    public sealed class UnityHelper
    {
        public static List<IAssemblyInitializer> assemblyInitializers = new List<IAssemblyInitializer>
        {
            new AssemblyInitializer()
        };
        private IUnityContainer unityContainer;
        public UnityHelper()
        {

            unityContainer = GetUnityContainer();
        }

        public  IUnityContainer GetUnityContainer()
        {
            unityContainer = unityContainer ?? new UnityContainer();
            foreach (var assemblyInitializer in assemblyInitializers)
            {
                assemblyInitializer.Initialize(unityContainer);
            }

            return unityContainer;
        }
    }
}
