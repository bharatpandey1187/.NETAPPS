﻿using Coforge.iShare.Services.Core.DI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace Coforge.iShare.Services.Core
{
    public class AssemblyInitializer : IAssemblyInitializer
    {
        public bool Initialize(IUnityContainer unityContainer)
        {
            return new ExportAttributeBasedConfigureContainer().RegisterTypes(unityContainer, System.Reflection.Assembly.GetExecutingAssembly());
        }
    }
}
