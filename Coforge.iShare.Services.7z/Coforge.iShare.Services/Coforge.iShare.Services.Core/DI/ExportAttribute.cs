﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coforge.iShare.Services.Core.DI
{
    public class ExportAttribute : Attribute
    {
        public Type Type { get; private set; }
        public LifeTime Scope { get; private set; }

        public ExportAttribute(Type type) : this(type, LifeTime.Transient)
        {
            Type = type;
        }

        public ExportAttribute(Type type, LifeTime lifeTime)
        {
            Type = type;
            Scope = lifeTime;
        }
    }

    public enum LifeTime
    {
        Singleton,
        Scoped,
        Transient
    }
}
