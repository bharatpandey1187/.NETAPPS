﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Unity;
using Unity.Lifetime;

namespace Coforge.iShare.Services.Core.DI
{
    public class ExportAttributeBasedConfigureContainer
    {
        /// <summary>
        /// Registers the types in the ASP.NET Core Service Container from the assembly.
        /// </summary>
        /// <param name="unityContainer">The unity container.</param>
        /// <param name="assembly">The assembly.</param>
        /// <returns>returns true on successful registration, false otherwise</returns>
        public bool RegisterTypes(IUnityContainer unityContainer, Assembly assembly)
        {
            var result = default(bool);
            try
            {
                var types = assembly.GetExportedTypes().Where(x => !x.IsAbstract
                                                                   && !x.IsInterface
                                                                   && x.CustomAttributes.Any(attribute => attribute.AttributeType == typeof(ExportAttribute)));
                if (types.Any())
                {
                    foreach (Type type in types)
                    {
                        RegisterType(unityContainer, type);
                    }

                    result = true;
                }
            }
            catch
            {
                result = false;
            }

            return result;
        }

        /// <summary>
        /// Registers the type.
        /// </summary>
        /// <param name="services">The ASP.NET Core service container.</param>
        /// <param name="type">The target type.</param>
        /// <exception cref="ArgumentException">Invalid arguments while registering type</exception>
        private void RegisterType(IUnityContainer unityContainer, Type type)
        {

            var exportAttribute = type.GetCustomAttribute(typeof(ExportAttribute)) as ExportAttribute;
            if (exportAttribute != default(ExportAttribute))
            {
                switch (exportAttribute.Scope)
                {
                    case LifeTime.Transient:
                        unityContainer.RegisterType(exportAttribute.Type, type, new TransientLifetimeManager());
                        break;
                    case LifeTime.Scoped:
                        unityContainer.RegisterType(exportAttribute.Type, type, new HierarchicalLifetimeManager());
                        break;
                    case LifeTime.Singleton:
                        unityContainer.RegisterType(exportAttribute.Type, type, new SingletonLifetimeManager());
                        break;
                    default:
                        throw new ArgumentException($"Invalid arguments while registering type,typeName:{exportAttribute.Type.FullName}", exportAttribute.Scope.ToString());
                }
            }
        }
    }
}
