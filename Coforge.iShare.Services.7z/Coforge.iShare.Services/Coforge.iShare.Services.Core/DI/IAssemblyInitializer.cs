﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace Coforge.iShare.Services.Core.DI
{
    public interface IAssemblyInitializer
    {
        bool Initialize(IUnityContainer unityContainer);
    }
}
