﻿using Coforge.iShare.Services.Core.DI;
using Microsoft.SharePoint.Client;
using OfficeDevPnP.Core;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coforge.iShare.Services.Core
{
    [Export(typeof(ISharePointOnlineService))]
    public class SharePointOnlineService : ISharePointOnlineService
    {
        private ClientContext clientContext;

        public SharePointOnlineService()
        {
            AuthenticationManager authenticationManager = new AuthenticationManager();
            clientContext = authenticationManager.GetAppOnlyAuthenticatedContext(ConfigurationManager.AppSettings[Constants.AppSettings.SiteUrl], ConfigurationManager.AppSettings[Constants.AppSettings.ClientId], ConfigurationManager.AppSettings[Constants.AppSettings.ClientSecret]);
        }

        public async Task<byte[]> GetFileDataAsBytes(string webUrl, string fileUrl)
        {
            byte[] fileData = default(byte[]);
            var web = clientContext.Web;
            var file = clientContext.Web.GetFileByServerRelativeUrl(fileUrl);
            ClientResult<Stream> data = file.OpenBinaryStreamWithOptions(SPOpenBinaryOptions.MinimizeProcessing);
            clientContext.Load(file);
            await clientContext.ExecuteQueryAsync();
            using (System.IO.MemoryStream mStream = new System.IO.MemoryStream())
            {
                if (data != null)
                {
                    data.Value.CopyTo(mStream);
                    fileData = mStream.ToArray();
                }
            }

            return fileData;
        }
    }
}
